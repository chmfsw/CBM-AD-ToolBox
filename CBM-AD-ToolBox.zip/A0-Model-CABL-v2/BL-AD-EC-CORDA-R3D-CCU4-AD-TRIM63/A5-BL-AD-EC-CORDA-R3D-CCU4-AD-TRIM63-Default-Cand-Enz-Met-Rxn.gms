$ontext
flag_model =        1.00

weighting factor for rxn with HC, MC, NC and OT assigned by the user
Weight_factor_Rxn_HCWeight_factor_Rxn_MCWeight_factor_Rxn_NCWeight_factor_Rxn_OT
        0.25        0.50        0.75        1.00
$offtext

sets
    RegulationSet "set of up/down and KO regulations"
    /
      'Reg1',       'Reg2',       'Reg3'
    /

    Candidate_rxn(reactions) "candidate reactions can be regulated"
    Candidate_enz(enzymes) "candidate enzymes can be regulated"
    Candidate_biocomp(biocompound) "candidate biocompound can be regulated"
    
    Essen_Cand_rxn(reactions) "candidate essential reactions can be regulated"
    Essen_Cand_enz(enzymes) "candidate essential enzymes can be regulated"
    Essen_Cand_biocomp(biocompound) "candidate essential biocompound can be regulated";

parameters
    index_Rxn_Reg(reactions, RegulationSet) "index to show candidate reactions"
    index_Enz_Reg(enzymes, RegulationSet) "index to show candidate enzymes"
*    index_Species_Reg(species, RegulationSet) "index to show candidate species"
    index_biocomp_Reg(biocompound, RegulationSet) "index to show candidate biocompound";
    
***** Candidate enzymes, metabolite and reactions provided by a user ********************************************************************************
candidate_Enz(Enzymes) = feasible_enz(enzymes) - Enzymes_NCA(Enzymes) - transport_enz(enzymes) -
                         Met_NonGPR_enz(enzymes) - exchange_enz(enzymes) - DM_sink_enz(enzymes);

Candidate_rxn(reactions) $ (not exchange_rxn(reactions)) = yes;

Candidate_biocomp(biocompound) = BioCompound_class1(biocompound) + BioCompound_class2(biocompound) +
                                 BioCompound_class3(biocompound) + BioCompound_class4(biocompound);
                                 
Essen_Cand_enz(enzymes) = candidate_Enz(Enzymes);
Essen_Cand_rxn(reactions) = Candidate_rxn(reactions);   
Essen_Cand_biocomp(biocompound) = Candidate_biocomp(biocompound); 
******************************************************************************************************************************************************

index_Enz_Reg(enzymes, 'Reg1') $ (candidate_Enz(Enzymes)) = 1;
index_Enz_Reg(enzymes, 'Reg2') $ (candidate_Enz(Enzymes)) = 2;
index_Enz_Reg(enzymes, 'Reg3') $ (candidate_Enz(Enzymes)) = 3;

index_biocomp_Reg(biocompound, 'Reg1') $ (Candidate_biocomp(biocompound)) = 1;
index_biocomp_Reg(biocompound, 'Reg2') $ (Candidate_biocomp(biocompound)) = 2;
index_biocomp_Reg(biocompound, 'Reg3') $ (Candidate_biocomp(biocompound)) = 3;

index_Rxn_Reg(reactions, 'Reg1') $ (Candidate_rxn(reactions)) = 1;
index_Rxn_Reg(reactions, 'Reg2') $ (Candidate_rxn(reactions)) = 2;
index_Rxn_Reg(reactions, 'Reg3') $ (Candidate_rxn(reactions)) = 3;