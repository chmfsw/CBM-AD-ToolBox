sets
***** S_hco3[m]
    syn_vb_rxn(reactions) "Synthesis reactions toward to species represented as the reactant in the reaction: C + D (desired species) <-- A + B"
    /

    /

    syn_vf_rxn(reactions) "Synthesis reactions toward to species represented as the product in the reaction: A + B --> C + D (desired species)"
    /

    /

***** S_glyc3p[m]
    syn_vb_rxn(reactions) "Synthesis reactions toward to species represented as the reactant in the reaction: C + D (desired species) <-- A + B"
    /

    /

    syn_vf_rxn(reactions) "Synthesis reactions toward to species represented as the product in the reaction: A + B --> C + D (desired species)"
    /

    /

***** S_glyc[m]
    syn_vb_rxn(reactions) "Synthesis reactions toward to species represented as the reactant in the reaction: C + D (desired species) <-- A + B"
    /

    /

    syn_vf_rxn(reactions) "Synthesis reactions toward to species represented as the product in the reaction: A + B --> C + D (desired species)"
    /

    /

***** S_dhap[m]
    syn_vb_rxn(reactions) "Synthesis reactions toward to species represented as the reactant in the reaction: C + D (desired species) <-- A + B"
    /

    /

    syn_vf_rxn(reactions) "Synthesis reactions toward to species represented as the product in the reaction: A + B --> C + D (desired species)"
    /

    /

***** S_aact[m]
    syn_vb_rxn(reactions) "Synthesis reactions toward to species represented as the reactant in the reaction: C + D (desired species) <-- A + B"
    /

    /

    syn_vf_rxn(reactions) "Synthesis reactions toward to species represented as the product in the reaction: A + B --> C + D (desired species)"
    /

    /

***** S_glu5sa[c]
    syn_vb_rxn(reactions) "Synthesis reactions toward to species represented as the reactant in the reaction: C + D (desired species) <-- A + B"
    /

    /

    syn_vf_rxn(reactions) "Synthesis reactions toward to species represented as the product in the reaction: A + B --> C + D (desired species)"
    /

    /

***** S_glyald[m]
    syn_vb_rxn(reactions) "Synthesis reactions toward to species represented as the reactant in the reaction: C + D (desired species) <-- A + B"
    /

    /

    syn_vf_rxn(reactions) "Synthesis reactions toward to species represented as the product in the reaction: A + B --> C + D (desired species)"
    /

    /

***** S_3pg[m]
    syn_vb_rxn(reactions) "Synthesis reactions toward to species represented as the reactant in the reaction: C + D (desired species) <-- A + B"
    /

    /

    syn_vf_rxn(reactions) "Synthesis reactions toward to species represented as the product in the reaction: A + B --> C + D (desired species)"
    /

    /

***** S_aacoa[c][m][x]
    syn_vb_rxn(reactions) "Synthesis reactions toward to species represented as the reactant in the reaction: C + D (desired species) <-- A + B"
    /

    /

    syn_vf_rxn(reactions) "Synthesis reactions toward to species represented as the product in the reaction: A + B --> C + D (desired species)"
    /

    /

