$onempty
sets
***** the user defines the following sets of objectives for the inner FBA and UFD problems **********************************************************
   ObjectSet "Multiobjectives of cell viability and bioenginnering in the outer optimization problem"
       /'ATP','DM_Tau','DM_Abeta','DM_IL6','DM_TNFA','Tau_syn','Abeta_syn','IL6_syn','TNFA_syn',
        'Ubiquitin_syn'/
*       ,'Itaconate'/

***** define reactions for each objective
    syn_vb_rxn(ObjectSet, reactions) "Synthesis reactions toward to species represented as the reactant in the reaction: C + D (desired species) <-- A + B"
    /   /

    syn_vf_rxn(ObjectSet, reactions) "Synthesis reactions toward to species represented as the product in the reaction: A + B --> C + D (desired species)"
    /
       'ATP'. ('R_ATPS4mi')
       'Tau_syn'. ('R_Tau_syn')
       'DM_Tau'. ('R_DM_Tau')
       'Abeta_syn'. ('R_Abeta_syn')
       'DM_Abeta'. ('R_DM_Abeta')
       'IL6_syn'. ('R_IL6_syn')
       'DM_IL6'. ('R_DM_IL6')
       'TNFA_syn'. ('R_TNFA_syn')
       'DM_TNFA'. ('R_DM_TNFA')
       'Ubiquitin_syn'. ('R_Ubiquitin_syn')
    /
    
    deg_vb_rxn(objectSet, reactions) "degradation reactions backward from species represented as the reactant in the reaction: <-- A"
     /
     /

    deg_vf_rxn(objectSet, reactions) "degradation reactions forward fromm the species represented as the reactant in the reaction: A-->"
     /
     /
*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

*%%%%% Fuzzy objectives for treated CA and perturbed BL/HT in the outer optimization problem %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
***** Fuzzy objectives of treated CA, TR, in the outer optimization problem 
   FmaxObj_Outer_TR(ObjectSet) "fuzzy max objectives for treated CA model"
      /'ATP'/
       
   FminObj_Outer_TR(ObjectSet) "fuzzy min objectives for treated CA model"
       /'DM_Tau','DM_Abeta','DM_IL6','DM_TNFA'/       

   PriObj_Outer_TR(ObjectSet) "priority objectives for treated CA model"
       /'DM_Tau','DM_Abeta','DM_IL6','DM_TNFA'/
*****************************************************************************************************************************************************   
***** Fuzzy objectives for perturbed BL, PB, in the outer optimization problem 
   FmaxObj_Outer_PB(ObjectSet) "fuzzy max objectives for perturbed BL model"
       /'ATP'/
       
   FminObj_Outer_PB(ObjectSet) "fuzzy min objectives for perturbed BL model"
       / /
       
   PriObj_Outer_PB(ObjectSet) "priority objectives for perturbed BL model"
       /'ATP'/
*****************************************************************************************************************************************************       
*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

*%%%%% Fuzzy objectives for CA, BL, HT, TR, PB and PH in the inner optimization problem %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
***** Fuzzy objectives for CA model in the inner optimization problem; The prime CA model is not treated  
   FmaxObj_Inner_CA(ObjectSet) "fuzzy max objectives for CA model"
       /'ATP','Tau_syn','Abeta_syn','IL6_syn','TNFA_syn', 'Ubiquitin_syn'/  

   FminObj_Inner_CA(ObjectSet) "fuzzy min objectives for CA model"
       / /    

   PriObj_Inner_CA(ObjectSet) "priority objectives for CA problem"
       /'Tau_syn','Abeta_syn','IL6_syn','TNFA_syn'/
*****************************************************************************************************************************************************

***** Fuzzy objectives for BL model in the inner optimization problem; The prime BL model is not perturbed 
   FmaxObj_Inner_BL(ObjectSet) "fuzzy max objectives for BL model"
       /'ATP'/
       
   FminObj_Inner_BL(ObjectSet) "fuzzy min objectives for BL model"
       / /
       
   PriObj_Inner_BL(ObjectSet) "priority objectives for BL problem"
       /'ATP'/
*****************************************************************************************************************************************************
      
***** Fuzzy objectives for perturbed BL model, PB, in the inner optimization problem; The prime BL model is perturbed. 
   FmaxObj_Inner_PB(ObjectSet) "fuzzy max objectives for PB model"
      /'ATP','Tau_syn','Abeta_syn','IL6_syn','TNFA_syn',  'Ubiquitin_syn'/
   
   FminObj_Inner_PB(ObjectSet) "fuzzy min objectives for PB model"
   / /
   
   PriObj_Inner_PB(ObjectSet) "priority objectives for PB problem"
   /'Tau_syn','Abeta_syn','IL6_syn','TNFA_syn'/

*****************************************************************************************************************************************************
*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
**%%%% A user can assign the sets for TR, PB and PH dependent the cell characteristics. %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
***** Fuzzy objectives for HT model in the outer optimization problem
   FmaxObj_Outer_PH(ObjectSet) "fuzzy max objectives for perturbed HT model" / /
   FminObj_Outer_PH(ObjectSet) "fuzzy min objectives for perturbed HT model" / /
   PriObj_Outer_PH(ObjectSet) "priority objectives for perturbed HT model" / /
*****************************************************************************************************************************************************
***** Fuzzy objectives for HT model in the inner optimization problem; ; The healthy HT model is not perturbed. 
   FmaxObj_Inner_HT(ObjectSet) "fuzzy max objectives for HT model" / /
   FminObj_Inner_HT(ObjectSet) "fuzzy min objectives for HT model" / /
   PriObj_Inner_HT(ObjectSet) "priority objectives for HT problem" / /
*****************************************************************************************************************************************************   
***** Fuzzy objectives for treated CA model, TR, in the inner optimization problem; The cancer CA model is treated. 
   FmaxObj_Inner_TR(ObjectSet) "fuzzy max objectives for TR model" / /
   FminObj_Inner_TR(ObjectSet) "fuzzy min objectives for TR model" / /
   PriObj_Inner_TR(ObjectSet) "priority objectives for TR problem" / /
*****************************************************************************************************************************************************
***** Fuzzy objectives for perturbed HT model, PH, in the inner optimization problem; The healthy HT model is perturbed.
   FmaxObj_Inner_PH(ObjectSet) "fuzzy max objectives for PH model" / /      
   FminObj_Inner_PH(ObjectSet) "fuzzy min objectives for PH model" / /
   PriObj_Inner_PH(ObjectSet) "priority objectives for PH problem" / /;
*****************************************************************************************************************************************************
FmaxObj_Outer_PH(ObjectSet) $ (card(FmaxObj_Outer_PH) = 0) = FmaxObj_Outer_PB(ObjectSet);
FminObj_Outer_PH(ObjectSet) $ (card(FminObj_Outer_PH) = 0) = FminObj_Outer_PB(ObjectSet);
PriObj_Outer_PH(ObjectSet) $ (card(PriObj_Outer_PH) = 0) = PriObj_Outer_PB(ObjectSet);

FmaxObj_Inner_HT(ObjectSet) $ (card(FmaxObj_Inner_HT) = 0) = FmaxObj_Inner_BL(ObjectSet);
FminObj_Inner_HT(ObjectSet) $ (card(FminObj_Inner_HT) = 0) = FminObj_Inner_BL(ObjectSet);
PriObj_Inner_HT(ObjectSet) $ (card(PriObj_Inner_HT) = 0) = PriObj_Inner_BL(ObjectSet);

FmaxObj_Inner_TR(ObjectSet) $ (card(FmaxObj_Inner_TR) = 0) = FmaxObj_Inner_CA(ObjectSet);
FminObj_Inner_TR(ObjectSet) $ (card(FminObj_Inner_TR) = 0) = FminObj_Inner_CA(ObjectSet);
PriObj_Inner_TR(ObjectSet) $ (card(PriObj_Inner_TR) = 0) = PriObj_Inner_CA(ObjectSet);

FmaxObj_Inner_PH(ObjectSet) $ (card(FmaxObj_Inner_PH) = 0) = FmaxObj_Inner_PB(ObjectSet);
FminObj_Inner_PH(ObjectSet) $ (card(FminObj_Inner_PH) = 0) = FminObj_Inner_PB(ObjectSet);
PriObj_Inner_PH(ObjectSet) $ (card(PriObj_Inner_PH) = 0) = PriObj_Inner_PB(ObjectSet);

*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
$offEmpty

Parameters
*%%%%% Weighting factors for CA, BL, HT, TR, PB and PH in the inner optimization problem %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
* The weighting factors CA_Weight_mem_obj_FBA use for min{wt_biomass * mem_biomass, wt_ATP * mem_ATP}. 
* smaller weighted value, higher impact on membership grade, mem_obj_FBA, to be chosen as a criterion.

***** weighting factors for the prime CA in the inner optimization problem
    CA_Weight_mem_obj_FBA(ObjectSet) "Weighting factors for mem_obj_FBA in CA; CA_weight = (0, 1]"
      /
        'ATP'           0.3
        'Tau_syn'       1.0
        'Abeta_syn'     1.0
        'IL6_syn'       1.0
        'TNFA_syn'      1.0
        'Ubiquitin_syn' 1.0
      /
      
    TR_Weight_mem_obj_FBA(ObjectSet) "Weighting factors for mem_obj_FBA in treated CA, TR model; TR_weight = (0, 1]"
      /
        'ATP'           1.0
        'Tau_syn'       1.0
        'Abeta_syn'     1.0
        'IL6_syn'       1.0
        'TNFA_syn'      1.0
        'Ubiquitin_syn' 1.0
      /

***** weighting factors for the prime BL in the inner optimization problem      
    BL_Weight_mem_obj_FBA(ObjectSet) "Weighting factors for mem_obj_FBA in BL; BL_weight = (0, 1]"
      /
        'ATP'           1.0
      /

***** weighting factors for the perturbed BL, PB, in the inner optimization problem       
    PB_Weight_mem_obj_FBA(ObjectSet) "Weighting factors for mem_obj_FBA in perturbed BL, PB model; PB_weight = (0, 1]"
      /
        'ATP'           1.0
        'Tau_syn'       1.0
        'Abeta_syn'     1.0
        'IL6_syn'       1.0
        'TNFA_syn'      1.0
        'Ubiquitin_syn' 1.0
      /
****************************************************************************************************************************************************
***** A user can assign the weighting for TR, PB and PH dependent the cell characteristics. ********************************************************
***** weighting factors for HT in the inner optimization problem 
    HT_Weight_mem_obj_FBA(ObjectSet) "Weighting factors for mem_obj_FBA in HT; HT_weight = (0, 1]"
***** weighting factors for treated CA, TR in the inner optimization problem 
*    TR_Weight_mem_obj_FBA(ObjectSet) "Weighting factors for mem_obj_FBA in TR; TR_weight = (0, 1]"
***** weighting factors for perturbed HT, PH in the inner optimization problem       
    PH_Weight_mem_obj_FBA(ObjectSet) "Weighting factors for mem_obj_FBA in perturbed HT, PH model; PH_weight = (0, 1]";

HT_Weight_mem_obj_FBA(ObjectSet) = BL_Weight_mem_obj_FBA(ObjectSet);
*TR_Weight_mem_obj_FBA(ObjectSet) = CA_Weight_mem_obj_FBA(ObjectSet);
PH_Weight_mem_obj_FBA(ObjectSet) = PB_Weight_mem_obj_FBA(ObjectSet);
****************************************************************************************************************************************************

FmaxObj_Inner_CA(ObjectSet) $ (CA_Weight_mem_obj_FBA(ObjectSet) = 0) = no;
FminObj_Inner_CA(ObjectSet) $ (CA_Weight_mem_obj_FBA(ObjectSet) = 0) = no;
FmaxObj_Inner_BL(ObjectSet) $ (BL_Weight_mem_obj_FBA(ObjectSet) = 0) = no;
FminObj_Inner_BL(ObjectSet) $ (BL_Weight_mem_obj_FBA(ObjectSet) = 0) = no;
FmaxObj_Inner_HT(ObjectSet) $ (HT_Weight_mem_obj_FBA(ObjectSet) = 0) = no;
FminObj_Inner_HT(ObjectSet) $ (HT_Weight_mem_obj_FBA(ObjectSet) = 0) = no;
FmaxObj_Inner_TR(ObjectSet) $ (TR_Weight_mem_obj_FBA(ObjectSet) = 0) = no;
FminObj_Inner_TR(ObjectSet) $ (TR_Weight_mem_obj_FBA(ObjectSet) = 0) = no;
FmaxObj_Inner_PB(ObjectSet) $ (PB_Weight_mem_obj_FBA(ObjectSet) = 0) = no;
FminObj_Inner_PB(ObjectSet) $ (PB_Weight_mem_obj_FBA(ObjectSet) = 0) = no;
FmaxObj_Inner_PH(ObjectSet) $ (PH_Weight_mem_obj_FBA(ObjectSet) = 0) = no;
FminObj_Inner_PH(ObjectSet) $ (PH_Weight_mem_obj_FBA(ObjectSet) = 0) = no;
*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%         
abort $ ((card(FmaxObj_Inner_CA) + card(FminObj_Inner_CA)) <> sum(objectset, (CA_weight_mem_obj_FBA(objectset) > 0) = 1))
          " Error: CA_Weight_mem_obj_FBA inconsistence to objectSet in inner CA";          
abort $ ((card(FmaxObj_Inner_BL) + card(FminObj_Inner_BL)) <> sum(objectset, (BL_weight_mem_obj_FBA(objectset) > 0) = 1))
          " Error: BL_Weight_mem_obj_FBA inconsistence to objectSet in inner BL";
abort $ ((card(FmaxObj_Inner_HT) + card(FminObj_Inner_HT)) <> sum(objectset, (HT_weight_mem_obj_FBA(objectset) > 0) = 1))
          " Error: HT_Weight_mem_obj_FBA inconsistence to objectSet in inner HT";
abort $ ((card(FmaxObj_Inner_TR) + card(FminObj_Inner_TR)) <> sum(objectset, (TR_weight_mem_obj_FBA(objectset) > 0) = 1))
          " Error: TR_Weight_mem_obj_FBA inconsistence to objectSet in inner TR";  
abort $ ((card(FmaxObj_Inner_PB) + card(FminObj_Inner_PB)) <> sum(objectset, (PB_weight_mem_obj_FBA(objectset) > 0) = 1))
          " Error: PB_Weight_mem_obj_FBA inconsistence to objectSet in inner PB";          
abort $ ((card(FmaxObj_Inner_PH) + card(FminObj_Inner_PH)) <> sum(objectset, (PH_weight_mem_obj_FBA(objectset) > 0) = 1))
          " Error: PH_Weight_mem_obj_FBA inconsistence to objectSet in inner PH";