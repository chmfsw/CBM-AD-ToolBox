****A4製作****                                    
$onempty                                    
set                                 
$onMulti
BioCompound(universalSet<) "implicit subset of biocompounds defined on BL human model"                                 
/                                   
                                    
*species participate in at least two intracellular compartments, but not included in the extracellular compartment                                  
"S_10fthf5glu[c]",  "S_10fthf5glu[l]",  "S_10fthf5glu[m]",  "S_10fthf6glu[c]",  "S_10fthf6glu[l]",  "S_10fthf6glu[m]",  "S_10fthf7glu[c]",  "S_10fthf7glu[l]",  "S_10fthf7glu[m]",  "S_10fthf[c]", 
"S_10fthf[l]",  "S_10fthf[m]",  "S_11docrtsl[c]",   "S_11docrtsl[m]",   "S_11docrtsl[r]",   "S_11docrtstrn[c]",     "S_11docrtstrn[m]",     "S_11docrtstrn[r]",     "S_h2o[c]",     "S_o2[c]", 
"S_h2o2[c]",    "S_nh4[c]",     "S_h2o[m]",     "S_o2[m]",  "S_h[m]",   "S_nadp[m]",    "S_1a25dhvitd2[m]",     "S_h[c]",   "S_1mncam[c]",  "S_atp[c]", 
"S_adp[c]",     "S_pi[c]",  "S_h[x]",   "S_nadh[x]",    "S_nad[x]",     "S_24nph[c]",   "S_pyr[c]",     "S_nadp[c]",    "S_Lcyst[c]",   "S_L2aadp[c]", 
"S_L2aadp[m]",  "S_akg[m]",     "S_akg[c]",     "S_drib[c]",    "S_nadh[c]",    "S_nad[c]",     "S_2hb[c]",     "S_2obut[c]",   "S_hco3[c]",    "S_na1[c]", 
"S_2mcit[c]",   "S_nadh[m]",    "S_nad[m]",     "S_2oxoadp[m]",     "S_co2[m]",     "S_2oxoadp[c]",     "S_34dhoxpeg[c]",   "S_amet[c]",    "S_ahcys[c]",   "S_34dhoxmand[c]", 
"S_34hpl[m]",   "S_co2[c]",     "S_34hpp[c]",   "S_hgentis[c]",     "S_35cgmp[c]",  "S_35cgmp[n]",  "S_3aib[m]",    "S_glu_L[m]",   "S_3aib[c]",    "S_sphgn[c]", 
"S_3hanthrn[c]",    "S_3hmp[m]",    "S_glu_L[c]",   "S_dopa[c]",    "S_3mob[c]",    "S_3mop[c]",    "S_3mop[m]",    "S_3mox4hoxm[c]",   "S_h2o[l]",     "S_pi[l]", 
"S_asp_L[c]",   "S_asp_L[m]",   "S_so3[c]",     "S_pyr[m]",     "S_adrnl[c]",   "S_mma[c]",     "S_nrpphr[c]",  "S_4abut[c]",   "S_4abut[m]",   "S_4hbz[m]", 
"S_4mptnl[c]",  "S_4mptnl[m]",  "S_4nphsf[c]",  "S_4nph[c]",    "S_5adtststerone[c]",   "S_5aop[c]",    "S_5aop[m]",    "S_5dhf[c]",    "S_5dhf[l]",    "S_5fthf[c]", 
"S_5htrp[c]",   "S_srtn[c]",    "S_5hoxindoa[c]",   "S_5mthf[c]",   "S_5thf[c]",    "S_5thf[l]",    "S_5thf[m]",    "S_6dhf[c]",    "S_6dhf[l]",    "S_6dhf[m]", 
"S_6htststerone[c]",    "S_6htststerone[r]",    "S_6thf[c]",    "S_6thf[l]",    "S_6thf[m]",    "S_7dhchsterol[r]",     "S_7dhchsterol[c]",     "S_7dhf[c]",    "S_7dhf[l]",    "S_7dhf[m]", 
"S_7thf[c]",    "S_7thf[l]",    "S_7thf[m]",    "S_man[c]",     "S_man[l]",     "S_galgluside_hs[c]",   "S_udp[c]",     "S_h[g]",   "S_galgluside_hs[g]",   "S_udp[g]", 
"S_aact[c]",    "S_mthgxl[c]",  "S_aact[m]",    "S_galgalfucfucgalacglcgalacglcgal14acglcgalgluside_hs[g]",     "S_sucsal[m]",  "S_xylu_L[c]",  "S_h[l]",   "S_4abut[l]",   "S_acac[c]",    "S_acac[m]", 
"S_acac[x]",    "S_acald[m]",   "S_acald[c]",   "S_atp[m]",     "S_adp[m]",     "S_pi[m]",  "S_hco3[m]",    "S_amp[m]",     "S_ppi[m]",     "S_ppa[m]", 
"S_acetone[m]",     "S_acgal[c]",   "S_itp[c]",     "S_idp[c]",     "S_acgal[g]",   "S_acgal[l]",   "S_acgam[c]",   "S_acgam[l]",   "S_ac[c]",  "S_acglu[m]", 
"S_ach[n]",     "S_ach[c]",     "S_cit[c]",     "S_oaa[c]",     "S_pep[c]",     "S_acnam[c]",   "S_acnam[n]",   "S_acngalacglcgal14acglcgalgluside_hs[c]",  "S_acngalacglcgal14acglcgalgluside_hs[g]",  "S_acmana[c]", 
"S_o2[x]",  "S_h2o2[x]",    "S_orn[c]",     "S_cit[m]",     "S_icit[m]",    "S_h2o[x]",     "S_fmn[c]",     "S_ribflv[c]",  "S_acrn[c]",    "S_amp[c]", 
"S_ppi[c]",     "S_ppa[c]",     "S_ac[m]",  "S_ac[g]",  "S_adn[c]",     "S_ins[c]",     "S_ade[c]",     "S_gtp[c]",     "S_gdp[c]",     "S_gtp[m]", 
"S_gdp[m]",     "S_ametam[c]",  "S_camp[c]",    "S_adn[m]",     "S_adpman[c]",  "S_adprib[c]",  "S_crn[c]",     "S_crn[m]",     "S_adrn[c]",    "S_fum[c]", 
"S_aicar[c]",   "S_aflatoxin[c]",   "S_cmp[c]",     "S_cdpea[c]",   "S_Rtotal2[c]",     "S_urea[m]",    "S_pa_hs[c]",   "S_glx[m]",     "S_gly[m]",     "S_pyr[x]", 
"S_ala_L[x]",   "S_glx[x]",     "S_gly[x]",     "S_ahcys[r]",   "S_mal_L[c]",   "S_mal_L[m]",   "S_akg[x]",     "S_prgstrn[c]",     "S_xol7aone[c]",    "S_xoldiolone[c]", 
"S_ala_L[c]",   "S_asn_L[c]",   "S_cys_L[c]",   "S_ala_D[c]",   "S_gln_L[c]",   "S_gly[c]",     "S_ser_L[c]",   "S_thr_L[c]",   "S_12ppd_R[c]",     "S_etoh[c]", 
"S_ind3ac[c]",  "S_ind3ac[m]",  "S_prist[c]",   "S_aldstrn[c]",     "S_aldstrn[m]",     "S_dhap[c]",    "S_arachd[c]",  "S_12HPET[c]",  "S_15HPET[c]",  "S_leuktrA4[c]", 
"S_h2o[r]",     "S_o2[r]",  "S_amet[r]",    "S_amet[m]",    "S_ahcys[m]",   "S_imp[c]",     "S_amp[x]",     "S_amp[r]",     "S_andrstrn[c]",    "S_andrstrn[r]", 
"S_antipyrene[c]",  "S_lys_L[c]",   "S_aqcobal[c]",     "S_arab_L[c]",  "S_arachd[r]",  "S_arach[c]",   "S_arg_L[m]",   "S_arg_L[c]",   "S_orn[m]",     "S_citr_L[c]", 
"S_so4[l]",     "S_Rtotal[c]",  "S_Rtotal[l]",  "S_crm_hs[l]",  "S_sphings[l]",     "S_ascb_L[c]",  "S_o2s[c]",     "S_dhdascb[c]",     "S_nh4[m]",     "S_asn_L[m]", 
"S_asp_D[c]",   "S_k[c]",   "S_asp_D[x]",   "S_oaa[m]",     "S_atp[r]",     "S_adp[r]",     "S_atp[n]",     "S_atp[x]",     "S_gbside_hs[g]",   "S_galgalgalthcrm_hs[g]", 
"S_galacglcgalgbside_hs[g]",    "S_h2o[g]",     "S_gluside_hs[g]",  "S_dgchol[x]",  "S_btn[c]",     "S_ala_B[c]",   "S_4tmeabutn[c]",   "S_succ[c]",    "S_caro[c]",    "S_retinal[c]", 
"S_glc_D[c]",   "S_bhb[m]",     "S_bhb[c]",     "S_hcys_L[c]",  "S_met_L[c]",   "S_bildglcur[c]",   "S_bildglcur[r]",   "S_bilglcur[c]",    "S_bilglcur[r]",    "S_biliverd[c]", 
"S_bilirub[c]",     "S_bilirub[r]",     "S_h[r]",   "S_h2o[n]",     "S_but[c]",     "S_bz[c]",  "S_bz[r]",  "S_nadp[r]",    "S_pmtcrn[c]",  "S_hdcecrn[c]", 
"S_hdd2crn[c]",     "S_hdd2crn[m]",     "S_stcrn[c]",   "S_odecrn[c]",  "S_odecrn[m]",  "S_co2[r]",     "S_nadh[r]",    "S_nad[r]",     "S_ca2[c]",     "S_h2o2[m]", 
"S_nh4[r]",     "S_glc_D[r]",   "S_pi[r]",  "S_ppi[r]",     "S_prostge1[c]",    "S_prostge2[c]",    "S_prostgf2[c]",    "S_inost[c]",   "S_pail_hs[c]",     "S_ctp[c]", 
"S_pa_hs[m]",   "S_ctp[m]",     "S_dag_hs[c]",  "S_pchol_hs[c]",    "S_pe_hs[c]",   "S_crm_hs[c]",  "S_crmp_hs[c]",     "S_crm_hs[g]",  "S_crm_hs[r]",  "S_gluside_hs[c]", 
"S_gluside_hs[r]",  "S_cgly[c]",    "S_chsterol[r]",    "S_xol25oh[r]",     "S_chol[c]",    "S_chol[n]",    "S_cholp[c]",   "S_cholate[c]",     "S_cholp[g]",   "S_cholp[l]", 
"S_chsterol[c]",    "S_chsterol[m]",    "S_chtn[c]",    "S_creat[c]",   "S_cl[c]",  "S_for[c]",     "S_i[c]",   "S_oxa[c]",     "S_clpnd[c]",   "S_pglyc_hs[c]", 
"S_cmp[g]",     "S_ppi[n]",     "S_ctp[n]",     "S_co2[x]",     "S_coke[r]",    "S_egme[r]",    "S_q10[m]",     "S_core4[g]",   "S_co[c]",  "S_T4hcinnm[m]", 
"S_coumarin[c]",    "S_crn[x]",     "S_pcrn[x]",    "S_pcrn[c]",    "S_acrn[x]",    "S_crtsl[c]",   "S_crtsl[m]",   "S_crtsl[r]",   "S_crtstrn[c]",     "S_crtstrn[m]", 
"S_crvnc[c]",   "S_cspg_a[l]",  "S_cspg_e[l]",  "S_crn[r]",     "S_csn[c]",     "S_cspg_a[g]",  "S_cspg_c[g]",  "S_cspg_d[g]",  "S_cspg_e[g]",  "S_q10h2[m]", 
"S_Lcystin[c]",     "S_gthrd[c]",   "S_gthox[c]",   "S_cys_L[m]",   "S_cytd[c]",    "S_uri[c]",     "S_cmp[m]",     "S_cytd[m]",    "S_nh4[n]",     "S_h[n]", 
"S_cdp[c]",     "S_dgtp[c]",    "S_cmp[n]",     "S_cdp[n]",     "S_dgtp[n]",    "S_dcmp[c]",    "S_dcmp[n]",    "S_utp[c]",     "S_udp[n]",     "S_utp[n]", 
"S_cdp[m]",     "S_adp[n]",     "S_dad_2[c]",   "S_din[c]",     "S_dag_hs[r]",  "S_nh4[x]",     "S_ala_D[x]",   "S_arg_D[x]",   "S_5g2oxpt[x]",     "S_oaa[x]", 
"S_dcmp[m]",    "S_dcyt[m]",    "S_dcyt[n]",    "S_dcsptn1[c]",     "S_dcyt[c]",    "S_duri[c]",    "S_dolichol_L[c]",  "S_dgchol[c]",  "S_dgmp[m]",    "S_dgsn[m]", 
"S_dgsn[c]",    "S_lthstrl[r]",     "S_dsmsterol[r]",   "S_dheas[c]",   "S_dheas[r]",   "S_dhea[c]",    "S_dhea[r]",    "S_dhf[c]",     "S_dhf[l]",     "S_dhf[m]", 
"S_orot[c]",    "S_56dura[c]",  "S_56dthm[c]",  "S_dhbpt[c]",   "S_thbpt[c]",   "S_mlthf[c]",   "S_lac_D[c]",   "S_dlnlcg[c]",  "S_dgtp[m]",    "S_dttp[m]", 
"S_dttp[n]",    "S_ethamp[r]",  "S_n5m2masn[g]",    "S_sprm[c]",    "S_dmantipyrine[c]",    "S_ppi[x]",     "S_dmhptcrn[c]",    "S_dmhptcrn[m]",    "S_dtdp[m]",    "S_dtdp[c]", 
"S_dttp[c]",    "S_dopasf[c]",  "S_orn_D[x]",   "S_5a2opntn[x]",    "S_3pg[c]",     "S_dtdp[n]",    "S_ura[c]",     "S_thym[c]",    "S_duri[m]",    "S_eaflatoxin[c]", 
"S_ebastineoh[c]",  "S_ebastineoh[r]",  "S_ebastine[c]",    "S_ebastine[r]",    "S_eicostet[c]",    "S_elaidcrn[c]",    "S_elaidcrn[m]",    "S_elaid[c]",   "S_estradiol[c]",   "S_estradiol[r]", 
"S_estriol[r]",     "S_estriol[c]",     "S_estrones[c]",    "S_estrone[r]",     "S_estrone[c]",     "S_ethamp[c]",  "S_etha[c]",    "S_f1a[g]",     "S_f1a[l]",     "S_gdp[g]", 
"S_ddca[c]",    "S_ttdca[c]",   "S_ttdcea[c]",  "S_hdca[c]",    "S_hdcea[c]",   "S_ocdca[c]",   "S_ocdcea[c]",  "S_lnlc[c]",    "S_lneldc[c]",  "S_ptdca[c]", 
"S_hpdca[c]",   "S_vacc[c]",    "S_lnlncg[c]",  "S_lnlnca[c]",  "S_strdnc[c]",  "S_tmndnc[c]",  "S_phyt[c]",    "S_lgnc[c]",    "S_nrvnc[c]",   "S_tettet6[c]", 
"S_tetpent6[c]",    "S_tetpent3[c]",    "S_tethex3[c]",     "S_hexc[c]",    "S_octa[c]",    "S_whhdca[c]",  "S_fald[c]",    "S_fald[l]",    "S_glyald[c]",  "S_fe2[m]", 
"S_pheme[m]",   "S_fe2[c]",     "S_Lkynr[c]",   "S_fol[c]",     "S_for[r]",     "S_5dhf[m]",    "S_thf[m]",     "S_fru[c]",     "S_thf[c]",     "S_fuc13galacglcgal14acglcgalgluside_hs[c]", 
"S_fuc13galacglcgal14acglcgalgluside_hs[g]",    "S_fuc14galacglcgalgluside_hs[c]",  "S_fuc14galacglcgalgluside_hs[g]",  "S_fucacgalfucgalacglcgalgluside_hs[c]",    "S_fucfuc12gal14acglcgalgluside_hs[c]",     "S_fucfuc12gal14acglcgalgluside_hs[g]",     "S_fucfucfucgalacglc13galacglcgal14acglcgalgluside_hs[c]",  "S_fucfucfucgalacglc13galacglcgal14acglcgalgluside_hs[g]",  "S_fucfucgalacglcgalgluside_hs[c]",     "S_fucfucgalacglcgalgluside_hs[g]", 
"S_fucgal14acglcgalgluside_hs[c]",  "S_fucgal14acglcgalgluside_hs[g]",  "S_fucgalfucgalacglcgalgluside_hs[c]",  "S_fum[m]",     "S_so4[c]",     "S_glyc3p[c]",  "S_gudac[c]",   "S_galacglcgalgbside_hs[c]",    "S_gal[l]",     "S_galgalfucfucgalacglcgalacglcgal14acglcgalgluside_hs[c]", 
"S_galgalgalthcrm_hs[c]",   "S_gd3_hs[g]",  "S_gal[c]",     "S_galt[c]",    "S_gam[c]",     "S_oagd3_hs[c]",    "S_gd3_hs[c]",  "S_oagd3_hs[g]",    "S_n2m2nmasn[l]",   "S_glc_D[l]", 
"S_gluside_hs[l]",  "S_gbside_hs[c]",   "S_gbside_hs[l]",   "S_glyclt[m]",  "S_mlthf[m]",   "S_gchola[c]",  "S_gmp[g]",     "S_gmp[c]",     "S_glu_L[l]",   "S_thf[l]", 
"S_Tyr_ggn[c]",     "S_leuktrE4[c]",    "S_leuktrF4[c]",    "S_ser_L[m]",   "S_glcr[c]",    "S_glygn2[c]",  "S_glcur[l]",   "S_ha[l]",  "S_ha_pre1[l]",     "S_udpglcur[g]", 
"S_ump[c]",     "S_glcur[c]",   "S_glcur[r]",   "S_dxtrn[c]",   "S_gln_L[m]",   "S_forglu[c]",  "S_glx[c]",     "S_glyc3p[m]",  "S_2pg[c]",     "S_glyc_R[c]", 
"S_glyclt[c]",  "S_glyclt[x]",  "S_glyc_S[c]",  "S_glyc[c]",    "S_glyc[m]",    "S_gthrd[m]",   "S_gmp[n]",     "S_hdca[r]",    "S_gq1b_hs[c]",     "S_gsn[c]", 
"S_gthox[m]",   "S_gthrd[r]",   "S_gua[c]",     "S_xan[c]",     "S_pe_hs[r]",   "S_h2o2[l]",    "S_udpglcur[c]",    "S_hcoumarin[c]",   "S_hestratriol[c]",     "S_his_L[c]", 
"S_hista[c]",   "S_hom_L[c]",   "S_pheme[c]",   "S_cortsn[r]",  "S_tststerone[r]",  "S_nadp[x]",    "S_andrstandn[r]",  "S_prgstrn[r]",     "S_xol7aone[r]",    "S_hspg[l]", 
"S_hspg[g]",    "S_htaxol[c]",  "S_hxan[c]",    "S_pydam[c]",   "S_taur[c]",    "S_icit[c]",    "S_icit[x]",    "S_3ityr_L[c]",     "S_35diotyr[c]",    "S_triodthy[c]", 
"S_thyox_L[c]",     "S_tyr_L[c]",   "S_idour[l]",   "S_idour[c]",   "S_ile_L[c]",   "S_itacon[m]",  "S_xylu_D[c]",  "S_tagat_D[c]",     "S_ksii_core2[g]",  "S_ksii_core4[g]", 
"S_k[g]",   "S_kynate[c]",  "S_lac_L[m]",   "S_leuktrB4[c]",    "S_leuktrB4[r]",    "S_leuktrC4[c]",    "S_leuktrD4[c]",    "S_leu_L[c]",   "S_xyl_D[l]",   "S_lac_L[c]", 
"S_lneldccrn[c]",   "S_lneldccrn[m]",   "S_lnlccrn[c]",     "S_lnlccrn[m]",     "S_lanost[c]",  "S_lanost[r]",  "S_lpchol_hs[c]",   "S_g3pc[c]",    "S_mag_hs[c]",  "S_retfa[c]", 
"S_retinol[c]",     "S_trp_L[c]",   "S_trypta[c]",  "S_malt[c]",    "S_normete_L[c]",   "S_meoh[c]",    "S_meoh[l]",    "S_mepi[c]",    "S_mi1p_D[c]",  "S_malttr[c]", 
"S_5mta[c]",    "S_nac[c]",     "S_ncam[c]",    "S_nad[n]",     "S_udp[l]",     "S_na1[g]",     "S_carn[c]",    "S_udp[r]",     "S_ump[r]",     "S_pi[g]", 
"S_ump[g]",     "S_nicrnt[c]",  "S_nicrnt[n]",  "S_nwharg[c]",  "S_no[c]",  "S_uri[l]",     "S_ump[l]",     "S_dtmp[m]",    "S_thymd[m]",   "S_xmp[c]", 
"S_o2s[m]",     "S_o2[n]",  "S_succ[m]",    "S_13_cis_retn[c]",     "S_orot5p[c]",  "S_thcholstoic[m]",     "S_xol27oh[m]",     "S_taxol[c]",   "S_wharachd[r]",    "S_leuktrB4woh[r]", 
"S_xoltri25[r]",    "S_xoltri27[r]",    "S_xol27oh[r]",     "S_leuktrB4wcooh[r]",   "S_pro_L[m]",   "S_pa_hs[r]",   "S_ak2lgchol_hs[c]",    "S_paf_hs[c]",  "S_pail_hs[n]",     "S_ptth[c]", 
"S_pchol_hs[r]",    "S_pcollg5hlys[c]",     "S_amp[g]",     "S_camp[g]",    "S_35cgmp[g]",  "S_pydxn[c]",   "S_prostgd2[c]",    "S_prostgh2[c]",    "S_prostgh2[r]",    "S_prostge2[r]", 
"S_phe_L[c]",   "S_phe_L[m]",   "S_succ[x]",    "S_pi[n]",  "S_pail_hs[r]",     "S_pnto_R[c]",  "S_prist[x]",   "S_pro_D[c]",   "S_prostgi2[c]",    "S_pro_L[c]", 
"S_ps_hs[c]",   "S_hdca[x]",    "S_phyt[x]",    "S_ptrc[c]",    "S_4abutn[c]",  "S_pydx[c]",    "S_rbl_D[c]",   "S_13_cis_retnglc[c]",  "S_13_cis_retnglc[r]",  "S_13_cis_retn[r]", 
"S_rib_D[c]",   "S_saccrp_L[m]",    "S_sbt_D[c]",   "S_selmeth[c]",     "S_ser_L[x]",   "S_sph1p[c]",   "S_sphmyln_hs[g]",  "S_sphmyln_hs[l]",  "S_sphings[c]",     "S_spc_hs[c]", 
"S_sphmyln_hs[c]",  "S_xolest_hs[c]",   "S_sphs1p[c]",  "S_spmd[c]",    "S_sql[r]",     "S_so4[r]",     "S_estrones[r]",    "S_T4hcinnm[c]",    "S_tchola[c]",  "S_tdchola[c]", 
"S_thcholstoic[x]",     "S_thymd[c]",   "S_thm[c]",     "S_thmtp[c]",   "S_tmlys[c]",   "S_q10[c]",     "S_q10h2[c]",   "S_tststerone[c]",  "S_ttdcrn[m]",  "S_ttdcrn[c]", 
"S_txa2[c]",    "S_txa2[r]",    "S_udpglcur[r]",    "S_ump[n]",     "S_urate[c]",   "S_urea[c]",    "S_val_L[c]",   "S_vitd3[c]",   "S_dhcholestanate[r]",  "S_thcholstoic[r]", 
"S_whtststerone[c]",    "S_xolest2_hs[c]",  "S_xoltri25[c]",    "S_xoltri27[c]",    "S_xylt[c]",    "S_xyl_D[c]",   "S_acmana[r]",  "S_lac_L[x]",   "S_fdp[c]",     "S_glyald[m]", 
"S_arachd[x]",  "S_3pg[m]",     "S_glyc_R[m]",  "S_lnlccrn[x]",     "S_dgmp[c]",    "S_mev_R[c]",   "S_fol[m]",     "S_HC00900[m]",     "S_cholate[r]",     "S_ptth[m]", 
"S_4hpro_LT[c]",    "S_4hpro_LT[m]",    "S_thcholstoic[c]",     "S_HC00900[c]",     "S_C02470[c]",  "S_C02528[r]",  "S_C02528[c]",  "S_dhcholestanate[c]",  "S_hxcoa[m]",   "S_xol7ah3[c]", 
"S_inost[r]",   "S_atp[l]",     "S_adp[l]",     "S_cmp[r]",     "S_hdca[l]",    "S_strdnc[l]",  "S_strdnc[r]",  "S_lnlc[l]",    "S_lnlc[r]",    "S_c8crn[c]", 
"S_met_L[m]",   "S_dtmp[c]",    "S_HC02020[r]",     "S_hdcea[r]",   "S_ocdcea[r]",  "S_ocdcea[l]",  "S_lnlnca[r]",  "S_lnlncg[r]",  "S_lnlncg[l]",  "S_lnlnca[l]", 
"S_dlnlcg[l]",  "S_dlnlcg[r]",  "S_xtsn[c]",    "S_HC02192[c]",     "S_HC02193[c]",     "S_HC02195[c]",     "S_HC02196[c]",     "S_HC02220[c]",     "S_dca[c]",     "S_HC02191[c]", 
"S_HC02194[c]",     "S_HC02197[c]",     "S_HC02198[c]",     "S_HC02187[c]",     "S_HC02180[c]",     "S_wharachd[c]",    "S_HC02202[c]",     "S_HC02203[c]",     "S_HC02204[c]",     "S_HC02205[c]", 
"S_HC02206[c]",     "S_HC02207[c]",     "S_HC02208[c]",     "S_HC02210[c]",     "S_HC02213[c]",     "S_HC02214[c]",     "S_HC02216[c]",     "S_HC02217[c]",     "S_c4crn[c]",   "S_docosac[c]", 
"S_CE2705[c]",  "S_maltttr[c]",     "S_CE2839[c]",  "S_CE2838[c]",  "S_atp[g]",     "S_adp[g]",     "S_CE1918[c]",  "S_xol7aone[m]",    "S_xol27oh[c]",     "S_cholate[m]", 
"S_cholate[x]",     "S_tdechola[c]",    "S_retinal[r]",     "S_CE1261[c]",  "S_CE5026[c]",  "S_CE5629[c]",  "S_retinol[r]",     "S_C13856[c]",  "S_C05957[c]",  "S_CE4877[c]", 
"S_dchac[c]",   "S_CE2172[c]",  "S_CE1310[m]",  "S_C05300[c]",  "S_C05300[r]",  "S_CE5025[c]",  "S_dsmsterol[c]",   "S_CE4969[m]",  "S_CE6205[c]",  "S_CE1273[c]", 
"S_HC02191[r]",     "S_crm_hs[n]",  "S_alltn[c]",   "S_CE0074[c]",  "S_hdcea[m]",   "S_leuktrB4[m]",    "S_leuktrB4woh[m]",     "S_leuktrB4wcooh[c]",   "S_leuktrB4wcooh[m]",   "S_leuktrB4woh[c]", 
"S_15HPET[n]",  "S_h2o2[r]",    "S_15HPET[r]",  "S_CE7172[c]",  "S_C06315[c]",  "S_C06314[c]",  "S_C05770[c]",  "S_tmndnc[r]",  "S_lthstrl[c]",     "S_tethex3[r]", 
"S_tetpent6[r]",    "S_CE2510[c]",  "S_doco13ac[c]",    "S_C14826[c]",  "S_CE2049[c]",  "S_C14825[c]",  "S_CE2047[c]",  "S_C14768[c]",  "S_C14770[c]",  "S_C14769[c]", 
"S_C14771[c]",  "S_C04717[c]",  "S_C01601[c]",  "S_CE2006[c]",  "S_C04805[c]",  "S_CE7096[c]",  "S_C04805[m]",  "S_CE7085[c]",  "S_CE7081[r]",  "S_CE7090[c]", 
"S_leuktrB4wcooh[x]",   "S_CE2537[c]",  "S_urcan[c]",   "S_C05767[c]",  "S_3bcrn[c]",   "S_c10crn[c]",  "S_c4crn[x]",   "S_hxcoa[c]",   "S_hxcoa[x]",   "S_dca[r]", 
"S_docosac[r]",     "S_hexdiac[c]",     "S_sebacid[c]",     "S_oh1[c]",     "S_dhap[m]",    "S_mal_L[x]",   "S_15kprostgf2[c]",     "S_21hprgnlone[c]",     "S_3mhis[c]",   "S_hmcr[c]", 
"S_peole_hs[c]",    "S_pepalm_hs[c]",   "S_pailpalm_hs[c]",     "S_pe2linl_hs[c]",  "S_pchol2palm_hs[c]",   "S_pear_hs[c]",     "S_pe203_hs[c]",    "S_pe226_hs[c]",    "S_pe224_hs[c]",    "S_pedh203_hs[c]", 
"S_pe12_hs[c]",     "S_pe14_hs[c]",     "S_pe161_hs[c]",    "S_pe13_hs[c]",     "S_pe15_hs[c]",     "S_pe17_hs[c]",     "S_pailar_hs[c]",   "S_pcholn261_hs[c]",    "S_pcholn281_hs[c]",    "S_pcholn28_hs[c]", 
"S_pelinl_hs[c]",   "S_eidi1114ac[c]",  "S_hxa[c]",     "S_glyc2p[c]",  "S_aclys[c]",   "S_34hpl[c]",   "S_3hmp[c]",    "S_acglu[c]",   "S_acgly[m]",   "S_acgly[c]", 
"S_cortsn[c]",  "S_hxa[m]",     "S_hxa[x]",     "S_pser_L[c]",  "S_saccrp_L[c]",    "S_7klitchol[c]",   "S_Lhcystin[c]",    "S_ppbng[c]",   "S_im4ac[c]",   "S_2h3mv[c]", 
"S_2hiv[c]",    "S_2m3hbu[m]",  "S_2m3hbu[c]",  "S_3h3mglt[c]",     "S_3mglutac[m]",    "S_3mglutac[c]",    "S_glutcon[m]",     "S_glutcon[c]",     "S_caproic[c]",     "S_5ohhexa[c]", 
"S_ethmalac[c]",    "S_peste_hs[c]",    "S_eic21114tr[c]",  "S_5eipenc[m]",     "S_5eipenc[c]",     "S_andrstandn[c]",  "S_CE1447[c]",  "S_CE4969[c]",  "S_CE1310[c]",  "S_4hbz[c]", 
"S_sucsal[c]",  "S_CE7081[c]",  "S_egme[c]",    "S_sql[c]",     "S_orn_D[c]",   "S_5g2oxpt[c]",     "S_HC02020[c]",     "S_xol25oh[c]",     "S_coke[c]",    "S_5a2opntn[c]", 
"S_arg_D[c]",   "S_dopa4glcur[c]",  "S_dopa3glcur[c]",  "S_34dhpe[c]",  "S_Rtotal[g]",  "S_sphings[g]",     "S_sphgn[g]",   "S_gm1_hs[l]",  "S_gd3_hs[l]",  "S_gm1_hs[c]", 
"S_gm1_hs[n]",  "S_sphings[n]",     "S_sphs1p[n]",  "S_sphgn[n]",   "S_sph1p[n]",   "S_15HPET[x]",  "S_M03134[c]",  "S_M02108[c]",  "S_M03117[c]",  "S_M03051[c]", 
"S_M00117[c]",  "S_M02745[c]",  "S_M01197[c]",  "S_M00003[c]",  "S_M01238[c]",  "S_M00019[c]",  "S_M00115[c]",  "S_M02613[c]",  "S_M00017[c]",  "S_M01235[c]", 
"S_M01207[c]",  "S_M02457[c]",  "S_M02053[c]",  "S_M01582[c]",  "S_M03045[c]",  "S_M03153[c]",  "S_M00010[c]",  "S_M00341[c]",  "S_M00260[c]",  "S_M00315[c]", 
"S_M00008[c]",  "S_M00021[c]",  "S_M00265[c]",  "S_sphmyln_hs[r]",  "S_galgluside_hs[r]",   "S_M01881[c]",  "S_arachd[n]",  "S_12HPET[r]",  "S_gthox[r]",   "S_HC02217[r]", 
"S_HC02180[r]",     "S_M01989[c]",  "S_M02155[c]",  "S_hestratriol[l]",     "S_stcrn[r]",   "S_odecrn[r]",  "S_ddca[r]",    "S_M03051[r]",  "S_ttdca[r]",   "S_M02745[r]", 
"S_ttdcea[r]",  "S_M00117[r]",  "S_ptdca[r]",   "S_M01197[r]",  "S_hpdca[r]",   "S_M00003[r]",  "S_M01238[r]",  "S_elaid[r]",   "S_M00019[r]",  "S_vacc[r]", 
"S_lneldc[r]",  "S_M02613[r]",  "S_arach[r]",   "S_CE2510[r]",  "S_M00017[r]",  "S_M01235[r]",  "S_M01207[r]",  "S_M02457[r]",  "S_M02053[r]",  "S_doco13ac[r]", 
"S_M01582[r]",  "S_M03045[r]",  "S_lgnc[r]",    "S_nrvnc[r]",   "S_hexc[r]",    "S_M03153[r]",  "S_eicostet[r]",    "S_clpnd[r]",   "S_tetpent3[r]",    "S_crvnc[r]", 
"S_M00010[r]",  "S_M00341[r]",  "S_adrn[r]",    "S_tettet6[r]",     "S_dcsptn1[r]",     "S_M00008[r]",  "S_M00021[r]",  "S_ac[x]",  "S_amp[n]",     "S_ocdca[r]", 
"S_peplys[c]",  "S_M01870[g]",  "S_M02446[c]",  "S_M02447[c]",  "S_M02449[c]",  "S_M02451[c]",  "S_itacon[c]",  "S_n5m2masn[c]",    "S_12dhchol[c]",    "S_3dhchol[c]", 
"S_3dhcdchol[c]",   "S_3dhdchol[c]",    "S_3dhlchol[c]",    "S_7dhcdchol[c]",   "S_7dhchol[c]",     "S_cdca24g[c]",     "S_cdca24g[r]",     "S_cdca3g[c]",  "S_cdca3g[r]",  "S_hyochol[c]", 
"S_coprost[c]",     "S_hca24g[c]",  "S_hdca24g[c]",     "S_hdca6g[c]",  "S_icdchol[c]",     "S_isochol[c]",     "S_lca24g[c]",  "S_lca3g[c]",   "S_thyochol[c]",    "S_uchol[c]", 
"S_hyochol[r]",     "S_hca24g[r]",  "S_M02155[r]",  "S_hdca24g[r]",     "S_hdca6g[r]",  "S_lca24g[r]",  "S_lca3g[r]",   "S_tacr[r]",    "S_12htacr[r]",     "S_12htacr[c]", 
"S_4ohmdz[r]",  "S_14hmdz[r]",  "S_1ohmdz[r]",  "S_14hmdz[c]",  "S_1hibupglu_S[c]",     "S_1hibup_S[r]",    "S_1hibupglu_S[r]",     "S_1hibup_S[c]",    "S_mdz[r]",     "S_1ohmdz[c]", 
"S_2hatvacid[c]",   "S_2hatvlac[c]",    "S_2hatvacid[r]",   "S_atvacid[r]",     "S_atvlac[r]",  "S_2hibupglu_S[c]",     "S_2hibup_R[c]",    "S_2hibup_S[r]",    "S_2hibupglu_S[r]",     "S_2hibup_S[c]", 
"S_pvs[r]",     "S_smv[r]",     "S_35dsmv[r]",  "S_35dsmv[c]",  "S_3hibupglu_S[c]",     "S_3hibup_R[c]",    "S_3hibup_S[r]",    "S_3hibupglu_S[r]",     "S_3hibup_S[c]",    "S_3hlvstacid[c]", 
"S_3hpvstet[c]",    "S_3hpvs[r]",   "S_3hpvs[c]",   "S_3hsmvacid[c]",   "S_pvs[c]",     "S_3ispvs[c]",  "S_3ohacmp[c]",     "S_acmp[r]",    "S_3ohacmp[r]",     "S_glz[r]", 
"S_4hatvacid[r]",   "S_4hatvlac[c]",    "S_4hatvacid[c]",   "S_4hatvlac[r]",    "S_4ohmdz[c]",  "S_56dhpvs[c]",     "S_56eppvs[c]",     "S_5ohfvs[r]",  "S_5ohfvsglu[r]",   "S_5ohfvsglu[c]", 
"S_fvs[r]",     "S_5ohfvs[c]",  "S_6bhglz[c]",  "S_6bhglz[r]",  "S_6csmvacid[c]",   "S_6epvs[c]",   "S_6hlvst[c]",  "S_6hmsmvacid[c]",  "S_6hsmvacid[c]",   "S_6melvst[c]", 
"S_6melvacid[c]",   "S_6ohfvsglu[r]",   "S_6ohfvsglu[c]",   "S_7bhglz[c]",  "S_7bhglz[r]",  "S_7hpvs[c]",   "S_acmp[c]",    "S_am1csa[r]",  "S_am19cs[r]",  "S_am9csa[r]", 
"S_am19cs[c]",  "S_am1csa[c]",  "S_csa[r]",     "S_am9csa[c]",  "S_csa[c]",     "S_atvacid[c]",     "S_atvlac[c]",  "S_caribupglu_S[c]",    "S_caribup_s[r]",   "S_caribupglu_S[r]", 
"S_caribup_s[c]",   "S_mhglz[r]",   "S_crvsm24[r]",     "S_crvs[c]",    "S_crvs[r]",    "S_crvsm24[c]",     "S_fvs[x]",     "S_deoxfvs[x]",     "S_deoxfvs[c]",     "S_glz[c]", 
"S_dspvs[c]",   "S_epoxtac[r]",     "S_epoxtac[c]",     "S_tlacfvs[r]",     "S_fvs[c]",     "S_glc3meacp[r]",   "S_glc3meacp[c]",   "S_ibupgluc[c]",    "S_ibup_S[r]",  "S_ibupgluc[r]", 
"S_ibup_R[c]",  "S_ibup_R[r]",  "S_2hibup_R[r]",    "S_3hibup_R[r]",    "S_ibup_S[c]",  "S_isolvstacid[c]",     "S_lstn[r]",    "S_lstn[c]",    "S_lstnm7[c]",  "S_lstnm7[r]", 
"S_lvst[c]",    "S_6melvacid[r]",   "S_lvst[r]",    "S_6hlvst[r]",  "S_6melvst[r]",     "S_mdz[c]",     "S_mhglz[c]",   "S_nfdac[r]",   "S_nfdoh[r]",   "S_nfdac[c]", 
"S_nfdoh[c]",   "S_profvs[c]",  "S_ptvst[c]",   "S_ptvst[r]",   "S_ptvstlac[r]",    "S_ptvstlac[c]",    "S_ptvstm13[r]",    "S_pvsgluc[c]",     "S_smvacid[c]",     "S_smv[c]", 
"S_tacr[c]",    "S_tlacfvs[c]",     "S_tripvs[c]",  "S_ptvstm13[c]",    "S_1a25dhvitd2[c]",     "S_h[i]",   "S_itp[m]",     "S_idp[m]",     "S_peptide[c]",     "S_abeta_L_lysine[c]", 
"S_abeta_L_lysine[n]",  "S_tau_L_lysine[c]",    "S_tau_L_lysine[n]",    "S_TNFA_L_lysine[c]",   "S_TNFA_L_lysine[n]",   "S_IL6_L_lysine[c]",    "S_IL6_L_lysine[n]",    "S_homoval[c]",     "S_3hpp[c]",    "S_3mlda[c]", 
"S_3mob[m]",    "S_4mop[c]",    "S_4mop[m]",    "S_5adtststerones[c]",  "S_acetone[c]",     "S_acnacngalgbside_hs[c]",  "S_acnacngalgbside_hs[g]",  "S_aprgstrn[c]",    "S_ala_B[m]",   "S_cbasp[c]", 
"S_gm1_hs[g]",  "S_3uib[c]",    "S_3aib_D[c]",  "S_pmtcrn[m]",  "S_stcrn[m]",   "S_chsterols[c]",   "S_chsterol[g]",    "S_3aib_D[m]",  "S_ditp[c]",    "S_s2l2n2m2m[c]", 
"S_s2l2n2m2m[l]",   "S_fuc_L[c]",   "S_for[m]",     "S_fuc_L[l]",   "S_s2l2fn2m2masn[l]",   "S_s2l2n2m2masn[l]",    "S_oxa[x]",     "S_gt1a_hs[c]",     "S_hestratriol[r]",     "S_mhista[c]", 
"S_nrpphrsf[c]",    "S_pac[c]",     "S_pchol_hs[g]",    "S_phpyr[c]",   "S_tre[c]",     "S_triodthysuf[c]",     "S_tststerones[c]",     "S_3hpp[m]",    "S_pac[m]",     "S_34dhoxmand[m]", 
"S_homoval[m]",     "S_3mox4hoxm[m]",   "S_2obut[m]",   "S_C11695[c]",  "S_avite1[c]",  "S_leuktrB4[x]",    "S_CE5304[c]",  "S_CE6247[c]",  "S_adpac[c]",   "S_adpac[x]", 
"S_c101crn[c]",     "S_decdicrn[c]",    "S_3deccrn[c]",     "S_ddeccrn[c]",     "S_ddece1crn[c]",   "S_dodecanac[c]",   "S_c12dc[c]",   "S_3ddcrn[c]",  "S_tetdece1crn[c]",     "S_tetdec2crn[c]", 
"S_3tdcrn[c]",  "S_c16dc[c]",   "S_3octdece1crn[c]",    "S_c3dc[c]",    "S_c4dc[c]",    "S_c6crn[c]",   "S_c81crn[c]",  "S_hexdiac[r]",     "S_subeac[x]",  "S_sebacid[x]", 
"S_subeac[c]",  "S_fe3[c]",     "S_slfcys[c]",  "S_adpoh[c]",   "S_phlac[c]",   "S_sphmyln18114_hs[c]",     "S_sphmyln18121_hs[c]",     "S_sphmyln181221_hs[c]",    "S_sphmyln18122_hs[c]",     "S_sphmyln18123_hs[c]", 
"S_sphmyln180241_hs[c]",    "S_sphmyln1824_hs[c]",  "S_sphmyln1825_hs[c]",  "S_sphmyln18115_hs[c]",     "S_sphmyln181161_hs[c]",    "S_sphmyln18116_hs[c]",     "S_sphmyln18117_hs[c]",     "S_sphmyln18118_hs[c]",     "S_sphmyln181181_hs[c]",    "S_sphmyln181201_hs[c]", 
"S_sphmyln18120_hs[c]",     "S_pcholmyr_hs[c]",     "S_pcholole_hs[c]",     "S_pcholpalme_hs[c]",   "S_pcholpalm_hs[c]",    "S_pcholste_hs[c]",     "S_pchol2linl_hs[c]",   "S_pchol2ole_hs[c]",    "S_pchol2ste_hs[c]",    "S_pcholn15_hs[c]", 
"S_pcholar_hs[c]",  "S_pcholn183_hs[c]",    "S_pcholn1836_hs[c]",   "S_pcholn19_hs[c]",     "S_pcholn201_hs[c]",    "S_pcholn204_hs[c]",    "S_pcholn205_hs[c]",    "S_pcholn224_hs[c]",    "S_pcholn225_hs[c]",    "S_pcholn2254_hs[c]", 
"S_pcholn226_hs[c]",    "S_pcholn203_hs[c]",    "S_pcholn24_hs[c]",     "S_pcholdoc_hs[c]",     "S_pcholeic_hs[c]",     "S_pcholet_hs[c]",  "S_pcholhep_hs[c]",     "S_pchollinl_hs[c]",    "S_pheacgly[m]",    "S_pheacgly[c]", 
"S_ppiogly[m]",     "S_ppiogly[c]",     "S_tiggly[m]",  "S_tiggly[c]",  "S_3hivac[m]",  "S_3hivac[c]",  "S_3hadpac[x]",     "S_3hadpac[c]",     "S_3ohsebac[x]",    "S_3ohsebac[c]", 
"S_3ohsubac[x]",    "S_3ohsubac[c]",    "S_hexgly[c]",  "S_subgly[c]",  "S_4ohbut[m]",  "S_4ohbut[c]",  "S_dag_hs[g]",  "S_gd3_hs[m]",  "S_M03131[c]",  "S_1hmdgluc[r]", 
"S_1hmdgluc[c]",    "S_2hatvlac[r]",    "S_2hatvlacgluc[r]",    "S_2hatvlacgluc[c]",    "S_4hmdgluc[c]",    "S_4hmdgluc[r]",    "S_oxyp[c]",            
"S_paps[c]",    "S_4hbzcoa[m]",     "S_ppcoa[m]",   "S_pmtcoa[x]",  "S_adrncoa[x]",     "S_5HPET[c]",   "S_arachdcoa[x]",   "S_lnlncgcoa[c]",   "S_tethex3coa[c]",  "S_galacglcgal14acglcgalgluside_hs[g]", 
"S_dcholcoa[x]",    "S_hdd2coa[m]",     "S_4mzym_int2[r]",  "S_coa[l]",     "S_dgdp[c]",    "S_dcsptn1crn[c]",  "S_datp[m]",    "S_fad[c]",     "S_dcdp[m]",    "S_3hbcoa[x]", 
"S_hpdcacoa[c]",    "S_stcoa[x]",   "S_odecoa[x]",  "S_gacpail_hs[r]",  "S_glac[r]",    "S_guln[c]",    "S_hpyr[c]",    "S_17ahprgstrn[r]",     "S_minohp[n]",  "S_1p3h5c[m]", 
"S_ppmi12346p[n]",  "S_Ser_Gly_Ala_X_Gly[r]",   "S_pan4p[m]",   "S_dcholcoa[c]",    "S_CE0713[x]",  "S_CE2434[m]",  "S_dec24dicoa[x]",  "S_CE2422[m]",  "S_CE5253[c]",  "S_udpgal[r]", 
"S_CE4793[x]",  "S_strdnccoa[r]",   "S_zymstnl[c]",     "S_dec47dicoa[m]",  "S_tetdecdicoa[m]",     "S_2hexdtricoa[m]",     "S_3octdectecoa[x]",    "S_3docopencoa[x]",     "S_1a25dhvitd3[n]",     "S_methf[c]", 
"S_M00129[c]",  "S_M02612[c]",  "S_M00343[c]",  "S_44mzym[c]",  "S_zymst[c]",   "S_M03050[m]",  "S_M00004[m]",  "S_M02638[m]",  "S_CE5151[m]",  "S_M02051[c]", 
"S_M00006[m]",  "S_M00261[m]",  "S_CE4847[m]",  "S_M00004[r]",  "S_M00123[r]",  "S_M00012[r]",  "S_tetpent3coa[r]",     "S_CE2242[x]",  "S_3ohodcoa[m]",    "S_CE5152[m]", 
"S_M03014[m]",  "S_CE5157[x]",  "S_HC10856[x]",     "S_M00885[x]",  "S_3hpvscoa[x]",    "S_6hmsmv[c]",  "S_3hlvst[r]",  "S_3hpvscoa[c]",    "S_clpndcoa[x]",    "S_tethex3coa[x]", 
"S_gm1b_hs[g]",     "S_3hdcoa[m]",  "S_CE5148[c]",  "S_CE5944[x]",  "S_hexdicoa[r]",    "S_M00790[c]",  "S_M03016[c]",  "S_nadph[m]",   "S_1a25dhvitd3[m]",     "S_25hvitd2[m]", 
"S_25hvitd3[m]",    "S_25hvitd2[c]",    "S_25hvitd3[c]",    "S_nadph[c]",   "S_pap[c]",     "S_coa[m]",     "S_34dhmald[c]",    "S_2mop[m]",    "S_b2coa[m]",   "S_3hbcoa_R[m]", 
"S_coa[c]",     "S_3sala[m]",   "S_3sala[c]",   "S_coucoa[m]",  "S_accoa[m]",   "S_udpgal[c]",  "S_thcrm_hs[c]",    "S_udpgal[g]",  "S_thcrm_hs[g]",    "S_uacgam[g]", 
"S_L2aadp6sa[m]",   "S_udpacgal[g]",    "S_aacoa[m]",   "S_coa[x]",     "S_accoa[x]",   "S_aacoa[x]",   "S_occoa[x]",   "S_dcacoa[x]",  "S_ddcacoa[x]",     "S_tdcoa[x]", 
"S_3ohodcoa[x]",    "S_3ohxccoa[x]",    "S_ttccoa[x]",  "S_accoa[c]",   "S_accoa[g]",   "S_accoa[n]",   "S_acgagbside_hs[c]",   "S_acgagbside_hs[g]",   "S_acgagbside_hs[l]",   "S_acgbgbside_hs[c]", 
"S_acgbgbside_hs[g]",   "S_acgbgbside_hs[l]",   "S_fad[m]",     "S_fadh2[m]",   "S_btcoa[m]",   "S_fad[x]",     "S_fadh2[x]",   "S_cholcoads[x]",   "S_ppcoa[c]",   "S_datp[c]", 
"S_dadp[c]",    "S_adrncoa[c]",     "S_adrncrn[c]",     "S_adrncoa[m]",     "S_adrncrn[m]",     "S_cdpchol[c]",     "S_succoa[m]",  "S_lald_L[c]",  "S_id3acald[c]",    "S_id3acald[m]", 
"S_pristanal[c]",   "S_dhcholestancoa[x]",  "S_dhcholestancoa[r]",  "S_cholcoar[x]",    "S_cholcoar[r]",    "S_arachcoa[c]",    "S_arachcoa[x]",    "S_arachcoa[m]",    "S_arachdcoa[c]",   "S_galside_hs[l]", 
"S_pmtcoa[c]",  "S_hdcoa[c]",   "S_tdcoa[c]",   "S_lnlncacoa[c]",   "S_strdnccoa[c]",   "S_dlnlcgcoa[c]",   "S_tmndnccoa[c]",   "S_lnlccoa[c]",     "S_clpndcoa[c]",    "S_dcsptn1coa[c]", 
"S_c226coa[c]",     "S_stcoa[c]",   "S_odecoa[c]",  "S_lneldccoa[c]",   "S_nrvnccoa[c]",    "S_od2coa[c]",  "S_ttccoa[c]",  "S_hexccoa[c]",     "S_eicostetcoa[c]",     "S_tetpent6coa[c]", 
"S_tetpent3coa[c]",     "S_tettet6coa[c]",  "S_hdd2coa[c]",     "S_pmtcoa[m]",  "S_cbp[c]",     "S_galgbside_hs[g]",    "S_acglcgalgluside_hs[g]",  "S_galacglcgalgluside_hs[g]",   "S_acglcgal14acglcgalgluside_hs[g]",    "S_acglcgalacglcgal14acglcgalgluside_hs[g]", 
"S_cholcoa[x]",     "S_dolmanp_U[r]",   "S_dolp_U[r]",  "S_nadph[r]",   "S_44mctr[r]",  "S_44mzym[r]",  "S_hdcoa[m]",   "S_stcoa[m]",   "S_odecoa[m]",  "S_arachdcrn[c]", 
"S_arachdcoa[m]",   "S_arachdcrn[m]",   "S_c226crn[c]",     "S_c226coa[m]",     "S_c226crn[m]",     "S_4mzym_int1[r]",  "S_zymst[r]",   "S_cbl2[c]",    "S_cbl2[m]",    "S_cbp[r]", 
"S_g6p[r]",     "S_cdpdag_hs[c]",   "S_cdpdag_hs[m]",   "S_coa[n]",     "S_clpndcrn[c]",    "S_clpndcoa[m]",    "S_clpndcrn[m]",    "S_cmpacna[c]",     "S_cmpacna[g]",     "S_cmpacna[n]", 
"S_coa[g]",     "S_coa[r]",     "S_Tn_antigen[g]",  "S_core6[g]",   "S_dmnoncrn[x]",    "S_dmnoncrn[m]",    "S_Ser_Gly_Ala_X_Gly[l]",   "S_dmnoncoa[x]",    "S_ppcoa[x]",   "S_dcdp[c]", 
"S_dcdp[n]",    "S_dctp[c]",    "S_dctp[n]",    "S_datp[n]",    "S_dadp[n]",    "S_dd2coa[m]",  "S_dd3coa[m]",  "S_dcsptn1coa[x]",  "S_dcsptn1coa[m]",  "S_dcsptn1crn[m]", 
"S_decdp[c]",   "S_decdp[m]",   "S_dadp[m]",    "S_dgdp[m]",    "S_fad[r]",     "S_fadh2[r]",   "S_zymstnl[r]",     "S_chlstol[r]",     "S_ddsmsterol[r]",  "S_dhcrm_hs[c]", 
"S_fadh2[c]",   "S_dlnlcgcrn[c]",   "S_dlnlcgcoa[m]",   "S_dlnlcgcrn[m]",   "S_dctp[m]",    "S_Ser_Thr[l]",     "S_dmnoncrn[c]",    "S_dmnoncoa[c]",    "S_dmnoncoa[m]",    "S_dnad[c]", 
"S_dnad[n]",    "S_dudp[c]",    "S_dudp[m]",    "S_dutp[c]",    "S_dutp[m]",    "S_dolp_U[c]",  "S_dolmanp_U[c]",   "S_dpcoa[l]",   "S_dpcoa[c]",   "S_ipdp[c]", 
"S_frdp[c]",    "S_dump[c]",    "S_dump[m]",    "S_3hbcoa[m]",  "S_b2coa[x]",   "S_eicostetcrn[c]",     "S_eicostetcoa[m]",     "S_eicostetcrn[m]",     "S_od2coa[m]",  "S_gdpfuc[c]", 
"S_gdpfuc[g]",  "S_ptdcacoa[c]",    "S_pristcoa[c]",    "S_phytcoa[c]",     "S_occoa[c]",   "S_tdcoa[m]",   "S_ptdcacoa[m]",    "S_occoa[m]",   "S_hpdcacoa[m]",    "S_lnlccoa[m]", 
"S_lneldccoa[m]",   "S_lnlncacoa[m]",   "S_lnlncgcoa[m]",   "S_lnlncgcoa[x]",   "S_strdnccoa[m]",   "S_strdnccoa[x]",   "S_tmndnccoa[m]",   "S_tmndnccoa[x]",   "S_nrvnccoa[x]",    "S_tetpent6coa[x]", 
"S_hexccoa[x]",     "S_dcacoa[c]",  "S_ddcacoa[c]",     "S_gcald[c]",   "S_ppp9[m]",    "S_formcoa[c]",     "S_formcoa[x]",     "S_frdp[r]",    "S_glu5sa[m]",  "S_1pyr5c[m]", 
"S_g6p[c]",     "S_gacpail_hs[c]",  "S_paps[g]",    "S_pap[g]",     "S_core6[l]",   "S_Ser_Thr[g]",     "S_galside_hs[c]",  "S_xser[g]",    "S_gcald[m]",   "S_glac[c]", 
"S_uacgam[c]",  "S_guln[r]",    "S_aacoa[c]",   "S_hmgcoa[c]",  "S_hmgcoa[m]",  "S_hmgcoa[x]",  "S_pristanal[x]",   "S_hpdcacrn[c]",    "S_hpdcacrn[m]",    "S_hpyr[m]", 
"S_hpyr[x]",    "S_andrstndn[r]",   "S_nadph[x]",   "S_cholcoaone[x]",  "S_prgnlone[c]",    "S_prgnlone[r]",    "S_17ahprgnlone[c]",    "S_17ahprgstrn[c]",     "S_17ahprgnlone[r]",    "S_lald_L[m]", 
"S_lnlncacrn[c]",   "S_lnlncacrn[m]",   "S_lnlncgcrn[c]",   "S_lnlncgcrn[m]",   "S_44mctr[c]",  "S_Ssq23epx[r]",    "S_minohp[c]",  "S_udpacgal[l]",    "S_Tn_antigen[l]",  "S_nmn[m]", 
"S_nmn[n]",     "S_nmn[c]",     "S_prgnlone[m]",    "S_20ahchsterol[m]",    "S_pail45p_hs[c]",  "S_pail45p_hs[n]",  "S_pail4p_hs[c]",   "S_pail4p_hs[n]",   "S_pan4p[c]",   "S_pristcoa[x]", 
"S_phytcoa[x]",     "S_pail35p_hs[c]",  "S_pail5p_hs[c]",   "S_pail5p_hs[n]",   "S_ppmi12346p[c]",  "S_pppg9[c]",   "S_pppg9[m]",   "S_ptdcacrn[c]",    "S_ptdcacrn[m]",    "S_retinal_cis_13[c]", 
"S_strdnccrn[c]",   "S_strdnccrn[m]",   "S_tmndnccrn[c]",   "S_tmndnccrn[m]",   "S_udpacgal[c]",    "S_xser[r]",    "S_dpcoa[m]",   "S_HC01434[m]",     "S_HC01434[x]",     "S_uacgam[r]", 
"S_HC01668[m]",     "S_pmtcoa[r]",  "S_lnlccoa[r]",     "S_lnlccoa[x]",     "S_arachdcoa[r]",   "S_cholcoa[r]",     "S_L2aadp6sa[c]",   "S_1p3h5c[c]",  "S_cholcoa[c]",     "S_HC01415[m]", 
"S_ddcacoa[m]",     "S_2mop[c]",    "S_dcholcoa[r]",    "S_HC01412[m]",     "S_dd2coa[x]",  "S_dcacoa[m]",  "S_dc2coa[m]",  "S_dc2coa[x]",  "S_hx2coa[m]",  "S_HC02110[r]", 
"S_cdpchol[r]",     "S_hdd2coa[r]",     "S_stcoa[r]",   "S_odecoa[r]",  "S_lnlncgcoa[r]",   "S_btcoa[c]",   "S_dlnlcgcoa[r]",   "S_HC10856[m]",     "S_HC10857[m]",     "S_HC10858[m]", 
"S_CE2421[m]",  "S_CE0713[m]",  "S_CE2421[x]",  "S_CE2253[c]",  "S_CE2249[c]",  "S_CE2245[c]",  "S_docoscoa[c]",    "S_docoscoa[m]",    "S_docoscoa[x]",    "S_andrstndn[c]", 
"S_CE2434[x]",  "S_CE0849[m]",  "S_CE2433[m]",  "S_CE0849[x]",  "S_CE2433[x]",  "S_CE0785[m]",  "S_CE2432[m]",  "S_CE0785[x]",  "S_CE2432[x]",  "S_dece4coa[x]", 
"S_C05279[m]",  "S_CE2420[m]",  "S_C05279[x]",  "S_CE2420[x]",  "S_CE2417[m]",  "S_CE2417[x]",  "S_CE2418[m]",  "S_CE2418[x]",  "S_CE2422[x]",  "S_CE2424[m]", 
"S_CE2424[x]",  "S_CE0693[m]",  "S_CE0693[x]",  "S_C05280[m]",  "S_C05280[x]",  "S_dece4coa[m]",    "S_cholcoa[m]",     "S_dhcholestancoa[c]",  "S_retinal_cis_13[r]",  "S_C02712[m]", 
"S_ddsmsterol[c]",  "S_cholcoar[m]",    "S_C02712[c]",  "S_udpgal[n]",  "S_galside_hs[n]",  "S_C01747[l]",  "S_C01747[c]",  "S_pail35p_hs[n]",  "S_CE4795[m]",  "S_CE4795[x]", 
"S_CE5114[x]",  "S_CE4791[x]",  "S_CE2439[x]",  "S_CE2440[x]",  "S_CE2437[x]",  "S_CE2438[x]",  "S_CE2442[m]",  "S_CE2442[x]",  "S_CE2441[x]",  "S_CE5116[x]", 
"S_CE2053[m]",  "S_CE2053[r]",  "S_eicostetcoa[r]",     "S_lnlncacoa[r]",   "S_clpndcoa[r]",    "S_tmndnccoa[r]",   "S_tethex3coa[r]",  "S_adrncoa[r]",     "S_tetpent6coa[r]",     "S_CE4843[c]", 
"S_CE4843[r]",  "S_CE4847[c]",  "S_CE4854[c]",  "S_CE4855[c]",  "S_CE5151[c]",  "S_CE5151[r]",  "S_CE5155[c]",  "S_CE5155[r]",  "S_nrvnccoa[r]",    "S_cholcoads[m]", 
"S_dmpp[c]",    "S_CE5947[c]",  "S_CE0347[c]",  "S_CE0347[r]",  "S_CE5947[m]",  "S_CE5947[x]",  "S_dec24dicoa[m]",  "S_dece3coa[m]",    "S_3hbcoa_R[c]",    "S_btcoa[x]", 
"S_dece3coa[x]",    "S_dectricoa[m]",   "S_dec47dicoa[x]",  "S_dectricoa[x]",   "S_2decdicoa[m]",   "S_octe5coa[m]",    "S_2decdicoa[x]",   "S_octe5coa[x]",    "S_3decdicoa[m]",   "S_3decdicoa[x]", 
"S_dd3coa[x]",  "S_2ddecdicoa[m]",  "S_3ddecdicoa[m]",  "S_2ddecdicoa[x]",  "S_3ddecdicoa[x]",  "S_2dodtricoa[m]",  "S_2dodtricoa[x]",  "S_3dodtricoa[m]",  "S_3dodtricoa[x]",  "S_tetdecdicoa[x]", 
"S_5tedtricoa[m]",  "S_5tedtricoa[x]",  "S_2hexdtricoa[x]",     "S_4hexdtricoa[m]",     "S_hexdectecoa[m]",     "S_4hexdtricoa[x]",     "S_hexdectecoa[x]",     "S_3hexdtricoa[m]",     "S_3hexdtricoa[x]",     "S_2octdectecoa[m]", 
"S_2octdectecoa[x]",    "S_3octdectecoa[m]",    "S_eitetcoa[m]",    "S_eitetcoa[x]",    "S_2docopencoa[m]",     "S_2docopencoa[x]",     "S_docohexcoa[m]",  "S_docohexcoa[x]",  "S_3docopencoa[m]",     "S_hx2coa[x]", 
"S_hexe3coa[m]",    "S_hexe3coa[x]",    "S_omhdecacid[r]",  "S_omhdecacid[c]",  "S_1a25dhvitd3[c]",     "S_glu5sa[c]",  "S_1pyr5c[c]",  "S_ppp9[c]",    "S_grdp[c]",    "S_HC01434[c]", 
"S_HC01668[c]",     "S_dhcrm_hs[g]",    "S_thcrm_hs[l]",    "S_gd1a_hs[c]",     "S_ga1_hs[c]",  "S_ga2_hs[c]",  "S_gd1a_hs[n]",     "S_M02694[c]",  "S_M02694[m]",  "S_M02107[c]", 
"S_M02107[m]",  "S_M02616[c]",  "S_M02616[m]",  "S_M03116[c]",  "S_M03116[m]",  "S_M03050[c]",  "S_HC10784[c]",     "S_M01141[c]",  "S_M01191[c]",  "S_M00004[c]", 
"S_M01237[c]",  "S_M00020[c]",  "S_vacccoa[c]",     "S_M00127[c]",  "S_M00116[c]",  "S_M00018[c]",  "S_M01236[c]",  "S_M00123[c]",  "S_M00101[c]",  "S_M02052[c]", 
"S_M00006[c]",  "S_M03047[c]",  "S_M02112[c]",  "S_M00012[c]",  "S_M00023[c]",  "S_HC02057[c]",     "S_gm1b_hs[c]",     "S_acglcgalgluside_hs[c]",  "S_galacglcgalgluside_hs[c]",   "S_acglcgal14acglcgalgluside_hs[c]", 
"S_galacglcgal14acglcgalgluside_hs[c]",     "S_acglcgalacglcgal14acglcgalgluside_hs[c]",    "S_5HPET[m]",   "S_Ssq23epx[c]",    "S_4mzym_int1[c]",  "S_4mzym_int2[c]",  "S_HC02110[c]",     "S_chlstol[c]",     "S_cholcoar[c]",    "S_cholcoaone[m]", 
"S_20ahchsterol[r]",    "S_M01075[c]",  "S_M01075[r]",  "S_CE5253[l]",  "S_M01729[c]",  "S_M01729[m]",  "S_M02973[c]",  "S_M02973[m]",  "S_M00129[m]",  "S_M02976[c]", 
"S_M02976[m]",  "S_M01141[m]",  "S_M01191[m]",  "S_M02102[c]",  "S_M02102[m]",  "S_M02103[c]",  "S_M02103[m]",  "S_M01237[m]",  "S_M00020[m]",  "S_vacccrn[c]", 
"S_vacccrn[m]",     "S_vacccoa[m]",     "S_M00127[m]",  "S_M02638[c]",  "S_M00116[m]",  "S_M02611[c]",  "S_M02611[m]",  "S_M02612[m]",  "S_M01776[c]",  "S_M01776[m]", 
"S_M00018[m]",  "S_M01777[c]",  "S_M01777[m]",  "S_M01775[c]",  "S_M01775[m]",  "S_M01236[m]",  "S_M00122[c]",  "S_M00122[m]",  "S_M00123[m]",  "S_M00100[c]", 
"S_M00100[m]",  "S_M00101[m]",  "S_M02051[m]",  "S_M02052[m]",  "S_M01724[c]",  "S_M01724[m]",  "S_M01727[c]",  "S_M01727[m]",  "S_CE5155[m]",  "S_M01726[c]", 
"S_M01726[m]",  "S_M02637[c]",  "S_M02637[m]",  "S_M00011[c]",  "S_M00011[m]",  "S_M00012[m]",  "S_M00342[c]",  "S_M00342[m]",  "S_M00343[m]",  "S_M00261[c]", 
"S_CE4854[m]",  "S_M01770[c]",  "S_M01770[m]",  "S_CE4843[m]",  "S_M00022[c]",  "S_M00022[m]",  "S_M00023[m]",  "S_M00263[c]",  "S_M00263[m]",  "S_ddcacoa[r]", 
"S_M03050[r]",  "S_tdcoa[r]",   "S_M00129[r]",  "S_HC10784[r]",     "S_M01141[r]",  "S_ptdcacoa[r]",    "S_M01191[r]",  "S_hpdcacoa[r]",    "S_M01237[r]",  "S_M00020[r]", 
"S_vacccoa[r]",     "S_M00127[r]",  "S_lneldccoa[r]",   "S_M02612[r]",  "S_arachcoa[r]",    "S_M01236[r]",  "S_M00018[r]",  "S_M00101[r]",  "S_M02052[r]",  "S_M01724[r]", 
"S_docoscoa[r]",    "S_M00006[r]",  "S_M02637[r]",  "S_strdnccrn[r]",   "S_tmndnccrn[r]",   "S_c226coa[r]",     "S_M00343[r]",  "S_lnlncgcrn[r]",   "S_dlnlcgcrn[r]",   "S_dcsptn1coa[r]", 
"S_M00023[r]",  "S_M03047[r]",  "S_ttccoa[r]",  "S_hexccoa[r]",     "S_M02112[r]",  "S_tettet6coa[r]",  "S_M03047[x]",  "S_CE4855[x]",  "S_M02112[x]",  "S_M00049[x]", 
"S_M00783[x]",  "S_CE2245[x]",  "S_CE2249[x]",  "S_CE2253[x]",  "S_CE2246[x]",  "S_CE2250[x]",  "S_CE2243[x]",  "S_CE2247[x]",  "S_CE2251[x]",  "S_od2coa[x]", 
"S_CE2248[x]",  "S_HC01415[x]",     "S_CE2242[m]",  "S_CE2246[m]",  "S_CE2250[m]",  "S_CE2243[m]",  "S_CE2247[m]",  "S_CE2251[m]",  "S_CE2248[m]",  "S_M00044[m]", 
"S_M00778[m]",  "S_M00873[m]",  "S_M00054[m]",  "S_M00790[m]",  "S_M00887[m]",  "S_CE5154[m]",  "S_CE5153[m]",  "S_CE5150[m]",  "S_CE5148[m]",  "S_CE5144[m]", 
"S_M03019[m]",  "S_M00172[m]",  "S_M00849[m]",  "S_M03022[m]",  "S_M01573[m]",  "S_M00885[m]",  "S_M00702[m]",  "S_M00843[m]",  "S_M03016[x]",  "S_M00715[x]", 
"S_M00879[x]",  "S_CE5158[x]",  "S_CE5156[x]",  "S_CE5155[x]",  "S_CE5154[x]",  "S_CE5153[x]",  "S_CE5152[x]",  "S_CE5151[x]",  "S_CE5150[x]",  "S_CE5148[x]", 
"S_CE5144[x]",  "S_HC10857[x]",     "S_HC10858[x]",     "S_M01191[x]",  "S_M03019[x]",  "S_M00172[x]",  "S_M00849[x]",  "S_M01141[x]",  "S_M03022[x]",  "S_M01573[x]", 
"S_CE5116[m]",  "S_CE5114[m]",  "S_CE4791[m]",  "S_CE4793[m]",  "S_CE2437[m]",  "S_CE2438[m]",  "S_CE2439[m]",  "S_CE2440[m]",  "S_CE2441[m]",  "S_coucoa[c]", 
"S_4hbzcoa[c]",     "S_HC02057[r]",     "S_3hlvst[c]",  "S_3hpvscoa[m]",    "S_3hpvstetcoa[m]",     "S_3hpvstetcoa[x]",     "S_3hsmv[c]",   "S_6hsmv[r]",   "S_3hsmv[r]",   "S_3meacmp[c]", 
"S_6csmv[c]",   "S_6csmv[r]",   "S_6hlvstacid[c]",  "S_6hmsmv[r]",  "S_6hsmv[c]",   "S_3meacmp[r]",     "S_lvstacid[c]",    "S_lvstacid[r]",    "S_6hlvstacid[r]",  "S_rsv[r]", 
"S_fvscoa[x]",  "S_profvscoa[x]",   "S_profvscoa[c]",   "S_rsv[c]",     "S_rsvlac[r]",  "S_rsvlac[c]",  "S_3hpvstetcoa[c]",     "S_fvscoa[c]",  "S_3m4hpga[c]",     "S_hdd2coa[x]", 
"S_arachcrn[c]",    "S_arachcrn[m]",    "S_ga2_hs[g]",  "S_ga1_hs[g]",  "S_c226coa[x]",     "S_digalside_hs[c]",    "S_digalside_hs[l]",    "S_dmpp[x]",    "S_ipdp[x]",    "S_grdp[x]", 
"S_tettet6coa[x]",  "S_tetpent3coa[x]",     "S_frdp[x]",    "S_methf[m]",   "S_pacald[c]",  "S_gd1a_hs[g]",     "S_pacald[m]",  "S_3hddcoa[m]",     "S_3htdcoa[m]",     "S_3htdcoa[x]", 
"S_HC01412[x]",     "S_34dhmald[m]",    "S_3m4hpga[m]",     "S_CE2250[c]",  "S_CE2246[c]",  "S_CE2242[c]",  "S_3ohodcoa[c]",    "S_CE2248[c]",  "S_CE4990[m]",  "S_CE4990[x]", 
"S_CE4793[c]",  "S_CE5114[c]",  "S_CE5144[c]",  "S_CE5152[c]",  "S_CE5156[c]",  "S_CE5150[c]",  "S_CE5153[c]",  "S_CE5154[c]",  "S_CE5157[c]",  "S_CE5158[c]", 
"S_CE5944[m]",  "S_CE4988[c]",  "S_CE4988[m]",  "S_CE4988[x]",  "S_CE2084[c]",  "S_CE2084[m]",  "S_adpcoa[c]",  "S_adpcoa[x]",  "S_c6dc[x]",    "S_c10dc[x]", 
"S_c10dc[c]",   "S_sebcoa[c]",  "S_3hdcoa[c]",  "S_dd2coa[c]",  "S_3hddcoa[c]",     "S_3htdcoa[c]",     "S_hexdicoa[c]",    "S_3octdece1coa[c]",    "S_c6dc[c]",    "S_sbcoa[c]", 
"S_c8dc[c]",    "S_sebcoa[x]",  "S_sbcoa[x]",   "S_3octdece1coa[m]",    "S_octdececoa[m]",  "S_succoa[c]",  "S_octdececrn[c]",  "S_octdececrn[m]",  "S_octdececoa[c]",  "S_c8dc[x]", 
"S_galgbside_hs[c]",    "S_3ohxccoa[c]",    "S_M00783[c]",  "S_M00049[c]",  "S_M00887[c]",  "S_M00054[c]",  "S_M00873[c]",  "S_M00778[c]",  "S_M00044[c]",  "S_M00879[c]", 
"S_M00715[c]",  "S_M00843[c]",  "S_M00702[c]",  "S_M03014[c]",  "S_CE4791[c]",                  
                                    
*species participate in the extracellular compartment, but also in other intracellular compartments                                 
"S_1mncam[e]",  "S_24nph[e]",   "S_h[e]",   "S_2hb[e]",     "S_hco3[e]",    "S_na1[e]",     "S_2mcit[e]",   "S_34dhoxpeg[e]",   "S_4mptnl[e]",  "S_4nphsf[e]", 
"S_4nph[e]",    "S_5adtststerone[e]",   "S_h2o[e]",     "S_5fthf[e]",   "S_5htrp[e]",   "S_5mthf[e]",   "S_6htststerone[e]",    "S_4abut[e]",   "S_acetone[e]",     "S_ac[e]", 
"S_ach[e]",     "S_chol[e]",    "S_acngalacglcgal14acglcgalgluside_hs[e]",  "S_nh4[e]",     "S_adn[e]",     "S_ins[e]",     "S_ade[e]",     "S_adprib[e]",  "S_adrnl[e]",   "S_adrn[e]", 
"S_aflatoxin[e]",   "S_akg[e]",     "S_ala_L[e]",   "S_asn_L[e]",   "S_cys_L[e]",   "S_ala_D[e]",   "S_gln_L[e]",   "S_gly[e]",     "S_ser_L[e]",   "S_thr_L[e]", 
"S_aldstrn[e]",     "S_cgly[e]",    "S_glc_D[e]",   "S_glygn2[e]",  "S_andrstrn[e]",    "S_antipyrene[e]",  "S_aqcobal[e]",     "S_arab_L[e]",  "S_arachd[e]",  "S_arach[e]", 
"S_lys_L[e]",   "S_arg_L[e]",   "S_ascb_L[e]",  "S_asp_D[e]",   "S_k[e]",   "S_asp_L[e]",   "S_atp[e]",     "S_pi[e]",  "S_amp[e]",     "S_adp[e]", 
"S_ala_B[e]",   "S_bhb[e]",     "S_bildglcur[e]",   "S_bilglcur[e]",    "S_bilirub[e]",     "S_btn[e]",     "S_bz[e]",  "S_ca2[e]",     "S_caro[e]",    "S_cholate[e]", 
"S_acgam[e]",   "S_chtn[e]",    "S_cit[e]",     "S_cl[e]",  "S_for[e]",     "S_i[e]",   "S_oxa[e]",     "S_clpnd[e]",   "S_co[e]",  "S_coumarin[e]", 
"S_creat[e]",   "S_crn[e]",     "S_crtsl[e]",   "S_crtstrn[e]",     "S_crvnc[e]",   "S_csn[e]",     "S_cspg_a[e]",  "S_cspg_c[e]",  "S_cspg_d[e]",  "S_cspg_e[e]", 
"S_glu_L[e]",   "S_Lcystin[e]",     "S_cytd[e]",    "S_dad_2[e]",   "S_din[e]",     "S_dag_hs[e]",  "S_dcsptn1[e]",     "S_dcyt[e]",    "S_dgchol[e]",  "S_dgsn[e]", 
"S_dhdascb[e]",     "S_dheas[e]",   "S_dlnlcg[e]",  "S_dmantipyrine[e]",    "S_dmhptcrn[e]",    "S_dopasf[e]",  "S_dopa[e]",    "S_drib[e]",    "S_duri[e]",    "S_eaflatoxin[e]", 
"S_ebastineoh[e]",  "S_ebastine[e]",    "S_eicostet[e]",    "S_elaid[e]",   "S_estradiol[e]",   "S_estrones[e]",    "S_10fthf[e]",  "S_10fthf5glu[e]",  "S_10fthf6glu[e]",  "S_10fthf7glu[e]", 
"S_13_cis_retnglc[e]",  "S_35cgmp[e]",  "S_3aib[e]",    "S_5dhf[e]",    "S_5thf[e]",    "S_6dhf[e]",    "S_6thf[e]",    "S_7dhf[e]",    "S_7thf[e]",    "S_ak2lgchol_hs[e]", 
"S_camp[e]",    "S_chsterol[e]",    "S_cmp[e]",     "S_dhf[e]",     "S_fuc13galacglcgal14acglcgalgluside_hs[e]",    "S_fuc14galacglcgalgluside_hs[e]",  "S_fucacgalfucgalacglcgalgluside_hs[e]",    "S_fucfuc12gal14acglcgalgluside_hs[e]",     "S_fucfucfucgalacglc13galacglcgal14acglcgalgluside_hs[e]",  "S_fucfucgalacglcgalgluside_hs[e]", 
"S_fucgal14acglcgalgluside_hs[e]",  "S_fucgalfucgalacglcgalgluside_hs[e]",  "S_galacglcgalgbside_hs[e]",    "S_galgalfucfucgalacglcgalacglcgal14acglcgalgluside_hs[e]",     "S_galgalgalthcrm_hs[e]",   "S_gbside_hs[e]",   "S_gchola[e]",  "S_gdp[e]",     "S_glyc_S[e]",  "S_gmp[e]", 
"S_gq1b_hs[e]",     "S_gsn[e]",     "S_gthox[e]",   "S_gthrd[e]",   "S_gtp[e]",     "S_h2o2[e]",    "S_ha[e]",  "S_ha_pre1[e]",     "S_hcoumarin[e]",   "S_hdca[e]", 
"S_hdcea[e]",   "S_hexc[e]",    "S_hista[e]",   "S_hom_L[e]",   "S_hpdca[e]",   "S_hspg[e]",    "S_htaxol[e]",  "S_idp[e]",     "S_imp[e]",     "S_inost[e]", 
"S_ksii_core2[e]",  "S_ksii_core4[e]",  "S_leuktrA4[e]",    "S_leuktrB4[e]",    "S_leuktrC4[e]",    "S_leuktrD4[e]",    "S_leuktrE4[e]",    "S_leuktrF4[e]",    "S_lgnc[e]",    "S_lneldc[e]", 
"S_lnlc[e]",    "S_lnlnca[e]",  "S_lnlncg[e]",  "S_lpchol_hs[e]",   "S_mag_hs[e]",  "S_meoh[e]",    "S_mthgxl[e]",  "S_n2m2nmasn[e]",   "S_nad[e]",     "S_nadp[e]", 
"S_ncam[e]",    "S_no[e]",  "S_nrpphr[e]",  "S_nrvnc[e]",   "S_o2s[e]",     "S_oagd3_hs[e]",    "S_ocdca[e]",   "S_ocdcea[e]",  "S_octa[e]",    "S_paf_hs[e]", 
"S_pchol_hs[e]",    "S_pe_hs[e]",   "S_peplys[e]",  "S_pglyc_hs[e]",    "S_phyt[e]",    "S_prgstrn[e]",     "S_pro_D[e]",   "S_prostgd2[e]",    "S_prostge1[e]",    "S_prostge2[e]", 
"S_prostgf2[e]",    "S_ps_hs[e]",   "S_ptdca[e]",   "S_retfa[e]",   "S_retinol[e]",     "S_Rtotal[e]",  "S_Rtotal2[e]",     "S_spc_hs[e]",  "S_sphs1p[e]",  "S_srtn[e]", 
"S_strdnc[e]",  "S_tagat_D[e]",     "S_taxol[e]",   "S_tchola[e]",  "S_tdchola[e]",     "S_tethex3[e]",     "S_tetpent3[e]",    "S_tetpent6[e]",    "S_thf[e]",     "S_thmtp[e]", 
"S_thym[e]",    "S_thyox_L[e]",     "S_triodthy[e]",    "S_tststerone[e]",  "S_ttdca[e]",   "S_txa2[e]",    "S_Tyr_ggn[e]",     "S_udp[e]",     "S_ump[e]",     "S_urate[e]", 
"S_utp[e]",     "S_vacc[e]",    "S_vitd3[e]",   "S_whhdca[e]",  "S_whtststerone[e]",    "S_xolest_hs[e]",   "S_xolest2_hs[e]",  "S_xoltri25[e]",    "S_xoltri27[e]",    "S_xylt[e]", 
"S_fe2[e]",     "S_fe3[e]",     "S_fol[e]",     "S_fru[e]",     "S_gal[e]",     "S_gam[e]",     "S_malt[e]",    "S_his_L[e]",   "S_ile_L[e]",   "S_leu_L[e]", 
"S_glyc[e]",    "S_man[e]",     "S_mepi[e]",    "S_met_L[e]",   "S_malttr[e]",  "S_nac[e]",     "S_uri[e]",     "S_orn[e]",     "S_phe_L[e]",   "S_pnto_R[e]", 
"S_ppa[e]",     "S_prostgh2[e]",    "S_prostgi2[e]",    "S_pro_L[e]",   "S_ribflv[e]",  "S_rib_D[e]",   "S_so4[e]",     "S_o2[e]",  "S_succ[e]",    "S_taur[e]", 
"S_thymd[e]",   "S_trp_L[e]",   "S_tyr_L[e]",   "S_ura[e]",     "S_urea[e]",    "S_val_L[e]",   "S_4abutn[e]",  "S_acmana[e]",  "S_ctp[e]",     "S_dhap[e]", 
"S_dtmp[e]",    "S_dttp[e]",    "S_fald[e]",    "S_itp[e]",     "S_orot[e]",    "S_cdp[e]",     "S_ptrc[e]",    "S_dtdp[e]",    "S_co2[e]",     "S_citr_L[e]", 
"S_spmd[e]",    "S_C02528[e]",  "S_C02470[e]",  "S_HC02192[e]",     "S_HC02193[e]",     "S_HC02195[e]",     "S_HC02196[e]",     "S_HC02220[e]",     "S_dca[e]",     "S_lac_L[e]", 
"S_but[e]",     "S_HC02191[e]",     "S_HC02194[e]",     "S_HC02197[e]",     "S_HC02198[e]",     "S_HC02187[e]",     "S_HC02180[e]",     "S_wharachd[e]",    "S_HC02202[e]",     "S_HC02203[e]", 
"S_HC02204[e]",     "S_HC02205[e]",     "S_HC02206[e]",     "S_HC02207[e]",     "S_HC02208[e]",     "S_HC02210[e]",     "S_HC02213[e]",     "S_HC02214[e]",     "S_HC02216[e]",     "S_HC02217[e]", 
"S_so3[e]",     "S_sprm[e]",    "S_maltttr[e]",     "S_CE2839[e]",  "S_CE2838[e]",  "S_glcur[e]",   "S_crm_hs[e]",  "S_CE0074[e]",  "S_cdpea[e]",   "S_12HPET[e]", 
"S_3bcrn[e]",   "S_c10crn[e]",  "S_c4crn[e]",   "S_c8crn[e]",   "S_doco13ac[e]",    "S_docosac[e]",     "S_ttdcrn[e]",  "S_4hpro_LT[e]",    "S_tdechola[e]",    "S_carn[e]", 
"S_dchac[e]",   "S_sbt_D[e]",   "S_thm[e]",     "S_oh1[e]",     "S_q10[e]",     "S_fmn[e]",     "S_ptth[e]",    "S_q10h2[e]",   "S_pheme[e]",   "S_34hpp[e]", 
"S_3mob[e]",    "S_3mop[e]",    "S_5mta[e]",    "S_ahcys[e]",   "S_aicar[e]",   "S_mal_L[e]",   "S_idour[e]",   "S_5hoxindoa[e]",   "S_glyald[e]",  "S_pep[e]", 
"S_gudac[e]",   "S_Lkynr[e]",   "S_kynate[e]",  "S_3hanthrn[e]",    "S_2pg[e]",     "S_cholp[e]",   "S_dcmp[e]",    "S_ethamp[e]",  "S_fum[e]",     "S_g3pc[e]", 
"S_icit[e]",    "S_L2aadp[e]",  "S_xan[e]",     "S_xmp[e]",     "S_xtsn[e]",    "S_3pg[e]",     "S_udpglcur[e]",    "S_glyc3p[e]",  "S_nicrnt[e]",  "S_orot5p[e]", 
"S_hcys_L[e]",  "S_retinal[e]",     "S_acrn[e]",    "S_pcrn[e]",    "S_lneldccrn[e]",   "S_odecrn[e]",  "S_stcrn[e]",   "S_pmtcrn[e]",  "S_hdcecrn[e]",     "S_pcholmyr_hs[e]", 
"S_pcholole_hs[e]",     "S_peole_hs[e]",    "S_pcholpalme_hs[e]",   "S_pcholpalm_hs[e]",    "S_pepalm_hs[e]",   "S_pail_hs[e]",     "S_pailpalm_hs[e]",     "S_pcholste_hs[e]",     "S_peste_hs[e]",    "S_pchol2linl_hs[e]", 
"S_pe2linl_hs[e]",  "S_pchol2ole_hs[e]",    "S_pchol2palm_hs[e]",   "S_pchol2ste_hs[e]",    "S_pcholn15_hs[e]",     "S_pcholar_hs[e]",  "S_pcholn183_hs[e]",    "S_pcholn1836_hs[e]",   "S_pcholn19_hs[e]",     "S_pcholn201_hs[e]", 
"S_pcholn204_hs[e]",    "S_pcholn205_hs[e]",    "S_pcholn224_hs[e]",    "S_pcholn225_hs[e]",    "S_pcholn2254_hs[e]",   "S_pcholn226_hs[e]",    "S_pear_hs[e]",     "S_pe203_hs[e]",    "S_pe226_hs[e]",    "S_pe224_hs[e]", 
"S_pedh203_hs[e]",  "S_pe12_hs[e]",     "S_pe14_hs[e]",     "S_pe161_hs[e]",    "S_pe13_hs[e]",     "S_pe15_hs[e]",     "S_pe17_hs[e]",     "S_pcholn203_hs[e]",    "S_pailar_hs[e]",   "S_pcholn24_hs[e]", 
"S_pcholn261_hs[e]",    "S_pcholn281_hs[e]",    "S_pcholn28_hs[e]",     "S_pcholdoc_hs[e]",     "S_pcholeic_hs[e]",     "S_pcholet_hs[e]",  "S_pcholhep_hs[e]",     "S_pchollinl_hs[e]",    "S_pelinl_hs[e]",   "S_elaidcrn[e]", 
"S_lnlccrn[e]",     "S_15HPET[e]",  "S_21hprgnlone[e]",     "S_2oxoadp[e]",     "S_34hpl[e]",   "S_3hmp[e]",    "S_3mhis[e]",   "S_4tmeabutn[e]",   "S_56dthm[e]",  "S_56dura[e]", 
"S_5aop[e]",    "S_7dhchsterol[e]",     "S_acglu[e]",   "S_acgly[e]",   "S_aclys[e]",   "S_alltn[e]",   "S_amet[e]",    "S_biliverd[e]",    "S_C04717[e]",  "S_C04805[e]", 
"S_C05957[e]",  "S_C06314[e]",  "S_C06315[e]",  "S_C14768[e]",  "S_C14769[e]",  "S_C14770[e]",  "S_C14771[e]",  "S_C14825[e]",  "S_C14826[e]",  "S_CE1273[e]", 
"S_CE2510[e]",  "S_CE2537[e]",  "S_eidi1114ac[e]",  "S_CE7172[e]",  "S_cortsn[e]",  "S_forglu[e]",  "S_HC00900[e]",     "S_hexdiac[e]",     "S_hgentis[e]",     "S_hmcr[e]", 
"S_hxcoa[e]",   "S_leuktrB4wcooh[e]",   "S_leuktrB4woh[e]",     "S_lthstrl[e]",     "S_mev_R[e]",   "S_mi1p_D[e]",  "S_nwharg[e]",  "S_pcollg5hlys[e]",     "S_saccrp_L[e]",    "S_sebacid[e]", 
"S_tmlys[e]",   "S_urcan[e]",   "S_galt[e]",    "S_glyc_R[e]",  "S_glyc2p[e]",  "S_glyclt[e]",  "S_ind3ac[e]",  "S_Lcyst[e]",   "S_oaa[e]",     "S_pser_L[e]", 
"S_ttdcea[e]",  "S_estriol[e]",     "S_ddca[e]",    "S_normete_L[e]",   "S_C05300[e]",  "S_dhbpt[e]",   "S_thbpt[e]",   "S_sphmyln_hs[e]",  "S_hxa[e]",     "S_Lhcystin[e]", 
"S_acnam[e]",   "S_etha[e]",    "S_acgal[e]",   "S_core4[e]",   "S_f1a[e]",     "S_dxtrn[e]",   "S_dhcholestanate[e]",  "S_thcholstoic[e]",     "S_xol7ah3[e]",     "S_xol7aone[e]", 
"S_xoldiolone[e]",  "S_7klitchol[e]",   "S_2obut[e]",   "S_gua[e]",     "S_glcr[e]",    "S_hxan[e]",    "S_xyl_D[e]",   "S_pydxn[e]",   "S_pydx[e]",    "S_pydam[e]", 
"S_4hbz[e]",    "S_etoh[e]",    "S_acald[e]",   "S_lanost[e]",  "S_3mox4hoxm[e]",   "S_glx[e]",     "S_2h3mv[e]",   "S_2hiv[e]",    "S_2m3hbu[e]",  "S_3h3mglt[e]", 
"S_3mglutac[e]",    "S_glutcon[e]",     "S_5ohhexa[e]",     "S_ethmalac[e]",    "S_eic21114tr[e]",  "S_5eipenc[e]",     "S_T4hcinnm[e]",    "S_andrstandn[e]",  "S_11docrtsl[e]",   "S_11docrtstrn[e]", 
"S_mma[e]",     "S_mhista[e]",  "S_CE2006[e]",  "S_mlthf[e]",   "S_trypta[e]",  "S_selmeth[e]",     "S_CE7090[e]",  "S_CE7085[e]",  "S_CE7096[e]",  "S_CE4877[e]", 
"S_CE1447[e]",  "S_C05770[e]",  "S_CE2705[e]",  "S_hdd2crn[e]",     "S_CE1918[e]",  "S_CE6205[e]",  "S_CE4969[e]",  "S_CE1310[e]",  "S_sucsal[e]",  "S_CE7081[e]", 
"S_egme[e]",    "S_sql[e]",     "S_orn_D[e]",   "S_5g2oxpt[e]",     "S_HC02020[e]",     "S_xol27oh[e]",     "S_xol25oh[e]",     "S_dsmsterol[e]",   "S_3ityr_L[e]",     "S_35diotyr[e]", 
"S_13_cis_retn[e]",     "S_C05767[e]",  "S_ppbng[e]",   "S_12ppd_R[e]",     "S_ametam[e]",  "S_xylu_L[e]",  "S_xylu_D[e]",  "S_sphings[e]",     "S_im4ac[e]",   "S_aact[e]", 
"S_sphgn[e]",   "S_C13856[e]",  "S_prist[e]",   "S_CE2049[e]",  "S_CE2047[e]",  "S_fdp[e]",     "S_coke[e]",    "S_5a2opntn[e]",    "S_arg_D[e]",   "S_dopa4glcur[e]", 
"S_dopa3glcur[e]",  "S_CE5026[e]",  "S_CE1261[e]",  "S_CE5025[e]",  "S_CE2172[e]",  "S_CE5629[e]",  "S_galgluside_hs[e]",   "S_gluside_hs[e]",  "S_gd3_hs[e]",  "S_gm1_hs[e]", 
"S_34dhpe[e]",  "S_M00003[e]",  "S_M00008[e]",  "S_M00010[e]",  "S_M00017[e]",  "S_M00019[e]",  "S_M00021[e]",  "S_M00115[e]",  "S_M00260[e]",  "S_M00265[e]", 
"S_M00315[e]",  "S_M00341[e]",  "S_M01207[e]",  "S_M01235[e]",  "S_M01238[e]",  "S_M01582[e]",  "S_M02053[e]",  "S_M02457[e]",  "S_M02613[e]",  "S_M02745[e]", 
"S_M03045[e]",  "S_M03153[e]",  "S_C01601[e]",  "S_M02108[e]",  "S_M03117[e]",  "S_M03134[e]",  "S_nadh[e]",    "S_M01870[e]",  "S_M02446[e]",  "S_M02447[e]", 
"S_M02449[e]",  "S_M02451[e]",  "S_itacon[e]",  "S_adpman[e]",  "S_rbl_D[e]",   "S_M02155[e]",  "S_M01989[e]",  "S_M01881[e]",  "S_n5m2masn[e]",    "S_dolichol_L[e]", 
"S_12dhchol[e]",    "S_3dhcdchol[e]",   "S_3dhchol[e]",     "S_3dhdchol[e]",    "S_3dhlchol[e]",    "S_7dhcdchol[e]",   "S_7dhchol[e]",     "S_cdca24g[e]",     "S_cdca3g[e]",  "S_coprost[e]", 
"S_hca24g[e]",  "S_hdca24g[e]",     "S_hdca6g[e]",  "S_hyochol[e]",     "S_icdchol[e]",     "S_isochol[e]",     "S_lca24g[e]",  "S_lca3g[e]",   "S_thyochol[e]",    "S_uchol[e]", 
"S_12htacr[e]",     "S_14hmdz[e]",  "S_1hibupglu_S[e]",     "S_1hibup_S[e]",    "S_1ohmdz[e]",  "S_2hatvacid[e]",   "S_2hatvlac[e]",    "S_2hibupglu_S[e]",     "S_2hibup_R[e]",    "S_2hibup_S[e]", 
"S_35dsmv[e]",  "S_3hibupglu_S[e]",     "S_3hibup_R[e]",    "S_3hibup_S[e]",    "S_3hlvstacid[e]",  "S_3hpvstet[e]",    "S_3hpvs[e]",   "S_3hsmvacid[e]",   "S_3ispvs[e]",  "S_3ohacmp[e]", 
"S_4hatvacid[e]",   "S_4hatvlac[e]",    "S_4ohmdz[e]",  "S_56dhpvs[e]",     "S_56eppvs[e]",     "S_5ohfvsglu[e]",   "S_5ohfvs[e]",  "S_6bhglz[e]",  "S_6csmvacid[e]",   "S_6epvs[e]", 
"S_6hlvst[e]",  "S_6hmsmvacid[e]",  "S_6hsmvacid[e]",   "S_6melvacid[e]",   "S_6melvst[e]",     "S_6ohfvsglu[e]",   "S_7bhglz[e]",  "S_7hpvs[e]",   "S_acmp[e]",    "S_am19cs[e]", 
"S_am1csa[e]",  "S_am9csa[e]",  "S_atvacid[e]",     "S_atvlac[e]",  "S_caribupglu_S[e]",    "S_caribup_s[e]",   "S_crvs[e]",    "S_crvsm24[e]",     "S_csa[e]",     "S_deoxfvs[e]", 
"S_dspvs[e]",   "S_epoxtac[e]",     "S_fvs[e]",     "S_glc3meacp[e]",   "S_glz[e]",     "S_ibup_R[e]",  "S_ibup_S[e]",  "S_ibupgluc[e]",    "S_isolvstacid[e]",     "S_lstn[e]", 
"S_lstnm7[e]",  "S_lvst[e]",    "S_mdz[e]",     "S_mhglz[e]",   "S_nfdac[e]",   "S_nfdoh[e]",   "S_profvs[e]",  "S_ptvst[e]",   "S_ptvstlac[e]",    "S_pvs[e]", 
"S_pvsgluc[e]",     "S_smv[e]",     "S_smvacid[e]",     "S_tacr[e]",    "S_tlacfvs[e]",     "S_tripvs[e]",  "S_ptvstm13[e]",    "S_caproic[e]",     "S_1a25dhvitd2[e]",     "S_peptide[e]", 
"S_abeta_L_lysine[e]",  "S_tau_L_lysine[e]",    "S_TNFA_L_lysine[e]",   "S_IL6_L_lysine[e]",    "S_3mlda[e]",   "S_5adtststerones[e]",  "S_acnacngalgbside_hs[e]",  "S_crmp_hs[e]",     "S_3aib_D[e]",  "S_lac_D[e]", 
"S_aprgstrn[e]",    "S_avite1[e]",  "S_fuc_L[e]",   "S_gt1a_hs[e]",     "S_hestratriol[e]",     "S_nrpphrsf[e]",    "S_s2l2fn2m2masn[e]",   "S_s2l2n2m2masn[e]",    "S_sph1p[e]",   "S_tettet6[e]", 
"S_tmndnc[e]",  "S_triodthysuf[e]",     "S_tststerones[e]",     "S_tre[e]",     "S_dgmp[e]",    "S_dgtp[e]",    "S_ppi[e]",     "S_pyr[e]",     "S_acac[e]",    "S_c101crn[e]", 
"S_c12dc[e]",   "S_c16dc[e]",   "S_c3dc[e]",    "S_c4dc[e]",    "S_c6crn[e]",   "S_c81crn[e]",  "S_3ddcrn[e]",  "S_ddeccrn[e]",     "S_ddece1crn[e]",   "S_3deccrn[e]", 
"S_decdicrn[e]",    "S_3octdece1crn[e]",    "S_3tdcrn[e]",  "S_tetdec2crn[e]",  "S_tetdece1crn[e]",     "S_slfcys[e]",  "S_4mop[e]",    "S_cbasp[e]",   "S_phlac[e]",   "S_15kprostgf2[e]", 
"S_3hpp[e]",    "S_3uib[e]",    "S_adpac[e]",   "S_adpoh[e]",   "S_pa_hs[e]",   "S_C11695[e]",  "S_CE5304[e]",  "S_CE6247[e]",  "S_dodecanac[e]",   "S_sphmyln180241_hs[e]", 
"S_sphmyln18114_hs[e]",     "S_sphmyln18115_hs[e]",     "S_sphmyln18116_hs[e]",     "S_sphmyln181161_hs[e]",    "S_sphmyln18117_hs[e]",     "S_sphmyln18118_hs[e]",     "S_sphmyln181181_hs[e]",    "S_sphmyln18120_hs[e]",     "S_sphmyln181201_hs[e]",    "S_sphmyln18121_hs[e]", 
"S_sphmyln18122_hs[e]",     "S_sphmyln181221_hs[e]",    "S_sphmyln18123_hs[e]",     "S_sphmyln1824_hs[e]",  "S_sphmyln1825_hs[e]",  "S_subeac[e]",  "S_pac[e]",     "S_pheacgly[e]",    "S_homoval[e]",     "S_s2l2n2m2m[e]", 
"S_phpyr[e]",   "S_ppiogly[e]",     "S_tiggly[e]",  "S_3hivac[e]",  "S_3hadpac[e]",     "S_3ohsebac[e]",    "S_3ohsubac[e]",    "S_hexgly[e]",  "S_subgly[e]",  "S_4ohbut[e]", 
"S_34dhoxmand[e]",  "S_dhea[e]",    "S_estrone[e]",     "S_chsterols[e]",   "S_M00117[e]",  "S_M01197[e]",  "S_M03051[e]",  "S_ditp[e]",    "S_M03131[e]",  "S_1hmdgluc[e]", 
"S_2hatvlacgluc[e]",    "S_4hmdgluc[e]",    "S_oxyp[e]",                            
                                    
*species participate in the extracellular compartment only, but not existed in the intrcellular compartments                                    
"S_strch1[e]",  "S_strch2[e]",  "S_glygn4[e]",  "S_adprbp[e]",  "S_gluala[e]",  "S_glygn5[e]",  "S_lcts[e]",    "S_sucr[e]",    "S_ahdt[e]",    "S_dha[e]", 
"S_HC01104[e]",     "S_HC01361[e]",     "S_HC01446[e]",     "S_HC01577[e]",     "S_HC01700[e]",     "S_HC00955[e]",     "S_maltpt[e]",  "S_malthx[e]",  "S_CE2915[e]",  "S_CE4722[e]", 
"S_CE2916[e]",  "S_CE4723[e]",  "S_CE2917[e]",  "S_CE4724[e]",  "S_malthp[e]",  "S_CE1950[e]",  "S_cynt[e]",    "S_CE5786[e]",  "S_CE5788[e]",  "S_CE5867[e]", 
"S_CE5868[e]",  "S_CE5869[e]",  "S_CE4633[e]",  "S_no2[e]",     "S_CE4881[e]",  "S_CE1926[e]",  "S_CE5854[e]",  "S_12dgr120[e]",    "S_CE1925[e]",  "S_CE5853[e]", 
"S_cysam[e]",   "S_pailste_hs[e]",  "S_xolest183_hs[e]",    "S_xolest181_hs[e]",    "S_xolest204_hs[e]",    "S_M00234[e]",  "S_M01807[e]",  "S_M00503[e]",  "S_M01111[e]",  "S_ksi[e]", 
"S_ksi_deg1[e]",    "S_HC01444[e]",     "S_CE5789[e]",  "S_CE5797[e]",  "S_CE5798[e]",  "S_aracheth[e]",    "S_didecaeth[e]",   "S_diholineth[e]",  "S_docohxeth[e]",   "S_docteteth[e]", 
"S_hepdeceth[e]",   "S_hexdeceeth[e]",  "S_lineth[e]",  "S_oleth[e]",   "S_pendecaeth[e]",  "S_pmeth[e]",   "S_steeth[e]",  "S_tetdecaeth[e]",  "S_trideceth[e]",   "S_h2co3[e]", 
                                    
*species participate in a single intracellular compartment only, but not existed in the extracellular compartment                                   
"S_13dampp[c]",     "S_cmusa[c]",   "S_T_antigen[g]",   "S_gam6p[c]",   "S_man6p[c]",   "S_dhcholoylcoa[x]",    "S_ksii_core4_pre5[g]",     "S_n2m2nmn[l]",     "S_octd11ecoa[c]",  "S_itaccoa[m]", 
"S_core7[g]",   "S_dgpi_prot_hs[r]",    "S_23dpg[c]",   "S_f26bp[c]",   "S_ksii_core4_pre10[g]",    "S_cs_d_pre3[g]",   "S_fgam[c]",    "S_cs_a_b_e_pre1[g]",   "S_hs_pre7[g]",     "S_hs_deg25[l]", 
"S_pre_prot[r]",    "S_hs_deg19[l]",    "S_lgt_S[c]",   "S_retinol_cis_11[c]",  "S_prpp[c]",    "S_ru5p_D[c]",  "S_cs_e_pre5b[g]",  "S_HC00342[m]",     "S_r5p[c]",     "S_HC02027[r]", 
"S_CE2576[c]",  "S_CE5118[m]",  "S_CE2567[c]",  "S_CE4838[x]",  "S_CE4803[m]",  "S_CE4807[m]",  "S_CE6504[c]",  "S_CE6232[c]",  "S_tmuncoa[x]",     "S_23dh1i56dio[c]", 
"S_gda1_hs[n]",     "S_M02686[c]",  "S_galfucgalacglcgalgluside_hs[c]",     "S_M00964[c]",  "S_M00406[c]",  "S_HC01406[x]",     "S_M00061[m]",  "S_M00792[m]",  "S_M01454[r]",  "S_M01465[r]", 
"S_M01475[r]",  "S_M01486[r]",  "S_M01501[r]",  "S_M00770[m]",  "S_tau_N_Ub_lysine[c]",     "S_IL6_N_Ub_lysine[c]",     "S_ivcoa[m]",   "S_CE2873[c]",  "S_CE4845[c]",  "S_c101coa[c]", 
"S_tetdec2coa[c]",  "S_3hadicoa[x]",    "S_M00871[c]",  "S_M00862[c]",  "S_bamppald[c]",    "S_2amac[c]",   "S_2dr1p[c]",   "S_glutcoa[m]",     "S_34dhpac[c]",     "S_3dphb[m]", 
"S_3dpdhb[m]",  "S_3hibutcoa[m]",   "S_hLkynr[c]",  "S_42A3HP24DB[c]",  "S_e4hglu[m]",  "S_5hoxindact[c]",  "S_m2mn[l]",    "S_mn[l]",  "S_core2[g]",   "S_gncore2[g]", 
"S_fucgalacglcgalgluside_hs[g]",    "S_fuc12gal14acglcgalgluside_hs[g]",    "S_fucfucgalacglcgalacglcgal14acglcgalgluside_hs[g]",   "S_abt[c]",     "S_acgal1p[c]",     "S_acgam6p[c]",     "S_acgam1p[c]",     "S_acgpail_hs[c]",  "S_gpail_hs[c]",    "S_acmanap[c]", 
"S_acnamp[c]",  "S_2mbcoa[m]",  "S_2mb2coa[m]",     "S_ibcoa[m]",   "S_2mp2coa[m]",     "S_acetol[c]",  "S_damp[c]",    "S_g1p[c]",     "S_man1p[c]",   "S_aps[c]", 
"S_dcamp[c]",   "S_25aics[c]",  "S_ksii_core4_pre2[g]",     "S_ksii_core4_pre3[g]",     "S_ksii_core4_pre4[g]",     "S_ksii_core4_pre7[g]",     "S_ksii_core4_pre8[g]",     "S_ksii_core2_pre2[g]",     "S_ksii_core2_pre3[g]",     "S_ksii_core2_pre4[g]", 
"S_ksii_core2_pre5[g]",     "S_ksii_core2_pre7[g]",     "S_ksii_core2_pre8[g]",     "S_air[c]",     "S_5aizc[c]",   "S_lald_D[c]",  "S_12ppd_S[c]",     "S_2aobut[m]",  "S_Rtotalcoa[c]",   "S_Rtotal3coa[c]", 
"S_Rtotal3[c]",     "S_R2coa_hs[c]",    "S_Asn_X_Ser_Thr[l]",   "S_gal14acglcgalgluside_hs[g]",     "S_acglc13galacglcgal14acglcgalgluside_hs[g]",  "S_galacglcgalacglcgal14acglcgalgluside_hs[g]",     "S_galacglc13galacglcgal14acglcgalgluside_hs[g]",   "S_galthcrm_hs[g]",     "S_galgalthcrm_hs[g]",  "S_acglcgalgbside_hs[g]", 
"S_dgcholcoa[x]",   "S_gdpmann[c]",     "S_memgacpail_hs[r]",   "S_m2emgacpail_hs[r]",  "S_zym_int2[r]",    "S_citmcoa_L[m]",   "S_clpn_hs[c]",     "S_2dpmhobq[m]",    "S_2dp6mobq[m]",    "S_2dp6mobq_me[m]", 
"S_2dp6mep[m]",     "S_core3[g]",   "S_core5[g]",   "S_cs_a[l]",    "S_cs_e[l]",    "S_focytC[m]",  "S_ficytC[m]",  "S_4h2oglt[m]",     "S_dedoldp_L[c]",   "S_dedolp_L[c]", 
"S_dedol_L[c]",     "S_tag_hs[c]",  "S_3dhguln[c]",     "S_3dpdhb_me[m]",   "S_dkmpp[c]",   "S_2kmb[c]",    "S_dem2emgacpail_prot_hs[r]",   "S_gpi_sig[r]",     "S_mem2emgacpail_prot_hs[r]",   "S_dmhptcoa[m]", 
"S_dopaqn[c]",  "S_13dpg[c]",   "S_2dr5p[c]",   "S_g3p[c]",     "S_3hmbcoa[m]",     "S_n2m2nm[l]",  "S_malcoa[c]",  "S_Sfglutth[c]",    "S_xu1p_D[c]",  "S_tag1p_D[c]", 
"S_f6p[c]",     "S_fucgalacglc13galacglcgal14acglcgalgluside_hs[g]",    "S_fucfucgalacglc13galacglcgal14acglcgalgluside_hs[g]",     "S_ksii_core4_pre1[g]",     "S_ksii_core4_pre6[g]",     "S_ksii_core4_pre9[g]",     "S_ksii_core2_pre1[g]",     "S_ksii_core2_pre6[g]",     "S_ksii_core2_pre9[g]",     "S_ksii_core2_pre10[g]", 
"S_glu5p[m]",   "S_cs_hs_linkage[g]",   "S_cs_pre[g]",  "S_cs_a_b_pre2[g]",     "S_cs_a_b_pre3[g]",     "S_cs_c_pre2[g]",   "S_cs_c_pre3[g]",   "S_cs_d_pre4[g]",   "S_cs_e_pre3[g]",   "S_cs_e_pre4[g]", 
"S_lxser[g]",   "S_l2xser[g]",  "S_gar[c]",     "S_lpam[m]",    "S_dhlam[m]",   "S_gdpddman[c]",    "S_udpg[c]",    "S_ttc_ggdp[c]",    "S_3htmelys[c]",    "S_4tmeabut[c]", 
"S_hs_deg9[l]",     "S_hs_deg10[l]",    "S_cs_a_deg2[l]",   "S_cs_a_deg3[l]",   "S_cs_e_deg3[l]",   "S_cs_e_deg4[l]",   "S_ha_deg1[l]",     "S_hs_pre10[g]",    "S_hs_pre11[g]",    "S_cs_c_d_e_pre1[g]", 
"S_cs_d_pre2[g]",   "S_cs_e_pre2[g]",   "S_hs_pre1[g]",     "S_hs_pre2[g]",     "S_hs_pre3[g]",     "S_hs_pre4[g]",     "S_hs_pre5[g]",     "S_hs_pre6[g]",     "S_hs_pre8[g]",     "S_hs_deg3[l]", 
"S_hs_deg4[l]",     "S_hs_deg8[l]",     "S_hs_deg14[l]",    "S_hs_deg15[l]",    "S_hs_deg20[l]",    "S_hs_deg21[l]",    "S_hs_deg24[l]",    "S_hs_pre9[g]",     "S_glygn3[c]",  "S_glucys[c]", 
"S_5forthf[c]",     "S_em2emgacpail_prot_hs[r]",    "S_gpi_prot_hs[r]",     "S_mgacpail_hs[r]",     "S_emgacpail_hs[r]",    "S_m2gacpail_hs[r]",    "S_m3gacpail_hs[r]",    "S_em3gacpail_hs[r]",   "S_emem2gacpail_hs[r]",     "S_em2emgacpail_hs[r]", 
"S_m3emgacpail_hs[r]",  "S_gpi_hs[r]",  "S_mem2emgacpail_hs[r]",    "S_im4act[c]",  "S_phyt2ohcoa[x]",  "S_hs_deg1[l]",     "S_hs_deg2[l]",     "S_hs_deg6[l]",     "S_hs_deg7[l]",     "S_hs_deg12[l]", 
"S_hs_deg13[l]",    "S_hs_deg18[l]",    "S_eandrstrn[r]",   "S_hs[l]",  "S_iodine[c]",  "S_hs_deg5[l]",     "S_hs_deg16[l]",    "S_hs_deg17[l]",    "S_hs_deg22[l]",    "S_hs_deg23[l]", 
"S_f1p[c]",     "S_4aphdob[c]",     "S_cs_a_deg5[l]",   "S_cs_e_deg7[l]",   "S_retinol_9_cis[c]",   "S_3mgcoa[m]",  "S_5mdru1p[c]",     "S_mi1345p[c]",     "S_mi134p[c]",  "S_mi145p[c]", 
"S_mi14p[c]",   "S_mi3p_D[c]",  "S_5mdr1p[c]",  "S_cs_a_deg1[l]",   "S_cs_a_deg4[l]",   "S_nicrns[c]",  "S_r1p[c]",     "S_thbpt4acam[c]",  "S_pail345p_hs[c]",     "S_pail34p_hs[c]", 
"S_pail3p_hs[c]",   "S_pram[c]",    "S_quln[c]",    "S_retinal_11_cis[c]",  "S_retinal_cis_9[c]",   "S_retinol_cis_13[c]",  "S_retn[r]",    "S_rnam[c]",    "S_cs_d_pre5[g]",   "S_hs_pre12[g]", 
"S_hs_pre13[g]",    "S_hs_pre14[g]",    "S_hs_pre15[g]",    "S_hs_deg11[l]",    "S_thmpp[c]",   "S_udpxyl[r]",  "S_xu5p_D[c]",  "S_HC01672[c]",     "S_HC00591[c]",     "S_HC01496[m]", 
"S_e4p[c]",     "S_HC00361[c]",     "S_s7p[c]",     "S_HC01712[m]",     "S_HC00718[c]",     "S_HC00664[c]",     "S_HC01180[c]",     "S_fpram[c]",   "S_xol7ah2al[c]",   "S_HC01842[c]", 
"S_HC02021[r]",     "S_HC02022[r]",     "S_HC02023[r]",     "S_HC02121[c]",     "S_CE1944[c]",  "S_CE2866[c]",  "S_CE4888[c]",  "S_CE5586[c]",  "S_CE5626[c]",  "S_CE5276[c]", 
"S_CE5021[c]",  "S_CE5022[c]",  "S_CE2577[c]",  "S_C05109[c]",  "S_CE5665[c]",  "S_CE5166[m]",  "S_CE5125[x]",  "S_CE5126[x]",  "S_CE5117[m]",  "S_CE5119[m]", 
"S_CE5120[m]",  "S_CE4790[m]",  "S_CE4792[m]",  "S_CE4794[m]",  "S_CE2056[r]",  "S_CE3554[r]",  "S_cpppg3[c]",  "S_uppg3[c]",   "S_CE2038[x]",  "S_CE5934[x]", 
"S_C07297[x]",  "S_tmtrdcoa[x]",    "S_CE4812[c]",  "S_CE4811[c]",  "S_CE4810[c]",  "S_CE4821[c]",  "S_CE4819[c]",  "S_CE4817[c]",  "S_CE2313[c]",  "S_CE2314[c]", 
"S_CE4833[c]",  "S_CE4831[c]",  "S_CE4835[c]",  "S_CE4834[c]",  "S_CE4849[c]",  "S_CE4820[x]",  "S_CE4832[x]",  "S_CE4842[c]",  "S_CE4853[c]",  "S_CE4801[m]", 
"S_CE4800[m]",  "S_CE4796[m]",  "S_CE4802[m]",  "S_CE4804[m]",  "S_CE5049[c]",  "S_CE4806[m]",  "S_CE4798[m]",  "S_CE4799[m]",  "S_CE4808[m]",  "S_CE4797[m]", 
"S_C11821[c]",  "S_CE6506[c]",  "S_C08261[c]",  "S_CE6508[c]",  "S_CE7091[r]",  "S_CE7088[c]",  "S_CE6230[c]",  "S_CE6234[c]",  "S_doco13ecoa[c]",  "S_hexdtrcoa[m]", 
"S_2hexdtetcoa[x]",     "S_4hexdtetcoa[x]",     "S_hexdpencoa[x]",  "S_3hexdtetcoa[x]",     "S_eipencoa[x]",    "S_5eipencoa[m]",   "S_2docohexecoa[m]",    "S_docohepcoa[m]",  "S_docosahexcoa[m]",    "S_5dpmev[c]", 
"S_6pgl[c]",    "S_5pmev[c]",   "S_ttdceacoa[c]",   "S_txb2[c]",    "S_hmbil[c]",   "S_phom[c]",    "S_gal1p[c]",   "S_glutacoa[m]",    "S_ethmalcoa[c]",   "S_6hddopaqn[c]", 
"S_5cysdopa[c]",    "S_gd1b_hs[c]",     "S_gt1b_hs[c]",     "S_gm2_hs[c]",  "S_HC02048[c]",     "S_HC02042[c]",     "S_HC02050[c]",     "S_HC02051[c]",     "S_HC02054[c]",     "S_HC02056[c]", 
"S_HC02060[c]",     "S_M02758[c]",  "S_HC02076[c]",     "S_HC02070[c]",     "S_M02197[c]",  "S_gm3_hs[c]",  "S_M02195[c]",  "S_acgalfucgalacglcgalgluside_hs[c]",   "S_M02683[c]",  "S_M02186[c]", 
"S_M02490[c]",  "S_M00961[c]",  "S_M00957[c]",  "S_M00963[c]",  "S_M00959[c]",  "S_M00955[c]",  "S_M01067[c]",  "S_M00940[c]",  "S_M00938[c]",  "S_M00942[c]", 
"S_M00962[c]",  "S_M00958[c]",  "S_M00954[c]",  "S_M00966[c]",  "S_M00967[c]",  "S_M00960[c]",  "S_M00956[c]",  "S_M01068[c]",  "S_cholcoas[m]",    "S_HC01459[m]", 
"S_M00605[c]",  "S_M02760[c]",  "S_M02761[c]",  "S_M00603[c]",  "S_M00285[c]",  "S_HC01405[x]",     "S_HC01407[x]",     "S_HC01408[x]",     "S_M00046[m]",  "S_M00780[m]", 
"S_M00875[m]",  "S_M00795[m]",  "S_M00897[m]",  "S_M00069[m]",  "S_M00804[m]",  "S_M00909[m]",  "S_M00071[m]",  "S_M00806[m]",  "S_M00911[m]",  "S_M00056[m]", 
"S_M00889[m]",  "S_M00048[m]",  "S_M00782[m]",  "S_M00877[m]",  "S_M00063[m]",  "S_M00797[m]",  "S_M00899[m]",  "S_M03024[m]",  "S_M00170[m]",  "S_M00841[m]", 
"S_M01455[r]",  "S_M01456[r]",  "S_M01457[r]",  "S_M01458[r]",  "S_M01460[r]",  "S_M01461[r]",  "S_M01462[r]",  "S_M01463[r]",  "S_M01464[r]",  "S_M01466[r]", 
"S_M01467[r]",  "S_M01468[r]",  "S_M01469[r]",  "S_M01470[r]",  "S_M01471[r]",  "S_M01472[r]",  "S_M01473[r]",  "S_M01474[r]",  "S_M01476[r]",  "S_M01477[r]", 
"S_M01479[r]",  "S_M01480[r]",  "S_M01481[r]",  "S_M01482[r]",  "S_M01483[r]",  "S_M01484[r]",  "S_M01485[r]",  "S_M01487[r]",  "S_M01489[r]",  "S_M01491[r]", 
"S_M01492[r]",  "S_M01494[r]",  "S_M01495[r]",  "S_M01496[r]",  "S_M01497[r]",  "S_M01498[r]",  "S_M01502[r]",  "S_M01506[r]",  "S_M01508[r]",  "S_M01509[r]", 
"S_M01510[r]",  "S_M00658[m]",  "S_M01165[m]",  "S_M00213[c]",  "S_Ndmelys[c]",     "S_Ntmelys[c]",     "S_M01869[g]",  "S_M03167[c]",  "S_6msmv[r]",   "S_atvethgluc[r]", 
"S_crvsm1[r]",  "S_crvsm23[r]",     "S_ptvstgluc[r]",   "S_rsvgluc[r]",     "S_ubiquitin[c]",   "S_abeta[c]",   "S_abeta_N_Ub_lysine[c]",   "S_abeta_N6_methyl_L_lysine[c]",    "S_abeta_N6_N6_dimethyl_L_lysine[c]",   "S_abeta_N6_N6_N6_trimethyl_L_lysine[c]", 
"S_tau[c]",     "S_tau_N6_methyl_L_lysine[c]",  "S_tau_N6_N6_dimethyl_L_lysine[c]",     "S_tau_N6_N6_N6_trimethyl_L_lysine[c]",     "S_TNFA[c]",    "S_TNFA_N_Ub_lysine[c]",    "S_TNFA_N6_methyl_L_lysine[c]",     "S_TNFA_N6_N6_dimethyl_L_lysine[c]",    "S_TNFA_N6_N6_N6_trimethyl_L_lysine[c]",    "S_IL6[c]", 
"S_IL6_N6_methyl_L_lysine[c]",  "S_IL6_N6_N6_dimethyl_L_lysine[c]",     "S_IL6_N6_N6_N6_trimethyl_L_lysine[c]",     "S_34dhpha[c]",     "S_4hoxpacd[c]",    "S_4hphac[c]",  "S_3otdcoa[x]",     "S_kdnp[c]",    "S_3mb2coa[m]",     "S_melatn[c]", 
"S_msa[m]",     "S_kdn[c]",     "S_fuc1p_L[c]",     "S_3mldz[c]",   "S_6hoxmelatn[c]",  "S_mi13p[c]",   "S_dimp[c]",    "S_peamn[c]",   "S_acngalgbside_hs[g]",     "S_trdrd[c]", 
"S_trdox[c]",   "S_tym[c]",     "S_3mox4hpac[m]",   "S_CE2870[c]",  "S_CE2872[c]",  "S_CE2875[c]",  "S_CE2874[c]",  "S_CE4841[c]",  "S_CE4840[c]",  "S_CE4844[c]", 
"S_CE4846[c]",  "S_CE4852[c]",  "S_CE4850[c]",  "S_CE4848[c]",  "S_CE4851[c]",  "S_CE5160[c]",  "S_CE5161[c]",  "S_CE5162[c]",  "S_CE7097[m]",  "S_decdicoa[c]", 
"S_c12dccoa[c]",    "S_tetdece1coa[c]",     "S_c81coa[c]",  "S_3ivcoa[m]",  "S_phaccoa[m]",     "S_3ohsebcoa[x]",   "S_3ohsubcoa[x]",   "S_M02491[c]",  "S_CE6246[c]",  "S_M00907[c]", 
"S_M00802[c]",  "S_M00067[c]",  "S_M00852[c]",  "S_M00707[c]",  "S_M03018[c]",  "S_M00839[c]",  "S_M00699[c]",  "S_M03011[c]",  "S_M00704[c]",  "S_M03017[c]", 
"S_M00860[c]",  "S_M00085[c]",  "S_M03008[c]",  "S_M00869[c]",  "S_M00086[c]",  "S_M03005[c]",  "S_M00712[c]",  "S_M03006[c]",  "S_atvacylgluc[r]",     "S_atvlacgluc[r]", 
                                    
*metabolites participate in at least two intracellular compartments, but not existed in the extracellular compartment                                   
"S_17ahprgnlone[c][r]",     "S_17ahprgstrn[c][r]",  "S_1a25dhvitd3[c][m][n]",   "S_1p3h5c[c][m]",   "S_1pyr5c[c][m]",   "S_20ahchsterol[m][r]",     "S_25hvitd2[c][m]",     "S_25hvitd3[c][m]",     "S_2ddecdicoa[m][x]",   "S_2decdicoa[m][x]", 
"S_2docopencoa[m][x]",  "S_2dodtricoa[m][x]",   "S_2hexdtricoa[m][x]",  "S_2mop[c][m]",     "S_2octdectecoa[m][x]",     "S_34dhmald[c][m]",     "S_3ddecdicoa[m][x]",   "S_3decdicoa[m][x]",    "S_3docopencoa[m][x]",  "S_3dodtricoa[m][x]", 
"S_3hbcoa[m][x]",   "S_3hbcoa_R[c][m]",     "S_3hdcoa[c][m]",   "S_3hddcoa[c][m]",  "S_3hexdtricoa[m][x]",  "S_3hlvst[c][r]",   "S_3hpvscoa[c][m][x]",  "S_3hpvstetcoa[c][m][x]",   "S_3hsmv[c][r]",    "S_3htdcoa[c][m][x]", 
"S_3m4hpga[c][m]",  "S_3meacmp[c][r]",  "S_3octdece1coa[c][m]",     "S_3octdectecoa[m][x]",     "S_3ohodcoa[c][m][x]",  "S_3ohxccoa[c][x]",     "S_3sala[c][m]",    "S_44mctr[c][r]",   "S_44mzym[c][r]",   "S_4hbzcoa[c][m]", 
"S_4hexdtricoa[m][x]",  "S_4mzym_int1[c][r]",   "S_4mzym_int2[c][r]",   "S_5HPET[c][m]",    "S_5tedtricoa[m][x]",   "S_6csmv[c][r]",    "S_6hlvstacid[c][r]",   "S_6hmsmv[c][r]",   "S_6hsmv[c][r]",    "S_aacoa[c][m][x]", 
"S_accoa[c][g][m][n][x]",   "S_acgagbside_hs[c][g][l]",     "S_acgbgbside_hs[c][g][l]",     "S_acglcgal14acglcgalgluside_hs[c][g]",     "S_acglcgalacglcgal14acglcgalgluside_hs[c][g]",     "S_acglcgalgluside_hs[c][g]",   "S_adpcoa[c][x]",   "S_adrncoa[c][m][r][x]",    "S_adrncrn[c][m]",  "S_andrstndn[c][r]", 
"S_arachcoa[c][m][r][x]",   "S_arachcrn[c][m]",     "S_arachdcoa[c][m][r][x]",  "S_arachdcrn[c][m]",    "S_b2coa[m][x]",    "S_btcoa[c][m][x]",     "S_C01747[c][l]",   "S_C02712[c][m]",   "S_C05279[m][x]",   "S_C05280[m][x]", 
"S_c10dc[c][x]",    "S_c226coa[c][m][r][x]",    "S_c226crn[c][m]",  "S_c6dc[c][x]",     "S_c8dc[c][x]",     "S_cbl2[c][m]",     "S_cbp[c][r]",  "S_cdpchol[c][r]",  "S_cdpdag_hs[c][m]",    "S_CE0347[c][r]", 
"S_CE0693[m][x]",   "S_CE0713[m][x]",   "S_CE0785[m][x]",   "S_CE0849[m][x]",   "S_CE2053[m][r]",   "S_CE2084[c][m]",   "S_CE2242[c][m][x]",    "S_CE2243[m][x]",   "S_CE2245[c][x]",   "S_CE2246[c][m][x]", 
"S_CE2247[m][x]",   "S_CE2248[c][m][x]",    "S_CE2249[c][x]",   "S_CE2250[c][m][x]",    "S_CE2251[m][x]",   "S_CE2253[c][x]",   "S_CE2417[m][x]",   "S_CE2418[m][x]",   "S_CE2420[m][x]",   "S_CE2421[m][x]", 
"S_CE2422[m][x]",   "S_CE2424[m][x]",   "S_CE2432[m][x]",   "S_CE2433[m][x]",   "S_CE2434[m][x]",   "S_CE2437[m][x]",   "S_CE2438[m][x]",   "S_CE2439[m][x]",   "S_CE2440[m][x]",   "S_CE2441[m][x]", 
"S_CE2442[m][x]",   "S_CE4791[c][m][x]",    "S_CE4793[c][m][x]",    "S_CE4795[m][x]",   "S_CE4843[c][m][r]",    "S_CE4847[c][m]",   "S_CE4854[c][m]",   "S_CE4855[c][x]",   "S_CE4988[c][m][x]",    "S_CE4990[m][x]", 
"S_CE5114[c][m][x]",    "S_CE5116[m][x]",   "S_CE5144[c][m][x]",    "S_CE5148[c][m][x]",    "S_CE5150[c][m][x]",    "S_CE5151[c][m][r][x]",     "S_CE5152[c][m][x]",    "S_CE5153[c][m][x]",    "S_CE5154[c][m][x]",    "S_CE5155[c][m][r][x]", 
"S_CE5156[c][x]",   "S_CE5157[c][x]",   "S_CE5158[c][x]",   "S_CE5253[c][l]",   "S_CE5944[m][x]",   "S_CE5947[c][m][x]",    "S_chlstol[c][r]",  "S_cholcoa[c][m][r][x]",    "S_cholcoads[m][x]",    "S_cholcoaone[m][x]", 
"S_cholcoar[c][m][r][x]",   "S_clpndcoa[c][m][r][x]",   "S_clpndcrn[c][m]",     "S_cmpacna[c][g][n]",   "S_coa[c][g][l][m][n][r][x]",   "S_core6[g][l]",    "S_coucoa[c][m]",   "S_dadp[c][m][n]",  "S_datp[c][m][n]",  "S_dc2coa[m][x]", 
"S_dcacoa[c][m][x]",    "S_dcdp[c][m][n]",  "S_dcholcoa[c][r][x]",  "S_dcsptn1coa[c][m][r][x]",     "S_dcsptn1crn[c][m]",   "S_dctp[c][m][n]",  "S_dd2coa[c][m][x]",    "S_dd3coa[m][x]",   "S_ddcacoa[c][m][r][x]",    "S_ddsmsterol[c][r]", 
"S_dec24dicoa[m][x]",   "S_dec47dicoa[m][x]",   "S_decdp[c][m]",    "S_dece3coa[m][x]",     "S_dece4coa[m][x]",     "S_dectricoa[m][x]",    "S_dgdp[c][m]",     "S_dhcholestancoa[c][r][x]",    "S_dhcrm_hs[c][g]",     "S_digalside_hs[c][l]", 
"S_dlnlcgcoa[c][m][r]",     "S_dlnlcgcrn[c][m][r]",     "S_dmnoncoa[c][m][x]",  "S_dmnoncrn[c][m][x]",  "S_dmpp[c][x]",     "S_dnad[c][n]",     "S_docohexcoa[m][x]",   "S_docoscoa[c][m][r][x]",   "S_dolmanp_U[c][r]",    "S_dolp_U[c][r]", 
"S_dpcoa[c][l][m]",     "S_dudp[c][m]",     "S_dump[c][m]",     "S_dutp[c][m]",     "S_eicostetcoa[c][m][r]",   "S_eicostetcrn[c][m]",  "S_eitetcoa[m][x]",     "S_fad[c][m][r][x]",    "S_fadh2[c][m][r][x]",  "S_formcoa[c][x]", 
"S_frdp[c][r][x]",  "S_fvscoa[c][x]",   "S_g6p[c][r]",  "S_ga1_hs[c][g]",   "S_ga2_hs[c][g]",   "S_gacpail_hs[c][r]",   "S_galacglcgal14acglcgalgluside_hs[c][g]",  "S_galacglcgalgluside_hs[c][g]",    "S_galgbside_hs[c][g]",     "S_galside_hs[c][l][n]", 
"S_gcald[c][m]",    "S_gd1a_hs[c][g][n]",   "S_gdpfuc[c][g]",   "S_glac[c][r]",     "S_glu5sa[c][m]",   "S_gm1b_hs[c][g]",  "S_grdp[c][x]",     "S_guln[c][r]",     "S_HC01412[m][x]",  "S_HC01415[m][x]", 
"S_HC01434[c][m][x]",   "S_HC01668[c][m]",  "S_HC02057[c][r]",  "S_HC02110[c][r]",  "S_HC10784[c][r]",  "S_HC10856[m][x]",  "S_HC10857[m][x]",  "S_HC10858[m][x]",  "S_hdcoa[c][m]",    "S_hdd2coa[c][m][r][x]", 
"S_hexccoa[c][r][x]",   "S_hexdectecoa[m][x]",  "S_hexdicoa[c][r]",     "S_hexe3coa[m][x]",     "S_hmgcoa[c][m][x]",    "S_hpdcacoa[c][m][r]",  "S_hpdcacrn[c][m]",     "S_hpyr[c][m][x]",  "S_hx2coa[m][x]",   "S_id3acald[c][m]", 
"S_ipdp[c][x]",     "S_L2aadp6sa[c][m]",    "S_lald_L[c][m]",   "S_lneldccoa[c][m][r]",     "S_lnlccoa[c][m][r][x]",    "S_lnlncacoa[c][m][r]",     "S_lnlncacrn[c][m]",    "S_lnlncgcoa[c][m][r][x]",  "S_lnlncgcrn[c][m][r]",     "S_lvstacid[c][r]", 
"S_M00004[c][m][r]",    "S_M00006[c][m][r]",    "S_M00011[c][m]",   "S_M00012[c][m][r]",    "S_M00018[c][m][r]",    "S_M00020[c][m][r]",    "S_M00022[c][m]",   "S_M00023[c][m][r]",    "S_M00044[c][m]",   "S_M00049[c][x]", 
"S_M00054[c][m]",   "S_M00100[c][m]",   "S_M00101[c][m][r]",    "S_M00116[c][m]",   "S_M00122[c][m]",   "S_M00123[c][m][r]",    "S_M00127[c][m][r]",    "S_M00129[c][m][r]",    "S_M00172[m][x]",   "S_M00261[c][m]", 
"S_M00263[c][m]",   "S_M00342[c][m]",   "S_M00343[c][m][r]",    "S_M00702[c][m]",   "S_M00715[c][x]",   "S_M00778[c][m]",   "S_M00783[c][x]",   "S_M00790[c][m]",   "S_M00843[c][m]",   "S_M00849[m][x]", 
"S_M00873[c][m]",   "S_M00879[c][x]",   "S_M00885[m][x]",   "S_M00887[c][m]",   "S_M01075[c][r]",   "S_M01141[c][m][r][x]",     "S_M01191[c][m][r][x]",     "S_M01236[c][m][r]",    "S_M01237[c][m][r]",    "S_M01573[m][x]", 
"S_M01724[c][m][r]",    "S_M01726[c][m]",   "S_M01727[c][m]",   "S_M01729[c][m]",   "S_M01770[c][m]",   "S_M01775[c][m]",   "S_M01776[c][m]",   "S_M01777[c][m]",   "S_M02051[c][m]",   "S_M02052[c][m][r]", 
"S_M02102[c][m]",   "S_M02103[c][m]",   "S_M02107[c][m]",   "S_M02112[c][r][x]",    "S_M02611[c][m]",   "S_M02612[c][m][r]",    "S_M02616[c][m]",   "S_M02637[c][m][r]",    "S_M02638[c][m]",   "S_M02694[c][m]", 
"S_M02973[c][m]",   "S_M02976[c][m]",   "S_M03014[c][m]",   "S_M03016[c][x]",   "S_M03019[m][x]",   "S_M03022[m][x]",   "S_M03047[c][r][x]",    "S_M03050[c][m][r]",    "S_M03116[c][m]",   "S_methf[c][m]", 
"S_minohp[c][n]",   "S_nadph[c][m][r][x]",  "S_nmn[c][m][n]",   "S_nrvnccoa[c][r][x]",  "S_occoa[c][m][x]",     "S_octdececoa[c][m]",   "S_octdececrn[c][m]",   "S_octe5coa[m][x]",     "S_od2coa[c][m][x]",    "S_odecoa[c][m][r][x]", 
"S_omhdecacid[c][r]",   "S_pacald[c][m]",   "S_pail35p_hs[c][n]",   "S_pail45p_hs[c][n]",   "S_pail4p_hs[c][n]",    "S_pail5p_hs[c][n]",    "S_pan4p[c][m]",    "S_pap[c][g]",  "S_paps[c][g]",     "S_phytcoa[c][x]", 
"S_pmtcoa[c][m][r][x]",     "S_ppcoa[c][m][x]",     "S_ppmi12346p[c][n]",   "S_ppp9[c][m]",     "S_pppg9[c][m]",    "S_prgnlone[c][m][r]",  "S_pristanal[c][x]",    "S_pristcoa[c][x]",     "S_profvscoa[c][x]",    "S_ptdcacoa[c][m][r]", 
"S_ptdcacrn[c][m]",     "S_retinal_cis_13[c][r]",   "S_rsv[c][r]",  "S_rsvlac[c][r]",   "S_sbcoa[c][x]",    "S_sebcoa[c][x]",   "S_Ser_Gly_Ala_X_Gly[l][r]",    "S_Ser_Thr[g][l]",  "S_Ssq23epx[c][r]",     "S_stcoa[c][m][r][x]", 
"S_strdnccoa[c][m][r][x]",  "S_strdnccrn[c][m][r]",     "S_succoa[c][m]",   "S_tdcoa[c][m][r][x]",  "S_tetdecdicoa[m][x]",  "S_tethex3coa[c][r][x]",    "S_tetpent3coa[c][r][x]",   "S_tetpent6coa[c][r][x]",   "S_tettet6coa[c][r][x]",    "S_thcrm_hs[c][g][l]", 
"S_tmndnccoa[c][m][r][x]",  "S_tmndnccrn[c][m][r]",     "S_Tn_antigen[g][l]",   "S_ttccoa[c][r][x]",    "S_uacgam[c][g][r]",    "S_udpacgal[c][g][l]",  "S_udpgal[c][g][n][r]",     "S_vacccoa[c][m][r]",   "S_vacccrn[c][m]",  "S_xser[g][r]", 
"S_zymst[c][r]",    "S_zymstnl[c][r]",                              
                                    
*metabolites participate in the overall (intracellular and extracellular) compartments                                  
"S_10fthf[c][e][l][m]",     "S_10fthf5glu[c][e][l][m]",     "S_10fthf6glu[c][e][l][m]",     "S_10fthf7glu[c][e][l][m]",     "S_11docrtsl[c][e][m][r]",  "S_11docrtstrn[c][e][m][r]",    "S_12dhchol[c][e]",     "S_12HPET[c][e][r]",    "S_12htacr[c][e][r]",   "S_12ppd_R[c][e]", 
"S_13_cis_retn[c][e][r]",   "S_13_cis_retnglc[c][e][r]",    "S_14hmdz[c][e][r]",    "S_15HPET[c][e][n][r][x]",  "S_15kprostgf2[c][e]",  "S_1a25dhvitd2[c][e][m]",   "S_1hibup_S[c][e][r]",  "S_1hibupglu_S[c][e][r]",   "S_1hmdgluc[c][e][r]",  "S_1mncam[c][e]", 
"S_1ohmdz[c][e][r]",    "S_21hprgnlone[c][e]",  "S_24nph[c][e]",    "S_2h3mv[c][e]",    "S_2hatvacid[c][e][r]",     "S_2hatvlac[c][e][r]",  "S_2hatvlacgluc[c][e][r]",  "S_2hb[c][e]",  "S_2hibup_R[c][e][r]",  "S_2hibup_S[c][e][r]", 
"S_2hibupglu_S[c][e][r]",   "S_2hiv[c][e]",     "S_2m3hbu[c][e][m]",    "S_2mcit[c][e]",    "S_2obut[c][e][m]",     "S_2oxoadp[c][e][m]",   "S_2pg[c][e]",  "S_34dhoxmand[c][e][m]",    "S_34dhoxpeg[c][e]",    "S_34dhpe[c][e]", 
"S_34hpl[c][e][m]",     "S_34hpp[c][e]",    "S_35cgmp[c][e][g][n]",     "S_35diotyr[c][e]",     "S_35dsmv[c][e][r]",    "S_3aib[c][e][m]",  "S_3aib_D[c][e][m]",    "S_3bcrn[c][e]",    "S_3ddcrn[c][e]",   "S_3deccrn[c][e]", 
"S_3dhcdchol[c][e]",    "S_3dhchol[c][e]",  "S_3dhdchol[c][e]",     "S_3dhlchol[c][e]",     "S_3h3mglt[c][e]",  "S_3hadpac[c][e][x]",   "S_3hanthrn[c][e]",     "S_3hibup_R[c][e][r]",  "S_3hibup_S[c][e][r]",  "S_3hibupglu_S[c][e][r]", 
"S_3hivac[c][e][m]",    "S_3hlvstacid[c][e]",   "S_3hmp[c][e][m]",  "S_3hpp[c][e][m]",  "S_3hpvs[c][e][r]",     "S_3hpvstet[c][e]",     "S_3hsmvacid[c][e]",    "S_3ispvs[c][e]",   "S_3ityr_L[c][e]",  "S_3mglutac[c][e][m]", 
"S_3mhis[c][e]",    "S_3mlda[c][e]",    "S_3mob[c][e][m]",  "S_3mop[c][e][m]",  "S_3mox4hoxm[c][e][m]",     "S_3octdece1crn[c][e]",     "S_3ohacmp[c][e][r]",   "S_3ohsebac[c][e][x]",  "S_3ohsubac[c][e][x]",  "S_3pg[c][e][m]", 
"S_3tdcrn[c][e]",   "S_3uib[c][e]",     "S_4abut[c][e][l][m]",  "S_4abutn[c][e]",   "S_4hatvacid[c][e][r]",     "S_4hatvlac[c][e][r]",  "S_4hbz[c][e][m]",  "S_4hmdgluc[c][e][r]",  "S_4hpro_LT[c][e][m]",  "S_4mop[c][e][m]", 
"S_4mptnl[c][e][m]",    "S_4nph[c][e]",     "S_4nphsf[c][e]",   "S_4ohbut[c][e][m]",    "S_4ohmdz[c][e][r]",    "S_4tmeabutn[c][e]",    "S_56dhpvs[c][e]",  "S_56dthm[c][e]",   "S_56dura[c][e]",   "S_56eppvs[c][e]", 
"S_5a2opntn[c][e][x]",  "S_5adtststerone[c][e]",    "S_5adtststerones[c][e]",   "S_5aop[c][e][m]",  "S_5dhf[c][e][l][m]",   "S_5eipenc[c][e][m]",   "S_5fthf[c][e]",    "S_5g2oxpt[c][e][x]",   "S_5hoxindoa[c][e]",    "S_5htrp[c][e]", 
"S_5mta[c][e]",     "S_5mthf[c][e]",    "S_5ohfvs[c][e][r]",    "S_5ohfvsglu[c][e][r]",     "S_5ohhexa[c][e]",  "S_5thf[c][e][l][m]",   "S_6bhglz[c][e][r]",    "S_6csmvacid[c][e]",    "S_6dhf[c][e][l][m]",   "S_6epvs[c][e]", 
"S_6hlvst[c][e][r]",    "S_6hmsmvacid[c][e]",   "S_6hsmvacid[c][e]",    "S_6htststerone[c][e][r]",  "S_6melvacid[c][e][r]",     "S_6melvst[c][e][r]",   "S_6ohfvsglu[c][e][r]",     "S_6thf[c][e][l][m]",   "S_7bhglz[c][e][r]",    "S_7dhcdchol[c][e]", 
"S_7dhchol[c][e]",  "S_7dhchsterol[c][e][r]",   "S_7dhf[c][e][l][m]",   "S_7hpvs[c][e]",    "S_7klitchol[c][e]",    "S_7thf[c][e][l][m]",   "S_aact[c][e][m]",  "S_abeta_L_lysine[c][e][n]",    "S_ac[c][e][g][m][x]",  "S_acac[c][e][m][x]", 
"S_acald[c][e][m]",     "S_acetone[c][e][m]",   "S_acgal[c][e][g][l]",  "S_acgam[c][e][l]",     "S_acglu[c][e][m]",     "S_acgly[c][e][m]",     "S_ach[c][e][n]",   "S_aclys[c][e]",    "S_acmana[c][e][r]",    "S_acmp[c][e][r]", 
"S_acnacngalgbside_hs[c][e][g]",    "S_acnam[c][e][n]",     "S_acngalacglcgal14acglcgalgluside_hs[c][e][g]",    "S_acrn[c][e][x]",  "S_ade[c][e]",  "S_adn[c][e][m]",   "S_adp[c][e][g][l][m][n][r]",   "S_adpac[c][e][x]",     "S_adpman[c][e]",   "S_adpoh[c][e]", 
"S_adprib[c][e]",   "S_adrn[c][e][r]",  "S_adrnl[c][e]",    "S_aflatoxin[c][e]",    "S_ahcys[c][e][m][r]",  "S_aicar[c][e]",    "S_ak2lgchol_hs[c][e]",     "S_akg[c][e][m][x]",    "S_ala_B[c][e][m]",     "S_ala_D[c][e][x]", 
"S_ala_L[c][e][x]",     "S_aldstrn[c][e][m]",   "S_alltn[c][e]",    "S_am19cs[c][e][r]",    "S_am1csa[c][e][r]",    "S_am9csa[c][e][r]",    "S_amet[c][e][m][r]",   "S_ametam[c][e]",   "S_amp[c][e][g][m][n][r][x]",   "S_andrstandn[c][e][r]", 
"S_andrstrn[c][e][r]",  "S_antipyrene[c][e]",   "S_aprgstrn[c][e]",     "S_aqcobal[c][e]",  "S_arab_L[c][e]",   "S_arach[c][e][r]",     "S_arachd[c][e][n][r][x]",  "S_arg_D[c][e][x]",     "S_arg_L[c][e][m]",     "S_ascb_L[c][e]", 
"S_asn_L[c][e][m]",     "S_asp_D[c][e][x]",     "S_asp_L[c][e][m]",     "S_atp[c][e][g][l][m][n][r][x]",    "S_atvacid[c][e][r]",   "S_atvlac[c][e][r]",    "S_avite1[c][e]",   "S_bhb[c][e][m]",   "S_bildglcur[c][e][r]",     "S_bilglcur[c][e][r]", 
"S_bilirub[c][e][r]",   "S_biliverd[c][e]",     "S_btn[c][e]",  "S_but[c][e]",  "S_bz[c][e][r]",    "S_C01601[c][e]",   "S_C02470[c][e]",   "S_C02528[c][e][r]",    "S_C04717[c][e]",   "S_C04805[c][e][m]", 
"S_C05300[c][e][r]",    "S_C05767[c][e]",   "S_C05770[c][e]",   "S_C05957[c][e]",   "S_C06314[c][e]",   "S_C06315[c][e]",   "S_c101crn[c][e]",  "S_c10crn[c][e]",   "S_C11695[c][e]",   "S_c12dc[c][e]", 
"S_C13856[c][e]",   "S_C14768[c][e]",   "S_C14769[c][e]",   "S_C14770[c][e]",   "S_C14771[c][e]",   "S_C14825[c][e]",   "S_C14826[c][e]",   "S_c16dc[c][e]",    "S_c3dc[c][e]",     "S_c4crn[c][e][x]", 
"S_c4dc[c][e]",     "S_c6crn[c][e]",    "S_c81crn[c][e]",   "S_c8crn[c][e]",    "S_ca2[c][e]",  "S_camp[c][e][g]",  "S_caproic[c][e]",  "S_caribup_s[c][e][r]",     "S_caribupglu_S[c][e][r]",  "S_carn[c][e]", 
"S_caro[c][e]",     "S_cbasp[c][e]",    "S_cdca24g[c][e][r]",   "S_cdca3g[c][e][r]",    "S_cdp[c][e][m][n]",    "S_cdpea[c][e]",    "S_CE0074[c][e]",   "S_CE1261[c][e]",   "S_CE1273[c][e]",   "S_CE1310[c][e][m]", 
"S_CE1447[c][e]",   "S_CE1918[c][e]",   "S_CE2006[c][e]",   "S_CE2047[c][e]",   "S_CE2049[c][e]",   "S_CE2172[c][e]",   "S_CE2510[c][e][r]",    "S_CE2537[c][e]",   "S_CE2705[c][e]",   "S_CE2838[c][e]", 
"S_CE2839[c][e]",   "S_CE4877[c][e]",   "S_CE4969[c][e][m]",    "S_CE5025[c][e]",   "S_CE5026[c][e]",   "S_CE5304[c][e]",   "S_CE5629[c][e]",   "S_CE6205[c][e]",   "S_CE6247[c][e]",   "S_CE7081[c][e][r]", 
"S_CE7085[c][e]",   "S_CE7090[c][e]",   "S_CE7096[c][e]",   "S_CE7172[c][e]",   "S_cgly[c][e]",     "S_chol[c][e][n]",  "S_cholate[c][e][m][r][x]",     "S_cholp[c][e][g][l]",  "S_chsterol[c][e][g][m][r]",    "S_chsterols[c][e]", 
"S_chtn[c][e]",     "S_cit[c][e][m]",   "S_citr_L[c][e]",   "S_cl[c][e]",   "S_clpnd[c][e][r]",     "S_cmp[c][e][g][m][n][r]",  "S_co[c][e]",   "S_co2[c][e][m][r][x]",     "S_coke[c][e][r]",  "S_coprost[c][e]", 
"S_core4[e][g]",    "S_cortsn[c][e][r]",    "S_coumarin[c][e]",     "S_creat[c][e]",    "S_crm_hs[c][e][g][l][n][r]",   "S_crmp_hs[c][e]",  "S_crn[c][e][m][r][x]",     "S_crtsl[c][e][m][r]",  "S_crtstrn[c][e][m]",   "S_crvnc[c][e][r]", 
"S_crvs[c][e][r]",  "S_crvsm24[c][e][r]",   "S_csa[c][e][r]",   "S_csn[c][e]",  "S_cspg_a[e][g][l]",    "S_cspg_c[e][g]",   "S_cspg_d[e][g]",   "S_cspg_e[e][g][l]",    "S_ctp[c][e][m][n]",    "S_cys_L[c][e][m]", 
"S_cytd[c][e][m]",  "S_dad_2[c][e]",    "S_dag_hs[c][e][g][r]",     "S_dca[c][e][r]",   "S_dchac[c][e]",    "S_dcmp[c][e][m][n]",   "S_dcsptn1[c][e][r]",   "S_dcyt[c][e][m][n]",   "S_ddca[c][e][r]",  "S_ddeccrn[c][e]", 
"S_ddece1crn[c][e]",    "S_decdicrn[c][e]",     "S_deoxfvs[c][e][x]",   "S_dgchol[c][e][x]",    "S_dgmp[c][e][m]",  "S_dgsn[c][e][m]",  "S_dgtp[c][e][m][n]",   "S_dhap[c][e][m]",  "S_dhbpt[c][e]",    "S_dhcholestanate[c][e][r]", 
"S_dhdascb[c][e]",  "S_dhea[c][e][r]",  "S_dheas[c][e][r]",     "S_dhf[c][e][l][m]",    "S_din[c][e]",  "S_ditp[c][e]",     "S_dlnlcg[c][e][l][r]",     "S_dmantipyrine[c][e]",     "S_dmhptcrn[c][e][m]",  "S_doco13ac[c][e][r]", 
"S_docosac[c][e][r]",   "S_dodecanac[c][e]",    "S_dolichol_L[c][e]",   "S_dopa[c][e]",     "S_dopa3glcur[c][e]",   "S_dopa4glcur[c][e]",   "S_dopasf[c][e]",   "S_drib[c][e]",     "S_dsmsterol[c][e][r]",     "S_dspvs[c][e]", 
"S_dtdp[c][e][m][n]",   "S_dtmp[c][e][m]",  "S_dttp[c][e][m][n]",   "S_duri[c][e][m]",  "S_dxtrn[c][e]",    "S_eaflatoxin[c][e]",   "S_ebastine[c][e][r]",  "S_ebastineoh[c][e][r]",    "S_egme[c][e][r]",  "S_eic21114tr[c][e]", 
"S_eicostet[c][e][r]",  "S_eidi1114ac[c][e]",   "S_elaid[c][e][r]",     "S_elaidcrn[c][e][m]",  "S_epoxtac[c][e][r]",   "S_estradiol[c][e][r]",     "S_estriol[c][e][r]",   "S_estrone[c][e][r]",   "S_estrones[c][e][r]",  "S_etha[c][e]", 
"S_ethamp[c][e][r]",    "S_ethmalac[c][e]",     "S_etoh[c][e]",     "S_f1a[e][g][l]",   "S_fald[c][e][l]",  "S_fdp[c][e]",  "S_fe2[c][e][m]",   "S_fe3[c][e]",  "S_fmn[c][e]",  "S_fol[c][e][m]", 
"S_for[c][e][m][r]",    "S_forglu[c][e]",   "S_fru[c][e]",  "S_fuc_L[c][e][l]",     "S_fuc13galacglcgal14acglcgalgluside_hs[c][e][g]",  "S_fuc14galacglcgalgluside_hs[c][e][g]",    "S_fucacgalfucgalacglcgalgluside_hs[c][e]",     "S_fucfuc12gal14acglcgalgluside_hs[c][e][g]",   "S_fucfucfucgalacglc13galacglcgal14acglcgalgluside_hs[c][e][g]",    "S_fucfucgalacglcgalgluside_hs[c][e][g]", 
"S_fucgal14acglcgalgluside_hs[c][e][g]",    "S_fucgalfucgalacglcgalgluside_hs[c][e]",   "S_fum[c][e][m]",   "S_fvs[c][e][r][x]",    "S_g3pc[c][e]",     "S_gal[c][e][l]",   "S_galacglcgalgbside_hs[c][e][g]",  "S_galgalfucfucgalacglcgalacglcgal14acglcgalgluside_hs[c][e][g]",   "S_galgalgalthcrm_hs[c][e][g]",     "S_galgluside_hs[c][e][g][r]", 
"S_galt[c][e]",     "S_gam[c][e]",  "S_gbside_hs[c][e][g][l]",  "S_gchola[c][e]",   "S_gd3_hs[c][e][g][l][m]",  "S_gdp[c][e][g][m]",    "S_glc_D[c][e][l][r]",  "S_glc3meacp[c][e][r]",     "S_glcr[c][e]",     "S_glcur[c][e][l][r]", 
"S_gln_L[c][e][m]",     "S_glu_L[c][e][l][m]",  "S_gluside_hs[c][e][g][l][r]",  "S_glutcon[c][e][m]",   "S_glx[c][e][m][x]",    "S_gly[c][e][m][x]",    "S_glyald[c][e][m]",    "S_glyc[c][e][m]",  "S_glyc_R[c][e][m]",    "S_glyc_S[c][e]", 
"S_glyc2p[c][e]",   "S_glyc3p[c][e][m]",    "S_glyclt[c][e][m][x]",     "S_glygn2[c][e]",   "S_glz[c][e][r]",   "S_gm1_hs[c][e][g][l][n]",  "S_gmp[c][e][g][n]",    "S_gq1b_hs[c][e]",  "S_gsn[c][e]",  "S_gt1a_hs[c][e]", 
"S_gthox[c][e][m][r]",  "S_gthrd[c][e][m][r]",  "S_gtp[c][e][m]",   "S_gua[c][e]",  "S_gudac[c][e]",    "S_h[c][e][g][i][l][m][n][r][x]",   "S_h2o[c][e][g][l][m][n][r][x]",    "S_h2o2[c][e][l][m][r][x]",     "S_ha[e][l]",   "S_ha_pre1[e][l]", 
"S_HC00900[c][e][m]",   "S_HC02020[c][e][r]",   "S_HC02180[c][e][r]",   "S_HC02187[c][e]",  "S_HC02191[c][e][r]",   "S_HC02192[c][e]",  "S_HC02193[c][e]",  "S_HC02194[c][e]",  "S_HC02195[c][e]",  "S_HC02196[c][e]", 
"S_HC02197[c][e]",  "S_HC02198[c][e]",  "S_HC02202[c][e]",  "S_HC02203[c][e]",  "S_HC02204[c][e]",  "S_HC02205[c][e]",  "S_HC02206[c][e]",  "S_HC02207[c][e]",  "S_HC02208[c][e]",  "S_HC02210[c][e]", 
"S_HC02213[c][e]",  "S_HC02214[c][e]",  "S_HC02216[c][e]",  "S_HC02217[c][e][r]",   "S_HC02220[c][e]",  "S_hca24g[c][e][r]",    "S_hco3[c][e][m]",  "S_hcoumarin[c][e]",    "S_hcys_L[c][e]",   "S_hdca[c][e][l][r][x]", 
"S_hdca24g[c][e][r]",   "S_hdca6g[c][e][r]",    "S_hdcea[c][e][m][r]",  "S_hdcecrn[c][e]",  "S_hdd2crn[c][e][m]",   "S_hestratriol[c][e][l][r]",    "S_hexc[c][e][r]",  "S_hexdiac[c][e][r]",   "S_hexgly[c][e]",   "S_hgentis[c][e]", 
"S_his_L[c][e]",    "S_hista[c][e]",    "S_hmcr[c][e]",     "S_hom_L[c][e]",    "S_homoval[c][e][m]",   "S_hpdca[c][e][r]",     "S_hspg[e][g][l]",  "S_htaxol[c][e]",   "S_hxa[c][e][m][x]",    "S_hxan[c][e]", 
"S_hxcoa[c][e][m][x]",  "S_hyochol[c][e][r]",   "S_i[c][e]",    "S_ibup_R[c][e][r]",    "S_ibup_S[c][e][r]",    "S_ibupgluc[c][e][r]",  "S_icdchol[c][e]",  "S_icit[c][e][m][x]",   "S_idour[c][e][l]",     "S_idp[c][e][m]", 
"S_IL6_L_lysine[c][e][n]",  "S_ile_L[c][e]",    "S_im4ac[c][e]",    "S_imp[c][e]",  "S_ind3ac[c][e][m]",    "S_inost[c][e][r]",     "S_ins[c][e]",  "S_isochol[c][e]",  "S_isolvstacid[c][e]",  "S_itacon[c][e][m]", 
"S_itp[c][e][m]",   "S_k[c][e][g]",     "S_ksii_core2[e][g]",   "S_ksii_core4[e][g]",   "S_kynate[c][e]",   "S_L2aadp[c][e][m]",    "S_lac_D[c][e]",    "S_lac_L[c][e][m][x]",  "S_lanost[c][e][r]",    "S_lca24g[c][e][r]", 
"S_lca3g[c][e][r]",     "S_Lcyst[c][e]",    "S_Lcystin[c][e]",  "S_leu_L[c][e]",    "S_leuktrA4[c][e]",     "S_leuktrB4[c][e][m][r][x]",    "S_leuktrB4wcooh[c][e][m][r][x]",   "S_leuktrB4woh[c][e][m][r]",    "S_leuktrC4[c][e]",     "S_leuktrD4[c][e]", 
"S_leuktrE4[c][e]",     "S_leuktrF4[c][e]",     "S_lgnc[c][e][r]",  "S_Lhcystin[c][e]",     "S_Lkynr[c][e]",    "S_lneldc[c][e][r]",    "S_lneldccrn[c][e][m]",     "S_lnlc[c][e][l][r]",   "S_lnlccrn[c][e][m][x]",    "S_lnlnca[c][e][l][r]", 
"S_lnlncg[c][e][l][r]",     "S_lpchol_hs[c][e]",    "S_lstn[c][e][r]",  "S_lstnm7[c][e][r]",    "S_lthstrl[c][e][r]",   "S_lvst[c][e][r]",  "S_lys_L[c][e]",    "S_M00003[c][e][r]",    "S_M00008[c][e][r]",    "S_M00010[c][e][r]", 
"S_M00017[c][e][r]",    "S_M00019[c][e][r]",    "S_M00021[c][e][r]",    "S_M00115[c][e]",   "S_M00117[c][e][r]",    "S_M00260[c][e]",   "S_M00265[c][e]",   "S_M00315[c][e]",   "S_M00341[c][e][r]",    "S_M01197[c][e][r]", 
"S_M01207[c][e][r]",    "S_M01235[c][e][r]",    "S_M01238[c][e][r]",    "S_M01582[c][e][r]",    "S_M01870[e][g]",   "S_M01881[c][e]",   "S_M01989[c][e]",   "S_M02053[c][e][r]",    "S_M02108[c][e]",   "S_M02155[c][e][r]", 
"S_M02446[c][e]",   "S_M02447[c][e]",   "S_M02449[c][e]",   "S_M02451[c][e]",   "S_M02457[c][e][r]",    "S_M02613[c][e][r]",    "S_M02745[c][e][r]",    "S_M03045[c][e][r]",    "S_M03051[c][e][r]",    "S_M03117[c][e]", 
"S_M03131[c][e]",   "S_M03134[c][e]",   "S_M03153[c][e][r]",    "S_mag_hs[c][e]",   "S_mal_L[c][e][m][x]",  "S_malt[c][e]",     "S_malttr[c][e]",   "S_maltttr[c][e]",  "S_man[c][e][l]",   "S_mdz[c][e][r]", 
"S_meoh[c][e][l]",  "S_mepi[c][e]",     "S_met_L[c][e][m]",     "S_mev_R[c][e]",    "S_mhglz[c][e][r]",     "S_mhista[c][e]",   "S_mi1p_D[c][e]",   "S_mlthf[c][e][m]",     "S_mma[c][e]",  "S_mthgxl[c][e]", 
"S_n2m2nmasn[e][l]",    "S_n5m2masn[c][e][g]",  "S_na1[c][e][g]",   "S_nac[c][e]",  "S_nad[c][e][m][n][r][x]",  "S_nadh[c][e][m][r][x]",    "S_nadp[c][e][m][r][x]",    "S_ncam[c][e]",     "S_nfdac[c][e][r]",     "S_nfdoh[c][e][r]", 
"S_nh4[c][e][m][n][r][x]",  "S_nicrnt[c][e][n]",    "S_no[c][e]",   "S_normete_L[c][e]",    "S_nrpphr[c][e]",   "S_nrpphrsf[c][e]",     "S_nrvnc[c][e][r]",     "S_nwharg[c][e]",   "S_o2[c][e][m][n][r][x]",   "S_o2s[c][e][m]", 
"S_oaa[c][e][m][x]",    "S_oagd3_hs[c][e][g]",  "S_ocdca[c][e][r]",     "S_ocdcea[c][e][l][r]",     "S_octa[c][e]",     "S_odecrn[c][e][m][r]",     "S_oh1[c][e]",  "S_orn[c][e][m]",   "S_orn_D[c][e][x]",     "S_orot[c][e]", 
"S_orot5p[c][e]",   "S_oxa[c][e][x]",   "S_oxyp[c][e]",     "S_pa_hs[c][e][m][r]",  "S_pac[c][e][m]",   "S_paf_hs[c][e]",   "S_pail_hs[c][e][n][r]",    "S_pailar_hs[c][e]",    "S_pailpalm_hs[c][e]",  "S_pchol_hs[c][e][g][r]", 
"S_pchol2linl_hs[c][e]",    "S_pchol2ole_hs[c][e]",     "S_pchol2palm_hs[c][e]",    "S_pchol2ste_hs[c][e]",     "S_pcholar_hs[c][e]",   "S_pcholdoc_hs[c][e]",  "S_pcholeic_hs[c][e]",  "S_pcholet_hs[c][e]",   "S_pcholhep_hs[c][e]",  "S_pchollinl_hs[c][e]", 
"S_pcholmyr_hs[c][e]",  "S_pcholn15_hs[c][e]",  "S_pcholn183_hs[c][e]",     "S_pcholn1836_hs[c][e]",    "S_pcholn19_hs[c][e]",  "S_pcholn201_hs[c][e]",     "S_pcholn203_hs[c][e]",     "S_pcholn204_hs[c][e]",     "S_pcholn205_hs[c][e]",     "S_pcholn224_hs[c][e]", 
"S_pcholn225_hs[c][e]",     "S_pcholn2254_hs[c][e]",    "S_pcholn226_hs[c][e]",     "S_pcholn24_hs[c][e]",  "S_pcholn261_hs[c][e]",     "S_pcholn28_hs[c][e]",  "S_pcholn281_hs[c][e]",     "S_pcholole_hs[c][e]",  "S_pcholpalm_hs[c][e]",     "S_pcholpalme_hs[c][e]", 
"S_pcholste_hs[c][e]",  "S_pcollg5hlys[c][e]",  "S_pcrn[c][e][x]",  "S_pe_hs[c][e][r]",     "S_pe12_hs[c][e]",  "S_pe13_hs[c][e]",  "S_pe14_hs[c][e]",  "S_pe15_hs[c][e]",  "S_pe161_hs[c][e]",     "S_pe17_hs[c][e]", 
"S_pe203_hs[c][e]",     "S_pe224_hs[c][e]",     "S_pe226_hs[c][e]",     "S_pe2linl_hs[c][e]",   "S_pear_hs[c][e]",  "S_pedh203_hs[c][e]",   "S_pelinl_hs[c][e]",    "S_peole_hs[c][e]",     "S_pep[c][e]",  "S_pepalm_hs[c][e]", 
"S_peplys[c][e]",   "S_peptide[c][e]",  "S_peste_hs[c][e]",     "S_pglyc_hs[c][e]",     "S_phe_L[c][e][m]",     "S_pheacgly[c][e][m]",  "S_pheme[c][e][m]",     "S_phlac[c][e]",    "S_phpyr[c][e]",    "S_phyt[c][e][x]", 
"S_pi[c][e][g][l][m][n][r]",    "S_pmtcrn[c][e][m]",    "S_pnto_R[c][e]",   "S_ppa[c][e][m]",   "S_ppbng[c][e]",    "S_ppi[c][e][m][n][r][x]",  "S_ppiogly[c][e][m]",   "S_prgstrn[c][e][r]",   "S_prist[c][e][x]",     "S_pro_D[c][e]", 
"S_pro_L[c][e][m]",     "S_profvs[c][e]",   "S_prostgd2[c][e]",     "S_prostge1[c][e]",     "S_prostge2[c][e][r]",  "S_prostgf2[c][e]",     "S_prostgh2[c][e][r]",  "S_prostgi2[c][e]",     "S_ps_hs[c][e]",    "S_pser_L[c][e]", 
"S_ptdca[c][e][r]",     "S_ptrc[c][e]",     "S_ptth[c][e][m]",  "S_ptvst[c][e][r]",     "S_ptvstlac[c][e][r]",  "S_ptvstm13[c][e][r]",  "S_pvs[c][e][r]",   "S_pvsgluc[c][e]",  "S_pydam[c][e]",    "S_pydx[c][e]", 
"S_pydxn[c][e]",    "S_pyr[c][e][m][x]",    "S_q10[c][e][m]",   "S_q10h2[c][e][m]",     "S_rbl_D[c][e]",    "S_retfa[c][e]",    "S_retinal[c][e][r]",   "S_retinol[c][e][r]",   "S_rib_D[c][e]",    "S_ribflv[c][e]", 
"S_Rtotal[c][e][g][l]",     "S_Rtotal2[c][e]",  "S_s2l2fn2m2masn[e][l]",    "S_s2l2n2m2m[c][e][l]",     "S_s2l2n2m2masn[e][l]",     "S_saccrp_L[c][e][m]",  "S_sbt_D[c][e]",    "S_sebacid[c][e][x]",   "S_selmeth[c][e]",  "S_ser_L[c][e][m][x]", 
"S_slfcys[c][e]",   "S_smv[c][e][r]",   "S_smvacid[c][e]",  "S_so3[c][e]",  "S_so4[c][e][l][r]",    "S_spc_hs[c][e]",   "S_sph1p[c][e][n]",     "S_sphgn[c][e][g][n]",  "S_sphings[c][e][g][l][n]",     "S_sphmyln_hs[c][e][g][l][r]", 
"S_sphmyln180241_hs[c][e]",     "S_sphmyln18114_hs[c][e]",  "S_sphmyln18115_hs[c][e]",  "S_sphmyln18116_hs[c][e]",  "S_sphmyln181161_hs[c][e]",     "S_sphmyln18117_hs[c][e]",  "S_sphmyln18118_hs[c][e]",  "S_sphmyln181181_hs[c][e]",     "S_sphmyln18120_hs[c][e]",  "S_sphmyln181201_hs[c][e]", 
"S_sphmyln18121_hs[c][e]",  "S_sphmyln18122_hs[c][e]",  "S_sphmyln181221_hs[c][e]",     "S_sphmyln18123_hs[c][e]",  "S_sphmyln1824_hs[c][e]",   "S_sphmyln1825_hs[c][e]",   "S_sphs1p[c][e][n]",    "S_spmd[c][e]",     "S_sprm[c][e]",     "S_sql[c][e][r]", 
"S_srtn[c][e]",     "S_stcrn[c][e][m][r]",  "S_strdnc[c][e][l][r]",     "S_subeac[c][e][x]",    "S_subgly[c][e]",   "S_succ[c][e][m][x]",   "S_sucsal[c][e][m]",    "S_T4hcinnm[c][e][m]",  "S_tacr[c][e][r]",  "S_tagat_D[c][e]", 
"S_tau_L_lysine[c][e][n]",  "S_taur[c][e]",     "S_taxol[c][e]",    "S_tchola[c][e]",   "S_tdchola[c][e]",  "S_tdechola[c][e]",     "S_tetdec2crn[c][e]",   "S_tetdece1crn[c][e]",  "S_tethex3[c][e][r]",   "S_tetpent3[c][e][r]", 
"S_tetpent6[c][e][r]",  "S_tettet6[c][e][r]",   "S_thbpt[c][e]",    "S_thcholstoic[c][e][m][r][x]",     "S_thf[c][e][l][m]",    "S_thm[c][e]",  "S_thmtp[c][e]",    "S_thr_L[c][e]",    "S_thym[c][e]",     "S_thymd[c][e][m]", 
"S_thyochol[c][e]",     "S_thyox_L[c][e]",  "S_tiggly[c][e][m]",    "S_tlacfvs[c][e][r]",   "S_tmlys[c][e]",    "S_tmndnc[c][e][r]",    "S_TNFA_L_lysine[c][e][n]",     "S_tre[c][e]",  "S_triodthy[c][e]",     "S_triodthysuf[c][e]", 
"S_tripvs[c][e]",   "S_trp_L[c][e]",    "S_trypta[c][e]",   "S_tststerone[c][e][r]",    "S_tststerones[c][e]",  "S_ttdca[c][e][r]",     "S_ttdcea[c][e][r]",    "S_ttdcrn[c][e][m]",    "S_txa2[c][e][r]",  "S_Tyr_ggn[c][e]", 
"S_tyr_L[c][e]",    "S_uchol[c][e]",    "S_udp[c][e][g][l][n][r]",  "S_udpglcur[c][e][g][r]",   "S_ump[c][e][g][l][n][r]",  "S_ura[c][e]",  "S_urate[c][e]",    "S_urcan[c][e]",    "S_urea[c][e][m]",  "S_uri[c][e][l]", 
"S_utp[c][e][n]",   "S_vacc[c][e][r]",  "S_val_L[c][e]",    "S_vitd3[c][e]",    "S_wharachd[c][e][r]",  "S_whhdca[c][e]",   "S_whtststerone[c][e]",     "S_xan[c][e]",  "S_xmp[c][e]",  "S_xol25oh[c][e][r]", 
"S_xol27oh[c][e][m][r]",    "S_xol7ah3[c][e]",  "S_xol7aone[c][e][m][r]",   "S_xoldiolone[c][e]",   "S_xolest_hs[c][e]",    "S_xolest2_hs[c][e]",   "S_xoltri25[c][e][r]",  "S_xoltri27[c][e][r]",  "S_xtsn[c][e]",     "S_xyl_D[c][e][l]", 
"S_xylt[c][e]",     "S_xylu_D[c][e]",   "S_xylu_L[c][e]"                            
                                    
*extra-metabolites are provided by the users, not existed in the above species and metabolites                                  
                                    
/                                   
                                    
BioCompound_NHT(biocompound) "biocompounds are not existed in HT model(CA only)"                                    
/                                   
                                    
*species participate in at least two intracellular compartments, but not included in the extracellular compartment                                  
"S_11docrtsl[c]",   "S_11docrtsl[m]",   "S_11docrtsl[r]",   "S_11docrtstrn[c]",     "S_11docrtstrn[m]",     "S_11docrtstrn[r]",     "S_3hanthrn[c]",    "S_3hmp[m]",    "S_4mptnl[c]",  "S_4mptnl[m]", 
"S_aact[c]",    "S_aact[m]",    "S_galgalfucfucgalacglcgalacglcgal14acglcgalgluside_hs[g]",     "S_acngalacglcgal14acglcgalgluside_hs[c]",  "S_acngalacglcgal14acglcgalgluside_hs[g]",  "S_acrn[c]",    "S_aldstrn[c]",     "S_aldstrn[m]",     "S_antipyrene[c]",  "S_biliverd[c]", 
"S_ca2[c]",     "S_co[c]",  "S_acrn[x]",    "S_crtsl[c]",   "S_crtsl[m]",   "S_crtsl[r]",   "S_dmantipyrine[c]",    "S_fucgal14acglcgalgluside_hs[c]",  "S_fucgal14acglcgalgluside_hs[g]",  "S_galgalfucfucgalacglcgalacglcgal14acglcgalgluside_hs[c]", 
"S_oagd3_hs[c]",    "S_oagd3_hs[g]",    "S_cortsn[r]",  "S_3ityr_L[c]",     "S_35diotyr[c]",    "S_g3pc[c]",    "S_xoltri25[r]",    "S_xoltri27[r]",    "S_selmeth[c]",     "S_xoltri25[c]", 
"S_xoltri27[c]",    "S_maltttr[c]",     "S_CE2839[c]",  "S_CE2838[c]",  "S_CE5629[c]",  "S_CE4877[c]",  "S_CE2172[c]",  "S_CE5025[c]",  "S_CE0074[c]",  "S_CE2049[c]", 
"S_C14825[c]",  "S_CE2047[c]",  "S_CE2006[c]",  "S_CE7096[c]",  "S_CE7085[c]",  "S_CE7090[c]",  "S_21hprgnlone[c]",     "S_glyc2p[c]",  "S_aclys[c]",   "S_3hmp[c]", 
"S_acgly[m]",   "S_acgly[c]",   "S_cortsn[c]",  "S_2m3hbu[m]",  "S_2m3hbu[c]",  "S_3mglutac[m]",    "S_3mglutac[c]",    "S_ethmalac[c]",    "S_dopa4glcur[c]",  "S_dopa3glcur[c]", 
"S_M01881[c]",  "S_M02446[c]",  "S_M02447[c]",  "S_M02449[c]",  "S_M02451[c]",  "S_mhglz[r]",   "S_mhglz[c]",           
"S_17ahprgnlone[c]",    "S_20ahchsterol[m]",    "S_3sala[m]",   "S_3sala[c]",   "S_acgagbside_hs[c]",   "S_acgagbside_hs[g]",   "S_acgagbside_hs[l]",   "S_acglcgalacglcgal14acglcgalgluside_hs[g]",    "S_andrstndn[r]",   "S_prgnlone[c]", 
"S_prgnlone[r]",    "S_17ahprgstrn[c]",     "S_17ahprgnlone[r]",    "S_17ahprgstrn[r]",     "S_prgnlone[m]",    "S_andrstndn[c]",   "S_omhdecacid[r]",  "S_omhdecacid[c]",  "S_acglcgalacglcgal14acglcgalgluside_hs[c]",    "S_20ahchsterol[r]", 
"S_M01075[c]",  "S_M01075[r]",                              
                                    
*species participate in the extracellular compartment, but also in other intracellular compartments                                 
"S_4mptnl[e]",  "S_acngalacglcgal14acglcgalgluside_hs[e]",  "S_aldstrn[e]",     "S_antipyrene[e]",  "S_ca2[e]",     "S_co[e]",  "S_crtsl[e]",   "S_dmantipyrine[e]",    "S_fucgal14acglcgalgluside_hs[e]",  "S_galgalfucfucgalacglcgalacglcgal14acglcgalgluside_hs[e]", 
"S_oagd3_hs[e]",    "S_xoltri25[e]",    "S_xoltri27[e]",    "S_maltttr[e]",     "S_CE2839[e]",  "S_CE2838[e]",  "S_CE0074[e]",  "S_3hanthrn[e]",    "S_g3pc[e]",    "S_acrn[e]", 
"S_21hprgnlone[e]",     "S_3hmp[e]",    "S_acgly[e]",   "S_aclys[e]",   "S_biliverd[e]",    "S_C14825[e]",  "S_cortsn[e]",  "S_glyc2p[e]",  "S_2m3hbu[e]",  "S_3mglutac[e]", 
"S_ethmalac[e]",    "S_11docrtsl[e]",   "S_11docrtstrn[e]",     "S_CE2006[e]",  "S_selmeth[e]",     "S_CE7090[e]",  "S_CE7085[e]",  "S_CE7096[e]",  "S_CE4877[e]",  "S_3ityr_L[e]", 
"S_35diotyr[e]",    "S_aact[e]",    "S_CE2049[e]",  "S_CE2047[e]",  "S_dopa4glcur[e]",  "S_dopa3glcur[e]",  "S_CE5025[e]",  "S_CE2172[e]",  "S_CE5629[e]",  "S_M02446[e]", 
"S_M02447[e]",  "S_M02449[e]",  "S_M02451[e]",  "S_M01881[e]",  "S_mhglz[e]",                   
                                    
*species participate in the extracellular compartment only, but not existed in the intrcellular compartments                                    
"S_glygn4[e]",  "S_maltpt[e]",  "S_malthx[e]",  "S_malthp[e]",  "S_CE1926[e]",  "S_CE5854[e]",  "S_CE1925[e]",  "S_CE5853[e]",  "S_pailste_hs[e]",  "S_xolest183_hs[e]", 
"S_xolest181_hs[e]",    "S_xolest204_hs[e]",                                
                                    
*species participate in a single intracellular compartment only, but not existed in the extracellular compartment                                   
"S_cmusa[c]",   "S_2aobut[m]",  "S_CE5665[c]",  "S_23dh1i56dio[c]",     "S_M02760[c]",  "S_3hibutcoa[m]",   "S_e4hglu[m]",  "S_fucfucgalacglcgalacglcgal14acglcgalgluside_hs[g]",   "S_2mp2coa[m]",     "S_galacglcgalacglcgal14acglcgalgluside_hs[g]", 
"S_4h2oglt[m]",     "S_dkmpp[c]",   "S_2kmb[c]",    "S_3hmbcoa[m]",     "S_iodine[c]",  "S_3mgcoa[m]",  "S_5mdru1p[c]",     "S_mi3p_D[c]",  "S_5mdr1p[c]",  "S_quln[c]", 
"S_HC01672[c]",     "S_HC01496[m]",     "S_CE4888[c]",  "S_CE5626[c]",  "S_CE5276[c]",  "S_CE2576[c]",  "S_CE2577[c]",  "S_CE6504[c]",  "S_CE6506[c]",  "S_C08261[c]", 
"S_CE6508[c]",  "S_ethmalcoa[c]",   "S_6hddopaqn[c]",   "S_5cysdopa[c]",    "S_M02683[c]",  "S_M02186[c]",  "S_M02490[c]",  "S_M00605[c]",  "S_M00406[c]",  "S_M02761[c]", 
"S_M00603[c]",                                  
                                    
*metabolites participate in at least two intracellular compartments, but not existed in the extracellular compartment                                   
"S_17ahprgnlone[c][r]",     "S_17ahprgstrn[c][r]",  "S_20ahchsterol[m][r]",     "S_3sala[c][m]",    "S_acgagbside_hs[c][g][l]",     "S_acglcgalacglcgal14acglcgalgluside_hs[c][g]",     "S_andrstndn[c][r]",    "S_M01075[c][r]",   "S_omhdecacid[c][r]",   "S_prgnlone[c][m][r]", 
                                    
*metabolites participate in the overall (intracellular and extracellular) compartments                                  
"S_11docrtsl[c][e][m][r]",  "S_11docrtstrn[c][e][m][r]",    "S_21hprgnlone[c][e]",  "S_2m3hbu[c][e][m]",    "S_35diotyr[c][e]",     "S_3hanthrn[c][e]",     "S_3hmp[c][e][m]",  "S_3ityr_L[c][e]",  "S_3mglutac[c][e][m]",  "S_4mptnl[c][e][m]", 
"S_aact[c][e][m]",  "S_acgly[c][e][m]",     "S_aclys[c][e]",    "S_acngalacglcgal14acglcgalgluside_hs[c][e][g]",    "S_acrn[c][e][x]",  "S_aldstrn[c][e][m]",   "S_antipyrene[c][e]",   "S_biliverd[c][e]",     "S_C14825[c][e]",   "S_ca2[c][e]", 
"S_CE0074[c][e]",   "S_CE2006[c][e]",   "S_CE2047[c][e]",   "S_CE2049[c][e]",   "S_CE2172[c][e]",   "S_CE2838[c][e]",   "S_CE2839[c][e]",   "S_CE4877[c][e]",   "S_CE5025[c][e]",   "S_CE5629[c][e]", 
"S_CE7085[c][e]",   "S_CE7090[c][e]",   "S_CE7096[c][e]",   "S_co[c][e]",   "S_cortsn[c][e][r]",    "S_crtsl[c][e][m][r]",  "S_dmantipyrine[c][e]",     "S_dopa3glcur[c][e]",   "S_dopa4glcur[c][e]",   "S_ethmalac[c][e]", 
"S_fucgal14acglcgalgluside_hs[c][e][g]",    "S_g3pc[c][e]",     "S_galgalfucfucgalacglcgalacglcgal14acglcgalgluside_hs[c][e][g]",   "S_glyc2p[c][e]",   "S_M01881[c][e]",   "S_M02446[c][e]",   "S_M02447[c][e]",   "S_M02449[c][e]",   "S_M02451[c][e]",   "S_maltttr[c][e]", 
"S_mhglz[c][e][r]",     "S_oagd3_hs[c][e][g]",  "S_selmeth[c][e]",  "S_xoltri25[c][e][r]",  "S_xoltri27[c][e][r]"                   
                                    
*extra-metabolites are provided by the users, not existed in the above species and metabolites                                  
                                    
/                                   
                                    
BioCompound_NCA(biocompound) "NCA biocompounds are not existed in CA model (HT only)"                                   
/                                   
                                    
*species participate in at least two intracellular compartments, but not included in the extracellular compartment                                  
"S_homoval[c]",     "S_3hpp[c]",    "S_3mlda[c]",   "S_4mop[c]",    "S_4mop[m]",    "S_5adtststerones[c]",  "S_acnacngalgbside_hs[c]",  "S_acnacngalgbside_hs[g]",  "S_aprgstrn[c]",    "S_cbasp[c]", 
"S_3uib[c]",    "S_3aib_D[c]",  "S_chsterols[c]",   "S_3aib_D[m]",  "S_ditp[c]",    "S_s2l2n2m2m[c]",   "S_s2l2n2m2m[l]",   "S_fuc_L[c]",   "S_fuc_L[l]",   "S_s2l2fn2m2masn[l]", 
"S_s2l2n2m2masn[l]",    "S_gt1a_hs[c]",     "S_nrpphrsf[c]",    "S_pac[c]",     "S_phpyr[c]",   "S_tre[c]",     "S_triodthysuf[c]",     "S_tststerones[c]",     "S_3hpp[m]",    "S_pac[m]", 
"S_homoval[m]",     "S_C11695[c]",  "S_avite1[c]",  "S_CE5304[c]",  "S_CE6247[c]",  "S_adpac[c]",   "S_adpac[x]",   "S_c101crn[c]",     "S_decdicrn[c]",    "S_3deccrn[c]", 
"S_ddeccrn[c]",     "S_ddece1crn[c]",   "S_dodecanac[c]",   "S_c12dc[c]",   "S_3ddcrn[c]",  "S_tetdece1crn[c]",     "S_tetdec2crn[c]",  "S_3tdcrn[c]",  "S_c16dc[c]",   "S_3octdece1crn[c]", 
"S_c3dc[c]",    "S_c4dc[c]",    "S_c6crn[c]",   "S_c81crn[c]",  "S_subeac[x]",  "S_subeac[c]",  "S_slfcys[c]",  "S_adpoh[c]",   "S_phlac[c]",   "S_sphmyln18114_hs[c]", 
"S_sphmyln18121_hs[c]",     "S_sphmyln181221_hs[c]",    "S_sphmyln18122_hs[c]",     "S_sphmyln18123_hs[c]",     "S_sphmyln180241_hs[c]",    "S_sphmyln1824_hs[c]",  "S_sphmyln1825_hs[c]",  "S_sphmyln18115_hs[c]",     "S_sphmyln181161_hs[c]",    "S_sphmyln18116_hs[c]", 
"S_sphmyln18117_hs[c]",     "S_sphmyln18118_hs[c]",     "S_sphmyln181181_hs[c]",    "S_sphmyln181201_hs[c]",    "S_sphmyln18120_hs[c]",     "S_pheacgly[m]",    "S_pheacgly[c]",    "S_ppiogly[m]",     "S_ppiogly[c]",     "S_tiggly[m]", 
"S_tiggly[c]",  "S_3hivac[m]",  "S_3hivac[c]",  "S_3hadpac[x]",     "S_3hadpac[c]",     "S_3ohsebac[x]",    "S_3ohsebac[c]",    "S_3ohsubac[x]",    "S_3ohsubac[c]",    "S_hexgly[c]", 
"S_subgly[c]",  "S_4ohbut[m]",  "S_4ohbut[c]",  "S_M03131[c]",  "S_1hmdgluc[r]",    "S_1hmdgluc[c]",    "S_2hatvlacgluc[r]",    "S_2hatvlacgluc[c]",    "S_4hmdgluc[c]",    "S_4hmdgluc[r]", 
"S_oxyp[c]",                                    
"S_arachcrn[c]",    "S_3hdcoa[m]",  "S_adpcoa[c]",  "S_3hddcoa[c]",     "S_sebcoa[x]",  "S_3m4hpga[c]",     "S_arachcrn[m]",    "S_digalside_hs[c]",    "S_digalside_hs[l]",    "S_pacald[c]", 
"S_pacald[m]",  "S_3hddcoa[m]",     "S_3htdcoa[m]",     "S_3htdcoa[x]",     "S_3m4hpga[m]",     "S_CE4990[m]",  "S_CE4990[x]",  "S_CE5944[m]",  "S_CE5944[x]",  "S_CE4988[c]", 
"S_CE4988[m]",  "S_CE4988[x]",  "S_CE2084[c]",  "S_CE2084[m]",  "S_adpcoa[x]",  "S_c6dc[x]",    "S_c10dc[x]",   "S_c10dc[c]",   "S_sebcoa[c]",  "S_3hdcoa[c]", 
"S_3htdcoa[c]",     "S_hexdicoa[c]",    "S_3octdece1coa[c]",    "S_c6dc[c]",    "S_sbcoa[c]",   "S_c8dc[c]",    "S_sbcoa[x]",   "S_hexdicoa[r]",    "S_3octdece1coa[m]",    "S_octdececoa[m]", 
"S_octdececrn[c]",  "S_octdececrn[m]",  "S_octdececoa[c]",  "S_c8dc[x]",                        
                                    
*species participate in the extracellular compartment, but also in other intracellular compartments                                 
"S_3mlda[e]",   "S_5adtststerones[e]",  "S_acnacngalgbside_hs[e]",  "S_3aib_D[e]",  "S_aprgstrn[e]",    "S_avite1[e]",  "S_fuc_L[e]",   "S_gt1a_hs[e]",     "S_nrpphrsf[e]",    "S_s2l2fn2m2masn[e]", 
"S_s2l2n2m2masn[e]",    "S_triodthysuf[e]",     "S_tststerones[e]",     "S_tre[e]",     "S_c101crn[e]",     "S_c12dc[e]",   "S_c16dc[e]",   "S_c3dc[e]",    "S_c4dc[e]",    "S_c6crn[e]", 
"S_c81crn[e]",  "S_3ddcrn[e]",  "S_ddeccrn[e]",     "S_ddece1crn[e]",   "S_3deccrn[e]",     "S_decdicrn[e]",    "S_3octdece1crn[e]",    "S_3tdcrn[e]",  "S_tetdec2crn[e]",  "S_tetdece1crn[e]", 
"S_slfcys[e]",  "S_4mop[e]",    "S_cbasp[e]",   "S_phlac[e]",   "S_3hpp[e]",    "S_3uib[e]",    "S_adpac[e]",   "S_adpoh[e]",   "S_C11695[e]",  "S_CE5304[e]", 
"S_CE6247[e]",  "S_dodecanac[e]",   "S_sphmyln180241_hs[e]",    "S_sphmyln18114_hs[e]",     "S_sphmyln18115_hs[e]",     "S_sphmyln18116_hs[e]",     "S_sphmyln181161_hs[e]",    "S_sphmyln18117_hs[e]",     "S_sphmyln18118_hs[e]",     "S_sphmyln181181_hs[e]", 
"S_sphmyln18120_hs[e]",     "S_sphmyln181201_hs[e]",    "S_sphmyln18121_hs[e]",     "S_sphmyln18122_hs[e]",     "S_sphmyln181221_hs[e]",    "S_sphmyln18123_hs[e]",     "S_sphmyln1824_hs[e]",  "S_sphmyln1825_hs[e]",  "S_subeac[e]",  "S_pac[e]", 
"S_pheacgly[e]",    "S_homoval[e]",     "S_s2l2n2m2m[e]",   "S_phpyr[e]",   "S_ppiogly[e]",     "S_tiggly[e]",  "S_3hivac[e]",  "S_3hadpac[e]",     "S_3ohsebac[e]",    "S_3ohsubac[e]", 
"S_hexgly[e]",  "S_subgly[e]",  "S_4ohbut[e]",  "S_chsterols[e]",   "S_ditp[e]",    "S_M03131[e]",  "S_1hmdgluc[e]",    "S_2hatvlacgluc[e]",    "S_4hmdgluc[e]",    "S_oxyp[e]", 
                                    
*species participate in the extracellular compartment only, but not existed in the intrcellular compartments                                    
"S_ksi[e]",     "S_ksi_deg1[e]",    "S_HC01444[e]",     "S_CE5789[e]",  "S_CE5797[e]",  "S_CE5798[e]",  "S_aracheth[e]",    "S_didecaeth[e]",   "S_diholineth[e]",  "S_docohxeth[e]", 
"S_docteteth[e]",   "S_hepdeceth[e]",   "S_hexdeceeth[e]",  "S_lineth[e]",  "S_oleth[e]",   "S_pendecaeth[e]",  "S_pmeth[e]",   "S_steeth[e]",  "S_tetdecaeth[e]",  "S_trideceth[e]", 
"S_h2co3[e]",                                   
                                    
*species participate in a single intracellular compartment only, but not existed in the extracellular compartment                                   
"S_34dhpha[c]",     "S_peamn[c]",   "S_CE4841[c]",  "S_CE5161[c]",  "S_phaccoa[m]",     "S_M00707[c]",  "S_M03008[c]",  "S_4hoxpacd[c]",    "S_4hphac[c]",  "S_3otdcoa[x]", 
"S_kdnp[c]",    "S_ivcoa[m]",   "S_3mb2coa[m]",     "S_melatn[c]",  "S_msa[m]",     "S_kdn[c]",     "S_fuc1p_L[c]",     "S_3mldz[c]",   "S_6hoxmelatn[c]",  "S_mi13p[c]", 
"S_dimp[c]",    "S_acngalgbside_hs[g]",     "S_trdrd[c]",   "S_trdox[c]",   "S_tym[c]",     "S_3mox4hpac[m]",   "S_CE2870[c]",  "S_CE2873[c]",  "S_CE2872[c]",  "S_CE2875[c]", 
"S_CE2874[c]",  "S_CE4840[c]",  "S_CE4845[c]",  "S_CE4844[c]",  "S_CE4846[c]",  "S_CE4852[c]",  "S_CE4850[c]",  "S_CE4848[c]",  "S_CE4851[c]",  "S_CE5160[c]", 
"S_CE5162[c]",  "S_CE7097[m]",  "S_c101coa[c]",     "S_decdicoa[c]",    "S_c12dccoa[c]",    "S_tetdece1coa[c]",     "S_tetdec2coa[c]",  "S_c81coa[c]",  "S_3ivcoa[m]",  "S_3hadicoa[x]", 
"S_3ohsebcoa[x]",   "S_3ohsubcoa[x]",   "S_M02491[c]",  "S_CE6246[c]",  "S_M00907[c]",  "S_M00802[c]",  "S_M00067[c]",  "S_M00852[c]",  "S_M03018[c]",  "S_M00839[c]", 
"S_M00699[c]",  "S_M03011[c]",  "S_M00871[c]",  "S_M00704[c]",  "S_M03017[c]",  "S_M00860[c]",  "S_M00085[c]",  "S_M00869[c]",  "S_M00086[c]",  "S_M03005[c]", 
"S_M00862[c]",  "S_M00712[c]",  "S_M03006[c]",  "S_atvacylgluc[r]",     "S_atvlacgluc[r]",                  
                                    
*metabolites participate in at least two intracellular compartments, but not existed in the extracellular compartment                                   
"S_3hdcoa[c][m]",   "S_3hddcoa[c][m]",  "S_3htdcoa[c][m][x]",   "S_3m4hpga[c][m]",  "S_3octdece1coa[c][m]",     "S_adpcoa[c][x]",   "S_arachcrn[c][m]",     "S_c10dc[c][x]",    "S_c6dc[c][x]",     "S_c8dc[c][x]", 
"S_CE2084[c][m]",   "S_CE4988[c][m][x]",    "S_CE4990[m][x]",   "S_CE5944[m][x]",   "S_digalside_hs[c][l]",     "S_hexdicoa[c][r]",     "S_octdececoa[c][m]",   "S_octdececrn[c][m]",   "S_pacald[c][m]",   "S_sbcoa[c][x]", 
"S_sebcoa[c][x]",                                   
                                    
*metabolites participate in the overall (intracellular and extracellular) compartments                                  
"S_1hmdgluc[c][e][r]",  "S_2hatvlacgluc[c][e][r]",  "S_3aib_D[c][e][m]",    "S_3ddcrn[c][e]",   "S_3deccrn[c][e]",  "S_3hadpac[c][e][x]",   "S_3hivac[c][e][m]",    "S_3hpp[c][e][m]",  "S_3mlda[c][e]",    "S_3octdece1crn[c][e]", 
"S_3ohsebac[c][e][x]",  "S_3ohsubac[c][e][x]",  "S_3tdcrn[c][e]",   "S_3uib[c][e]",     "S_4hmdgluc[c][e][r]",  "S_4mop[c][e][m]",  "S_4ohbut[c][e][m]",    "S_5adtststerones[c][e]",   "S_acnacngalgbside_hs[c][e][g]",    "S_adpac[c][e][x]", 
"S_adpoh[c][e]",    "S_aprgstrn[c][e]",     "S_avite1[c][e]",   "S_c101crn[c][e]",  "S_C11695[c][e]",   "S_c12dc[c][e]",    "S_c16dc[c][e]",    "S_c3dc[c][e]",     "S_c4dc[c][e]",     "S_c6crn[c][e]", 
"S_c81crn[c][e]",   "S_cbasp[c][e]",    "S_CE5304[c][e]",   "S_CE6247[c][e]",   "S_chsterols[c][e]",    "S_ddeccrn[c][e]",  "S_ddece1crn[c][e]",    "S_decdicrn[c][e]",     "S_ditp[c][e]",     "S_dodecanac[c][e]", 
"S_fuc_L[c][e][l]",     "S_gt1a_hs[c][e]",  "S_hexgly[c][e]",   "S_homoval[c][e][m]",   "S_M03131[c][e]",   "S_nrpphrsf[c][e]",     "S_oxyp[c][e]",     "S_pac[c][e][m]",   "S_pheacgly[c][e][m]",  "S_phlac[c][e]", 
"S_phpyr[c][e]",    "S_ppiogly[c][e][m]",   "S_s2l2fn2m2masn[e][l]",    "S_s2l2n2m2m[c][e][l]",     "S_s2l2n2m2masn[e][l]",     "S_slfcys[c][e]",   "S_sphmyln180241_hs[c][e]",     "S_sphmyln18114_hs[c][e]",  "S_sphmyln18115_hs[c][e]",  "S_sphmyln18116_hs[c][e]", 
"S_sphmyln181161_hs[c][e]",     "S_sphmyln18117_hs[c][e]",  "S_sphmyln18118_hs[c][e]",  "S_sphmyln181181_hs[c][e]",     "S_sphmyln18120_hs[c][e]",  "S_sphmyln181201_hs[c][e]",     "S_sphmyln18121_hs[c][e]",  "S_sphmyln18122_hs[c][e]",  "S_sphmyln181221_hs[c][e]",     "S_sphmyln18123_hs[c][e]", 
"S_sphmyln1824_hs[c][e]",   "S_sphmyln1825_hs[c][e]",   "S_subeac[c][e][x]",    "S_subgly[c][e]",   "S_tetdec2crn[c][e]",   "S_tetdece1crn[c][e]",  "S_tiggly[c][e][m]",    "S_tre[c][e]",  "S_triodthysuf[c][e]",  "S_tststerones[c][e]"
                                    
*extra-metabolites are provided by the users, not existed in the above species and metabolites                                  
                                    
/                                   
                                    
BioCompound_Class1(biocompound) "species participate in at least two intracellular compartments, but not included in the extracellular compartment"                                 
/                                   
"S_10fthf5glu[c]",  "S_10fthf5glu[l]",  "S_10fthf5glu[m]",  "S_10fthf6glu[c]",  "S_10fthf6glu[l]",  "S_10fthf6glu[m]",  "S_10fthf7glu[c]",  "S_10fthf7glu[l]",  "S_10fthf7glu[m]",  "S_10fthf[c]", 
"S_10fthf[l]",  "S_10fthf[m]",  "S_11docrtsl[c]",   "S_11docrtsl[m]",   "S_11docrtsl[r]",   "S_11docrtstrn[c]",     "S_11docrtstrn[m]",     "S_11docrtstrn[r]",     "S_h2o[c]",     "S_o2[c]", 
"S_h2o2[c]",    "S_nh4[c]",     "S_h2o[m]",     "S_o2[m]",  "S_h[m]",   "S_nadp[m]",    "S_1a25dhvitd2[m]",     "S_h[c]",   "S_1mncam[c]",  "S_atp[c]", 
"S_adp[c]",     "S_pi[c]",  "S_h[x]",   "S_nadh[x]",    "S_nad[x]",     "S_24nph[c]",   "S_pyr[c]",     "S_nadp[c]",    "S_Lcyst[c]",   "S_L2aadp[c]", 
"S_L2aadp[m]",  "S_akg[m]",     "S_akg[c]",     "S_drib[c]",    "S_nadh[c]",    "S_nad[c]",     "S_2hb[c]",     "S_2obut[c]",   "S_hco3[c]",    "S_na1[c]", 
"S_2mcit[c]",   "S_nadh[m]",    "S_nad[m]",     "S_2oxoadp[m]",     "S_co2[m]",     "S_2oxoadp[c]",     "S_34dhoxpeg[c]",   "S_amet[c]",    "S_ahcys[c]",   "S_34dhoxmand[c]", 
"S_34hpl[m]",   "S_co2[c]",     "S_34hpp[c]",   "S_hgentis[c]",     "S_35cgmp[c]",  "S_35cgmp[n]",  "S_3aib[m]",    "S_glu_L[m]",   "S_3aib[c]",    "S_sphgn[c]", 
"S_3hanthrn[c]",    "S_3hmp[m]",    "S_glu_L[c]",   "S_dopa[c]",    "S_3mob[c]",    "S_3mop[c]",    "S_3mop[m]",    "S_3mox4hoxm[c]",   "S_h2o[l]",     "S_pi[l]", 
"S_asp_L[c]",   "S_asp_L[m]",   "S_so3[c]",     "S_pyr[m]",     "S_adrnl[c]",   "S_mma[c]",     "S_nrpphr[c]",  "S_4abut[c]",   "S_4abut[m]",   "S_4hbz[m]", 
"S_4mptnl[c]",  "S_4mptnl[m]",  "S_4nphsf[c]",  "S_4nph[c]",    "S_5adtststerone[c]",   "S_5aop[c]",    "S_5aop[m]",    "S_5dhf[c]",    "S_5dhf[l]",    "S_5fthf[c]", 
"S_5htrp[c]",   "S_srtn[c]",    "S_5hoxindoa[c]",   "S_5mthf[c]",   "S_5thf[c]",    "S_5thf[l]",    "S_5thf[m]",    "S_6dhf[c]",    "S_6dhf[l]",    "S_6dhf[m]", 
"S_6htststerone[c]",    "S_6htststerone[r]",    "S_6thf[c]",    "S_6thf[l]",    "S_6thf[m]",    "S_7dhchsterol[r]",     "S_7dhchsterol[c]",     "S_7dhf[c]",    "S_7dhf[l]",    "S_7dhf[m]", 
"S_7thf[c]",    "S_7thf[l]",    "S_7thf[m]",    "S_man[c]",     "S_man[l]",     "S_galgluside_hs[c]",   "S_udp[c]",     "S_h[g]",   "S_galgluside_hs[g]",   "S_udp[g]", 
"S_aact[c]",    "S_mthgxl[c]",  "S_aact[m]",    "S_galgalfucfucgalacglcgalacglcgal14acglcgalgluside_hs[g]",     "S_sucsal[m]",  "S_xylu_L[c]",  "S_h[l]",   "S_4abut[l]",   "S_acac[c]",    "S_acac[m]", 
"S_acac[x]",    "S_acald[m]",   "S_acald[c]",   "S_atp[m]",     "S_adp[m]",     "S_pi[m]",  "S_hco3[m]",    "S_amp[m]",     "S_ppi[m]",     "S_ppa[m]", 
"S_acetone[m]",     "S_acgal[c]",   "S_itp[c]",     "S_idp[c]",     "S_acgal[g]",   "S_acgal[l]",   "S_acgam[c]",   "S_acgam[l]",   "S_ac[c]",  "S_acglu[m]", 
"S_ach[n]",     "S_ach[c]",     "S_cit[c]",     "S_oaa[c]",     "S_pep[c]",     "S_acnam[c]",   "S_acnam[n]",   "S_acngalacglcgal14acglcgalgluside_hs[c]",  "S_acngalacglcgal14acglcgalgluside_hs[g]",  "S_acmana[c]", 
"S_o2[x]",  "S_h2o2[x]",    "S_orn[c]",     "S_cit[m]",     "S_icit[m]",    "S_h2o[x]",     "S_fmn[c]",     "S_ribflv[c]",  "S_acrn[c]",    "S_amp[c]", 
"S_ppi[c]",     "S_ppa[c]",     "S_ac[m]",  "S_ac[g]",  "S_adn[c]",     "S_ins[c]",     "S_ade[c]",     "S_gtp[c]",     "S_gdp[c]",     "S_gtp[m]", 
"S_gdp[m]",     "S_ametam[c]",  "S_camp[c]",    "S_adn[m]",     "S_adpman[c]",  "S_adprib[c]",  "S_crn[c]",     "S_crn[m]",     "S_adrn[c]",    "S_fum[c]", 
"S_aicar[c]",   "S_aflatoxin[c]",   "S_cmp[c]",     "S_cdpea[c]",   "S_Rtotal2[c]",     "S_urea[m]",    "S_pa_hs[c]",   "S_glx[m]",     "S_gly[m]",     "S_pyr[x]", 
"S_ala_L[x]",   "S_glx[x]",     "S_gly[x]",     "S_ahcys[r]",   "S_mal_L[c]",   "S_mal_L[m]",   "S_akg[x]",     "S_prgstrn[c]",     "S_xol7aone[c]",    "S_xoldiolone[c]", 
"S_ala_L[c]",   "S_asn_L[c]",   "S_cys_L[c]",   "S_ala_D[c]",   "S_gln_L[c]",   "S_gly[c]",     "S_ser_L[c]",   "S_thr_L[c]",   "S_12ppd_R[c]",     "S_etoh[c]", 
"S_ind3ac[c]",  "S_ind3ac[m]",  "S_prist[c]",   "S_aldstrn[c]",     "S_aldstrn[m]",     "S_dhap[c]",    "S_arachd[c]",  "S_12HPET[c]",  "S_15HPET[c]",  "S_leuktrA4[c]", 
"S_h2o[r]",     "S_o2[r]",  "S_amet[r]",    "S_amet[m]",    "S_ahcys[m]",   "S_imp[c]",     "S_amp[x]",     "S_amp[r]",     "S_andrstrn[c]",    "S_andrstrn[r]", 
"S_antipyrene[c]",  "S_lys_L[c]",   "S_aqcobal[c]",     "S_arab_L[c]",  "S_arachd[r]",  "S_arach[c]",   "S_arg_L[m]",   "S_arg_L[c]",   "S_orn[m]",     "S_citr_L[c]", 
"S_so4[l]",     "S_Rtotal[c]",  "S_Rtotal[l]",  "S_crm_hs[l]",  "S_sphings[l]",     "S_ascb_L[c]",  "S_o2s[c]",     "S_dhdascb[c]",     "S_nh4[m]",     "S_asn_L[m]", 
"S_asp_D[c]",   "S_k[c]",   "S_asp_D[x]",   "S_oaa[m]",     "S_atp[r]",     "S_adp[r]",     "S_atp[n]",     "S_atp[x]",     "S_gbside_hs[g]",   "S_galgalgalthcrm_hs[g]", 
"S_galacglcgalgbside_hs[g]",    "S_h2o[g]",     "S_gluside_hs[g]",  "S_dgchol[x]",  "S_btn[c]",     "S_ala_B[c]",   "S_4tmeabutn[c]",   "S_succ[c]",    "S_caro[c]",    "S_retinal[c]", 
"S_glc_D[c]",   "S_bhb[m]",     "S_bhb[c]",     "S_hcys_L[c]",  "S_met_L[c]",   "S_bildglcur[c]",   "S_bildglcur[r]",   "S_bilglcur[c]",    "S_bilglcur[r]",    "S_biliverd[c]", 
"S_bilirub[c]",     "S_bilirub[r]",     "S_h[r]",   "S_h2o[n]",     "S_but[c]",     "S_bz[c]",  "S_bz[r]",  "S_nadp[r]",    "S_pmtcrn[c]",  "S_hdcecrn[c]", 
"S_hdd2crn[c]",     "S_hdd2crn[m]",     "S_stcrn[c]",   "S_odecrn[c]",  "S_odecrn[m]",  "S_co2[r]",     "S_nadh[r]",    "S_nad[r]",     "S_ca2[c]",     "S_h2o2[m]", 
"S_nh4[r]",     "S_glc_D[r]",   "S_pi[r]",  "S_ppi[r]",     "S_prostge1[c]",    "S_prostge2[c]",    "S_prostgf2[c]",    "S_inost[c]",   "S_pail_hs[c]",     "S_ctp[c]", 
"S_pa_hs[m]",   "S_ctp[m]",     "S_dag_hs[c]",  "S_pchol_hs[c]",    "S_pe_hs[c]",   "S_crm_hs[c]",  "S_crmp_hs[c]",     "S_crm_hs[g]",  "S_crm_hs[r]",  "S_gluside_hs[c]", 
"S_gluside_hs[r]",  "S_cgly[c]",    "S_chsterol[r]",    "S_xol25oh[r]",     "S_chol[c]",    "S_chol[n]",    "S_cholp[c]",   "S_cholate[c]",     "S_cholp[g]",   "S_cholp[l]", 
"S_chsterol[c]",    "S_chsterol[m]",    "S_chtn[c]",    "S_creat[c]",   "S_cl[c]",  "S_for[c]",     "S_i[c]",   "S_oxa[c]",     "S_clpnd[c]",   "S_pglyc_hs[c]", 
"S_cmp[g]",     "S_ppi[n]",     "S_ctp[n]",     "S_co2[x]",     "S_coke[r]",    "S_egme[r]",    "S_q10[m]",     "S_core4[g]",   "S_co[c]",  "S_T4hcinnm[m]", 
"S_coumarin[c]",    "S_crn[x]",     "S_pcrn[x]",    "S_pcrn[c]",    "S_acrn[x]",    "S_crtsl[c]",   "S_crtsl[m]",   "S_crtsl[r]",   "S_crtstrn[c]",     "S_crtstrn[m]", 
"S_crvnc[c]",   "S_cspg_a[l]",  "S_cspg_e[l]",  "S_crn[r]",     "S_csn[c]",     "S_cspg_a[g]",  "S_cspg_c[g]",  "S_cspg_d[g]",  "S_cspg_e[g]",  "S_q10h2[m]", 
"S_Lcystin[c]",     "S_gthrd[c]",   "S_gthox[c]",   "S_cys_L[m]",   "S_cytd[c]",    "S_uri[c]",     "S_cmp[m]",     "S_cytd[m]",    "S_nh4[n]",     "S_h[n]", 
"S_cdp[c]",     "S_dgtp[c]",    "S_cmp[n]",     "S_cdp[n]",     "S_dgtp[n]",    "S_dcmp[c]",    "S_dcmp[n]",    "S_utp[c]",     "S_udp[n]",     "S_utp[n]", 
"S_cdp[m]",     "S_adp[n]",     "S_dad_2[c]",   "S_din[c]",     "S_dag_hs[r]",  "S_nh4[x]",     "S_ala_D[x]",   "S_arg_D[x]",   "S_5g2oxpt[x]",     "S_oaa[x]", 
"S_dcmp[m]",    "S_dcyt[m]",    "S_dcyt[n]",    "S_dcsptn1[c]",     "S_dcyt[c]",    "S_duri[c]",    "S_dolichol_L[c]",  "S_dgchol[c]",  "S_dgmp[m]",    "S_dgsn[m]", 
"S_dgsn[c]",    "S_lthstrl[r]",     "S_dsmsterol[r]",   "S_dheas[c]",   "S_dheas[r]",   "S_dhea[c]",    "S_dhea[r]",    "S_dhf[c]",     "S_dhf[l]",     "S_dhf[m]", 
"S_orot[c]",    "S_56dura[c]",  "S_56dthm[c]",  "S_dhbpt[c]",   "S_thbpt[c]",   "S_mlthf[c]",   "S_lac_D[c]",   "S_dlnlcg[c]",  "S_dgtp[m]",    "S_dttp[m]", 
"S_dttp[n]",    "S_ethamp[r]",  "S_n5m2masn[g]",    "S_sprm[c]",    "S_dmantipyrine[c]",    "S_ppi[x]",     "S_dmhptcrn[c]",    "S_dmhptcrn[m]",    "S_dtdp[m]",    "S_dtdp[c]", 
"S_dttp[c]",    "S_dopasf[c]",  "S_orn_D[x]",   "S_5a2opntn[x]",    "S_3pg[c]",     "S_dtdp[n]",    "S_ura[c]",     "S_thym[c]",    "S_duri[m]",    "S_eaflatoxin[c]", 
"S_ebastineoh[c]",  "S_ebastineoh[r]",  "S_ebastine[c]",    "S_ebastine[r]",    "S_eicostet[c]",    "S_elaidcrn[c]",    "S_elaidcrn[m]",    "S_elaid[c]",   "S_estradiol[c]",   "S_estradiol[r]", 
"S_estriol[r]",     "S_estriol[c]",     "S_estrones[c]",    "S_estrone[r]",     "S_estrone[c]",     "S_ethamp[c]",  "S_etha[c]",    "S_f1a[g]",     "S_f1a[l]",     "S_gdp[g]", 
"S_ddca[c]",    "S_ttdca[c]",   "S_ttdcea[c]",  "S_hdca[c]",    "S_hdcea[c]",   "S_ocdca[c]",   "S_ocdcea[c]",  "S_lnlc[c]",    "S_lneldc[c]",  "S_ptdca[c]", 
"S_hpdca[c]",   "S_vacc[c]",    "S_lnlncg[c]",  "S_lnlnca[c]",  "S_strdnc[c]",  "S_tmndnc[c]",  "S_phyt[c]",    "S_lgnc[c]",    "S_nrvnc[c]",   "S_tettet6[c]", 
"S_tetpent6[c]",    "S_tetpent3[c]",    "S_tethex3[c]",     "S_hexc[c]",    "S_octa[c]",    "S_whhdca[c]",  "S_fald[c]",    "S_fald[l]",    "S_glyald[c]",  "S_fe2[m]", 
"S_pheme[m]",   "S_fe2[c]",     "S_Lkynr[c]",   "S_fol[c]",     "S_for[r]",     "S_5dhf[m]",    "S_thf[m]",     "S_fru[c]",     "S_thf[c]",     "S_fuc13galacglcgal14acglcgalgluside_hs[c]", 
"S_fuc13galacglcgal14acglcgalgluside_hs[g]",    "S_fuc14galacglcgalgluside_hs[c]",  "S_fuc14galacglcgalgluside_hs[g]",  "S_fucacgalfucgalacglcgalgluside_hs[c]",    "S_fucfuc12gal14acglcgalgluside_hs[c]",     "S_fucfuc12gal14acglcgalgluside_hs[g]",     "S_fucfucfucgalacglc13galacglcgal14acglcgalgluside_hs[c]",  "S_fucfucfucgalacglc13galacglcgal14acglcgalgluside_hs[g]",  "S_fucfucgalacglcgalgluside_hs[c]",     "S_fucfucgalacglcgalgluside_hs[g]", 
"S_fucgal14acglcgalgluside_hs[c]",  "S_fucgal14acglcgalgluside_hs[g]",  "S_fucgalfucgalacglcgalgluside_hs[c]",  "S_fum[m]",     "S_so4[c]",     "S_glyc3p[c]",  "S_gudac[c]",   "S_galacglcgalgbside_hs[c]",    "S_gal[l]",     "S_galgalfucfucgalacglcgalacglcgal14acglcgalgluside_hs[c]", 
"S_galgalgalthcrm_hs[c]",   "S_gd3_hs[g]",  "S_gal[c]",     "S_galt[c]",    "S_gam[c]",     "S_oagd3_hs[c]",    "S_gd3_hs[c]",  "S_oagd3_hs[g]",    "S_n2m2nmasn[l]",   "S_glc_D[l]", 
"S_gluside_hs[l]",  "S_gbside_hs[c]",   "S_gbside_hs[l]",   "S_glyclt[m]",  "S_mlthf[m]",   "S_gchola[c]",  "S_gmp[g]",     "S_gmp[c]",     "S_glu_L[l]",   "S_thf[l]", 
"S_Tyr_ggn[c]",     "S_leuktrE4[c]",    "S_leuktrF4[c]",    "S_ser_L[m]",   "S_glcr[c]",    "S_glygn2[c]",  "S_glcur[l]",   "S_ha[l]",  "S_ha_pre1[l]",     "S_udpglcur[g]", 
"S_ump[c]",     "S_glcur[c]",   "S_glcur[r]",   "S_dxtrn[c]",   "S_gln_L[m]",   "S_forglu[c]",  "S_glx[c]",     "S_glyc3p[m]",  "S_2pg[c]",     "S_glyc_R[c]", 
"S_glyclt[c]",  "S_glyclt[x]",  "S_glyc_S[c]",  "S_glyc[c]",    "S_glyc[m]",    "S_gthrd[m]",   "S_gmp[n]",     "S_hdca[r]",    "S_gq1b_hs[c]",     "S_gsn[c]", 
"S_gthox[m]",   "S_gthrd[r]",   "S_gua[c]",     "S_xan[c]",     "S_pe_hs[r]",   "S_h2o2[l]",    "S_udpglcur[c]",    "S_hcoumarin[c]",   "S_hestratriol[c]",     "S_his_L[c]", 
"S_hista[c]",   "S_hom_L[c]",   "S_pheme[c]",   "S_cortsn[r]",  "S_tststerone[r]",  "S_nadp[x]",    "S_andrstandn[r]",  "S_prgstrn[r]",     "S_xol7aone[r]",    "S_hspg[l]", 
"S_hspg[g]",    "S_htaxol[c]",  "S_hxan[c]",    "S_pydam[c]",   "S_taur[c]",    "S_icit[c]",    "S_icit[x]",    "S_3ityr_L[c]",     "S_35diotyr[c]",    "S_triodthy[c]", 
"S_thyox_L[c]",     "S_tyr_L[c]",   "S_idour[l]",   "S_idour[c]",   "S_ile_L[c]",   "S_itacon[m]",  "S_xylu_D[c]",  "S_tagat_D[c]",     "S_ksii_core2[g]",  "S_ksii_core4[g]", 
"S_k[g]",   "S_kynate[c]",  "S_lac_L[m]",   "S_leuktrB4[c]",    "S_leuktrB4[r]",    "S_leuktrC4[c]",    "S_leuktrD4[c]",    "S_leu_L[c]",   "S_xyl_D[l]",   "S_lac_L[c]", 
"S_lneldccrn[c]",   "S_lneldccrn[m]",   "S_lnlccrn[c]",     "S_lnlccrn[m]",     "S_lanost[c]",  "S_lanost[r]",  "S_lpchol_hs[c]",   "S_g3pc[c]",    "S_mag_hs[c]",  "S_retfa[c]", 
"S_retinol[c]",     "S_trp_L[c]",   "S_trypta[c]",  "S_malt[c]",    "S_normete_L[c]",   "S_meoh[c]",    "S_meoh[l]",    "S_mepi[c]",    "S_mi1p_D[c]",  "S_malttr[c]", 
"S_5mta[c]",    "S_nac[c]",     "S_ncam[c]",    "S_nad[n]",     "S_udp[l]",     "S_na1[g]",     "S_carn[c]",    "S_udp[r]",     "S_ump[r]",     "S_pi[g]", 
"S_ump[g]",     "S_nicrnt[c]",  "S_nicrnt[n]",  "S_nwharg[c]",  "S_no[c]",  "S_uri[l]",     "S_ump[l]",     "S_dtmp[m]",    "S_thymd[m]",   "S_xmp[c]", 
"S_o2s[m]",     "S_o2[n]",  "S_succ[m]",    "S_13_cis_retn[c]",     "S_orot5p[c]",  "S_thcholstoic[m]",     "S_xol27oh[m]",     "S_taxol[c]",   "S_wharachd[r]",    "S_leuktrB4woh[r]", 
"S_xoltri25[r]",    "S_xoltri27[r]",    "S_xol27oh[r]",     "S_leuktrB4wcooh[r]",   "S_pro_L[m]",   "S_pa_hs[r]",   "S_ak2lgchol_hs[c]",    "S_paf_hs[c]",  "S_pail_hs[n]",     "S_ptth[c]", 
"S_pchol_hs[r]",    "S_pcollg5hlys[c]",     "S_amp[g]",     "S_camp[g]",    "S_35cgmp[g]",  "S_pydxn[c]",   "S_prostgd2[c]",    "S_prostgh2[c]",    "S_prostgh2[r]",    "S_prostge2[r]", 
"S_phe_L[c]",   "S_phe_L[m]",   "S_succ[x]",    "S_pi[n]",  "S_pail_hs[r]",     "S_pnto_R[c]",  "S_prist[x]",   "S_pro_D[c]",   "S_prostgi2[c]",    "S_pro_L[c]", 
"S_ps_hs[c]",   "S_hdca[x]",    "S_phyt[x]",    "S_ptrc[c]",    "S_4abutn[c]",  "S_pydx[c]",    "S_rbl_D[c]",   "S_13_cis_retnglc[c]",  "S_13_cis_retnglc[r]",  "S_13_cis_retn[r]", 
"S_rib_D[c]",   "S_saccrp_L[m]",    "S_sbt_D[c]",   "S_selmeth[c]",     "S_ser_L[x]",   "S_sph1p[c]",   "S_sphmyln_hs[g]",  "S_sphmyln_hs[l]",  "S_sphings[c]",     "S_spc_hs[c]", 
"S_sphmyln_hs[c]",  "S_xolest_hs[c]",   "S_sphs1p[c]",  "S_spmd[c]",    "S_sql[r]",     "S_so4[r]",     "S_estrones[r]",    "S_T4hcinnm[c]",    "S_tchola[c]",  "S_tdchola[c]", 
"S_thcholstoic[x]",     "S_thymd[c]",   "S_thm[c]",     "S_thmtp[c]",   "S_tmlys[c]",   "S_q10[c]",     "S_q10h2[c]",   "S_tststerone[c]",  "S_ttdcrn[m]",  "S_ttdcrn[c]", 
"S_txa2[c]",    "S_txa2[r]",    "S_udpglcur[r]",    "S_ump[n]",     "S_urate[c]",   "S_urea[c]",    "S_val_L[c]",   "S_vitd3[c]",   "S_dhcholestanate[r]",  "S_thcholstoic[r]", 
"S_whtststerone[c]",    "S_xolest2_hs[c]",  "S_xoltri25[c]",    "S_xoltri27[c]",    "S_xylt[c]",    "S_xyl_D[c]",   "S_acmana[r]",  "S_lac_L[x]",   "S_fdp[c]",     "S_glyald[m]", 
"S_arachd[x]",  "S_3pg[m]",     "S_glyc_R[m]",  "S_lnlccrn[x]",     "S_dgmp[c]",    "S_mev_R[c]",   "S_fol[m]",     "S_HC00900[m]",     "S_cholate[r]",     "S_ptth[m]", 
"S_4hpro_LT[c]",    "S_4hpro_LT[m]",    "S_thcholstoic[c]",     "S_HC00900[c]",     "S_C02470[c]",  "S_C02528[r]",  "S_C02528[c]",  "S_dhcholestanate[c]",  "S_hxcoa[m]",   "S_xol7ah3[c]", 
"S_inost[r]",   "S_atp[l]",     "S_adp[l]",     "S_cmp[r]",     "S_hdca[l]",    "S_strdnc[l]",  "S_strdnc[r]",  "S_lnlc[l]",    "S_lnlc[r]",    "S_c8crn[c]", 
"S_met_L[m]",   "S_dtmp[c]",    "S_HC02020[r]",     "S_hdcea[r]",   "S_ocdcea[r]",  "S_ocdcea[l]",  "S_lnlnca[r]",  "S_lnlncg[r]",  "S_lnlncg[l]",  "S_lnlnca[l]", 
"S_dlnlcg[l]",  "S_dlnlcg[r]",  "S_xtsn[c]",    "S_HC02192[c]",     "S_HC02193[c]",     "S_HC02195[c]",     "S_HC02196[c]",     "S_HC02220[c]",     "S_dca[c]",     "S_HC02191[c]", 
"S_HC02194[c]",     "S_HC02197[c]",     "S_HC02198[c]",     "S_HC02187[c]",     "S_HC02180[c]",     "S_wharachd[c]",    "S_HC02202[c]",     "S_HC02203[c]",     "S_HC02204[c]",     "S_HC02205[c]", 
"S_HC02206[c]",     "S_HC02207[c]",     "S_HC02208[c]",     "S_HC02210[c]",     "S_HC02213[c]",     "S_HC02214[c]",     "S_HC02216[c]",     "S_HC02217[c]",     "S_c4crn[c]",   "S_docosac[c]", 
"S_CE2705[c]",  "S_maltttr[c]",     "S_CE2839[c]",  "S_CE2838[c]",  "S_atp[g]",     "S_adp[g]",     "S_CE1918[c]",  "S_xol7aone[m]",    "S_xol27oh[c]",     "S_cholate[m]", 
"S_cholate[x]",     "S_tdechola[c]",    "S_retinal[r]",     "S_CE1261[c]",  "S_CE5026[c]",  "S_CE5629[c]",  "S_retinol[r]",     "S_C13856[c]",  "S_C05957[c]",  "S_CE4877[c]", 
"S_dchac[c]",   "S_CE2172[c]",  "S_CE1310[m]",  "S_C05300[c]",  "S_C05300[r]",  "S_CE5025[c]",  "S_dsmsterol[c]",   "S_CE4969[m]",  "S_CE6205[c]",  "S_CE1273[c]", 
"S_HC02191[r]",     "S_crm_hs[n]",  "S_alltn[c]",   "S_CE0074[c]",  "S_hdcea[m]",   "S_leuktrB4[m]",    "S_leuktrB4woh[m]",     "S_leuktrB4wcooh[c]",   "S_leuktrB4wcooh[m]",   "S_leuktrB4woh[c]", 
"S_15HPET[n]",  "S_h2o2[r]",    "S_15HPET[r]",  "S_CE7172[c]",  "S_C06315[c]",  "S_C06314[c]",  "S_C05770[c]",  "S_tmndnc[r]",  "S_lthstrl[c]",     "S_tethex3[r]", 
"S_tetpent6[r]",    "S_CE2510[c]",  "S_doco13ac[c]",    "S_C14826[c]",  "S_CE2049[c]",  "S_C14825[c]",  "S_CE2047[c]",  "S_C14768[c]",  "S_C14770[c]",  "S_C14769[c]", 
"S_C14771[c]",  "S_C04717[c]",  "S_C01601[c]",  "S_CE2006[c]",  "S_C04805[c]",  "S_CE7096[c]",  "S_C04805[m]",  "S_CE7085[c]",  "S_CE7081[r]",  "S_CE7090[c]", 
"S_leuktrB4wcooh[x]",   "S_CE2537[c]",  "S_urcan[c]",   "S_C05767[c]",  "S_3bcrn[c]",   "S_c10crn[c]",  "S_c4crn[x]",   "S_hxcoa[c]",   "S_hxcoa[x]",   "S_dca[r]", 
"S_docosac[r]",     "S_hexdiac[c]",     "S_sebacid[c]",     "S_oh1[c]",     "S_dhap[m]",    "S_mal_L[x]",   "S_15kprostgf2[c]",     "S_21hprgnlone[c]",     "S_3mhis[c]",   "S_hmcr[c]", 
"S_peole_hs[c]",    "S_pepalm_hs[c]",   "S_pailpalm_hs[c]",     "S_pe2linl_hs[c]",  "S_pchol2palm_hs[c]",   "S_pear_hs[c]",     "S_pe203_hs[c]",    "S_pe226_hs[c]",    "S_pe224_hs[c]",    "S_pedh203_hs[c]", 
"S_pe12_hs[c]",     "S_pe14_hs[c]",     "S_pe161_hs[c]",    "S_pe13_hs[c]",     "S_pe15_hs[c]",     "S_pe17_hs[c]",     "S_pailar_hs[c]",   "S_pcholn261_hs[c]",    "S_pcholn281_hs[c]",    "S_pcholn28_hs[c]", 
"S_pelinl_hs[c]",   "S_eidi1114ac[c]",  "S_hxa[c]",     "S_glyc2p[c]",  "S_aclys[c]",   "S_34hpl[c]",   "S_3hmp[c]",    "S_acglu[c]",   "S_acgly[m]",   "S_acgly[c]", 
"S_cortsn[c]",  "S_hxa[m]",     "S_hxa[x]",     "S_pser_L[c]",  "S_saccrp_L[c]",    "S_7klitchol[c]",   "S_Lhcystin[c]",    "S_ppbng[c]",   "S_im4ac[c]",   "S_2h3mv[c]", 
"S_2hiv[c]",    "S_2m3hbu[m]",  "S_2m3hbu[c]",  "S_3h3mglt[c]",     "S_3mglutac[m]",    "S_3mglutac[c]",    "S_glutcon[m]",     "S_glutcon[c]",     "S_caproic[c]",     "S_5ohhexa[c]", 
"S_ethmalac[c]",    "S_peste_hs[c]",    "S_eic21114tr[c]",  "S_5eipenc[m]",     "S_5eipenc[c]",     "S_andrstandn[c]",  "S_CE1447[c]",  "S_CE4969[c]",  "S_CE1310[c]",  "S_4hbz[c]", 
"S_sucsal[c]",  "S_CE7081[c]",  "S_egme[c]",    "S_sql[c]",     "S_orn_D[c]",   "S_5g2oxpt[c]",     "S_HC02020[c]",     "S_xol25oh[c]",     "S_coke[c]",    "S_5a2opntn[c]", 
"S_arg_D[c]",   "S_dopa4glcur[c]",  "S_dopa3glcur[c]",  "S_34dhpe[c]",  "S_Rtotal[g]",  "S_sphings[g]",     "S_sphgn[g]",   "S_gm1_hs[l]",  "S_gd3_hs[l]",  "S_gm1_hs[c]", 
"S_gm1_hs[n]",  "S_sphings[n]",     "S_sphs1p[n]",  "S_sphgn[n]",   "S_sph1p[n]",   "S_15HPET[x]",  "S_M03134[c]",  "S_M02108[c]",  "S_M03117[c]",  "S_M03051[c]", 
"S_M00117[c]",  "S_M02745[c]",  "S_M01197[c]",  "S_M00003[c]",  "S_M01238[c]",  "S_M00019[c]",  "S_M00115[c]",  "S_M02613[c]",  "S_M00017[c]",  "S_M01235[c]", 
"S_M01207[c]",  "S_M02457[c]",  "S_M02053[c]",  "S_M01582[c]",  "S_M03045[c]",  "S_M03153[c]",  "S_M00010[c]",  "S_M00341[c]",  "S_M00260[c]",  "S_M00315[c]", 
"S_M00008[c]",  "S_M00021[c]",  "S_M00265[c]",  "S_sphmyln_hs[r]",  "S_galgluside_hs[r]",   "S_M01881[c]",  "S_arachd[n]",  "S_12HPET[r]",  "S_gthox[r]",   "S_HC02217[r]", 
"S_HC02180[r]",     "S_M01989[c]",  "S_M02155[c]",  "S_hestratriol[l]",     "S_stcrn[r]",   "S_odecrn[r]",  "S_ddca[r]",    "S_M03051[r]",  "S_ttdca[r]",   "S_M02745[r]", 
"S_ttdcea[r]",  "S_M00117[r]",  "S_ptdca[r]",   "S_M01197[r]",  "S_hpdca[r]",   "S_M00003[r]",  "S_M01238[r]",  "S_elaid[r]",   "S_M00019[r]",  "S_vacc[r]", 
"S_lneldc[r]",  "S_M02613[r]",  "S_arach[r]",   "S_CE2510[r]",  "S_M00017[r]",  "S_M01235[r]",  "S_M01207[r]",  "S_M02457[r]",  "S_M02053[r]",  "S_doco13ac[r]", 
"S_M01582[r]",  "S_M03045[r]",  "S_lgnc[r]",    "S_nrvnc[r]",   "S_hexc[r]",    "S_M03153[r]",  "S_eicostet[r]",    "S_clpnd[r]",   "S_tetpent3[r]",    "S_crvnc[r]", 
"S_M00010[r]",  "S_M00341[r]",  "S_adrn[r]",    "S_tettet6[r]",     "S_dcsptn1[r]",     "S_M00008[r]",  "S_M00021[r]",  "S_ac[x]",  "S_amp[n]",     "S_ocdca[r]", 
"S_peplys[c]",  "S_M01870[g]",  "S_M02446[c]",  "S_M02447[c]",  "S_M02449[c]",  "S_M02451[c]",  "S_itacon[c]",  "S_n5m2masn[c]",    "S_12dhchol[c]",    "S_3dhchol[c]", 
"S_3dhcdchol[c]",   "S_3dhdchol[c]",    "S_3dhlchol[c]",    "S_7dhcdchol[c]",   "S_7dhchol[c]",     "S_cdca24g[c]",     "S_cdca24g[r]",     "S_cdca3g[c]",  "S_cdca3g[r]",  "S_hyochol[c]", 
"S_coprost[c]",     "S_hca24g[c]",  "S_hdca24g[c]",     "S_hdca6g[c]",  "S_icdchol[c]",     "S_isochol[c]",     "S_lca24g[c]",  "S_lca3g[c]",   "S_thyochol[c]",    "S_uchol[c]", 
"S_hyochol[r]",     "S_hca24g[r]",  "S_M02155[r]",  "S_hdca24g[r]",     "S_hdca6g[r]",  "S_lca24g[r]",  "S_lca3g[r]",   "S_tacr[r]",    "S_12htacr[r]",     "S_12htacr[c]", 
"S_4ohmdz[r]",  "S_14hmdz[r]",  "S_1ohmdz[r]",  "S_14hmdz[c]",  "S_1hibupglu_S[c]",     "S_1hibup_S[r]",    "S_1hibupglu_S[r]",     "S_1hibup_S[c]",    "S_mdz[r]",     "S_1ohmdz[c]", 
"S_2hatvacid[c]",   "S_2hatvlac[c]",    "S_2hatvacid[r]",   "S_atvacid[r]",     "S_atvlac[r]",  "S_2hibupglu_S[c]",     "S_2hibup_R[c]",    "S_2hibup_S[r]",    "S_2hibupglu_S[r]",     "S_2hibup_S[c]", 
"S_pvs[r]",     "S_smv[r]",     "S_35dsmv[r]",  "S_35dsmv[c]",  "S_3hibupglu_S[c]",     "S_3hibup_R[c]",    "S_3hibup_S[r]",    "S_3hibupglu_S[r]",     "S_3hibup_S[c]",    "S_3hlvstacid[c]", 
"S_3hpvstet[c]",    "S_3hpvs[r]",   "S_3hpvs[c]",   "S_3hsmvacid[c]",   "S_pvs[c]",     "S_3ispvs[c]",  "S_3ohacmp[c]",     "S_acmp[r]",    "S_3ohacmp[r]",     "S_glz[r]", 
"S_4hatvacid[r]",   "S_4hatvlac[c]",    "S_4hatvacid[c]",   "S_4hatvlac[r]",    "S_4ohmdz[c]",  "S_56dhpvs[c]",     "S_56eppvs[c]",     "S_5ohfvs[r]",  "S_5ohfvsglu[r]",   "S_5ohfvsglu[c]", 
"S_fvs[r]",     "S_5ohfvs[c]",  "S_6bhglz[c]",  "S_6bhglz[r]",  "S_6csmvacid[c]",   "S_6epvs[c]",   "S_6hlvst[c]",  "S_6hmsmvacid[c]",  "S_6hsmvacid[c]",   "S_6melvst[c]", 
"S_6melvacid[c]",   "S_6ohfvsglu[r]",   "S_6ohfvsglu[c]",   "S_7bhglz[c]",  "S_7bhglz[r]",  "S_7hpvs[c]",   "S_acmp[c]",    "S_am1csa[r]",  "S_am19cs[r]",  "S_am9csa[r]", 
"S_am19cs[c]",  "S_am1csa[c]",  "S_csa[r]",     "S_am9csa[c]",  "S_csa[c]",     "S_atvacid[c]",     "S_atvlac[c]",  "S_caribupglu_S[c]",    "S_caribup_s[r]",   "S_caribupglu_S[r]", 
"S_caribup_s[c]",   "S_mhglz[r]",   "S_crvsm24[r]",     "S_crvs[c]",    "S_crvs[r]",    "S_crvsm24[c]",     "S_fvs[x]",     "S_deoxfvs[x]",     "S_deoxfvs[c]",     "S_glz[c]", 
"S_dspvs[c]",   "S_epoxtac[r]",     "S_epoxtac[c]",     "S_tlacfvs[r]",     "S_fvs[c]",     "S_glc3meacp[r]",   "S_glc3meacp[c]",   "S_ibupgluc[c]",    "S_ibup_S[r]",  "S_ibupgluc[r]", 
"S_ibup_R[c]",  "S_ibup_R[r]",  "S_2hibup_R[r]",    "S_3hibup_R[r]",    "S_ibup_S[c]",  "S_isolvstacid[c]",     "S_lstn[r]",    "S_lstn[c]",    "S_lstnm7[c]",  "S_lstnm7[r]", 
"S_lvst[c]",    "S_6melvacid[r]",   "S_lvst[r]",    "S_6hlvst[r]",  "S_6melvst[r]",     "S_mdz[c]",     "S_mhglz[c]",   "S_nfdac[r]",   "S_nfdoh[r]",   "S_nfdac[c]", 
"S_nfdoh[c]",   "S_profvs[c]",  "S_ptvst[c]",   "S_ptvst[r]",   "S_ptvstlac[r]",    "S_ptvstlac[c]",    "S_ptvstm13[r]",    "S_pvsgluc[c]",     "S_smvacid[c]",     "S_smv[c]", 
"S_tacr[c]",    "S_tlacfvs[c]",     "S_tripvs[c]",  "S_ptvstm13[c]",    "S_1a25dhvitd2[c]",     "S_h[i]",   "S_itp[m]",     "S_idp[m]",     "S_peptide[c]",     "S_abeta_L_lysine[c]", 
"S_abeta_L_lysine[n]",  "S_tau_L_lysine[c]",    "S_tau_L_lysine[n]",    "S_TNFA_L_lysine[c]",   "S_TNFA_L_lysine[n]",   "S_IL6_L_lysine[c]",    "S_IL6_L_lysine[n]",    "S_homoval[c]",     "S_3hpp[c]",    "S_3mlda[c]", 
"S_3mob[m]",    "S_4mop[c]",    "S_4mop[m]",    "S_5adtststerones[c]",  "S_acetone[c]",     "S_acnacngalgbside_hs[c]",  "S_acnacngalgbside_hs[g]",  "S_aprgstrn[c]",    "S_ala_B[m]",   "S_cbasp[c]", 
"S_gm1_hs[g]",  "S_3uib[c]",    "S_3aib_D[c]",  "S_pmtcrn[m]",  "S_stcrn[m]",   "S_chsterols[c]",   "S_chsterol[g]",    "S_3aib_D[m]",  "S_ditp[c]",    "S_s2l2n2m2m[c]", 
"S_s2l2n2m2m[l]",   "S_fuc_L[c]",   "S_for[m]",     "S_fuc_L[l]",   "S_s2l2fn2m2masn[l]",   "S_s2l2n2m2masn[l]",    "S_oxa[x]",     "S_gt1a_hs[c]",     "S_hestratriol[r]",     "S_mhista[c]", 
"S_nrpphrsf[c]",    "S_pac[c]",     "S_pchol_hs[g]",    "S_phpyr[c]",   "S_tre[c]",     "S_triodthysuf[c]",     "S_tststerones[c]",     "S_3hpp[m]",    "S_pac[m]",     "S_34dhoxmand[m]", 
"S_homoval[m]",     "S_3mox4hoxm[m]",   "S_2obut[m]",   "S_C11695[c]",  "S_avite1[c]",  "S_leuktrB4[x]",    "S_CE5304[c]",  "S_CE6247[c]",  "S_adpac[c]",   "S_adpac[x]", 
"S_c101crn[c]",     "S_decdicrn[c]",    "S_3deccrn[c]",     "S_ddeccrn[c]",     "S_ddece1crn[c]",   "S_dodecanac[c]",   "S_c12dc[c]",   "S_3ddcrn[c]",  "S_tetdece1crn[c]",     "S_tetdec2crn[c]", 
"S_3tdcrn[c]",  "S_c16dc[c]",   "S_3octdece1crn[c]",    "S_c3dc[c]",    "S_c4dc[c]",    "S_c6crn[c]",   "S_c81crn[c]",  "S_hexdiac[r]",     "S_subeac[x]",  "S_sebacid[x]", 
"S_subeac[c]",  "S_fe3[c]",     "S_slfcys[c]",  "S_adpoh[c]",   "S_phlac[c]",   "S_sphmyln18114_hs[c]",     "S_sphmyln18121_hs[c]",     "S_sphmyln181221_hs[c]",    "S_sphmyln18122_hs[c]",     "S_sphmyln18123_hs[c]", 
"S_sphmyln180241_hs[c]",    "S_sphmyln1824_hs[c]",  "S_sphmyln1825_hs[c]",  "S_sphmyln18115_hs[c]",     "S_sphmyln181161_hs[c]",    "S_sphmyln18116_hs[c]",     "S_sphmyln18117_hs[c]",     "S_sphmyln18118_hs[c]",     "S_sphmyln181181_hs[c]",    "S_sphmyln181201_hs[c]", 
"S_sphmyln18120_hs[c]",     "S_pcholmyr_hs[c]",     "S_pcholole_hs[c]",     "S_pcholpalme_hs[c]",   "S_pcholpalm_hs[c]",    "S_pcholste_hs[c]",     "S_pchol2linl_hs[c]",   "S_pchol2ole_hs[c]",    "S_pchol2ste_hs[c]",    "S_pcholn15_hs[c]", 
"S_pcholar_hs[c]",  "S_pcholn183_hs[c]",    "S_pcholn1836_hs[c]",   "S_pcholn19_hs[c]",     "S_pcholn201_hs[c]",    "S_pcholn204_hs[c]",    "S_pcholn205_hs[c]",    "S_pcholn224_hs[c]",    "S_pcholn225_hs[c]",    "S_pcholn2254_hs[c]", 
"S_pcholn226_hs[c]",    "S_pcholn203_hs[c]",    "S_pcholn24_hs[c]",     "S_pcholdoc_hs[c]",     "S_pcholeic_hs[c]",     "S_pcholet_hs[c]",  "S_pcholhep_hs[c]",     "S_pchollinl_hs[c]",    "S_pheacgly[m]",    "S_pheacgly[c]", 
"S_ppiogly[m]",     "S_ppiogly[c]",     "S_tiggly[m]",  "S_tiggly[c]",  "S_3hivac[m]",  "S_3hivac[c]",  "S_3hadpac[x]",     "S_3hadpac[c]",     "S_3ohsebac[x]",    "S_3ohsebac[c]", 
"S_3ohsubac[x]",    "S_3ohsubac[c]",    "S_hexgly[c]",  "S_subgly[c]",  "S_4ohbut[m]",  "S_4ohbut[c]",  "S_dag_hs[g]",  "S_gd3_hs[m]",  "S_M03131[c]",  "S_1hmdgluc[r]", 
"S_1hmdgluc[c]",    "S_2hatvlac[r]",    "S_2hatvlacgluc[r]",    "S_2hatvlacgluc[c]",    "S_4hmdgluc[c]",    "S_4hmdgluc[r]",    "S_oxyp[c]",            
"S_paps[c]",    "S_4hbzcoa[m]",     "S_ppcoa[m]",   "S_pmtcoa[x]",  "S_adrncoa[x]",     "S_5HPET[c]",   "S_arachdcoa[x]",   "S_lnlncgcoa[c]",   "S_tethex3coa[c]",  "S_galacglcgal14acglcgalgluside_hs[g]", 
"S_dcholcoa[x]",    "S_hdd2coa[m]",     "S_4mzym_int2[r]",  "S_coa[l]",     "S_dgdp[c]",    "S_dcsptn1crn[c]",  "S_datp[m]",    "S_fad[c]",     "S_dcdp[m]",    "S_3hbcoa[x]", 
"S_hpdcacoa[c]",    "S_stcoa[x]",   "S_odecoa[x]",  "S_gacpail_hs[r]",  "S_glac[r]",    "S_guln[c]",    "S_hpyr[c]",    "S_17ahprgstrn[r]",     "S_minohp[n]",  "S_1p3h5c[m]", 
"S_ppmi12346p[n]",  "S_Ser_Gly_Ala_X_Gly[r]",   "S_pan4p[m]",   "S_dcholcoa[c]",    "S_CE0713[x]",  "S_CE2434[m]",  "S_dec24dicoa[x]",  "S_CE2422[m]",  "S_CE5253[c]",  "S_udpgal[r]", 
"S_CE4793[x]",  "S_strdnccoa[r]",   "S_zymstnl[c]",     "S_dec47dicoa[m]",  "S_tetdecdicoa[m]",     "S_2hexdtricoa[m]",     "S_3octdectecoa[x]",    "S_3docopencoa[x]",     "S_1a25dhvitd3[n]",     "S_methf[c]", 
"S_M00129[c]",  "S_M02612[c]",  "S_M00343[c]",  "S_44mzym[c]",  "S_zymst[c]",   "S_M03050[m]",  "S_M00004[m]",  "S_M02638[m]",  "S_CE5151[m]",  "S_M02051[c]", 
"S_M00006[m]",  "S_M00261[m]",  "S_CE4847[m]",  "S_M00004[r]",  "S_M00123[r]",  "S_M00012[r]",  "S_tetpent3coa[r]",     "S_CE2242[x]",  "S_3ohodcoa[m]",    "S_CE5152[m]", 
"S_M03014[m]",  "S_CE5157[x]",  "S_HC10856[x]",     "S_M00885[x]",  "S_3hpvscoa[x]",    "S_6hmsmv[c]",  "S_3hlvst[r]",  "S_3hpvscoa[c]",    "S_clpndcoa[x]",    "S_tethex3coa[x]", 
"S_gm1b_hs[g]",     "S_3hdcoa[m]",  "S_CE5148[c]",  "S_CE5944[x]",  "S_hexdicoa[r]",    "S_M00790[c]",  "S_M03016[c]",  "S_nadph[m]",   "S_1a25dhvitd3[m]",     "S_25hvitd2[m]", 
"S_25hvitd3[m]",    "S_25hvitd2[c]",    "S_25hvitd3[c]",    "S_nadph[c]",   "S_pap[c]",     "S_coa[m]",     "S_34dhmald[c]",    "S_2mop[m]",    "S_b2coa[m]",   "S_3hbcoa_R[m]", 
"S_coa[c]",     "S_3sala[m]",   "S_3sala[c]",   "S_coucoa[m]",  "S_accoa[m]",   "S_udpgal[c]",  "S_thcrm_hs[c]",    "S_udpgal[g]",  "S_thcrm_hs[g]",    "S_uacgam[g]", 
"S_L2aadp6sa[m]",   "S_udpacgal[g]",    "S_aacoa[m]",   "S_coa[x]",     "S_accoa[x]",   "S_aacoa[x]",   "S_occoa[x]",   "S_dcacoa[x]",  "S_ddcacoa[x]",     "S_tdcoa[x]", 
"S_3ohodcoa[x]",    "S_3ohxccoa[x]",    "S_ttccoa[x]",  "S_accoa[c]",   "S_accoa[g]",   "S_accoa[n]",   "S_acgagbside_hs[c]",   "S_acgagbside_hs[g]",   "S_acgagbside_hs[l]",   "S_acgbgbside_hs[c]", 
"S_acgbgbside_hs[g]",   "S_acgbgbside_hs[l]",   "S_fad[m]",     "S_fadh2[m]",   "S_btcoa[m]",   "S_fad[x]",     "S_fadh2[x]",   "S_cholcoads[x]",   "S_ppcoa[c]",   "S_datp[c]", 
"S_dadp[c]",    "S_adrncoa[c]",     "S_adrncrn[c]",     "S_adrncoa[m]",     "S_adrncrn[m]",     "S_cdpchol[c]",     "S_succoa[m]",  "S_lald_L[c]",  "S_id3acald[c]",    "S_id3acald[m]", 
"S_pristanal[c]",   "S_dhcholestancoa[x]",  "S_dhcholestancoa[r]",  "S_cholcoar[x]",    "S_cholcoar[r]",    "S_arachcoa[c]",    "S_arachcoa[x]",    "S_arachcoa[m]",    "S_arachdcoa[c]",   "S_galside_hs[l]", 
"S_pmtcoa[c]",  "S_hdcoa[c]",   "S_tdcoa[c]",   "S_lnlncacoa[c]",   "S_strdnccoa[c]",   "S_dlnlcgcoa[c]",   "S_tmndnccoa[c]",   "S_lnlccoa[c]",     "S_clpndcoa[c]",    "S_dcsptn1coa[c]", 
"S_c226coa[c]",     "S_stcoa[c]",   "S_odecoa[c]",  "S_lneldccoa[c]",   "S_nrvnccoa[c]",    "S_od2coa[c]",  "S_ttccoa[c]",  "S_hexccoa[c]",     "S_eicostetcoa[c]",     "S_tetpent6coa[c]", 
"S_tetpent3coa[c]",     "S_tettet6coa[c]",  "S_hdd2coa[c]",     "S_pmtcoa[m]",  "S_cbp[c]",     "S_galgbside_hs[g]",    "S_acglcgalgluside_hs[g]",  "S_galacglcgalgluside_hs[g]",   "S_acglcgal14acglcgalgluside_hs[g]",    "S_acglcgalacglcgal14acglcgalgluside_hs[g]", 
"S_cholcoa[x]",     "S_dolmanp_U[r]",   "S_dolp_U[r]",  "S_nadph[r]",   "S_44mctr[r]",  "S_44mzym[r]",  "S_hdcoa[m]",   "S_stcoa[m]",   "S_odecoa[m]",  "S_arachdcrn[c]", 
"S_arachdcoa[m]",   "S_arachdcrn[m]",   "S_c226crn[c]",     "S_c226coa[m]",     "S_c226crn[m]",     "S_4mzym_int1[r]",  "S_zymst[r]",   "S_cbl2[c]",    "S_cbl2[m]",    "S_cbp[r]", 
"S_g6p[r]",     "S_cdpdag_hs[c]",   "S_cdpdag_hs[m]",   "S_coa[n]",     "S_clpndcrn[c]",    "S_clpndcoa[m]",    "S_clpndcrn[m]",    "S_cmpacna[c]",     "S_cmpacna[g]",     "S_cmpacna[n]", 
"S_coa[g]",     "S_coa[r]",     "S_Tn_antigen[g]",  "S_core6[g]",   "S_dmnoncrn[x]",    "S_dmnoncrn[m]",    "S_Ser_Gly_Ala_X_Gly[l]",   "S_dmnoncoa[x]",    "S_ppcoa[x]",   "S_dcdp[c]", 
"S_dcdp[n]",    "S_dctp[c]",    "S_dctp[n]",    "S_datp[n]",    "S_dadp[n]",    "S_dd2coa[m]",  "S_dd3coa[m]",  "S_dcsptn1coa[x]",  "S_dcsptn1coa[m]",  "S_dcsptn1crn[m]", 
"S_decdp[c]",   "S_decdp[m]",   "S_dadp[m]",    "S_dgdp[m]",    "S_fad[r]",     "S_fadh2[r]",   "S_zymstnl[r]",     "S_chlstol[r]",     "S_ddsmsterol[r]",  "S_dhcrm_hs[c]", 
"S_fadh2[c]",   "S_dlnlcgcrn[c]",   "S_dlnlcgcoa[m]",   "S_dlnlcgcrn[m]",   "S_dctp[m]",    "S_Ser_Thr[l]",     "S_dmnoncrn[c]",    "S_dmnoncoa[c]",    "S_dmnoncoa[m]",    "S_dnad[c]", 
"S_dnad[n]",    "S_dudp[c]",    "S_dudp[m]",    "S_dutp[c]",    "S_dutp[m]",    "S_dolp_U[c]",  "S_dolmanp_U[c]",   "S_dpcoa[l]",   "S_dpcoa[c]",   "S_ipdp[c]", 
"S_frdp[c]",    "S_dump[c]",    "S_dump[m]",    "S_3hbcoa[m]",  "S_b2coa[x]",   "S_eicostetcrn[c]",     "S_eicostetcoa[m]",     "S_eicostetcrn[m]",     "S_od2coa[m]",  "S_gdpfuc[c]", 
"S_gdpfuc[g]",  "S_ptdcacoa[c]",    "S_pristcoa[c]",    "S_phytcoa[c]",     "S_occoa[c]",   "S_tdcoa[m]",   "S_ptdcacoa[m]",    "S_occoa[m]",   "S_hpdcacoa[m]",    "S_lnlccoa[m]", 
"S_lneldccoa[m]",   "S_lnlncacoa[m]",   "S_lnlncgcoa[m]",   "S_lnlncgcoa[x]",   "S_strdnccoa[m]",   "S_strdnccoa[x]",   "S_tmndnccoa[m]",   "S_tmndnccoa[x]",   "S_nrvnccoa[x]",    "S_tetpent6coa[x]", 
"S_hexccoa[x]",     "S_dcacoa[c]",  "S_ddcacoa[c]",     "S_gcald[c]",   "S_ppp9[m]",    "S_formcoa[c]",     "S_formcoa[x]",     "S_frdp[r]",    "S_glu5sa[m]",  "S_1pyr5c[m]", 
"S_g6p[c]",     "S_gacpail_hs[c]",  "S_paps[g]",    "S_pap[g]",     "S_core6[l]",   "S_Ser_Thr[g]",     "S_galside_hs[c]",  "S_xser[g]",    "S_gcald[m]",   "S_glac[c]", 
"S_uacgam[c]",  "S_guln[r]",    "S_aacoa[c]",   "S_hmgcoa[c]",  "S_hmgcoa[m]",  "S_hmgcoa[x]",  "S_pristanal[x]",   "S_hpdcacrn[c]",    "S_hpdcacrn[m]",    "S_hpyr[m]", 
"S_hpyr[x]",    "S_andrstndn[r]",   "S_nadph[x]",   "S_cholcoaone[x]",  "S_prgnlone[c]",    "S_prgnlone[r]",    "S_17ahprgnlone[c]",    "S_17ahprgstrn[c]",     "S_17ahprgnlone[r]",    "S_lald_L[m]", 
"S_lnlncacrn[c]",   "S_lnlncacrn[m]",   "S_lnlncgcrn[c]",   "S_lnlncgcrn[m]",   "S_44mctr[c]",  "S_Ssq23epx[r]",    "S_minohp[c]",  "S_udpacgal[l]",    "S_Tn_antigen[l]",  "S_nmn[m]", 
"S_nmn[n]",     "S_nmn[c]",     "S_prgnlone[m]",    "S_20ahchsterol[m]",    "S_pail45p_hs[c]",  "S_pail45p_hs[n]",  "S_pail4p_hs[c]",   "S_pail4p_hs[n]",   "S_pan4p[c]",   "S_pristcoa[x]", 
"S_phytcoa[x]",     "S_pail35p_hs[c]",  "S_pail5p_hs[c]",   "S_pail5p_hs[n]",   "S_ppmi12346p[c]",  "S_pppg9[c]",   "S_pppg9[m]",   "S_ptdcacrn[c]",    "S_ptdcacrn[m]",    "S_retinal_cis_13[c]", 
"S_strdnccrn[c]",   "S_strdnccrn[m]",   "S_tmndnccrn[c]",   "S_tmndnccrn[m]",   "S_udpacgal[c]",    "S_xser[r]",    "S_dpcoa[m]",   "S_HC01434[m]",     "S_HC01434[x]",     "S_uacgam[r]", 
"S_HC01668[m]",     "S_pmtcoa[r]",  "S_lnlccoa[r]",     "S_lnlccoa[x]",     "S_arachdcoa[r]",   "S_cholcoa[r]",     "S_L2aadp6sa[c]",   "S_1p3h5c[c]",  "S_cholcoa[c]",     "S_HC01415[m]", 
"S_ddcacoa[m]",     "S_2mop[c]",    "S_dcholcoa[r]",    "S_HC01412[m]",     "S_dd2coa[x]",  "S_dcacoa[m]",  "S_dc2coa[m]",  "S_dc2coa[x]",  "S_hx2coa[m]",  "S_HC02110[r]", 
"S_cdpchol[r]",     "S_hdd2coa[r]",     "S_stcoa[r]",   "S_odecoa[r]",  "S_lnlncgcoa[r]",   "S_btcoa[c]",   "S_dlnlcgcoa[r]",   "S_HC10856[m]",     "S_HC10857[m]",     "S_HC10858[m]", 
"S_CE2421[m]",  "S_CE0713[m]",  "S_CE2421[x]",  "S_CE2253[c]",  "S_CE2249[c]",  "S_CE2245[c]",  "S_docoscoa[c]",    "S_docoscoa[m]",    "S_docoscoa[x]",    "S_andrstndn[c]", 
"S_CE2434[x]",  "S_CE0849[m]",  "S_CE2433[m]",  "S_CE0849[x]",  "S_CE2433[x]",  "S_CE0785[m]",  "S_CE2432[m]",  "S_CE0785[x]",  "S_CE2432[x]",  "S_dece4coa[x]", 
"S_C05279[m]",  "S_CE2420[m]",  "S_C05279[x]",  "S_CE2420[x]",  "S_CE2417[m]",  "S_CE2417[x]",  "S_CE2418[m]",  "S_CE2418[x]",  "S_CE2422[x]",  "S_CE2424[m]", 
"S_CE2424[x]",  "S_CE0693[m]",  "S_CE0693[x]",  "S_C05280[m]",  "S_C05280[x]",  "S_dece4coa[m]",    "S_cholcoa[m]",     "S_dhcholestancoa[c]",  "S_retinal_cis_13[r]",  "S_C02712[m]", 
"S_ddsmsterol[c]",  "S_cholcoar[m]",    "S_C02712[c]",  "S_udpgal[n]",  "S_galside_hs[n]",  "S_C01747[l]",  "S_C01747[c]",  "S_pail35p_hs[n]",  "S_CE4795[m]",  "S_CE4795[x]", 
"S_CE5114[x]",  "S_CE4791[x]",  "S_CE2439[x]",  "S_CE2440[x]",  "S_CE2437[x]",  "S_CE2438[x]",  "S_CE2442[m]",  "S_CE2442[x]",  "S_CE2441[x]",  "S_CE5116[x]", 
"S_CE2053[m]",  "S_CE2053[r]",  "S_eicostetcoa[r]",     "S_lnlncacoa[r]",   "S_clpndcoa[r]",    "S_tmndnccoa[r]",   "S_tethex3coa[r]",  "S_adrncoa[r]",     "S_tetpent6coa[r]",     "S_CE4843[c]", 
"S_CE4843[r]",  "S_CE4847[c]",  "S_CE4854[c]",  "S_CE4855[c]",  "S_CE5151[c]",  "S_CE5151[r]",  "S_CE5155[c]",  "S_CE5155[r]",  "S_nrvnccoa[r]",    "S_cholcoads[m]", 
"S_dmpp[c]",    "S_CE5947[c]",  "S_CE0347[c]",  "S_CE0347[r]",  "S_CE5947[m]",  "S_CE5947[x]",  "S_dec24dicoa[m]",  "S_dece3coa[m]",    "S_3hbcoa_R[c]",    "S_btcoa[x]", 
"S_dece3coa[x]",    "S_dectricoa[m]",   "S_dec47dicoa[x]",  "S_dectricoa[x]",   "S_2decdicoa[m]",   "S_octe5coa[m]",    "S_2decdicoa[x]",   "S_octe5coa[x]",    "S_3decdicoa[m]",   "S_3decdicoa[x]", 
"S_dd3coa[x]",  "S_2ddecdicoa[m]",  "S_3ddecdicoa[m]",  "S_2ddecdicoa[x]",  "S_3ddecdicoa[x]",  "S_2dodtricoa[m]",  "S_2dodtricoa[x]",  "S_3dodtricoa[m]",  "S_3dodtricoa[x]",  "S_tetdecdicoa[x]", 
"S_5tedtricoa[m]",  "S_5tedtricoa[x]",  "S_2hexdtricoa[x]",     "S_4hexdtricoa[m]",     "S_hexdectecoa[m]",     "S_4hexdtricoa[x]",     "S_hexdectecoa[x]",     "S_3hexdtricoa[m]",     "S_3hexdtricoa[x]",     "S_2octdectecoa[m]", 
"S_2octdectecoa[x]",    "S_3octdectecoa[m]",    "S_eitetcoa[m]",    "S_eitetcoa[x]",    "S_2docopencoa[m]",     "S_2docopencoa[x]",     "S_docohexcoa[m]",  "S_docohexcoa[x]",  "S_3docopencoa[m]",     "S_hx2coa[x]", 
"S_hexe3coa[m]",    "S_hexe3coa[x]",    "S_omhdecacid[r]",  "S_omhdecacid[c]",  "S_1a25dhvitd3[c]",     "S_glu5sa[c]",  "S_1pyr5c[c]",  "S_ppp9[c]",    "S_grdp[c]",    "S_HC01434[c]", 
"S_HC01668[c]",     "S_dhcrm_hs[g]",    "S_thcrm_hs[l]",    "S_gd1a_hs[c]",     "S_ga1_hs[c]",  "S_ga2_hs[c]",  "S_gd1a_hs[n]",     "S_M02694[c]",  "S_M02694[m]",  "S_M02107[c]", 
"S_M02107[m]",  "S_M02616[c]",  "S_M02616[m]",  "S_M03116[c]",  "S_M03116[m]",  "S_M03050[c]",  "S_HC10784[c]",     "S_M01141[c]",  "S_M01191[c]",  "S_M00004[c]", 
"S_M01237[c]",  "S_M00020[c]",  "S_vacccoa[c]",     "S_M00127[c]",  "S_M00116[c]",  "S_M00018[c]",  "S_M01236[c]",  "S_M00123[c]",  "S_M00101[c]",  "S_M02052[c]", 
"S_M00006[c]",  "S_M03047[c]",  "S_M02112[c]",  "S_M00012[c]",  "S_M00023[c]",  "S_HC02057[c]",     "S_gm1b_hs[c]",     "S_acglcgalgluside_hs[c]",  "S_galacglcgalgluside_hs[c]",   "S_acglcgal14acglcgalgluside_hs[c]", 
"S_galacglcgal14acglcgalgluside_hs[c]",     "S_acglcgalacglcgal14acglcgalgluside_hs[c]",    "S_5HPET[m]",   "S_Ssq23epx[c]",    "S_4mzym_int1[c]",  "S_4mzym_int2[c]",  "S_HC02110[c]",     "S_chlstol[c]",     "S_cholcoar[c]",    "S_cholcoaone[m]", 
"S_20ahchsterol[r]",    "S_M01075[c]",  "S_M01075[r]",  "S_CE5253[l]",  "S_M01729[c]",  "S_M01729[m]",  "S_M02973[c]",  "S_M02973[m]",  "S_M00129[m]",  "S_M02976[c]", 
"S_M02976[m]",  "S_M01141[m]",  "S_M01191[m]",  "S_M02102[c]",  "S_M02102[m]",  "S_M02103[c]",  "S_M02103[m]",  "S_M01237[m]",  "S_M00020[m]",  "S_vacccrn[c]", 
"S_vacccrn[m]",     "S_vacccoa[m]",     "S_M00127[m]",  "S_M02638[c]",  "S_M00116[m]",  "S_M02611[c]",  "S_M02611[m]",  "S_M02612[m]",  "S_M01776[c]",  "S_M01776[m]", 
"S_M00018[m]",  "S_M01777[c]",  "S_M01777[m]",  "S_M01775[c]",  "S_M01775[m]",  "S_M01236[m]",  "S_M00122[c]",  "S_M00122[m]",  "S_M00123[m]",  "S_M00100[c]", 
"S_M00100[m]",  "S_M00101[m]",  "S_M02051[m]",  "S_M02052[m]",  "S_M01724[c]",  "S_M01724[m]",  "S_M01727[c]",  "S_M01727[m]",  "S_CE5155[m]",  "S_M01726[c]", 
"S_M01726[m]",  "S_M02637[c]",  "S_M02637[m]",  "S_M00011[c]",  "S_M00011[m]",  "S_M00012[m]",  "S_M00342[c]",  "S_M00342[m]",  "S_M00343[m]",  "S_M00261[c]", 
"S_CE4854[m]",  "S_M01770[c]",  "S_M01770[m]",  "S_CE4843[m]",  "S_M00022[c]",  "S_M00022[m]",  "S_M00023[m]",  "S_M00263[c]",  "S_M00263[m]",  "S_ddcacoa[r]", 
"S_M03050[r]",  "S_tdcoa[r]",   "S_M00129[r]",  "S_HC10784[r]",     "S_M01141[r]",  "S_ptdcacoa[r]",    "S_M01191[r]",  "S_hpdcacoa[r]",    "S_M01237[r]",  "S_M00020[r]", 
"S_vacccoa[r]",     "S_M00127[r]",  "S_lneldccoa[r]",   "S_M02612[r]",  "S_arachcoa[r]",    "S_M01236[r]",  "S_M00018[r]",  "S_M00101[r]",  "S_M02052[r]",  "S_M01724[r]", 
"S_docoscoa[r]",    "S_M00006[r]",  "S_M02637[r]",  "S_strdnccrn[r]",   "S_tmndnccrn[r]",   "S_c226coa[r]",     "S_M00343[r]",  "S_lnlncgcrn[r]",   "S_dlnlcgcrn[r]",   "S_dcsptn1coa[r]", 
"S_M00023[r]",  "S_M03047[r]",  "S_ttccoa[r]",  "S_hexccoa[r]",     "S_M02112[r]",  "S_tettet6coa[r]",  "S_M03047[x]",  "S_CE4855[x]",  "S_M02112[x]",  "S_M00049[x]", 
"S_M00783[x]",  "S_CE2245[x]",  "S_CE2249[x]",  "S_CE2253[x]",  "S_CE2246[x]",  "S_CE2250[x]",  "S_CE2243[x]",  "S_CE2247[x]",  "S_CE2251[x]",  "S_od2coa[x]", 
"S_CE2248[x]",  "S_HC01415[x]",     "S_CE2242[m]",  "S_CE2246[m]",  "S_CE2250[m]",  "S_CE2243[m]",  "S_CE2247[m]",  "S_CE2251[m]",  "S_CE2248[m]",  "S_M00044[m]", 
"S_M00778[m]",  "S_M00873[m]",  "S_M00054[m]",  "S_M00790[m]",  "S_M00887[m]",  "S_CE5154[m]",  "S_CE5153[m]",  "S_CE5150[m]",  "S_CE5148[m]",  "S_CE5144[m]", 
"S_M03019[m]",  "S_M00172[m]",  "S_M00849[m]",  "S_M03022[m]",  "S_M01573[m]",  "S_M00885[m]",  "S_M00702[m]",  "S_M00843[m]",  "S_M03016[x]",  "S_M00715[x]", 
"S_M00879[x]",  "S_CE5158[x]",  "S_CE5156[x]",  "S_CE5155[x]",  "S_CE5154[x]",  "S_CE5153[x]",  "S_CE5152[x]",  "S_CE5151[x]",  "S_CE5150[x]",  "S_CE5148[x]", 
"S_CE5144[x]",  "S_HC10857[x]",     "S_HC10858[x]",     "S_M01191[x]",  "S_M03019[x]",  "S_M00172[x]",  "S_M00849[x]",  "S_M01141[x]",  "S_M03022[x]",  "S_M01573[x]", 
"S_CE5116[m]",  "S_CE5114[m]",  "S_CE4791[m]",  "S_CE4793[m]",  "S_CE2437[m]",  "S_CE2438[m]",  "S_CE2439[m]",  "S_CE2440[m]",  "S_CE2441[m]",  "S_coucoa[c]", 
"S_4hbzcoa[c]",     "S_HC02057[r]",     "S_3hlvst[c]",  "S_3hpvscoa[m]",    "S_3hpvstetcoa[m]",     "S_3hpvstetcoa[x]",     "S_3hsmv[c]",   "S_6hsmv[r]",   "S_3hsmv[r]",   "S_3meacmp[c]", 
"S_6csmv[c]",   "S_6csmv[r]",   "S_6hlvstacid[c]",  "S_6hmsmv[r]",  "S_6hsmv[c]",   "S_3meacmp[r]",     "S_lvstacid[c]",    "S_lvstacid[r]",    "S_6hlvstacid[r]",  "S_rsv[r]", 
"S_fvscoa[x]",  "S_profvscoa[x]",   "S_profvscoa[c]",   "S_rsv[c]",     "S_rsvlac[r]",  "S_rsvlac[c]",  "S_3hpvstetcoa[c]",     "S_fvscoa[c]",  "S_3m4hpga[c]",     "S_hdd2coa[x]", 
"S_arachcrn[c]",    "S_arachcrn[m]",    "S_ga2_hs[g]",  "S_ga1_hs[g]",  "S_c226coa[x]",     "S_digalside_hs[c]",    "S_digalside_hs[l]",    "S_dmpp[x]",    "S_ipdp[x]",    "S_grdp[x]", 
"S_tettet6coa[x]",  "S_tetpent3coa[x]",     "S_frdp[x]",    "S_methf[m]",   "S_pacald[c]",  "S_gd1a_hs[g]",     "S_pacald[m]",  "S_3hddcoa[m]",     "S_3htdcoa[m]",     "S_3htdcoa[x]", 
"S_HC01412[x]",     "S_34dhmald[m]",    "S_3m4hpga[m]",     "S_CE2250[c]",  "S_CE2246[c]",  "S_CE2242[c]",  "S_3ohodcoa[c]",    "S_CE2248[c]",  "S_CE4990[m]",  "S_CE4990[x]", 
"S_CE4793[c]",  "S_CE5114[c]",  "S_CE5144[c]",  "S_CE5152[c]",  "S_CE5156[c]",  "S_CE5150[c]",  "S_CE5153[c]",  "S_CE5154[c]",  "S_CE5157[c]",  "S_CE5158[c]", 
"S_CE5944[m]",  "S_CE4988[c]",  "S_CE4988[m]",  "S_CE4988[x]",  "S_CE2084[c]",  "S_CE2084[m]",  "S_adpcoa[c]",  "S_adpcoa[x]",  "S_c6dc[x]",    "S_c10dc[x]", 
"S_c10dc[c]",   "S_sebcoa[c]",  "S_3hdcoa[c]",  "S_dd2coa[c]",  "S_3hddcoa[c]",     "S_3htdcoa[c]",     "S_hexdicoa[c]",    "S_3octdece1coa[c]",    "S_c6dc[c]",    "S_sbcoa[c]", 
"S_c8dc[c]",    "S_sebcoa[x]",  "S_sbcoa[x]",   "S_3octdece1coa[m]",    "S_octdececoa[m]",  "S_succoa[c]",  "S_octdececrn[c]",  "S_octdececrn[m]",  "S_octdececoa[c]",  "S_c8dc[x]", 
"S_galgbside_hs[c]",    "S_3ohxccoa[c]",    "S_M00783[c]",  "S_M00049[c]",  "S_M00887[c]",  "S_M00054[c]",  "S_M00873[c]",  "S_M00778[c]",  "S_M00044[c]",  "S_M00879[c]", 
"S_M00715[c]",  "S_M00843[c]",  "S_M00702[c]",  "S_M03014[c]",  "S_CE4791[c]"                   
/                                   
                                    
BioCompound_Class2(biocompound) "species participate in the extracellular compartment, but also in other intracellular compartments"                                    
/                                   
"S_1mncam[e]",  "S_24nph[e]",   "S_h[e]",   "S_2hb[e]",     "S_hco3[e]",    "S_na1[e]",     "S_2mcit[e]",   "S_34dhoxpeg[e]",   "S_4mptnl[e]",  "S_4nphsf[e]", 
"S_4nph[e]",    "S_5adtststerone[e]",   "S_h2o[e]",     "S_5fthf[e]",   "S_5htrp[e]",   "S_5mthf[e]",   "S_6htststerone[e]",    "S_4abut[e]",   "S_acetone[e]",     "S_ac[e]", 
"S_ach[e]",     "S_chol[e]",    "S_acngalacglcgal14acglcgalgluside_hs[e]",  "S_nh4[e]",     "S_adn[e]",     "S_ins[e]",     "S_ade[e]",     "S_adprib[e]",  "S_adrnl[e]",   "S_adrn[e]", 
"S_aflatoxin[e]",   "S_akg[e]",     "S_ala_L[e]",   "S_asn_L[e]",   "S_cys_L[e]",   "S_ala_D[e]",   "S_gln_L[e]",   "S_gly[e]",     "S_ser_L[e]",   "S_thr_L[e]", 
"S_aldstrn[e]",     "S_cgly[e]",    "S_glc_D[e]",   "S_glygn2[e]",  "S_andrstrn[e]",    "S_antipyrene[e]",  "S_aqcobal[e]",     "S_arab_L[e]",  "S_arachd[e]",  "S_arach[e]", 
"S_lys_L[e]",   "S_arg_L[e]",   "S_ascb_L[e]",  "S_asp_D[e]",   "S_k[e]",   "S_asp_L[e]",   "S_atp[e]",     "S_pi[e]",  "S_amp[e]",     "S_adp[e]", 
"S_ala_B[e]",   "S_bhb[e]",     "S_bildglcur[e]",   "S_bilglcur[e]",    "S_bilirub[e]",     "S_btn[e]",     "S_bz[e]",  "S_ca2[e]",     "S_caro[e]",    "S_cholate[e]", 
"S_acgam[e]",   "S_chtn[e]",    "S_cit[e]",     "S_cl[e]",  "S_for[e]",     "S_i[e]",   "S_oxa[e]",     "S_clpnd[e]",   "S_co[e]",  "S_coumarin[e]", 
"S_creat[e]",   "S_crn[e]",     "S_crtsl[e]",   "S_crtstrn[e]",     "S_crvnc[e]",   "S_csn[e]",     "S_cspg_a[e]",  "S_cspg_c[e]",  "S_cspg_d[e]",  "S_cspg_e[e]", 
"S_glu_L[e]",   "S_Lcystin[e]",     "S_cytd[e]",    "S_dad_2[e]",   "S_din[e]",     "S_dag_hs[e]",  "S_dcsptn1[e]",     "S_dcyt[e]",    "S_dgchol[e]",  "S_dgsn[e]", 
"S_dhdascb[e]",     "S_dheas[e]",   "S_dlnlcg[e]",  "S_dmantipyrine[e]",    "S_dmhptcrn[e]",    "S_dopasf[e]",  "S_dopa[e]",    "S_drib[e]",    "S_duri[e]",    "S_eaflatoxin[e]", 
"S_ebastineoh[e]",  "S_ebastine[e]",    "S_eicostet[e]",    "S_elaid[e]",   "S_estradiol[e]",   "S_estrones[e]",    "S_10fthf[e]",  "S_10fthf5glu[e]",  "S_10fthf6glu[e]",  "S_10fthf7glu[e]", 
"S_13_cis_retnglc[e]",  "S_35cgmp[e]",  "S_3aib[e]",    "S_5dhf[e]",    "S_5thf[e]",    "S_6dhf[e]",    "S_6thf[e]",    "S_7dhf[e]",    "S_7thf[e]",    "S_ak2lgchol_hs[e]", 
"S_camp[e]",    "S_chsterol[e]",    "S_cmp[e]",     "S_dhf[e]",     "S_fuc13galacglcgal14acglcgalgluside_hs[e]",    "S_fuc14galacglcgalgluside_hs[e]",  "S_fucacgalfucgalacglcgalgluside_hs[e]",    "S_fucfuc12gal14acglcgalgluside_hs[e]",     "S_fucfucfucgalacglc13galacglcgal14acglcgalgluside_hs[e]",  "S_fucfucgalacglcgalgluside_hs[e]", 
"S_fucgal14acglcgalgluside_hs[e]",  "S_fucgalfucgalacglcgalgluside_hs[e]",  "S_galacglcgalgbside_hs[e]",    "S_galgalfucfucgalacglcgalacglcgal14acglcgalgluside_hs[e]",     "S_galgalgalthcrm_hs[e]",   "S_gbside_hs[e]",   "S_gchola[e]",  "S_gdp[e]",     "S_glyc_S[e]",  "S_gmp[e]", 
"S_gq1b_hs[e]",     "S_gsn[e]",     "S_gthox[e]",   "S_gthrd[e]",   "S_gtp[e]",     "S_h2o2[e]",    "S_ha[e]",  "S_ha_pre1[e]",     "S_hcoumarin[e]",   "S_hdca[e]", 
"S_hdcea[e]",   "S_hexc[e]",    "S_hista[e]",   "S_hom_L[e]",   "S_hpdca[e]",   "S_hspg[e]",    "S_htaxol[e]",  "S_idp[e]",     "S_imp[e]",     "S_inost[e]", 
"S_ksii_core2[e]",  "S_ksii_core4[e]",  "S_leuktrA4[e]",    "S_leuktrB4[e]",    "S_leuktrC4[e]",    "S_leuktrD4[e]",    "S_leuktrE4[e]",    "S_leuktrF4[e]",    "S_lgnc[e]",    "S_lneldc[e]", 
"S_lnlc[e]",    "S_lnlnca[e]",  "S_lnlncg[e]",  "S_lpchol_hs[e]",   "S_mag_hs[e]",  "S_meoh[e]",    "S_mthgxl[e]",  "S_n2m2nmasn[e]",   "S_nad[e]",     "S_nadp[e]", 
"S_ncam[e]",    "S_no[e]",  "S_nrpphr[e]",  "S_nrvnc[e]",   "S_o2s[e]",     "S_oagd3_hs[e]",    "S_ocdca[e]",   "S_ocdcea[e]",  "S_octa[e]",    "S_paf_hs[e]", 
"S_pchol_hs[e]",    "S_pe_hs[e]",   "S_peplys[e]",  "S_pglyc_hs[e]",    "S_phyt[e]",    "S_prgstrn[e]",     "S_pro_D[e]",   "S_prostgd2[e]",    "S_prostge1[e]",    "S_prostge2[e]", 
"S_prostgf2[e]",    "S_ps_hs[e]",   "S_ptdca[e]",   "S_retfa[e]",   "S_retinol[e]",     "S_Rtotal[e]",  "S_Rtotal2[e]",     "S_spc_hs[e]",  "S_sphs1p[e]",  "S_srtn[e]", 
"S_strdnc[e]",  "S_tagat_D[e]",     "S_taxol[e]",   "S_tchola[e]",  "S_tdchola[e]",     "S_tethex3[e]",     "S_tetpent3[e]",    "S_tetpent6[e]",    "S_thf[e]",     "S_thmtp[e]", 
"S_thym[e]",    "S_thyox_L[e]",     "S_triodthy[e]",    "S_tststerone[e]",  "S_ttdca[e]",   "S_txa2[e]",    "S_Tyr_ggn[e]",     "S_udp[e]",     "S_ump[e]",     "S_urate[e]", 
"S_utp[e]",     "S_vacc[e]",    "S_vitd3[e]",   "S_whhdca[e]",  "S_whtststerone[e]",    "S_xolest_hs[e]",   "S_xolest2_hs[e]",  "S_xoltri25[e]",    "S_xoltri27[e]",    "S_xylt[e]", 
"S_fe2[e]",     "S_fe3[e]",     "S_fol[e]",     "S_fru[e]",     "S_gal[e]",     "S_gam[e]",     "S_malt[e]",    "S_his_L[e]",   "S_ile_L[e]",   "S_leu_L[e]", 
"S_glyc[e]",    "S_man[e]",     "S_mepi[e]",    "S_met_L[e]",   "S_malttr[e]",  "S_nac[e]",     "S_uri[e]",     "S_orn[e]",     "S_phe_L[e]",   "S_pnto_R[e]", 
"S_ppa[e]",     "S_prostgh2[e]",    "S_prostgi2[e]",    "S_pro_L[e]",   "S_ribflv[e]",  "S_rib_D[e]",   "S_so4[e]",     "S_o2[e]",  "S_succ[e]",    "S_taur[e]", 
"S_thymd[e]",   "S_trp_L[e]",   "S_tyr_L[e]",   "S_ura[e]",     "S_urea[e]",    "S_val_L[e]",   "S_4abutn[e]",  "S_acmana[e]",  "S_ctp[e]",     "S_dhap[e]", 
"S_dtmp[e]",    "S_dttp[e]",    "S_fald[e]",    "S_itp[e]",     "S_orot[e]",    "S_cdp[e]",     "S_ptrc[e]",    "S_dtdp[e]",    "S_co2[e]",     "S_citr_L[e]", 
"S_spmd[e]",    "S_C02528[e]",  "S_C02470[e]",  "S_HC02192[e]",     "S_HC02193[e]",     "S_HC02195[e]",     "S_HC02196[e]",     "S_HC02220[e]",     "S_dca[e]",     "S_lac_L[e]", 
"S_but[e]",     "S_HC02191[e]",     "S_HC02194[e]",     "S_HC02197[e]",     "S_HC02198[e]",     "S_HC02187[e]",     "S_HC02180[e]",     "S_wharachd[e]",    "S_HC02202[e]",     "S_HC02203[e]", 
"S_HC02204[e]",     "S_HC02205[e]",     "S_HC02206[e]",     "S_HC02207[e]",     "S_HC02208[e]",     "S_HC02210[e]",     "S_HC02213[e]",     "S_HC02214[e]",     "S_HC02216[e]",     "S_HC02217[e]", 
"S_so3[e]",     "S_sprm[e]",    "S_maltttr[e]",     "S_CE2839[e]",  "S_CE2838[e]",  "S_glcur[e]",   "S_crm_hs[e]",  "S_CE0074[e]",  "S_cdpea[e]",   "S_12HPET[e]", 
"S_3bcrn[e]",   "S_c10crn[e]",  "S_c4crn[e]",   "S_c8crn[e]",   "S_doco13ac[e]",    "S_docosac[e]",     "S_ttdcrn[e]",  "S_4hpro_LT[e]",    "S_tdechola[e]",    "S_carn[e]", 
"S_dchac[e]",   "S_sbt_D[e]",   "S_thm[e]",     "S_oh1[e]",     "S_q10[e]",     "S_fmn[e]",     "S_ptth[e]",    "S_q10h2[e]",   "S_pheme[e]",   "S_34hpp[e]", 
"S_3mob[e]",    "S_3mop[e]",    "S_5mta[e]",    "S_ahcys[e]",   "S_aicar[e]",   "S_mal_L[e]",   "S_idour[e]",   "S_5hoxindoa[e]",   "S_glyald[e]",  "S_pep[e]", 
"S_gudac[e]",   "S_Lkynr[e]",   "S_kynate[e]",  "S_3hanthrn[e]",    "S_2pg[e]",     "S_cholp[e]",   "S_dcmp[e]",    "S_ethamp[e]",  "S_fum[e]",     "S_g3pc[e]", 
"S_icit[e]",    "S_L2aadp[e]",  "S_xan[e]",     "S_xmp[e]",     "S_xtsn[e]",    "S_3pg[e]",     "S_udpglcur[e]",    "S_glyc3p[e]",  "S_nicrnt[e]",  "S_orot5p[e]", 
"S_hcys_L[e]",  "S_retinal[e]",     "S_acrn[e]",    "S_pcrn[e]",    "S_lneldccrn[e]",   "S_odecrn[e]",  "S_stcrn[e]",   "S_pmtcrn[e]",  "S_hdcecrn[e]",     "S_pcholmyr_hs[e]", 
"S_pcholole_hs[e]",     "S_peole_hs[e]",    "S_pcholpalme_hs[e]",   "S_pcholpalm_hs[e]",    "S_pepalm_hs[e]",   "S_pail_hs[e]",     "S_pailpalm_hs[e]",     "S_pcholste_hs[e]",     "S_peste_hs[e]",    "S_pchol2linl_hs[e]", 
"S_pe2linl_hs[e]",  "S_pchol2ole_hs[e]",    "S_pchol2palm_hs[e]",   "S_pchol2ste_hs[e]",    "S_pcholn15_hs[e]",     "S_pcholar_hs[e]",  "S_pcholn183_hs[e]",    "S_pcholn1836_hs[e]",   "S_pcholn19_hs[e]",     "S_pcholn201_hs[e]", 
"S_pcholn204_hs[e]",    "S_pcholn205_hs[e]",    "S_pcholn224_hs[e]",    "S_pcholn225_hs[e]",    "S_pcholn2254_hs[e]",   "S_pcholn226_hs[e]",    "S_pear_hs[e]",     "S_pe203_hs[e]",    "S_pe226_hs[e]",    "S_pe224_hs[e]", 
"S_pedh203_hs[e]",  "S_pe12_hs[e]",     "S_pe14_hs[e]",     "S_pe161_hs[e]",    "S_pe13_hs[e]",     "S_pe15_hs[e]",     "S_pe17_hs[e]",     "S_pcholn203_hs[e]",    "S_pailar_hs[e]",   "S_pcholn24_hs[e]", 
"S_pcholn261_hs[e]",    "S_pcholn281_hs[e]",    "S_pcholn28_hs[e]",     "S_pcholdoc_hs[e]",     "S_pcholeic_hs[e]",     "S_pcholet_hs[e]",  "S_pcholhep_hs[e]",     "S_pchollinl_hs[e]",    "S_pelinl_hs[e]",   "S_elaidcrn[e]", 
"S_lnlccrn[e]",     "S_15HPET[e]",  "S_21hprgnlone[e]",     "S_2oxoadp[e]",     "S_34hpl[e]",   "S_3hmp[e]",    "S_3mhis[e]",   "S_4tmeabutn[e]",   "S_56dthm[e]",  "S_56dura[e]", 
"S_5aop[e]",    "S_7dhchsterol[e]",     "S_acglu[e]",   "S_acgly[e]",   "S_aclys[e]",   "S_alltn[e]",   "S_amet[e]",    "S_biliverd[e]",    "S_C04717[e]",  "S_C04805[e]", 
"S_C05957[e]",  "S_C06314[e]",  "S_C06315[e]",  "S_C14768[e]",  "S_C14769[e]",  "S_C14770[e]",  "S_C14771[e]",  "S_C14825[e]",  "S_C14826[e]",  "S_CE1273[e]", 
"S_CE2510[e]",  "S_CE2537[e]",  "S_eidi1114ac[e]",  "S_CE7172[e]",  "S_cortsn[e]",  "S_forglu[e]",  "S_HC00900[e]",     "S_hexdiac[e]",     "S_hgentis[e]",     "S_hmcr[e]", 
"S_hxcoa[e]",   "S_leuktrB4wcooh[e]",   "S_leuktrB4woh[e]",     "S_lthstrl[e]",     "S_mev_R[e]",   "S_mi1p_D[e]",  "S_nwharg[e]",  "S_pcollg5hlys[e]",     "S_saccrp_L[e]",    "S_sebacid[e]", 
"S_tmlys[e]",   "S_urcan[e]",   "S_galt[e]",    "S_glyc_R[e]",  "S_glyc2p[e]",  "S_glyclt[e]",  "S_ind3ac[e]",  "S_Lcyst[e]",   "S_oaa[e]",     "S_pser_L[e]", 
"S_ttdcea[e]",  "S_estriol[e]",     "S_ddca[e]",    "S_normete_L[e]",   "S_C05300[e]",  "S_dhbpt[e]",   "S_thbpt[e]",   "S_sphmyln_hs[e]",  "S_hxa[e]",     "S_Lhcystin[e]", 
"S_acnam[e]",   "S_etha[e]",    "S_acgal[e]",   "S_core4[e]",   "S_f1a[e]",     "S_dxtrn[e]",   "S_dhcholestanate[e]",  "S_thcholstoic[e]",     "S_xol7ah3[e]",     "S_xol7aone[e]", 
"S_xoldiolone[e]",  "S_7klitchol[e]",   "S_2obut[e]",   "S_gua[e]",     "S_glcr[e]",    "S_hxan[e]",    "S_xyl_D[e]",   "S_pydxn[e]",   "S_pydx[e]",    "S_pydam[e]", 
"S_4hbz[e]",    "S_etoh[e]",    "S_acald[e]",   "S_lanost[e]",  "S_3mox4hoxm[e]",   "S_glx[e]",     "S_2h3mv[e]",   "S_2hiv[e]",    "S_2m3hbu[e]",  "S_3h3mglt[e]", 
"S_3mglutac[e]",    "S_glutcon[e]",     "S_5ohhexa[e]",     "S_ethmalac[e]",    "S_eic21114tr[e]",  "S_5eipenc[e]",     "S_T4hcinnm[e]",    "S_andrstandn[e]",  "S_11docrtsl[e]",   "S_11docrtstrn[e]", 
"S_mma[e]",     "S_mhista[e]",  "S_CE2006[e]",  "S_mlthf[e]",   "S_trypta[e]",  "S_selmeth[e]",     "S_CE7090[e]",  "S_CE7085[e]",  "S_CE7096[e]",  "S_CE4877[e]", 
"S_CE1447[e]",  "S_C05770[e]",  "S_CE2705[e]",  "S_hdd2crn[e]",     "S_CE1918[e]",  "S_CE6205[e]",  "S_CE4969[e]",  "S_CE1310[e]",  "S_sucsal[e]",  "S_CE7081[e]", 
"S_egme[e]",    "S_sql[e]",     "S_orn_D[e]",   "S_5g2oxpt[e]",     "S_HC02020[e]",     "S_xol27oh[e]",     "S_xol25oh[e]",     "S_dsmsterol[e]",   "S_3ityr_L[e]",     "S_35diotyr[e]", 
"S_13_cis_retn[e]",     "S_C05767[e]",  "S_ppbng[e]",   "S_12ppd_R[e]",     "S_ametam[e]",  "S_xylu_L[e]",  "S_xylu_D[e]",  "S_sphings[e]",     "S_im4ac[e]",   "S_aact[e]", 
"S_sphgn[e]",   "S_C13856[e]",  "S_prist[e]",   "S_CE2049[e]",  "S_CE2047[e]",  "S_fdp[e]",     "S_coke[e]",    "S_5a2opntn[e]",    "S_arg_D[e]",   "S_dopa4glcur[e]", 
"S_dopa3glcur[e]",  "S_CE5026[e]",  "S_CE1261[e]",  "S_CE5025[e]",  "S_CE2172[e]",  "S_CE5629[e]",  "S_galgluside_hs[e]",   "S_gluside_hs[e]",  "S_gd3_hs[e]",  "S_gm1_hs[e]", 
"S_34dhpe[e]",  "S_M00003[e]",  "S_M00008[e]",  "S_M00010[e]",  "S_M00017[e]",  "S_M00019[e]",  "S_M00021[e]",  "S_M00115[e]",  "S_M00260[e]",  "S_M00265[e]", 
"S_M00315[e]",  "S_M00341[e]",  "S_M01207[e]",  "S_M01235[e]",  "S_M01238[e]",  "S_M01582[e]",  "S_M02053[e]",  "S_M02457[e]",  "S_M02613[e]",  "S_M02745[e]", 
"S_M03045[e]",  "S_M03153[e]",  "S_C01601[e]",  "S_M02108[e]",  "S_M03117[e]",  "S_M03134[e]",  "S_nadh[e]",    "S_M01870[e]",  "S_M02446[e]",  "S_M02447[e]", 
"S_M02449[e]",  "S_M02451[e]",  "S_itacon[e]",  "S_adpman[e]",  "S_rbl_D[e]",   "S_M02155[e]",  "S_M01989[e]",  "S_M01881[e]",  "S_n5m2masn[e]",    "S_dolichol_L[e]", 
"S_12dhchol[e]",    "S_3dhcdchol[e]",   "S_3dhchol[e]",     "S_3dhdchol[e]",    "S_3dhlchol[e]",    "S_7dhcdchol[e]",   "S_7dhchol[e]",     "S_cdca24g[e]",     "S_cdca3g[e]",  "S_coprost[e]", 
"S_hca24g[e]",  "S_hdca24g[e]",     "S_hdca6g[e]",  "S_hyochol[e]",     "S_icdchol[e]",     "S_isochol[e]",     "S_lca24g[e]",  "S_lca3g[e]",   "S_thyochol[e]",    "S_uchol[e]", 
"S_12htacr[e]",     "S_14hmdz[e]",  "S_1hibupglu_S[e]",     "S_1hibup_S[e]",    "S_1ohmdz[e]",  "S_2hatvacid[e]",   "S_2hatvlac[e]",    "S_2hibupglu_S[e]",     "S_2hibup_R[e]",    "S_2hibup_S[e]", 
"S_35dsmv[e]",  "S_3hibupglu_S[e]",     "S_3hibup_R[e]",    "S_3hibup_S[e]",    "S_3hlvstacid[e]",  "S_3hpvstet[e]",    "S_3hpvs[e]",   "S_3hsmvacid[e]",   "S_3ispvs[e]",  "S_3ohacmp[e]", 
"S_4hatvacid[e]",   "S_4hatvlac[e]",    "S_4ohmdz[e]",  "S_56dhpvs[e]",     "S_56eppvs[e]",     "S_5ohfvsglu[e]",   "S_5ohfvs[e]",  "S_6bhglz[e]",  "S_6csmvacid[e]",   "S_6epvs[e]", 
"S_6hlvst[e]",  "S_6hmsmvacid[e]",  "S_6hsmvacid[e]",   "S_6melvacid[e]",   "S_6melvst[e]",     "S_6ohfvsglu[e]",   "S_7bhglz[e]",  "S_7hpvs[e]",   "S_acmp[e]",    "S_am19cs[e]", 
"S_am1csa[e]",  "S_am9csa[e]",  "S_atvacid[e]",     "S_atvlac[e]",  "S_caribupglu_S[e]",    "S_caribup_s[e]",   "S_crvs[e]",    "S_crvsm24[e]",     "S_csa[e]",     "S_deoxfvs[e]", 
"S_dspvs[e]",   "S_epoxtac[e]",     "S_fvs[e]",     "S_glc3meacp[e]",   "S_glz[e]",     "S_ibup_R[e]",  "S_ibup_S[e]",  "S_ibupgluc[e]",    "S_isolvstacid[e]",     "S_lstn[e]", 
"S_lstnm7[e]",  "S_lvst[e]",    "S_mdz[e]",     "S_mhglz[e]",   "S_nfdac[e]",   "S_nfdoh[e]",   "S_profvs[e]",  "S_ptvst[e]",   "S_ptvstlac[e]",    "S_pvs[e]", 
"S_pvsgluc[e]",     "S_smv[e]",     "S_smvacid[e]",     "S_tacr[e]",    "S_tlacfvs[e]",     "S_tripvs[e]",  "S_ptvstm13[e]",    "S_caproic[e]",     "S_1a25dhvitd2[e]",     "S_peptide[e]", 
"S_abeta_L_lysine[e]",  "S_tau_L_lysine[e]",    "S_TNFA_L_lysine[e]",   "S_IL6_L_lysine[e]",    "S_3mlda[e]",   "S_5adtststerones[e]",  "S_acnacngalgbside_hs[e]",  "S_crmp_hs[e]",     "S_3aib_D[e]",  "S_lac_D[e]", 
"S_aprgstrn[e]",    "S_avite1[e]",  "S_fuc_L[e]",   "S_gt1a_hs[e]",     "S_hestratriol[e]",     "S_nrpphrsf[e]",    "S_s2l2fn2m2masn[e]",   "S_s2l2n2m2masn[e]",    "S_sph1p[e]",   "S_tettet6[e]", 
"S_tmndnc[e]",  "S_triodthysuf[e]",     "S_tststerones[e]",     "S_tre[e]",     "S_dgmp[e]",    "S_dgtp[e]",    "S_ppi[e]",     "S_pyr[e]",     "S_acac[e]",    "S_c101crn[e]", 
"S_c12dc[e]",   "S_c16dc[e]",   "S_c3dc[e]",    "S_c4dc[e]",    "S_c6crn[e]",   "S_c81crn[e]",  "S_3ddcrn[e]",  "S_ddeccrn[e]",     "S_ddece1crn[e]",   "S_3deccrn[e]", 
"S_decdicrn[e]",    "S_3octdece1crn[e]",    "S_3tdcrn[e]",  "S_tetdec2crn[e]",  "S_tetdece1crn[e]",     "S_slfcys[e]",  "S_4mop[e]",    "S_cbasp[e]",   "S_phlac[e]",   "S_15kprostgf2[e]", 
"S_3hpp[e]",    "S_3uib[e]",    "S_adpac[e]",   "S_adpoh[e]",   "S_pa_hs[e]",   "S_C11695[e]",  "S_CE5304[e]",  "S_CE6247[e]",  "S_dodecanac[e]",   "S_sphmyln180241_hs[e]", 
"S_sphmyln18114_hs[e]",     "S_sphmyln18115_hs[e]",     "S_sphmyln18116_hs[e]",     "S_sphmyln181161_hs[e]",    "S_sphmyln18117_hs[e]",     "S_sphmyln18118_hs[e]",     "S_sphmyln181181_hs[e]",    "S_sphmyln18120_hs[e]",     "S_sphmyln181201_hs[e]",    "S_sphmyln18121_hs[e]", 
"S_sphmyln18122_hs[e]",     "S_sphmyln181221_hs[e]",    "S_sphmyln18123_hs[e]",     "S_sphmyln1824_hs[e]",  "S_sphmyln1825_hs[e]",  "S_subeac[e]",  "S_pac[e]",     "S_pheacgly[e]",    "S_homoval[e]",     "S_s2l2n2m2m[e]", 
"S_phpyr[e]",   "S_ppiogly[e]",     "S_tiggly[e]",  "S_3hivac[e]",  "S_3hadpac[e]",     "S_3ohsebac[e]",    "S_3ohsubac[e]",    "S_hexgly[e]",  "S_subgly[e]",  "S_4ohbut[e]", 
"S_34dhoxmand[e]",  "S_dhea[e]",    "S_estrone[e]",     "S_chsterols[e]",   "S_M00117[e]",  "S_M01197[e]",  "S_M03051[e]",  "S_ditp[e]",    "S_M03131[e]",  "S_1hmdgluc[e]", 
"S_2hatvlacgluc[e]",    "S_4hmdgluc[e]",    "S_oxyp[e]"                         
/                                   
                                    
BioCompound_Class3(biocompound) "species participate in the extracellular compartment only, but not existed in the intrcellular compartments"                                   
/                                   
"S_strch1[e]",  "S_strch2[e]",  "S_glygn4[e]",  "S_adprbp[e]",  "S_gluala[e]",  "S_glygn5[e]",  "S_lcts[e]",    "S_sucr[e]",    "S_ahdt[e]",    "S_dha[e]", 
"S_HC01104[e]",     "S_HC01361[e]",     "S_HC01446[e]",     "S_HC01577[e]",     "S_HC01700[e]",     "S_HC00955[e]",     "S_maltpt[e]",  "S_malthx[e]",  "S_CE2915[e]",  "S_CE4722[e]", 
"S_CE2916[e]",  "S_CE4723[e]",  "S_CE2917[e]",  "S_CE4724[e]",  "S_malthp[e]",  "S_CE1950[e]",  "S_cynt[e]",    "S_CE5786[e]",  "S_CE5788[e]",  "S_CE5867[e]", 
"S_CE5868[e]",  "S_CE5869[e]",  "S_CE4633[e]",  "S_no2[e]",     "S_CE4881[e]",  "S_CE1926[e]",  "S_CE5854[e]",  "S_12dgr120[e]",    "S_CE1925[e]",  "S_CE5853[e]", 
"S_cysam[e]",   "S_pailste_hs[e]",  "S_xolest183_hs[e]",    "S_xolest181_hs[e]",    "S_xolest204_hs[e]",    "S_M00234[e]",  "S_M01807[e]",  "S_M00503[e]",  "S_M01111[e]",  "S_ksi[e]", 
"S_ksi_deg1[e]",    "S_HC01444[e]",     "S_CE5789[e]",  "S_CE5797[e]",  "S_CE5798[e]",  "S_aracheth[e]",    "S_didecaeth[e]",   "S_diholineth[e]",  "S_docohxeth[e]",   "S_docteteth[e]", 
"S_hepdeceth[e]",   "S_hexdeceeth[e]",  "S_lineth[e]",  "S_oleth[e]",   "S_pendecaeth[e]",  "S_pmeth[e]",   "S_steeth[e]",  "S_tetdecaeth[e]",  "S_trideceth[e]",   "S_h2co3[e]"
/                                   
                                    
BioCompound_Class4(biocompound) "species participate in a single intracellular compartment only, but not existed in the extracellular compartment"                                  
/                                   
"S_13dampp[c]",     "S_cmusa[c]",   "S_T_antigen[g]",   "S_gam6p[c]",   "S_man6p[c]",   "S_dhcholoylcoa[x]",    "S_ksii_core4_pre5[g]",     "S_n2m2nmn[l]",     "S_octd11ecoa[c]",  "S_itaccoa[m]", 
"S_core7[g]",   "S_dgpi_prot_hs[r]",    "S_23dpg[c]",   "S_f26bp[c]",   "S_ksii_core4_pre10[g]",    "S_cs_d_pre3[g]",   "S_fgam[c]",    "S_cs_a_b_e_pre1[g]",   "S_hs_pre7[g]",     "S_hs_deg25[l]", 
"S_pre_prot[r]",    "S_hs_deg19[l]",    "S_lgt_S[c]",   "S_retinol_cis_11[c]",  "S_prpp[c]",    "S_ru5p_D[c]",  "S_cs_e_pre5b[g]",  "S_HC00342[m]",     "S_r5p[c]",     "S_HC02027[r]", 
"S_CE2576[c]",  "S_CE5118[m]",  "S_CE2567[c]",  "S_CE4838[x]",  "S_CE4803[m]",  "S_CE4807[m]",  "S_CE6504[c]",  "S_CE6232[c]",  "S_tmuncoa[x]",     "S_23dh1i56dio[c]", 
"S_gda1_hs[n]",     "S_M02686[c]",  "S_galfucgalacglcgalgluside_hs[c]",     "S_M00964[c]",  "S_M00406[c]",  "S_HC01406[x]",     "S_M00061[m]",  "S_M00792[m]",  "S_M01454[r]",  "S_M01465[r]", 
"S_M01475[r]",  "S_M01486[r]",  "S_M01501[r]",  "S_M00770[m]",  "S_tau_N_Ub_lysine[c]",     "S_IL6_N_Ub_lysine[c]",     "S_ivcoa[m]",   "S_CE2873[c]",  "S_CE4845[c]",  "S_c101coa[c]", 
"S_tetdec2coa[c]",  "S_3hadicoa[x]",    "S_M00871[c]",  "S_M00862[c]",  "S_bamppald[c]",    "S_2amac[c]",   "S_2dr1p[c]",   "S_glutcoa[m]",     "S_34dhpac[c]",     "S_3dphb[m]", 
"S_3dpdhb[m]",  "S_3hibutcoa[m]",   "S_hLkynr[c]",  "S_42A3HP24DB[c]",  "S_e4hglu[m]",  "S_5hoxindact[c]",  "S_m2mn[l]",    "S_mn[l]",  "S_core2[g]",   "S_gncore2[g]", 
"S_fucgalacglcgalgluside_hs[g]",    "S_fuc12gal14acglcgalgluside_hs[g]",    "S_fucfucgalacglcgalacglcgal14acglcgalgluside_hs[g]",   "S_abt[c]",     "S_acgal1p[c]",     "S_acgam6p[c]",     "S_acgam1p[c]",     "S_acgpail_hs[c]",  "S_gpail_hs[c]",    "S_acmanap[c]", 
"S_acnamp[c]",  "S_2mbcoa[m]",  "S_2mb2coa[m]",     "S_ibcoa[m]",   "S_2mp2coa[m]",     "S_acetol[c]",  "S_damp[c]",    "S_g1p[c]",     "S_man1p[c]",   "S_aps[c]", 
"S_dcamp[c]",   "S_25aics[c]",  "S_ksii_core4_pre2[g]",     "S_ksii_core4_pre3[g]",     "S_ksii_core4_pre4[g]",     "S_ksii_core4_pre7[g]",     "S_ksii_core4_pre8[g]",     "S_ksii_core2_pre2[g]",     "S_ksii_core2_pre3[g]",     "S_ksii_core2_pre4[g]", 
"S_ksii_core2_pre5[g]",     "S_ksii_core2_pre7[g]",     "S_ksii_core2_pre8[g]",     "S_air[c]",     "S_5aizc[c]",   "S_lald_D[c]",  "S_12ppd_S[c]",     "S_2aobut[m]",  "S_Rtotalcoa[c]",   "S_Rtotal3coa[c]", 
"S_Rtotal3[c]",     "S_R2coa_hs[c]",    "S_Asn_X_Ser_Thr[l]",   "S_gal14acglcgalgluside_hs[g]",     "S_acglc13galacglcgal14acglcgalgluside_hs[g]",  "S_galacglcgalacglcgal14acglcgalgluside_hs[g]",     "S_galacglc13galacglcgal14acglcgalgluside_hs[g]",   "S_galthcrm_hs[g]",     "S_galgalthcrm_hs[g]",  "S_acglcgalgbside_hs[g]", 
"S_dgcholcoa[x]",   "S_gdpmann[c]",     "S_memgacpail_hs[r]",   "S_m2emgacpail_hs[r]",  "S_zym_int2[r]",    "S_citmcoa_L[m]",   "S_clpn_hs[c]",     "S_2dpmhobq[m]",    "S_2dp6mobq[m]",    "S_2dp6mobq_me[m]", 
"S_2dp6mep[m]",     "S_core3[g]",   "S_core5[g]",   "S_cs_a[l]",    "S_cs_e[l]",    "S_focytC[m]",  "S_ficytC[m]",  "S_4h2oglt[m]",     "S_dedoldp_L[c]",   "S_dedolp_L[c]", 
"S_dedol_L[c]",     "S_tag_hs[c]",  "S_3dhguln[c]",     "S_3dpdhb_me[m]",   "S_dkmpp[c]",   "S_2kmb[c]",    "S_dem2emgacpail_prot_hs[r]",   "S_gpi_sig[r]",     "S_mem2emgacpail_prot_hs[r]",   "S_dmhptcoa[m]", 
"S_dopaqn[c]",  "S_13dpg[c]",   "S_2dr5p[c]",   "S_g3p[c]",     "S_3hmbcoa[m]",     "S_n2m2nm[l]",  "S_malcoa[c]",  "S_Sfglutth[c]",    "S_xu1p_D[c]",  "S_tag1p_D[c]", 
"S_f6p[c]",     "S_fucgalacglc13galacglcgal14acglcgalgluside_hs[g]",    "S_fucfucgalacglc13galacglcgal14acglcgalgluside_hs[g]",     "S_ksii_core4_pre1[g]",     "S_ksii_core4_pre6[g]",     "S_ksii_core4_pre9[g]",     "S_ksii_core2_pre1[g]",     "S_ksii_core2_pre6[g]",     "S_ksii_core2_pre9[g]",     "S_ksii_core2_pre10[g]", 
"S_glu5p[m]",   "S_cs_hs_linkage[g]",   "S_cs_pre[g]",  "S_cs_a_b_pre2[g]",     "S_cs_a_b_pre3[g]",     "S_cs_c_pre2[g]",   "S_cs_c_pre3[g]",   "S_cs_d_pre4[g]",   "S_cs_e_pre3[g]",   "S_cs_e_pre4[g]", 
"S_lxser[g]",   "S_l2xser[g]",  "S_gar[c]",     "S_lpam[m]",    "S_dhlam[m]",   "S_gdpddman[c]",    "S_udpg[c]",    "S_ttc_ggdp[c]",    "S_3htmelys[c]",    "S_4tmeabut[c]", 
"S_hs_deg9[l]",     "S_hs_deg10[l]",    "S_cs_a_deg2[l]",   "S_cs_a_deg3[l]",   "S_cs_e_deg3[l]",   "S_cs_e_deg4[l]",   "S_ha_deg1[l]",     "S_hs_pre10[g]",    "S_hs_pre11[g]",    "S_cs_c_d_e_pre1[g]", 
"S_cs_d_pre2[g]",   "S_cs_e_pre2[g]",   "S_hs_pre1[g]",     "S_hs_pre2[g]",     "S_hs_pre3[g]",     "S_hs_pre4[g]",     "S_hs_pre5[g]",     "S_hs_pre6[g]",     "S_hs_pre8[g]",     "S_hs_deg3[l]", 
"S_hs_deg4[l]",     "S_hs_deg8[l]",     "S_hs_deg14[l]",    "S_hs_deg15[l]",    "S_hs_deg20[l]",    "S_hs_deg21[l]",    "S_hs_deg24[l]",    "S_hs_pre9[g]",     "S_glygn3[c]",  "S_glucys[c]", 
"S_5forthf[c]",     "S_em2emgacpail_prot_hs[r]",    "S_gpi_prot_hs[r]",     "S_mgacpail_hs[r]",     "S_emgacpail_hs[r]",    "S_m2gacpail_hs[r]",    "S_m3gacpail_hs[r]",    "S_em3gacpail_hs[r]",   "S_emem2gacpail_hs[r]",     "S_em2emgacpail_hs[r]", 
"S_m3emgacpail_hs[r]",  "S_gpi_hs[r]",  "S_mem2emgacpail_hs[r]",    "S_im4act[c]",  "S_phyt2ohcoa[x]",  "S_hs_deg1[l]",     "S_hs_deg2[l]",     "S_hs_deg6[l]",     "S_hs_deg7[l]",     "S_hs_deg12[l]", 
"S_hs_deg13[l]",    "S_hs_deg18[l]",    "S_eandrstrn[r]",   "S_hs[l]",  "S_iodine[c]",  "S_hs_deg5[l]",     "S_hs_deg16[l]",    "S_hs_deg17[l]",    "S_hs_deg22[l]",    "S_hs_deg23[l]", 
"S_f1p[c]",     "S_4aphdob[c]",     "S_cs_a_deg5[l]",   "S_cs_e_deg7[l]",   "S_retinol_9_cis[c]",   "S_3mgcoa[m]",  "S_5mdru1p[c]",     "S_mi1345p[c]",     "S_mi134p[c]",  "S_mi145p[c]", 
"S_mi14p[c]",   "S_mi3p_D[c]",  "S_5mdr1p[c]",  "S_cs_a_deg1[l]",   "S_cs_a_deg4[l]",   "S_nicrns[c]",  "S_r1p[c]",     "S_thbpt4acam[c]",  "S_pail345p_hs[c]",     "S_pail34p_hs[c]", 
"S_pail3p_hs[c]",   "S_pram[c]",    "S_quln[c]",    "S_retinal_11_cis[c]",  "S_retinal_cis_9[c]",   "S_retinol_cis_13[c]",  "S_retn[r]",    "S_rnam[c]",    "S_cs_d_pre5[g]",   "S_hs_pre12[g]", 
"S_hs_pre13[g]",    "S_hs_pre14[g]",    "S_hs_pre15[g]",    "S_hs_deg11[l]",    "S_thmpp[c]",   "S_udpxyl[r]",  "S_xu5p_D[c]",  "S_HC01672[c]",     "S_HC00591[c]",     "S_HC01496[m]", 
"S_e4p[c]",     "S_HC00361[c]",     "S_s7p[c]",     "S_HC01712[m]",     "S_HC00718[c]",     "S_HC00664[c]",     "S_HC01180[c]",     "S_fpram[c]",   "S_xol7ah2al[c]",   "S_HC01842[c]", 
"S_HC02021[r]",     "S_HC02022[r]",     "S_HC02023[r]",     "S_HC02121[c]",     "S_CE1944[c]",  "S_CE2866[c]",  "S_CE4888[c]",  "S_CE5586[c]",  "S_CE5626[c]",  "S_CE5276[c]", 
"S_CE5021[c]",  "S_CE5022[c]",  "S_CE2577[c]",  "S_C05109[c]",  "S_CE5665[c]",  "S_CE5166[m]",  "S_CE5125[x]",  "S_CE5126[x]",  "S_CE5117[m]",  "S_CE5119[m]", 
"S_CE5120[m]",  "S_CE4790[m]",  "S_CE4792[m]",  "S_CE4794[m]",  "S_CE2056[r]",  "S_CE3554[r]",  "S_cpppg3[c]",  "S_uppg3[c]",   "S_CE2038[x]",  "S_CE5934[x]", 
"S_C07297[x]",  "S_tmtrdcoa[x]",    "S_CE4812[c]",  "S_CE4811[c]",  "S_CE4810[c]",  "S_CE4821[c]",  "S_CE4819[c]",  "S_CE4817[c]",  "S_CE2313[c]",  "S_CE2314[c]", 
"S_CE4833[c]",  "S_CE4831[c]",  "S_CE4835[c]",  "S_CE4834[c]",  "S_CE4849[c]",  "S_CE4820[x]",  "S_CE4832[x]",  "S_CE4842[c]",  "S_CE4853[c]",  "S_CE4801[m]", 
"S_CE4800[m]",  "S_CE4796[m]",  "S_CE4802[m]",  "S_CE4804[m]",  "S_CE5049[c]",  "S_CE4806[m]",  "S_CE4798[m]",  "S_CE4799[m]",  "S_CE4808[m]",  "S_CE4797[m]", 
"S_C11821[c]",  "S_CE6506[c]",  "S_C08261[c]",  "S_CE6508[c]",  "S_CE7091[r]",  "S_CE7088[c]",  "S_CE6230[c]",  "S_CE6234[c]",  "S_doco13ecoa[c]",  "S_hexdtrcoa[m]", 
"S_2hexdtetcoa[x]",     "S_4hexdtetcoa[x]",     "S_hexdpencoa[x]",  "S_3hexdtetcoa[x]",     "S_eipencoa[x]",    "S_5eipencoa[m]",   "S_2docohexecoa[m]",    "S_docohepcoa[m]",  "S_docosahexcoa[m]",    "S_5dpmev[c]", 
"S_6pgl[c]",    "S_5pmev[c]",   "S_ttdceacoa[c]",   "S_txb2[c]",    "S_hmbil[c]",   "S_phom[c]",    "S_gal1p[c]",   "S_glutacoa[m]",    "S_ethmalcoa[c]",   "S_6hddopaqn[c]", 
"S_5cysdopa[c]",    "S_gd1b_hs[c]",     "S_gt1b_hs[c]",     "S_gm2_hs[c]",  "S_HC02048[c]",     "S_HC02042[c]",     "S_HC02050[c]",     "S_HC02051[c]",     "S_HC02054[c]",     "S_HC02056[c]", 
"S_HC02060[c]",     "S_M02758[c]",  "S_HC02076[c]",     "S_HC02070[c]",     "S_M02197[c]",  "S_gm3_hs[c]",  "S_M02195[c]",  "S_acgalfucgalacglcgalgluside_hs[c]",   "S_M02683[c]",  "S_M02186[c]", 
"S_M02490[c]",  "S_M00961[c]",  "S_M00957[c]",  "S_M00963[c]",  "S_M00959[c]",  "S_M00955[c]",  "S_M01067[c]",  "S_M00940[c]",  "S_M00938[c]",  "S_M00942[c]", 
"S_M00962[c]",  "S_M00958[c]",  "S_M00954[c]",  "S_M00966[c]",  "S_M00967[c]",  "S_M00960[c]",  "S_M00956[c]",  "S_M01068[c]",  "S_cholcoas[m]",    "S_HC01459[m]", 
"S_M00605[c]",  "S_M02760[c]",  "S_M02761[c]",  "S_M00603[c]",  "S_M00285[c]",  "S_HC01405[x]",     "S_HC01407[x]",     "S_HC01408[x]",     "S_M00046[m]",  "S_M00780[m]", 
"S_M00875[m]",  "S_M00795[m]",  "S_M00897[m]",  "S_M00069[m]",  "S_M00804[m]",  "S_M00909[m]",  "S_M00071[m]",  "S_M00806[m]",  "S_M00911[m]",  "S_M00056[m]", 
"S_M00889[m]",  "S_M00048[m]",  "S_M00782[m]",  "S_M00877[m]",  "S_M00063[m]",  "S_M00797[m]",  "S_M00899[m]",  "S_M03024[m]",  "S_M00170[m]",  "S_M00841[m]", 
"S_M01455[r]",  "S_M01456[r]",  "S_M01457[r]",  "S_M01458[r]",  "S_M01460[r]",  "S_M01461[r]",  "S_M01462[r]",  "S_M01463[r]",  "S_M01464[r]",  "S_M01466[r]", 
"S_M01467[r]",  "S_M01468[r]",  "S_M01469[r]",  "S_M01470[r]",  "S_M01471[r]",  "S_M01472[r]",  "S_M01473[r]",  "S_M01474[r]",  "S_M01476[r]",  "S_M01477[r]", 
"S_M01479[r]",  "S_M01480[r]",  "S_M01481[r]",  "S_M01482[r]",  "S_M01483[r]",  "S_M01484[r]",  "S_M01485[r]",  "S_M01487[r]",  "S_M01489[r]",  "S_M01491[r]", 
"S_M01492[r]",  "S_M01494[r]",  "S_M01495[r]",  "S_M01496[r]",  "S_M01497[r]",  "S_M01498[r]",  "S_M01502[r]",  "S_M01506[r]",  "S_M01508[r]",  "S_M01509[r]", 
"S_M01510[r]",  "S_M00658[m]",  "S_M01165[m]",  "S_M00213[c]",  "S_Ndmelys[c]",     "S_Ntmelys[c]",     "S_M01869[g]",  "S_M03167[c]",  "S_6msmv[r]",   "S_atvethgluc[r]", 
"S_crvsm1[r]",  "S_crvsm23[r]",     "S_ptvstgluc[r]",   "S_rsvgluc[r]",     "S_ubiquitin[c]",   "S_abeta[c]",   "S_abeta_N_Ub_lysine[c]",   "S_abeta_N6_methyl_L_lysine[c]",    "S_abeta_N6_N6_dimethyl_L_lysine[c]",   "S_abeta_N6_N6_N6_trimethyl_L_lysine[c]", 
"S_tau[c]",     "S_tau_N6_methyl_L_lysine[c]",  "S_tau_N6_N6_dimethyl_L_lysine[c]",     "S_tau_N6_N6_N6_trimethyl_L_lysine[c]",     "S_TNFA[c]",    "S_TNFA_N_Ub_lysine[c]",    "S_TNFA_N6_methyl_L_lysine[c]",     "S_TNFA_N6_N6_dimethyl_L_lysine[c]",    "S_TNFA_N6_N6_N6_trimethyl_L_lysine[c]",    "S_IL6[c]", 
"S_IL6_N6_methyl_L_lysine[c]",  "S_IL6_N6_N6_dimethyl_L_lysine[c]",     "S_IL6_N6_N6_N6_trimethyl_L_lysine[c]",     "S_34dhpha[c]",     "S_4hoxpacd[c]",    "S_4hphac[c]",  "S_3otdcoa[x]",     "S_kdnp[c]",    "S_3mb2coa[m]",     "S_melatn[c]", 
"S_msa[m]",     "S_kdn[c]",     "S_fuc1p_L[c]",     "S_3mldz[c]",   "S_6hoxmelatn[c]",  "S_mi13p[c]",   "S_dimp[c]",    "S_peamn[c]",   "S_acngalgbside_hs[g]",     "S_trdrd[c]", 
"S_trdox[c]",   "S_tym[c]",     "S_3mox4hpac[m]",   "S_CE2870[c]",  "S_CE2872[c]",  "S_CE2875[c]",  "S_CE2874[c]",  "S_CE4841[c]",  "S_CE4840[c]",  "S_CE4844[c]", 
"S_CE4846[c]",  "S_CE4852[c]",  "S_CE4850[c]",  "S_CE4848[c]",  "S_CE4851[c]",  "S_CE5160[c]",  "S_CE5161[c]",  "S_CE5162[c]",  "S_CE7097[m]",  "S_decdicoa[c]", 
"S_c12dccoa[c]",    "S_tetdece1coa[c]",     "S_c81coa[c]",  "S_3ivcoa[m]",  "S_phaccoa[m]",     "S_3ohsebcoa[x]",   "S_3ohsubcoa[x]",   "S_M02491[c]",  "S_CE6246[c]",  "S_M00907[c]", 
"S_M00802[c]",  "S_M00067[c]",  "S_M00852[c]",  "S_M00707[c]",  "S_M03018[c]",  "S_M00839[c]",  "S_M00699[c]",  "S_M03011[c]",  "S_M00704[c]",  "S_M03017[c]", 
"S_M00860[c]",  "S_M00085[c]",  "S_M03008[c]",  "S_M00869[c]",  "S_M00086[c]",  "S_M03005[c]",  "S_M00712[c]",  "S_M03006[c]",  "S_atvacylgluc[r]",     "S_atvlacgluc[r]"
/                                   
                                    
BioCompound_Class5(biocompound) "metabolites participate in at least two intracellular compartments, but not existed in the extracellular compartment"                                  
/                                   
"S_17ahprgnlone[c][r]",     "S_17ahprgstrn[c][r]",  "S_1a25dhvitd3[c][m][n]",   "S_1p3h5c[c][m]",   "S_1pyr5c[c][m]",   "S_20ahchsterol[m][r]",     "S_25hvitd2[c][m]",     "S_25hvitd3[c][m]",     "S_2ddecdicoa[m][x]",   "S_2decdicoa[m][x]", 
"S_2docopencoa[m][x]",  "S_2dodtricoa[m][x]",   "S_2hexdtricoa[m][x]",  "S_2mop[c][m]",     "S_2octdectecoa[m][x]",     "S_34dhmald[c][m]",     "S_3ddecdicoa[m][x]",   "S_3decdicoa[m][x]",    "S_3docopencoa[m][x]",  "S_3dodtricoa[m][x]", 
"S_3hbcoa[m][x]",   "S_3hbcoa_R[c][m]",     "S_3hdcoa[c][m]",   "S_3hddcoa[c][m]",  "S_3hexdtricoa[m][x]",  "S_3hlvst[c][r]",   "S_3hpvscoa[c][m][x]",  "S_3hpvstetcoa[c][m][x]",   "S_3hsmv[c][r]",    "S_3htdcoa[c][m][x]", 
"S_3m4hpga[c][m]",  "S_3meacmp[c][r]",  "S_3octdece1coa[c][m]",     "S_3octdectecoa[m][x]",     "S_3ohodcoa[c][m][x]",  "S_3ohxccoa[c][x]",     "S_3sala[c][m]",    "S_44mctr[c][r]",   "S_44mzym[c][r]",   "S_4hbzcoa[c][m]", 
"S_4hexdtricoa[m][x]",  "S_4mzym_int1[c][r]",   "S_4mzym_int2[c][r]",   "S_5HPET[c][m]",    "S_5tedtricoa[m][x]",   "S_6csmv[c][r]",    "S_6hlvstacid[c][r]",   "S_6hmsmv[c][r]",   "S_6hsmv[c][r]",    "S_aacoa[c][m][x]", 
"S_accoa[c][g][m][n][x]",   "S_acgagbside_hs[c][g][l]",     "S_acgbgbside_hs[c][g][l]",     "S_acglcgal14acglcgalgluside_hs[c][g]",     "S_acglcgalacglcgal14acglcgalgluside_hs[c][g]",     "S_acglcgalgluside_hs[c][g]",   "S_adpcoa[c][x]",   "S_adrncoa[c][m][r][x]",    "S_adrncrn[c][m]",  "S_andrstndn[c][r]", 
"S_arachcoa[c][m][r][x]",   "S_arachcrn[c][m]",     "S_arachdcoa[c][m][r][x]",  "S_arachdcrn[c][m]",    "S_b2coa[m][x]",    "S_btcoa[c][m][x]",     "S_C01747[c][l]",   "S_C02712[c][m]",   "S_C05279[m][x]",   "S_C05280[m][x]", 
"S_c10dc[c][x]",    "S_c226coa[c][m][r][x]",    "S_c226crn[c][m]",  "S_c6dc[c][x]",     "S_c8dc[c][x]",     "S_cbl2[c][m]",     "S_cbp[c][r]",  "S_cdpchol[c][r]",  "S_cdpdag_hs[c][m]",    "S_CE0347[c][r]", 
"S_CE0693[m][x]",   "S_CE0713[m][x]",   "S_CE0785[m][x]",   "S_CE0849[m][x]",   "S_CE2053[m][r]",   "S_CE2084[c][m]",   "S_CE2242[c][m][x]",    "S_CE2243[m][x]",   "S_CE2245[c][x]",   "S_CE2246[c][m][x]", 
"S_CE2247[m][x]",   "S_CE2248[c][m][x]",    "S_CE2249[c][x]",   "S_CE2250[c][m][x]",    "S_CE2251[m][x]",   "S_CE2253[c][x]",   "S_CE2417[m][x]",   "S_CE2418[m][x]",   "S_CE2420[m][x]",   "S_CE2421[m][x]", 
"S_CE2422[m][x]",   "S_CE2424[m][x]",   "S_CE2432[m][x]",   "S_CE2433[m][x]",   "S_CE2434[m][x]",   "S_CE2437[m][x]",   "S_CE2438[m][x]",   "S_CE2439[m][x]",   "S_CE2440[m][x]",   "S_CE2441[m][x]", 
"S_CE2442[m][x]",   "S_CE4791[c][m][x]",    "S_CE4793[c][m][x]",    "S_CE4795[m][x]",   "S_CE4843[c][m][r]",    "S_CE4847[c][m]",   "S_CE4854[c][m]",   "S_CE4855[c][x]",   "S_CE4988[c][m][x]",    "S_CE4990[m][x]", 
"S_CE5114[c][m][x]",    "S_CE5116[m][x]",   "S_CE5144[c][m][x]",    "S_CE5148[c][m][x]",    "S_CE5150[c][m][x]",    "S_CE5151[c][m][r][x]",     "S_CE5152[c][m][x]",    "S_CE5153[c][m][x]",    "S_CE5154[c][m][x]",    "S_CE5155[c][m][r][x]", 
"S_CE5156[c][x]",   "S_CE5157[c][x]",   "S_CE5158[c][x]",   "S_CE5253[c][l]",   "S_CE5944[m][x]",   "S_CE5947[c][m][x]",    "S_chlstol[c][r]",  "S_cholcoa[c][m][r][x]",    "S_cholcoads[m][x]",    "S_cholcoaone[m][x]", 
"S_cholcoar[c][m][r][x]",   "S_clpndcoa[c][m][r][x]",   "S_clpndcrn[c][m]",     "S_cmpacna[c][g][n]",   "S_coa[c][g][l][m][n][r][x]",   "S_core6[g][l]",    "S_coucoa[c][m]",   "S_dadp[c][m][n]",  "S_datp[c][m][n]",  "S_dc2coa[m][x]", 
"S_dcacoa[c][m][x]",    "S_dcdp[c][m][n]",  "S_dcholcoa[c][r][x]",  "S_dcsptn1coa[c][m][r][x]",     "S_dcsptn1crn[c][m]",   "S_dctp[c][m][n]",  "S_dd2coa[c][m][x]",    "S_dd3coa[m][x]",   "S_ddcacoa[c][m][r][x]",    "S_ddsmsterol[c][r]", 
"S_dec24dicoa[m][x]",   "S_dec47dicoa[m][x]",   "S_decdp[c][m]",    "S_dece3coa[m][x]",     "S_dece4coa[m][x]",     "S_dectricoa[m][x]",    "S_dgdp[c][m]",     "S_dhcholestancoa[c][r][x]",    "S_dhcrm_hs[c][g]",     "S_digalside_hs[c][l]", 
"S_dlnlcgcoa[c][m][r]",     "S_dlnlcgcrn[c][m][r]",     "S_dmnoncoa[c][m][x]",  "S_dmnoncrn[c][m][x]",  "S_dmpp[c][x]",     "S_dnad[c][n]",     "S_docohexcoa[m][x]",   "S_docoscoa[c][m][r][x]",   "S_dolmanp_U[c][r]",    "S_dolp_U[c][r]", 
"S_dpcoa[c][l][m]",     "S_dudp[c][m]",     "S_dump[c][m]",     "S_dutp[c][m]",     "S_eicostetcoa[c][m][r]",   "S_eicostetcrn[c][m]",  "S_eitetcoa[m][x]",     "S_fad[c][m][r][x]",    "S_fadh2[c][m][r][x]",  "S_formcoa[c][x]", 
"S_frdp[c][r][x]",  "S_fvscoa[c][x]",   "S_g6p[c][r]",  "S_ga1_hs[c][g]",   "S_ga2_hs[c][g]",   "S_gacpail_hs[c][r]",   "S_galacglcgal14acglcgalgluside_hs[c][g]",  "S_galacglcgalgluside_hs[c][g]",    "S_galgbside_hs[c][g]",     "S_galside_hs[c][l][n]", 
"S_gcald[c][m]",    "S_gd1a_hs[c][g][n]",   "S_gdpfuc[c][g]",   "S_glac[c][r]",     "S_glu5sa[c][m]",   "S_gm1b_hs[c][g]",  "S_grdp[c][x]",     "S_guln[c][r]",     "S_HC01412[m][x]",  "S_HC01415[m][x]", 
"S_HC01434[c][m][x]",   "S_HC01668[c][m]",  "S_HC02057[c][r]",  "S_HC02110[c][r]",  "S_HC10784[c][r]",  "S_HC10856[m][x]",  "S_HC10857[m][x]",  "S_HC10858[m][x]",  "S_hdcoa[c][m]",    "S_hdd2coa[c][m][r][x]", 
"S_hexccoa[c][r][x]",   "S_hexdectecoa[m][x]",  "S_hexdicoa[c][r]",     "S_hexe3coa[m][x]",     "S_hmgcoa[c][m][x]",    "S_hpdcacoa[c][m][r]",  "S_hpdcacrn[c][m]",     "S_hpyr[c][m][x]",  "S_hx2coa[m][x]",   "S_id3acald[c][m]", 
"S_ipdp[c][x]",     "S_L2aadp6sa[c][m]",    "S_lald_L[c][m]",   "S_lneldccoa[c][m][r]",     "S_lnlccoa[c][m][r][x]",    "S_lnlncacoa[c][m][r]",     "S_lnlncacrn[c][m]",    "S_lnlncgcoa[c][m][r][x]",  "S_lnlncgcrn[c][m][r]",     "S_lvstacid[c][r]", 
"S_M00004[c][m][r]",    "S_M00006[c][m][r]",    "S_M00011[c][m]",   "S_M00012[c][m][r]",    "S_M00018[c][m][r]",    "S_M00020[c][m][r]",    "S_M00022[c][m]",   "S_M00023[c][m][r]",    "S_M00044[c][m]",   "S_M00049[c][x]", 
"S_M00054[c][m]",   "S_M00100[c][m]",   "S_M00101[c][m][r]",    "S_M00116[c][m]",   "S_M00122[c][m]",   "S_M00123[c][m][r]",    "S_M00127[c][m][r]",    "S_M00129[c][m][r]",    "S_M00172[m][x]",   "S_M00261[c][m]", 
"S_M00263[c][m]",   "S_M00342[c][m]",   "S_M00343[c][m][r]",    "S_M00702[c][m]",   "S_M00715[c][x]",   "S_M00778[c][m]",   "S_M00783[c][x]",   "S_M00790[c][m]",   "S_M00843[c][m]",   "S_M00849[m][x]", 
"S_M00873[c][m]",   "S_M00879[c][x]",   "S_M00885[m][x]",   "S_M00887[c][m]",   "S_M01075[c][r]",   "S_M01141[c][m][r][x]",     "S_M01191[c][m][r][x]",     "S_M01236[c][m][r]",    "S_M01237[c][m][r]",    "S_M01573[m][x]", 
"S_M01724[c][m][r]",    "S_M01726[c][m]",   "S_M01727[c][m]",   "S_M01729[c][m]",   "S_M01770[c][m]",   "S_M01775[c][m]",   "S_M01776[c][m]",   "S_M01777[c][m]",   "S_M02051[c][m]",   "S_M02052[c][m][r]", 
"S_M02102[c][m]",   "S_M02103[c][m]",   "S_M02107[c][m]",   "S_M02112[c][r][x]",    "S_M02611[c][m]",   "S_M02612[c][m][r]",    "S_M02616[c][m]",   "S_M02637[c][m][r]",    "S_M02638[c][m]",   "S_M02694[c][m]", 
"S_M02973[c][m]",   "S_M02976[c][m]",   "S_M03014[c][m]",   "S_M03016[c][x]",   "S_M03019[m][x]",   "S_M03022[m][x]",   "S_M03047[c][r][x]",    "S_M03050[c][m][r]",    "S_M03116[c][m]",   "S_methf[c][m]", 
"S_minohp[c][n]",   "S_nadph[c][m][r][x]",  "S_nmn[c][m][n]",   "S_nrvnccoa[c][r][x]",  "S_occoa[c][m][x]",     "S_octdececoa[c][m]",   "S_octdececrn[c][m]",   "S_octe5coa[m][x]",     "S_od2coa[c][m][x]",    "S_odecoa[c][m][r][x]", 
"S_omhdecacid[c][r]",   "S_pacald[c][m]",   "S_pail35p_hs[c][n]",   "S_pail45p_hs[c][n]",   "S_pail4p_hs[c][n]",    "S_pail5p_hs[c][n]",    "S_pan4p[c][m]",    "S_pap[c][g]",  "S_paps[c][g]",     "S_phytcoa[c][x]", 
"S_pmtcoa[c][m][r][x]",     "S_ppcoa[c][m][x]",     "S_ppmi12346p[c][n]",   "S_ppp9[c][m]",     "S_pppg9[c][m]",    "S_prgnlone[c][m][r]",  "S_pristanal[c][x]",    "S_pristcoa[c][x]",     "S_profvscoa[c][x]",    "S_ptdcacoa[c][m][r]", 
"S_ptdcacrn[c][m]",     "S_retinal_cis_13[c][r]",   "S_rsv[c][r]",  "S_rsvlac[c][r]",   "S_sbcoa[c][x]",    "S_sebcoa[c][x]",   "S_Ser_Gly_Ala_X_Gly[l][r]",    "S_Ser_Thr[g][l]",  "S_Ssq23epx[c][r]",     "S_stcoa[c][m][r][x]", 
"S_strdnccoa[c][m][r][x]",  "S_strdnccrn[c][m][r]",     "S_succoa[c][m]",   "S_tdcoa[c][m][r][x]",  "S_tetdecdicoa[m][x]",  "S_tethex3coa[c][r][x]",    "S_tetpent3coa[c][r][x]",   "S_tetpent6coa[c][r][x]",   "S_tettet6coa[c][r][x]",    "S_thcrm_hs[c][g][l]", 
"S_tmndnccoa[c][m][r][x]",  "S_tmndnccrn[c][m][r]",     "S_Tn_antigen[g][l]",   "S_ttccoa[c][r][x]",    "S_uacgam[c][g][r]",    "S_udpacgal[c][g][l]",  "S_udpgal[c][g][n][r]",     "S_vacccoa[c][m][r]",   "S_vacccrn[c][m]",  "S_xser[g][r]", 
"S_zymst[c][r]",    "S_zymstnl[c][r]"                               
/                                   
                                    
BioCompound_Class6(biocompound) "metabolites participate in the overall (intracellular and extracellular) compartments"                                 
/                                   
"S_10fthf[c][e][l][m]",     "S_10fthf5glu[c][e][l][m]",     "S_10fthf6glu[c][e][l][m]",     "S_10fthf7glu[c][e][l][m]",     "S_11docrtsl[c][e][m][r]",  "S_11docrtstrn[c][e][m][r]",    "S_12dhchol[c][e]",     "S_12HPET[c][e][r]",    "S_12htacr[c][e][r]",   "S_12ppd_R[c][e]", 
"S_13_cis_retn[c][e][r]",   "S_13_cis_retnglc[c][e][r]",    "S_14hmdz[c][e][r]",    "S_15HPET[c][e][n][r][x]",  "S_15kprostgf2[c][e]",  "S_1a25dhvitd2[c][e][m]",   "S_1hibup_S[c][e][r]",  "S_1hibupglu_S[c][e][r]",   "S_1hmdgluc[c][e][r]",  "S_1mncam[c][e]", 
"S_1ohmdz[c][e][r]",    "S_21hprgnlone[c][e]",  "S_24nph[c][e]",    "S_2h3mv[c][e]",    "S_2hatvacid[c][e][r]",     "S_2hatvlac[c][e][r]",  "S_2hatvlacgluc[c][e][r]",  "S_2hb[c][e]",  "S_2hibup_R[c][e][r]",  "S_2hibup_S[c][e][r]", 
"S_2hibupglu_S[c][e][r]",   "S_2hiv[c][e]",     "S_2m3hbu[c][e][m]",    "S_2mcit[c][e]",    "S_2obut[c][e][m]",     "S_2oxoadp[c][e][m]",   "S_2pg[c][e]",  "S_34dhoxmand[c][e][m]",    "S_34dhoxpeg[c][e]",    "S_34dhpe[c][e]", 
"S_34hpl[c][e][m]",     "S_34hpp[c][e]",    "S_35cgmp[c][e][g][n]",     "S_35diotyr[c][e]",     "S_35dsmv[c][e][r]",    "S_3aib[c][e][m]",  "S_3aib_D[c][e][m]",    "S_3bcrn[c][e]",    "S_3ddcrn[c][e]",   "S_3deccrn[c][e]", 
"S_3dhcdchol[c][e]",    "S_3dhchol[c][e]",  "S_3dhdchol[c][e]",     "S_3dhlchol[c][e]",     "S_3h3mglt[c][e]",  "S_3hadpac[c][e][x]",   "S_3hanthrn[c][e]",     "S_3hibup_R[c][e][r]",  "S_3hibup_S[c][e][r]",  "S_3hibupglu_S[c][e][r]", 
"S_3hivac[c][e][m]",    "S_3hlvstacid[c][e]",   "S_3hmp[c][e][m]",  "S_3hpp[c][e][m]",  "S_3hpvs[c][e][r]",     "S_3hpvstet[c][e]",     "S_3hsmvacid[c][e]",    "S_3ispvs[c][e]",   "S_3ityr_L[c][e]",  "S_3mglutac[c][e][m]", 
"S_3mhis[c][e]",    "S_3mlda[c][e]",    "S_3mob[c][e][m]",  "S_3mop[c][e][m]",  "S_3mox4hoxm[c][e][m]",     "S_3octdece1crn[c][e]",     "S_3ohacmp[c][e][r]",   "S_3ohsebac[c][e][x]",  "S_3ohsubac[c][e][x]",  "S_3pg[c][e][m]", 
"S_3tdcrn[c][e]",   "S_3uib[c][e]",     "S_4abut[c][e][l][m]",  "S_4abutn[c][e]",   "S_4hatvacid[c][e][r]",     "S_4hatvlac[c][e][r]",  "S_4hbz[c][e][m]",  "S_4hmdgluc[c][e][r]",  "S_4hpro_LT[c][e][m]",  "S_4mop[c][e][m]", 
"S_4mptnl[c][e][m]",    "S_4nph[c][e]",     "S_4nphsf[c][e]",   "S_4ohbut[c][e][m]",    "S_4ohmdz[c][e][r]",    "S_4tmeabutn[c][e]",    "S_56dhpvs[c][e]",  "S_56dthm[c][e]",   "S_56dura[c][e]",   "S_56eppvs[c][e]", 
"S_5a2opntn[c][e][x]",  "S_5adtststerone[c][e]",    "S_5adtststerones[c][e]",   "S_5aop[c][e][m]",  "S_5dhf[c][e][l][m]",   "S_5eipenc[c][e][m]",   "S_5fthf[c][e]",    "S_5g2oxpt[c][e][x]",   "S_5hoxindoa[c][e]",    "S_5htrp[c][e]", 
"S_5mta[c][e]",     "S_5mthf[c][e]",    "S_5ohfvs[c][e][r]",    "S_5ohfvsglu[c][e][r]",     "S_5ohhexa[c][e]",  "S_5thf[c][e][l][m]",   "S_6bhglz[c][e][r]",    "S_6csmvacid[c][e]",    "S_6dhf[c][e][l][m]",   "S_6epvs[c][e]", 
"S_6hlvst[c][e][r]",    "S_6hmsmvacid[c][e]",   "S_6hsmvacid[c][e]",    "S_6htststerone[c][e][r]",  "S_6melvacid[c][e][r]",     "S_6melvst[c][e][r]",   "S_6ohfvsglu[c][e][r]",     "S_6thf[c][e][l][m]",   "S_7bhglz[c][e][r]",    "S_7dhcdchol[c][e]", 
"S_7dhchol[c][e]",  "S_7dhchsterol[c][e][r]",   "S_7dhf[c][e][l][m]",   "S_7hpvs[c][e]",    "S_7klitchol[c][e]",    "S_7thf[c][e][l][m]",   "S_aact[c][e][m]",  "S_abeta_L_lysine[c][e][n]",    "S_ac[c][e][g][m][x]",  "S_acac[c][e][m][x]", 
"S_acald[c][e][m]",     "S_acetone[c][e][m]",   "S_acgal[c][e][g][l]",  "S_acgam[c][e][l]",     "S_acglu[c][e][m]",     "S_acgly[c][e][m]",     "S_ach[c][e][n]",   "S_aclys[c][e]",    "S_acmana[c][e][r]",    "S_acmp[c][e][r]", 
"S_acnacngalgbside_hs[c][e][g]",    "S_acnam[c][e][n]",     "S_acngalacglcgal14acglcgalgluside_hs[c][e][g]",    "S_acrn[c][e][x]",  "S_ade[c][e]",  "S_adn[c][e][m]",   "S_adp[c][e][g][l][m][n][r]",   "S_adpac[c][e][x]",     "S_adpman[c][e]",   "S_adpoh[c][e]", 
"S_adprib[c][e]",   "S_adrn[c][e][r]",  "S_adrnl[c][e]",    "S_aflatoxin[c][e]",    "S_ahcys[c][e][m][r]",  "S_aicar[c][e]",    "S_ak2lgchol_hs[c][e]",     "S_akg[c][e][m][x]",    "S_ala_B[c][e][m]",     "S_ala_D[c][e][x]", 
"S_ala_L[c][e][x]",     "S_aldstrn[c][e][m]",   "S_alltn[c][e]",    "S_am19cs[c][e][r]",    "S_am1csa[c][e][r]",    "S_am9csa[c][e][r]",    "S_amet[c][e][m][r]",   "S_ametam[c][e]",   "S_amp[c][e][g][m][n][r][x]",   "S_andrstandn[c][e][r]", 
"S_andrstrn[c][e][r]",  "S_antipyrene[c][e]",   "S_aprgstrn[c][e]",     "S_aqcobal[c][e]",  "S_arab_L[c][e]",   "S_arach[c][e][r]",     "S_arachd[c][e][n][r][x]",  "S_arg_D[c][e][x]",     "S_arg_L[c][e][m]",     "S_ascb_L[c][e]", 
"S_asn_L[c][e][m]",     "S_asp_D[c][e][x]",     "S_asp_L[c][e][m]",     "S_atp[c][e][g][l][m][n][r][x]",    "S_atvacid[c][e][r]",   "S_atvlac[c][e][r]",    "S_avite1[c][e]",   "S_bhb[c][e][m]",   "S_bildglcur[c][e][r]",     "S_bilglcur[c][e][r]", 
"S_bilirub[c][e][r]",   "S_biliverd[c][e]",     "S_btn[c][e]",  "S_but[c][e]",  "S_bz[c][e][r]",    "S_C01601[c][e]",   "S_C02470[c][e]",   "S_C02528[c][e][r]",    "S_C04717[c][e]",   "S_C04805[c][e][m]", 
"S_C05300[c][e][r]",    "S_C05767[c][e]",   "S_C05770[c][e]",   "S_C05957[c][e]",   "S_C06314[c][e]",   "S_C06315[c][e]",   "S_c101crn[c][e]",  "S_c10crn[c][e]",   "S_C11695[c][e]",   "S_c12dc[c][e]", 
"S_C13856[c][e]",   "S_C14768[c][e]",   "S_C14769[c][e]",   "S_C14770[c][e]",   "S_C14771[c][e]",   "S_C14825[c][e]",   "S_C14826[c][e]",   "S_c16dc[c][e]",    "S_c3dc[c][e]",     "S_c4crn[c][e][x]", 
"S_c4dc[c][e]",     "S_c6crn[c][e]",    "S_c81crn[c][e]",   "S_c8crn[c][e]",    "S_ca2[c][e]",  "S_camp[c][e][g]",  "S_caproic[c][e]",  "S_caribup_s[c][e][r]",     "S_caribupglu_S[c][e][r]",  "S_carn[c][e]", 
"S_caro[c][e]",     "S_cbasp[c][e]",    "S_cdca24g[c][e][r]",   "S_cdca3g[c][e][r]",    "S_cdp[c][e][m][n]",    "S_cdpea[c][e]",    "S_CE0074[c][e]",   "S_CE1261[c][e]",   "S_CE1273[c][e]",   "S_CE1310[c][e][m]", 
"S_CE1447[c][e]",   "S_CE1918[c][e]",   "S_CE2006[c][e]",   "S_CE2047[c][e]",   "S_CE2049[c][e]",   "S_CE2172[c][e]",   "S_CE2510[c][e][r]",    "S_CE2537[c][e]",   "S_CE2705[c][e]",   "S_CE2838[c][e]", 
"S_CE2839[c][e]",   "S_CE4877[c][e]",   "S_CE4969[c][e][m]",    "S_CE5025[c][e]",   "S_CE5026[c][e]",   "S_CE5304[c][e]",   "S_CE5629[c][e]",   "S_CE6205[c][e]",   "S_CE6247[c][e]",   "S_CE7081[c][e][r]", 
"S_CE7085[c][e]",   "S_CE7090[c][e]",   "S_CE7096[c][e]",   "S_CE7172[c][e]",   "S_cgly[c][e]",     "S_chol[c][e][n]",  "S_cholate[c][e][m][r][x]",     "S_cholp[c][e][g][l]",  "S_chsterol[c][e][g][m][r]",    "S_chsterols[c][e]", 
"S_chtn[c][e]",     "S_cit[c][e][m]",   "S_citr_L[c][e]",   "S_cl[c][e]",   "S_clpnd[c][e][r]",     "S_cmp[c][e][g][m][n][r]",  "S_co[c][e]",   "S_co2[c][e][m][r][x]",     "S_coke[c][e][r]",  "S_coprost[c][e]", 
"S_core4[e][g]",    "S_cortsn[c][e][r]",    "S_coumarin[c][e]",     "S_creat[c][e]",    "S_crm_hs[c][e][g][l][n][r]",   "S_crmp_hs[c][e]",  "S_crn[c][e][m][r][x]",     "S_crtsl[c][e][m][r]",  "S_crtstrn[c][e][m]",   "S_crvnc[c][e][r]", 
"S_crvs[c][e][r]",  "S_crvsm24[c][e][r]",   "S_csa[c][e][r]",   "S_csn[c][e]",  "S_cspg_a[e][g][l]",    "S_cspg_c[e][g]",   "S_cspg_d[e][g]",   "S_cspg_e[e][g][l]",    "S_ctp[c][e][m][n]",    "S_cys_L[c][e][m]", 
"S_cytd[c][e][m]",  "S_dad_2[c][e]",    "S_dag_hs[c][e][g][r]",     "S_dca[c][e][r]",   "S_dchac[c][e]",    "S_dcmp[c][e][m][n]",   "S_dcsptn1[c][e][r]",   "S_dcyt[c][e][m][n]",   "S_ddca[c][e][r]",  "S_ddeccrn[c][e]", 
"S_ddece1crn[c][e]",    "S_decdicrn[c][e]",     "S_deoxfvs[c][e][x]",   "S_dgchol[c][e][x]",    "S_dgmp[c][e][m]",  "S_dgsn[c][e][m]",  "S_dgtp[c][e][m][n]",   "S_dhap[c][e][m]",  "S_dhbpt[c][e]",    "S_dhcholestanate[c][e][r]", 
"S_dhdascb[c][e]",  "S_dhea[c][e][r]",  "S_dheas[c][e][r]",     "S_dhf[c][e][l][m]",    "S_din[c][e]",  "S_ditp[c][e]",     "S_dlnlcg[c][e][l][r]",     "S_dmantipyrine[c][e]",     "S_dmhptcrn[c][e][m]",  "S_doco13ac[c][e][r]", 
"S_docosac[c][e][r]",   "S_dodecanac[c][e]",    "S_dolichol_L[c][e]",   "S_dopa[c][e]",     "S_dopa3glcur[c][e]",   "S_dopa4glcur[c][e]",   "S_dopasf[c][e]",   "S_drib[c][e]",     "S_dsmsterol[c][e][r]",     "S_dspvs[c][e]", 
"S_dtdp[c][e][m][n]",   "S_dtmp[c][e][m]",  "S_dttp[c][e][m][n]",   "S_duri[c][e][m]",  "S_dxtrn[c][e]",    "S_eaflatoxin[c][e]",   "S_ebastine[c][e][r]",  "S_ebastineoh[c][e][r]",    "S_egme[c][e][r]",  "S_eic21114tr[c][e]", 
"S_eicostet[c][e][r]",  "S_eidi1114ac[c][e]",   "S_elaid[c][e][r]",     "S_elaidcrn[c][e][m]",  "S_epoxtac[c][e][r]",   "S_estradiol[c][e][r]",     "S_estriol[c][e][r]",   "S_estrone[c][e][r]",   "S_estrones[c][e][r]",  "S_etha[c][e]", 
"S_ethamp[c][e][r]",    "S_ethmalac[c][e]",     "S_etoh[c][e]",     "S_f1a[e][g][l]",   "S_fald[c][e][l]",  "S_fdp[c][e]",  "S_fe2[c][e][m]",   "S_fe3[c][e]",  "S_fmn[c][e]",  "S_fol[c][e][m]", 
"S_for[c][e][m][r]",    "S_forglu[c][e]",   "S_fru[c][e]",  "S_fuc_L[c][e][l]",     "S_fuc13galacglcgal14acglcgalgluside_hs[c][e][g]",  "S_fuc14galacglcgalgluside_hs[c][e][g]",    "S_fucacgalfucgalacglcgalgluside_hs[c][e]",     "S_fucfuc12gal14acglcgalgluside_hs[c][e][g]",   "S_fucfucfucgalacglc13galacglcgal14acglcgalgluside_hs[c][e][g]",    "S_fucfucgalacglcgalgluside_hs[c][e][g]", 
"S_fucgal14acglcgalgluside_hs[c][e][g]",    "S_fucgalfucgalacglcgalgluside_hs[c][e]",   "S_fum[c][e][m]",   "S_fvs[c][e][r][x]",    "S_g3pc[c][e]",     "S_gal[c][e][l]",   "S_galacglcgalgbside_hs[c][e][g]",  "S_galgalfucfucgalacglcgalacglcgal14acglcgalgluside_hs[c][e][g]",   "S_galgalgalthcrm_hs[c][e][g]",     "S_galgluside_hs[c][e][g][r]", 
"S_galt[c][e]",     "S_gam[c][e]",  "S_gbside_hs[c][e][g][l]",  "S_gchola[c][e]",   "S_gd3_hs[c][e][g][l][m]",  "S_gdp[c][e][g][m]",    "S_glc_D[c][e][l][r]",  "S_glc3meacp[c][e][r]",     "S_glcr[c][e]",     "S_glcur[c][e][l][r]", 
"S_gln_L[c][e][m]",     "S_glu_L[c][e][l][m]",  "S_gluside_hs[c][e][g][l][r]",  "S_glutcon[c][e][m]",   "S_glx[c][e][m][x]",    "S_gly[c][e][m][x]",    "S_glyald[c][e][m]",    "S_glyc[c][e][m]",  "S_glyc_R[c][e][m]",    "S_glyc_S[c][e]", 
"S_glyc2p[c][e]",   "S_glyc3p[c][e][m]",    "S_glyclt[c][e][m][x]",     "S_glygn2[c][e]",   "S_glz[c][e][r]",   "S_gm1_hs[c][e][g][l][n]",  "S_gmp[c][e][g][n]",    "S_gq1b_hs[c][e]",  "S_gsn[c][e]",  "S_gt1a_hs[c][e]", 
"S_gthox[c][e][m][r]",  "S_gthrd[c][e][m][r]",  "S_gtp[c][e][m]",   "S_gua[c][e]",  "S_gudac[c][e]",    "S_h[c][e][g][i][l][m][n][r][x]",   "S_h2o[c][e][g][l][m][n][r][x]",    "S_h2o2[c][e][l][m][r][x]",     "S_ha[e][l]",   "S_ha_pre1[e][l]", 
"S_HC00900[c][e][m]",   "S_HC02020[c][e][r]",   "S_HC02180[c][e][r]",   "S_HC02187[c][e]",  "S_HC02191[c][e][r]",   "S_HC02192[c][e]",  "S_HC02193[c][e]",  "S_HC02194[c][e]",  "S_HC02195[c][e]",  "S_HC02196[c][e]", 
"S_HC02197[c][e]",  "S_HC02198[c][e]",  "S_HC02202[c][e]",  "S_HC02203[c][e]",  "S_HC02204[c][e]",  "S_HC02205[c][e]",  "S_HC02206[c][e]",  "S_HC02207[c][e]",  "S_HC02208[c][e]",  "S_HC02210[c][e]", 
"S_HC02213[c][e]",  "S_HC02214[c][e]",  "S_HC02216[c][e]",  "S_HC02217[c][e][r]",   "S_HC02220[c][e]",  "S_hca24g[c][e][r]",    "S_hco3[c][e][m]",  "S_hcoumarin[c][e]",    "S_hcys_L[c][e]",   "S_hdca[c][e][l][r][x]", 
"S_hdca24g[c][e][r]",   "S_hdca6g[c][e][r]",    "S_hdcea[c][e][m][r]",  "S_hdcecrn[c][e]",  "S_hdd2crn[c][e][m]",   "S_hestratriol[c][e][l][r]",    "S_hexc[c][e][r]",  "S_hexdiac[c][e][r]",   "S_hexgly[c][e]",   "S_hgentis[c][e]", 
"S_his_L[c][e]",    "S_hista[c][e]",    "S_hmcr[c][e]",     "S_hom_L[c][e]",    "S_homoval[c][e][m]",   "S_hpdca[c][e][r]",     "S_hspg[e][g][l]",  "S_htaxol[c][e]",   "S_hxa[c][e][m][x]",    "S_hxan[c][e]", 
"S_hxcoa[c][e][m][x]",  "S_hyochol[c][e][r]",   "S_i[c][e]",    "S_ibup_R[c][e][r]",    "S_ibup_S[c][e][r]",    "S_ibupgluc[c][e][r]",  "S_icdchol[c][e]",  "S_icit[c][e][m][x]",   "S_idour[c][e][l]",     "S_idp[c][e][m]", 
"S_IL6_L_lysine[c][e][n]",  "S_ile_L[c][e]",    "S_im4ac[c][e]",    "S_imp[c][e]",  "S_ind3ac[c][e][m]",    "S_inost[c][e][r]",     "S_ins[c][e]",  "S_isochol[c][e]",  "S_isolvstacid[c][e]",  "S_itacon[c][e][m]", 
"S_itp[c][e][m]",   "S_k[c][e][g]",     "S_ksii_core2[e][g]",   "S_ksii_core4[e][g]",   "S_kynate[c][e]",   "S_L2aadp[c][e][m]",    "S_lac_D[c][e]",    "S_lac_L[c][e][m][x]",  "S_lanost[c][e][r]",    "S_lca24g[c][e][r]", 
"S_lca3g[c][e][r]",     "S_Lcyst[c][e]",    "S_Lcystin[c][e]",  "S_leu_L[c][e]",    "S_leuktrA4[c][e]",     "S_leuktrB4[c][e][m][r][x]",    "S_leuktrB4wcooh[c][e][m][r][x]",   "S_leuktrB4woh[c][e][m][r]",    "S_leuktrC4[c][e]",     "S_leuktrD4[c][e]", 
"S_leuktrE4[c][e]",     "S_leuktrF4[c][e]",     "S_lgnc[c][e][r]",  "S_Lhcystin[c][e]",     "S_Lkynr[c][e]",    "S_lneldc[c][e][r]",    "S_lneldccrn[c][e][m]",     "S_lnlc[c][e][l][r]",   "S_lnlccrn[c][e][m][x]",    "S_lnlnca[c][e][l][r]", 
"S_lnlncg[c][e][l][r]",     "S_lpchol_hs[c][e]",    "S_lstn[c][e][r]",  "S_lstnm7[c][e][r]",    "S_lthstrl[c][e][r]",   "S_lvst[c][e][r]",  "S_lys_L[c][e]",    "S_M00003[c][e][r]",    "S_M00008[c][e][r]",    "S_M00010[c][e][r]", 
"S_M00017[c][e][r]",    "S_M00019[c][e][r]",    "S_M00021[c][e][r]",    "S_M00115[c][e]",   "S_M00117[c][e][r]",    "S_M00260[c][e]",   "S_M00265[c][e]",   "S_M00315[c][e]",   "S_M00341[c][e][r]",    "S_M01197[c][e][r]", 
"S_M01207[c][e][r]",    "S_M01235[c][e][r]",    "S_M01238[c][e][r]",    "S_M01582[c][e][r]",    "S_M01870[e][g]",   "S_M01881[c][e]",   "S_M01989[c][e]",   "S_M02053[c][e][r]",    "S_M02108[c][e]",   "S_M02155[c][e][r]", 
"S_M02446[c][e]",   "S_M02447[c][e]",   "S_M02449[c][e]",   "S_M02451[c][e]",   "S_M02457[c][e][r]",    "S_M02613[c][e][r]",    "S_M02745[c][e][r]",    "S_M03045[c][e][r]",    "S_M03051[c][e][r]",    "S_M03117[c][e]", 
"S_M03131[c][e]",   "S_M03134[c][e]",   "S_M03153[c][e][r]",    "S_mag_hs[c][e]",   "S_mal_L[c][e][m][x]",  "S_malt[c][e]",     "S_malttr[c][e]",   "S_maltttr[c][e]",  "S_man[c][e][l]",   "S_mdz[c][e][r]", 
"S_meoh[c][e][l]",  "S_mepi[c][e]",     "S_met_L[c][e][m]",     "S_mev_R[c][e]",    "S_mhglz[c][e][r]",     "S_mhista[c][e]",   "S_mi1p_D[c][e]",   "S_mlthf[c][e][m]",     "S_mma[c][e]",  "S_mthgxl[c][e]", 
"S_n2m2nmasn[e][l]",    "S_n5m2masn[c][e][g]",  "S_na1[c][e][g]",   "S_nac[c][e]",  "S_nad[c][e][m][n][r][x]",  "S_nadh[c][e][m][r][x]",    "S_nadp[c][e][m][r][x]",    "S_ncam[c][e]",     "S_nfdac[c][e][r]",     "S_nfdoh[c][e][r]", 
"S_nh4[c][e][m][n][r][x]",  "S_nicrnt[c][e][n]",    "S_no[c][e]",   "S_normete_L[c][e]",    "S_nrpphr[c][e]",   "S_nrpphrsf[c][e]",     "S_nrvnc[c][e][r]",     "S_nwharg[c][e]",   "S_o2[c][e][m][n][r][x]",   "S_o2s[c][e][m]", 
"S_oaa[c][e][m][x]",    "S_oagd3_hs[c][e][g]",  "S_ocdca[c][e][r]",     "S_ocdcea[c][e][l][r]",     "S_octa[c][e]",     "S_odecrn[c][e][m][r]",     "S_oh1[c][e]",  "S_orn[c][e][m]",   "S_orn_D[c][e][x]",     "S_orot[c][e]", 
"S_orot5p[c][e]",   "S_oxa[c][e][x]",   "S_oxyp[c][e]",     "S_pa_hs[c][e][m][r]",  "S_pac[c][e][m]",   "S_paf_hs[c][e]",   "S_pail_hs[c][e][n][r]",    "S_pailar_hs[c][e]",    "S_pailpalm_hs[c][e]",  "S_pchol_hs[c][e][g][r]", 
"S_pchol2linl_hs[c][e]",    "S_pchol2ole_hs[c][e]",     "S_pchol2palm_hs[c][e]",    "S_pchol2ste_hs[c][e]",     "S_pcholar_hs[c][e]",   "S_pcholdoc_hs[c][e]",  "S_pcholeic_hs[c][e]",  "S_pcholet_hs[c][e]",   "S_pcholhep_hs[c][e]",  "S_pchollinl_hs[c][e]", 
"S_pcholmyr_hs[c][e]",  "S_pcholn15_hs[c][e]",  "S_pcholn183_hs[c][e]",     "S_pcholn1836_hs[c][e]",    "S_pcholn19_hs[c][e]",  "S_pcholn201_hs[c][e]",     "S_pcholn203_hs[c][e]",     "S_pcholn204_hs[c][e]",     "S_pcholn205_hs[c][e]",     "S_pcholn224_hs[c][e]", 
"S_pcholn225_hs[c][e]",     "S_pcholn2254_hs[c][e]",    "S_pcholn226_hs[c][e]",     "S_pcholn24_hs[c][e]",  "S_pcholn261_hs[c][e]",     "S_pcholn28_hs[c][e]",  "S_pcholn281_hs[c][e]",     "S_pcholole_hs[c][e]",  "S_pcholpalm_hs[c][e]",     "S_pcholpalme_hs[c][e]", 
"S_pcholste_hs[c][e]",  "S_pcollg5hlys[c][e]",  "S_pcrn[c][e][x]",  "S_pe_hs[c][e][r]",     "S_pe12_hs[c][e]",  "S_pe13_hs[c][e]",  "S_pe14_hs[c][e]",  "S_pe15_hs[c][e]",  "S_pe161_hs[c][e]",     "S_pe17_hs[c][e]", 
"S_pe203_hs[c][e]",     "S_pe224_hs[c][e]",     "S_pe226_hs[c][e]",     "S_pe2linl_hs[c][e]",   "S_pear_hs[c][e]",  "S_pedh203_hs[c][e]",   "S_pelinl_hs[c][e]",    "S_peole_hs[c][e]",     "S_pep[c][e]",  "S_pepalm_hs[c][e]", 
"S_peplys[c][e]",   "S_peptide[c][e]",  "S_peste_hs[c][e]",     "S_pglyc_hs[c][e]",     "S_phe_L[c][e][m]",     "S_pheacgly[c][e][m]",  "S_pheme[c][e][m]",     "S_phlac[c][e]",    "S_phpyr[c][e]",    "S_phyt[c][e][x]", 
"S_pi[c][e][g][l][m][n][r]",    "S_pmtcrn[c][e][m]",    "S_pnto_R[c][e]",   "S_ppa[c][e][m]",   "S_ppbng[c][e]",    "S_ppi[c][e][m][n][r][x]",  "S_ppiogly[c][e][m]",   "S_prgstrn[c][e][r]",   "S_prist[c][e][x]",     "S_pro_D[c][e]", 
"S_pro_L[c][e][m]",     "S_profvs[c][e]",   "S_prostgd2[c][e]",     "S_prostge1[c][e]",     "S_prostge2[c][e][r]",  "S_prostgf2[c][e]",     "S_prostgh2[c][e][r]",  "S_prostgi2[c][e]",     "S_ps_hs[c][e]",    "S_pser_L[c][e]", 
"S_ptdca[c][e][r]",     "S_ptrc[c][e]",     "S_ptth[c][e][m]",  "S_ptvst[c][e][r]",     "S_ptvstlac[c][e][r]",  "S_ptvstm13[c][e][r]",  "S_pvs[c][e][r]",   "S_pvsgluc[c][e]",  "S_pydam[c][e]",    "S_pydx[c][e]", 
"S_pydxn[c][e]",    "S_pyr[c][e][m][x]",    "S_q10[c][e][m]",   "S_q10h2[c][e][m]",     "S_rbl_D[c][e]",    "S_retfa[c][e]",    "S_retinal[c][e][r]",   "S_retinol[c][e][r]",   "S_rib_D[c][e]",    "S_ribflv[c][e]", 
"S_Rtotal[c][e][g][l]",     "S_Rtotal2[c][e]",  "S_s2l2fn2m2masn[e][l]",    "S_s2l2n2m2m[c][e][l]",     "S_s2l2n2m2masn[e][l]",     "S_saccrp_L[c][e][m]",  "S_sbt_D[c][e]",    "S_sebacid[c][e][x]",   "S_selmeth[c][e]",  "S_ser_L[c][e][m][x]", 
"S_slfcys[c][e]",   "S_smv[c][e][r]",   "S_smvacid[c][e]",  "S_so3[c][e]",  "S_so4[c][e][l][r]",    "S_spc_hs[c][e]",   "S_sph1p[c][e][n]",     "S_sphgn[c][e][g][n]",  "S_sphings[c][e][g][l][n]",     "S_sphmyln_hs[c][e][g][l][r]", 
"S_sphmyln180241_hs[c][e]",     "S_sphmyln18114_hs[c][e]",  "S_sphmyln18115_hs[c][e]",  "S_sphmyln18116_hs[c][e]",  "S_sphmyln181161_hs[c][e]",     "S_sphmyln18117_hs[c][e]",  "S_sphmyln18118_hs[c][e]",  "S_sphmyln181181_hs[c][e]",     "S_sphmyln18120_hs[c][e]",  "S_sphmyln181201_hs[c][e]", 
"S_sphmyln18121_hs[c][e]",  "S_sphmyln18122_hs[c][e]",  "S_sphmyln181221_hs[c][e]",     "S_sphmyln18123_hs[c][e]",  "S_sphmyln1824_hs[c][e]",   "S_sphmyln1825_hs[c][e]",   "S_sphs1p[c][e][n]",    "S_spmd[c][e]",     "S_sprm[c][e]",     "S_sql[c][e][r]", 
"S_srtn[c][e]",     "S_stcrn[c][e][m][r]",  "S_strdnc[c][e][l][r]",     "S_subeac[c][e][x]",    "S_subgly[c][e]",   "S_succ[c][e][m][x]",   "S_sucsal[c][e][m]",    "S_T4hcinnm[c][e][m]",  "S_tacr[c][e][r]",  "S_tagat_D[c][e]", 
"S_tau_L_lysine[c][e][n]",  "S_taur[c][e]",     "S_taxol[c][e]",    "S_tchola[c][e]",   "S_tdchola[c][e]",  "S_tdechola[c][e]",     "S_tetdec2crn[c][e]",   "S_tetdece1crn[c][e]",  "S_tethex3[c][e][r]",   "S_tetpent3[c][e][r]", 
"S_tetpent6[c][e][r]",  "S_tettet6[c][e][r]",   "S_thbpt[c][e]",    "S_thcholstoic[c][e][m][r][x]",     "S_thf[c][e][l][m]",    "S_thm[c][e]",  "S_thmtp[c][e]",    "S_thr_L[c][e]",    "S_thym[c][e]",     "S_thymd[c][e][m]", 
"S_thyochol[c][e]",     "S_thyox_L[c][e]",  "S_tiggly[c][e][m]",    "S_tlacfvs[c][e][r]",   "S_tmlys[c][e]",    "S_tmndnc[c][e][r]",    "S_TNFA_L_lysine[c][e][n]",     "S_tre[c][e]",  "S_triodthy[c][e]",     "S_triodthysuf[c][e]", 
"S_tripvs[c][e]",   "S_trp_L[c][e]",    "S_trypta[c][e]",   "S_tststerone[c][e][r]",    "S_tststerones[c][e]",  "S_ttdca[c][e][r]",     "S_ttdcea[c][e][r]",    "S_ttdcrn[c][e][m]",    "S_txa2[c][e][r]",  "S_Tyr_ggn[c][e]", 
"S_tyr_L[c][e]",    "S_uchol[c][e]",    "S_udp[c][e][g][l][n][r]",  "S_udpglcur[c][e][g][r]",   "S_ump[c][e][g][l][n][r]",  "S_ura[c][e]",  "S_urate[c][e]",    "S_urcan[c][e]",    "S_urea[c][e][m]",  "S_uri[c][e][l]", 
"S_utp[c][e][n]",   "S_vacc[c][e][r]",  "S_val_L[c][e]",    "S_vitd3[c][e]",    "S_wharachd[c][e][r]",  "S_whhdca[c][e]",   "S_whtststerone[c][e]",     "S_xan[c][e]",  "S_xmp[c][e]",  "S_xol25oh[c][e][r]", 
"S_xol27oh[c][e][m][r]",    "S_xol7ah3[c][e]",  "S_xol7aone[c][e][m][r]",   "S_xoldiolone[c][e]",   "S_xolest_hs[c][e]",    "S_xolest2_hs[c][e]",   "S_xoltri25[c][e][r]",  "S_xoltri27[c][e][r]",  "S_xtsn[c][e]",     "S_xyl_D[c][e][l]", 
"S_xylt[c][e]",     "S_xylu_D[c][e]",   "S_xylu_L[c][e]"                            
/                                   
                                    
BioCompound_Class7(biocompound) "extra-metabolites are provided by the users, not existed in the above species and metabolites"                                 
/                                   
                                    
/                                   
                                    
BioCompound_species(BioCompound, species) "biocompounds related to the model species in the various compartments of BL human model"                                 
/                                   
                                    
"S_10fthf5glu[c]".("M_10fthf5glu[c]")                                   
"S_10fthf5glu[l]".("M_10fthf5glu[l]")                                   
"S_10fthf5glu[m]".("M_10fthf5glu[m]")                                   
"S_10fthf6glu[c]".("M_10fthf6glu[c]")                                   
"S_10fthf6glu[l]".("M_10fthf6glu[l]")                                   
"S_10fthf6glu[m]".("M_10fthf6glu[m]")                                   
"S_10fthf7glu[c]".("M_10fthf7glu[c]")                                   
"S_10fthf7glu[l]".("M_10fthf7glu[l]")                                   
"S_10fthf7glu[m]".("M_10fthf7glu[m]")                                   
"S_10fthf[c]".("M_10fthf[c]")                                   
"S_10fthf[l]".("M_10fthf[l]")                                   
"S_10fthf[m]".("M_10fthf[m]")                                   
"S_11docrtsl[c]".("M_11docrtsl[c]")                                 
"S_11docrtsl[m]".("M_11docrtsl[m]")                                 
"S_11docrtsl[r]".("M_11docrtsl[r]")                                 
"S_11docrtstrn[c]".("M_11docrtstrn[c]")                                 
"S_11docrtstrn[m]".("M_11docrtstrn[m]")                                 
"S_11docrtstrn[r]".("M_11docrtstrn[r]")                                 
"S_h2o[c]".("M_h2o[c]")                                 
"S_o2[c]".("M_o2[c]")                                   
"S_h2o2[c]".("M_h2o2[c]")                                   
"S_nh4[c]".("M_nh4[c]")                                 
"S_h2o[m]".("M_h2o[m]")                                 
"S_o2[m]".("M_o2[m]")                                   
"S_h[m]".("M_h[m]")                                 
"S_nadp[m]".("M_nadp[m]")                                   
"S_1a25dhvitd2[m]".("M_1a25dhvitd2[m]")                                 
"S_h[c]".("M_h[c]")                                 
"S_1mncam[c]".("M_1mncam[c]")                                   
"S_atp[c]".("M_atp[c]")                                 
"S_adp[c]".("M_adp[c]")                                 
"S_pi[c]".("M_pi[c]")                                   
"S_h[x]".("M_h[x]")                                 
"S_nadh[x]".("M_nadh[x]")                                   
"S_nad[x]".("M_nad[x]")                                 
"S_24nph[c]".("M_24nph[c]")                                 
"S_pyr[c]".("M_pyr[c]")                                 
"S_nadp[c]".("M_nadp[c]")                                   
"S_Lcyst[c]".("M_Lcyst[c]")                                 
"S_L2aadp[c]".("M_L2aadp[c]")                                   
"S_L2aadp[m]".("M_L2aadp[m]")                                   
"S_akg[m]".("M_akg[m]")                                 
"S_akg[c]".("M_akg[c]")                                 
"S_drib[c]".("M_drib[c]")                                   
"S_nadh[c]".("M_nadh[c]")                                   
"S_nad[c]".("M_nad[c]")                                 
"S_2hb[c]".("M_2hb[c]")                                 
"S_2obut[c]".("M_2obut[c]")                                 
"S_hco3[c]".("M_hco3[c]")                                   
"S_na1[c]".("M_na1[c]")                                 
"S_2mcit[c]".("M_2mcit[c]")                                 
"S_nadh[m]".("M_nadh[m]")                                   
"S_nad[m]".("M_nad[m]")                                 
"S_2oxoadp[m]".("M_2oxoadp[m]")                                 
"S_co2[m]".("M_co2[m]")                                 
"S_2oxoadp[c]".("M_2oxoadp[c]")                                 
"S_34dhoxpeg[c]".("M_34dhoxpeg[c]")                                 
"S_amet[c]".("M_amet[c]")                                   
"S_ahcys[c]".("M_ahcys[c]")                                 
"S_34dhoxmand[c]".("M_34dhoxmand[c]")                                   
"S_34hpl[m]".("M_34hpl[m]")                                 
"S_co2[c]".("M_co2[c]")                                 
"S_34hpp[c]".("M_34hpp[c]")                                 
"S_hgentis[c]".("M_hgentis[c]")                                 
"S_35cgmp[c]".("M_35cgmp[c]")                                   
"S_35cgmp[n]".("M_35cgmp[n]")                                   
"S_3aib[m]".("M_3aib[m]")                                   
"S_glu_L[m]".("M_glu_L[m]")                                 
"S_3aib[c]".("M_3aib[c]")                                   
"S_sphgn[c]".("M_sphgn[c]")                                 
"S_3hanthrn[c]".("M_3hanthrn[c]")                                   
"S_3hmp[m]".("M_3hmp[m]")                                   
"S_glu_L[c]".("M_glu_L[c]")                                 
"S_dopa[c]".("M_dopa[c]")                                   
"S_3mob[c]".("M_3mob[c]")                                   
"S_3mop[c]".("M_3mop[c]")                                   
"S_3mop[m]".("M_3mop[m]")                                   
"S_3mox4hoxm[c]".("M_3mox4hoxm[c]")                                 
"S_h2o[l]".("M_h2o[l]")                                 
"S_pi[l]".("M_pi[l]")                                   
"S_asp_L[c]".("M_asp_L[c]")                                 
"S_asp_L[m]".("M_asp_L[m]")                                 
"S_so3[c]".("M_so3[c]")                                 
"S_pyr[m]".("M_pyr[m]")                                 
"S_adrnl[c]".("M_adrnl[c]")                                 
"S_mma[c]".("M_mma[c]")                                 
"S_nrpphr[c]".("M_nrpphr[c]")                                   
"S_4abut[c]".("M_4abut[c]")                                 
"S_4abut[m]".("M_4abut[m]")                                 
"S_4hbz[m]".("M_4hbz[m]")                                   
"S_4mptnl[c]".("M_4mptnl[c]")                                   
"S_4mptnl[m]".("M_4mptnl[m]")                                   
"S_4nphsf[c]".("M_4nphsf[c]")                                   
"S_4nph[c]".("M_4nph[c]")                                   
"S_5adtststerone[c]".("M_5adtststerone[c]")                                 
"S_5aop[c]".("M_5aop[c]")                                   
"S_5aop[m]".("M_5aop[m]")                                   
"S_5dhf[c]".("M_5dhf[c]")                                   
"S_5dhf[l]".("M_5dhf[l]")                                   
"S_5fthf[c]".("M_5fthf[c]")                                 
"S_5htrp[c]".("M_5htrp[c]")                                 
"S_srtn[c]".("M_srtn[c]")                                   
"S_5hoxindoa[c]".("M_5hoxindoa[c]")                                 
"S_5mthf[c]".("M_5mthf[c]")                                 
"S_5thf[c]".("M_5thf[c]")                                   
"S_5thf[l]".("M_5thf[l]")                                   
"S_5thf[m]".("M_5thf[m]")                                   
"S_6dhf[c]".("M_6dhf[c]")                                   
"S_6dhf[l]".("M_6dhf[l]")                                   
"S_6dhf[m]".("M_6dhf[m]")                                   
"S_6htststerone[c]".("M_6htststerone[c]")                                   
"S_6htststerone[r]".("M_6htststerone[r]")                                   
"S_6thf[c]".("M_6thf[c]")                                   
"S_6thf[l]".("M_6thf[l]")                                   
"S_6thf[m]".("M_6thf[m]")                                   
"S_7dhchsterol[r]".("M_7dhchsterol[r]")                                 
"S_7dhchsterol[c]".("M_7dhchsterol[c]")                                 
"S_7dhf[c]".("M_7dhf[c]")                                   
"S_7dhf[l]".("M_7dhf[l]")                                   
"S_7dhf[m]".("M_7dhf[m]")                                   
"S_7thf[c]".("M_7thf[c]")                                   
"S_7thf[l]".("M_7thf[l]")                                   
"S_7thf[m]".("M_7thf[m]")                                   
"S_man[c]".("M_man[c]")                                 
"S_man[l]".("M_man[l]")                                 
"S_galgluside_hs[c]".("M_galgluside_hs[c]")                                 
"S_udp[c]".("M_udp[c]")                                 
"S_h[g]".("M_h[g]")                                 
"S_galgluside_hs[g]".("M_galgluside_hs[g]")                                 
"S_udp[g]".("M_udp[g]")                                 
"S_aact[c]".("M_aact[c]")                                   
"S_mthgxl[c]".("M_mthgxl[c]")                                   
"S_aact[m]".("M_aact[m]")                                   
"S_galgalfucfucgalacglcgalacglcgal14acglcgalgluside_hs[g]".("M_galgalfucfucgalacglcgalacglcgal14acglcgalgluside_hs[g]")                                 
"S_sucsal[m]".("M_sucsal[m]")                                   
"S_xylu_L[c]".("M_xylu_L[c]")                                   
"S_h[l]".("M_h[l]")                                 
"S_4abut[l]".("M_4abut[l]")                                 
"S_acac[c]".("M_acac[c]")                                   
"S_acac[m]".("M_acac[m]")                                   
"S_acac[x]".("M_acac[x]")                                   
"S_acald[m]".("M_acald[m]")                                 
"S_acald[c]".("M_acald[c]")                                 
"S_atp[m]".("M_atp[m]")                                 
"S_adp[m]".("M_adp[m]")                                 
"S_pi[m]".("M_pi[m]")                                   
"S_hco3[m]".("M_hco3[m]")                                   
"S_amp[m]".("M_amp[m]")                                 
"S_ppi[m]".("M_ppi[m]")                                 
"S_ppa[m]".("M_ppa[m]")                                 
"S_acetone[m]".("M_acetone[m]")                                 
"S_acgal[c]".("M_acgal[c]")                                 
"S_itp[c]".("M_itp[c]")                                 
"S_idp[c]".("M_idp[c]")                                 
"S_acgal[g]".("M_acgal[g]")                                 
"S_acgal[l]".("M_acgal[l]")                                 
"S_acgam[c]".("M_acgam[c]")                                 
"S_acgam[l]".("M_acgam[l]")                                 
"S_ac[c]".("M_ac[c]")                                   
"S_acglu[m]".("M_acglu[m]")                                 
"S_ach[n]".("M_ach[n]")                                 
"S_ach[c]".("M_ach[c]")                                 
"S_cit[c]".("M_cit[c]")                                 
"S_oaa[c]".("M_oaa[c]")                                 
"S_pep[c]".("M_pep[c]")                                 
"S_acnam[c]".("M_acnam[c]")                                 
"S_acnam[n]".("M_acnam[n]")                                 
"S_acngalacglcgal14acglcgalgluside_hs[c]".("M_acngalacglcgal14acglcgalgluside_hs[c]")                                   
"S_acngalacglcgal14acglcgalgluside_hs[g]".("M_acngalacglcgal14acglcgalgluside_hs[g]")                                   
"S_acmana[c]".("M_acmana[c]")                                   
"S_o2[x]".("M_o2[x]")                                   
"S_h2o2[x]".("M_h2o2[x]")                                   
"S_orn[c]".("M_orn[c]")                                 
"S_cit[m]".("M_cit[m]")                                 
"S_icit[m]".("M_icit[m]")                                   
"S_h2o[x]".("M_h2o[x]")                                 
"S_fmn[c]".("M_fmn[c]")                                 
"S_ribflv[c]".("M_ribflv[c]")                                   
"S_acrn[c]".("M_acrn[c]")                                   
"S_amp[c]".("M_amp[c]")                                 
"S_ppi[c]".("M_ppi[c]")                                 
"S_ppa[c]".("M_ppa[c]")                                 
"S_ac[m]".("M_ac[m]")                                   
"S_ac[g]".("M_ac[g]")                                   
"S_adn[c]".("M_adn[c]")                                 
"S_ins[c]".("M_ins[c]")                                 
"S_ade[c]".("M_ade[c]")                                 
"S_gtp[c]".("M_gtp[c]")                                 
"S_gdp[c]".("M_gdp[c]")                                 
"S_gtp[m]".("M_gtp[m]")                                 
"S_gdp[m]".("M_gdp[m]")                                 
"S_ametam[c]".("M_ametam[c]")                                   
"S_camp[c]".("M_camp[c]")                                   
"S_adn[m]".("M_adn[m]")                                 
"S_adpman[c]".("M_adpman[c]")                                   
"S_adprib[c]".("M_adprib[c]")                                   
"S_crn[c]".("M_crn[c]")                                 
"S_crn[m]".("M_crn[m]")                                 
"S_adrn[c]".("M_adrn[c]")                                   
"S_fum[c]".("M_fum[c]")                                 
"S_aicar[c]".("M_aicar[c]")                                 
"S_aflatoxin[c]".("M_aflatoxin[c]")                                 
"S_cmp[c]".("M_cmp[c]")                                 
"S_cdpea[c]".("M_cdpea[c]")                                 
"S_Rtotal2[c]".("M_Rtotal2[c]")                                 
"S_urea[m]".("M_urea[m]")                                   
"S_pa_hs[c]".("M_pa_hs[c]")                                 
"S_glx[m]".("M_glx[m]")                                 
"S_gly[m]".("M_gly[m]")                                 
"S_pyr[x]".("M_pyr[x]")                                 
"S_ala_L[x]".("M_ala_L[x]")                                 
"S_glx[x]".("M_glx[x]")                                 
"S_gly[x]".("M_gly[x]")                                 
"S_ahcys[r]".("M_ahcys[r]")                                 
"S_mal_L[c]".("M_mal_L[c]")                                 
"S_mal_L[m]".("M_mal_L[m]")                                 
"S_akg[x]".("M_akg[x]")                                 
"S_prgstrn[c]".("M_prgstrn[c]")                                 
"S_xol7aone[c]".("M_xol7aone[c]")                                   
"S_xoldiolone[c]".("M_xoldiolone[c]")                                   
"S_ala_L[c]".("M_ala_L[c]")                                 
"S_asn_L[c]".("M_asn_L[c]")                                 
"S_cys_L[c]".("M_cys_L[c]")                                 
"S_ala_D[c]".("M_ala_D[c]")                                 
"S_gln_L[c]".("M_gln_L[c]")                                 
"S_gly[c]".("M_gly[c]")                                 
"S_ser_L[c]".("M_ser_L[c]")                                 
"S_thr_L[c]".("M_thr_L[c]")                                 
"S_12ppd_R[c]".("M_12ppd_R[c]")                                 
"S_etoh[c]".("M_etoh[c]")                                   
"S_ind3ac[c]".("M_ind3ac[c]")                                   
"S_ind3ac[m]".("M_ind3ac[m]")                                   
"S_prist[c]".("M_prist[c]")                                 
"S_aldstrn[c]".("M_aldstrn[c]")                                 
"S_aldstrn[m]".("M_aldstrn[m]")                                 
"S_dhap[c]".("M_dhap[c]")                                   
"S_arachd[c]".("M_arachd[c]")                                   
"S_12HPET[c]".("M_12HPET[c]")                                   
"S_15HPET[c]".("M_15HPET[c]")                                   
"S_leuktrA4[c]".("M_leuktrA4[c]")                                   
"S_h2o[r]".("M_h2o[r]")                                 
"S_o2[r]".("M_o2[r]")                                   
"S_amet[r]".("M_amet[r]")                                   
"S_amet[m]".("M_amet[m]")                                   
"S_ahcys[m]".("M_ahcys[m]")                                 
"S_imp[c]".("M_imp[c]")                                 
"S_amp[x]".("M_amp[x]")                                 
"S_amp[r]".("M_amp[r]")                                 
"S_andrstrn[c]".("M_andrstrn[c]")                                   
"S_andrstrn[r]".("M_andrstrn[r]")                                   
"S_antipyrene[c]".("M_antipyrene[c]")                                   
"S_lys_L[c]".("M_lys_L[c]")                                 
"S_aqcobal[c]".("M_aqcobal[c]")                                 
"S_arab_L[c]".("M_arab_L[c]")                                   
"S_arachd[r]".("M_arachd[r]")                                   
"S_arach[c]".("M_arach[c]")                                 
"S_arg_L[m]".("M_arg_L[m]")                                 
"S_arg_L[c]".("M_arg_L[c]")                                 
"S_orn[m]".("M_orn[m]")                                 
"S_citr_L[c]".("M_citr_L[c]")                                   
"S_so4[l]".("M_so4[l]")                                 
"S_Rtotal[c]".("M_Rtotal[c]")                                   
"S_Rtotal[l]".("M_Rtotal[l]")                                   
"S_crm_hs[l]".("M_crm_hs[l]")                                   
"S_sphings[l]".("M_sphings[l]")                                 
"S_ascb_L[c]".("M_ascb_L[c]")                                   
"S_o2s[c]".("M_o2s[c]")                                 
"S_dhdascb[c]".("M_dhdascb[c]")                                 
"S_nh4[m]".("M_nh4[m]")                                 
"S_asn_L[m]".("M_asn_L[m]")                                 
"S_asp_D[c]".("M_asp_D[c]")                                 
"S_k[c]".("M_k[c]")                                 
"S_asp_D[x]".("M_asp_D[x]")                                 
"S_oaa[m]".("M_oaa[m]")                                 
"S_atp[r]".("M_atp[r]")                                 
"S_adp[r]".("M_adp[r]")                                 
"S_atp[n]".("M_atp[n]")                                 
"S_atp[x]".("M_atp[x]")                                 
"S_gbside_hs[g]".("M_gbside_hs[g]")                                 
"S_galgalgalthcrm_hs[g]".("M_galgalgalthcrm_hs[g]")                                 
"S_galacglcgalgbside_hs[g]".("M_galacglcgalgbside_hs[g]")                                   
"S_h2o[g]".("M_h2o[g]")                                 
"S_gluside_hs[g]".("M_gluside_hs[g]")                                   
"S_dgchol[x]".("M_dgchol[x]")                                   
"S_btn[c]".("M_btn[c]")                                 
"S_ala_B[c]".("M_ala_B[c]")                                 
"S_4tmeabutn[c]".("M_4tmeabutn[c]")                                 
"S_succ[c]".("M_succ[c]")                                   
"S_caro[c]".("M_caro[c]")                                   
"S_retinal[c]".("M_retinal[c]")                                 
"S_glc_D[c]".("M_glc_D[c]")                                 
"S_bhb[m]".("M_bhb[m]")                                 
"S_bhb[c]".("M_bhb[c]")                                 
"S_hcys_L[c]".("M_hcys_L[c]")                                   
"S_met_L[c]".("M_met_L[c]")                                 
"S_bildglcur[c]".("M_bildglcur[c]")                                 
"S_bildglcur[r]".("M_bildglcur[r]")                                 
"S_bilglcur[c]".("M_bilglcur[c]")                                   
"S_bilglcur[r]".("M_bilglcur[r]")                                   
"S_biliverd[c]".("M_biliverd[c]")                                   
"S_bilirub[c]".("M_bilirub[c]")                                 
"S_bilirub[r]".("M_bilirub[r]")                                 
"S_h[r]".("M_h[r]")                                 
"S_h2o[n]".("M_h2o[n]")                                 
"S_but[c]".("M_but[c]")                                 
"S_bz[c]".("M_bz[c]")                                   
"S_bz[r]".("M_bz[r]")                                   
"S_nadp[r]".("M_nadp[r]")                                   
"S_pmtcrn[c]".("M_pmtcrn[c]")                                   
"S_hdcecrn[c]".("M_hdcecrn[c]")                                 
"S_hdd2crn[c]".("M_hdd2crn[c]")                                 
"S_hdd2crn[m]".("M_hdd2crn[m]")                                 
"S_stcrn[c]".("M_stcrn[c]")                                 
"S_odecrn[c]".("M_odecrn[c]")                                   
"S_odecrn[m]".("M_odecrn[m]")                                   
"S_co2[r]".("M_co2[r]")                                 
"S_nadh[r]".("M_nadh[r]")                                   
"S_nad[r]".("M_nad[r]")                                 
"S_ca2[c]".("M_ca2[c]")                                 
"S_h2o2[m]".("M_h2o2[m]")                                   
"S_nh4[r]".("M_nh4[r]")                                 
"S_glc_D[r]".("M_glc_D[r]")                                 
"S_pi[r]".("M_pi[r]")                                   
"S_ppi[r]".("M_ppi[r]")                                 
"S_prostge1[c]".("M_prostge1[c]")                                   
"S_prostge2[c]".("M_prostge2[c]")                                   
"S_prostgf2[c]".("M_prostgf2[c]")                                   
"S_inost[c]".("M_inost[c]")                                 
"S_pail_hs[c]".("M_pail_hs[c]")                                 
"S_ctp[c]".("M_ctp[c]")                                 
"S_pa_hs[m]".("M_pa_hs[m]")                                 
"S_ctp[m]".("M_ctp[m]")                                 
"S_dag_hs[c]".("M_dag_hs[c]")                                   
"S_pchol_hs[c]".("M_pchol_hs[c]")                                   
"S_pe_hs[c]".("M_pe_hs[c]")                                 
"S_crm_hs[c]".("M_crm_hs[c]")                                   
"S_crmp_hs[c]".("M_crmp_hs[c]")                                 
"S_crm_hs[g]".("M_crm_hs[g]")                                   
"S_crm_hs[r]".("M_crm_hs[r]")                                   
"S_gluside_hs[c]".("M_gluside_hs[c]")                                   
"S_gluside_hs[r]".("M_gluside_hs[r]")                                   
"S_cgly[c]".("M_cgly[c]")                                   
"S_chsterol[r]".("M_chsterol[r]")                                   
"S_xol25oh[r]".("M_xol25oh[r]")                                 
"S_chol[c]".("M_chol[c]")                                   
"S_chol[n]".("M_chol[n]")                                   
"S_cholp[c]".("M_cholp[c]")                                 
"S_cholate[c]".("M_cholate[c]")                                 
"S_cholp[g]".("M_cholp[g]")                                 
"S_cholp[l]".("M_cholp[l]")                                 
"S_chsterol[c]".("M_chsterol[c]")                                   
"S_chsterol[m]".("M_chsterol[m]")                                   
"S_chtn[c]".("M_chtn[c]")                                   
"S_creat[c]".("M_creat[c]")                                 
"S_cl[c]".("M_cl[c]")                                   
"S_for[c]".("M_for[c]")                                 
"S_i[c]".("M_i[c]")                                 
"S_oxa[c]".("M_oxa[c]")                                 
"S_clpnd[c]".("M_clpnd[c]")                                 
"S_pglyc_hs[c]".("M_pglyc_hs[c]")                                   
"S_cmp[g]".("M_cmp[g]")                                 
"S_ppi[n]".("M_ppi[n]")                                 
"S_ctp[n]".("M_ctp[n]")                                 
"S_co2[x]".("M_co2[x]")                                 
"S_coke[r]".("M_coke[r]")                                   
"S_egme[r]".("M_egme[r]")                                   
"S_q10[m]".("M_q10[m]")                                 
"S_core4[g]".("M_core4[g]")                                 
"S_co[c]".("M_co[c]")                                   
"S_T4hcinnm[m]".("M_T4hcinnm[m]")                                   
"S_coumarin[c]".("M_coumarin[c]")                                   
"S_crn[x]".("M_crn[x]")                                 
"S_pcrn[x]".("M_pcrn[x]")                                   
"S_pcrn[c]".("M_pcrn[c]")                                   
"S_acrn[x]".("M_acrn[x]")                                   
"S_crtsl[c]".("M_crtsl[c]")                                 
"S_crtsl[m]".("M_crtsl[m]")                                 
"S_crtsl[r]".("M_crtsl[r]")                                 
"S_crtstrn[c]".("M_crtstrn[c]")                                 
"S_crtstrn[m]".("M_crtstrn[m]")                                 
"S_crvnc[c]".("M_crvnc[c]")                                 
"S_cspg_a[l]".("M_cspg_a[l]")                                   
"S_cspg_e[l]".("M_cspg_e[l]")                                   
"S_crn[r]".("M_crn[r]")                                 
"S_csn[c]".("M_csn[c]")                                 
"S_cspg_a[g]".("M_cspg_a[g]")                                   
"S_cspg_c[g]".("M_cspg_c[g]")                                   
"S_cspg_d[g]".("M_cspg_d[g]")                                   
"S_cspg_e[g]".("M_cspg_e[g]")                                   
"S_q10h2[m]".("M_q10h2[m]")                                 
"S_Lcystin[c]".("M_Lcystin[c]")                                 
"S_gthrd[c]".("M_gthrd[c]")                                 
"S_gthox[c]".("M_gthox[c]")                                 
"S_cys_L[m]".("M_cys_L[m]")                                 
"S_cytd[c]".("M_cytd[c]")                                   
"S_uri[c]".("M_uri[c]")                                 
"S_cmp[m]".("M_cmp[m]")                                 
"S_cytd[m]".("M_cytd[m]")                                   
"S_nh4[n]".("M_nh4[n]")                                 
"S_h[n]".("M_h[n]")                                 
"S_cdp[c]".("M_cdp[c]")                                 
"S_dgtp[c]".("M_dgtp[c]")                                   
"S_cmp[n]".("M_cmp[n]")                                 
"S_cdp[n]".("M_cdp[n]")                                 
"S_dgtp[n]".("M_dgtp[n]")                                   
"S_dcmp[c]".("M_dcmp[c]")                                   
"S_dcmp[n]".("M_dcmp[n]")                                   
"S_utp[c]".("M_utp[c]")                                 
"S_udp[n]".("M_udp[n]")                                 
"S_utp[n]".("M_utp[n]")                                 
"S_cdp[m]".("M_cdp[m]")                                 
"S_adp[n]".("M_adp[n]")                                 
"S_dad_2[c]".("M_dad_2[c]")                                 
"S_din[c]".("M_din[c]")                                 
"S_dag_hs[r]".("M_dag_hs[r]")                                   
"S_nh4[x]".("M_nh4[x]")                                 
"S_ala_D[x]".("M_ala_D[x]")                                 
"S_arg_D[x]".("M_arg_D[x]")                                 
"S_5g2oxpt[x]".("M_5g2oxpt[x]")                                 
"S_oaa[x]".("M_oaa[x]")                                 
"S_dcmp[m]".("M_dcmp[m]")                                   
"S_dcyt[m]".("M_dcyt[m]")                                   
"S_dcyt[n]".("M_dcyt[n]")                                   
"S_dcsptn1[c]".("M_dcsptn1[c]")                                 
"S_dcyt[c]".("M_dcyt[c]")                                   
"S_duri[c]".("M_duri[c]")                                   
"S_dolichol_L[c]".("M_dolichol_L[c]")                                   
"S_dgchol[c]".("M_dgchol[c]")                                   
"S_dgmp[m]".("M_dgmp[m]")                                   
"S_dgsn[m]".("M_dgsn[m]")                                   
"S_dgsn[c]".("M_dgsn[c]")                                   
"S_lthstrl[r]".("M_lthstrl[r]")                                 
"S_dsmsterol[r]".("M_dsmsterol[r]")                                 
"S_dheas[c]".("M_dheas[c]")                                 
"S_dheas[r]".("M_dheas[r]")                                 
"S_dhea[c]".("M_dhea[c]")                                   
"S_dhea[r]".("M_dhea[r]")                                   
"S_dhf[c]".("M_dhf[c]")                                 
"S_dhf[l]".("M_dhf[l]")                                 
"S_dhf[m]".("M_dhf[m]")                                 
"S_orot[c]".("M_orot[c]")                                   
"S_56dura[c]".("M_56dura[c]")                                   
"S_56dthm[c]".("M_56dthm[c]")                                   
"S_dhbpt[c]".("M_dhbpt[c]")                                 
"S_thbpt[c]".("M_thbpt[c]")                                 
"S_mlthf[c]".("M_mlthf[c]")                                 
"S_lac_D[c]".("M_lac_D[c]")                                 
"S_dlnlcg[c]".("M_dlnlcg[c]")                                   
"S_dgtp[m]".("M_dgtp[m]")                                   
"S_dttp[m]".("M_dttp[m]")                                   
"S_dttp[n]".("M_dttp[n]")                                   
"S_ethamp[r]".("M_ethamp[r]")                                   
"S_n5m2masn[g]".("M_n5m2masn[g]")                                   
"S_sprm[c]".("M_sprm[c]")                                   
"S_dmantipyrine[c]".("M_dmantipyrine[c]")                                   
"S_ppi[x]".("M_ppi[x]")                                 
"S_dmhptcrn[c]".("M_dmhptcrn[c]")                                   
"S_dmhptcrn[m]".("M_dmhptcrn[m]")                                   
"S_dtdp[m]".("M_dtdp[m]")                                   
"S_dtdp[c]".("M_dtdp[c]")                                   
"S_dttp[c]".("M_dttp[c]")                                   
"S_dopasf[c]".("M_dopasf[c]")                                   
"S_orn_D[x]".("M_orn_D[x]")                                 
"S_5a2opntn[x]".("M_5a2opntn[x]")                                   
"S_3pg[c]".("M_3pg[c]")                                 
"S_dtdp[n]".("M_dtdp[n]")                                   
"S_ura[c]".("M_ura[c]")                                 
"S_thym[c]".("M_thym[c]")                                   
"S_duri[m]".("M_duri[m]")                                   
"S_eaflatoxin[c]".("M_eaflatoxin[c]")                                   
"S_ebastineoh[c]".("M_ebastineoh[c]")                                   
"S_ebastineoh[r]".("M_ebastineoh[r]")                                   
"S_ebastine[c]".("M_ebastine[c]")                                   
"S_ebastine[r]".("M_ebastine[r]")                                   
"S_eicostet[c]".("M_eicostet[c]")                                   
"S_elaidcrn[c]".("M_elaidcrn[c]")                                   
"S_elaidcrn[m]".("M_elaidcrn[m]")                                   
"S_elaid[c]".("M_elaid[c]")                                 
"S_estradiol[c]".("M_estradiol[c]")                                 
"S_estradiol[r]".("M_estradiol[r]")                                 
"S_estriol[r]".("M_estriol[r]")                                 
"S_estriol[c]".("M_estriol[c]")                                 
"S_estrones[c]".("M_estrones[c]")                                   
"S_estrone[r]".("M_estrone[r]")                                 
"S_estrone[c]".("M_estrone[c]")                                 
"S_ethamp[c]".("M_ethamp[c]")                                   
"S_etha[c]".("M_etha[c]")                                   
"S_f1a[g]".("M_f1a[g]")                                 
"S_f1a[l]".("M_f1a[l]")                                 
"S_gdp[g]".("M_gdp[g]")                                 
"S_ddca[c]".("M_ddca[c]")                                   
"S_ttdca[c]".("M_ttdca[c]")                                 
"S_ttdcea[c]".("M_ttdcea[c]")                                   
"S_hdca[c]".("M_hdca[c]")                                   
"S_hdcea[c]".("M_hdcea[c]")                                 
"S_ocdca[c]".("M_ocdca[c]")                                 
"S_ocdcea[c]".("M_ocdcea[c]")                                   
"S_lnlc[c]".("M_lnlc[c]")                                   
"S_lneldc[c]".("M_lneldc[c]")                                   
"S_ptdca[c]".("M_ptdca[c]")                                 
"S_hpdca[c]".("M_hpdca[c]")                                 
"S_vacc[c]".("M_vacc[c]")                                   
"S_lnlncg[c]".("M_lnlncg[c]")                                   
"S_lnlnca[c]".("M_lnlnca[c]")                                   
"S_strdnc[c]".("M_strdnc[c]")                                   
"S_tmndnc[c]".("M_tmndnc[c]")                                   
"S_phyt[c]".("M_phyt[c]")                                   
"S_lgnc[c]".("M_lgnc[c]")                                   
"S_nrvnc[c]".("M_nrvnc[c]")                                 
"S_tettet6[c]".("M_tettet6[c]")                                 
"S_tetpent6[c]".("M_tetpent6[c]")                                   
"S_tetpent3[c]".("M_tetpent3[c]")                                   
"S_tethex3[c]".("M_tethex3[c]")                                 
"S_hexc[c]".("M_hexc[c]")                                   
"S_octa[c]".("M_octa[c]")                                   
"S_whhdca[c]".("M_whhdca[c]")                                   
"S_fald[c]".("M_fald[c]")                                   
"S_fald[l]".("M_fald[l]")                                   
"S_glyald[c]".("M_glyald[c]")                                   
"S_fe2[m]".("M_fe2[m]")                                 
"S_pheme[m]".("M_pheme[m]")                                 
"S_fe2[c]".("M_fe2[c]")                                 
"S_Lkynr[c]".("M_Lkynr[c]")                                 
"S_fol[c]".("M_fol[c]")                                 
"S_for[r]".("M_for[r]")                                 
"S_5dhf[m]".("M_5dhf[m]")                                   
"S_thf[m]".("M_thf[m]")                                 
"S_fru[c]".("M_fru[c]")                                 
"S_thf[c]".("M_thf[c]")                                 
"S_fuc13galacglcgal14acglcgalgluside_hs[c]".("M_fuc13galacglcgal14acglcgalgluside_hs[c]")                                   
"S_fuc13galacglcgal14acglcgalgluside_hs[g]".("M_fuc13galacglcgal14acglcgalgluside_hs[g]")                                   
"S_fuc14galacglcgalgluside_hs[c]".("M_fuc14galacglcgalgluside_hs[c]")                                   
"S_fuc14galacglcgalgluside_hs[g]".("M_fuc14galacglcgalgluside_hs[g]")                                   
"S_fucacgalfucgalacglcgalgluside_hs[c]".("M_fucacgalfucgalacglcgalgluside_hs[c]")                                   
"S_fucfuc12gal14acglcgalgluside_hs[c]".("M_fucfuc12gal14acglcgalgluside_hs[c]")                                 
"S_fucfuc12gal14acglcgalgluside_hs[g]".("M_fucfuc12gal14acglcgalgluside_hs[g]")                                 
"S_fucfucfucgalacglc13galacglcgal14acglcgalgluside_hs[c]".("M_fucfucfucgalacglc13galacglcgal14acglcgalgluside_hs[c]")                                   
"S_fucfucfucgalacglc13galacglcgal14acglcgalgluside_hs[g]".("M_fucfucfucgalacglc13galacglcgal14acglcgalgluside_hs[g]")                                   
"S_fucfucgalacglcgalgluside_hs[c]".("M_fucfucgalacglcgalgluside_hs[c]")                                 
"S_fucfucgalacglcgalgluside_hs[g]".("M_fucfucgalacglcgalgluside_hs[g]")                                 
"S_fucgal14acglcgalgluside_hs[c]".("M_fucgal14acglcgalgluside_hs[c]")                                   
"S_fucgal14acglcgalgluside_hs[g]".("M_fucgal14acglcgalgluside_hs[g]")                                   
"S_fucgalfucgalacglcgalgluside_hs[c]".("M_fucgalfucgalacglcgalgluside_hs[c]")                                   
"S_fum[m]".("M_fum[m]")                                 
"S_so4[c]".("M_so4[c]")                                 
"S_glyc3p[c]".("M_glyc3p[c]")                                   
"S_gudac[c]".("M_gudac[c]")                                 
"S_galacglcgalgbside_hs[c]".("M_galacglcgalgbside_hs[c]")                                   
"S_gal[l]".("M_gal[l]")                                 
"S_galgalfucfucgalacglcgalacglcgal14acglcgalgluside_hs[c]".("M_galgalfucfucgalacglcgalacglcgal14acglcgalgluside_hs[c]")                                 
"S_galgalgalthcrm_hs[c]".("M_galgalgalthcrm_hs[c]")                                 
"S_gd3_hs[g]".("M_gd3_hs[g]")                                   
"S_gal[c]".("M_gal[c]")                                 
"S_galt[c]".("M_galt[c]")                                   
"S_gam[c]".("M_gam[c]")                                 
"S_oagd3_hs[c]".("M_oagd3_hs[c]")                                   
"S_gd3_hs[c]".("M_gd3_hs[c]")                                   
"S_oagd3_hs[g]".("M_oagd3_hs[g]")                                   
"S_n2m2nmasn[l]".("M_n2m2nmasn[l]")                                 
"S_glc_D[l]".("M_glc_D[l]")                                 
"S_gluside_hs[l]".("M_gluside_hs[l]")                                   
"S_gbside_hs[c]".("M_gbside_hs[c]")                                 
"S_gbside_hs[l]".("M_gbside_hs[l]")                                 
"S_glyclt[m]".("M_glyclt[m]")                                   
"S_mlthf[m]".("M_mlthf[m]")                                 
"S_gchola[c]".("M_gchola[c]")                                   
"S_gmp[g]".("M_gmp[g]")                                 
"S_gmp[c]".("M_gmp[c]")                                 
"S_glu_L[l]".("M_glu_L[l]")                                 
"S_thf[l]".("M_thf[l]")                                 
"S_Tyr_ggn[c]".("M_Tyr_ggn[c]")                                 
"S_leuktrE4[c]".("M_leuktrE4[c]")                                   
"S_leuktrF4[c]".("M_leuktrF4[c]")                                   
"S_ser_L[m]".("M_ser_L[m]")                                 
"S_glcr[c]".("M_glcr[c]")                                   
"S_glygn2[c]".("M_glygn2[c]")                                   
"S_glcur[l]".("M_glcur[l]")                                 
"S_ha[l]".("M_ha[l]")                                   
"S_ha_pre1[l]".("M_ha_pre1[l]")                                 
"S_udpglcur[g]".("M_udpglcur[g]")                                   
"S_ump[c]".("M_ump[c]")                                 
"S_glcur[c]".("M_glcur[c]")                                 
"S_glcur[r]".("M_glcur[r]")                                 
"S_dxtrn[c]".("M_dxtrn[c]")                                 
"S_gln_L[m]".("M_gln_L[m]")                                 
"S_forglu[c]".("M_forglu[c]")                                   
"S_glx[c]".("M_glx[c]")                                 
"S_glyc3p[m]".("M_glyc3p[m]")                                   
"S_2pg[c]".("M_2pg[c]")                                 
"S_glyc_R[c]".("M_glyc_R[c]")                                   
"S_glyclt[c]".("M_glyclt[c]")                                   
"S_glyclt[x]".("M_glyclt[x]")                                   
"S_glyc_S[c]".("M_glyc_S[c]")                                   
"S_glyc[c]".("M_glyc[c]")                                   
"S_glyc[m]".("M_glyc[m]")                                   
"S_gthrd[m]".("M_gthrd[m]")                                 
"S_gmp[n]".("M_gmp[n]")                                 
"S_hdca[r]".("M_hdca[r]")                                   
"S_gq1b_hs[c]".("M_gq1b_hs[c]")                                 
"S_gsn[c]".("M_gsn[c]")                                 
"S_gthox[m]".("M_gthox[m]")                                 
"S_gthrd[r]".("M_gthrd[r]")                                 
"S_gua[c]".("M_gua[c]")                                 
"S_xan[c]".("M_xan[c]")                                 
"S_pe_hs[r]".("M_pe_hs[r]")                                 
"S_h2o2[l]".("M_h2o2[l]")                                   
"S_udpglcur[c]".("M_udpglcur[c]")                                   
"S_hcoumarin[c]".("M_hcoumarin[c]")                                 
"S_hestratriol[c]".("M_hestratriol[c]")                                 
"S_his_L[c]".("M_his_L[c]")                                 
"S_hista[c]".("M_hista[c]")                                 
"S_hom_L[c]".("M_hom_L[c]")                                 
"S_pheme[c]".("M_pheme[c]")                                 
"S_cortsn[r]".("M_cortsn[r]")                                   
"S_tststerone[r]".("M_tststerone[r]")                                   
"S_nadp[x]".("M_nadp[x]")                                   
"S_andrstandn[r]".("M_andrstandn[r]")                                   
"S_prgstrn[r]".("M_prgstrn[r]")                                 
"S_xol7aone[r]".("M_xol7aone[r]")                                   
"S_hspg[l]".("M_hspg[l]")                                   
"S_hspg[g]".("M_hspg[g]")                                   
"S_htaxol[c]".("M_htaxol[c]")                                   
"S_hxan[c]".("M_hxan[c]")                                   
"S_pydam[c]".("M_pydam[c]")                                 
"S_taur[c]".("M_taur[c]")                                   
"S_icit[c]".("M_icit[c]")                                   
"S_icit[x]".("M_icit[x]")                                   
"S_3ityr_L[c]".("M_3ityr_L[c]")                                 
"S_35diotyr[c]".("M_35diotyr[c]")                                   
"S_triodthy[c]".("M_triodthy[c]")                                   
"S_thyox_L[c]".("M_thyox_L[c]")                                 
"S_tyr_L[c]".("M_tyr_L[c]")                                 
"S_idour[l]".("M_idour[l]")                                 
"S_idour[c]".("M_idour[c]")                                 
"S_ile_L[c]".("M_ile_L[c]")                                 
"S_itacon[m]".("M_itacon[m]")                                   
"S_xylu_D[c]".("M_xylu_D[c]")                                   
"S_tagat_D[c]".("M_tagat_D[c]")                                 
"S_ksii_core2[g]".("M_ksii_core2[g]")                                   
"S_ksii_core4[g]".("M_ksii_core4[g]")                                   
"S_k[g]".("M_k[g]")                                 
"S_kynate[c]".("M_kynate[c]")                                   
"S_lac_L[m]".("M_lac_L[m]")                                 
"S_leuktrB4[c]".("M_leuktrB4[c]")                                   
"S_leuktrB4[r]".("M_leuktrB4[r]")                                   
"S_leuktrC4[c]".("M_leuktrC4[c]")                                   
"S_leuktrD4[c]".("M_leuktrD4[c]")                                   
"S_leu_L[c]".("M_leu_L[c]")                                 
"S_xyl_D[l]".("M_xyl_D[l]")                                 
"S_lac_L[c]".("M_lac_L[c]")                                 
"S_lneldccrn[c]".("M_lneldccrn[c]")                                 
"S_lneldccrn[m]".("M_lneldccrn[m]")                                 
"S_lnlccrn[c]".("M_lnlccrn[c]")                                 
"S_lnlccrn[m]".("M_lnlccrn[m]")                                 
"S_lanost[c]".("M_lanost[c]")                                   
"S_lanost[r]".("M_lanost[r]")                                   
"S_lpchol_hs[c]".("M_lpchol_hs[c]")                                 
"S_g3pc[c]".("M_g3pc[c]")                                   
"S_mag_hs[c]".("M_mag_hs[c]")                                   
"S_retfa[c]".("M_retfa[c]")                                 
"S_retinol[c]".("M_retinol[c]")                                 
"S_trp_L[c]".("M_trp_L[c]")                                 
"S_trypta[c]".("M_trypta[c]")                                   
"S_malt[c]".("M_malt[c]")                                   
"S_normete_L[c]".("M_normete_L[c]")                                 
"S_meoh[c]".("M_meoh[c]")                                   
"S_meoh[l]".("M_meoh[l]")                                   
"S_mepi[c]".("M_mepi[c]")                                   
"S_mi1p_D[c]".("M_mi1p_D[c]")                                   
"S_malttr[c]".("M_malttr[c]")                                   
"S_5mta[c]".("M_5mta[c]")                                   
"S_nac[c]".("M_nac[c]")                                 
"S_ncam[c]".("M_ncam[c]")                                   
"S_nad[n]".("M_nad[n]")                                 
"S_udp[l]".("M_udp[l]")                                 
"S_na1[g]".("M_na1[g]")                                 
"S_carn[c]".("M_carn[c]")                                   
"S_udp[r]".("M_udp[r]")                                 
"S_ump[r]".("M_ump[r]")                                 
"S_pi[g]".("M_pi[g]")                                   
"S_ump[g]".("M_ump[g]")                                 
"S_nicrnt[c]".("M_nicrnt[c]")                                   
"S_nicrnt[n]".("M_nicrnt[n]")                                   
"S_nwharg[c]".("M_nwharg[c]")                                   
"S_no[c]".("M_no[c]")                                   
"S_uri[l]".("M_uri[l]")                                 
"S_ump[l]".("M_ump[l]")                                 
"S_dtmp[m]".("M_dtmp[m]")                                   
"S_thymd[m]".("M_thymd[m]")                                 
"S_xmp[c]".("M_xmp[c]")                                 
"S_o2s[m]".("M_o2s[m]")                                 
"S_o2[n]".("M_o2[n]")                                   
"S_succ[m]".("M_succ[m]")                                   
"S_13_cis_retn[c]".("M_13_cis_retn[c]")                                 
"S_orot5p[c]".("M_orot5p[c]")                                   
"S_thcholstoic[m]".("M_thcholstoic[m]")                                 
"S_xol27oh[m]".("M_xol27oh[m]")                                 
"S_taxol[c]".("M_taxol[c]")                                 
"S_wharachd[r]".("M_wharachd[r]")                                   
"S_leuktrB4woh[r]".("M_leuktrB4woh[r]")                                 
"S_xoltri25[r]".("M_xoltri25[r]")                                   
"S_xoltri27[r]".("M_xoltri27[r]")                                   
"S_xol27oh[r]".("M_xol27oh[r]")                                 
"S_leuktrB4wcooh[r]".("M_leuktrB4wcooh[r]")                                 
"S_pro_L[m]".("M_pro_L[m]")                                 
"S_pa_hs[r]".("M_pa_hs[r]")                                 
"S_ak2lgchol_hs[c]".("M_ak2lgchol_hs[c]")                                   
"S_paf_hs[c]".("M_paf_hs[c]")                                   
"S_pail_hs[n]".("M_pail_hs[n]")                                 
"S_ptth[c]".("M_ptth[c]")                                   
"S_pchol_hs[r]".("M_pchol_hs[r]")                                   
"S_pcollg5hlys[c]".("M_pcollg5hlys[c]")                                 
"S_amp[g]".("M_amp[g]")                                 
"S_camp[g]".("M_camp[g]")                                   
"S_35cgmp[g]".("M_35cgmp[g]")                                   
"S_pydxn[c]".("M_pydxn[c]")                                 
"S_prostgd2[c]".("M_prostgd2[c]")                                   
"S_prostgh2[c]".("M_prostgh2[c]")                                   
"S_prostgh2[r]".("M_prostgh2[r]")                                   
"S_prostge2[r]".("M_prostge2[r]")                                   
"S_phe_L[c]".("M_phe_L[c]")                                 
"S_phe_L[m]".("M_phe_L[m]")                                 
"S_succ[x]".("M_succ[x]")                                   
"S_pi[n]".("M_pi[n]")                                   
"S_pail_hs[r]".("M_pail_hs[r]")                                 
"S_pnto_R[c]".("M_pnto_R[c]")                                   
"S_prist[x]".("M_prist[x]")                                 
"S_pro_D[c]".("M_pro_D[c]")                                 
"S_prostgi2[c]".("M_prostgi2[c]")                                   
"S_pro_L[c]".("M_pro_L[c]")                                 
"S_ps_hs[c]".("M_ps_hs[c]")                                 
"S_hdca[x]".("M_hdca[x]")                                   
"S_phyt[x]".("M_phyt[x]")                                   
"S_ptrc[c]".("M_ptrc[c]")                                   
"S_4abutn[c]".("M_4abutn[c]")                                   
"S_pydx[c]".("M_pydx[c]")                                   
"S_rbl_D[c]".("M_rbl_D[c]")                                 
"S_13_cis_retnglc[c]".("M_13_cis_retnglc[c]")                                   
"S_13_cis_retnglc[r]".("M_13_cis_retnglc[r]")                                   
"S_13_cis_retn[r]".("M_13_cis_retn[r]")                                 
"S_rib_D[c]".("M_rib_D[c]")                                 
"S_saccrp_L[m]".("M_saccrp_L[m]")                                   
"S_sbt_D[c]".("M_sbt_D[c]")                                 
"S_selmeth[c]".("M_selmeth[c]")                                 
"S_ser_L[x]".("M_ser_L[x]")                                 
"S_sph1p[c]".("M_sph1p[c]")                                 
"S_sphmyln_hs[g]".("M_sphmyln_hs[g]")                                   
"S_sphmyln_hs[l]".("M_sphmyln_hs[l]")                                   
"S_sphings[c]".("M_sphings[c]")                                 
"S_spc_hs[c]".("M_spc_hs[c]")                                   
"S_sphmyln_hs[c]".("M_sphmyln_hs[c]")                                   
"S_xolest_hs[c]".("M_xolest_hs[c]")                                 
"S_sphs1p[c]".("M_sphs1p[c]")                                   
"S_spmd[c]".("M_spmd[c]")                                   
"S_sql[r]".("M_sql[r]")                                 
"S_so4[r]".("M_so4[r]")                                 
"S_estrones[r]".("M_estrones[r]")                                   
"S_T4hcinnm[c]".("M_T4hcinnm[c]")                                   
"S_tchola[c]".("M_tchola[c]")                                   
"S_tdchola[c]".("M_tdchola[c]")                                 
"S_thcholstoic[x]".("M_thcholstoic[x]")                                 
"S_thymd[c]".("M_thymd[c]")                                 
"S_thm[c]".("M_thm[c]")                                 
"S_thmtp[c]".("M_thmtp[c]")                                 
"S_tmlys[c]".("M_tmlys[c]")                                 
"S_q10[c]".("M_q10[c]")                                 
"S_q10h2[c]".("M_q10h2[c]")                                 
"S_tststerone[c]".("M_tststerone[c]")                                   
"S_ttdcrn[m]".("M_ttdcrn[m]")                                   
"S_ttdcrn[c]".("M_ttdcrn[c]")                                   
"S_txa2[c]".("M_txa2[c]")                                   
"S_txa2[r]".("M_txa2[r]")                                   
"S_udpglcur[r]".("M_udpglcur[r]")                                   
"S_ump[n]".("M_ump[n]")                                 
"S_urate[c]".("M_urate[c]")                                 
"S_urea[c]".("M_urea[c]")                                   
"S_val_L[c]".("M_val_L[c]")                                 
"S_vitd3[c]".("M_vitd3[c]")                                 
"S_dhcholestanate[r]".("M_dhcholestanate[r]")                                   
"S_thcholstoic[r]".("M_thcholstoic[r]")                                 
"S_whtststerone[c]".("M_whtststerone[c]")                                   
"S_xolest2_hs[c]".("M_xolest2_hs[c]")                                   
"S_xoltri25[c]".("M_xoltri25[c]")                                   
"S_xoltri27[c]".("M_xoltri27[c]")                                   
"S_xylt[c]".("M_xylt[c]")                                   
"S_xyl_D[c]".("M_xyl_D[c]")                                 
"S_acmana[r]".("M_acmana[r]")                                   
"S_lac_L[x]".("M_lac_L[x]")                                 
"S_fdp[c]".("M_fdp[c]")                                 
"S_glyald[m]".("M_glyald[m]")                                   
"S_arachd[x]".("M_arachd[x]")                                   
"S_3pg[m]".("M_3pg[m]")                                 
"S_glyc_R[m]".("M_glyc_R[m]")                                   
"S_lnlccrn[x]".("M_lnlccrn[x]")                                 
"S_dgmp[c]".("M_dgmp[c]")                                   
"S_mev_R[c]".("M_mev_R[c]")                                 
"S_fol[m]".("M_fol[m]")                                 
"S_HC00900[m]".("M_HC00900[m]")                                 
"S_cholate[r]".("M_cholate[r]")                                 
"S_ptth[m]".("M_ptth[m]")                                   
"S_4hpro_LT[c]".("M_4hpro_LT[c]")                                   
"S_4hpro_LT[m]".("M_4hpro_LT[m]")                                   
"S_thcholstoic[c]".("M_thcholstoic[c]")                                 
"S_HC00900[c]".("M_HC00900[c]")                                 
"S_C02470[c]".("M_C02470[c]")                                   
"S_C02528[r]".("M_C02528[r]")                                   
"S_C02528[c]".("M_C02528[c]")                                   
"S_dhcholestanate[c]".("M_dhcholestanate[c]")                                   
"S_hxcoa[m]".("M_hxcoa[m]")                                 
"S_xol7ah3[c]".("M_xol7ah3[c]")                                 
"S_inost[r]".("M_inost[r]")                                 
"S_atp[l]".("M_atp[l]")                                 
"S_adp[l]".("M_adp[l]")                                 
"S_cmp[r]".("M_cmp[r]")                                 
"S_hdca[l]".("M_hdca[l]")                                   
"S_strdnc[l]".("M_strdnc[l]")                                   
"S_strdnc[r]".("M_strdnc[r]")                                   
"S_lnlc[l]".("M_lnlc[l]")                                   
"S_lnlc[r]".("M_lnlc[r]")                                   
"S_c8crn[c]".("M_c8crn[c]")                                 
"S_met_L[m]".("M_met_L[m]")                                 
"S_dtmp[c]".("M_dtmp[c]")                                   
"S_HC02020[r]".("M_HC02020[r]")                                 
"S_hdcea[r]".("M_hdcea[r]")                                 
"S_ocdcea[r]".("M_ocdcea[r]")                                   
"S_ocdcea[l]".("M_ocdcea[l]")                                   
"S_lnlnca[r]".("M_lnlnca[r]")                                   
"S_lnlncg[r]".("M_lnlncg[r]")                                   
"S_lnlncg[l]".("M_lnlncg[l]")                                   
"S_lnlnca[l]".("M_lnlnca[l]")                                   
"S_dlnlcg[l]".("M_dlnlcg[l]")                                   
"S_dlnlcg[r]".("M_dlnlcg[r]")                                   
"S_xtsn[c]".("M_xtsn[c]")                                   
"S_HC02192[c]".("M_HC02192[c]")                                 
"S_HC02193[c]".("M_HC02193[c]")                                 
"S_HC02195[c]".("M_HC02195[c]")                                 
"S_HC02196[c]".("M_HC02196[c]")                                 
"S_HC02220[c]".("M_HC02220[c]")                                 
"S_dca[c]".("M_dca[c]")                                 
"S_HC02191[c]".("M_HC02191[c]")                                 
"S_HC02194[c]".("M_HC02194[c]")                                 
"S_HC02197[c]".("M_HC02197[c]")                                 
"S_HC02198[c]".("M_HC02198[c]")                                 
"S_HC02187[c]".("M_HC02187[c]")                                 
"S_HC02180[c]".("M_HC02180[c]")                                 
"S_wharachd[c]".("M_wharachd[c]")                                   
"S_HC02202[c]".("M_HC02202[c]")                                 
"S_HC02203[c]".("M_HC02203[c]")                                 
"S_HC02204[c]".("M_HC02204[c]")                                 
"S_HC02205[c]".("M_HC02205[c]")                                 
"S_HC02206[c]".("M_HC02206[c]")                                 
"S_HC02207[c]".("M_HC02207[c]")                                 
"S_HC02208[c]".("M_HC02208[c]")                                 
"S_HC02210[c]".("M_HC02210[c]")                                 
"S_HC02213[c]".("M_HC02213[c]")                                 
"S_HC02214[c]".("M_HC02214[c]")                                 
"S_HC02216[c]".("M_HC02216[c]")                                 
"S_HC02217[c]".("M_HC02217[c]")                                 
"S_c4crn[c]".("M_c4crn[c]")                                 
"S_docosac[c]".("M_docosac[c]")                                 
"S_CE2705[c]".("M_CE2705[c]")                                   
"S_maltttr[c]".("M_maltttr[c]")                                 
"S_CE2839[c]".("M_CE2839[c]")                                   
"S_CE2838[c]".("M_CE2838[c]")                                   
"S_atp[g]".("M_atp[g]")                                 
"S_adp[g]".("M_adp[g]")                                 
"S_CE1918[c]".("M_CE1918[c]")                                   
"S_xol7aone[m]".("M_xol7aone[m]")                                   
"S_xol27oh[c]".("M_xol27oh[c]")                                 
"S_cholate[m]".("M_cholate[m]")                                 
"S_cholate[x]".("M_cholate[x]")                                 
"S_tdechola[c]".("M_tdechola[c]")                                   
"S_retinal[r]".("M_retinal[r]")                                 
"S_CE1261[c]".("M_CE1261[c]")                                   
"S_CE5026[c]".("M_CE5026[c]")                                   
"S_CE5629[c]".("M_CE5629[c]")                                   
"S_retinol[r]".("M_retinol[r]")                                 
"S_C13856[c]".("M_C13856[c]")                                   
"S_C05957[c]".("M_C05957[c]")                                   
"S_CE4877[c]".("M_CE4877[c]")                                   
"S_dchac[c]".("M_dchac[c]")                                 
"S_CE2172[c]".("M_CE2172[c]")                                   
"S_CE1310[m]".("M_CE1310[m]")                                   
"S_C05300[c]".("M_C05300[c]")                                   
"S_C05300[r]".("M_C05300[r]")                                   
"S_CE5025[c]".("M_CE5025[c]")                                   
"S_dsmsterol[c]".("M_dsmsterol[c]")                                 
"S_CE4969[m]".("M_CE4969[m]")                                   
"S_CE6205[c]".("M_CE6205[c]")                                   
"S_CE1273[c]".("M_CE1273[c]")                                   
"S_HC02191[r]".("M_HC02191[r]")                                 
"S_crm_hs[n]".("M_crm_hs[n]")                                   
"S_alltn[c]".("M_alltn[c]")                                 
"S_CE0074[c]".("M_CE0074[c]")                                   
"S_hdcea[m]".("M_hdcea[m]")                                 
"S_leuktrB4[m]".("M_leuktrB4[m]")                                   
"S_leuktrB4woh[m]".("M_leuktrB4woh[m]")                                 
"S_leuktrB4wcooh[c]".("M_leuktrB4wcooh[c]")                                 
"S_leuktrB4wcooh[m]".("M_leuktrB4wcooh[m]")                                 
"S_leuktrB4woh[c]".("M_leuktrB4woh[c]")                                 
"S_15HPET[n]".("M_15HPET[n]")                                   
"S_h2o2[r]".("M_h2o2[r]")                                   
"S_15HPET[r]".("M_15HPET[r]")                                   
"S_CE7172[c]".("M_CE7172[c]")                                   
"S_C06315[c]".("M_C06315[c]")                                   
"S_C06314[c]".("M_C06314[c]")                                   
"S_C05770[c]".("M_C05770[c]")                                   
"S_tmndnc[r]".("M_tmndnc[r]")                                   
"S_lthstrl[c]".("M_lthstrl[c]")                                 
"S_tethex3[r]".("M_tethex3[r]")                                 
"S_tetpent6[r]".("M_tetpent6[r]")                                   
"S_CE2510[c]".("M_CE2510[c]")                                   
"S_doco13ac[c]".("M_doco13ac[c]")                                   
"S_C14826[c]".("M_C14826[c]")                                   
"S_CE2049[c]".("M_CE2049[c]")                                   
"S_C14825[c]".("M_C14825[c]")                                   
"S_CE2047[c]".("M_CE2047[c]")                                   
"S_C14768[c]".("M_C14768[c]")                                   
"S_C14770[c]".("M_C14770[c]")                                   
"S_C14769[c]".("M_C14769[c]")                                   
"S_C14771[c]".("M_C14771[c]")                                   
"S_C04717[c]".("M_C04717[c]")                                   
"S_C01601[c]".("M_C01601[c]")                                   
"S_CE2006[c]".("M_CE2006[c]")                                   
"S_C04805[c]".("M_C04805[c]")                                   
"S_CE7096[c]".("M_CE7096[c]")                                   
"S_C04805[m]".("M_C04805[m]")                                   
"S_CE7085[c]".("M_CE7085[c]")                                   
"S_CE7081[r]".("M_CE7081[r]")                                   
"S_CE7090[c]".("M_CE7090[c]")                                   
"S_leuktrB4wcooh[x]".("M_leuktrB4wcooh[x]")                                 
"S_CE2537[c]".("M_CE2537[c]")                                   
"S_urcan[c]".("M_urcan[c]")                                 
"S_C05767[c]".("M_C05767[c]")                                   
"S_3bcrn[c]".("M_3bcrn[c]")                                 
"S_c10crn[c]".("M_c10crn[c]")                                   
"S_c4crn[x]".("M_c4crn[x]")                                 
"S_hxcoa[c]".("M_hxcoa[c]")                                 
"S_hxcoa[x]".("M_hxcoa[x]")                                 
"S_dca[r]".("M_dca[r]")                                 
"S_docosac[r]".("M_docosac[r]")                                 
"S_hexdiac[c]".("M_hexdiac[c]")                                 
"S_sebacid[c]".("M_sebacid[c]")                                 
"S_oh1[c]".("M_oh1[c]")                                 
"S_dhap[m]".("M_dhap[m]")                                   
"S_mal_L[x]".("M_mal_L[x]")                                 
"S_15kprostgf2[c]".("M_15kprostgf2[c]")                                 
"S_21hprgnlone[c]".("M_21hprgnlone[c]")                                 
"S_3mhis[c]".("M_3mhis[c]")                                 
"S_hmcr[c]".("M_hmcr[c]")                                   
"S_peole_hs[c]".("M_peole_hs[c]")                                   
"S_pepalm_hs[c]".("M_pepalm_hs[c]")                                 
"S_pailpalm_hs[c]".("M_pailpalm_hs[c]")                                 
"S_pe2linl_hs[c]".("M_pe2linl_hs[c]")                                   
"S_pchol2palm_hs[c]".("M_pchol2palm_hs[c]")                                 
"S_pear_hs[c]".("M_pear_hs[c]")                                 
"S_pe203_hs[c]".("M_pe203_hs[c]")                                   
"S_pe226_hs[c]".("M_pe226_hs[c]")                                   
"S_pe224_hs[c]".("M_pe224_hs[c]")                                   
"S_pedh203_hs[c]".("M_pedh203_hs[c]")                                   
"S_pe12_hs[c]".("M_pe12_hs[c]")                                 
"S_pe14_hs[c]".("M_pe14_hs[c]")                                 
"S_pe161_hs[c]".("M_pe161_hs[c]")                                   
"S_pe13_hs[c]".("M_pe13_hs[c]")                                 
"S_pe15_hs[c]".("M_pe15_hs[c]")                                 
"S_pe17_hs[c]".("M_pe17_hs[c]")                                 
"S_pailar_hs[c]".("M_pailar_hs[c]")                                 
"S_pcholn261_hs[c]".("M_pcholn261_hs[c]")                                   
"S_pcholn281_hs[c]".("M_pcholn281_hs[c]")                                   
"S_pcholn28_hs[c]".("M_pcholn28_hs[c]")                                 
"S_pelinl_hs[c]".("M_pelinl_hs[c]")                                 
"S_eidi1114ac[c]".("M_eidi1114ac[c]")                                   
"S_hxa[c]".("M_hxa[c]")                                 
"S_glyc2p[c]".("M_glyc2p[c]")                                   
"S_aclys[c]".("M_aclys[c]")                                 
"S_34hpl[c]".("M_34hpl[c]")                                 
"S_3hmp[c]".("M_3hmp[c]")                                   
"S_acglu[c]".("M_acglu[c]")                                 
"S_acgly[m]".("M_acgly[m]")                                 
"S_acgly[c]".("M_acgly[c]")                                 
"S_cortsn[c]".("M_cortsn[c]")                                   
"S_hxa[m]".("M_hxa[m]")                                 
"S_hxa[x]".("M_hxa[x]")                                 
"S_pser_L[c]".("M_pser_L[c]")                                   
"S_saccrp_L[c]".("M_saccrp_L[c]")                                   
"S_7klitchol[c]".("M_7klitchol[c]")                                 
"S_Lhcystin[c]".("M_Lhcystin[c]")                                   
"S_ppbng[c]".("M_ppbng[c]")                                 
"S_im4ac[c]".("M_im4ac[c]")                                 
"S_2h3mv[c]".("M_2h3mv[c]")                                 
"S_2hiv[c]".("M_2hiv[c]")                                   
"S_2m3hbu[m]".("M_2m3hbu[m]")                                   
"S_2m3hbu[c]".("M_2m3hbu[c]")                                   
"S_3h3mglt[c]".("M_3h3mglt[c]")                                 
"S_3mglutac[m]".("M_3mglutac[m]")                                   
"S_3mglutac[c]".("M_3mglutac[c]")                                   
"S_glutcon[m]".("M_glutcon[m]")                                 
"S_glutcon[c]".("M_glutcon[c]")                                 
"S_caproic[c]".("M_caproic[c]")                                 
"S_5ohhexa[c]".("M_5ohhexa[c]")                                 
"S_ethmalac[c]".("M_ethmalac[c]")                                   
"S_peste_hs[c]".("M_peste_hs[c]")                                   
"S_eic21114tr[c]".("M_eic21114tr[c]")                                   
"S_5eipenc[m]".("M_5eipenc[m]")                                 
"S_5eipenc[c]".("M_5eipenc[c]")                                 
"S_andrstandn[c]".("M_andrstandn[c]")                                   
"S_CE1447[c]".("M_CE1447[c]")                                   
"S_CE4969[c]".("M_CE4969[c]")                                   
"S_CE1310[c]".("M_CE1310[c]")                                   
"S_4hbz[c]".("M_4hbz[c]")                                   
"S_sucsal[c]".("M_sucsal[c]")                                   
"S_CE7081[c]".("M_CE7081[c]")                                   
"S_egme[c]".("M_egme[c]")                                   
"S_sql[c]".("M_sql[c]")                                 
"S_orn_D[c]".("M_orn_D[c]")                                 
"S_5g2oxpt[c]".("M_5g2oxpt[c]")                                 
"S_HC02020[c]".("M_HC02020[c]")                                 
"S_xol25oh[c]".("M_xol25oh[c]")                                 
"S_coke[c]".("M_coke[c]")                                   
"S_5a2opntn[c]".("M_5a2opntn[c]")                                   
"S_arg_D[c]".("M_arg_D[c]")                                 
"S_dopa4glcur[c]".("M_dopa4glcur[c]")                                   
"S_dopa3glcur[c]".("M_dopa3glcur[c]")                                   
"S_34dhpe[c]".("M_34dhpe[c]")                                   
"S_Rtotal[g]".("M_Rtotal[g]")                                   
"S_sphings[g]".("M_sphings[g]")                                 
"S_sphgn[g]".("M_sphgn[g]")                                 
"S_gm1_hs[l]".("M_gm1_hs[l]")                                   
"S_gd3_hs[l]".("M_gd3_hs[l]")                                   
"S_gm1_hs[c]".("M_gm1_hs[c]")                                   
"S_gm1_hs[n]".("M_gm1_hs[n]")                                   
"S_sphings[n]".("M_sphings[n]")                                 
"S_sphs1p[n]".("M_sphs1p[n]")                                   
"S_sphgn[n]".("M_sphgn[n]")                                 
"S_sph1p[n]".("M_sph1p[n]")                                 
"S_15HPET[x]".("M_15HPET[x]")                                   
"S_M03134[c]".("M_M03134[c]")                                   
"S_M02108[c]".("M_M02108[c]")                                   
"S_M03117[c]".("M_M03117[c]")                                   
"S_M03051[c]".("M_M03051[c]")                                   
"S_M00117[c]".("M_M00117[c]")                                   
"S_M02745[c]".("M_M02745[c]")                                   
"S_M01197[c]".("M_M01197[c]")                                   
"S_M00003[c]".("M_M00003[c]")                                   
"S_M01238[c]".("M_M01238[c]")                                   
"S_M00019[c]".("M_M00019[c]")                                   
"S_M00115[c]".("M_M00115[c]")                                   
"S_M02613[c]".("M_M02613[c]")                                   
"S_M00017[c]".("M_M00017[c]")                                   
"S_M01235[c]".("M_M01235[c]")                                   
"S_M01207[c]".("M_M01207[c]")                                   
"S_M02457[c]".("M_M02457[c]")                                   
"S_M02053[c]".("M_M02053[c]")                                   
"S_M01582[c]".("M_M01582[c]")                                   
"S_M03045[c]".("M_M03045[c]")                                   
"S_M03153[c]".("M_M03153[c]")                                   
"S_M00010[c]".("M_M00010[c]")                                   
"S_M00341[c]".("M_M00341[c]")                                   
"S_M00260[c]".("M_M00260[c]")                                   
"S_M00315[c]".("M_M00315[c]")                                   
"S_M00008[c]".("M_M00008[c]")                                   
"S_M00021[c]".("M_M00021[c]")                                   
"S_M00265[c]".("M_M00265[c]")                                   
"S_sphmyln_hs[r]".("M_sphmyln_hs[r]")                                   
"S_galgluside_hs[r]".("M_galgluside_hs[r]")                                 
"S_M01881[c]".("M_M01881[c]")                                   
"S_arachd[n]".("M_arachd[n]")                                   
"S_12HPET[r]".("M_12HPET[r]")                                   
"S_gthox[r]".("M_gthox[r]")                                 
"S_HC02217[r]".("M_HC02217[r]")                                 
"S_HC02180[r]".("M_HC02180[r]")                                 
"S_M01989[c]".("M_M01989[c]")                                   
"S_M02155[c]".("M_M02155[c]")                                   
"S_hestratriol[l]".("M_hestratriol[l]")                                 
"S_stcrn[r]".("M_stcrn[r]")                                 
"S_odecrn[r]".("M_odecrn[r]")                                   
"S_ddca[r]".("M_ddca[r]")                                   
"S_M03051[r]".("M_M03051[r]")                                   
"S_ttdca[r]".("M_ttdca[r]")                                 
"S_M02745[r]".("M_M02745[r]")                                   
"S_ttdcea[r]".("M_ttdcea[r]")                                   
"S_M00117[r]".("M_M00117[r]")                                   
"S_ptdca[r]".("M_ptdca[r]")                                 
"S_M01197[r]".("M_M01197[r]")                                   
"S_hpdca[r]".("M_hpdca[r]")                                 
"S_M00003[r]".("M_M00003[r]")                                   
"S_M01238[r]".("M_M01238[r]")                                   
"S_elaid[r]".("M_elaid[r]")                                 
"S_M00019[r]".("M_M00019[r]")                                   
"S_vacc[r]".("M_vacc[r]")                                   
"S_lneldc[r]".("M_lneldc[r]")                                   
"S_M02613[r]".("M_M02613[r]")                                   
"S_arach[r]".("M_arach[r]")                                 
"S_CE2510[r]".("M_CE2510[r]")                                   
"S_M00017[r]".("M_M00017[r]")                                   
"S_M01235[r]".("M_M01235[r]")                                   
"S_M01207[r]".("M_M01207[r]")                                   
"S_M02457[r]".("M_M02457[r]")                                   
"S_M02053[r]".("M_M02053[r]")                                   
"S_doco13ac[r]".("M_doco13ac[r]")                                   
"S_M01582[r]".("M_M01582[r]")                                   
"S_M03045[r]".("M_M03045[r]")                                   
"S_lgnc[r]".("M_lgnc[r]")                                   
"S_nrvnc[r]".("M_nrvnc[r]")                                 
"S_hexc[r]".("M_hexc[r]")                                   
"S_M03153[r]".("M_M03153[r]")                                   
"S_eicostet[r]".("M_eicostet[r]")                                   
"S_clpnd[r]".("M_clpnd[r]")                                 
"S_tetpent3[r]".("M_tetpent3[r]")                                   
"S_crvnc[r]".("M_crvnc[r]")                                 
"S_M00010[r]".("M_M00010[r]")                                   
"S_M00341[r]".("M_M00341[r]")                                   
"S_adrn[r]".("M_adrn[r]")                                   
"S_tettet6[r]".("M_tettet6[r]")                                 
"S_dcsptn1[r]".("M_dcsptn1[r]")                                 
"S_M00008[r]".("M_M00008[r]")                                   
"S_M00021[r]".("M_M00021[r]")                                   
"S_ac[x]".("M_ac[x]")                                   
"S_amp[n]".("M_amp[n]")                                 
"S_ocdca[r]".("M_ocdca[r]")                                 
"S_peplys[c]".("M_peplys[c]")                                   
"S_M01870[g]".("M_M01870[g]")                                   
"S_M02446[c]".("M_M02446[c]")                                   
"S_M02447[c]".("M_M02447[c]")                                   
"S_M02449[c]".("M_M02449[c]")                                   
"S_M02451[c]".("M_M02451[c]")                                   
"S_itacon[c]".("M_itacon[c]")                                   
"S_n5m2masn[c]".("M_n5m2masn[c]")                                   
"S_12dhchol[c]".("M_12dhchol[c]")                                   
"S_3dhchol[c]".("M_3dhchol[c]")                                 
"S_3dhcdchol[c]".("M_3dhcdchol[c]")                                 
"S_3dhdchol[c]".("M_3dhdchol[c]")                                   
"S_3dhlchol[c]".("M_3dhlchol[c]")                                   
"S_7dhcdchol[c]".("M_7dhcdchol[c]")                                 
"S_7dhchol[c]".("M_7dhchol[c]")                                 
"S_cdca24g[c]".("M_cdca24g[c]")                                 
"S_cdca24g[r]".("M_cdca24g[r]")                                 
"S_cdca3g[c]".("M_cdca3g[c]")                                   
"S_cdca3g[r]".("M_cdca3g[r]")                                   
"S_hyochol[c]".("M_hyochol[c]")                                 
"S_coprost[c]".("M_coprost[c]")                                 
"S_hca24g[c]".("M_hca24g[c]")                                   
"S_hdca24g[c]".("M_hdca24g[c]")                                 
"S_hdca6g[c]".("M_hdca6g[c]")                                   
"S_icdchol[c]".("M_icdchol[c]")                                 
"S_isochol[c]".("M_isochol[c]")                                 
"S_lca24g[c]".("M_lca24g[c]")                                   
"S_lca3g[c]".("M_lca3g[c]")                                 
"S_thyochol[c]".("M_thyochol[c]")                                   
"S_uchol[c]".("M_uchol[c]")                                 
"S_hyochol[r]".("M_hyochol[r]")                                 
"S_hca24g[r]".("M_hca24g[r]")                                   
"S_M02155[r]".("M_M02155[r]")                                   
"S_hdca24g[r]".("M_hdca24g[r]")                                 
"S_hdca6g[r]".("M_hdca6g[r]")                                   
"S_lca24g[r]".("M_lca24g[r]")                                   
"S_lca3g[r]".("M_lca3g[r]")                                 
"S_tacr[r]".("M_tacr[r]")                                   
"S_12htacr[r]".("M_12htacr[r]")                                 
"S_12htacr[c]".("M_12htacr[c]")                                 
"S_4ohmdz[r]".("M_4ohmdz[r]")                                   
"S_14hmdz[r]".("M_14hmdz[r]")                                   
"S_1ohmdz[r]".("M_1ohmdz[r]")                                   
"S_14hmdz[c]".("M_14hmdz[c]")                                   
"S_1hibupglu_S[c]".("M_1hibupglu_S[c]")                                 
"S_1hibup_S[r]".("M_1hibup_S[r]")                                   
"S_1hibupglu_S[r]".("M_1hibupglu_S[r]")                                 
"S_1hibup_S[c]".("M_1hibup_S[c]")                                   
"S_mdz[r]".("M_mdz[r]")                                 
"S_1ohmdz[c]".("M_1ohmdz[c]")                                   
"S_2hatvacid[c]".("M_2hatvacid[c]")                                 
"S_2hatvlac[c]".("M_2hatvlac[c]")                                   
"S_2hatvacid[r]".("M_2hatvacid[r]")                                 
"S_atvacid[r]".("M_atvacid[r]")                                 
"S_atvlac[r]".("M_atvlac[r]")                                   
"S_2hibupglu_S[c]".("M_2hibupglu_S[c]")                                 
"S_2hibup_R[c]".("M_2hibup_R[c]")                                   
"S_2hibup_S[r]".("M_2hibup_S[r]")                                   
"S_2hibupglu_S[r]".("M_2hibupglu_S[r]")                                 
"S_2hibup_S[c]".("M_2hibup_S[c]")                                   
"S_pvs[r]".("M_pvs[r]")                                 
"S_smv[r]".("M_smv[r]")                                 
"S_35dsmv[r]".("M_35dsmv[r]")                                   
"S_35dsmv[c]".("M_35dsmv[c]")                                   
"S_3hibupglu_S[c]".("M_3hibupglu_S[c]")                                 
"S_3hibup_R[c]".("M_3hibup_R[c]")                                   
"S_3hibup_S[r]".("M_3hibup_S[r]")                                   
"S_3hibupglu_S[r]".("M_3hibupglu_S[r]")                                 
"S_3hibup_S[c]".("M_3hibup_S[c]")                                   
"S_3hlvstacid[c]".("M_3hlvstacid[c]")                                   
"S_3hpvstet[c]".("M_3hpvstet[c]")                                   
"S_3hpvs[r]".("M_3hpvs[r]")                                 
"S_3hpvs[c]".("M_3hpvs[c]")                                 
"S_3hsmvacid[c]".("M_3hsmvacid[c]")                                 
"S_pvs[c]".("M_pvs[c]")                                 
"S_3ispvs[c]".("M_3ispvs[c]")                                   
"S_3ohacmp[c]".("M_3ohacmp[c]")                                 
"S_acmp[r]".("M_acmp[r]")                                   
"S_3ohacmp[r]".("M_3ohacmp[r]")                                 
"S_glz[r]".("M_glz[r]")                                 
"S_4hatvacid[r]".("M_4hatvacid[r]")                                 
"S_4hatvlac[c]".("M_4hatvlac[c]")                                   
"S_4hatvacid[c]".("M_4hatvacid[c]")                                 
"S_4hatvlac[r]".("M_4hatvlac[r]")                                   
"S_4ohmdz[c]".("M_4ohmdz[c]")                                   
"S_56dhpvs[c]".("M_56dhpvs[c]")                                 
"S_56eppvs[c]".("M_56eppvs[c]")                                 
"S_5ohfvs[r]".("M_5ohfvs[r]")                                   
"S_5ohfvsglu[r]".("M_5ohfvsglu[r]")                                 
"S_5ohfvsglu[c]".("M_5ohfvsglu[c]")                                 
"S_fvs[r]".("M_fvs[r]")                                 
"S_5ohfvs[c]".("M_5ohfvs[c]")                                   
"S_6bhglz[c]".("M_6bhglz[c]")                                   
"S_6bhglz[r]".("M_6bhglz[r]")                                   
"S_6csmvacid[c]".("M_6csmvacid[c]")                                 
"S_6epvs[c]".("M_6epvs[c]")                                 
"S_6hlvst[c]".("M_6hlvst[c]")                                   
"S_6hmsmvacid[c]".("M_6hmsmvacid[c]")                                   
"S_6hsmvacid[c]".("M_6hsmvacid[c]")                                 
"S_6melvst[c]".("M_6melvst[c]")                                 
"S_6melvacid[c]".("M_6melvacid[c]")                                 
"S_6ohfvsglu[r]".("M_6ohfvsglu[r]")                                 
"S_6ohfvsglu[c]".("M_6ohfvsglu[c]")                                 
"S_7bhglz[c]".("M_7bhglz[c]")                                   
"S_7bhglz[r]".("M_7bhglz[r]")                                   
"S_7hpvs[c]".("M_7hpvs[c]")                                 
"S_acmp[c]".("M_acmp[c]")                                   
"S_am1csa[r]".("M_am1csa[r]")                                   
"S_am19cs[r]".("M_am19cs[r]")                                   
"S_am9csa[r]".("M_am9csa[r]")                                   
"S_am19cs[c]".("M_am19cs[c]")                                   
"S_am1csa[c]".("M_am1csa[c]")                                   
"S_csa[r]".("M_csa[r]")                                 
"S_am9csa[c]".("M_am9csa[c]")                                   
"S_csa[c]".("M_csa[c]")                                 
"S_atvacid[c]".("M_atvacid[c]")                                 
"S_atvlac[c]".("M_atvlac[c]")                                   
"S_caribupglu_S[c]".("M_caribupglu_S[c]")                                   
"S_caribup_s[r]".("M_caribup_s[r]")                                 
"S_caribupglu_S[r]".("M_caribupglu_S[r]")                                   
"S_caribup_s[c]".("M_caribup_s[c]")                                 
"S_mhglz[r]".("M_mhglz[r]")                                 
"S_crvsm24[r]".("M_crvsm24[r]")                                 
"S_crvs[c]".("M_crvs[c]")                                   
"S_crvs[r]".("M_crvs[r]")                                   
"S_crvsm24[c]".("M_crvsm24[c]")                                 
"S_fvs[x]".("M_fvs[x]")                                 
"S_deoxfvs[x]".("M_deoxfvs[x]")                                 
"S_deoxfvs[c]".("M_deoxfvs[c]")                                 
"S_glz[c]".("M_glz[c]")                                 
"S_dspvs[c]".("M_dspvs[c]")                                 
"S_epoxtac[r]".("M_epoxtac[r]")                                 
"S_epoxtac[c]".("M_epoxtac[c]")                                 
"S_tlacfvs[r]".("M_tlacfvs[r]")                                 
"S_fvs[c]".("M_fvs[c]")                                 
"S_glc3meacp[r]".("M_glc3meacp[r]")                                 
"S_glc3meacp[c]".("M_glc3meacp[c]")                                 
"S_ibupgluc[c]".("M_ibupgluc[c]")                                   
"S_ibup_S[r]".("M_ibup_S[r]")                                   
"S_ibupgluc[r]".("M_ibupgluc[r]")                                   
"S_ibup_R[c]".("M_ibup_R[c]")                                   
"S_ibup_R[r]".("M_ibup_R[r]")                                   
"S_2hibup_R[r]".("M_2hibup_R[r]")                                   
"S_3hibup_R[r]".("M_3hibup_R[r]")                                   
"S_ibup_S[c]".("M_ibup_S[c]")                                   
"S_isolvstacid[c]".("M_isolvstacid[c]")                                 
"S_lstn[r]".("M_lstn[r]")                                   
"S_lstn[c]".("M_lstn[c]")                                   
"S_lstnm7[c]".("M_lstnm7[c]")                                   
"S_lstnm7[r]".("M_lstnm7[r]")                                   
"S_lvst[c]".("M_lvst[c]")                                   
"S_6melvacid[r]".("M_6melvacid[r]")                                 
"S_lvst[r]".("M_lvst[r]")                                   
"S_6hlvst[r]".("M_6hlvst[r]")                                   
"S_6melvst[r]".("M_6melvst[r]")                                 
"S_mdz[c]".("M_mdz[c]")                                 
"S_mhglz[c]".("M_mhglz[c]")                                 
"S_nfdac[r]".("M_nfdac[r]")                                 
"S_nfdoh[r]".("M_nfdoh[r]")                                 
"S_nfdac[c]".("M_nfdac[c]")                                 
"S_nfdoh[c]".("M_nfdoh[c]")                                 
"S_profvs[c]".("M_profvs[c]")                                   
"S_ptvst[c]".("M_ptvst[c]")                                 
"S_ptvst[r]".("M_ptvst[r]")                                 
"S_ptvstlac[r]".("M_ptvstlac[r]")                                   
"S_ptvstlac[c]".("M_ptvstlac[c]")                                   
"S_ptvstm13[r]".("M_ptvstm13[r]")                                   
"S_pvsgluc[c]".("M_pvsgluc[c]")                                 
"S_smvacid[c]".("M_smvacid[c]")                                 
"S_smv[c]".("M_smv[c]")                                 
"S_tacr[c]".("M_tacr[c]")                                   
"S_tlacfvs[c]".("M_tlacfvs[c]")                                 
"S_tripvs[c]".("M_tripvs[c]")                                   
"S_ptvstm13[c]".("M_ptvstm13[c]")                                   
"S_1a25dhvitd2[c]".("M_1a25dhvitd2[c]")                                 
"S_h[i]".("M_h[i]")                                 
"S_itp[m]".("M_itp[m]")                                 
"S_idp[m]".("M_idp[m]")                                 
"S_peptide[c]".("M_peptide[c]")                                 
"S_abeta_L_lysine[c]".("M_abeta_L_lysine[c]")                                   
"S_abeta_L_lysine[n]".("M_abeta_L_lysine[n]")                                   
"S_tau_L_lysine[c]".("M_tau_L_lysine[c]")                                   
"S_tau_L_lysine[n]".("M_tau_L_lysine[n]")                                   
"S_TNFA_L_lysine[c]".("M_TNFA_L_lysine[c]")                                 
"S_TNFA_L_lysine[n]".("M_TNFA_L_lysine[n]")                                 
"S_IL6_L_lysine[c]".("M_IL6_L_lysine[c]")                                   
"S_IL6_L_lysine[n]".("M_IL6_L_lysine[n]")                                   
"S_homoval[c]".("M_homoval[c]")                                 
"S_3hpp[c]".("M_3hpp[c]")                                   
"S_3mlda[c]".("M_3mlda[c]")                                 
"S_3mob[m]".("M_3mob[m]")                                   
"S_4mop[c]".("M_4mop[c]")                                   
"S_4mop[m]".("M_4mop[m]")                                   
"S_5adtststerones[c]".("M_5adtststerones[c]")                                   
"S_acetone[c]".("M_acetone[c]")                                 
"S_acnacngalgbside_hs[c]".("M_acnacngalgbside_hs[c]")                                   
"S_acnacngalgbside_hs[g]".("M_acnacngalgbside_hs[g]")                                   
"S_aprgstrn[c]".("M_aprgstrn[c]")                                   
"S_ala_B[m]".("M_ala_B[m]")                                 
"S_cbasp[c]".("M_cbasp[c]")                                 
"S_gm1_hs[g]".("M_gm1_hs[g]")                                   
"S_3uib[c]".("M_3uib[c]")                                   
"S_3aib_D[c]".("M_3aib_D[c]")                                   
"S_pmtcrn[m]".("M_pmtcrn[m]")                                   
"S_stcrn[m]".("M_stcrn[m]")                                 
"S_chsterols[c]".("M_chsterols[c]")                                 
"S_chsterol[g]".("M_chsterol[g]")                                   
"S_3aib_D[m]".("M_3aib_D[m]")                                   
"S_ditp[c]".("M_ditp[c]")                                   
"S_s2l2n2m2m[c]".("M_s2l2n2m2m[c]")                                 
"S_s2l2n2m2m[l]".("M_s2l2n2m2m[l]")                                 
"S_fuc_L[c]".("M_fuc_L[c]")                                 
"S_for[m]".("M_for[m]")                                 
"S_fuc_L[l]".("M_fuc_L[l]")                                 
"S_s2l2fn2m2masn[l]".("M_s2l2fn2m2masn[l]")                                 
"S_s2l2n2m2masn[l]".("M_s2l2n2m2masn[l]")                                   
"S_oxa[x]".("M_oxa[x]")                                 
"S_gt1a_hs[c]".("M_gt1a_hs[c]")                                 
"S_hestratriol[r]".("M_hestratriol[r]")                                 
"S_mhista[c]".("M_mhista[c]")                                   
"S_nrpphrsf[c]".("M_nrpphrsf[c]")                                   
"S_pac[c]".("M_pac[c]")                                 
"S_pchol_hs[g]".("M_pchol_hs[g]")                                   
"S_phpyr[c]".("M_phpyr[c]")                                 
"S_tre[c]".("M_tre[c]")                                 
"S_triodthysuf[c]".("M_triodthysuf[c]")                                 
"S_tststerones[c]".("M_tststerones[c]")                                 
"S_3hpp[m]".("M_3hpp[m]")                                   
"S_pac[m]".("M_pac[m]")                                 
"S_34dhoxmand[m]".("M_34dhoxmand[m]")                                   
"S_homoval[m]".("M_homoval[m]")                                 
"S_3mox4hoxm[m]".("M_3mox4hoxm[m]")                                 
"S_2obut[m]".("M_2obut[m]")                                 
"S_C11695[c]".("M_C11695[c]")                                   
"S_avite1[c]".("M_avite1[c]")                                   
"S_leuktrB4[x]".("M_leuktrB4[x]")                                   
"S_CE5304[c]".("M_CE5304[c]")                                   
"S_CE6247[c]".("M_CE6247[c]")                                   
"S_adpac[c]".("M_adpac[c]")                                 
"S_adpac[x]".("M_adpac[x]")                                 
"S_c101crn[c]".("M_c101crn[c]")                                 
"S_decdicrn[c]".("M_decdicrn[c]")                                   
"S_3deccrn[c]".("M_3deccrn[c]")                                 
"S_ddeccrn[c]".("M_ddeccrn[c]")                                 
"S_ddece1crn[c]".("M_ddece1crn[c]")                                 
"S_dodecanac[c]".("M_dodecanac[c]")                                 
"S_c12dc[c]".("M_c12dc[c]")                                 
"S_3ddcrn[c]".("M_3ddcrn[c]")                                   
"S_tetdece1crn[c]".("M_tetdece1crn[c]")                                 
"S_tetdec2crn[c]".("M_tetdec2crn[c]")                                   
"S_3tdcrn[c]".("M_3tdcrn[c]")                                   
"S_c16dc[c]".("M_c16dc[c]")                                 
"S_3octdece1crn[c]".("M_3octdece1crn[c]")                                   
"S_c3dc[c]".("M_c3dc[c]")                                   
"S_c4dc[c]".("M_c4dc[c]")                                   
"S_c6crn[c]".("M_c6crn[c]")                                 
"S_c81crn[c]".("M_c81crn[c]")                                   
"S_hexdiac[r]".("M_hexdiac[r]")                                 
"S_subeac[x]".("M_subeac[x]")                                   
"S_sebacid[x]".("M_sebacid[x]")                                 
"S_subeac[c]".("M_subeac[c]")                                   
"S_fe3[c]".("M_fe3[c]")                                 
"S_slfcys[c]".("M_slfcys[c]")                                   
"S_adpoh[c]".("M_adpoh[c]")                                 
"S_phlac[c]".("M_phlac[c]")                                 
"S_sphmyln18114_hs[c]".("M_sphmyln18114_hs[c]")                                 
"S_sphmyln18121_hs[c]".("M_sphmyln18121_hs[c]")                                 
"S_sphmyln181221_hs[c]".("M_sphmyln181221_hs[c]")                                   
"S_sphmyln18122_hs[c]".("M_sphmyln18122_hs[c]")                                 
"S_sphmyln18123_hs[c]".("M_sphmyln18123_hs[c]")                                 
"S_sphmyln180241_hs[c]".("M_sphmyln180241_hs[c]")                                   
"S_sphmyln1824_hs[c]".("M_sphmyln1824_hs[c]")                                   
"S_sphmyln1825_hs[c]".("M_sphmyln1825_hs[c]")                                   
"S_sphmyln18115_hs[c]".("M_sphmyln18115_hs[c]")                                 
"S_sphmyln181161_hs[c]".("M_sphmyln181161_hs[c]")                                   
"S_sphmyln18116_hs[c]".("M_sphmyln18116_hs[c]")                                 
"S_sphmyln18117_hs[c]".("M_sphmyln18117_hs[c]")                                 
"S_sphmyln18118_hs[c]".("M_sphmyln18118_hs[c]")                                 
"S_sphmyln181181_hs[c]".("M_sphmyln181181_hs[c]")                                   
"S_sphmyln181201_hs[c]".("M_sphmyln181201_hs[c]")                                   
"S_sphmyln18120_hs[c]".("M_sphmyln18120_hs[c]")                                 
"S_pcholmyr_hs[c]".("M_pcholmyr_hs[c]")                                 
"S_pcholole_hs[c]".("M_pcholole_hs[c]")                                 
"S_pcholpalme_hs[c]".("M_pcholpalme_hs[c]")                                 
"S_pcholpalm_hs[c]".("M_pcholpalm_hs[c]")                                   
"S_pcholste_hs[c]".("M_pcholste_hs[c]")                                 
"S_pchol2linl_hs[c]".("M_pchol2linl_hs[c]")                                 
"S_pchol2ole_hs[c]".("M_pchol2ole_hs[c]")                                   
"S_pchol2ste_hs[c]".("M_pchol2ste_hs[c]")                                   
"S_pcholn15_hs[c]".("M_pcholn15_hs[c]")                                 
"S_pcholar_hs[c]".("M_pcholar_hs[c]")                                   
"S_pcholn183_hs[c]".("M_pcholn183_hs[c]")                                   
"S_pcholn1836_hs[c]".("M_pcholn1836_hs[c]")                                 
"S_pcholn19_hs[c]".("M_pcholn19_hs[c]")                                 
"S_pcholn201_hs[c]".("M_pcholn201_hs[c]")                                   
"S_pcholn204_hs[c]".("M_pcholn204_hs[c]")                                   
"S_pcholn205_hs[c]".("M_pcholn205_hs[c]")                                   
"S_pcholn224_hs[c]".("M_pcholn224_hs[c]")                                   
"S_pcholn225_hs[c]".("M_pcholn225_hs[c]")                                   
"S_pcholn2254_hs[c]".("M_pcholn2254_hs[c]")                                 
"S_pcholn226_hs[c]".("M_pcholn226_hs[c]")                                   
"S_pcholn203_hs[c]".("M_pcholn203_hs[c]")                                   
"S_pcholn24_hs[c]".("M_pcholn24_hs[c]")                                 
"S_pcholdoc_hs[c]".("M_pcholdoc_hs[c]")                                 
"S_pcholeic_hs[c]".("M_pcholeic_hs[c]")                                 
"S_pcholet_hs[c]".("M_pcholet_hs[c]")                                   
"S_pcholhep_hs[c]".("M_pcholhep_hs[c]")                                 
"S_pchollinl_hs[c]".("M_pchollinl_hs[c]")                                   
"S_pheacgly[m]".("M_pheacgly[m]")                                   
"S_pheacgly[c]".("M_pheacgly[c]")                                   
"S_ppiogly[m]".("M_ppiogly[m]")                                 
"S_ppiogly[c]".("M_ppiogly[c]")                                 
"S_tiggly[m]".("M_tiggly[m]")                                   
"S_tiggly[c]".("M_tiggly[c]")                                   
"S_3hivac[m]".("M_3hivac[m]")                                   
"S_3hivac[c]".("M_3hivac[c]")                                   
"S_3hadpac[x]".("M_3hadpac[x]")                                 
"S_3hadpac[c]".("M_3hadpac[c]")                                 
"S_3ohsebac[x]".("M_3ohsebac[x]")                                   
"S_3ohsebac[c]".("M_3ohsebac[c]")                                   
"S_3ohsubac[x]".("M_3ohsubac[x]")                                   
"S_3ohsubac[c]".("M_3ohsubac[c]")                                   
"S_hexgly[c]".("M_hexgly[c]")                                   
"S_subgly[c]".("M_subgly[c]")                                   
"S_4ohbut[m]".("M_4ohbut[m]")                                   
"S_4ohbut[c]".("M_4ohbut[c]")                                   
"S_dag_hs[g]".("M_dag_hs[g]")                                   
"S_gd3_hs[m]".("M_gd3_hs[m]")                                   
"S_M03131[c]".("M_M03131[c]")                                   
"S_1hmdgluc[r]".("M_1hmdgluc[r]")                                   
"S_1hmdgluc[c]".("M_1hmdgluc[c]")                                   
"S_2hatvlac[r]".("M_2hatvlac[r]")                                   
"S_2hatvlacgluc[r]".("M_2hatvlacgluc[r]")                                   
"S_2hatvlacgluc[c]".("M_2hatvlacgluc[c]")                                   
"S_4hmdgluc[c]".("M_4hmdgluc[c]")                                   
"S_4hmdgluc[r]".("M_4hmdgluc[r]")                                   
"S_oxyp[c]".("M_oxyp[c]")                                   
"S_13dampp[c]".("M_13dampp[c]")                                 
"S_bamppald[c]".("M_bamppald[c]")                                   
"S_nadph[m]".("M_nadph[m]")                                 
"S_1a25dhvitd3[m]".("M_1a25dhvitd3[m]")                                 
"S_25hvitd2[m]".("M_25hvitd2[m]")                                   
"S_25hvitd3[m]".("M_25hvitd3[m]")                                   
"S_25hvitd2[c]".("M_25hvitd2[c]")                                   
"S_25hvitd3[c]".("M_25hvitd3[c]")                                   
"S_2amac[c]".("M_2amac[c]")                                 
"S_nadph[c]".("M_nadph[c]")                                 
"S_paps[c]".("M_paps[c]")                                   
"S_pap[c]".("M_pap[c]")                                 
"S_2dr1p[c]".("M_2dr1p[c]")                                 
"S_coa[m]".("M_coa[m]")                                 
"S_glutcoa[m]".("M_glutcoa[m]")                                 
"S_34dhmald[c]".("M_34dhmald[c]")                                   
"S_34dhpac[c]".("M_34dhpac[c]")                                 
"S_2mop[m]".("M_2mop[m]")                                   
"S_3dphb[m]".("M_3dphb[m]")                                 
"S_3dpdhb[m]".("M_3dpdhb[m]")                                   
"S_cmusa[c]".("M_cmusa[c]")                                 
"S_b2coa[m]".("M_b2coa[m]")                                 
"S_3hbcoa_R[m]".("M_3hbcoa_R[m]")                                   
"S_3hibutcoa[m]".("M_3hibutcoa[m]")                                 
"S_hLkynr[c]".("M_hLkynr[c]")                                   
"S_42A3HP24DB[c]".("M_42A3HP24DB[c]")                                   
"S_coa[c]".("M_coa[c]")                                 
"S_3sala[m]".("M_3sala[m]")                                 
"S_3sala[c]".("M_3sala[c]")                                 
"S_coucoa[m]".("M_coucoa[m]")                                   
"S_4hbzcoa[m]".("M_4hbzcoa[m]")                                 
"S_accoa[m]".("M_accoa[m]")                                 
"S_e4hglu[m]".("M_e4hglu[m]")                                   
"S_5hoxindact[c]".("M_5hoxindact[c]")                                   
"S_m2mn[l]".("M_m2mn[l]")                                   
"S_mn[l]".("M_mn[l]")                                   
"S_udpgal[c]".("M_udpgal[c]")                                   
"S_thcrm_hs[c]".("M_thcrm_hs[c]")                                   
"S_udpgal[g]".("M_udpgal[g]")                                   
"S_thcrm_hs[g]".("M_thcrm_hs[g]")                                   
"S_T_antigen[g]".("M_T_antigen[g]")                                 
"S_uacgam[g]".("M_uacgam[g]")                                   
"S_core2[g]".("M_core2[g]")                                 
"S_gncore2[g]".("M_gncore2[g]")                                 
"S_L2aadp6sa[m]".("M_L2aadp6sa[m]")                                 
"S_fucgalacglcgalgluside_hs[g]".("M_fucgalacglcgalgluside_hs[g]")                                   
"S_udpacgal[g]".("M_udpacgal[g]")                                   
"S_fuc12gal14acglcgalgluside_hs[g]".("M_fuc12gal14acglcgalgluside_hs[g]")                                   
"S_fucfucgalacglcgalacglcgal14acglcgalgluside_hs[g]".("M_fucfucgalacglcgalacglcgal14acglcgalgluside_hs[g]")                                 
"S_abt[c]".("M_abt[c]")                                 
"S_ppcoa[m]".("M_ppcoa[m]")                                 
"S_aacoa[m]".("M_aacoa[m]")                                 
"S_coa[x]".("M_coa[x]")                                 
"S_accoa[x]".("M_accoa[x]")                                 
"S_aacoa[x]".("M_aacoa[x]")                                 
"S_occoa[x]".("M_occoa[x]")                                 
"S_dcacoa[x]".("M_dcacoa[x]")                                   
"S_ddcacoa[x]".("M_ddcacoa[x]")                                 
"S_tdcoa[x]".("M_tdcoa[x]")                                 
"S_3ohodcoa[x]".("M_3ohodcoa[x]")                                   
"S_pmtcoa[x]".("M_pmtcoa[x]")                                   
"S_3ohxccoa[x]".("M_3ohxccoa[x]")                                   
"S_ttccoa[x]".("M_ttccoa[x]")                                   
"S_accoa[c]".("M_accoa[c]")                                 
"S_accoa[g]".("M_accoa[g]")                                 
"S_accoa[n]".("M_accoa[n]")                                 
"S_acgagbside_hs[c]".("M_acgagbside_hs[c]")                                 
"S_acgagbside_hs[g]".("M_acgagbside_hs[g]")                                 
"S_acgagbside_hs[l]".("M_acgagbside_hs[l]")                                 
"S_acgal1p[c]".("M_acgal1p[c]")                                 
"S_gam6p[c]".("M_gam6p[c]")                                 
"S_acgam6p[c]".("M_acgam6p[c]")                                 
"S_acgam1p[c]".("M_acgam1p[c]")                                 
"S_acgbgbside_hs[c]".("M_acgbgbside_hs[c]")                                 
"S_acgbgbside_hs[g]".("M_acgbgbside_hs[g]")                                 
"S_acgbgbside_hs[l]".("M_acgbgbside_hs[l]")                                 
"S_acgpail_hs[c]".("M_acgpail_hs[c]")                                   
"S_gpail_hs[c]".("M_gpail_hs[c]")                                   
"S_acmanap[c]".("M_acmanap[c]")                                 
"S_acnamp[c]".("M_acnamp[c]")                                   
"S_man6p[c]".("M_man6p[c]")                                 
"S_2mbcoa[m]".("M_2mbcoa[m]")                                   
"S_fad[m]".("M_fad[m]")                                 
"S_2mb2coa[m]".("M_2mb2coa[m]")                                 
"S_fadh2[m]".("M_fadh2[m]")                                 
"S_btcoa[m]".("M_btcoa[m]")                                 
"S_ibcoa[m]".("M_ibcoa[m]")                                 
"S_2mp2coa[m]".("M_2mp2coa[m]")                                 
"S_fad[x]".("M_fad[x]")                                 
"S_fadh2[x]".("M_fadh2[x]")                                 
"S_dhcholoylcoa[x]".("M_dhcholoylcoa[x]")                                   
"S_cholcoads[x]".("M_cholcoads[x]")                                 
"S_ppcoa[c]".("M_ppcoa[c]")                                 
"S_acetol[c]".("M_acetol[c]")                                   
"S_damp[c]".("M_damp[c]")                                   
"S_datp[c]".("M_datp[c]")                                   
"S_dadp[c]".("M_dadp[c]")                                   
"S_g1p[c]".("M_g1p[c]")                                 
"S_man1p[c]".("M_man1p[c]")                                 
"S_adrncoa[c]".("M_adrncoa[c]")                                 
"S_adrncoa[x]".("M_adrncoa[x]")                                 
"S_adrncrn[c]".("M_adrncrn[c]")                                 
"S_adrncoa[m]".("M_adrncoa[m]")                                 
"S_adrncrn[m]".("M_adrncrn[m]")                                 
"S_aps[c]".("M_aps[c]")                                 
"S_dcamp[c]".("M_dcamp[c]")                                 
"S_25aics[c]".("M_25aics[c]")                                   
"S_ksii_core4_pre2[g]".("M_ksii_core4_pre2[g]")                                 
"S_ksii_core4_pre3[g]".("M_ksii_core4_pre3[g]")                                 
"S_ksii_core4_pre4[g]".("M_ksii_core4_pre4[g]")                                 
"S_ksii_core4_pre5[g]".("M_ksii_core4_pre5[g]")                                 
"S_ksii_core4_pre7[g]".("M_ksii_core4_pre7[g]")                                 
"S_ksii_core4_pre8[g]".("M_ksii_core4_pre8[g]")                                 
"S_ksii_core2_pre2[g]".("M_ksii_core2_pre2[g]")                                 
"S_ksii_core2_pre3[g]".("M_ksii_core2_pre3[g]")                                 
"S_ksii_core2_pre4[g]".("M_ksii_core2_pre4[g]")                                 
"S_ksii_core2_pre5[g]".("M_ksii_core2_pre5[g]")                                 
"S_ksii_core2_pre7[g]".("M_ksii_core2_pre7[g]")                                 
"S_ksii_core2_pre8[g]".("M_ksii_core2_pre8[g]")                                 
"S_cdpchol[c]".("M_cdpchol[c]")                                 
"S_n2m2nmn[l]".("M_n2m2nmn[l]")                                 
"S_air[c]".("M_air[c]")                                 
"S_5aizc[c]".("M_5aizc[c]")                                 
"S_succoa[m]".("M_succoa[m]")                                   
"S_lald_D[c]".("M_lald_D[c]")                                   
"S_12ppd_S[c]".("M_12ppd_S[c]")                                 
"S_lald_L[c]".("M_lald_L[c]")                                   
"S_id3acald[c]".("M_id3acald[c]")                                   
"S_id3acald[m]".("M_id3acald[m]")                                   
"S_pristanal[c]".("M_pristanal[c]")                                 
"S_5HPET[c]".("M_5HPET[c]")                                 
"S_dhcholestancoa[x]".("M_dhcholestancoa[x]")                                   
"S_dhcholestancoa[r]".("M_dhcholestancoa[r]")                                   
"S_cholcoar[x]".("M_cholcoar[x]")                                   
"S_cholcoar[r]".("M_cholcoar[r]")                                   
"S_2aobut[m]".("M_2aobut[m]")                                   
"S_arachcoa[c]".("M_arachcoa[c]")                                   
"S_arachcoa[x]".("M_arachcoa[x]")                                   
"S_arachcoa[m]".("M_arachcoa[m]")                                   
"S_arachdcoa[c]".("M_arachdcoa[c]")                                 
"S_arachdcoa[x]".("M_arachdcoa[x]")                                 
"S_galside_hs[l]".("M_galside_hs[l]")                                   
"S_Rtotalcoa[c]".("M_Rtotalcoa[c]")                                 
"S_Rtotal3coa[c]".("M_Rtotal3coa[c]")                                   
"S_Rtotal3[c]".("M_Rtotal3[c]")                                 
"S_pmtcoa[c]".("M_pmtcoa[c]")                                   
"S_hdcoa[c]".("M_hdcoa[c]")                                 
"S_tdcoa[c]".("M_tdcoa[c]")                                 
"S_lnlncacoa[c]".("M_lnlncacoa[c]")                                 
"S_R2coa_hs[c]".("M_R2coa_hs[c]")                                   
"S_lnlncgcoa[c]".("M_lnlncgcoa[c]")                                 
"S_strdnccoa[c]".("M_strdnccoa[c]")                                 
"S_dlnlcgcoa[c]".("M_dlnlcgcoa[c]")                                 
"S_tmndnccoa[c]".("M_tmndnccoa[c]")                                 
"S_lnlccoa[c]".("M_lnlccoa[c]")                                 
"S_clpndcoa[c]".("M_clpndcoa[c]")                                   
"S_dcsptn1coa[c]".("M_dcsptn1coa[c]")                                   
"S_c226coa[c]".("M_c226coa[c]")                                 
"S_stcoa[c]".("M_stcoa[c]")                                 
"S_odecoa[c]".("M_odecoa[c]")                                   
"S_octd11ecoa[c]".("M_octd11ecoa[c]")                                   
"S_lneldccoa[c]".("M_lneldccoa[c]")                                 
"S_nrvnccoa[c]".("M_nrvnccoa[c]")                                   
"S_od2coa[c]".("M_od2coa[c]")                                   
"S_ttccoa[c]".("M_ttccoa[c]")                                   
"S_hexccoa[c]".("M_hexccoa[c]")                                 
"S_eicostetcoa[c]".("M_eicostetcoa[c]")                                 
"S_tetpent6coa[c]".("M_tetpent6coa[c]")                                 
"S_tetpent3coa[c]".("M_tetpent3coa[c]")                                 
"S_tettet6coa[c]".("M_tettet6coa[c]")                                   
"S_tethex3coa[c]".("M_tethex3coa[c]")                                   
"S_hdd2coa[c]".("M_hdd2coa[c]")                                 
"S_pmtcoa[m]".("M_pmtcoa[m]")                                   
"S_Asn_X_Ser_Thr[l]".("M_Asn_X_Ser_Thr[l]")                                 
"S_cbp[c]".("M_cbp[c]")                                 
"S_galgbside_hs[g]".("M_galgbside_hs[g]")                                   
"S_acglcgalgluside_hs[g]".("M_acglcgalgluside_hs[g]")                                   
"S_galacglcgalgluside_hs[g]".("M_galacglcgalgluside_hs[g]")                                 
"S_gal14acglcgalgluside_hs[g]".("M_gal14acglcgalgluside_hs[g]")                                 
"S_acglcgal14acglcgalgluside_hs[g]".("M_acglcgal14acglcgalgluside_hs[g]")                                   
"S_galacglcgal14acglcgalgluside_hs[g]".("M_galacglcgal14acglcgalgluside_hs[g]")                                 
"S_acglc13galacglcgal14acglcgalgluside_hs[g]".("M_acglc13galacglcgal14acglcgalgluside_hs[g]")                                   
"S_acglcgalacglcgal14acglcgalgluside_hs[g]".("M_acglcgalacglcgal14acglcgalgluside_hs[g]")                                   
"S_galacglcgalacglcgal14acglcgalgluside_hs[g]".("M_galacglcgalacglcgal14acglcgalgluside_hs[g]")                                 
"S_galacglc13galacglcgal14acglcgalgluside_hs[g]".("M_galacglc13galacglcgal14acglcgalgluside_hs[g]")                                 
"S_galthcrm_hs[g]".("M_galthcrm_hs[g]")                                 
"S_galgalthcrm_hs[g]".("M_galgalthcrm_hs[g]")                                   
"S_acglcgalgbside_hs[g]".("M_acglcgalgbside_hs[g]")                                 
"S_cholcoa[x]".("M_cholcoa[x]")                                 
"S_dgcholcoa[x]".("M_dgcholcoa[x]")                                 
"S_dcholcoa[x]".("M_dcholcoa[x]")                                   
"S_gdpmann[c]".("M_gdpmann[c]")                                 
"S_memgacpail_hs[r]".("M_memgacpail_hs[r]")                                 
"S_m2emgacpail_hs[r]".("M_m2emgacpail_hs[r]")                                   
"S_dolmanp_U[r]".("M_dolmanp_U[r]")                                 
"S_dolp_U[r]".("M_dolp_U[r]")                                   
"S_nadph[r]".("M_nadph[r]")                                 
"S_44mctr[r]".("M_44mctr[r]")                                   
"S_44mzym[r]".("M_44mzym[r]")                                   
"S_hdcoa[m]".("M_hdcoa[m]")                                 
"S_hdd2coa[m]".("M_hdd2coa[m]")                                 
"S_stcoa[m]".("M_stcoa[m]")                                 
"S_odecoa[m]".("M_odecoa[m]")                                   
"S_arachdcrn[c]".("M_arachdcrn[c]")                                 
"S_arachdcoa[m]".("M_arachdcoa[m]")                                 
"S_arachdcrn[m]".("M_arachdcrn[m]")                                 
"S_c226crn[c]".("M_c226crn[c]")                                 
"S_c226coa[m]".("M_c226coa[m]")                                 
"S_c226crn[m]".("M_c226crn[m]")                                 
"S_4mzym_int1[r]".("M_4mzym_int1[r]")                                   
"S_4mzym_int2[r]".("M_4mzym_int2[r]")                                   
"S_zym_int2[r]".("M_zym_int2[r]")                                   
"S_zymst[r]".("M_zymst[r]")                                 
"S_cbl2[c]".("M_cbl2[c]")                                   
"S_cbl2[m]".("M_cbl2[m]")                                   
"S_cbp[r]".("M_cbp[r]")                                 
"S_g6p[r]".("M_g6p[r]")                                 
"S_cdpdag_hs[c]".("M_cdpdag_hs[c]")                                 
"S_cdpdag_hs[m]".("M_cdpdag_hs[m]")                                 
"S_coa[n]".("M_coa[n]")                                 
"S_itaccoa[m]".("M_itaccoa[m]")                                 
"S_citmcoa_L[m]".("M_citmcoa_L[m]")                                 
"S_clpndcrn[c]".("M_clpndcrn[c]")                                   
"S_clpndcoa[m]".("M_clpndcoa[m]")                                   
"S_clpndcrn[m]".("M_clpndcrn[m]")                                   
"S_clpn_hs[c]".("M_clpn_hs[c]")                                 
"S_cmpacna[c]".("M_cmpacna[c]")                                 
"S_cmpacna[g]".("M_cmpacna[g]")                                 
"S_cmpacna[n]".("M_cmpacna[n]")                                 
"S_coa[g]".("M_coa[g]")                                 
"S_coa[l]".("M_coa[l]")                                 
"S_coa[r]".("M_coa[r]")                                 
"S_2dpmhobq[m]".("M_2dpmhobq[m]")                                   
"S_2dp6mobq[m]".("M_2dp6mobq[m]")                                   
"S_2dp6mobq_me[m]".("M_2dp6mobq_me[m]")                                 
"S_2dp6mep[m]".("M_2dp6mep[m]")                                 
"S_Tn_antigen[g]".("M_Tn_antigen[g]")                                   
"S_core3[g]".("M_core3[g]")                                 
"S_core5[g]".("M_core5[g]")                                 
"S_core6[g]".("M_core6[g]")                                 
"S_core7[g]".("M_core7[g]")                                 
"S_dmnoncrn[x]".("M_dmnoncrn[x]")                                   
"S_dmnoncrn[m]".("M_dmnoncrn[m]")                                   
"S_Ser_Gly_Ala_X_Gly[l]".("M_Ser_Gly_Ala_X_Gly[l]")                                 
"S_cs_a[l]".("M_cs_a[l]")                                   
"S_cs_e[l]".("M_cs_e[l]")                                   
"S_dmnoncoa[x]".("M_dmnoncoa[x]")                                   
"S_ppcoa[x]".("M_ppcoa[x]")                                 
"S_focytC[m]".("M_focytC[m]")                                   
"S_ficytC[m]".("M_ficytC[m]")                                   
"S_dgdp[c]".("M_dgdp[c]")                                   
"S_dcdp[c]".("M_dcdp[c]")                                   
"S_dcdp[n]".("M_dcdp[n]")                                   
"S_dctp[c]".("M_dctp[c]")                                   
"S_dctp[n]".("M_dctp[n]")                                   
"S_datp[n]".("M_datp[n]")                                   
"S_dadp[n]".("M_dadp[n]")                                   
"S_dd2coa[m]".("M_dd2coa[m]")                                   
"S_dd3coa[m]".("M_dd3coa[m]")                                   
"S_dcsptn1coa[x]".("M_dcsptn1coa[x]")                                   
"S_dcsptn1crn[c]".("M_dcsptn1crn[c]")                                   
"S_dcsptn1coa[m]".("M_dcsptn1coa[m]")                                   
"S_dcsptn1crn[m]".("M_dcsptn1crn[m]")                                   
"S_4h2oglt[m]".("M_4h2oglt[m]")                                 
"S_decdp[c]".("M_decdp[c]")                                 
"S_decdp[m]".("M_decdp[m]")                                 
"S_dedoldp_L[c]".("M_dedoldp_L[c]")                                 
"S_dedolp_L[c]".("M_dedolp_L[c]")                                   
"S_dedol_L[c]".("M_dedol_L[c]")                                 
"S_tag_hs[c]".("M_tag_hs[c]")                                   
"S_datp[m]".("M_datp[m]")                                   
"S_dadp[m]".("M_dadp[m]")                                   
"S_dgdp[m]".("M_dgdp[m]")                                   
"S_3dhguln[c]".("M_3dhguln[c]")                                 
"S_fad[r]".("M_fad[r]")                                 
"S_fadh2[r]".("M_fadh2[r]")                                 
"S_zymstnl[r]".("M_zymstnl[r]")                                 
"S_chlstol[r]".("M_chlstol[r]")                                 
"S_ddsmsterol[r]".("M_ddsmsterol[r]")                                   
"S_dhcrm_hs[c]".("M_dhcrm_hs[c]")                                   
"S_fad[c]".("M_fad[c]")                                 
"S_fadh2[c]".("M_fadh2[c]")                                 
"S_3dpdhb_me[m]".("M_3dpdhb_me[m]")                                 
"S_dkmpp[c]".("M_dkmpp[c]")                                 
"S_2kmb[c]".("M_2kmb[c]")                                   
"S_dlnlcgcrn[c]".("M_dlnlcgcrn[c]")                                 
"S_dlnlcgcoa[m]".("M_dlnlcgcoa[m]")                                 
"S_dlnlcgcrn[m]".("M_dlnlcgcrn[m]")                                 
"S_dctp[m]".("M_dctp[m]")                                   
"S_dem2emgacpail_prot_hs[r]".("M_dem2emgacpail_prot_hs[r]")                                 
"S_dgpi_prot_hs[r]".("M_dgpi_prot_hs[r]")                                   
"S_gpi_sig[r]".("M_gpi_sig[r]")                                 
"S_mem2emgacpail_prot_hs[r]".("M_mem2emgacpail_prot_hs[r]")                                 
"S_Ser_Thr[l]".("M_Ser_Thr[l]")                                 
"S_dmhptcoa[m]".("M_dmhptcoa[m]")                                   
"S_dmnoncrn[c]".("M_dmnoncrn[c]")                                   
"S_dmnoncoa[c]".("M_dmnoncoa[c]")                                   
"S_dmnoncoa[m]".("M_dmnoncoa[m]")                                   
"S_dnad[c]".("M_dnad[c]")                                   
"S_dnad[n]".("M_dnad[n]")                                   
"S_dcdp[m]".("M_dcdp[m]")                                   
"S_dudp[c]".("M_dudp[c]")                                   
"S_dudp[m]".("M_dudp[m]")                                   
"S_dutp[c]".("M_dutp[c]")                                   
"S_dutp[m]".("M_dutp[m]")                                   
"S_dolp_U[c]".("M_dolp_U[c]")                                   
"S_dolmanp_U[c]".("M_dolmanp_U[c]")                                 
"S_dopaqn[c]".("M_dopaqn[c]")                                   
"S_dpcoa[l]".("M_dpcoa[l]")                                 
"S_dpcoa[c]".("M_dpcoa[c]")                                 
"S_23dpg[c]".("M_23dpg[c]")                                 
"S_13dpg[c]".("M_13dpg[c]")                                 
"S_ipdp[c]".("M_ipdp[c]")                                   
"S_frdp[c]".("M_frdp[c]")                                   
"S_2dr5p[c]".("M_2dr5p[c]")                                 
"S_g3p[c]".("M_g3p[c]")                                 
"S_dump[c]".("M_dump[c]")                                   
"S_dump[m]".("M_dump[m]")                                   
"S_3hbcoa[m]".("M_3hbcoa[m]")                                   
"S_b2coa[x]".("M_b2coa[x]")                                 
"S_3hbcoa[x]".("M_3hbcoa[x]")                                   
"S_3hmbcoa[m]".("M_3hmbcoa[m]")                                 
"S_eicostetcrn[c]".("M_eicostetcrn[c]")                                 
"S_eicostetcoa[m]".("M_eicostetcoa[m]")                                 
"S_eicostetcrn[m]".("M_eicostetcrn[m]")                                 
"S_od2coa[m]".("M_od2coa[m]")                                   
"S_n2m2nm[l]".("M_n2m2nm[l]")                                   
"S_gdpfuc[c]".("M_gdpfuc[c]")                                   
"S_gdpfuc[g]".("M_gdpfuc[g]")                                   
"S_ptdcacoa[c]".("M_ptdcacoa[c]")                                   
"S_hpdcacoa[c]".("M_hpdcacoa[c]")                                   
"S_pristcoa[c]".("M_pristcoa[c]")                                   
"S_phytcoa[c]".("M_phytcoa[c]")                                 
"S_occoa[c]".("M_occoa[c]")                                 
"S_malcoa[c]".("M_malcoa[c]")                                   
"S_Sfglutth[c]".("M_Sfglutth[c]")                                   
"S_tdcoa[m]".("M_tdcoa[m]")                                 
"S_ptdcacoa[m]".("M_ptdcacoa[m]")                                   
"S_occoa[m]".("M_occoa[m]")                                 
"S_hpdcacoa[m]".("M_hpdcacoa[m]")                                   
"S_stcoa[x]".("M_stcoa[x]")                                 
"S_lnlccoa[m]".("M_lnlccoa[m]")                                 
"S_lneldccoa[m]".("M_lneldccoa[m]")                                 
"S_lnlncacoa[m]".("M_lnlncacoa[m]")                                 
"S_lnlncgcoa[m]".("M_lnlncgcoa[m]")                                 
"S_lnlncgcoa[x]".("M_lnlncgcoa[x]")                                 
"S_strdnccoa[m]".("M_strdnccoa[m]")                                 
"S_strdnccoa[x]".("M_strdnccoa[x]")                                 
"S_tmndnccoa[m]".("M_tmndnccoa[m]")                                 
"S_tmndnccoa[x]".("M_tmndnccoa[x]")                                 
"S_odecoa[x]".("M_odecoa[x]")                                   
"S_nrvnccoa[x]".("M_nrvnccoa[x]")                                   
"S_tetpent6coa[x]".("M_tetpent6coa[x]")                                 
"S_hexccoa[x]".("M_hexccoa[x]")                                 
"S_dcacoa[c]".("M_dcacoa[c]")                                   
"S_ddcacoa[c]".("M_ddcacoa[c]")                                 
"S_xu1p_D[c]".("M_xu1p_D[c]")                                   
"S_gcald[c]".("M_gcald[c]")                                 
"S_tag1p_D[c]".("M_tag1p_D[c]")                                 
"S_f6p[c]".("M_f6p[c]")                                 
"S_f26bp[c]".("M_f26bp[c]")                                 
"S_ppp9[m]".("M_ppp9[m]")                                   
"S_formcoa[c]".("M_formcoa[c]")                                 
"S_formcoa[x]".("M_formcoa[x]")                                 
"S_frdp[r]".("M_frdp[r]")                                   
"S_fucgalacglc13galacglcgal14acglcgalgluside_hs[g]".("M_fucgalacglc13galacglcgal14acglcgalgluside_hs[g]")                                   
"S_fucfucgalacglc13galacglcgal14acglcgalgluside_hs[g]".("M_fucfucgalacglc13galacglcgal14acglcgalgluside_hs[g]")                                 
"S_ksii_core4_pre1[g]".("M_ksii_core4_pre1[g]")                                 
"S_ksii_core4_pre6[g]".("M_ksii_core4_pre6[g]")                                 
"S_ksii_core4_pre9[g]".("M_ksii_core4_pre9[g]")                                 
"S_ksii_core4_pre10[g]".("M_ksii_core4_pre10[g]")                                   
"S_ksii_core2_pre1[g]".("M_ksii_core2_pre1[g]")                                 
"S_ksii_core2_pre6[g]".("M_ksii_core2_pre6[g]")                                 
"S_ksii_core2_pre9[g]".("M_ksii_core2_pre9[g]")                                 
"S_ksii_core2_pre10[g]".("M_ksii_core2_pre10[g]")                                   
"S_glu5sa[m]".("M_glu5sa[m]")                                   
"S_1pyr5c[m]".("M_1pyr5c[m]")                                   
"S_glu5p[m]".("M_glu5p[m]")                                 
"S_g6p[c]".("M_g6p[c]")                                 
"S_gacpail_hs[c]".("M_gacpail_hs[c]")                                   
"S_gacpail_hs[r]".("M_gacpail_hs[r]")                                   
"S_paps[g]".("M_paps[g]")                                   
"S_pap[g]".("M_pap[g]")                                 
"S_core6[l]".("M_core6[l]")                                 
"S_cs_hs_linkage[g]".("M_cs_hs_linkage[g]")                                 
"S_cs_pre[g]".("M_cs_pre[g]")                                   
"S_cs_a_b_pre2[g]".("M_cs_a_b_pre2[g]")                                 
"S_cs_a_b_pre3[g]".("M_cs_a_b_pre3[g]")                                 
"S_cs_c_pre2[g]".("M_cs_c_pre2[g]")                                 
"S_cs_c_pre3[g]".("M_cs_c_pre3[g]")                                 
"S_cs_d_pre3[g]".("M_cs_d_pre3[g]")                                 
"S_cs_d_pre4[g]".("M_cs_d_pre4[g]")                                 
"S_cs_e_pre3[g]".("M_cs_e_pre3[g]")                                 
"S_cs_e_pre4[g]".("M_cs_e_pre4[g]")                                 
"S_Ser_Thr[g]".("M_Ser_Thr[g]")                                 
"S_galside_hs[c]".("M_galside_hs[c]")                                   
"S_lxser[g]".("M_lxser[g]")                                 
"S_l2xser[g]".("M_l2xser[g]")                                   
"S_xser[g]".("M_xser[g]")                                   
"S_gar[c]".("M_gar[c]")                                 
"S_fgam[c]".("M_fgam[c]")                                   
"S_gcald[m]".("M_gcald[m]")                                 
"S_lpam[m]".("M_lpam[m]")                                   
"S_dhlam[m]".("M_dhlam[m]")                                 
"S_gdpddman[c]".("M_gdpddman[c]")                                   
"S_udpg[c]".("M_udpg[c]")                                   
"S_ttc_ggdp[c]".("M_ttc_ggdp[c]")                                   
"S_3htmelys[c]".("M_3htmelys[c]")                                   
"S_4tmeabut[c]".("M_4tmeabut[c]")                                   
"S_glac[c]".("M_glac[c]")                                   
"S_glac[r]".("M_glac[r]")                                   
"S_hs_deg9[l]".("M_hs_deg9[l]")                                 
"S_hs_deg10[l]".("M_hs_deg10[l]")                                   
"S_cs_a_deg2[l]".("M_cs_a_deg2[l]")                                 
"S_cs_a_deg3[l]".("M_cs_a_deg3[l]")                                 
"S_cs_e_deg3[l]".("M_cs_e_deg3[l]")                                 
"S_cs_e_deg4[l]".("M_cs_e_deg4[l]")                                 
"S_ha_deg1[l]".("M_ha_deg1[l]")                                 
"S_hs_pre10[g]".("M_hs_pre10[g]")                                   
"S_hs_pre11[g]".("M_hs_pre11[g]")                                   
"S_cs_a_b_e_pre1[g]".("M_cs_a_b_e_pre1[g]")                                 
"S_cs_c_d_e_pre1[g]".("M_cs_c_d_e_pre1[g]")                                 
"S_cs_d_pre2[g]".("M_cs_d_pre2[g]")                                 
"S_cs_e_pre2[g]".("M_cs_e_pre2[g]")                                 
"S_hs_pre1[g]".("M_hs_pre1[g]")                                 
"S_hs_pre2[g]".("M_hs_pre2[g]")                                 
"S_hs_pre3[g]".("M_hs_pre3[g]")                                 
"S_hs_pre4[g]".("M_hs_pre4[g]")                                 
"S_hs_pre5[g]".("M_hs_pre5[g]")                                 
"S_hs_pre6[g]".("M_hs_pre6[g]")                                 
"S_hs_pre7[g]".("M_hs_pre7[g]")                                 
"S_hs_pre8[g]".("M_hs_pre8[g]")                                 
"S_hs_deg3[l]".("M_hs_deg3[l]")                                 
"S_hs_deg4[l]".("M_hs_deg4[l]")                                 
"S_hs_deg8[l]".("M_hs_deg8[l]")                                 
"S_hs_deg14[l]".("M_hs_deg14[l]")                                   
"S_hs_deg15[l]".("M_hs_deg15[l]")                                   
"S_hs_deg20[l]".("M_hs_deg20[l]")                                   
"S_hs_deg21[l]".("M_hs_deg21[l]")                                   
"S_hs_deg24[l]".("M_hs_deg24[l]")                                   
"S_hs_deg25[l]".("M_hs_deg25[l]")                                   
"S_hs_pre9[g]".("M_hs_pre9[g]")                                 
"S_uacgam[c]".("M_uacgam[c]")                                   
"S_glygn3[c]".("M_glygn3[c]")                                   
"S_guln[r]".("M_guln[r]")                                   
"S_glucys[c]".("M_glucys[c]")                                   
"S_5forthf[c]".("M_5forthf[c]")                                 
"S_em2emgacpail_prot_hs[r]".("M_em2emgacpail_prot_hs[r]")                                   
"S_gpi_prot_hs[r]".("M_gpi_prot_hs[r]")                                 
"S_mgacpail_hs[r]".("M_mgacpail_hs[r]")                                 
"S_guln[c]".("M_guln[c]")                                   
"S_emgacpail_hs[r]".("M_emgacpail_hs[r]")                                   
"S_m2gacpail_hs[r]".("M_m2gacpail_hs[r]")                                   
"S_m3gacpail_hs[r]".("M_m3gacpail_hs[r]")                                   
"S_em3gacpail_hs[r]".("M_em3gacpail_hs[r]")                                 
"S_emem2gacpail_hs[r]".("M_emem2gacpail_hs[r]")                                 
"S_em2emgacpail_hs[r]".("M_em2emgacpail_hs[r]")                                 
"S_m3emgacpail_hs[r]".("M_m3emgacpail_hs[r]")                                   
"S_gpi_hs[r]".("M_gpi_hs[r]")                                   
"S_mem2emgacpail_hs[r]".("M_mem2emgacpail_hs[r]")                                   
"S_pre_prot[r]".("M_pre_prot[r]")                                   
"S_im4act[c]".("M_im4act[c]")                                   
"S_aacoa[c]".("M_aacoa[c]")                                 
"S_hmgcoa[c]".("M_hmgcoa[c]")                                   
"S_hmgcoa[m]".("M_hmgcoa[m]")                                   
"S_hmgcoa[x]".("M_hmgcoa[x]")                                   
"S_pristanal[x]".("M_pristanal[x]")                                 
"S_phyt2ohcoa[x]".("M_phyt2ohcoa[x]")                                   
"S_hpdcacrn[c]".("M_hpdcacrn[c]")                                   
"S_hpdcacrn[m]".("M_hpdcacrn[m]")                                   
"S_hpyr[c]".("M_hpyr[c]")                                   
"S_hpyr[m]".("M_hpyr[m]")                                   
"S_hpyr[x]".("M_hpyr[x]")                                   
"S_hs_deg1[l]".("M_hs_deg1[l]")                                 
"S_hs_deg2[l]".("M_hs_deg2[l]")                                 
"S_hs_deg6[l]".("M_hs_deg6[l]")                                 
"S_hs_deg7[l]".("M_hs_deg7[l]")                                 
"S_hs_deg12[l]".("M_hs_deg12[l]")                                   
"S_hs_deg13[l]".("M_hs_deg13[l]")                                   
"S_hs_deg18[l]".("M_hs_deg18[l]")                                   
"S_hs_deg19[l]".("M_hs_deg19[l]")                                   
"S_andrstndn[r]".("M_andrstndn[r]")                                 
"S_nadph[x]".("M_nadph[x]")                                 
"S_cholcoaone[x]".("M_cholcoaone[x]")                                   
"S_eandrstrn[r]".("M_eandrstrn[r]")                                 
"S_prgnlone[c]".("M_prgnlone[c]")                                   
"S_prgnlone[r]".("M_prgnlone[r]")                                   
"S_17ahprgnlone[c]".("M_17ahprgnlone[c]")                                   
"S_17ahprgstrn[c]".("M_17ahprgstrn[c]")                                 
"S_17ahprgnlone[r]".("M_17ahprgnlone[r]")                                   
"S_17ahprgstrn[r]".("M_17ahprgstrn[r]")                                 
"S_hs[l]".("M_hs[l]")                                   
"S_iodine[c]".("M_iodine[c]")                                   
"S_hs_deg5[l]".("M_hs_deg5[l]")                                 
"S_hs_deg16[l]".("M_hs_deg16[l]")                                   
"S_hs_deg17[l]".("M_hs_deg17[l]")                                   
"S_hs_deg22[l]".("M_hs_deg22[l]")                                   
"S_hs_deg23[l]".("M_hs_deg23[l]")                                   
"S_f1p[c]".("M_f1p[c]")                                 
"S_4aphdob[c]".("M_4aphdob[c]")                                 
"S_lgt_S[c]".("M_lgt_S[c]")                                 
"S_lald_L[m]".("M_lald_L[m]")                                   
"S_cs_a_deg5[l]".("M_cs_a_deg5[l]")                                 
"S_cs_e_deg7[l]".("M_cs_e_deg7[l]")                                 
"S_lnlncacrn[c]".("M_lnlncacrn[c]")                                 
"S_lnlncacrn[m]".("M_lnlncacrn[m]")                                 
"S_lnlncgcrn[c]".("M_lnlncgcrn[c]")                                 
"S_lnlncgcrn[m]".("M_lnlncgcrn[m]")                                 
"S_44mctr[c]".("M_44mctr[c]")                                   
"S_Ssq23epx[r]".("M_Ssq23epx[r]")                                   
"S_retinol_cis_11[c]".("M_retinol_cis_11[c]")                                   
"S_retinol_9_cis[c]".("M_retinol_9_cis[c]")                                 
"S_3mgcoa[m]".("M_3mgcoa[m]")                                   
"S_5mdru1p[c]".("M_5mdru1p[c]")                                 
"S_minohp[c]".("M_minohp[c]")                                   
"S_mi1345p[c]".("M_mi1345p[c]")                                 
"S_mi134p[c]".("M_mi134p[c]")                                   
"S_mi145p[c]".("M_mi145p[c]")                                   
"S_mi14p[c]".("M_mi14p[c]")                                 
"S_mi3p_D[c]".("M_mi3p_D[c]")                                   
"S_minohp[n]".("M_minohp[n]")                                   
"S_5mdr1p[c]".("M_5mdr1p[c]")                                   
"S_cs_a_deg1[l]".("M_cs_a_deg1[l]")                                 
"S_cs_a_deg4[l]".("M_cs_a_deg4[l]")                                 
"S_udpacgal[l]".("M_udpacgal[l]")                                   
"S_Tn_antigen[l]".("M_Tn_antigen[l]")                                   
"S_nicrns[c]".("M_nicrns[c]")                                   
"S_nmn[m]".("M_nmn[m]")                                 
"S_nmn[n]".("M_nmn[n]")                                 
"S_nmn[c]".("M_nmn[c]")                                 
"S_prpp[c]".("M_prpp[c]")                                   
"S_r1p[c]".("M_r1p[c]")                                 
"S_prgnlone[m]".("M_prgnlone[m]")                                   
"S_20ahchsterol[m]".("M_20ahchsterol[m]")                                   
"S_pail45p_hs[c]".("M_pail45p_hs[c]")                                   
"S_pail45p_hs[n]".("M_pail45p_hs[n]")                                   
"S_pail4p_hs[c]".("M_pail4p_hs[c]")                                 
"S_pail4p_hs[n]".("M_pail4p_hs[n]")                                 
"S_pan4p[c]".("M_pan4p[c]")                                 
"S_pristcoa[x]".("M_pristcoa[x]")                                   
"S_1p3h5c[m]".("M_1p3h5c[m]")                                   
"S_thbpt4acam[c]".("M_thbpt4acam[c]")                                   
"S_phytcoa[x]".("M_phytcoa[x]")                                 
"S_pail345p_hs[c]".("M_pail345p_hs[c]")                                 
"S_pail34p_hs[c]".("M_pail34p_hs[c]")                                   
"S_pail3p_hs[c]".("M_pail3p_hs[c]")                                 
"S_pail35p_hs[c]".("M_pail35p_hs[c]")                                   
"S_pail5p_hs[c]".("M_pail5p_hs[c]")                                 
"S_pail5p_hs[n]".("M_pail5p_hs[n]")                                 
"S_ppmi12346p[c]".("M_ppmi12346p[c]")                                   
"S_ppmi12346p[n]".("M_ppmi12346p[n]")                                   
"S_pppg9[c]".("M_pppg9[c]")                                 
"S_pppg9[m]".("M_pppg9[m]")                                 
"S_pram[c]".("M_pram[c]")                                   
"S_ptdcacrn[c]".("M_ptdcacrn[c]")                                   
"S_ptdcacrn[m]".("M_ptdcacrn[m]")                                   
"S_quln[c]".("M_quln[c]")                                   
"S_retinal_cis_13[c]".("M_retinal_cis_13[c]")                                   
"S_retinal_11_cis[c]".("M_retinal_11_cis[c]")                                   
"S_retinal_cis_9[c]".("M_retinal_cis_9[c]")                                 
"S_ru5p_D[c]".("M_ru5p_D[c]")                                   
"S_retinol_cis_13[c]".("M_retinol_cis_13[c]")                                   
"S_retn[r]".("M_retn[r]")                                   
"S_rnam[c]".("M_rnam[c]")                                   
"S_cs_d_pre5[g]".("M_cs_d_pre5[g]")                                 
"S_hs_pre12[g]".("M_hs_pre12[g]")                                   
"S_hs_pre13[g]".("M_hs_pre13[g]")                                   
"S_hs_pre14[g]".("M_hs_pre14[g]")                                   
"S_hs_pre15[g]".("M_hs_pre15[g]")                                   
"S_hs_deg11[l]".("M_hs_deg11[l]")                                   
"S_cs_e_pre5b[g]".("M_cs_e_pre5b[g]")                                   
"S_strdnccrn[c]".("M_strdnccrn[c]")                                 
"S_strdnccrn[m]".("M_strdnccrn[m]")                                 
"S_thmpp[c]".("M_thmpp[c]")                                 
"S_tmndnccrn[c]".("M_tmndnccrn[c]")                                 
"S_tmndnccrn[m]".("M_tmndnccrn[m]")                                 
"S_udpacgal[c]".("M_udpacgal[c]")                                   
"S_udpxyl[r]".("M_udpxyl[r]")                                   
"S_xser[r]".("M_xser[r]")                                   
"S_xu5p_D[c]".("M_xu5p_D[c]")                                   
"S_Ser_Gly_Ala_X_Gly[r]".("M_Ser_Gly_Ala_X_Gly[r]")                                 
"S_dpcoa[m]".("M_dpcoa[m]")                                 
"S_HC01672[c]".("M_HC01672[c]")                                 
"S_HC01434[m]".("M_HC01434[m]")                                 
"S_HC01434[x]".("M_HC01434[x]")                                 
"S_HC00591[c]".("M_HC00591[c]")                                 
"S_uacgam[r]".("M_uacgam[r]")                                   
"S_HC01496[m]".("M_HC01496[m]")                                 
"S_HC01668[m]".("M_HC01668[m]")                                 
"S_pmtcoa[r]".("M_pmtcoa[r]")                                   
"S_HC00342[m]".("M_HC00342[m]")                                 
"S_e4p[c]".("M_e4p[c]")                                 
"S_HC00361[c]".("M_HC00361[c]")                                 
"S_s7p[c]".("M_s7p[c]")                                 
"S_lnlccoa[r]".("M_lnlccoa[r]")                                 
"S_lnlccoa[x]".("M_lnlccoa[x]")                                 
"S_arachdcoa[r]".("M_arachdcoa[r]")                                 
"S_HC01712[m]".("M_HC01712[m]")                                 
"S_HC00718[c]".("M_HC00718[c]")                                 
"S_cholcoa[r]".("M_cholcoa[r]")                                 
"S_pan4p[m]".("M_pan4p[m]")                                 
"S_L2aadp6sa[c]".("M_L2aadp6sa[c]")                                 
"S_HC00664[c]".("M_HC00664[c]")                                 
"S_HC01180[c]".("M_HC01180[c]")                                 
"S_1p3h5c[c]".("M_1p3h5c[c]")                                   
"S_cholcoa[c]".("M_cholcoa[c]")                                 
"S_HC01415[m]".("M_HC01415[m]")                                 
"S_ddcacoa[m]".("M_ddcacoa[m]")                                 
"S_2mop[c]".("M_2mop[c]")                                   
"S_dcholcoa[r]".("M_dcholcoa[r]")                                   
"S_dcholcoa[c]".("M_dcholcoa[c]")                                   
"S_HC01412[m]".("M_HC01412[m]")                                 
"S_dd2coa[x]".("M_dd2coa[x]")                                   
"S_fpram[c]".("M_fpram[c]")                                 
"S_xol7ah2al[c]".("M_xol7ah2al[c]")                                 
"S_dcacoa[m]".("M_dcacoa[m]")                                   
"S_dc2coa[m]".("M_dc2coa[m]")                                   
"S_dc2coa[x]".("M_dc2coa[x]")                                   
"S_hx2coa[m]".("M_hx2coa[m]")                                   
"S_HC01842[c]".("M_HC01842[c]")                                 
"S_r5p[c]".("M_r5p[c]")                                 
"S_HC02110[r]".("M_HC02110[r]")                                 
"S_cdpchol[r]".("M_cdpchol[r]")                                 
"S_hdd2coa[r]".("M_hdd2coa[r]")                                 
"S_HC02021[r]".("M_HC02021[r]")                                 
"S_stcoa[r]".("M_stcoa[r]")                                 
"S_HC02022[r]".("M_HC02022[r]")                                 
"S_odecoa[r]".("M_odecoa[r]")                                   
"S_HC02023[r]".("M_HC02023[r]")                                 
"S_lnlncgcoa[r]".("M_lnlncgcoa[r]")                                 
"S_HC02027[r]".("M_HC02027[r]")                                 
"S_HC02121[c]".("M_HC02121[c]")                                 
"S_btcoa[c]".("M_btcoa[c]")                                 
"S_dlnlcgcoa[r]".("M_dlnlcgcoa[r]")                                 
"S_HC10856[m]".("M_HC10856[m]")                                 
"S_HC10857[m]".("M_HC10857[m]")                                 
"S_HC10858[m]".("M_HC10858[m]")                                 
"S_CE2421[m]".("M_CE2421[m]")                                   
"S_CE0713[m]".("M_CE0713[m]")                                   
"S_CE2421[x]".("M_CE2421[x]")                                   
"S_CE0713[x]".("M_CE0713[x]")                                   
"S_CE2253[c]".("M_CE2253[c]")                                   
"S_CE2249[c]".("M_CE2249[c]")                                   
"S_CE2245[c]".("M_CE2245[c]")                                   
"S_docoscoa[c]".("M_docoscoa[c]")                                   
"S_docoscoa[m]".("M_docoscoa[m]")                                   
"S_docoscoa[x]".("M_docoscoa[x]")                                   
"S_CE1944[c]".("M_CE1944[c]")                                   
"S_CE2866[c]".("M_CE2866[c]")                                   
"S_andrstndn[c]".("M_andrstndn[c]")                                 
"S_CE2434[m]".("M_CE2434[m]")                                   
"S_CE2434[x]".("M_CE2434[x]")                                   
"S_CE0849[m]".("M_CE0849[m]")                                   
"S_CE2433[m]".("M_CE2433[m]")                                   
"S_CE0849[x]".("M_CE0849[x]")                                   
"S_CE2433[x]".("M_CE2433[x]")                                   
"S_CE0785[m]".("M_CE0785[m]")                                   
"S_CE2432[m]".("M_CE2432[m]")                                   
"S_CE0785[x]".("M_CE0785[x]")                                   
"S_CE2432[x]".("M_CE2432[x]")                                   
"S_dec24dicoa[x]".("M_dec24dicoa[x]")                                   
"S_dece4coa[x]".("M_dece4coa[x]")                                   
"S_C05279[m]".("M_C05279[m]")                                   
"S_CE2420[m]".("M_CE2420[m]")                                   
"S_C05279[x]".("M_C05279[x]")                                   
"S_CE2420[x]".("M_CE2420[x]")                                   
"S_CE2417[m]".("M_CE2417[m]")                                   
"S_CE2417[x]".("M_CE2417[x]")                                   
"S_CE2418[m]".("M_CE2418[m]")                                   
"S_CE2418[x]".("M_CE2418[x]")                                   
"S_CE2422[m]".("M_CE2422[m]")                                   
"S_CE2422[x]".("M_CE2422[x]")                                   
"S_CE2424[m]".("M_CE2424[m]")                                   
"S_CE2424[x]".("M_CE2424[x]")                                   
"S_CE0693[m]".("M_CE0693[m]")                                   
"S_CE0693[x]".("M_CE0693[x]")                                   
"S_C05280[m]".("M_C05280[m]")                                   
"S_C05280[x]".("M_C05280[x]")                                   
"S_dece4coa[m]".("M_dece4coa[m]")                                   
"S_CE4888[c]".("M_CE4888[c]")                                   
"S_CE5253[c]".("M_CE5253[c]")                                   
"S_cholcoa[m]".("M_cholcoa[m]")                                 
"S_dhcholestancoa[c]".("M_dhcholestancoa[c]")                                   
"S_CE5586[c]".("M_CE5586[c]")                                   
"S_retinal_cis_13[r]".("M_retinal_cis_13[r]")                                   
"S_CE5626[c]".("M_CE5626[c]")                                   
"S_C02712[m]".("M_C02712[m]")                                   
"S_CE5276[c]".("M_CE5276[c]")                                   
"S_CE5021[c]".("M_CE5021[c]")                                   
"S_CE5022[c]".("M_CE5022[c]")                                   
"S_CE2576[c]".("M_CE2576[c]")                                   
"S_CE2577[c]".("M_CE2577[c]")                                   
"S_C05109[c]".("M_C05109[c]")                                   
"S_ddsmsterol[c]".("M_ddsmsterol[c]")                                   
"S_CE5665[c]".("M_CE5665[c]")                                   
"S_cholcoar[m]".("M_cholcoar[m]")                                   
"S_CE5166[m]".("M_CE5166[m]")                                   
"S_C02712[c]".("M_C02712[c]")                                   
"S_udpgal[n]".("M_udpgal[n]")                                   
"S_galside_hs[n]".("M_galside_hs[n]")                                   
"S_udpgal[r]".("M_udpgal[r]")                                   
"S_C01747[l]".("M_C01747[l]")                                   
"S_C01747[c]".("M_C01747[c]")                                   
"S_CE5125[x]".("M_CE5125[x]")                                   
"S_CE5126[x]".("M_CE5126[x]")                                   
"S_pail35p_hs[n]".("M_pail35p_hs[n]")                                   
"S_CE4795[m]".("M_CE4795[m]")                                   
"S_CE4795[x]".("M_CE4795[x]")                                   
"S_CE5114[x]".("M_CE5114[x]")                                   
"S_CE4791[x]".("M_CE4791[x]")                                   
"S_CE4793[x]".("M_CE4793[x]")                                   
"S_CE2439[x]".("M_CE2439[x]")                                   
"S_CE2440[x]".("M_CE2440[x]")                                   
"S_CE2437[x]".("M_CE2437[x]")                                   
"S_CE2438[x]".("M_CE2438[x]")                                   
"S_CE2442[m]".("M_CE2442[m]")                                   
"S_CE2442[x]".("M_CE2442[x]")                                   
"S_CE2441[x]".("M_CE2441[x]")                                   
"S_CE5116[x]".("M_CE5116[x]")                                   
"S_CE5117[m]".("M_CE5117[m]")                                   
"S_CE5118[m]".("M_CE5118[m]")                                   
"S_CE5119[m]".("M_CE5119[m]")                                   
"S_CE5120[m]".("M_CE5120[m]")                                   
"S_CE4790[m]".("M_CE4790[m]")                                   
"S_CE4792[m]".("M_CE4792[m]")                                   
"S_CE4794[m]".("M_CE4794[m]")                                   
"S_CE2053[m]".("M_CE2053[m]")                                   
"S_CE2053[r]".("M_CE2053[r]")                                   
"S_CE2056[r]".("M_CE2056[r]")                                   
"S_CE3554[r]".("M_CE3554[r]")                                   
"S_CE2567[c]".("M_CE2567[c]")                                   
"S_cpppg3[c]".("M_cpppg3[c]")                                   
"S_uppg3[c]".("M_uppg3[c]")                                 
"S_CE2038[x]".("M_CE2038[x]")                                   
"S_CE5934[x]".("M_CE5934[x]")                                   
"S_C07297[x]".("M_C07297[x]")                                   
"S_tmtrdcoa[x]".("M_tmtrdcoa[x]")                                   
"S_CE4812[c]".("M_CE4812[c]")                                   
"S_eicostetcoa[r]".("M_eicostetcoa[r]")                                 
"S_CE4811[c]".("M_CE4811[c]")                                   
"S_strdnccoa[r]".("M_strdnccoa[r]")                                 
"S_CE4810[c]".("M_CE4810[c]")                                   
"S_lnlncacoa[r]".("M_lnlncacoa[r]")                                 
"S_CE4821[c]".("M_CE4821[c]")                                   
"S_clpndcoa[r]".("M_clpndcoa[r]")                                   
"S_CE4819[c]".("M_CE4819[c]")                                   
"S_tmndnccoa[r]".("M_tmndnccoa[r]")                                 
"S_CE4817[c]".("M_CE4817[c]")                                   
"S_CE2313[c]".("M_CE2313[c]")                                   
"S_CE2314[c]".("M_CE2314[c]")                                   
"S_zymstnl[c]".("M_zymstnl[c]")                                 
"S_tethex3coa[r]".("M_tethex3coa[r]")                                   
"S_adrncoa[r]".("M_adrncoa[r]")                                 
"S_CE4833[c]".("M_CE4833[c]")                                   
"S_CE4831[c]".("M_CE4831[c]")                                   
"S_CE4835[c]".("M_CE4835[c]")                                   
"S_CE4834[c]".("M_CE4834[c]")                                   
"S_CE4849[c]".("M_CE4849[c]")                                   
"S_CE4820[x]".("M_CE4820[x]")                                   
"S_CE4832[x]".("M_CE4832[x]")                                   
"S_CE4838[x]".("M_CE4838[x]")                                   
"S_tetpent6coa[r]".("M_tetpent6coa[r]")                                 
"S_CE4842[c]".("M_CE4842[c]")                                   
"S_CE4843[c]".("M_CE4843[c]")                                   
"S_CE4843[r]".("M_CE4843[r]")                                   
"S_CE4847[c]".("M_CE4847[c]")                                   
"S_CE4854[c]".("M_CE4854[c]")                                   
"S_CE4853[c]".("M_CE4853[c]")                                   
"S_CE4855[c]".("M_CE4855[c]")                                   
"S_CE4801[m]".("M_CE4801[m]")                                   
"S_CE4803[m]".("M_CE4803[m]")                                   
"S_CE4800[m]".("M_CE4800[m]")                                   
"S_CE4796[m]".("M_CE4796[m]")                                   
"S_CE4802[m]".("M_CE4802[m]")                                   
"S_CE4804[m]".("M_CE4804[m]")                                   
"S_CE5049[c]".("M_CE5049[c]")                                   
"S_CE4806[m]".("M_CE4806[m]")                                   
"S_CE4798[m]".("M_CE4798[m]")                                   
"S_CE4799[m]".("M_CE4799[m]")                                   
"S_CE4808[m]".("M_CE4808[m]")                                   
"S_CE4807[m]".("M_CE4807[m]")                                   
"S_CE4797[m]".("M_CE4797[m]")                                   
"S_CE5151[c]".("M_CE5151[c]")                                   
"S_CE5151[r]".("M_CE5151[r]")                                   
"S_CE5155[c]".("M_CE5155[c]")                                   
"S_CE5155[r]".("M_CE5155[r]")                                   
"S_nrvnccoa[r]".("M_nrvnccoa[r]")                                   
"S_cholcoads[m]".("M_cholcoads[m]")                                 
"S_C11821[c]".("M_C11821[c]")                                   
"S_dmpp[c]".("M_dmpp[c]")                                   
"S_CE6504[c]".("M_CE6504[c]")                                   
"S_CE6506[c]".("M_CE6506[c]")                                   
"S_C08261[c]".("M_C08261[c]")                                   
"S_CE5947[c]".("M_CE5947[c]")                                   
"S_CE6508[c]".("M_CE6508[c]")                                   
"S_CE7091[r]".("M_CE7091[r]")                                   
"S_CE7088[c]".("M_CE7088[c]")                                   
"S_CE0347[c]".("M_CE0347[c]")                                   
"S_CE0347[r]".("M_CE0347[r]")                                   
"S_CE6230[c]".("M_CE6230[c]")                                   
"S_CE6232[c]".("M_CE6232[c]")                                   
"S_CE6234[c]".("M_CE6234[c]")                                   
"S_CE5947[m]".("M_CE5947[m]")                                   
"S_CE5947[x]".("M_CE5947[x]")                                   
"S_dec24dicoa[m]".("M_dec24dicoa[m]")                                   
"S_dece3coa[m]".("M_dece3coa[m]")                                   
"S_3hbcoa_R[c]".("M_3hbcoa_R[c]")                                   
"S_btcoa[x]".("M_btcoa[x]")                                 
"S_doco13ecoa[c]".("M_doco13ecoa[c]")                                   
"S_dece3coa[x]".("M_dece3coa[x]")                                   
"S_dec47dicoa[m]".("M_dec47dicoa[m]")                                   
"S_dectricoa[m]".("M_dectricoa[m]")                                 
"S_dec47dicoa[x]".("M_dec47dicoa[x]")                                   
"S_dectricoa[x]".("M_dectricoa[x]")                                 
"S_2decdicoa[m]".("M_2decdicoa[m]")                                 
"S_octe5coa[m]".("M_octe5coa[m]")                                   
"S_2decdicoa[x]".("M_2decdicoa[x]")                                 
"S_octe5coa[x]".("M_octe5coa[x]")                                   
"S_3decdicoa[m]".("M_3decdicoa[m]")                                 
"S_3decdicoa[x]".("M_3decdicoa[x]")                                 
"S_tmuncoa[x]".("M_tmuncoa[x]")                                 
"S_dd3coa[x]".("M_dd3coa[x]")                                   
"S_2ddecdicoa[m]".("M_2ddecdicoa[m]")                                   
"S_3ddecdicoa[m]".("M_3ddecdicoa[m]")                                   
"S_2ddecdicoa[x]".("M_2ddecdicoa[x]")                                   
"S_3ddecdicoa[x]".("M_3ddecdicoa[x]")                                   
"S_2dodtricoa[m]".("M_2dodtricoa[m]")                                   
"S_2dodtricoa[x]".("M_2dodtricoa[x]")                                   
"S_3dodtricoa[m]".("M_3dodtricoa[m]")                                   
"S_3dodtricoa[x]".("M_3dodtricoa[x]")                                   
"S_tetdecdicoa[m]".("M_tetdecdicoa[m]")                                 
"S_tetdecdicoa[x]".("M_tetdecdicoa[x]")                                 
"S_5tedtricoa[m]".("M_5tedtricoa[m]")                                   
"S_5tedtricoa[x]".("M_5tedtricoa[x]")                                   
"S_2hexdtricoa[x]".("M_2hexdtricoa[x]")                                 
"S_hexdtrcoa[m]".("M_hexdtrcoa[m]")                                 
"S_4hexdtricoa[m]".("M_4hexdtricoa[m]")                                 
"S_hexdectecoa[m]".("M_hexdectecoa[m]")                                 
"S_4hexdtricoa[x]".("M_4hexdtricoa[x]")                                 
"S_hexdectecoa[x]".("M_hexdectecoa[x]")                                 
"S_2hexdtricoa[m]".("M_2hexdtricoa[m]")                                 
"S_3hexdtricoa[m]".("M_3hexdtricoa[m]")                                 
"S_3hexdtricoa[x]".("M_3hexdtricoa[x]")                                 
"S_2hexdtetcoa[x]".("M_2hexdtetcoa[x]")                                 
"S_4hexdtetcoa[x]".("M_4hexdtetcoa[x]")                                 
"S_hexdpencoa[x]".("M_hexdpencoa[x]")                                   
"S_3hexdtetcoa[x]".("M_3hexdtetcoa[x]")                                 
"S_2octdectecoa[m]".("M_2octdectecoa[m]")                                   
"S_2octdectecoa[x]".("M_2octdectecoa[x]")                                   
"S_3octdectecoa[m]".("M_3octdectecoa[m]")                                   
"S_3octdectecoa[x]".("M_3octdectecoa[x]")                                   
"S_eitetcoa[m]".("M_eitetcoa[m]")                                   
"S_eitetcoa[x]".("M_eitetcoa[x]")                                   
"S_eipencoa[x]".("M_eipencoa[x]")                                   
"S_5eipencoa[m]".("M_5eipencoa[m]")                                 
"S_2docopencoa[m]".("M_2docopencoa[m]")                                 
"S_2docopencoa[x]".("M_2docopencoa[x]")                                 
"S_docohexcoa[m]".("M_docohexcoa[m]")                                   
"S_docohexcoa[x]".("M_docohexcoa[x]")                                   
"S_3docopencoa[m]".("M_3docopencoa[m]")                                 
"S_3docopencoa[x]".("M_3docopencoa[x]")                                 
"S_2docohexecoa[m]".("M_2docohexecoa[m]")                                   
"S_docohepcoa[m]".("M_docohepcoa[m]")                                   
"S_docosahexcoa[m]".("M_docosahexcoa[m]")                                   
"S_hx2coa[x]".("M_hx2coa[x]")                                   
"S_hexe3coa[m]".("M_hexe3coa[m]")                                   
"S_hexe3coa[x]".("M_hexe3coa[x]")                                   
"S_omhdecacid[r]".("M_omhdecacid[r]")                                   
"S_omhdecacid[c]".("M_omhdecacid[c]")                                   
"S_1a25dhvitd3[c]".("M_1a25dhvitd3[c]")                                 
"S_1a25dhvitd3[n]".("M_1a25dhvitd3[n]")                                 
"S_5dpmev[c]".("M_5dpmev[c]")                                   
"S_6pgl[c]".("M_6pgl[c]")                                   
"S_glu5sa[c]".("M_glu5sa[c]")                                   
"S_5pmev[c]".("M_5pmev[c]")                                 
"S_1pyr5c[c]".("M_1pyr5c[c]")                                   
"S_ttdceacoa[c]".("M_ttdceacoa[c]")                                 
"S_txb2[c]".("M_txb2[c]")                                   
"S_ppp9[c]".("M_ppp9[c]")                                   
"S_grdp[c]".("M_grdp[c]")                                   
"S_methf[c]".("M_methf[c]")                                 
"S_hmbil[c]".("M_hmbil[c]")                                 
"S_phom[c]".("M_phom[c]")                                   
"S_HC01434[c]".("M_HC01434[c]")                                 
"S_HC01668[c]".("M_HC01668[c]")                                 
"S_gal1p[c]".("M_gal1p[c]")                                 
"S_glutacoa[m]".("M_glutacoa[m]")                                   
"S_ethmalcoa[c]".("M_ethmalcoa[c]")                                 
"S_6hddopaqn[c]".("M_6hddopaqn[c]")                                 
"S_5cysdopa[c]".("M_5cysdopa[c]")                                   
"S_23dh1i56dio[c]".("M_23dh1i56dio[c]")                                 
"S_dhcrm_hs[g]".("M_dhcrm_hs[g]")                                   
"S_thcrm_hs[l]".("M_thcrm_hs[l]")                                   
"S_gd1a_hs[c]".("M_gd1a_hs[c]")                                 
"S_gd1b_hs[c]".("M_gd1b_hs[c]")                                 
"S_gt1b_hs[c]".("M_gt1b_hs[c]")                                 
"S_ga1_hs[c]".("M_ga1_hs[c]")                                   
"S_ga2_hs[c]".("M_ga2_hs[c]")                                   
"S_gm2_hs[c]".("M_gm2_hs[c]")                                   
"S_gd1a_hs[n]".("M_gd1a_hs[n]")                                 
"S_gda1_hs[n]".("M_gda1_hs[n]")                                 
"S_M02694[c]".("M_M02694[c]")                                   
"S_M02694[m]".("M_M02694[m]")                                   
"S_M02107[c]".("M_M02107[c]")                                   
"S_M02107[m]".("M_M02107[m]")                                   
"S_M02616[c]".("M_M02616[c]")                                   
"S_M02616[m]".("M_M02616[m]")                                   
"S_M03116[c]".("M_M03116[c]")                                   
"S_M03116[m]".("M_M03116[m]")                                   
"S_M03050[c]".("M_M03050[c]")                                   
"S_M00129[c]".("M_M00129[c]")                                   
"S_HC10784[c]".("M_HC10784[c]")                                 
"S_M01141[c]".("M_M01141[c]")                                   
"S_M01191[c]".("M_M01191[c]")                                   
"S_M00004[c]".("M_M00004[c]")                                   
"S_M01237[c]".("M_M01237[c]")                                   
"S_M00020[c]".("M_M00020[c]")                                   
"S_vacccoa[c]".("M_vacccoa[c]")                                 
"S_M00127[c]".("M_M00127[c]")                                   
"S_M00116[c]".("M_M00116[c]")                                   
"S_M02612[c]".("M_M02612[c]")                                   
"S_M00018[c]".("M_M00018[c]")                                   
"S_M01236[c]".("M_M01236[c]")                                   
"S_M00123[c]".("M_M00123[c]")                                   
"S_M00101[c]".("M_M00101[c]")                                   
"S_M02052[c]".("M_M02052[c]")                                   
"S_M00006[c]".("M_M00006[c]")                                   
"S_M03047[c]".("M_M03047[c]")                                   
"S_M02112[c]".("M_M02112[c]")                                   
"S_M00012[c]".("M_M00012[c]")                                   
"S_M00343[c]".("M_M00343[c]")                                   
"S_M00023[c]".("M_M00023[c]")                                   
"S_HC02048[c]".("M_HC02048[c]")                                 
"S_HC02042[c]".("M_HC02042[c]")                                 
"S_HC02050[c]".("M_HC02050[c]")                                 
"S_HC02051[c]".("M_HC02051[c]")                                 
"S_HC02054[c]".("M_HC02054[c]")                                 
"S_HC02056[c]".("M_HC02056[c]")                                 
"S_HC02057[c]".("M_HC02057[c]")                                 
"S_HC02060[c]".("M_HC02060[c]")                                 
"S_M02686[c]".("M_M02686[c]")                                   
"S_M02758[c]".("M_M02758[c]")                                   
"S_HC02076[c]".("M_HC02076[c]")                                 
"S_HC02070[c]".("M_HC02070[c]")                                 
"S_M02197[c]".("M_M02197[c]")                                   
"S_gm1b_hs[c]".("M_gm1b_hs[c]")                                 
"S_gm3_hs[c]".("M_gm3_hs[c]")                                   
"S_acglcgalgluside_hs[c]".("M_acglcgalgluside_hs[c]")                                   
"S_galacglcgalgluside_hs[c]".("M_galacglcgalgluside_hs[c]")                                 
"S_M02195[c]".("M_M02195[c]")                                   
"S_galfucgalacglcgalgluside_hs[c]".("M_galfucgalacglcgalgluside_hs[c]")                                 
"S_acgalfucgalacglcgalgluside_hs[c]".("M_acgalfucgalacglcgalgluside_hs[c]")                                 
"S_M02683[c]".("M_M02683[c]")                                   
"S_acglcgal14acglcgalgluside_hs[c]".("M_acglcgal14acglcgalgluside_hs[c]")                                   
"S_galacglcgal14acglcgalgluside_hs[c]".("M_galacglcgal14acglcgalgluside_hs[c]")                                 
"S_acglcgalacglcgal14acglcgalgluside_hs[c]".("M_acglcgalacglcgal14acglcgalgluside_hs[c]")                                   
"S_M02186[c]".("M_M02186[c]")                                   
"S_M02490[c]".("M_M02490[c]")                                   
"S_5HPET[m]".("M_5HPET[m]")                                 
"S_Ssq23epx[c]".("M_Ssq23epx[c]")                                   
"S_44mzym[c]".("M_44mzym[c]")                                   
"S_M00961[c]".("M_M00961[c]")                                   
"S_M00957[c]".("M_M00957[c]")                                   
"S_4mzym_int1[c]".("M_4mzym_int1[c]")                                   
"S_4mzym_int2[c]".("M_4mzym_int2[c]")                                   
"S_HC02110[c]".("M_HC02110[c]")                                 
"S_M00963[c]".("M_M00963[c]")                                   
"S_M00959[c]".("M_M00959[c]")                                   
"S_M00955[c]".("M_M00955[c]")                                   
"S_M01067[c]".("M_M01067[c]")                                   
"S_zymst[c]".("M_zymst[c]")                                 
"S_chlstol[c]".("M_chlstol[c]")                                 
"S_M00940[c]".("M_M00940[c]")                                   
"S_M00938[c]".("M_M00938[c]")                                   
"S_M00942[c]".("M_M00942[c]")                                   
"S_M00962[c]".("M_M00962[c]")                                   
"S_M00958[c]".("M_M00958[c]")                                   
"S_M00954[c]".("M_M00954[c]")                                   
"S_M00966[c]".("M_M00966[c]")                                   
"S_M00967[c]".("M_M00967[c]")                                   
"S_M00964[c]".("M_M00964[c]")                                   
"S_M00960[c]".("M_M00960[c]")                                   
"S_M00956[c]".("M_M00956[c]")                                   
"S_M01068[c]".("M_M01068[c]")                                   
"S_cholcoar[c]".("M_cholcoar[c]")                                   
"S_cholcoas[m]".("M_cholcoas[m]")                                   
"S_cholcoaone[m]".("M_cholcoaone[m]")                                   
"S_HC01459[m]".("M_HC01459[m]")                                 
"S_20ahchsterol[r]".("M_20ahchsterol[r]")                                   
"S_M00605[c]".("M_M00605[c]")                                   
"S_M00406[c]".("M_M00406[c]")                                   
"S_M01075[c]".("M_M01075[c]")                                   
"S_M01075[r]".("M_M01075[r]")                                   
"S_M02760[c]".("M_M02760[c]")                                   
"S_M02761[c]".("M_M02761[c]")                                   
"S_M00603[c]".("M_M00603[c]")                                   
"S_M00285[c]".("M_M00285[c]")                                   
"S_CE5253[l]".("M_CE5253[l]")                                   
"S_M01729[c]".("M_M01729[c]")                                   
"S_M01729[m]".("M_M01729[m]")                                   
"S_M03050[m]".("M_M03050[m]")                                   
"S_M02973[c]".("M_M02973[c]")                                   
"S_M02973[m]".("M_M02973[m]")                                   
"S_M00129[m]".("M_M00129[m]")                                   
"S_M02976[c]".("M_M02976[c]")                                   
"S_M02976[m]".("M_M02976[m]")                                   
"S_M01141[m]".("M_M01141[m]")                                   
"S_M01191[m]".("M_M01191[m]")                                   
"S_M02102[c]".("M_M02102[c]")                                   
"S_M02102[m]".("M_M02102[m]")                                   
"S_M00004[m]".("M_M00004[m]")                                   
"S_M02103[c]".("M_M02103[c]")                                   
"S_M02103[m]".("M_M02103[m]")                                   
"S_M01237[m]".("M_M01237[m]")                                   
"S_M00020[m]".("M_M00020[m]")                                   
"S_vacccrn[c]".("M_vacccrn[c]")                                 
"S_vacccrn[m]".("M_vacccrn[m]")                                 
"S_vacccoa[m]".("M_vacccoa[m]")                                 
"S_M00127[m]".("M_M00127[m]")                                   
"S_M02638[c]".("M_M02638[c]")                                   
"S_M02638[m]".("M_M02638[m]")                                   
"S_M00116[m]".("M_M00116[m]")                                   
"S_M02611[c]".("M_M02611[c]")                                   
"S_M02611[m]".("M_M02611[m]")                                   
"S_M02612[m]".("M_M02612[m]")                                   
"S_M01776[c]".("M_M01776[c]")                                   
"S_M01776[m]".("M_M01776[m]")                                   
"S_M00018[m]".("M_M00018[m]")                                   
"S_M01777[c]".("M_M01777[c]")                                   
"S_M01777[m]".("M_M01777[m]")                                   
"S_CE5151[m]".("M_CE5151[m]")                                   
"S_M01775[c]".("M_M01775[c]")                                   
"S_M01775[m]".("M_M01775[m]")                                   
"S_M01236[m]".("M_M01236[m]")                                   
"S_M00122[c]".("M_M00122[c]")                                   
"S_M00122[m]".("M_M00122[m]")                                   
"S_M00123[m]".("M_M00123[m]")                                   
"S_M00100[c]".("M_M00100[c]")                                   
"S_M00100[m]".("M_M00100[m]")                                   
"S_M00101[m]".("M_M00101[m]")                                   
"S_M02051[c]".("M_M02051[c]")                                   
"S_M02051[m]".("M_M02051[m]")                                   
"S_M02052[m]".("M_M02052[m]")                                   
"S_M01724[c]".("M_M01724[c]")                                   
"S_M01724[m]".("M_M01724[m]")                                   
"S_M01727[c]".("M_M01727[c]")                                   
"S_M01727[m]".("M_M01727[m]")                                   
"S_CE5155[m]".("M_CE5155[m]")                                   
"S_M01726[c]".("M_M01726[c]")                                   
"S_M01726[m]".("M_M01726[m]")                                   
"S_M00006[m]".("M_M00006[m]")                                   
"S_M02637[c]".("M_M02637[c]")                                   
"S_M02637[m]".("M_M02637[m]")                                   
"S_M00011[c]".("M_M00011[c]")                                   
"S_M00011[m]".("M_M00011[m]")                                   
"S_M00012[m]".("M_M00012[m]")                                   
"S_M00342[c]".("M_M00342[c]")                                   
"S_M00342[m]".("M_M00342[m]")                                   
"S_M00343[m]".("M_M00343[m]")                                   
"S_M00261[c]".("M_M00261[c]")                                   
"S_M00261[m]".("M_M00261[m]")                                   
"S_CE4854[m]".("M_CE4854[m]")                                   
"S_M01770[c]".("M_M01770[c]")                                   
"S_M01770[m]".("M_M01770[m]")                                   
"S_CE4843[m]".("M_CE4843[m]")                                   
"S_M00022[c]".("M_M00022[c]")                                   
"S_M00022[m]".("M_M00022[m]")                                   
"S_M00023[m]".("M_M00023[m]")                                   
"S_M00263[c]".("M_M00263[c]")                                   
"S_M00263[m]".("M_M00263[m]")                                   
"S_CE4847[m]".("M_CE4847[m]")                                   
"S_ddcacoa[r]".("M_ddcacoa[r]")                                 
"S_M03050[r]".("M_M03050[r]")                                   
"S_tdcoa[r]".("M_tdcoa[r]")                                 
"S_M00129[r]".("M_M00129[r]")                                   
"S_HC10784[r]".("M_HC10784[r]")                                 
"S_M01141[r]".("M_M01141[r]")                                   
"S_ptdcacoa[r]".("M_ptdcacoa[r]")                                   
"S_M01191[r]".("M_M01191[r]")                                   
"S_hpdcacoa[r]".("M_hpdcacoa[r]")                                   
"S_M00004[r]".("M_M00004[r]")                                   
"S_M01237[r]".("M_M01237[r]")                                   
"S_M00020[r]".("M_M00020[r]")                                   
"S_vacccoa[r]".("M_vacccoa[r]")                                 
"S_M00127[r]".("M_M00127[r]")                                   
"S_lneldccoa[r]".("M_lneldccoa[r]")                                 
"S_M02612[r]".("M_M02612[r]")                                   
"S_arachcoa[r]".("M_arachcoa[r]")                                   
"S_M01236[r]".("M_M01236[r]")                                   
"S_M00018[r]".("M_M00018[r]")                                   
"S_M00123[r]".("M_M00123[r]")                                   
"S_M00101[r]".("M_M00101[r]")                                   
"S_M02052[r]".("M_M02052[r]")                                   
"S_M01724[r]".("M_M01724[r]")                                   
"S_docoscoa[r]".("M_docoscoa[r]")                                   
"S_M00006[r]".("M_M00006[r]")                                   
"S_M02637[r]".("M_M02637[r]")                                   
"S_strdnccrn[r]".("M_strdnccrn[r]")                                 
"S_tmndnccrn[r]".("M_tmndnccrn[r]")                                 
"S_c226coa[r]".("M_c226coa[r]")                                 
"S_M00012[r]".("M_M00012[r]")                                   
"S_M00343[r]".("M_M00343[r]")                                   
"S_lnlncgcrn[r]".("M_lnlncgcrn[r]")                                 
"S_dlnlcgcrn[r]".("M_dlnlcgcrn[r]")                                 
"S_dcsptn1coa[r]".("M_dcsptn1coa[r]")                                   
"S_M00023[r]".("M_M00023[r]")                                   
"S_M03047[r]".("M_M03047[r]")                                   
"S_ttccoa[r]".("M_ttccoa[r]")                                   
"S_hexccoa[r]".("M_hexccoa[r]")                                 
"S_M02112[r]".("M_M02112[r]")                                   
"S_tetpent3coa[r]".("M_tetpent3coa[r]")                                 
"S_tettet6coa[r]".("M_tettet6coa[r]")                                   
"S_M03047[x]".("M_M03047[x]")                                   
"S_CE4855[x]".("M_CE4855[x]")                                   
"S_M02112[x]".("M_M02112[x]")                                   
"S_M00049[x]".("M_M00049[x]")                                   
"S_M00783[x]".("M_M00783[x]")                                   
"S_CE2245[x]".("M_CE2245[x]")                                   
"S_CE2249[x]".("M_CE2249[x]")                                   
"S_CE2253[x]".("M_CE2253[x]")                                   
"S_CE2242[x]".("M_CE2242[x]")                                   
"S_CE2246[x]".("M_CE2246[x]")                                   
"S_CE2250[x]".("M_CE2250[x]")                                   
"S_CE2243[x]".("M_CE2243[x]")                                   
"S_CE2247[x]".("M_CE2247[x]")                                   
"S_CE2251[x]".("M_CE2251[x]")                                   
"S_od2coa[x]".("M_od2coa[x]")                                   
"S_CE2248[x]".("M_CE2248[x]")                                   
"S_HC01415[x]".("M_HC01415[x]")                                 
"S_HC01405[x]".("M_HC01405[x]")                                 
"S_HC01406[x]".("M_HC01406[x]")                                 
"S_HC01407[x]".("M_HC01407[x]")                                 
"S_HC01408[x]".("M_HC01408[x]")                                 
"S_CE2242[m]".("M_CE2242[m]")                                   
"S_CE2246[m]".("M_CE2246[m]")                                   
"S_CE2250[m]".("M_CE2250[m]")                                   
"S_CE2243[m]".("M_CE2243[m]")                                   
"S_CE2247[m]".("M_CE2247[m]")                                   
"S_CE2251[m]".("M_CE2251[m]")                                   
"S_CE2248[m]".("M_CE2248[m]")                                   
"S_3ohodcoa[m]".("M_3ohodcoa[m]")                                   
"S_M00044[m]".("M_M00044[m]")                                   
"S_M00778[m]".("M_M00778[m]")                                   
"S_M00873[m]".("M_M00873[m]")                                   
"S_M00054[m]".("M_M00054[m]")                                   
"S_M00790[m]".("M_M00790[m]")                                   
"S_M00887[m]".("M_M00887[m]")                                   
"S_M00046[m]".("M_M00046[m]")                                   
"S_M00780[m]".("M_M00780[m]")                                   
"S_M00875[m]".("M_M00875[m]")                                   
"S_M00061[m]".("M_M00061[m]")                                   
"S_M00795[m]".("M_M00795[m]")                                   
"S_M00897[m]".("M_M00897[m]")                                   
"S_M00069[m]".("M_M00069[m]")                                   
"S_M00804[m]".("M_M00804[m]")                                   
"S_M00909[m]".("M_M00909[m]")                                   
"S_M00071[m]".("M_M00071[m]")                                   
"S_M00806[m]".("M_M00806[m]")                                   
"S_M00911[m]".("M_M00911[m]")                                   
"S_M00056[m]".("M_M00056[m]")                                   
"S_M00792[m]".("M_M00792[m]")                                   
"S_M00889[m]".("M_M00889[m]")                                   
"S_M00048[m]".("M_M00048[m]")                                   
"S_M00782[m]".("M_M00782[m]")                                   
"S_M00877[m]".("M_M00877[m]")                                   
"S_M00063[m]".("M_M00063[m]")                                   
"S_M00797[m]".("M_M00797[m]")                                   
"S_M00899[m]".("M_M00899[m]")                                   
"S_CE5154[m]".("M_CE5154[m]")                                   
"S_CE5153[m]".("M_CE5153[m]")                                   
"S_CE5152[m]".("M_CE5152[m]")                                   
"S_CE5150[m]".("M_CE5150[m]")                                   
"S_CE5148[m]".("M_CE5148[m]")                                   
"S_CE5144[m]".("M_CE5144[m]")                                   
"S_M03019[m]".("M_M03019[m]")                                   
"S_M00172[m]".("M_M00172[m]")                                   
"S_M00849[m]".("M_M00849[m]")                                   
"S_M03022[m]".("M_M03022[m]")                                   
"S_M01573[m]".("M_M01573[m]")                                   
"S_M00885[m]".("M_M00885[m]")                                   
"S_M03014[m]".("M_M03014[m]")                                   
"S_M00702[m]".("M_M00702[m]")                                   
"S_M00843[m]".("M_M00843[m]")                                   
"S_M03024[m]".("M_M03024[m]")                                   
"S_M00170[m]".("M_M00170[m]")                                   
"S_M00841[m]".("M_M00841[m]")                                   
"S_M03016[x]".("M_M03016[x]")                                   
"S_M00715[x]".("M_M00715[x]")                                   
"S_M00879[x]".("M_M00879[x]")                                   
"S_CE5158[x]".("M_CE5158[x]")                                   
"S_CE5157[x]".("M_CE5157[x]")                                   
"S_CE5156[x]".("M_CE5156[x]")                                   
"S_CE5155[x]".("M_CE5155[x]")                                   
"S_CE5154[x]".("M_CE5154[x]")                                   
"S_CE5153[x]".("M_CE5153[x]")                                   
"S_CE5152[x]".("M_CE5152[x]")                                   
"S_CE5151[x]".("M_CE5151[x]")                                   
"S_CE5150[x]".("M_CE5150[x]")                                   
"S_CE5148[x]".("M_CE5148[x]")                                   
"S_CE5144[x]".("M_CE5144[x]")                                   
"S_HC10856[x]".("M_HC10856[x]")                                 
"S_HC10857[x]".("M_HC10857[x]")                                 
"S_HC10858[x]".("M_HC10858[x]")                                 
"S_M01191[x]".("M_M01191[x]")                                   
"S_M03019[x]".("M_M03019[x]")                                   
"S_M00172[x]".("M_M00172[x]")                                   
"S_M00849[x]".("M_M00849[x]")                                   
"S_M01141[x]".("M_M01141[x]")                                   
"S_M03022[x]".("M_M03022[x]")                                   
"S_M01573[x]".("M_M01573[x]")                                   
"S_M00885[x]".("M_M00885[x]")                                   
"S_CE5116[m]".("M_CE5116[m]")                                   
"S_CE5114[m]".("M_CE5114[m]")                                   
"S_CE4791[m]".("M_CE4791[m]")                                   
"S_CE4793[m]".("M_CE4793[m]")                                   
"S_CE2437[m]".("M_CE2437[m]")                                   
"S_CE2438[m]".("M_CE2438[m]")                                   
"S_CE2439[m]".("M_CE2439[m]")                                   
"S_CE2440[m]".("M_CE2440[m]")                                   
"S_CE2441[m]".("M_CE2441[m]")                                   
"S_M01454[r]".("M_M01454[r]")                                   
"S_M01455[r]".("M_M01455[r]")                                   
"S_M01456[r]".("M_M01456[r]")                                   
"S_M01457[r]".("M_M01457[r]")                                   
"S_M01458[r]".("M_M01458[r]")                                   
"S_M01460[r]".("M_M01460[r]")                                   
"S_M01461[r]".("M_M01461[r]")                                   
"S_M01462[r]".("M_M01462[r]")                                   
"S_M01463[r]".("M_M01463[r]")                                   
"S_M01464[r]".("M_M01464[r]")                                   
"S_M01465[r]".("M_M01465[r]")                                   
"S_M01466[r]".("M_M01466[r]")                                   
"S_M01467[r]".("M_M01467[r]")                                   
"S_M01468[r]".("M_M01468[r]")                                   
"S_M01469[r]".("M_M01469[r]")                                   
"S_M01470[r]".("M_M01470[r]")                                   
"S_M01471[r]".("M_M01471[r]")                                   
"S_M01472[r]".("M_M01472[r]")                                   
"S_M01473[r]".("M_M01473[r]")                                   
"S_M01474[r]".("M_M01474[r]")                                   
"S_M01475[r]".("M_M01475[r]")                                   
"S_M01476[r]".("M_M01476[r]")                                   
"S_M01477[r]".("M_M01477[r]")                                   
"S_M01479[r]".("M_M01479[r]")                                   
"S_M01480[r]".("M_M01480[r]")                                   
"S_M01481[r]".("M_M01481[r]")                                   
"S_M01482[r]".("M_M01482[r]")                                   
"S_M01483[r]".("M_M01483[r]")                                   
"S_M01484[r]".("M_M01484[r]")                                   
"S_M01485[r]".("M_M01485[r]")                                   
"S_M01486[r]".("M_M01486[r]")                                   
"S_M01487[r]".("M_M01487[r]")                                   
"S_M01489[r]".("M_M01489[r]")                                   
"S_M01491[r]".("M_M01491[r]")                                   
"S_M01492[r]".("M_M01492[r]")                                   
"S_M01494[r]".("M_M01494[r]")                                   
"S_M01495[r]".("M_M01495[r]")                                   
"S_M01496[r]".("M_M01496[r]")                                   
"S_M01497[r]".("M_M01497[r]")                                   
"S_M01498[r]".("M_M01498[r]")                                   
"S_M01501[r]".("M_M01501[r]")                                   
"S_M01502[r]".("M_M01502[r]")                                   
"S_M01506[r]".("M_M01506[r]")                                   
"S_M01508[r]".("M_M01508[r]")                                   
"S_M01509[r]".("M_M01509[r]")                                   
"S_M01510[r]".("M_M01510[r]")                                   
"S_coucoa[c]".("M_coucoa[c]")                                   
"S_4hbzcoa[c]".("M_4hbzcoa[c]")                                 
"S_M00658[m]".("M_M00658[m]")                                   
"S_M01165[m]".("M_M01165[m]")                                   
"S_M00770[m]".("M_M00770[m]")                                   
"S_M00213[c]".("M_M00213[c]")                                   
"S_Ndmelys[c]".("M_Ndmelys[c]")                                 
"S_Ntmelys[c]".("M_Ntmelys[c]")                                 
"S_M01869[g]".("M_M01869[g]")                                   
"S_HC02057[r]".("M_HC02057[r]")                                 
"S_M03167[c]".("M_M03167[c]")                                   
"S_3hlvst[c]".("M_3hlvst[c]")                                   
"S_3hpvscoa[m]".("M_3hpvscoa[m]")                                   
"S_3hpvstetcoa[m]".("M_3hpvstetcoa[m]")                                 
"S_3hpvscoa[x]".("M_3hpvscoa[x]")                                   
"S_3hpvstetcoa[x]".("M_3hpvstetcoa[x]")                                 
"S_3hsmv[c]".("M_3hsmv[c]")                                 
"S_6hsmv[r]".("M_6hsmv[r]")                                 
"S_3hsmv[r]".("M_3hsmv[r]")                                 
"S_3meacmp[c]".("M_3meacmp[c]")                                 
"S_6csmv[c]".("M_6csmv[c]")                                 
"S_6msmv[r]".("M_6msmv[r]")                                 
"S_6csmv[r]".("M_6csmv[r]")                                 
"S_6hlvstacid[c]".("M_6hlvstacid[c]")                                   
"S_6hmsmv[c]".("M_6hmsmv[c]")                                   
"S_6hmsmv[r]".("M_6hmsmv[r]")                                   
"S_6hsmv[c]".("M_6hsmv[c]")                                 
"S_atvethgluc[r]".("M_atvethgluc[r]")                                   
"S_crvsm1[r]".("M_crvsm1[r]")                                   
"S_crvsm23[r]".("M_crvsm23[r]")                                 
"S_3meacmp[r]".("M_3meacmp[r]")                                 
"S_lvstacid[c]".("M_lvstacid[c]")                                   
"S_lvstacid[r]".("M_lvstacid[r]")                                   
"S_6hlvstacid[r]".("M_6hlvstacid[r]")                                   
"S_3hlvst[r]".("M_3hlvst[r]")                                   
"S_rsv[r]".("M_rsv[r]")                                 
"S_fvscoa[x]".("M_fvscoa[x]")                                   
"S_profvscoa[x]".("M_profvscoa[x]")                                 
"S_profvscoa[c]".("M_profvscoa[c]")                                 
"S_ptvstgluc[r]".("M_ptvstgluc[r]")                                 
"S_rsv[c]".("M_rsv[c]")                                 
"S_rsvgluc[r]".("M_rsvgluc[r]")                                 
"S_rsvlac[r]".("M_rsvlac[r]")                                   
"S_rsvlac[c]".("M_rsvlac[c]")                                   
"S_3hpvscoa[c]".("M_3hpvscoa[c]")                                   
"S_3hpvstetcoa[c]".("M_3hpvstetcoa[c]")                                 
"S_fvscoa[c]".("M_fvscoa[c]")                                   
"S_ubiquitin[c]".("M_ubiquitin[c]")                                 
"S_abeta[c]".("M_abeta[c]")                                 
"S_abeta_N_Ub_lysine[c]".("M_abeta_N_Ub_lysine[c]")                                 
"S_abeta_N6_methyl_L_lysine[c]".("M_abeta_N6_methyl_L_lysine[c]")                                   
"S_abeta_N6_N6_dimethyl_L_lysine[c]".("M_abeta_N6_N6_dimethyl_L_lysine[c]")                                 
"S_abeta_N6_N6_N6_trimethyl_L_lysine[c]".("M_abeta_N6_N6_N6_trimethyl_L_lysine[c]")                                 
"S_tau[c]".("M_tau[c]")                                 
"S_tau_N_Ub_lysine[c]".("M_tau_N_Ub_lysine[c]")                                 
"S_tau_N6_methyl_L_lysine[c]".("M_tau_N6_methyl_L_lysine[c]")                                   
"S_tau_N6_N6_dimethyl_L_lysine[c]".("M_tau_N6_N6_dimethyl_L_lysine[c]")                                 
"S_tau_N6_N6_N6_trimethyl_L_lysine[c]".("M_tau_N6_N6_N6_trimethyl_L_lysine[c]")                                 
"S_TNFA[c]".("M_TNFA[c]")                                   
"S_TNFA_N_Ub_lysine[c]".("M_TNFA_N_Ub_lysine[c]")                                   
"S_TNFA_N6_methyl_L_lysine[c]".("M_TNFA_N6_methyl_L_lysine[c]")                                 
"S_TNFA_N6_N6_dimethyl_L_lysine[c]".("M_TNFA_N6_N6_dimethyl_L_lysine[c]")                                   
"S_TNFA_N6_N6_N6_trimethyl_L_lysine[c]".("M_TNFA_N6_N6_N6_trimethyl_L_lysine[c]")                                   
"S_IL6[c]".("M_IL6[c]")                                 
"S_IL6_N_Ub_lysine[c]".("M_IL6_N_Ub_lysine[c]")                                 
"S_IL6_N6_methyl_L_lysine[c]".("M_IL6_N6_methyl_L_lysine[c]")                                   
"S_IL6_N6_N6_dimethyl_L_lysine[c]".("M_IL6_N6_N6_dimethyl_L_lysine[c]")                                 
"S_IL6_N6_N6_N6_trimethyl_L_lysine[c]".("M_IL6_N6_N6_N6_trimethyl_L_lysine[c]")                                 
"S_34dhpha[c]".("M_34dhpha[c]")                                 
"S_3m4hpga[c]".("M_3m4hpga[c]")                                 
"S_4hoxpacd[c]".("M_4hoxpacd[c]")                                   
"S_4hphac[c]".("M_4hphac[c]")                                   
"S_3otdcoa[x]".("M_3otdcoa[x]")                                 
"S_kdnp[c]".("M_kdnp[c]")                                   
"S_ivcoa[m]".("M_ivcoa[m]")                                 
"S_3mb2coa[m]".("M_3mb2coa[m]")                                 
"S_hdd2coa[x]".("M_hdd2coa[x]")                                 
"S_melatn[c]".("M_melatn[c]")                                   
"S_msa[m]".("M_msa[m]")                                 
"S_arachcrn[c]".("M_arachcrn[c]")                                   
"S_arachcrn[m]".("M_arachcrn[m]")                                   
"S_ga2_hs[g]".("M_ga2_hs[g]")                                   
"S_ga1_hs[g]".("M_ga1_hs[g]")                                   
"S_c226coa[x]".("M_c226coa[x]")                                 
"S_clpndcoa[x]".("M_clpndcoa[x]")                                   
"S_digalside_hs[c]".("M_digalside_hs[c]")                                   
"S_digalside_hs[l]".("M_digalside_hs[l]")                                   
"S_kdn[c]".("M_kdn[c]")                                 
"S_dmpp[x]".("M_dmpp[x]")                                   
"S_ipdp[x]".("M_ipdp[x]")                                   
"S_grdp[x]".("M_grdp[x]")                                   
"S_fuc1p_L[c]".("M_fuc1p_L[c]")                                 
"S_tettet6coa[x]".("M_tettet6coa[x]")                                   
"S_tetpent3coa[x]".("M_tetpent3coa[x]")                                 
"S_tethex3coa[x]".("M_tethex3coa[x]")                                   
"S_frdp[x]".("M_frdp[x]")                                   
"S_3mldz[c]".("M_3mldz[c]")                                 
"S_6hoxmelatn[c]".("M_6hoxmelatn[c]")                                   
"S_mi13p[c]".("M_mi13p[c]")                                 
"S_methf[m]".("M_methf[m]")                                 
"S_dimp[c]".("M_dimp[c]")                                   
"S_peamn[c]".("M_peamn[c]")                                 
"S_pacald[c]".("M_pacald[c]")                                   
"S_acngalgbside_hs[g]".("M_acngalgbside_hs[g]")                                 
"S_gm1b_hs[g]".("M_gm1b_hs[g]")                                 
"S_gd1a_hs[g]".("M_gd1a_hs[g]")                                 
"S_trdrd[c]".("M_trdrd[c]")                                 
"S_trdox[c]".("M_trdox[c]")                                 
"S_tym[c]".("M_tym[c]")                                 
"S_pacald[m]".("M_pacald[m]")                                   
"S_3hddcoa[m]".("M_3hddcoa[m]")                                 
"S_3htdcoa[m]".("M_3htdcoa[m]")                                 
"S_3htdcoa[x]".("M_3htdcoa[x]")                                 
"S_HC01412[x]".("M_HC01412[x]")                                 
"S_3hdcoa[m]".("M_3hdcoa[m]")                                   
"S_34dhmald[m]".("M_34dhmald[m]")                                   
"S_3mox4hpac[m]".("M_3mox4hpac[m]")                                 
"S_3m4hpga[m]".("M_3m4hpga[m]")                                 
"S_CE2250[c]".("M_CE2250[c]")                                   
"S_CE2246[c]".("M_CE2246[c]")                                   
"S_CE2242[c]".("M_CE2242[c]")                                   
"S_3ohodcoa[c]".("M_3ohodcoa[c]")                                   
"S_CE2248[c]".("M_CE2248[c]")                                   
"S_CE2870[c]".("M_CE2870[c]")                                   
"S_CE2873[c]".("M_CE2873[c]")                                   
"S_CE2872[c]".("M_CE2872[c]")                                   
"S_CE2875[c]".("M_CE2875[c]")                                   
"S_CE2874[c]".("M_CE2874[c]")                                   
"S_CE4990[m]".("M_CE4990[m]")                                   
"S_CE4990[x]".("M_CE4990[x]")                                   
"S_CE4793[c]".("M_CE4793[c]")                                   
"S_CE5114[c]".("M_CE5114[c]")                                   
"S_CE4841[c]".("M_CE4841[c]")                                   
"S_CE4840[c]".("M_CE4840[c]")                                   
"S_CE4845[c]".("M_CE4845[c]")                                   
"S_CE4844[c]".("M_CE4844[c]")                                   
"S_CE4846[c]".("M_CE4846[c]")                                   
"S_CE4852[c]".("M_CE4852[c]")                                   
"S_CE4850[c]".("M_CE4850[c]")                                   
"S_CE4848[c]".("M_CE4848[c]")                                   
"S_CE4851[c]".("M_CE4851[c]")                                   
"S_CE5144[c]".("M_CE5144[c]")                                   
"S_CE5152[c]".("M_CE5152[c]")                                   
"S_CE5156[c]".("M_CE5156[c]")                                   
"S_CE5148[c]".("M_CE5148[c]")                                   
"S_CE5150[c]".("M_CE5150[c]")                                   
"S_CE5153[c]".("M_CE5153[c]")                                   
"S_CE5154[c]".("M_CE5154[c]")                                   
"S_CE5157[c]".("M_CE5157[c]")                                   
"S_CE5158[c]".("M_CE5158[c]")                                   
"S_CE5160[c]".("M_CE5160[c]")                                   
"S_CE5161[c]".("M_CE5161[c]")                                   
"S_CE5162[c]".("M_CE5162[c]")                                   
"S_CE5944[m]".("M_CE5944[m]")                                   
"S_CE5944[x]".("M_CE5944[x]")                                   
"S_CE4988[c]".("M_CE4988[c]")                                   
"S_CE4988[m]".("M_CE4988[m]")                                   
"S_CE4988[x]".("M_CE4988[x]")                                   
"S_CE7097[m]".("M_CE7097[m]")                                   
"S_CE2084[c]".("M_CE2084[c]")                                   
"S_CE2084[m]".("M_CE2084[m]")                                   
"S_adpcoa[c]".("M_adpcoa[c]")                                   
"S_adpcoa[x]".("M_adpcoa[x]")                                   
"S_c6dc[x]".("M_c6dc[x]")                                   
"S_c101coa[c]".("M_c101coa[c]")                                 
"S_decdicoa[c]".("M_decdicoa[c]")                                   
"S_c10dc[x]".("M_c10dc[x]")                                 
"S_c10dc[c]".("M_c10dc[c]")                                 
"S_sebcoa[c]".("M_sebcoa[c]")                                   
"S_3hdcoa[c]".("M_3hdcoa[c]")                                   
"S_dd2coa[c]".("M_dd2coa[c]")                                   
"S_c12dccoa[c]".("M_c12dccoa[c]")                                   
"S_3hddcoa[c]".("M_3hddcoa[c]")                                 
"S_tetdece1coa[c]".("M_tetdece1coa[c]")                                 
"S_tetdec2coa[c]".("M_tetdec2coa[c]")                                   
"S_3htdcoa[c]".("M_3htdcoa[c]")                                 
"S_hexdicoa[c]".("M_hexdicoa[c]")                                   
"S_3octdece1coa[c]".("M_3octdece1coa[c]")                                   
"S_c6dc[c]".("M_c6dc[c]")                                   
"S_c81coa[c]".("M_c81coa[c]")                                   
"S_sbcoa[c]".("M_sbcoa[c]")                                 
"S_c8dc[c]".("M_c8dc[c]")                                   
"S_sebcoa[x]".("M_sebcoa[x]")                                   
"S_sbcoa[x]".("M_sbcoa[x]")                                 
"S_hexdicoa[r]".("M_hexdicoa[r]")                                   
"S_3octdece1coa[m]".("M_3octdece1coa[m]")                                   
"S_octdececoa[m]".("M_octdececoa[m]")                                   
"S_succoa[c]".("M_succoa[c]")                                   
"S_3ivcoa[m]".("M_3ivcoa[m]")                                   
"S_octdececrn[c]".("M_octdececrn[c]")                                   
"S_octdececrn[m]".("M_octdececrn[m]")                                   
"S_octdececoa[c]".("M_octdececoa[c]")                                   
"S_c8dc[x]".("M_c8dc[x]")                                   
"S_phaccoa[m]".("M_phaccoa[m]")                                 
"S_3hadicoa[x]".("M_3hadicoa[x]")                                   
"S_3ohsebcoa[x]".("M_3ohsebcoa[x]")                                 
"S_3ohsubcoa[x]".("M_3ohsubcoa[x]")                                 
"S_galgbside_hs[c]".("M_galgbside_hs[c]")                                   
"S_M02491[c]".("M_M02491[c]")                                   
"S_CE6246[c]".("M_CE6246[c]")                                   
"S_3ohxccoa[c]".("M_3ohxccoa[c]")                                   
"S_M00783[c]".("M_M00783[c]")                                   
"S_M00049[c]".("M_M00049[c]")                                   
"S_M00887[c]".("M_M00887[c]")                                   
"S_M00790[c]".("M_M00790[c]")                                   
"S_M00054[c]".("M_M00054[c]")                                   
"S_M00873[c]".("M_M00873[c]")                                   
"S_M00778[c]".("M_M00778[c]")                                   
"S_M00044[c]".("M_M00044[c]")                                   
"S_M00907[c]".("M_M00907[c]")                                   
"S_M00802[c]".("M_M00802[c]")                                   
"S_M00067[c]".("M_M00067[c]")                                   
"S_M00879[c]".("M_M00879[c]")                                   
"S_M00715[c]".("M_M00715[c]")                                   
"S_M03016[c]".("M_M03016[c]")                                   
"S_M00843[c]".("M_M00843[c]")                                   
"S_M00702[c]".("M_M00702[c]")                                   
"S_M03014[c]".("M_M03014[c]")                                   
"S_M00852[c]".("M_M00852[c]")                                   
"S_M00707[c]".("M_M00707[c]")                                   
"S_M03018[c]".("M_M03018[c]")                                   
"S_M00839[c]".("M_M00839[c]")                                   
"S_M00699[c]".("M_M00699[c]")                                   
"S_M03011[c]".("M_M03011[c]")                                   
"S_M00871[c]".("M_M00871[c]")                                   
"S_M00704[c]".("M_M00704[c]")                                   
"S_M03017[c]".("M_M03017[c]")                                   
"S_CE4791[c]".("M_CE4791[c]")                                   
"S_M00860[c]".("M_M00860[c]")                                   
"S_M00085[c]".("M_M00085[c]")                                   
"S_M03008[c]".("M_M03008[c]")                                   
"S_M00869[c]".("M_M00869[c]")                                   
"S_M00086[c]".("M_M00086[c]")                                   
"S_M03005[c]".("M_M03005[c]")                                   
"S_M00862[c]".("M_M00862[c]")                                   
"S_M00712[c]".("M_M00712[c]")                                   
"S_M03006[c]".("M_M03006[c]")                                   
"S_atvacylgluc[r]".("M_atvacylgluc[r]")                                 
"S_atvlacgluc[r]".("M_atvlacgluc[r]")                                   
"S_1mncam[e]".("M_1mncam[e]")                                   
"S_24nph[e]".("M_24nph[e]")                                 
"S_h[e]".("M_h[e]")                                 
"S_2hb[e]".("M_2hb[e]")                                 
"S_hco3[e]".("M_hco3[e]")                                   
"S_na1[e]".("M_na1[e]")                                 
"S_2mcit[e]".("M_2mcit[e]")                                 
"S_34dhoxpeg[e]".("M_34dhoxpeg[e]")                                 
"S_4mptnl[e]".("M_4mptnl[e]")                                   
"S_4nphsf[e]".("M_4nphsf[e]")                                   
"S_4nph[e]".("M_4nph[e]")                                   
"S_5adtststerone[e]".("M_5adtststerone[e]")                                 
"S_h2o[e]".("M_h2o[e]")                                 
"S_5fthf[e]".("M_5fthf[e]")                                 
"S_5htrp[e]".("M_5htrp[e]")                                 
"S_5mthf[e]".("M_5mthf[e]")                                 
"S_6htststerone[e]".("M_6htststerone[e]")                                   
"S_4abut[e]".("M_4abut[e]")                                 
"S_acetone[e]".("M_acetone[e]")                                 
"S_ac[e]".("M_ac[e]")                                   
"S_ach[e]".("M_ach[e]")                                 
"S_chol[e]".("M_chol[e]")                                   
"S_acngalacglcgal14acglcgalgluside_hs[e]".("M_acngalacglcgal14acglcgalgluside_hs[e]")                                   
"S_nh4[e]".("M_nh4[e]")                                 
"S_adn[e]".("M_adn[e]")                                 
"S_ins[e]".("M_ins[e]")                                 
"S_ade[e]".("M_ade[e]")                                 
"S_adprib[e]".("M_adprib[e]")                                   
"S_adrnl[e]".("M_adrnl[e]")                                 
"S_adrn[e]".("M_adrn[e]")                                   
"S_aflatoxin[e]".("M_aflatoxin[e]")                                 
"S_akg[e]".("M_akg[e]")                                 
"S_ala_L[e]".("M_ala_L[e]")                                 
"S_asn_L[e]".("M_asn_L[e]")                                 
"S_cys_L[e]".("M_cys_L[e]")                                 
"S_ala_D[e]".("M_ala_D[e]")                                 
"S_gln_L[e]".("M_gln_L[e]")                                 
"S_gly[e]".("M_gly[e]")                                 
"S_ser_L[e]".("M_ser_L[e]")                                 
"S_thr_L[e]".("M_thr_L[e]")                                 
"S_aldstrn[e]".("M_aldstrn[e]")                                 
"S_cgly[e]".("M_cgly[e]")                                   
"S_glc_D[e]".("M_glc_D[e]")                                 
"S_glygn2[e]".("M_glygn2[e]")                                   
"S_andrstrn[e]".("M_andrstrn[e]")                                   
"S_antipyrene[e]".("M_antipyrene[e]")                                   
"S_aqcobal[e]".("M_aqcobal[e]")                                 
"S_arab_L[e]".("M_arab_L[e]")                                   
"S_arachd[e]".("M_arachd[e]")                                   
"S_arach[e]".("M_arach[e]")                                 
"S_lys_L[e]".("M_lys_L[e]")                                 
"S_arg_L[e]".("M_arg_L[e]")                                 
"S_ascb_L[e]".("M_ascb_L[e]")                                   
"S_asp_D[e]".("M_asp_D[e]")                                 
"S_k[e]".("M_k[e]")                                 
"S_asp_L[e]".("M_asp_L[e]")                                 
"S_atp[e]".("M_atp[e]")                                 
"S_pi[e]".("M_pi[e]")                                   
"S_amp[e]".("M_amp[e]")                                 
"S_adp[e]".("M_adp[e]")                                 
"S_ala_B[e]".("M_ala_B[e]")                                 
"S_bhb[e]".("M_bhb[e]")                                 
"S_bildglcur[e]".("M_bildglcur[e]")                                 
"S_bilglcur[e]".("M_bilglcur[e]")                                   
"S_bilirub[e]".("M_bilirub[e]")                                 
"S_btn[e]".("M_btn[e]")                                 
"S_bz[e]".("M_bz[e]")                                   
"S_ca2[e]".("M_ca2[e]")                                 
"S_caro[e]".("M_caro[e]")                                   
"S_cholate[e]".("M_cholate[e]")                                 
"S_acgam[e]".("M_acgam[e]")                                 
"S_chtn[e]".("M_chtn[e]")                                   
"S_cit[e]".("M_cit[e]")                                 
"S_cl[e]".("M_cl[e]")                                   
"S_for[e]".("M_for[e]")                                 
"S_i[e]".("M_i[e]")                                 
"S_oxa[e]".("M_oxa[e]")                                 
"S_clpnd[e]".("M_clpnd[e]")                                 
"S_co[e]".("M_co[e]")                                   
"S_coumarin[e]".("M_coumarin[e]")                                   
"S_creat[e]".("M_creat[e]")                                 
"S_crn[e]".("M_crn[e]")                                 
"S_crtsl[e]".("M_crtsl[e]")                                 
"S_crtstrn[e]".("M_crtstrn[e]")                                 
"S_crvnc[e]".("M_crvnc[e]")                                 
"S_csn[e]".("M_csn[e]")                                 
"S_cspg_a[e]".("M_cspg_a[e]")                                   
"S_cspg_c[e]".("M_cspg_c[e]")                                   
"S_cspg_d[e]".("M_cspg_d[e]")                                   
"S_cspg_e[e]".("M_cspg_e[e]")                                   
"S_glu_L[e]".("M_glu_L[e]")                                 
"S_Lcystin[e]".("M_Lcystin[e]")                                 
"S_cytd[e]".("M_cytd[e]")                                   
"S_dad_2[e]".("M_dad_2[e]")                                 
"S_din[e]".("M_din[e]")                                 
"S_dag_hs[e]".("M_dag_hs[e]")                                   
"S_dcsptn1[e]".("M_dcsptn1[e]")                                 
"S_dcyt[e]".("M_dcyt[e]")                                   
"S_dgchol[e]".("M_dgchol[e]")                                   
"S_dgsn[e]".("M_dgsn[e]")                                   
"S_dhdascb[e]".("M_dhdascb[e]")                                 
"S_dheas[e]".("M_dheas[e]")                                 
"S_dlnlcg[e]".("M_dlnlcg[e]")                                   
"S_dmantipyrine[e]".("M_dmantipyrine[e]")                                   
"S_dmhptcrn[e]".("M_dmhptcrn[e]")                                   
"S_dopasf[e]".("M_dopasf[e]")                                   
"S_dopa[e]".("M_dopa[e]")                                   
"S_drib[e]".("M_drib[e]")                                   
"S_duri[e]".("M_duri[e]")                                   
"S_eaflatoxin[e]".("M_eaflatoxin[e]")                                   
"S_ebastineoh[e]".("M_ebastineoh[e]")                                   
"S_ebastine[e]".("M_ebastine[e]")                                   
"S_eicostet[e]".("M_eicostet[e]")                                   
"S_elaid[e]".("M_elaid[e]")                                 
"S_estradiol[e]".("M_estradiol[e]")                                 
"S_estrones[e]".("M_estrones[e]")                                   
"S_10fthf[e]".("M_10fthf[e]")                                   
"S_10fthf5glu[e]".("M_10fthf5glu[e]")                                   
"S_10fthf6glu[e]".("M_10fthf6glu[e]")                                   
"S_10fthf7glu[e]".("M_10fthf7glu[e]")                                   
"S_13_cis_retnglc[e]".("M_13_cis_retnglc[e]")                                   
"S_35cgmp[e]".("M_35cgmp[e]")                                   
"S_3aib[e]".("M_3aib[e]")                                   
"S_5dhf[e]".("M_5dhf[e]")                                   
"S_5thf[e]".("M_5thf[e]")                                   
"S_6dhf[e]".("M_6dhf[e]")                                   
"S_6thf[e]".("M_6thf[e]")                                   
"S_7dhf[e]".("M_7dhf[e]")                                   
"S_7thf[e]".("M_7thf[e]")                                   
"S_ak2lgchol_hs[e]".("M_ak2lgchol_hs[e]")                                   
"S_camp[e]".("M_camp[e]")                                   
"S_chsterol[e]".("M_chsterol[e]")                                   
"S_cmp[e]".("M_cmp[e]")                                 
"S_dhf[e]".("M_dhf[e]")                                 
"S_fuc13galacglcgal14acglcgalgluside_hs[e]".("M_fuc13galacglcgal14acglcgalgluside_hs[e]")                                   
"S_fuc14galacglcgalgluside_hs[e]".("M_fuc14galacglcgalgluside_hs[e]")                                   
"S_fucacgalfucgalacglcgalgluside_hs[e]".("M_fucacgalfucgalacglcgalgluside_hs[e]")                                   
"S_fucfuc12gal14acglcgalgluside_hs[e]".("M_fucfuc12gal14acglcgalgluside_hs[e]")                                 
"S_fucfucfucgalacglc13galacglcgal14acglcgalgluside_hs[e]".("M_fucfucfucgalacglc13galacglcgal14acglcgalgluside_hs[e]")                                   
"S_fucfucgalacglcgalgluside_hs[e]".("M_fucfucgalacglcgalgluside_hs[e]")                                 
"S_fucgal14acglcgalgluside_hs[e]".("M_fucgal14acglcgalgluside_hs[e]")                                   
"S_fucgalfucgalacglcgalgluside_hs[e]".("M_fucgalfucgalacglcgalgluside_hs[e]")                                   
"S_galacglcgalgbside_hs[e]".("M_galacglcgalgbside_hs[e]")                                   
"S_galgalfucfucgalacglcgalacglcgal14acglcgalgluside_hs[e]".("M_galgalfucfucgalacglcgalacglcgal14acglcgalgluside_hs[e]")                                 
"S_galgalgalthcrm_hs[e]".("M_galgalgalthcrm_hs[e]")                                 
"S_gbside_hs[e]".("M_gbside_hs[e]")                                 
"S_gchola[e]".("M_gchola[e]")                                   
"S_gdp[e]".("M_gdp[e]")                                 
"S_glyc_S[e]".("M_glyc_S[e]")                                   
"S_gmp[e]".("M_gmp[e]")                                 
"S_gq1b_hs[e]".("M_gq1b_hs[e]")                                 
"S_gsn[e]".("M_gsn[e]")                                 
"S_gthox[e]".("M_gthox[e]")                                 
"S_gthrd[e]".("M_gthrd[e]")                                 
"S_gtp[e]".("M_gtp[e]")                                 
"S_h2o2[e]".("M_h2o2[e]")                                   
"S_ha[e]".("M_ha[e]")                                   
"S_ha_pre1[e]".("M_ha_pre1[e]")                                 
"S_hcoumarin[e]".("M_hcoumarin[e]")                                 
"S_hdca[e]".("M_hdca[e]")                                   
"S_hdcea[e]".("M_hdcea[e]")                                 
"S_hexc[e]".("M_hexc[e]")                                   
"S_hista[e]".("M_hista[e]")                                 
"S_hom_L[e]".("M_hom_L[e]")                                 
"S_hpdca[e]".("M_hpdca[e]")                                 
"S_hspg[e]".("M_hspg[e]")                                   
"S_htaxol[e]".("M_htaxol[e]")                                   
"S_idp[e]".("M_idp[e]")                                 
"S_imp[e]".("M_imp[e]")                                 
"S_inost[e]".("M_inost[e]")                                 
"S_ksii_core2[e]".("M_ksii_core2[e]")                                   
"S_ksii_core4[e]".("M_ksii_core4[e]")                                   
"S_leuktrA4[e]".("M_leuktrA4[e]")                                   
"S_leuktrB4[e]".("M_leuktrB4[e]")                                   
"S_leuktrC4[e]".("M_leuktrC4[e]")                                   
"S_leuktrD4[e]".("M_leuktrD4[e]")                                   
"S_leuktrE4[e]".("M_leuktrE4[e]")                                   
"S_leuktrF4[e]".("M_leuktrF4[e]")                                   
"S_lgnc[e]".("M_lgnc[e]")                                   
"S_lneldc[e]".("M_lneldc[e]")                                   
"S_lnlc[e]".("M_lnlc[e]")                                   
"S_lnlnca[e]".("M_lnlnca[e]")                                   
"S_lnlncg[e]".("M_lnlncg[e]")                                   
"S_lpchol_hs[e]".("M_lpchol_hs[e]")                                 
"S_mag_hs[e]".("M_mag_hs[e]")                                   
"S_meoh[e]".("M_meoh[e]")                                   
"S_mthgxl[e]".("M_mthgxl[e]")                                   
"S_n2m2nmasn[e]".("M_n2m2nmasn[e]")                                 
"S_nad[e]".("M_nad[e]")                                 
"S_nadp[e]".("M_nadp[e]")                                   
"S_ncam[e]".("M_ncam[e]")                                   
"S_no[e]".("M_no[e]")                                   
"S_nrpphr[e]".("M_nrpphr[e]")                                   
"S_nrvnc[e]".("M_nrvnc[e]")                                 
"S_o2s[e]".("M_o2s[e]")                                 
"S_oagd3_hs[e]".("M_oagd3_hs[e]")                                   
"S_ocdca[e]".("M_ocdca[e]")                                 
"S_ocdcea[e]".("M_ocdcea[e]")                                   
"S_octa[e]".("M_octa[e]")                                   
"S_paf_hs[e]".("M_paf_hs[e]")                                   
"S_pchol_hs[e]".("M_pchol_hs[e]")                                   
"S_pe_hs[e]".("M_pe_hs[e]")                                 
"S_peplys[e]".("M_peplys[e]")                                   
"S_pglyc_hs[e]".("M_pglyc_hs[e]")                                   
"S_phyt[e]".("M_phyt[e]")                                   
"S_prgstrn[e]".("M_prgstrn[e]")                                 
"S_pro_D[e]".("M_pro_D[e]")                                 
"S_prostgd2[e]".("M_prostgd2[e]")                                   
"S_prostge1[e]".("M_prostge1[e]")                                   
"S_prostge2[e]".("M_prostge2[e]")                                   
"S_prostgf2[e]".("M_prostgf2[e]")                                   
"S_ps_hs[e]".("M_ps_hs[e]")                                 
"S_ptdca[e]".("M_ptdca[e]")                                 
"S_retfa[e]".("M_retfa[e]")                                 
"S_retinol[e]".("M_retinol[e]")                                 
"S_Rtotal[e]".("M_Rtotal[e]")                                   
"S_Rtotal2[e]".("M_Rtotal2[e]")                                 
"S_spc_hs[e]".("M_spc_hs[e]")                                   
"S_sphs1p[e]".("M_sphs1p[e]")                                   
"S_srtn[e]".("M_srtn[e]")                                   
"S_strdnc[e]".("M_strdnc[e]")                                   
"S_tagat_D[e]".("M_tagat_D[e]")                                 
"S_taxol[e]".("M_taxol[e]")                                 
"S_tchola[e]".("M_tchola[e]")                                   
"S_tdchola[e]".("M_tdchola[e]")                                 
"S_tethex3[e]".("M_tethex3[e]")                                 
"S_tetpent3[e]".("M_tetpent3[e]")                                   
"S_tetpent6[e]".("M_tetpent6[e]")                                   
"S_thf[e]".("M_thf[e]")                                 
"S_thmtp[e]".("M_thmtp[e]")                                 
"S_thym[e]".("M_thym[e]")                                   
"S_thyox_L[e]".("M_thyox_L[e]")                                 
"S_triodthy[e]".("M_triodthy[e]")                                   
"S_tststerone[e]".("M_tststerone[e]")                                   
"S_ttdca[e]".("M_ttdca[e]")                                 
"S_txa2[e]".("M_txa2[e]")                                   
"S_Tyr_ggn[e]".("M_Tyr_ggn[e]")                                 
"S_udp[e]".("M_udp[e]")                                 
"S_ump[e]".("M_ump[e]")                                 
"S_urate[e]".("M_urate[e]")                                 
"S_utp[e]".("M_utp[e]")                                 
"S_vacc[e]".("M_vacc[e]")                                   
"S_vitd3[e]".("M_vitd3[e]")                                 
"S_whhdca[e]".("M_whhdca[e]")                                   
"S_whtststerone[e]".("M_whtststerone[e]")                                   
"S_xolest_hs[e]".("M_xolest_hs[e]")                                 
"S_xolest2_hs[e]".("M_xolest2_hs[e]")                                   
"S_xoltri25[e]".("M_xoltri25[e]")                                   
"S_xoltri27[e]".("M_xoltri27[e]")                                   
"S_xylt[e]".("M_xylt[e]")                                   
"S_fe2[e]".("M_fe2[e]")                                 
"S_fe3[e]".("M_fe3[e]")                                 
"S_fol[e]".("M_fol[e]")                                 
"S_fru[e]".("M_fru[e]")                                 
"S_gal[e]".("M_gal[e]")                                 
"S_gam[e]".("M_gam[e]")                                 
"S_malt[e]".("M_malt[e]")                                   
"S_his_L[e]".("M_his_L[e]")                                 
"S_ile_L[e]".("M_ile_L[e]")                                 
"S_leu_L[e]".("M_leu_L[e]")                                 
"S_glyc[e]".("M_glyc[e]")                                   
"S_man[e]".("M_man[e]")                                 
"S_mepi[e]".("M_mepi[e]")                                   
"S_met_L[e]".("M_met_L[e]")                                 
"S_malttr[e]".("M_malttr[e]")                                   
"S_nac[e]".("M_nac[e]")                                 
"S_uri[e]".("M_uri[e]")                                 
"S_orn[e]".("M_orn[e]")                                 
"S_phe_L[e]".("M_phe_L[e]")                                 
"S_pnto_R[e]".("M_pnto_R[e]")                                   
"S_ppa[e]".("M_ppa[e]")                                 
"S_prostgh2[e]".("M_prostgh2[e]")                                   
"S_prostgi2[e]".("M_prostgi2[e]")                                   
"S_pro_L[e]".("M_pro_L[e]")                                 
"S_ribflv[e]".("M_ribflv[e]")                                   
"S_rib_D[e]".("M_rib_D[e]")                                 
"S_so4[e]".("M_so4[e]")                                 
"S_o2[e]".("M_o2[e]")                                   
"S_succ[e]".("M_succ[e]")                                   
"S_taur[e]".("M_taur[e]")                                   
"S_thymd[e]".("M_thymd[e]")                                 
"S_trp_L[e]".("M_trp_L[e]")                                 
"S_tyr_L[e]".("M_tyr_L[e]")                                 
"S_ura[e]".("M_ura[e]")                                 
"S_urea[e]".("M_urea[e]")                                   
"S_val_L[e]".("M_val_L[e]")                                 
"S_4abutn[e]".("M_4abutn[e]")                                   
"S_acmana[e]".("M_acmana[e]")                                   
"S_ctp[e]".("M_ctp[e]")                                 
"S_dhap[e]".("M_dhap[e]")                                   
"S_dtmp[e]".("M_dtmp[e]")                                   
"S_dttp[e]".("M_dttp[e]")                                   
"S_fald[e]".("M_fald[e]")                                   
"S_itp[e]".("M_itp[e]")                                 
"S_orot[e]".("M_orot[e]")                                   
"S_cdp[e]".("M_cdp[e]")                                 
"S_ptrc[e]".("M_ptrc[e]")                                   
"S_dtdp[e]".("M_dtdp[e]")                                   
"S_co2[e]".("M_co2[e]")                                 
"S_citr_L[e]".("M_citr_L[e]")                                   
"S_spmd[e]".("M_spmd[e]")                                   
"S_C02528[e]".("M_C02528[e]")                                   
"S_C02470[e]".("M_C02470[e]")                                   
"S_HC02192[e]".("M_HC02192[e]")                                 
"S_HC02193[e]".("M_HC02193[e]")                                 
"S_HC02195[e]".("M_HC02195[e]")                                 
"S_HC02196[e]".("M_HC02196[e]")                                 
"S_HC02220[e]".("M_HC02220[e]")                                 
"S_dca[e]".("M_dca[e]")                                 
"S_lac_L[e]".("M_lac_L[e]")                                 
"S_but[e]".("M_but[e]")                                 
"S_HC02191[e]".("M_HC02191[e]")                                 
"S_HC02194[e]".("M_HC02194[e]")                                 
"S_HC02197[e]".("M_HC02197[e]")                                 
"S_HC02198[e]".("M_HC02198[e]")                                 
"S_HC02187[e]".("M_HC02187[e]")                                 
"S_HC02180[e]".("M_HC02180[e]")                                 
"S_wharachd[e]".("M_wharachd[e]")                                   
"S_HC02202[e]".("M_HC02202[e]")                                 
"S_HC02203[e]".("M_HC02203[e]")                                 
"S_HC02204[e]".("M_HC02204[e]")                                 
"S_HC02205[e]".("M_HC02205[e]")                                 
"S_HC02206[e]".("M_HC02206[e]")                                 
"S_HC02207[e]".("M_HC02207[e]")                                 
"S_HC02208[e]".("M_HC02208[e]")                                 
"S_HC02210[e]".("M_HC02210[e]")                                 
"S_HC02213[e]".("M_HC02213[e]")                                 
"S_HC02214[e]".("M_HC02214[e]")                                 
"S_HC02216[e]".("M_HC02216[e]")                                 
"S_HC02217[e]".("M_HC02217[e]")                                 
"S_so3[e]".("M_so3[e]")                                 
"S_sprm[e]".("M_sprm[e]")                                   
"S_maltttr[e]".("M_maltttr[e]")                                 
"S_CE2839[e]".("M_CE2839[e]")                                   
"S_CE2838[e]".("M_CE2838[e]")                                   
"S_glcur[e]".("M_glcur[e]")                                 
"S_crm_hs[e]".("M_crm_hs[e]")                                   
"S_CE0074[e]".("M_CE0074[e]")                                   
"S_cdpea[e]".("M_cdpea[e]")                                 
"S_12HPET[e]".("M_12HPET[e]")                                   
"S_3bcrn[e]".("M_3bcrn[e]")                                 
"S_c10crn[e]".("M_c10crn[e]")                                   
"S_c4crn[e]".("M_c4crn[e]")                                 
"S_c8crn[e]".("M_c8crn[e]")                                 
"S_doco13ac[e]".("M_doco13ac[e]")                                   
"S_docosac[e]".("M_docosac[e]")                                 
"S_ttdcrn[e]".("M_ttdcrn[e]")                                   
"S_4hpro_LT[e]".("M_4hpro_LT[e]")                                   
"S_tdechola[e]".("M_tdechola[e]")                                   
"S_carn[e]".("M_carn[e]")                                   
"S_dchac[e]".("M_dchac[e]")                                 
"S_sbt_D[e]".("M_sbt_D[e]")                                 
"S_thm[e]".("M_thm[e]")                                 
"S_oh1[e]".("M_oh1[e]")                                 
"S_q10[e]".("M_q10[e]")                                 
"S_fmn[e]".("M_fmn[e]")                                 
"S_ptth[e]".("M_ptth[e]")                                   
"S_q10h2[e]".("M_q10h2[e]")                                 
"S_pheme[e]".("M_pheme[e]")                                 
"S_34hpp[e]".("M_34hpp[e]")                                 
"S_3mob[e]".("M_3mob[e]")                                   
"S_3mop[e]".("M_3mop[e]")                                   
"S_5mta[e]".("M_5mta[e]")                                   
"S_ahcys[e]".("M_ahcys[e]")                                 
"S_aicar[e]".("M_aicar[e]")                                 
"S_mal_L[e]".("M_mal_L[e]")                                 
"S_idour[e]".("M_idour[e]")                                 
"S_5hoxindoa[e]".("M_5hoxindoa[e]")                                 
"S_glyald[e]".("M_glyald[e]")                                   
"S_pep[e]".("M_pep[e]")                                 
"S_gudac[e]".("M_gudac[e]")                                 
"S_Lkynr[e]".("M_Lkynr[e]")                                 
"S_kynate[e]".("M_kynate[e]")                                   
"S_3hanthrn[e]".("M_3hanthrn[e]")                                   
"S_2pg[e]".("M_2pg[e]")                                 
"S_cholp[e]".("M_cholp[e]")                                 
"S_dcmp[e]".("M_dcmp[e]")                                   
"S_ethamp[e]".("M_ethamp[e]")                                   
"S_fum[e]".("M_fum[e]")                                 
"S_g3pc[e]".("M_g3pc[e]")                                   
"S_icit[e]".("M_icit[e]")                                   
"S_L2aadp[e]".("M_L2aadp[e]")                                   
"S_xan[e]".("M_xan[e]")                                 
"S_xmp[e]".("M_xmp[e]")                                 
"S_xtsn[e]".("M_xtsn[e]")                                   
"S_3pg[e]".("M_3pg[e]")                                 
"S_udpglcur[e]".("M_udpglcur[e]")                                   
"S_glyc3p[e]".("M_glyc3p[e]")                                   
"S_nicrnt[e]".("M_nicrnt[e]")                                   
"S_orot5p[e]".("M_orot5p[e]")                                   
"S_hcys_L[e]".("M_hcys_L[e]")                                   
"S_retinal[e]".("M_retinal[e]")                                 
"S_acrn[e]".("M_acrn[e]")                                   
"S_pcrn[e]".("M_pcrn[e]")                                   
"S_lneldccrn[e]".("M_lneldccrn[e]")                                 
"S_odecrn[e]".("M_odecrn[e]")                                   
"S_stcrn[e]".("M_stcrn[e]")                                 
"S_pmtcrn[e]".("M_pmtcrn[e]")                                   
"S_hdcecrn[e]".("M_hdcecrn[e]")                                 
"S_pcholmyr_hs[e]".("M_pcholmyr_hs[e]")                                 
"S_pcholole_hs[e]".("M_pcholole_hs[e]")                                 
"S_peole_hs[e]".("M_peole_hs[e]")                                   
"S_pcholpalme_hs[e]".("M_pcholpalme_hs[e]")                                 
"S_pcholpalm_hs[e]".("M_pcholpalm_hs[e]")                                   
"S_pepalm_hs[e]".("M_pepalm_hs[e]")                                 
"S_pail_hs[e]".("M_pail_hs[e]")                                 
"S_pailpalm_hs[e]".("M_pailpalm_hs[e]")                                 
"S_pcholste_hs[e]".("M_pcholste_hs[e]")                                 
"S_peste_hs[e]".("M_peste_hs[e]")                                   
"S_pchol2linl_hs[e]".("M_pchol2linl_hs[e]")                                 
"S_pe2linl_hs[e]".("M_pe2linl_hs[e]")                                   
"S_pchol2ole_hs[e]".("M_pchol2ole_hs[e]")                                   
"S_pchol2palm_hs[e]".("M_pchol2palm_hs[e]")                                 
"S_pchol2ste_hs[e]".("M_pchol2ste_hs[e]")                                   
"S_pcholn15_hs[e]".("M_pcholn15_hs[e]")                                 
"S_pcholar_hs[e]".("M_pcholar_hs[e]")                                   
"S_pcholn183_hs[e]".("M_pcholn183_hs[e]")                                   
"S_pcholn1836_hs[e]".("M_pcholn1836_hs[e]")                                 
"S_pcholn19_hs[e]".("M_pcholn19_hs[e]")                                 
"S_pcholn201_hs[e]".("M_pcholn201_hs[e]")                                   
"S_pcholn204_hs[e]".("M_pcholn204_hs[e]")                                   
"S_pcholn205_hs[e]".("M_pcholn205_hs[e]")                                   
"S_pcholn224_hs[e]".("M_pcholn224_hs[e]")                                   
"S_pcholn225_hs[e]".("M_pcholn225_hs[e]")                                   
"S_pcholn2254_hs[e]".("M_pcholn2254_hs[e]")                                 
"S_pcholn226_hs[e]".("M_pcholn226_hs[e]")                                   
"S_pear_hs[e]".("M_pear_hs[e]")                                 
"S_pe203_hs[e]".("M_pe203_hs[e]")                                   
"S_pe226_hs[e]".("M_pe226_hs[e]")                                   
"S_pe224_hs[e]".("M_pe224_hs[e]")                                   
"S_pedh203_hs[e]".("M_pedh203_hs[e]")                                   
"S_pe12_hs[e]".("M_pe12_hs[e]")                                 
"S_pe14_hs[e]".("M_pe14_hs[e]")                                 
"S_pe161_hs[e]".("M_pe161_hs[e]")                                   
"S_pe13_hs[e]".("M_pe13_hs[e]")                                 
"S_pe15_hs[e]".("M_pe15_hs[e]")                                 
"S_pe17_hs[e]".("M_pe17_hs[e]")                                 
"S_pcholn203_hs[e]".("M_pcholn203_hs[e]")                                   
"S_pailar_hs[e]".("M_pailar_hs[e]")                                 
"S_pcholn24_hs[e]".("M_pcholn24_hs[e]")                                 
"S_pcholn261_hs[e]".("M_pcholn261_hs[e]")                                   
"S_pcholn281_hs[e]".("M_pcholn281_hs[e]")                                   
"S_pcholn28_hs[e]".("M_pcholn28_hs[e]")                                 
"S_pcholdoc_hs[e]".("M_pcholdoc_hs[e]")                                 
"S_pcholeic_hs[e]".("M_pcholeic_hs[e]")                                 
"S_pcholet_hs[e]".("M_pcholet_hs[e]")                                   
"S_pcholhep_hs[e]".("M_pcholhep_hs[e]")                                 
"S_pchollinl_hs[e]".("M_pchollinl_hs[e]")                                   
"S_pelinl_hs[e]".("M_pelinl_hs[e]")                                 
"S_elaidcrn[e]".("M_elaidcrn[e]")                                   
"S_lnlccrn[e]".("M_lnlccrn[e]")                                 
"S_15HPET[e]".("M_15HPET[e]")                                   
"S_21hprgnlone[e]".("M_21hprgnlone[e]")                                 
"S_2oxoadp[e]".("M_2oxoadp[e]")                                 
"S_34hpl[e]".("M_34hpl[e]")                                 
"S_3hmp[e]".("M_3hmp[e]")                                   
"S_3mhis[e]".("M_3mhis[e]")                                 
"S_4tmeabutn[e]".("M_4tmeabutn[e]")                                 
"S_56dthm[e]".("M_56dthm[e]")                                   
"S_56dura[e]".("M_56dura[e]")                                   
"S_5aop[e]".("M_5aop[e]")                                   
"S_7dhchsterol[e]".("M_7dhchsterol[e]")                                 
"S_acglu[e]".("M_acglu[e]")                                 
"S_acgly[e]".("M_acgly[e]")                                 
"S_aclys[e]".("M_aclys[e]")                                 
"S_alltn[e]".("M_alltn[e]")                                 
"S_amet[e]".("M_amet[e]")                                   
"S_biliverd[e]".("M_biliverd[e]")                                   
"S_C04717[e]".("M_C04717[e]")                                   
"S_C04805[e]".("M_C04805[e]")                                   
"S_C05957[e]".("M_C05957[e]")                                   
"S_C06314[e]".("M_C06314[e]")                                   
"S_C06315[e]".("M_C06315[e]")                                   
"S_C14768[e]".("M_C14768[e]")                                   
"S_C14769[e]".("M_C14769[e]")                                   
"S_C14770[e]".("M_C14770[e]")                                   
"S_C14771[e]".("M_C14771[e]")                                   
"S_C14825[e]".("M_C14825[e]")                                   
"S_C14826[e]".("M_C14826[e]")                                   
"S_CE1273[e]".("M_CE1273[e]")                                   
"S_CE2510[e]".("M_CE2510[e]")                                   
"S_CE2537[e]".("M_CE2537[e]")                                   
"S_eidi1114ac[e]".("M_eidi1114ac[e]")                                   
"S_CE7172[e]".("M_CE7172[e]")                                   
"S_cortsn[e]".("M_cortsn[e]")                                   
"S_forglu[e]".("M_forglu[e]")                                   
"S_HC00900[e]".("M_HC00900[e]")                                 
"S_hexdiac[e]".("M_hexdiac[e]")                                 
"S_hgentis[e]".("M_hgentis[e]")                                 
"S_hmcr[e]".("M_hmcr[e]")                                   
"S_hxcoa[e]".("M_hxcoa[e]")                                 
"S_leuktrB4wcooh[e]".("M_leuktrB4wcooh[e]")                                 
"S_leuktrB4woh[e]".("M_leuktrB4woh[e]")                                 
"S_lthstrl[e]".("M_lthstrl[e]")                                 
"S_mev_R[e]".("M_mev_R[e]")                                 
"S_mi1p_D[e]".("M_mi1p_D[e]")                                   
"S_nwharg[e]".("M_nwharg[e]")                                   
"S_pcollg5hlys[e]".("M_pcollg5hlys[e]")                                 
"S_saccrp_L[e]".("M_saccrp_L[e]")                                   
"S_sebacid[e]".("M_sebacid[e]")                                 
"S_tmlys[e]".("M_tmlys[e]")                                 
"S_urcan[e]".("M_urcan[e]")                                 
"S_galt[e]".("M_galt[e]")                                   
"S_glyc_R[e]".("M_glyc_R[e]")                                   
"S_glyc2p[e]".("M_glyc2p[e]")                                   
"S_glyclt[e]".("M_glyclt[e]")                                   
"S_ind3ac[e]".("M_ind3ac[e]")                                   
"S_Lcyst[e]".("M_Lcyst[e]")                                 
"S_oaa[e]".("M_oaa[e]")                                 
"S_pser_L[e]".("M_pser_L[e]")                                   
"S_ttdcea[e]".("M_ttdcea[e]")                                   
"S_estriol[e]".("M_estriol[e]")                                 
"S_ddca[e]".("M_ddca[e]")                                   
"S_normete_L[e]".("M_normete_L[e]")                                 
"S_C05300[e]".("M_C05300[e]")                                   
"S_dhbpt[e]".("M_dhbpt[e]")                                 
"S_thbpt[e]".("M_thbpt[e]")                                 
"S_sphmyln_hs[e]".("M_sphmyln_hs[e]")                                   
"S_hxa[e]".("M_hxa[e]")                                 
"S_Lhcystin[e]".("M_Lhcystin[e]")                                   
"S_acnam[e]".("M_acnam[e]")                                 
"S_etha[e]".("M_etha[e]")                                   
"S_acgal[e]".("M_acgal[e]")                                 
"S_core4[e]".("M_core4[e]")                                 
"S_f1a[e]".("M_f1a[e]")                                 
"S_dxtrn[e]".("M_dxtrn[e]")                                 
"S_dhcholestanate[e]".("M_dhcholestanate[e]")                                   
"S_thcholstoic[e]".("M_thcholstoic[e]")                                 
"S_xol7ah3[e]".("M_xol7ah3[e]")                                 
"S_xol7aone[e]".("M_xol7aone[e]")                                   
"S_xoldiolone[e]".("M_xoldiolone[e]")                                   
"S_7klitchol[e]".("M_7klitchol[e]")                                 
"S_2obut[e]".("M_2obut[e]")                                 
"S_gua[e]".("M_gua[e]")                                 
"S_glcr[e]".("M_glcr[e]")                                   
"S_hxan[e]".("M_hxan[e]")                                   
"S_xyl_D[e]".("M_xyl_D[e]")                                 
"S_pydxn[e]".("M_pydxn[e]")                                 
"S_pydx[e]".("M_pydx[e]")                                   
"S_pydam[e]".("M_pydam[e]")                                 
"S_4hbz[e]".("M_4hbz[e]")                                   
"S_etoh[e]".("M_etoh[e]")                                   
"S_acald[e]".("M_acald[e]")                                 
"S_lanost[e]".("M_lanost[e]")                                   
"S_3mox4hoxm[e]".("M_3mox4hoxm[e]")                                 
"S_glx[e]".("M_glx[e]")                                 
"S_2h3mv[e]".("M_2h3mv[e]")                                 
"S_2hiv[e]".("M_2hiv[e]")                                   
"S_2m3hbu[e]".("M_2m3hbu[e]")                                   
"S_3h3mglt[e]".("M_3h3mglt[e]")                                 
"S_3mglutac[e]".("M_3mglutac[e]")                                   
"S_glutcon[e]".("M_glutcon[e]")                                 
"S_5ohhexa[e]".("M_5ohhexa[e]")                                 
"S_ethmalac[e]".("M_ethmalac[e]")                                   
"S_eic21114tr[e]".("M_eic21114tr[e]")                                   
"S_5eipenc[e]".("M_5eipenc[e]")                                 
"S_T4hcinnm[e]".("M_T4hcinnm[e]")                                   
"S_andrstandn[e]".("M_andrstandn[e]")                                   
"S_11docrtsl[e]".("M_11docrtsl[e]")                                 
"S_11docrtstrn[e]".("M_11docrtstrn[e]")                                 
"S_mma[e]".("M_mma[e]")                                 
"S_mhista[e]".("M_mhista[e]")                                   
"S_CE2006[e]".("M_CE2006[e]")                                   
"S_mlthf[e]".("M_mlthf[e]")                                 
"S_trypta[e]".("M_trypta[e]")                                   
"S_selmeth[e]".("M_selmeth[e]")                                 
"S_CE7090[e]".("M_CE7090[e]")                                   
"S_CE7085[e]".("M_CE7085[e]")                                   
"S_CE7096[e]".("M_CE7096[e]")                                   
"S_CE4877[e]".("M_CE4877[e]")                                   
"S_CE1447[e]".("M_CE1447[e]")                                   
"S_C05770[e]".("M_C05770[e]")                                   
"S_CE2705[e]".("M_CE2705[e]")                                   
"S_hdd2crn[e]".("M_hdd2crn[e]")                                 
"S_CE1918[e]".("M_CE1918[e]")                                   
"S_CE6205[e]".("M_CE6205[e]")                                   
"S_CE4969[e]".("M_CE4969[e]")                                   
"S_CE1310[e]".("M_CE1310[e]")                                   
"S_sucsal[e]".("M_sucsal[e]")                                   
"S_CE7081[e]".("M_CE7081[e]")                                   
"S_egme[e]".("M_egme[e]")                                   
"S_sql[e]".("M_sql[e]")                                 
"S_orn_D[e]".("M_orn_D[e]")                                 
"S_5g2oxpt[e]".("M_5g2oxpt[e]")                                 
"S_HC02020[e]".("M_HC02020[e]")                                 
"S_xol27oh[e]".("M_xol27oh[e]")                                 
"S_xol25oh[e]".("M_xol25oh[e]")                                 
"S_dsmsterol[e]".("M_dsmsterol[e]")                                 
"S_3ityr_L[e]".("M_3ityr_L[e]")                                 
"S_35diotyr[e]".("M_35diotyr[e]")                                   
"S_13_cis_retn[e]".("M_13_cis_retn[e]")                                 
"S_C05767[e]".("M_C05767[e]")                                   
"S_ppbng[e]".("M_ppbng[e]")                                 
"S_12ppd_R[e]".("M_12ppd_R[e]")                                 
"S_ametam[e]".("M_ametam[e]")                                   
"S_xylu_L[e]".("M_xylu_L[e]")                                   
"S_xylu_D[e]".("M_xylu_D[e]")                                   
"S_sphings[e]".("M_sphings[e]")                                 
"S_im4ac[e]".("M_im4ac[e]")                                 
"S_aact[e]".("M_aact[e]")                                   
"S_sphgn[e]".("M_sphgn[e]")                                 
"S_C13856[e]".("M_C13856[e]")                                   
"S_prist[e]".("M_prist[e]")                                 
"S_CE2049[e]".("M_CE2049[e]")                                   
"S_CE2047[e]".("M_CE2047[e]")                                   
"S_fdp[e]".("M_fdp[e]")                                 
"S_coke[e]".("M_coke[e]")                                   
"S_5a2opntn[e]".("M_5a2opntn[e]")                                   
"S_arg_D[e]".("M_arg_D[e]")                                 
"S_dopa4glcur[e]".("M_dopa4glcur[e]")                                   
"S_dopa3glcur[e]".("M_dopa3glcur[e]")                                   
"S_CE5026[e]".("M_CE5026[e]")                                   
"S_CE1261[e]".("M_CE1261[e]")                                   
"S_CE5025[e]".("M_CE5025[e]")                                   
"S_CE2172[e]".("M_CE2172[e]")                                   
"S_CE5629[e]".("M_CE5629[e]")                                   
"S_galgluside_hs[e]".("M_galgluside_hs[e]")                                 
"S_gluside_hs[e]".("M_gluside_hs[e]")                                   
"S_gd3_hs[e]".("M_gd3_hs[e]")                                   
"S_gm1_hs[e]".("M_gm1_hs[e]")                                   
"S_34dhpe[e]".("M_34dhpe[e]")                                   
"S_M00003[e]".("M_M00003[e]")                                   
"S_M00008[e]".("M_M00008[e]")                                   
"S_M00010[e]".("M_M00010[e]")                                   
"S_M00017[e]".("M_M00017[e]")                                   
"S_M00019[e]".("M_M00019[e]")                                   
"S_M00021[e]".("M_M00021[e]")                                   
"S_M00115[e]".("M_M00115[e]")                                   
"S_M00260[e]".("M_M00260[e]")                                   
"S_M00265[e]".("M_M00265[e]")                                   
"S_M00315[e]".("M_M00315[e]")                                   
"S_M00341[e]".("M_M00341[e]")                                   
"S_M01207[e]".("M_M01207[e]")                                   
"S_M01235[e]".("M_M01235[e]")                                   
"S_M01238[e]".("M_M01238[e]")                                   
"S_M01582[e]".("M_M01582[e]")                                   
"S_M02053[e]".("M_M02053[e]")                                   
"S_M02457[e]".("M_M02457[e]")                                   
"S_M02613[e]".("M_M02613[e]")                                   
"S_M02745[e]".("M_M02745[e]")                                   
"S_M03045[e]".("M_M03045[e]")                                   
"S_M03153[e]".("M_M03153[e]")                                   
"S_C01601[e]".("M_C01601[e]")                                   
"S_M02108[e]".("M_M02108[e]")                                   
"S_M03117[e]".("M_M03117[e]")                                   
"S_M03134[e]".("M_M03134[e]")                                   
"S_nadh[e]".("M_nadh[e]")                                   
"S_M01870[e]".("M_M01870[e]")                                   
"S_M02446[e]".("M_M02446[e]")                                   
"S_M02447[e]".("M_M02447[e]")                                   
"S_M02449[e]".("M_M02449[e]")                                   
"S_M02451[e]".("M_M02451[e]")                                   
"S_itacon[e]".("M_itacon[e]")                                   
"S_adpman[e]".("M_adpman[e]")                                   
"S_rbl_D[e]".("M_rbl_D[e]")                                 
"S_M02155[e]".("M_M02155[e]")                                   
"S_M01989[e]".("M_M01989[e]")                                   
"S_M01881[e]".("M_M01881[e]")                                   
"S_n5m2masn[e]".("M_n5m2masn[e]")                                   
"S_dolichol_L[e]".("M_dolichol_L[e]")                                   
"S_12dhchol[e]".("M_12dhchol[e]")                                   
"S_3dhcdchol[e]".("M_3dhcdchol[e]")                                 
"S_3dhchol[e]".("M_3dhchol[e]")                                 
"S_3dhdchol[e]".("M_3dhdchol[e]")                                   
"S_3dhlchol[e]".("M_3dhlchol[e]")                                   
"S_7dhcdchol[e]".("M_7dhcdchol[e]")                                 
"S_7dhchol[e]".("M_7dhchol[e]")                                 
"S_cdca24g[e]".("M_cdca24g[e]")                                 
"S_cdca3g[e]".("M_cdca3g[e]")                                   
"S_coprost[e]".("M_coprost[e]")                                 
"S_hca24g[e]".("M_hca24g[e]")                                   
"S_hdca24g[e]".("M_hdca24g[e]")                                 
"S_hdca6g[e]".("M_hdca6g[e]")                                   
"S_hyochol[e]".("M_hyochol[e]")                                 
"S_icdchol[e]".("M_icdchol[e]")                                 
"S_isochol[e]".("M_isochol[e]")                                 
"S_lca24g[e]".("M_lca24g[e]")                                   
"S_lca3g[e]".("M_lca3g[e]")                                 
"S_thyochol[e]".("M_thyochol[e]")                                   
"S_uchol[e]".("M_uchol[e]")                                 
"S_12htacr[e]".("M_12htacr[e]")                                 
"S_14hmdz[e]".("M_14hmdz[e]")                                   
"S_1hibupglu_S[e]".("M_1hibupglu_S[e]")                                 
"S_1hibup_S[e]".("M_1hibup_S[e]")                                   
"S_1ohmdz[e]".("M_1ohmdz[e]")                                   
"S_2hatvacid[e]".("M_2hatvacid[e]")                                 
"S_2hatvlac[e]".("M_2hatvlac[e]")                                   
"S_2hibupglu_S[e]".("M_2hibupglu_S[e]")                                 
"S_2hibup_R[e]".("M_2hibup_R[e]")                                   
"S_2hibup_S[e]".("M_2hibup_S[e]")                                   
"S_35dsmv[e]".("M_35dsmv[e]")                                   
"S_3hibupglu_S[e]".("M_3hibupglu_S[e]")                                 
"S_3hibup_R[e]".("M_3hibup_R[e]")                                   
"S_3hibup_S[e]".("M_3hibup_S[e]")                                   
"S_3hlvstacid[e]".("M_3hlvstacid[e]")                                   
"S_3hpvstet[e]".("M_3hpvstet[e]")                                   
"S_3hpvs[e]".("M_3hpvs[e]")                                 
"S_3hsmvacid[e]".("M_3hsmvacid[e]")                                 
"S_3ispvs[e]".("M_3ispvs[e]")                                   
"S_3ohacmp[e]".("M_3ohacmp[e]")                                 
"S_4hatvacid[e]".("M_4hatvacid[e]")                                 
"S_4hatvlac[e]".("M_4hatvlac[e]")                                   
"S_4ohmdz[e]".("M_4ohmdz[e]")                                   
"S_56dhpvs[e]".("M_56dhpvs[e]")                                 
"S_56eppvs[e]".("M_56eppvs[e]")                                 
"S_5ohfvsglu[e]".("M_5ohfvsglu[e]")                                 
"S_5ohfvs[e]".("M_5ohfvs[e]")                                   
"S_6bhglz[e]".("M_6bhglz[e]")                                   
"S_6csmvacid[e]".("M_6csmvacid[e]")                                 
"S_6epvs[e]".("M_6epvs[e]")                                 
"S_6hlvst[e]".("M_6hlvst[e]")                                   
"S_6hmsmvacid[e]".("M_6hmsmvacid[e]")                                   
"S_6hsmvacid[e]".("M_6hsmvacid[e]")                                 
"S_6melvacid[e]".("M_6melvacid[e]")                                 
"S_6melvst[e]".("M_6melvst[e]")                                 
"S_6ohfvsglu[e]".("M_6ohfvsglu[e]")                                 
"S_7bhglz[e]".("M_7bhglz[e]")                                   
"S_7hpvs[e]".("M_7hpvs[e]")                                 
"S_acmp[e]".("M_acmp[e]")                                   
"S_am19cs[e]".("M_am19cs[e]")                                   
"S_am1csa[e]".("M_am1csa[e]")                                   
"S_am9csa[e]".("M_am9csa[e]")                                   
"S_atvacid[e]".("M_atvacid[e]")                                 
"S_atvlac[e]".("M_atvlac[e]")                                   
"S_caribupglu_S[e]".("M_caribupglu_S[e]")                                   
"S_caribup_s[e]".("M_caribup_s[e]")                                 
"S_crvs[e]".("M_crvs[e]")                                   
"S_crvsm24[e]".("M_crvsm24[e]")                                 
"S_csa[e]".("M_csa[e]")                                 
"S_deoxfvs[e]".("M_deoxfvs[e]")                                 
"S_dspvs[e]".("M_dspvs[e]")                                 
"S_epoxtac[e]".("M_epoxtac[e]")                                 
"S_fvs[e]".("M_fvs[e]")                                 
"S_glc3meacp[e]".("M_glc3meacp[e]")                                 
"S_glz[e]".("M_glz[e]")                                 
"S_ibup_R[e]".("M_ibup_R[e]")                                   
"S_ibup_S[e]".("M_ibup_S[e]")                                   
"S_ibupgluc[e]".("M_ibupgluc[e]")                                   
"S_isolvstacid[e]".("M_isolvstacid[e]")                                 
"S_lstn[e]".("M_lstn[e]")                                   
"S_lstnm7[e]".("M_lstnm7[e]")                                   
"S_lvst[e]".("M_lvst[e]")                                   
"S_mdz[e]".("M_mdz[e]")                                 
"S_mhglz[e]".("M_mhglz[e]")                                 
"S_nfdac[e]".("M_nfdac[e]")                                 
"S_nfdoh[e]".("M_nfdoh[e]")                                 
"S_profvs[e]".("M_profvs[e]")                                   
"S_ptvst[e]".("M_ptvst[e]")                                 
"S_ptvstlac[e]".("M_ptvstlac[e]")                                   
"S_pvs[e]".("M_pvs[e]")                                 
"S_pvsgluc[e]".("M_pvsgluc[e]")                                 
"S_smv[e]".("M_smv[e]")                                 
"S_smvacid[e]".("M_smvacid[e]")                                 
"S_tacr[e]".("M_tacr[e]")                                   
"S_tlacfvs[e]".("M_tlacfvs[e]")                                 
"S_tripvs[e]".("M_tripvs[e]")                                   
"S_ptvstm13[e]".("M_ptvstm13[e]")                                   
"S_caproic[e]".("M_caproic[e]")                                 
"S_1a25dhvitd2[e]".("M_1a25dhvitd2[e]")                                 
"S_peptide[e]".("M_peptide[e]")                                 
"S_abeta_L_lysine[e]".("M_abeta_L_lysine[e]")                                   
"S_tau_L_lysine[e]".("M_tau_L_lysine[e]")                                   
"S_TNFA_L_lysine[e]".("M_TNFA_L_lysine[e]")                                 
"S_IL6_L_lysine[e]".("M_IL6_L_lysine[e]")                                   
"S_3mlda[e]".("M_3mlda[e]")                                 
"S_5adtststerones[e]".("M_5adtststerones[e]")                                   
"S_acnacngalgbside_hs[e]".("M_acnacngalgbside_hs[e]")                                   
"S_crmp_hs[e]".("M_crmp_hs[e]")                                 
"S_3aib_D[e]".("M_3aib_D[e]")                                   
"S_lac_D[e]".("M_lac_D[e]")                                 
"S_aprgstrn[e]".("M_aprgstrn[e]")                                   
"S_avite1[e]".("M_avite1[e]")                                   
"S_fuc_L[e]".("M_fuc_L[e]")                                 
"S_gt1a_hs[e]".("M_gt1a_hs[e]")                                 
"S_hestratriol[e]".("M_hestratriol[e]")                                 
"S_nrpphrsf[e]".("M_nrpphrsf[e]")                                   
"S_s2l2fn2m2masn[e]".("M_s2l2fn2m2masn[e]")                                 
"S_s2l2n2m2masn[e]".("M_s2l2n2m2masn[e]")                                   
"S_sph1p[e]".("M_sph1p[e]")                                 
"S_tettet6[e]".("M_tettet6[e]")                                 
"S_tmndnc[e]".("M_tmndnc[e]")                                   
"S_triodthysuf[e]".("M_triodthysuf[e]")                                 
"S_tststerones[e]".("M_tststerones[e]")                                 
"S_tre[e]".("M_tre[e]")                                 
"S_dgmp[e]".("M_dgmp[e]")                                   
"S_dgtp[e]".("M_dgtp[e]")                                   
"S_ppi[e]".("M_ppi[e]")                                 
"S_pyr[e]".("M_pyr[e]")                                 
"S_acac[e]".("M_acac[e]")                                   
"S_c101crn[e]".("M_c101crn[e]")                                 
"S_c12dc[e]".("M_c12dc[e]")                                 
"S_c16dc[e]".("M_c16dc[e]")                                 
"S_c3dc[e]".("M_c3dc[e]")                                   
"S_c4dc[e]".("M_c4dc[e]")                                   
"S_c6crn[e]".("M_c6crn[e]")                                 
"S_c81crn[e]".("M_c81crn[e]")                                   
"S_3ddcrn[e]".("M_3ddcrn[e]")                                   
"S_ddeccrn[e]".("M_ddeccrn[e]")                                 
"S_ddece1crn[e]".("M_ddece1crn[e]")                                 
"S_3deccrn[e]".("M_3deccrn[e]")                                 
"S_decdicrn[e]".("M_decdicrn[e]")                                   
"S_3octdece1crn[e]".("M_3octdece1crn[e]")                                   
"S_3tdcrn[e]".("M_3tdcrn[e]")                                   
"S_tetdec2crn[e]".("M_tetdec2crn[e]")                                   
"S_tetdece1crn[e]".("M_tetdece1crn[e]")                                 
"S_slfcys[e]".("M_slfcys[e]")                                   
"S_4mop[e]".("M_4mop[e]")                                   
"S_cbasp[e]".("M_cbasp[e]")                                 
"S_phlac[e]".("M_phlac[e]")                                 
"S_15kprostgf2[e]".("M_15kprostgf2[e]")                                 
"S_3hpp[e]".("M_3hpp[e]")                                   
"S_3uib[e]".("M_3uib[e]")                                   
"S_adpac[e]".("M_adpac[e]")                                 
"S_adpoh[e]".("M_adpoh[e]")                                 
"S_pa_hs[e]".("M_pa_hs[e]")                                 
"S_C11695[e]".("M_C11695[e]")                                   
"S_CE5304[e]".("M_CE5304[e]")                                   
"S_CE6247[e]".("M_CE6247[e]")                                   
"S_dodecanac[e]".("M_dodecanac[e]")                                 
"S_sphmyln180241_hs[e]".("M_sphmyln180241_hs[e]")                                   
"S_sphmyln18114_hs[e]".("M_sphmyln18114_hs[e]")                                 
"S_sphmyln18115_hs[e]".("M_sphmyln18115_hs[e]")                                 
"S_sphmyln18116_hs[e]".("M_sphmyln18116_hs[e]")                                 
"S_sphmyln181161_hs[e]".("M_sphmyln181161_hs[e]")                                   
"S_sphmyln18117_hs[e]".("M_sphmyln18117_hs[e]")                                 
"S_sphmyln18118_hs[e]".("M_sphmyln18118_hs[e]")                                 
"S_sphmyln181181_hs[e]".("M_sphmyln181181_hs[e]")                                   
"S_sphmyln18120_hs[e]".("M_sphmyln18120_hs[e]")                                 
"S_sphmyln181201_hs[e]".("M_sphmyln181201_hs[e]")                                   
"S_sphmyln18121_hs[e]".("M_sphmyln18121_hs[e]")                                 
"S_sphmyln18122_hs[e]".("M_sphmyln18122_hs[e]")                                 
"S_sphmyln181221_hs[e]".("M_sphmyln181221_hs[e]")                                   
"S_sphmyln18123_hs[e]".("M_sphmyln18123_hs[e]")                                 
"S_sphmyln1824_hs[e]".("M_sphmyln1824_hs[e]")                                   
"S_sphmyln1825_hs[e]".("M_sphmyln1825_hs[e]")                                   
"S_subeac[e]".("M_subeac[e]")                                   
"S_pac[e]".("M_pac[e]")                                 
"S_pheacgly[e]".("M_pheacgly[e]")                                   
"S_homoval[e]".("M_homoval[e]")                                 
"S_s2l2n2m2m[e]".("M_s2l2n2m2m[e]")                                 
"S_phpyr[e]".("M_phpyr[e]")                                 
"S_ppiogly[e]".("M_ppiogly[e]")                                 
"S_tiggly[e]".("M_tiggly[e]")                                   
"S_3hivac[e]".("M_3hivac[e]")                                   
"S_3hadpac[e]".("M_3hadpac[e]")                                 
"S_3ohsebac[e]".("M_3ohsebac[e]")                                   
"S_3ohsubac[e]".("M_3ohsubac[e]")                                   
"S_hexgly[e]".("M_hexgly[e]")                                   
"S_subgly[e]".("M_subgly[e]")                                   
"S_4ohbut[e]".("M_4ohbut[e]")                                   
"S_34dhoxmand[e]".("M_34dhoxmand[e]")                                   
"S_dhea[e]".("M_dhea[e]")                                   
"S_estrone[e]".("M_estrone[e]")                                 
"S_chsterols[e]".("M_chsterols[e]")                                 
"S_M00117[e]".("M_M00117[e]")                                   
"S_M01197[e]".("M_M01197[e]")                                   
"S_M03051[e]".("M_M03051[e]")                                   
"S_ditp[e]".("M_ditp[e]")                                   
"S_M03131[e]".("M_M03131[e]")                                   
"S_1hmdgluc[e]".("M_1hmdgluc[e]")                                   
"S_2hatvlacgluc[e]".("M_2hatvlacgluc[e]")                                   
"S_4hmdgluc[e]".("M_4hmdgluc[e]")                                   
"S_oxyp[e]".("M_oxyp[e]")                                   
"S_strch1[e]".("M_strch1[e]")                                   
"S_strch2[e]".("M_strch2[e]")                                   
"S_glygn4[e]".("M_glygn4[e]")                                   
"S_adprbp[e]".("M_adprbp[e]")                                   
"S_gluala[e]".("M_gluala[e]")                                   
"S_glygn5[e]".("M_glygn5[e]")                                   
"S_lcts[e]".("M_lcts[e]")                                   
"S_sucr[e]".("M_sucr[e]")                                   
"S_ahdt[e]".("M_ahdt[e]")                                   
"S_dha[e]".("M_dha[e]")                                 
"S_HC01104[e]".("M_HC01104[e]")                                 
"S_HC01361[e]".("M_HC01361[e]")                                 
"S_HC01446[e]".("M_HC01446[e]")                                 
"S_HC01577[e]".("M_HC01577[e]")                                 
"S_HC01700[e]".("M_HC01700[e]")                                 
"S_HC00955[e]".("M_HC00955[e]")                                 
"S_maltpt[e]".("M_maltpt[e]")                                   
"S_malthx[e]".("M_malthx[e]")                                   
"S_CE2915[e]".("M_CE2915[e]")                                   
"S_CE4722[e]".("M_CE4722[e]")                                   
"S_CE2916[e]".("M_CE2916[e]")                                   
"S_CE4723[e]".("M_CE4723[e]")                                   
"S_CE2917[e]".("M_CE2917[e]")                                   
"S_CE4724[e]".("M_CE4724[e]")                                   
"S_malthp[e]".("M_malthp[e]")                                   
"S_CE1950[e]".("M_CE1950[e]")                                   
"S_cynt[e]".("M_cynt[e]")                                   
"S_CE5786[e]".("M_CE5786[e]")                                   
"S_CE5788[e]".("M_CE5788[e]")                                   
"S_CE5867[e]".("M_CE5867[e]")                                   
"S_CE5868[e]".("M_CE5868[e]")                                   
"S_CE5869[e]".("M_CE5869[e]")                                   
"S_CE4633[e]".("M_CE4633[e]")                                   
"S_no2[e]".("M_no2[e]")                                 
"S_CE4881[e]".("M_CE4881[e]")                                   
"S_CE1926[e]".("M_CE1926[e]")                                   
"S_CE5854[e]".("M_CE5854[e]")                                   
"S_12dgr120[e]".("M_12dgr120[e]")                                   
"S_CE1925[e]".("M_CE1925[e]")                                   
"S_CE5853[e]".("M_CE5853[e]")                                   
"S_cysam[e]".("M_cysam[e]")                                 
"S_pailste_hs[e]".("M_pailste_hs[e]")                                   
"S_xolest183_hs[e]".("M_xolest183_hs[e]")                                   
"S_xolest181_hs[e]".("M_xolest181_hs[e]")                                   
"S_xolest204_hs[e]".("M_xolest204_hs[e]")                                   
"S_M00234[e]".("M_M00234[e]")                                   
"S_M01807[e]".("M_M01807[e]")                                   
"S_M00503[e]".("M_M00503[e]")                                   
"S_M01111[e]".("M_M01111[e]")                                   
"S_ksi[e]".("M_ksi[e]")                                 
"S_ksi_deg1[e]".("M_ksi_deg1[e]")                                   
"S_HC01444[e]".("M_HC01444[e]")                                 
"S_CE5789[e]".("M_CE5789[e]")                                   
"S_CE5797[e]".("M_CE5797[e]")                                   
"S_CE5798[e]".("M_CE5798[e]")                                   
"S_aracheth[e]".("M_aracheth[e]")                                   
"S_didecaeth[e]".("M_didecaeth[e]")                                 
"S_diholineth[e]".("M_diholineth[e]")                                   
"S_docohxeth[e]".("M_docohxeth[e]")                                 
"S_docteteth[e]".("M_docteteth[e]")                                 
"S_hepdeceth[e]".("M_hepdeceth[e]")                                 
"S_hexdeceeth[e]".("M_hexdeceeth[e]")                                   
"S_lineth[e]".("M_lineth[e]")                                   
"S_oleth[e]".("M_oleth[e]")                                 
"S_pendecaeth[e]".("M_pendecaeth[e]")                                   
"S_pmeth[e]".("M_pmeth[e]")                                 
"S_steeth[e]".("M_steeth[e]")                                   
"S_tetdecaeth[e]".("M_tetdecaeth[e]")                                   
"S_trideceth[e]".("M_trideceth[e]")                                 
"S_h2co3[e]".("M_h2co3[e]")                                 
"S_17ahprgnlone[c][r]".("M_17ahprgnlone[c]", "M_17ahprgnlone[r]")                                   
"S_17ahprgstrn[c][r]".("M_17ahprgstrn[c]", "M_17ahprgstrn[r]")                                  
"S_1a25dhvitd3[c][m][n]".("M_1a25dhvitd3[c]", "M_1a25dhvitd3[m]", "M_1a25dhvitd3[n]")                                   
"S_1p3h5c[c][m]".("M_1p3h5c[c]", "M_1p3h5c[m]")                                 
"S_1pyr5c[c][m]".("M_1pyr5c[c]", "M_1pyr5c[m]")                                 
"S_20ahchsterol[m][r]".("M_20ahchsterol[m]", "M_20ahchsterol[r]")                                   
"S_25hvitd2[c][m]".("M_25hvitd2[c]", "M_25hvitd2[m]")                                   
"S_25hvitd3[c][m]".("M_25hvitd3[c]", "M_25hvitd3[m]")                                   
"S_2ddecdicoa[m][x]".("M_2ddecdicoa[m]", "M_2ddecdicoa[x]")                                 
"S_2decdicoa[m][x]".("M_2decdicoa[m]", "M_2decdicoa[x]")                                    
"S_2docopencoa[m][x]".("M_2docopencoa[m]", "M_2docopencoa[x]")                                  
"S_2dodtricoa[m][x]".("M_2dodtricoa[m]", "M_2dodtricoa[x]")                                 
"S_2hexdtricoa[m][x]".("M_2hexdtricoa[m]", "M_2hexdtricoa[x]")                                  
"S_2mop[c][m]".("M_2mop[c]", "M_2mop[m]")                                   
"S_2octdectecoa[m][x]".("M_2octdectecoa[m]", "M_2octdectecoa[x]")                                   
"S_34dhmald[c][m]".("M_34dhmald[c]", "M_34dhmald[m]")                                   
"S_3ddecdicoa[m][x]".("M_3ddecdicoa[m]", "M_3ddecdicoa[x]")                                 
"S_3decdicoa[m][x]".("M_3decdicoa[m]", "M_3decdicoa[x]")                                    
"S_3docopencoa[m][x]".("M_3docopencoa[m]", "M_3docopencoa[x]")                                  
"S_3dodtricoa[m][x]".("M_3dodtricoa[m]", "M_3dodtricoa[x]")                                 
"S_3hbcoa[m][x]".("M_3hbcoa[m]", "M_3hbcoa[x]")                                 
"S_3hbcoa_R[c][m]".("M_3hbcoa_R[c]", "M_3hbcoa_R[m]")                                   
"S_3hdcoa[c][m]".("M_3hdcoa[c]", "M_3hdcoa[m]")                                 
"S_3hddcoa[c][m]".("M_3hddcoa[c]", "M_3hddcoa[m]")                                  
"S_3hexdtricoa[m][x]".("M_3hexdtricoa[m]", "M_3hexdtricoa[x]")                                  
"S_3hlvst[c][r]".("M_3hlvst[c]", "M_3hlvst[r]")                                 
"S_3hpvscoa[c][m][x]".("M_3hpvscoa[c]", "M_3hpvscoa[m]", "M_3hpvscoa[x]")                                   
"S_3hpvstetcoa[c][m][x]".("M_3hpvstetcoa[c]", "M_3hpvstetcoa[m]", "M_3hpvstetcoa[x]")                                   
"S_3hsmv[c][r]".("M_3hsmv[c]", "M_3hsmv[r]")                                    
"S_3htdcoa[c][m][x]".("M_3htdcoa[c]", "M_3htdcoa[m]", "M_3htdcoa[x]")                                   
"S_3m4hpga[c][m]".("M_3m4hpga[c]", "M_3m4hpga[m]")                                  
"S_3meacmp[c][r]".("M_3meacmp[c]", "M_3meacmp[r]")                                  
"S_3octdece1coa[c][m]".("M_3octdece1coa[c]", "M_3octdece1coa[m]")                                   
"S_3octdectecoa[m][x]".("M_3octdectecoa[m]", "M_3octdectecoa[x]")                                   
"S_3ohodcoa[c][m][x]".("M_3ohodcoa[c]", "M_3ohodcoa[m]", "M_3ohodcoa[x]")                                   
"S_3ohxccoa[c][x]".("M_3ohxccoa[c]", "M_3ohxccoa[x]")                                   
"S_3sala[c][m]".("M_3sala[c]", "M_3sala[m]")                                    
"S_44mctr[c][r]".("M_44mctr[c]", "M_44mctr[r]")                                 
"S_44mzym[c][r]".("M_44mzym[c]", "M_44mzym[r]")                                 
"S_4hbzcoa[c][m]".("M_4hbzcoa[c]", "M_4hbzcoa[m]")                                  
"S_4hexdtricoa[m][x]".("M_4hexdtricoa[m]", "M_4hexdtricoa[x]")                                  
"S_4mzym_int1[c][r]".("M_4mzym_int1[c]", "M_4mzym_int1[r]")                                 
"S_4mzym_int2[c][r]".("M_4mzym_int2[c]", "M_4mzym_int2[r]")                                 
"S_5HPET[c][m]".("M_5HPET[c]", "M_5HPET[m]")                                    
"S_5tedtricoa[m][x]".("M_5tedtricoa[m]", "M_5tedtricoa[x]")                                 
"S_6csmv[c][r]".("M_6csmv[c]", "M_6csmv[r]")                                    
"S_6hlvstacid[c][r]".("M_6hlvstacid[c]", "M_6hlvstacid[r]")                                 
"S_6hmsmv[c][r]".("M_6hmsmv[c]", "M_6hmsmv[r]")                                 
"S_6hsmv[c][r]".("M_6hsmv[c]", "M_6hsmv[r]")                                    
"S_aacoa[c][m][x]".("M_aacoa[c]", "M_aacoa[m]", "M_aacoa[x]")                                   
"S_accoa[c][g][m][n][x]".("M_accoa[c]", "M_accoa[g]", "M_accoa[m]", "M_accoa[n]", "M_accoa[x]")                                 
"S_acgagbside_hs[c][g][l]".("M_acgagbside_hs[c]", "M_acgagbside_hs[g]", "M_acgagbside_hs[l]")                                   
"S_acgbgbside_hs[c][g][l]".("M_acgbgbside_hs[c]", "M_acgbgbside_hs[g]", "M_acgbgbside_hs[l]")                                   
"S_acglcgal14acglcgalgluside_hs[c][g]".("M_acglcgal14acglcgalgluside_hs[c]", "M_acglcgal14acglcgalgluside_hs[g]")                                   
"S_acglcgalacglcgal14acglcgalgluside_hs[c][g]".("M_acglcgalacglcgal14acglcgalgluside_hs[c]", "M_acglcgalacglcgal14acglcgalgluside_hs[g]")                                   
"S_acglcgalgluside_hs[c][g]".("M_acglcgalgluside_hs[c]", "M_acglcgalgluside_hs[g]")                                 
"S_adpcoa[c][x]".("M_adpcoa[c]", "M_adpcoa[x]")                                 
"S_adrncoa[c][m][r][x]".("M_adrncoa[c]", "M_adrncoa[m]", "M_adrncoa[r]", "M_adrncoa[x]")                                    
"S_adrncrn[c][m]".("M_adrncrn[c]", "M_adrncrn[m]")                                  
"S_andrstndn[c][r]".("M_andrstndn[c]", "M_andrstndn[r]")                                    
"S_arachcoa[c][m][r][x]".("M_arachcoa[c]", "M_arachcoa[m]", "M_arachcoa[r]", "M_arachcoa[x]")                                   
"S_arachcrn[c][m]".("M_arachcrn[c]", "M_arachcrn[m]")                                   
"S_arachdcoa[c][m][r][x]".("M_arachdcoa[c]", "M_arachdcoa[m]", "M_arachdcoa[r]", "M_arachdcoa[x]")                                  
"S_arachdcrn[c][m]".("M_arachdcrn[c]", "M_arachdcrn[m]")                                    
"S_b2coa[m][x]".("M_b2coa[m]", "M_b2coa[x]")                                    
"S_btcoa[c][m][x]".("M_btcoa[c]", "M_btcoa[m]", "M_btcoa[x]")                                   
"S_C01747[c][l]".("M_C01747[c]", "M_C01747[l]")                                 
"S_C02712[c][m]".("M_C02712[c]", "M_C02712[m]")                                 
"S_C05279[m][x]".("M_C05279[m]", "M_C05279[x]")                                 
"S_C05280[m][x]".("M_C05280[m]", "M_C05280[x]")                                 
"S_c10dc[c][x]".("M_c10dc[c]", "M_c10dc[x]")                                    
"S_c226coa[c][m][r][x]".("M_c226coa[c]", "M_c226coa[m]", "M_c226coa[r]", "M_c226coa[x]")                                    
"S_c226crn[c][m]".("M_c226crn[c]", "M_c226crn[m]")                                  
"S_c6dc[c][x]".("M_c6dc[c]", "M_c6dc[x]")                                   
"S_c8dc[c][x]".("M_c8dc[c]", "M_c8dc[x]")                                   
"S_cbl2[c][m]".("M_cbl2[c]", "M_cbl2[m]")                                   
"S_cbp[c][r]".("M_cbp[c]", "M_cbp[r]")                                  
"S_cdpchol[c][r]".("M_cdpchol[c]", "M_cdpchol[r]")                                  
"S_cdpdag_hs[c][m]".("M_cdpdag_hs[c]", "M_cdpdag_hs[m]")                                    
"S_CE0347[c][r]".("M_CE0347[c]", "M_CE0347[r]")                                 
"S_CE0693[m][x]".("M_CE0693[m]", "M_CE0693[x]")                                 
"S_CE0713[m][x]".("M_CE0713[m]", "M_CE0713[x]")                                 
"S_CE0785[m][x]".("M_CE0785[m]", "M_CE0785[x]")                                 
"S_CE0849[m][x]".("M_CE0849[m]", "M_CE0849[x]")                                 
"S_CE2053[m][r]".("M_CE2053[m]", "M_CE2053[r]")                                 
"S_CE2084[c][m]".("M_CE2084[c]", "M_CE2084[m]")                                 
"S_CE2242[c][m][x]".("M_CE2242[c]", "M_CE2242[m]", "M_CE2242[x]")                                   
"S_CE2243[m][x]".("M_CE2243[m]", "M_CE2243[x]")                                 
"S_CE2245[c][x]".("M_CE2245[c]", "M_CE2245[x]")                                 
"S_CE2246[c][m][x]".("M_CE2246[c]", "M_CE2246[m]", "M_CE2246[x]")                                   
"S_CE2247[m][x]".("M_CE2247[m]", "M_CE2247[x]")                                 
"S_CE2248[c][m][x]".("M_CE2248[c]", "M_CE2248[m]", "M_CE2248[x]")                                   
"S_CE2249[c][x]".("M_CE2249[c]", "M_CE2249[x]")                                 
"S_CE2250[c][m][x]".("M_CE2250[c]", "M_CE2250[m]", "M_CE2250[x]")                                   
"S_CE2251[m][x]".("M_CE2251[m]", "M_CE2251[x]")                                 
"S_CE2253[c][x]".("M_CE2253[c]", "M_CE2253[x]")                                 
"S_CE2417[m][x]".("M_CE2417[m]", "M_CE2417[x]")                                 
"S_CE2418[m][x]".("M_CE2418[m]", "M_CE2418[x]")                                 
"S_CE2420[m][x]".("M_CE2420[m]", "M_CE2420[x]")                                 
"S_CE2421[m][x]".("M_CE2421[m]", "M_CE2421[x]")                                 
"S_CE2422[m][x]".("M_CE2422[m]", "M_CE2422[x]")                                 
"S_CE2424[m][x]".("M_CE2424[m]", "M_CE2424[x]")                                 
"S_CE2432[m][x]".("M_CE2432[m]", "M_CE2432[x]")                                 
"S_CE2433[m][x]".("M_CE2433[m]", "M_CE2433[x]")                                 
"S_CE2434[m][x]".("M_CE2434[m]", "M_CE2434[x]")                                 
"S_CE2437[m][x]".("M_CE2437[m]", "M_CE2437[x]")                                 
"S_CE2438[m][x]".("M_CE2438[m]", "M_CE2438[x]")                                 
"S_CE2439[m][x]".("M_CE2439[m]", "M_CE2439[x]")                                 
"S_CE2440[m][x]".("M_CE2440[m]", "M_CE2440[x]")                                 
"S_CE2441[m][x]".("M_CE2441[m]", "M_CE2441[x]")                                 
"S_CE2442[m][x]".("M_CE2442[m]", "M_CE2442[x]")                                 
"S_CE4791[c][m][x]".("M_CE4791[c]", "M_CE4791[m]", "M_CE4791[x]")                                   
"S_CE4793[c][m][x]".("M_CE4793[c]", "M_CE4793[m]", "M_CE4793[x]")                                   
"S_CE4795[m][x]".("M_CE4795[m]", "M_CE4795[x]")                                 
"S_CE4843[c][m][r]".("M_CE4843[c]", "M_CE4843[m]", "M_CE4843[r]")                                   
"S_CE4847[c][m]".("M_CE4847[c]", "M_CE4847[m]")                                 
"S_CE4854[c][m]".("M_CE4854[c]", "M_CE4854[m]")                                 
"S_CE4855[c][x]".("M_CE4855[c]", "M_CE4855[x]")                                 
"S_CE4988[c][m][x]".("M_CE4988[c]", "M_CE4988[m]", "M_CE4988[x]")                                   
"S_CE4990[m][x]".("M_CE4990[m]", "M_CE4990[x]")                                 
"S_CE5114[c][m][x]".("M_CE5114[c]", "M_CE5114[m]", "M_CE5114[x]")                                   
"S_CE5116[m][x]".("M_CE5116[m]", "M_CE5116[x]")                                 
"S_CE5144[c][m][x]".("M_CE5144[c]", "M_CE5144[m]", "M_CE5144[x]")                                   
"S_CE5148[c][m][x]".("M_CE5148[c]", "M_CE5148[m]", "M_CE5148[x]")                                   
"S_CE5150[c][m][x]".("M_CE5150[c]", "M_CE5150[m]", "M_CE5150[x]")                                   
"S_CE5151[c][m][r][x]".("M_CE5151[c]", "M_CE5151[m]", "M_CE5151[r]", "M_CE5151[x]")                                 
"S_CE5152[c][m][x]".("M_CE5152[c]", "M_CE5152[m]", "M_CE5152[x]")                                   
"S_CE5153[c][m][x]".("M_CE5153[c]", "M_CE5153[m]", "M_CE5153[x]")                                   
"S_CE5154[c][m][x]".("M_CE5154[c]", "M_CE5154[m]", "M_CE5154[x]")                                   
"S_CE5155[c][m][r][x]".("M_CE5155[c]", "M_CE5155[m]", "M_CE5155[r]", "M_CE5155[x]")                                 
"S_CE5156[c][x]".("M_CE5156[c]", "M_CE5156[x]")                                 
"S_CE5157[c][x]".("M_CE5157[c]", "M_CE5157[x]")                                 
"S_CE5158[c][x]".("M_CE5158[c]", "M_CE5158[x]")                                 
"S_CE5253[c][l]".("M_CE5253[c]", "M_CE5253[l]")                                 
"S_CE5944[m][x]".("M_CE5944[m]", "M_CE5944[x]")                                 
"S_CE5947[c][m][x]".("M_CE5947[c]", "M_CE5947[m]", "M_CE5947[x]")                                   
"S_chlstol[c][r]".("M_chlstol[c]", "M_chlstol[r]")                                  
"S_cholcoa[c][m][r][x]".("M_cholcoa[c]", "M_cholcoa[m]", "M_cholcoa[r]", "M_cholcoa[x]")                                    
"S_cholcoads[m][x]".("M_cholcoads[m]", "M_cholcoads[x]")                                    
"S_cholcoaone[m][x]".("M_cholcoaone[m]", "M_cholcoaone[x]")                                 
"S_cholcoar[c][m][r][x]".("M_cholcoar[c]", "M_cholcoar[m]", "M_cholcoar[r]", "M_cholcoar[x]")                                   
"S_clpndcoa[c][m][r][x]".("M_clpndcoa[c]", "M_clpndcoa[m]", "M_clpndcoa[r]", "M_clpndcoa[x]")                                   
"S_clpndcrn[c][m]".("M_clpndcrn[c]", "M_clpndcrn[m]")                                   
"S_cmpacna[c][g][n]".("M_cmpacna[c]", "M_cmpacna[g]", "M_cmpacna[n]")                                   
"S_coa[c][g][l][m][n][r][x]".("M_coa[c]", "M_coa[g]", "M_coa[l]", "M_coa[m]", "M_coa[n]", "M_coa[r]", "M_coa[x]")                                   
"S_core6[g][l]".("M_core6[g]", "M_core6[l]")                                    
"S_coucoa[c][m]".("M_coucoa[c]", "M_coucoa[m]")                                 
"S_dadp[c][m][n]".("M_dadp[c]", "M_dadp[m]", "M_dadp[n]")                                   
"S_datp[c][m][n]".("M_datp[c]", "M_datp[m]", "M_datp[n]")                                   
"S_dc2coa[m][x]".("M_dc2coa[m]", "M_dc2coa[x]")                                 
"S_dcacoa[c][m][x]".("M_dcacoa[c]", "M_dcacoa[m]", "M_dcacoa[x]")                                   
"S_dcdp[c][m][n]".("M_dcdp[c]", "M_dcdp[m]", "M_dcdp[n]")                                   
"S_dcholcoa[c][r][x]".("M_dcholcoa[c]", "M_dcholcoa[r]", "M_dcholcoa[x]")                                   
"S_dcsptn1coa[c][m][r][x]".("M_dcsptn1coa[c]", "M_dcsptn1coa[m]", "M_dcsptn1coa[r]", "M_dcsptn1coa[x]")                                 
"S_dcsptn1crn[c][m]".("M_dcsptn1crn[c]", "M_dcsptn1crn[m]")                                 
"S_dctp[c][m][n]".("M_dctp[c]", "M_dctp[m]", "M_dctp[n]")                                   
"S_dd2coa[c][m][x]".("M_dd2coa[c]", "M_dd2coa[m]", "M_dd2coa[x]")                                   
"S_dd3coa[m][x]".("M_dd3coa[m]", "M_dd3coa[x]")                                 
"S_ddcacoa[c][m][r][x]".("M_ddcacoa[c]", "M_ddcacoa[m]", "M_ddcacoa[r]", "M_ddcacoa[x]")                                    
"S_ddsmsterol[c][r]".("M_ddsmsterol[c]", "M_ddsmsterol[r]")                                 
"S_dec24dicoa[m][x]".("M_dec24dicoa[m]", "M_dec24dicoa[x]")                                 
"S_dec47dicoa[m][x]".("M_dec47dicoa[m]", "M_dec47dicoa[x]")                                 
"S_decdp[c][m]".("M_decdp[c]", "M_decdp[m]")                                    
"S_dece3coa[m][x]".("M_dece3coa[m]", "M_dece3coa[x]")                                   
"S_dece4coa[m][x]".("M_dece4coa[m]", "M_dece4coa[x]")                                   
"S_dectricoa[m][x]".("M_dectricoa[m]", "M_dectricoa[x]")                                    
"S_dgdp[c][m]".("M_dgdp[c]", "M_dgdp[m]")                                   
"S_dhcholestancoa[c][r][x]".("M_dhcholestancoa[c]", "M_dhcholestancoa[r]", "M_dhcholestancoa[x]")                                   
"S_dhcrm_hs[c][g]".("M_dhcrm_hs[c]", "M_dhcrm_hs[g]")                                   
"S_digalside_hs[c][l]".("M_digalside_hs[c]", "M_digalside_hs[l]")                                   
"S_dlnlcgcoa[c][m][r]".("M_dlnlcgcoa[c]", "M_dlnlcgcoa[m]", "M_dlnlcgcoa[r]")                                   
"S_dlnlcgcrn[c][m][r]".("M_dlnlcgcrn[c]", "M_dlnlcgcrn[m]", "M_dlnlcgcrn[r]")                                   
"S_dmnoncoa[c][m][x]".("M_dmnoncoa[c]", "M_dmnoncoa[m]", "M_dmnoncoa[x]")                                   
"S_dmnoncrn[c][m][x]".("M_dmnoncrn[c]", "M_dmnoncrn[m]", "M_dmnoncrn[x]")                                   
"S_dmpp[c][x]".("M_dmpp[c]", "M_dmpp[x]")                                   
"S_dnad[c][n]".("M_dnad[c]", "M_dnad[n]")                                   
"S_docohexcoa[m][x]".("M_docohexcoa[m]", "M_docohexcoa[x]")                                 
"S_docoscoa[c][m][r][x]".("M_docoscoa[c]", "M_docoscoa[m]", "M_docoscoa[r]", "M_docoscoa[x]")                                   
"S_dolmanp_U[c][r]".("M_dolmanp_U[c]", "M_dolmanp_U[r]")                                    
"S_dolp_U[c][r]".("M_dolp_U[c]", "M_dolp_U[r]")                                 
"S_dpcoa[c][l][m]".("M_dpcoa[c]", "M_dpcoa[l]", "M_dpcoa[m]")                                   
"S_dudp[c][m]".("M_dudp[c]", "M_dudp[m]")                                   
"S_dump[c][m]".("M_dump[c]", "M_dump[m]")                                   
"S_dutp[c][m]".("M_dutp[c]", "M_dutp[m]")                                   
"S_eicostetcoa[c][m][r]".("M_eicostetcoa[c]", "M_eicostetcoa[m]", "M_eicostetcoa[r]")                                   
"S_eicostetcrn[c][m]".("M_eicostetcrn[c]", "M_eicostetcrn[m]")                                  
"S_eitetcoa[m][x]".("M_eitetcoa[m]", "M_eitetcoa[x]")                                   
"S_fad[c][m][r][x]".("M_fad[c]", "M_fad[m]", "M_fad[r]", "M_fad[x]")                                    
"S_fadh2[c][m][r][x]".("M_fadh2[c]", "M_fadh2[m]", "M_fadh2[r]", "M_fadh2[x]")                                  
"S_formcoa[c][x]".("M_formcoa[c]", "M_formcoa[x]")                                  
"S_frdp[c][r][x]".("M_frdp[c]", "M_frdp[r]", "M_frdp[x]")                                   
"S_fvscoa[c][x]".("M_fvscoa[c]", "M_fvscoa[x]")                                 
"S_g6p[c][r]".("M_g6p[c]", "M_g6p[r]")                                  
"S_ga1_hs[c][g]".("M_ga1_hs[c]", "M_ga1_hs[g]")                                 
"S_ga2_hs[c][g]".("M_ga2_hs[c]", "M_ga2_hs[g]")                                 
"S_gacpail_hs[c][r]".("M_gacpail_hs[c]", "M_gacpail_hs[r]")                                 
"S_galacglcgal14acglcgalgluside_hs[c][g]".("M_galacglcgal14acglcgalgluside_hs[c]", "M_galacglcgal14acglcgalgluside_hs[g]")                                  
"S_galacglcgalgluside_hs[c][g]".("M_galacglcgalgluside_hs[c]", "M_galacglcgalgluside_hs[g]")                                    
"S_galgbside_hs[c][g]".("M_galgbside_hs[c]", "M_galgbside_hs[g]")                                   
"S_galside_hs[c][l][n]".("M_galside_hs[c]", "M_galside_hs[l]", "M_galside_hs[n]")                                   
"S_gcald[c][m]".("M_gcald[c]", "M_gcald[m]")                                    
"S_gd1a_hs[c][g][n]".("M_gd1a_hs[c]", "M_gd1a_hs[g]", "M_gd1a_hs[n]")                                   
"S_gdpfuc[c][g]".("M_gdpfuc[c]", "M_gdpfuc[g]")                                 
"S_glac[c][r]".("M_glac[c]", "M_glac[r]")                                   
"S_glu5sa[c][m]".("M_glu5sa[c]", "M_glu5sa[m]")                                 
"S_gm1b_hs[c][g]".("M_gm1b_hs[c]", "M_gm1b_hs[g]")                                  
"S_grdp[c][x]".("M_grdp[c]", "M_grdp[x]")                                   
"S_guln[c][r]".("M_guln[c]", "M_guln[r]")                                   
"S_HC01412[m][x]".("M_HC01412[m]", "M_HC01412[x]")                                  
"S_HC01415[m][x]".("M_HC01415[m]", "M_HC01415[x]")                                  
"S_HC01434[c][m][x]".("M_HC01434[c]", "M_HC01434[m]", "M_HC01434[x]")                                   
"S_HC01668[c][m]".("M_HC01668[c]", "M_HC01668[m]")                                  
"S_HC02057[c][r]".("M_HC02057[c]", "M_HC02057[r]")                                  
"S_HC02110[c][r]".("M_HC02110[c]", "M_HC02110[r]")                                  
"S_HC10784[c][r]".("M_HC10784[c]", "M_HC10784[r]")                                  
"S_HC10856[m][x]".("M_HC10856[m]", "M_HC10856[x]")                                  
"S_HC10857[m][x]".("M_HC10857[m]", "M_HC10857[x]")                                  
"S_HC10858[m][x]".("M_HC10858[m]", "M_HC10858[x]")                                  
"S_hdcoa[c][m]".("M_hdcoa[c]", "M_hdcoa[m]")                                    
"S_hdd2coa[c][m][r][x]".("M_hdd2coa[c]", "M_hdd2coa[m]", "M_hdd2coa[r]", "M_hdd2coa[x]")                                    
"S_hexccoa[c][r][x]".("M_hexccoa[c]", "M_hexccoa[r]", "M_hexccoa[x]")                                   
"S_hexdectecoa[m][x]".("M_hexdectecoa[m]", "M_hexdectecoa[x]")                                  
"S_hexdicoa[c][r]".("M_hexdicoa[c]", "M_hexdicoa[r]")                                   
"S_hexe3coa[m][x]".("M_hexe3coa[m]", "M_hexe3coa[x]")                                   
"S_hmgcoa[c][m][x]".("M_hmgcoa[c]", "M_hmgcoa[m]", "M_hmgcoa[x]")                                   
"S_hpdcacoa[c][m][r]".("M_hpdcacoa[c]", "M_hpdcacoa[m]", "M_hpdcacoa[r]")                                   
"S_hpdcacrn[c][m]".("M_hpdcacrn[c]", "M_hpdcacrn[m]")                                   
"S_hpyr[c][m][x]".("M_hpyr[c]", "M_hpyr[m]", "M_hpyr[x]")                                   
"S_hx2coa[m][x]".("M_hx2coa[m]", "M_hx2coa[x]")                                 
"S_id3acald[c][m]".("M_id3acald[c]", "M_id3acald[m]")                                   
"S_ipdp[c][x]".("M_ipdp[c]", "M_ipdp[x]")                                   
"S_L2aadp6sa[c][m]".("M_L2aadp6sa[c]", "M_L2aadp6sa[m]")                                    
"S_lald_L[c][m]".("M_lald_L[c]", "M_lald_L[m]")                                 
"S_lneldccoa[c][m][r]".("M_lneldccoa[c]", "M_lneldccoa[m]", "M_lneldccoa[r]")                                   
"S_lnlccoa[c][m][r][x]".("M_lnlccoa[c]", "M_lnlccoa[m]", "M_lnlccoa[r]", "M_lnlccoa[x]")                                    
"S_lnlncacoa[c][m][r]".("M_lnlncacoa[c]", "M_lnlncacoa[m]", "M_lnlncacoa[r]")                                   
"S_lnlncacrn[c][m]".("M_lnlncacrn[c]", "M_lnlncacrn[m]")                                    
"S_lnlncgcoa[c][m][r][x]".("M_lnlncgcoa[c]", "M_lnlncgcoa[m]", "M_lnlncgcoa[r]", "M_lnlncgcoa[x]")                                  
"S_lnlncgcrn[c][m][r]".("M_lnlncgcrn[c]", "M_lnlncgcrn[m]", "M_lnlncgcrn[r]")                                   
"S_lvstacid[c][r]".("M_lvstacid[c]", "M_lvstacid[r]")                                   
"S_M00004[c][m][r]".("M_M00004[c]", "M_M00004[m]", "M_M00004[r]")                                   
"S_M00006[c][m][r]".("M_M00006[c]", "M_M00006[m]", "M_M00006[r]")                                   
"S_M00011[c][m]".("M_M00011[c]", "M_M00011[m]")                                 
"S_M00012[c][m][r]".("M_M00012[c]", "M_M00012[m]", "M_M00012[r]")                                   
"S_M00018[c][m][r]".("M_M00018[c]", "M_M00018[m]", "M_M00018[r]")                                   
"S_M00020[c][m][r]".("M_M00020[c]", "M_M00020[m]", "M_M00020[r]")                                   
"S_M00022[c][m]".("M_M00022[c]", "M_M00022[m]")                                 
"S_M00023[c][m][r]".("M_M00023[c]", "M_M00023[m]", "M_M00023[r]")                                   
"S_M00044[c][m]".("M_M00044[c]", "M_M00044[m]")                                 
"S_M00049[c][x]".("M_M00049[c]", "M_M00049[x]")                                 
"S_M00054[c][m]".("M_M00054[c]", "M_M00054[m]")                                 
"S_M00100[c][m]".("M_M00100[c]", "M_M00100[m]")                                 
"S_M00101[c][m][r]".("M_M00101[c]", "M_M00101[m]", "M_M00101[r]")                                   
"S_M00116[c][m]".("M_M00116[c]", "M_M00116[m]")                                 
"S_M00122[c][m]".("M_M00122[c]", "M_M00122[m]")                                 
"S_M00123[c][m][r]".("M_M00123[c]", "M_M00123[m]", "M_M00123[r]")                                   
"S_M00127[c][m][r]".("M_M00127[c]", "M_M00127[m]", "M_M00127[r]")                                   
"S_M00129[c][m][r]".("M_M00129[c]", "M_M00129[m]", "M_M00129[r]")                                   
"S_M00172[m][x]".("M_M00172[m]", "M_M00172[x]")                                 
"S_M00261[c][m]".("M_M00261[c]", "M_M00261[m]")                                 
"S_M00263[c][m]".("M_M00263[c]", "M_M00263[m]")                                 
"S_M00342[c][m]".("M_M00342[c]", "M_M00342[m]")                                 
"S_M00343[c][m][r]".("M_M00343[c]", "M_M00343[m]", "M_M00343[r]")                                   
"S_M00702[c][m]".("M_M00702[c]", "M_M00702[m]")                                 
"S_M00715[c][x]".("M_M00715[c]", "M_M00715[x]")                                 
"S_M00778[c][m]".("M_M00778[c]", "M_M00778[m]")                                 
"S_M00783[c][x]".("M_M00783[c]", "M_M00783[x]")                                 
"S_M00790[c][m]".("M_M00790[c]", "M_M00790[m]")                                 
"S_M00843[c][m]".("M_M00843[c]", "M_M00843[m]")                                 
"S_M00849[m][x]".("M_M00849[m]", "M_M00849[x]")                                 
"S_M00873[c][m]".("M_M00873[c]", "M_M00873[m]")                                 
"S_M00879[c][x]".("M_M00879[c]", "M_M00879[x]")                                 
"S_M00885[m][x]".("M_M00885[m]", "M_M00885[x]")                                 
"S_M00887[c][m]".("M_M00887[c]", "M_M00887[m]")                                 
"S_M01075[c][r]".("M_M01075[c]", "M_M01075[r]")                                 
"S_M01141[c][m][r][x]".("M_M01141[c]", "M_M01141[m]", "M_M01141[r]", "M_M01141[x]")                                 
"S_M01191[c][m][r][x]".("M_M01191[c]", "M_M01191[m]", "M_M01191[r]", "M_M01191[x]")                                 
"S_M01236[c][m][r]".("M_M01236[c]", "M_M01236[m]", "M_M01236[r]")                                   
"S_M01237[c][m][r]".("M_M01237[c]", "M_M01237[m]", "M_M01237[r]")                                   
"S_M01573[m][x]".("M_M01573[m]", "M_M01573[x]")                                 
"S_M01724[c][m][r]".("M_M01724[c]", "M_M01724[m]", "M_M01724[r]")                                   
"S_M01726[c][m]".("M_M01726[c]", "M_M01726[m]")                                 
"S_M01727[c][m]".("M_M01727[c]", "M_M01727[m]")                                 
"S_M01729[c][m]".("M_M01729[c]", "M_M01729[m]")                                 
"S_M01770[c][m]".("M_M01770[c]", "M_M01770[m]")                                 
"S_M01775[c][m]".("M_M01775[c]", "M_M01775[m]")                                 
"S_M01776[c][m]".("M_M01776[c]", "M_M01776[m]")                                 
"S_M01777[c][m]".("M_M01777[c]", "M_M01777[m]")                                 
"S_M02051[c][m]".("M_M02051[c]", "M_M02051[m]")                                 
"S_M02052[c][m][r]".("M_M02052[c]", "M_M02052[m]", "M_M02052[r]")                                   
"S_M02102[c][m]".("M_M02102[c]", "M_M02102[m]")                                 
"S_M02103[c][m]".("M_M02103[c]", "M_M02103[m]")                                 
"S_M02107[c][m]".("M_M02107[c]", "M_M02107[m]")                                 
"S_M02112[c][r][x]".("M_M02112[c]", "M_M02112[r]", "M_M02112[x]")                                   
"S_M02611[c][m]".("M_M02611[c]", "M_M02611[m]")                                 
"S_M02612[c][m][r]".("M_M02612[c]", "M_M02612[m]", "M_M02612[r]")                                   
"S_M02616[c][m]".("M_M02616[c]", "M_M02616[m]")                                 
"S_M02637[c][m][r]".("M_M02637[c]", "M_M02637[m]", "M_M02637[r]")                                   
"S_M02638[c][m]".("M_M02638[c]", "M_M02638[m]")                                 
"S_M02694[c][m]".("M_M02694[c]", "M_M02694[m]")                                 
"S_M02973[c][m]".("M_M02973[c]", "M_M02973[m]")                                 
"S_M02976[c][m]".("M_M02976[c]", "M_M02976[m]")                                 
"S_M03014[c][m]".("M_M03014[c]", "M_M03014[m]")                                 
"S_M03016[c][x]".("M_M03016[c]", "M_M03016[x]")                                 
"S_M03019[m][x]".("M_M03019[m]", "M_M03019[x]")                                 
"S_M03022[m][x]".("M_M03022[m]", "M_M03022[x]")                                 
"S_M03047[c][r][x]".("M_M03047[c]", "M_M03047[r]", "M_M03047[x]")                                   
"S_M03050[c][m][r]".("M_M03050[c]", "M_M03050[m]", "M_M03050[r]")                                   
"S_M03116[c][m]".("M_M03116[c]", "M_M03116[m]")                                 
"S_methf[c][m]".("M_methf[c]", "M_methf[m]")                                    
"S_minohp[c][n]".("M_minohp[c]", "M_minohp[n]")                                 
"S_nadph[c][m][r][x]".("M_nadph[c]", "M_nadph[m]", "M_nadph[r]", "M_nadph[x]")                                  
"S_nmn[c][m][n]".("M_nmn[c]", "M_nmn[m]", "M_nmn[n]")                                   
"S_nrvnccoa[c][r][x]".("M_nrvnccoa[c]", "M_nrvnccoa[r]", "M_nrvnccoa[x]")                                   
"S_occoa[c][m][x]".("M_occoa[c]", "M_occoa[m]", "M_occoa[x]")                                   
"S_octdececoa[c][m]".("M_octdececoa[c]", "M_octdececoa[m]")                                 
"S_octdececrn[c][m]".("M_octdececrn[c]", "M_octdececrn[m]")                                 
"S_octe5coa[m][x]".("M_octe5coa[m]", "M_octe5coa[x]")                                   
"S_od2coa[c][m][x]".("M_od2coa[c]", "M_od2coa[m]", "M_od2coa[x]")                                   
"S_odecoa[c][m][r][x]".("M_odecoa[c]", "M_odecoa[m]", "M_odecoa[r]", "M_odecoa[x]")                                 
"S_omhdecacid[c][r]".("M_omhdecacid[c]", "M_omhdecacid[r]")                                 
"S_pacald[c][m]".("M_pacald[c]", "M_pacald[m]")                                 
"S_pail35p_hs[c][n]".("M_pail35p_hs[c]", "M_pail35p_hs[n]")                                 
"S_pail45p_hs[c][n]".("M_pail45p_hs[c]", "M_pail45p_hs[n]")                                 
"S_pail4p_hs[c][n]".("M_pail4p_hs[c]", "M_pail4p_hs[n]")                                    
"S_pail5p_hs[c][n]".("M_pail5p_hs[c]", "M_pail5p_hs[n]")                                    
"S_pan4p[c][m]".("M_pan4p[c]", "M_pan4p[m]")                                    
"S_pap[c][g]".("M_pap[c]", "M_pap[g]")                                  
"S_paps[c][g]".("M_paps[c]", "M_paps[g]")                                   
"S_phytcoa[c][x]".("M_phytcoa[c]", "M_phytcoa[x]")                                  
"S_pmtcoa[c][m][r][x]".("M_pmtcoa[c]", "M_pmtcoa[m]", "M_pmtcoa[r]", "M_pmtcoa[x]")                                 
"S_ppcoa[c][m][x]".("M_ppcoa[c]", "M_ppcoa[m]", "M_ppcoa[x]")                                   
"S_ppmi12346p[c][n]".("M_ppmi12346p[c]", "M_ppmi12346p[n]")                                 
"S_ppp9[c][m]".("M_ppp9[c]", "M_ppp9[m]")                                   
"S_pppg9[c][m]".("M_pppg9[c]", "M_pppg9[m]")                                    
"S_prgnlone[c][m][r]".("M_prgnlone[c]", "M_prgnlone[m]", "M_prgnlone[r]")                                   
"S_pristanal[c][x]".("M_pristanal[c]", "M_pristanal[x]")                                    
"S_pristcoa[c][x]".("M_pristcoa[c]", "M_pristcoa[x]")                                   
"S_profvscoa[c][x]".("M_profvscoa[c]", "M_profvscoa[x]")                                    
"S_ptdcacoa[c][m][r]".("M_ptdcacoa[c]", "M_ptdcacoa[m]", "M_ptdcacoa[r]")                                   
"S_ptdcacrn[c][m]".("M_ptdcacrn[c]", "M_ptdcacrn[m]")                                   
"S_retinal_cis_13[c][r]".("M_retinal_cis_13[c]", "M_retinal_cis_13[r]")                                 
"S_rsv[c][r]".("M_rsv[c]", "M_rsv[r]")                                  
"S_rsvlac[c][r]".("M_rsvlac[c]", "M_rsvlac[r]")                                 
"S_sbcoa[c][x]".("M_sbcoa[c]", "M_sbcoa[x]")                                    
"S_sebcoa[c][x]".("M_sebcoa[c]", "M_sebcoa[x]")                                 
"S_Ser_Gly_Ala_X_Gly[l][r]".("M_Ser_Gly_Ala_X_Gly[l]", "M_Ser_Gly_Ala_X_Gly[r]")                                    
"S_Ser_Thr[g][l]".("M_Ser_Thr[g]", "M_Ser_Thr[l]")                                  
"S_Ssq23epx[c][r]".("M_Ssq23epx[c]", "M_Ssq23epx[r]")                                   
"S_stcoa[c][m][r][x]".("M_stcoa[c]", "M_stcoa[m]", "M_stcoa[r]", "M_stcoa[x]")                                  
"S_strdnccoa[c][m][r][x]".("M_strdnccoa[c]", "M_strdnccoa[m]", "M_strdnccoa[r]", "M_strdnccoa[x]")                                  
"S_strdnccrn[c][m][r]".("M_strdnccrn[c]", "M_strdnccrn[m]", "M_strdnccrn[r]")                                   
"S_succoa[c][m]".("M_succoa[c]", "M_succoa[m]")                                 
"S_tdcoa[c][m][r][x]".("M_tdcoa[c]", "M_tdcoa[m]", "M_tdcoa[r]", "M_tdcoa[x]")                                  
"S_tetdecdicoa[m][x]".("M_tetdecdicoa[m]", "M_tetdecdicoa[x]")                                  
"S_tethex3coa[c][r][x]".("M_tethex3coa[c]", "M_tethex3coa[r]", "M_tethex3coa[x]")                                   
"S_tetpent3coa[c][r][x]".("M_tetpent3coa[c]", "M_tetpent3coa[r]", "M_tetpent3coa[x]")                                   
"S_tetpent6coa[c][r][x]".("M_tetpent6coa[c]", "M_tetpent6coa[r]", "M_tetpent6coa[x]")                                   
"S_tettet6coa[c][r][x]".("M_tettet6coa[c]", "M_tettet6coa[r]", "M_tettet6coa[x]")                                   
"S_thcrm_hs[c][g][l]".("M_thcrm_hs[c]", "M_thcrm_hs[g]", "M_thcrm_hs[l]")                                   
"S_tmndnccoa[c][m][r][x]".("M_tmndnccoa[c]", "M_tmndnccoa[m]", "M_tmndnccoa[r]", "M_tmndnccoa[x]")                                  
"S_tmndnccrn[c][m][r]".("M_tmndnccrn[c]", "M_tmndnccrn[m]", "M_tmndnccrn[r]")                                   
"S_Tn_antigen[g][l]".("M_Tn_antigen[g]", "M_Tn_antigen[l]")                                 
"S_ttccoa[c][r][x]".("M_ttccoa[c]", "M_ttccoa[r]", "M_ttccoa[x]")                                   
"S_uacgam[c][g][r]".("M_uacgam[c]", "M_uacgam[g]", "M_uacgam[r]")                                   
"S_udpacgal[c][g][l]".("M_udpacgal[c]", "M_udpacgal[g]", "M_udpacgal[l]")                                   
"S_udpgal[c][g][n][r]".("M_udpgal[c]", "M_udpgal[g]", "M_udpgal[n]", "M_udpgal[r]")                                 
"S_vacccoa[c][m][r]".("M_vacccoa[c]", "M_vacccoa[m]", "M_vacccoa[r]")                                   
"S_vacccrn[c][m]".("M_vacccrn[c]", "M_vacccrn[m]")                                  
"S_xser[g][r]".("M_xser[g]", "M_xser[r]")                                   
"S_zymst[c][r]".("M_zymst[c]", "M_zymst[r]")                                    
"S_zymstnl[c][r]".("M_zymstnl[c]", "M_zymstnl[r]")                                  
"S_10fthf[c][e][l][m]".("M_10fthf[c]", "M_10fthf[e]", "M_10fthf[l]", "M_10fthf[m]")                                 
"S_10fthf5glu[c][e][l][m]".("M_10fthf5glu[c]", "M_10fthf5glu[e]", "M_10fthf5glu[l]", "M_10fthf5glu[m]")                                 
"S_10fthf6glu[c][e][l][m]".("M_10fthf6glu[c]", "M_10fthf6glu[e]", "M_10fthf6glu[l]", "M_10fthf6glu[m]")                                 
"S_10fthf7glu[c][e][l][m]".("M_10fthf7glu[c]", "M_10fthf7glu[e]", "M_10fthf7glu[l]", "M_10fthf7glu[m]")                                 
"S_11docrtsl[c][e][m][r]".("M_11docrtsl[c]", "M_11docrtsl[e]", "M_11docrtsl[m]", "M_11docrtsl[r]")                                  
"S_11docrtstrn[c][e][m][r]".("M_11docrtstrn[c]", "M_11docrtstrn[e]", "M_11docrtstrn[m]", "M_11docrtstrn[r]")                                    
"S_12dhchol[c][e]".("M_12dhchol[c]", "M_12dhchol[e]")                                   
"S_12HPET[c][e][r]".("M_12HPET[c]", "M_12HPET[e]", "M_12HPET[r]")                                   
"S_12htacr[c][e][r]".("M_12htacr[c]", "M_12htacr[e]", "M_12htacr[r]")                                   
"S_12ppd_R[c][e]".("M_12ppd_R[c]", "M_12ppd_R[e]")                                  
"S_13_cis_retn[c][e][r]".("M_13_cis_retn[c]", "M_13_cis_retn[e]", "M_13_cis_retn[r]")                                   
"S_13_cis_retnglc[c][e][r]".("M_13_cis_retnglc[c]", "M_13_cis_retnglc[e]", "M_13_cis_retnglc[r]")                                   
"S_14hmdz[c][e][r]".("M_14hmdz[c]", "M_14hmdz[e]", "M_14hmdz[r]")                                   
"S_15HPET[c][e][n][r][x]".("M_15HPET[c]", "M_15HPET[e]", "M_15HPET[n]", "M_15HPET[r]", "M_15HPET[x]")                                   
"S_15kprostgf2[c][e]".("M_15kprostgf2[c]", "M_15kprostgf2[e]")                                  
"S_1a25dhvitd2[c][e][m]".("M_1a25dhvitd2[c]", "M_1a25dhvitd2[e]", "M_1a25dhvitd2[m]")                                   
"S_1hibup_S[c][e][r]".("M_1hibup_S[c]", "M_1hibup_S[e]", "M_1hibup_S[r]")                                   
"S_1hibupglu_S[c][e][r]".("M_1hibupglu_S[c]", "M_1hibupglu_S[e]", "M_1hibupglu_S[r]")                                   
"S_1hmdgluc[c][e][r]".("M_1hmdgluc[c]", "M_1hmdgluc[e]", "M_1hmdgluc[r]")                                   
"S_1mncam[c][e]".("M_1mncam[c]", "M_1mncam[e]")                                 
"S_1ohmdz[c][e][r]".("M_1ohmdz[c]", "M_1ohmdz[e]", "M_1ohmdz[r]")                                   
"S_21hprgnlone[c][e]".("M_21hprgnlone[c]", "M_21hprgnlone[e]")                                  
"S_24nph[c][e]".("M_24nph[c]", "M_24nph[e]")                                    
"S_2h3mv[c][e]".("M_2h3mv[c]", "M_2h3mv[e]")                                    
"S_2hatvacid[c][e][r]".("M_2hatvacid[c]", "M_2hatvacid[e]", "M_2hatvacid[r]")                                   
"S_2hatvlac[c][e][r]".("M_2hatvlac[c]", "M_2hatvlac[e]", "M_2hatvlac[r]")                                   
"S_2hatvlacgluc[c][e][r]".("M_2hatvlacgluc[c]", "M_2hatvlacgluc[e]", "M_2hatvlacgluc[r]")                                   
"S_2hb[c][e]".("M_2hb[c]", "M_2hb[e]")                                  
"S_2hibup_R[c][e][r]".("M_2hibup_R[c]", "M_2hibup_R[e]", "M_2hibup_R[r]")                                   
"S_2hibup_S[c][e][r]".("M_2hibup_S[c]", "M_2hibup_S[e]", "M_2hibup_S[r]")                                   
"S_2hibupglu_S[c][e][r]".("M_2hibupglu_S[c]", "M_2hibupglu_S[e]", "M_2hibupglu_S[r]")                                   
"S_2hiv[c][e]".("M_2hiv[c]", "M_2hiv[e]")                                   
"S_2m3hbu[c][e][m]".("M_2m3hbu[c]", "M_2m3hbu[e]", "M_2m3hbu[m]")                                   
"S_2mcit[c][e]".("M_2mcit[c]", "M_2mcit[e]")                                    
"S_2obut[c][e][m]".("M_2obut[c]", "M_2obut[e]", "M_2obut[m]")                                   
"S_2oxoadp[c][e][m]".("M_2oxoadp[c]", "M_2oxoadp[e]", "M_2oxoadp[m]")                                   
"S_2pg[c][e]".("M_2pg[c]", "M_2pg[e]")                                  
"S_34dhoxmand[c][e][m]".("M_34dhoxmand[c]", "M_34dhoxmand[e]", "M_34dhoxmand[m]")                                   
"S_34dhoxpeg[c][e]".("M_34dhoxpeg[c]", "M_34dhoxpeg[e]")                                    
"S_34dhpe[c][e]".("M_34dhpe[c]", "M_34dhpe[e]")                                 
"S_34hpl[c][e][m]".("M_34hpl[c]", "M_34hpl[e]", "M_34hpl[m]")                                   
"S_34hpp[c][e]".("M_34hpp[c]", "M_34hpp[e]")                                    
"S_35cgmp[c][e][g][n]".("M_35cgmp[c]", "M_35cgmp[e]", "M_35cgmp[g]", "M_35cgmp[n]")                                 
"S_35diotyr[c][e]".("M_35diotyr[c]", "M_35diotyr[e]")                                   
"S_35dsmv[c][e][r]".("M_35dsmv[c]", "M_35dsmv[e]", "M_35dsmv[r]")                                   
"S_3aib[c][e][m]".("M_3aib[c]", "M_3aib[e]", "M_3aib[m]")                                   
"S_3aib_D[c][e][m]".("M_3aib_D[c]", "M_3aib_D[e]", "M_3aib_D[m]")                                   
"S_3bcrn[c][e]".("M_3bcrn[c]", "M_3bcrn[e]")                                    
"S_3ddcrn[c][e]".("M_3ddcrn[c]", "M_3ddcrn[e]")                                 
"S_3deccrn[c][e]".("M_3deccrn[c]", "M_3deccrn[e]")                                  
"S_3dhcdchol[c][e]".("M_3dhcdchol[c]", "M_3dhcdchol[e]")                                    
"S_3dhchol[c][e]".("M_3dhchol[c]", "M_3dhchol[e]")                                  
"S_3dhdchol[c][e]".("M_3dhdchol[c]", "M_3dhdchol[e]")                                   
"S_3dhlchol[c][e]".("M_3dhlchol[c]", "M_3dhlchol[e]")                                   
"S_3h3mglt[c][e]".("M_3h3mglt[c]", "M_3h3mglt[e]")                                  
"S_3hadpac[c][e][x]".("M_3hadpac[c]", "M_3hadpac[e]", "M_3hadpac[x]")                                   
"S_3hanthrn[c][e]".("M_3hanthrn[c]", "M_3hanthrn[e]")                                   
"S_3hibup_R[c][e][r]".("M_3hibup_R[c]", "M_3hibup_R[e]", "M_3hibup_R[r]")                                   
"S_3hibup_S[c][e][r]".("M_3hibup_S[c]", "M_3hibup_S[e]", "M_3hibup_S[r]")                                   
"S_3hibupglu_S[c][e][r]".("M_3hibupglu_S[c]", "M_3hibupglu_S[e]", "M_3hibupglu_S[r]")                                   
"S_3hivac[c][e][m]".("M_3hivac[c]", "M_3hivac[e]", "M_3hivac[m]")                                   
"S_3hlvstacid[c][e]".("M_3hlvstacid[c]", "M_3hlvstacid[e]")                                 
"S_3hmp[c][e][m]".("M_3hmp[c]", "M_3hmp[e]", "M_3hmp[m]")                                   
"S_3hpp[c][e][m]".("M_3hpp[c]", "M_3hpp[e]", "M_3hpp[m]")                                   
"S_3hpvs[c][e][r]".("M_3hpvs[c]", "M_3hpvs[e]", "M_3hpvs[r]")                                   
"S_3hpvstet[c][e]".("M_3hpvstet[c]", "M_3hpvstet[e]")                                   
"S_3hsmvacid[c][e]".("M_3hsmvacid[c]", "M_3hsmvacid[e]")                                    
"S_3ispvs[c][e]".("M_3ispvs[c]", "M_3ispvs[e]")                                 
"S_3ityr_L[c][e]".("M_3ityr_L[c]", "M_3ityr_L[e]")                                  
"S_3mglutac[c][e][m]".("M_3mglutac[c]", "M_3mglutac[e]", "M_3mglutac[m]")                                   
"S_3mhis[c][e]".("M_3mhis[c]", "M_3mhis[e]")                                    
"S_3mlda[c][e]".("M_3mlda[c]", "M_3mlda[e]")                                    
"S_3mob[c][e][m]".("M_3mob[c]", "M_3mob[e]", "M_3mob[m]")                                   
"S_3mop[c][e][m]".("M_3mop[c]", "M_3mop[e]", "M_3mop[m]")                                   
"S_3mox4hoxm[c][e][m]".("M_3mox4hoxm[c]", "M_3mox4hoxm[e]", "M_3mox4hoxm[m]")                                   
"S_3octdece1crn[c][e]".("M_3octdece1crn[c]", "M_3octdece1crn[e]")                                   
"S_3ohacmp[c][e][r]".("M_3ohacmp[c]", "M_3ohacmp[e]", "M_3ohacmp[r]")                                   
"S_3ohsebac[c][e][x]".("M_3ohsebac[c]", "M_3ohsebac[e]", "M_3ohsebac[x]")                                   
"S_3ohsubac[c][e][x]".("M_3ohsubac[c]", "M_3ohsubac[e]", "M_3ohsubac[x]")                                   
"S_3pg[c][e][m]".("M_3pg[c]", "M_3pg[e]", "M_3pg[m]")                                   
"S_3tdcrn[c][e]".("M_3tdcrn[c]", "M_3tdcrn[e]")                                 
"S_3uib[c][e]".("M_3uib[c]", "M_3uib[e]")                                   
"S_4abut[c][e][l][m]".("M_4abut[c]", "M_4abut[e]", "M_4abut[l]", "M_4abut[m]")                                  
"S_4abutn[c][e]".("M_4abutn[c]", "M_4abutn[e]")                                 
"S_4hatvacid[c][e][r]".("M_4hatvacid[c]", "M_4hatvacid[e]", "M_4hatvacid[r]")                                   
"S_4hatvlac[c][e][r]".("M_4hatvlac[c]", "M_4hatvlac[e]", "M_4hatvlac[r]")                                   
"S_4hbz[c][e][m]".("M_4hbz[c]", "M_4hbz[e]", "M_4hbz[m]")                                   
"S_4hmdgluc[c][e][r]".("M_4hmdgluc[c]", "M_4hmdgluc[e]", "M_4hmdgluc[r]")                                   
"S_4hpro_LT[c][e][m]".("M_4hpro_LT[c]", "M_4hpro_LT[e]", "M_4hpro_LT[m]")                                   
"S_4mop[c][e][m]".("M_4mop[c]", "M_4mop[e]", "M_4mop[m]")                                   
"S_4mptnl[c][e][m]".("M_4mptnl[c]", "M_4mptnl[e]", "M_4mptnl[m]")                                   
"S_4nph[c][e]".("M_4nph[c]", "M_4nph[e]")                                   
"S_4nphsf[c][e]".("M_4nphsf[c]", "M_4nphsf[e]")                                 
"S_4ohbut[c][e][m]".("M_4ohbut[c]", "M_4ohbut[e]", "M_4ohbut[m]")                                   
"S_4ohmdz[c][e][r]".("M_4ohmdz[c]", "M_4ohmdz[e]", "M_4ohmdz[r]")                                   
"S_4tmeabutn[c][e]".("M_4tmeabutn[c]", "M_4tmeabutn[e]")                                    
"S_56dhpvs[c][e]".("M_56dhpvs[c]", "M_56dhpvs[e]")                                  
"S_56dthm[c][e]".("M_56dthm[c]", "M_56dthm[e]")                                 
"S_56dura[c][e]".("M_56dura[c]", "M_56dura[e]")                                 
"S_56eppvs[c][e]".("M_56eppvs[c]", "M_56eppvs[e]")                                  
"S_5a2opntn[c][e][x]".("M_5a2opntn[c]", "M_5a2opntn[e]", "M_5a2opntn[x]")                                   
"S_5adtststerone[c][e]".("M_5adtststerone[c]", "M_5adtststerone[e]")                                    
"S_5adtststerones[c][e]".("M_5adtststerones[c]", "M_5adtststerones[e]")                                 
"S_5aop[c][e][m]".("M_5aop[c]", "M_5aop[e]", "M_5aop[m]")                                   
"S_5dhf[c][e][l][m]".("M_5dhf[c]", "M_5dhf[e]", "M_5dhf[l]", "M_5dhf[m]")                                   
"S_5eipenc[c][e][m]".("M_5eipenc[c]", "M_5eipenc[e]", "M_5eipenc[m]")                                   
"S_5fthf[c][e]".("M_5fthf[c]", "M_5fthf[e]")                                    
"S_5g2oxpt[c][e][x]".("M_5g2oxpt[c]", "M_5g2oxpt[e]", "M_5g2oxpt[x]")                                   
"S_5hoxindoa[c][e]".("M_5hoxindoa[c]", "M_5hoxindoa[e]")                                    
"S_5htrp[c][e]".("M_5htrp[c]", "M_5htrp[e]")                                    
"S_5mta[c][e]".("M_5mta[c]", "M_5mta[e]")                                   
"S_5mthf[c][e]".("M_5mthf[c]", "M_5mthf[e]")                                    
"S_5ohfvs[c][e][r]".("M_5ohfvs[c]", "M_5ohfvs[e]", "M_5ohfvs[r]")                                   
"S_5ohfvsglu[c][e][r]".("M_5ohfvsglu[c]", "M_5ohfvsglu[e]", "M_5ohfvsglu[r]")                                   
"S_5ohhexa[c][e]".("M_5ohhexa[c]", "M_5ohhexa[e]")                                  
"S_5thf[c][e][l][m]".("M_5thf[c]", "M_5thf[e]", "M_5thf[l]", "M_5thf[m]")                                   
"S_6bhglz[c][e][r]".("M_6bhglz[c]", "M_6bhglz[e]", "M_6bhglz[r]")                                   
"S_6csmvacid[c][e]".("M_6csmvacid[c]", "M_6csmvacid[e]")                                    
"S_6dhf[c][e][l][m]".("M_6dhf[c]", "M_6dhf[e]", "M_6dhf[l]", "M_6dhf[m]")                                   
"S_6epvs[c][e]".("M_6epvs[c]", "M_6epvs[e]")                                    
"S_6hlvst[c][e][r]".("M_6hlvst[c]", "M_6hlvst[e]", "M_6hlvst[r]")                                   
"S_6hmsmvacid[c][e]".("M_6hmsmvacid[c]", "M_6hmsmvacid[e]")                                 
"S_6hsmvacid[c][e]".("M_6hsmvacid[c]", "M_6hsmvacid[e]")                                    
"S_6htststerone[c][e][r]".("M_6htststerone[c]", "M_6htststerone[e]", "M_6htststerone[r]")                                   
"S_6melvacid[c][e][r]".("M_6melvacid[c]", "M_6melvacid[e]", "M_6melvacid[r]")                                   
"S_6melvst[c][e][r]".("M_6melvst[c]", "M_6melvst[e]", "M_6melvst[r]")                                   
"S_6ohfvsglu[c][e][r]".("M_6ohfvsglu[c]", "M_6ohfvsglu[e]", "M_6ohfvsglu[r]")                                   
"S_6thf[c][e][l][m]".("M_6thf[c]", "M_6thf[e]", "M_6thf[l]", "M_6thf[m]")                                   
"S_7bhglz[c][e][r]".("M_7bhglz[c]", "M_7bhglz[e]", "M_7bhglz[r]")                                   
"S_7dhcdchol[c][e]".("M_7dhcdchol[c]", "M_7dhcdchol[e]")                                    
"S_7dhchol[c][e]".("M_7dhchol[c]", "M_7dhchol[e]")                                  
"S_7dhchsterol[c][e][r]".("M_7dhchsterol[c]", "M_7dhchsterol[e]", "M_7dhchsterol[r]")                                   
"S_7dhf[c][e][l][m]".("M_7dhf[c]", "M_7dhf[e]", "M_7dhf[l]", "M_7dhf[m]")                                   
"S_7hpvs[c][e]".("M_7hpvs[c]", "M_7hpvs[e]")                                    
"S_7klitchol[c][e]".("M_7klitchol[c]", "M_7klitchol[e]")                                    
"S_7thf[c][e][l][m]".("M_7thf[c]", "M_7thf[e]", "M_7thf[l]", "M_7thf[m]")                                   
"S_aact[c][e][m]".("M_aact[c]", "M_aact[e]", "M_aact[m]")                                   
"S_abeta_L_lysine[c][e][n]".("M_abeta_L_lysine[c]", "M_abeta_L_lysine[e]", "M_abeta_L_lysine[n]")                                   
"S_ac[c][e][g][m][x]".("M_ac[c]", "M_ac[e]", "M_ac[g]", "M_ac[m]", "M_ac[x]")                                   
"S_acac[c][e][m][x]".("M_acac[c]", "M_acac[e]", "M_acac[m]", "M_acac[x]")                                   
"S_acald[c][e][m]".("M_acald[c]", "M_acald[e]", "M_acald[m]")                                   
"S_acetone[c][e][m]".("M_acetone[c]", "M_acetone[e]", "M_acetone[m]")                                   
"S_acgal[c][e][g][l]".("M_acgal[c]", "M_acgal[e]", "M_acgal[g]", "M_acgal[l]")                                  
"S_acgam[c][e][l]".("M_acgam[c]", "M_acgam[e]", "M_acgam[l]")                                   
"S_acglu[c][e][m]".("M_acglu[c]", "M_acglu[e]", "M_acglu[m]")                                   
"S_acgly[c][e][m]".("M_acgly[c]", "M_acgly[e]", "M_acgly[m]")                                   
"S_ach[c][e][n]".("M_ach[c]", "M_ach[e]", "M_ach[n]")                                   
"S_aclys[c][e]".("M_aclys[c]", "M_aclys[e]")                                    
"S_acmana[c][e][r]".("M_acmana[c]", "M_acmana[e]", "M_acmana[r]")                                   
"S_acmp[c][e][r]".("M_acmp[c]", "M_acmp[e]", "M_acmp[r]")                                   
"S_acnacngalgbside_hs[c][e][g]".("M_acnacngalgbside_hs[c]", "M_acnacngalgbside_hs[e]", "M_acnacngalgbside_hs[g]")                                   
"S_acnam[c][e][n]".("M_acnam[c]", "M_acnam[e]", "M_acnam[n]")                                   
"S_acngalacglcgal14acglcgalgluside_hs[c][e][g]".("M_acngalacglcgal14acglcgalgluside_hs[c]", "M_acngalacglcgal14acglcgalgluside_hs[e]", "M_acngalacglcgal14acglcgalgluside_hs[g]")                                   
"S_acrn[c][e][x]".("M_acrn[c]", "M_acrn[e]", "M_acrn[x]")                                   
"S_ade[c][e]".("M_ade[c]", "M_ade[e]")                                  
"S_adn[c][e][m]".("M_adn[c]", "M_adn[e]", "M_adn[m]")                                   
"S_adp[c][e][g][l][m][n][r]".("M_adp[c]", "M_adp[e]", "M_adp[g]", "M_adp[l]", "M_adp[m]", "M_adp[n]", "M_adp[r]")                                   
"S_adpac[c][e][x]".("M_adpac[c]", "M_adpac[e]", "M_adpac[x]")                                   
"S_adpman[c][e]".("M_adpman[c]", "M_adpman[e]")                                 
"S_adpoh[c][e]".("M_adpoh[c]", "M_adpoh[e]")                                    
"S_adprib[c][e]".("M_adprib[c]", "M_adprib[e]")                                 
"S_adrn[c][e][r]".("M_adrn[c]", "M_adrn[e]", "M_adrn[r]")                                   
"S_adrnl[c][e]".("M_adrnl[c]", "M_adrnl[e]")                                    
"S_aflatoxin[c][e]".("M_aflatoxin[c]", "M_aflatoxin[e]")                                    
"S_ahcys[c][e][m][r]".("M_ahcys[c]", "M_ahcys[e]", "M_ahcys[m]", "M_ahcys[r]")                                  
"S_aicar[c][e]".("M_aicar[c]", "M_aicar[e]")                                    
"S_ak2lgchol_hs[c][e]".("M_ak2lgchol_hs[c]", "M_ak2lgchol_hs[e]")                                   
"S_akg[c][e][m][x]".("M_akg[c]", "M_akg[e]", "M_akg[m]", "M_akg[x]")                                    
"S_ala_B[c][e][m]".("M_ala_B[c]", "M_ala_B[e]", "M_ala_B[m]")                                   
"S_ala_D[c][e][x]".("M_ala_D[c]", "M_ala_D[e]", "M_ala_D[x]")                                   
"S_ala_L[c][e][x]".("M_ala_L[c]", "M_ala_L[e]", "M_ala_L[x]")                                   
"S_aldstrn[c][e][m]".("M_aldstrn[c]", "M_aldstrn[e]", "M_aldstrn[m]")                                   
"S_alltn[c][e]".("M_alltn[c]", "M_alltn[e]")                                    
"S_am19cs[c][e][r]".("M_am19cs[c]", "M_am19cs[e]", "M_am19cs[r]")                                   
"S_am1csa[c][e][r]".("M_am1csa[c]", "M_am1csa[e]", "M_am1csa[r]")                                   
"S_am9csa[c][e][r]".("M_am9csa[c]", "M_am9csa[e]", "M_am9csa[r]")                                   
"S_amet[c][e][m][r]".("M_amet[c]", "M_amet[e]", "M_amet[m]", "M_amet[r]")                                   
"S_ametam[c][e]".("M_ametam[c]", "M_ametam[e]")                                 
"S_amp[c][e][g][m][n][r][x]".("M_amp[c]", "M_amp[e]", "M_amp[g]", "M_amp[m]", "M_amp[n]", "M_amp[r]", "M_amp[x]")                                   
"S_andrstandn[c][e][r]".("M_andrstandn[c]", "M_andrstandn[e]", "M_andrstandn[r]")                                   
"S_andrstrn[c][e][r]".("M_andrstrn[c]", "M_andrstrn[e]", "M_andrstrn[r]")                                   
"S_antipyrene[c][e]".("M_antipyrene[c]", "M_antipyrene[e]")                                 
"S_aprgstrn[c][e]".("M_aprgstrn[c]", "M_aprgstrn[e]")                                   
"S_aqcobal[c][e]".("M_aqcobal[c]", "M_aqcobal[e]")                                  
"S_arab_L[c][e]".("M_arab_L[c]", "M_arab_L[e]")                                 
"S_arach[c][e][r]".("M_arach[c]", "M_arach[e]", "M_arach[r]")                                   
"S_arachd[c][e][n][r][x]".("M_arachd[c]", "M_arachd[e]", "M_arachd[n]", "M_arachd[r]", "M_arachd[x]")                                   
"S_arg_D[c][e][x]".("M_arg_D[c]", "M_arg_D[e]", "M_arg_D[x]")                                   
"S_arg_L[c][e][m]".("M_arg_L[c]", "M_arg_L[e]", "M_arg_L[m]")                                   
"S_ascb_L[c][e]".("M_ascb_L[c]", "M_ascb_L[e]")                                 
"S_asn_L[c][e][m]".("M_asn_L[c]", "M_asn_L[e]", "M_asn_L[m]")                                   
"S_asp_D[c][e][x]".("M_asp_D[c]", "M_asp_D[e]", "M_asp_D[x]")                                   
"S_asp_L[c][e][m]".("M_asp_L[c]", "M_asp_L[e]", "M_asp_L[m]")                                   
"S_atp[c][e][g][l][m][n][r][x]".("M_atp[c]", "M_atp[e]", "M_atp[g]", "M_atp[l]", "M_atp[m]", "M_atp[n]", "M_atp[r]", "M_atp[x]")                                    
"S_atvacid[c][e][r]".("M_atvacid[c]", "M_atvacid[e]", "M_atvacid[r]")                                   
"S_atvlac[c][e][r]".("M_atvlac[c]", "M_atvlac[e]", "M_atvlac[r]")                                   
"S_avite1[c][e]".("M_avite1[c]", "M_avite1[e]")                                 
"S_bhb[c][e][m]".("M_bhb[c]", "M_bhb[e]", "M_bhb[m]")                                   
"S_bildglcur[c][e][r]".("M_bildglcur[c]", "M_bildglcur[e]", "M_bildglcur[r]")                                   
"S_bilglcur[c][e][r]".("M_bilglcur[c]", "M_bilglcur[e]", "M_bilglcur[r]")                                   
"S_bilirub[c][e][r]".("M_bilirub[c]", "M_bilirub[e]", "M_bilirub[r]")                                   
"S_biliverd[c][e]".("M_biliverd[c]", "M_biliverd[e]")                                   
"S_btn[c][e]".("M_btn[c]", "M_btn[e]")                                  
"S_but[c][e]".("M_but[c]", "M_but[e]")                                  
"S_bz[c][e][r]".("M_bz[c]", "M_bz[e]", "M_bz[r]")                                   
"S_C01601[c][e]".("M_C01601[c]", "M_C01601[e]")                                 
"S_C02470[c][e]".("M_C02470[c]", "M_C02470[e]")                                 
"S_C02528[c][e][r]".("M_C02528[c]", "M_C02528[e]", "M_C02528[r]")                                   
"S_C04717[c][e]".("M_C04717[c]", "M_C04717[e]")                                 
"S_C04805[c][e][m]".("M_C04805[c]", "M_C04805[e]", "M_C04805[m]")                                   
"S_C05300[c][e][r]".("M_C05300[c]", "M_C05300[e]", "M_C05300[r]")                                   
"S_C05767[c][e]".("M_C05767[c]", "M_C05767[e]")                                 
"S_C05770[c][e]".("M_C05770[c]", "M_C05770[e]")                                 
"S_C05957[c][e]".("M_C05957[c]", "M_C05957[e]")                                 
"S_C06314[c][e]".("M_C06314[c]", "M_C06314[e]")                                 
"S_C06315[c][e]".("M_C06315[c]", "M_C06315[e]")                                 
"S_c101crn[c][e]".("M_c101crn[c]", "M_c101crn[e]")                                  
"S_c10crn[c][e]".("M_c10crn[c]", "M_c10crn[e]")                                 
"S_C11695[c][e]".("M_C11695[c]", "M_C11695[e]")                                 
"S_c12dc[c][e]".("M_c12dc[c]", "M_c12dc[e]")                                    
"S_C13856[c][e]".("M_C13856[c]", "M_C13856[e]")                                 
"S_C14768[c][e]".("M_C14768[c]", "M_C14768[e]")                                 
"S_C14769[c][e]".("M_C14769[c]", "M_C14769[e]")                                 
"S_C14770[c][e]".("M_C14770[c]", "M_C14770[e]")                                 
"S_C14771[c][e]".("M_C14771[c]", "M_C14771[e]")                                 
"S_C14825[c][e]".("M_C14825[c]", "M_C14825[e]")                                 
"S_C14826[c][e]".("M_C14826[c]", "M_C14826[e]")                                 
"S_c16dc[c][e]".("M_c16dc[c]", "M_c16dc[e]")                                    
"S_c3dc[c][e]".("M_c3dc[c]", "M_c3dc[e]")                                   
"S_c4crn[c][e][x]".("M_c4crn[c]", "M_c4crn[e]", "M_c4crn[x]")                                   
"S_c4dc[c][e]".("M_c4dc[c]", "M_c4dc[e]")                                   
"S_c6crn[c][e]".("M_c6crn[c]", "M_c6crn[e]")                                    
"S_c81crn[c][e]".("M_c81crn[c]", "M_c81crn[e]")                                 
"S_c8crn[c][e]".("M_c8crn[c]", "M_c8crn[e]")                                    
"S_ca2[c][e]".("M_ca2[c]", "M_ca2[e]")                                  
"S_camp[c][e][g]".("M_camp[c]", "M_camp[e]", "M_camp[g]")                                   
"S_caproic[c][e]".("M_caproic[c]", "M_caproic[e]")                                  
"S_caribup_s[c][e][r]".("M_caribup_s[c]", "M_caribup_s[e]", "M_caribup_s[r]")                                   
"S_caribupglu_S[c][e][r]".("M_caribupglu_S[c]", "M_caribupglu_S[e]", "M_caribupglu_S[r]")                                   
"S_carn[c][e]".("M_carn[c]", "M_carn[e]")                                   
"S_caro[c][e]".("M_caro[c]", "M_caro[e]")                                   
"S_cbasp[c][e]".("M_cbasp[c]", "M_cbasp[e]")                                    
"S_cdca24g[c][e][r]".("M_cdca24g[c]", "M_cdca24g[e]", "M_cdca24g[r]")                                   
"S_cdca3g[c][e][r]".("M_cdca3g[c]", "M_cdca3g[e]", "M_cdca3g[r]")                                   
"S_cdp[c][e][m][n]".("M_cdp[c]", "M_cdp[e]", "M_cdp[m]", "M_cdp[n]")                                    
"S_cdpea[c][e]".("M_cdpea[c]", "M_cdpea[e]")                                    
"S_CE0074[c][e]".("M_CE0074[c]", "M_CE0074[e]")                                 
"S_CE1261[c][e]".("M_CE1261[c]", "M_CE1261[e]")                                 
"S_CE1273[c][e]".("M_CE1273[c]", "M_CE1273[e]")                                 
"S_CE1310[c][e][m]".("M_CE1310[c]", "M_CE1310[e]", "M_CE1310[m]")                                   
"S_CE1447[c][e]".("M_CE1447[c]", "M_CE1447[e]")                                 
"S_CE1918[c][e]".("M_CE1918[c]", "M_CE1918[e]")                                 
"S_CE2006[c][e]".("M_CE2006[c]", "M_CE2006[e]")                                 
"S_CE2047[c][e]".("M_CE2047[c]", "M_CE2047[e]")                                 
"S_CE2049[c][e]".("M_CE2049[c]", "M_CE2049[e]")                                 
"S_CE2172[c][e]".("M_CE2172[c]", "M_CE2172[e]")                                 
"S_CE2510[c][e][r]".("M_CE2510[c]", "M_CE2510[e]", "M_CE2510[r]")                                   
"S_CE2537[c][e]".("M_CE2537[c]", "M_CE2537[e]")                                 
"S_CE2705[c][e]".("M_CE2705[c]", "M_CE2705[e]")                                 
"S_CE2838[c][e]".("M_CE2838[c]", "M_CE2838[e]")                                 
"S_CE2839[c][e]".("M_CE2839[c]", "M_CE2839[e]")                                 
"S_CE4877[c][e]".("M_CE4877[c]", "M_CE4877[e]")                                 
"S_CE4969[c][e][m]".("M_CE4969[c]", "M_CE4969[e]", "M_CE4969[m]")                                   
"S_CE5025[c][e]".("M_CE5025[c]", "M_CE5025[e]")                                 
"S_CE5026[c][e]".("M_CE5026[c]", "M_CE5026[e]")                                 
"S_CE5304[c][e]".("M_CE5304[c]", "M_CE5304[e]")                                 
"S_CE5629[c][e]".("M_CE5629[c]", "M_CE5629[e]")                                 
"S_CE6205[c][e]".("M_CE6205[c]", "M_CE6205[e]")                                 
"S_CE6247[c][e]".("M_CE6247[c]", "M_CE6247[e]")                                 
"S_CE7081[c][e][r]".("M_CE7081[c]", "M_CE7081[e]", "M_CE7081[r]")                                   
"S_CE7085[c][e]".("M_CE7085[c]", "M_CE7085[e]")                                 
"S_CE7090[c][e]".("M_CE7090[c]", "M_CE7090[e]")                                 
"S_CE7096[c][e]".("M_CE7096[c]", "M_CE7096[e]")                                 
"S_CE7172[c][e]".("M_CE7172[c]", "M_CE7172[e]")                                 
"S_cgly[c][e]".("M_cgly[c]", "M_cgly[e]")                                   
"S_chol[c][e][n]".("M_chol[c]", "M_chol[e]", "M_chol[n]")                                   
"S_cholate[c][e][m][r][x]".("M_cholate[c]", "M_cholate[e]", "M_cholate[m]", "M_cholate[r]", "M_cholate[x]")                                 
"S_cholp[c][e][g][l]".("M_cholp[c]", "M_cholp[e]", "M_cholp[g]", "M_cholp[l]")                                  
"S_chsterol[c][e][g][m][r]".("M_chsterol[c]", "M_chsterol[e]", "M_chsterol[g]", "M_chsterol[m]", "M_chsterol[r]")                                   
"S_chsterols[c][e]".("M_chsterols[c]", "M_chsterols[e]")                                    
"S_chtn[c][e]".("M_chtn[c]", "M_chtn[e]")                                   
"S_cit[c][e][m]".("M_cit[c]", "M_cit[e]", "M_cit[m]")                                   
"S_citr_L[c][e]".("M_citr_L[c]", "M_citr_L[e]")                                 
"S_cl[c][e]".("M_cl[c]", "M_cl[e]")                                 
"S_clpnd[c][e][r]".("M_clpnd[c]", "M_clpnd[e]", "M_clpnd[r]")                                   
"S_cmp[c][e][g][m][n][r]".("M_cmp[c]", "M_cmp[e]", "M_cmp[g]", "M_cmp[m]", "M_cmp[n]", "M_cmp[r]")                                  
"S_co[c][e]".("M_co[c]", "M_co[e]")                                 
"S_co2[c][e][m][r][x]".("M_co2[c]", "M_co2[e]", "M_co2[m]", "M_co2[r]", "M_co2[x]")                                 
"S_coke[c][e][r]".("M_coke[c]", "M_coke[e]", "M_coke[r]")                                   
"S_coprost[c][e]".("M_coprost[c]", "M_coprost[e]")                                  
"S_core4[e][g]".("M_core4[e]", "M_core4[g]")                                    
"S_cortsn[c][e][r]".("M_cortsn[c]", "M_cortsn[e]", "M_cortsn[r]")                                   
"S_coumarin[c][e]".("M_coumarin[c]", "M_coumarin[e]")                                   
"S_creat[c][e]".("M_creat[c]", "M_creat[e]")                                    
"S_crm_hs[c][e][g][l][n][r]".("M_crm_hs[c]", "M_crm_hs[e]", "M_crm_hs[g]", "M_crm_hs[l]", "M_crm_hs[n]", "M_crm_hs[r]")                                 
"S_crmp_hs[c][e]".("M_crmp_hs[c]", "M_crmp_hs[e]")                                  
"S_crn[c][e][m][r][x]".("M_crn[c]", "M_crn[e]", "M_crn[m]", "M_crn[r]", "M_crn[x]")                                 
"S_crtsl[c][e][m][r]".("M_crtsl[c]", "M_crtsl[e]", "M_crtsl[m]", "M_crtsl[r]")                                  
"S_crtstrn[c][e][m]".("M_crtstrn[c]", "M_crtstrn[e]", "M_crtstrn[m]")                                   
"S_crvnc[c][e][r]".("M_crvnc[c]", "M_crvnc[e]", "M_crvnc[r]")                                   
"S_crvs[c][e][r]".("M_crvs[c]", "M_crvs[e]", "M_crvs[r]")                                   
"S_crvsm24[c][e][r]".("M_crvsm24[c]", "M_crvsm24[e]", "M_crvsm24[r]")                                   
"S_csa[c][e][r]".("M_csa[c]", "M_csa[e]", "M_csa[r]")                                   
"S_csn[c][e]".("M_csn[c]", "M_csn[e]")                                  
"S_cspg_a[e][g][l]".("M_cspg_a[e]", "M_cspg_a[g]", "M_cspg_a[l]")                                   
"S_cspg_c[e][g]".("M_cspg_c[e]", "M_cspg_c[g]")                                 
"S_cspg_d[e][g]".("M_cspg_d[e]", "M_cspg_d[g]")                                 
"S_cspg_e[e][g][l]".("M_cspg_e[e]", "M_cspg_e[g]", "M_cspg_e[l]")                                   
"S_ctp[c][e][m][n]".("M_ctp[c]", "M_ctp[e]", "M_ctp[m]", "M_ctp[n]")                                    
"S_cys_L[c][e][m]".("M_cys_L[c]", "M_cys_L[e]", "M_cys_L[m]")                                   
"S_cytd[c][e][m]".("M_cytd[c]", "M_cytd[e]", "M_cytd[m]")                                   
"S_dad_2[c][e]".("M_dad_2[c]", "M_dad_2[e]")                                    
"S_dag_hs[c][e][g][r]".("M_dag_hs[c]", "M_dag_hs[e]", "M_dag_hs[g]", "M_dag_hs[r]")                                 
"S_dca[c][e][r]".("M_dca[c]", "M_dca[e]", "M_dca[r]")                                   
"S_dchac[c][e]".("M_dchac[c]", "M_dchac[e]")                                    
"S_dcmp[c][e][m][n]".("M_dcmp[c]", "M_dcmp[e]", "M_dcmp[m]", "M_dcmp[n]")                                   
"S_dcsptn1[c][e][r]".("M_dcsptn1[c]", "M_dcsptn1[e]", "M_dcsptn1[r]")                                   
"S_dcyt[c][e][m][n]".("M_dcyt[c]", "M_dcyt[e]", "M_dcyt[m]", "M_dcyt[n]")                                   
"S_ddca[c][e][r]".("M_ddca[c]", "M_ddca[e]", "M_ddca[r]")                                   
"S_ddeccrn[c][e]".("M_ddeccrn[c]", "M_ddeccrn[e]")                                  
"S_ddece1crn[c][e]".("M_ddece1crn[c]", "M_ddece1crn[e]")                                    
"S_decdicrn[c][e]".("M_decdicrn[c]", "M_decdicrn[e]")                                   
"S_deoxfvs[c][e][x]".("M_deoxfvs[c]", "M_deoxfvs[e]", "M_deoxfvs[x]")                                   
"S_dgchol[c][e][x]".("M_dgchol[c]", "M_dgchol[e]", "M_dgchol[x]")                                   
"S_dgmp[c][e][m]".("M_dgmp[c]", "M_dgmp[e]", "M_dgmp[m]")                                   
"S_dgsn[c][e][m]".("M_dgsn[c]", "M_dgsn[e]", "M_dgsn[m]")                                   
"S_dgtp[c][e][m][n]".("M_dgtp[c]", "M_dgtp[e]", "M_dgtp[m]", "M_dgtp[n]")                                   
"S_dhap[c][e][m]".("M_dhap[c]", "M_dhap[e]", "M_dhap[m]")                                   
"S_dhbpt[c][e]".("M_dhbpt[c]", "M_dhbpt[e]")                                    
"S_dhcholestanate[c][e][r]".("M_dhcholestanate[c]", "M_dhcholestanate[e]", "M_dhcholestanate[r]")                                   
"S_dhdascb[c][e]".("M_dhdascb[c]", "M_dhdascb[e]")                                  
"S_dhea[c][e][r]".("M_dhea[c]", "M_dhea[e]", "M_dhea[r]")                                   
"S_dheas[c][e][r]".("M_dheas[c]", "M_dheas[e]", "M_dheas[r]")                                   
"S_dhf[c][e][l][m]".("M_dhf[c]", "M_dhf[e]", "M_dhf[l]", "M_dhf[m]")                                    
"S_din[c][e]".("M_din[c]", "M_din[e]")                                  
"S_ditp[c][e]".("M_ditp[c]", "M_ditp[e]")                                   
"S_dlnlcg[c][e][l][r]".("M_dlnlcg[c]", "M_dlnlcg[e]", "M_dlnlcg[l]", "M_dlnlcg[r]")                                 
"S_dmantipyrine[c][e]".("M_dmantipyrine[c]", "M_dmantipyrine[e]")                                   
"S_dmhptcrn[c][e][m]".("M_dmhptcrn[c]", "M_dmhptcrn[e]", "M_dmhptcrn[m]")                                   
"S_doco13ac[c][e][r]".("M_doco13ac[c]", "M_doco13ac[e]", "M_doco13ac[r]")                                   
"S_docosac[c][e][r]".("M_docosac[c]", "M_docosac[e]", "M_docosac[r]")                                   
"S_dodecanac[c][e]".("M_dodecanac[c]", "M_dodecanac[e]")                                    
"S_dolichol_L[c][e]".("M_dolichol_L[c]", "M_dolichol_L[e]")                                 
"S_dopa[c][e]".("M_dopa[c]", "M_dopa[e]")                                   
"S_dopa3glcur[c][e]".("M_dopa3glcur[c]", "M_dopa3glcur[e]")                                 
"S_dopa4glcur[c][e]".("M_dopa4glcur[c]", "M_dopa4glcur[e]")                                 
"S_dopasf[c][e]".("M_dopasf[c]", "M_dopasf[e]")                                 
"S_drib[c][e]".("M_drib[c]", "M_drib[e]")                                   
"S_dsmsterol[c][e][r]".("M_dsmsterol[c]", "M_dsmsterol[e]", "M_dsmsterol[r]")                                   
"S_dspvs[c][e]".("M_dspvs[c]", "M_dspvs[e]")                                    
"S_dtdp[c][e][m][n]".("M_dtdp[c]", "M_dtdp[e]", "M_dtdp[m]", "M_dtdp[n]")                                   
"S_dtmp[c][e][m]".("M_dtmp[c]", "M_dtmp[e]", "M_dtmp[m]")                                   
"S_dttp[c][e][m][n]".("M_dttp[c]", "M_dttp[e]", "M_dttp[m]", "M_dttp[n]")                                   
"S_duri[c][e][m]".("M_duri[c]", "M_duri[e]", "M_duri[m]")                                   
"S_dxtrn[c][e]".("M_dxtrn[c]", "M_dxtrn[e]")                                    
"S_eaflatoxin[c][e]".("M_eaflatoxin[c]", "M_eaflatoxin[e]")                                 
"S_ebastine[c][e][r]".("M_ebastine[c]", "M_ebastine[e]", "M_ebastine[r]")                                   
"S_ebastineoh[c][e][r]".("M_ebastineoh[c]", "M_ebastineoh[e]", "M_ebastineoh[r]")                                   
"S_egme[c][e][r]".("M_egme[c]", "M_egme[e]", "M_egme[r]")                                   
"S_eic21114tr[c][e]".("M_eic21114tr[c]", "M_eic21114tr[e]")                                 
"S_eicostet[c][e][r]".("M_eicostet[c]", "M_eicostet[e]", "M_eicostet[r]")                                   
"S_eidi1114ac[c][e]".("M_eidi1114ac[c]", "M_eidi1114ac[e]")                                 
"S_elaid[c][e][r]".("M_elaid[c]", "M_elaid[e]", "M_elaid[r]")                                   
"S_elaidcrn[c][e][m]".("M_elaidcrn[c]", "M_elaidcrn[e]", "M_elaidcrn[m]")                                   
"S_epoxtac[c][e][r]".("M_epoxtac[c]", "M_epoxtac[e]", "M_epoxtac[r]")                                   
"S_estradiol[c][e][r]".("M_estradiol[c]", "M_estradiol[e]", "M_estradiol[r]")                                   
"S_estriol[c][e][r]".("M_estriol[c]", "M_estriol[e]", "M_estriol[r]")                                   
"S_estrone[c][e][r]".("M_estrone[c]", "M_estrone[e]", "M_estrone[r]")                                   
"S_estrones[c][e][r]".("M_estrones[c]", "M_estrones[e]", "M_estrones[r]")                                   
"S_etha[c][e]".("M_etha[c]", "M_etha[e]")                                   
"S_ethamp[c][e][r]".("M_ethamp[c]", "M_ethamp[e]", "M_ethamp[r]")                                   
"S_ethmalac[c][e]".("M_ethmalac[c]", "M_ethmalac[e]")                                   
"S_etoh[c][e]".("M_etoh[c]", "M_etoh[e]")                                   
"S_f1a[e][g][l]".("M_f1a[e]", "M_f1a[g]", "M_f1a[l]")                                   
"S_fald[c][e][l]".("M_fald[c]", "M_fald[e]", "M_fald[l]")                                   
"S_fdp[c][e]".("M_fdp[c]", "M_fdp[e]")                                  
"S_fe2[c][e][m]".("M_fe2[c]", "M_fe2[e]", "M_fe2[m]")                                   
"S_fe3[c][e]".("M_fe3[c]", "M_fe3[e]")                                  
"S_fmn[c][e]".("M_fmn[c]", "M_fmn[e]")                                  
"S_fol[c][e][m]".("M_fol[c]", "M_fol[e]", "M_fol[m]")                                   
"S_for[c][e][m][r]".("M_for[c]", "M_for[e]", "M_for[m]", "M_for[r]")                                    
"S_forglu[c][e]".("M_forglu[c]", "M_forglu[e]")                                 
"S_fru[c][e]".("M_fru[c]", "M_fru[e]")                                  
"S_fuc_L[c][e][l]".("M_fuc_L[c]", "M_fuc_L[e]", "M_fuc_L[l]")                                   
"S_fuc13galacglcgal14acglcgalgluside_hs[c][e][g]".("M_fuc13galacglcgal14acglcgalgluside_hs[c]", "M_fuc13galacglcgal14acglcgalgluside_hs[e]", "M_fuc13galacglcgal14acglcgalgluside_hs[g]")                                   
"S_fuc14galacglcgalgluside_hs[c][e][g]".("M_fuc14galacglcgalgluside_hs[c]", "M_fuc14galacglcgalgluside_hs[e]", "M_fuc14galacglcgalgluside_hs[g]")                                   
"S_fucacgalfucgalacglcgalgluside_hs[c][e]".("M_fucacgalfucgalacglcgalgluside_hs[c]", "M_fucacgalfucgalacglcgalgluside_hs[e]")                                   
"S_fucfuc12gal14acglcgalgluside_hs[c][e][g]".("M_fucfuc12gal14acglcgalgluside_hs[c]", "M_fucfuc12gal14acglcgalgluside_hs[e]", "M_fucfuc12gal14acglcgalgluside_hs[g]")                                   
"S_fucfucfucgalacglc13galacglcgal14acglcgalgluside_hs[c][e][g]".("M_fucfucfucgalacglc13galacglcgal14acglcgalgluside_hs[c]", "M_fucfucfucgalacglc13galacglcgal14acglcgalgluside_hs[e]", "M_fucfucfucgalacglc13galacglcgal14acglcgalgluside_hs[g]")                                   
"S_fucfucgalacglcgalgluside_hs[c][e][g]".("M_fucfucgalacglcgalgluside_hs[c]", "M_fucfucgalacglcgalgluside_hs[e]", "M_fucfucgalacglcgalgluside_hs[g]")                                   
"S_fucgal14acglcgalgluside_hs[c][e][g]".("M_fucgal14acglcgalgluside_hs[c]", "M_fucgal14acglcgalgluside_hs[e]", "M_fucgal14acglcgalgluside_hs[g]")                                   
"S_fucgalfucgalacglcgalgluside_hs[c][e]".("M_fucgalfucgalacglcgalgluside_hs[c]", "M_fucgalfucgalacglcgalgluside_hs[e]")                                 
"S_fum[c][e][m]".("M_fum[c]", "M_fum[e]", "M_fum[m]")                                   
"S_fvs[c][e][r][x]".("M_fvs[c]", "M_fvs[e]", "M_fvs[r]", "M_fvs[x]")                                    
"S_g3pc[c][e]".("M_g3pc[c]", "M_g3pc[e]")                                   
"S_gal[c][e][l]".("M_gal[c]", "M_gal[e]", "M_gal[l]")                                   
"S_galacglcgalgbside_hs[c][e][g]".("M_galacglcgalgbside_hs[c]", "M_galacglcgalgbside_hs[e]", "M_galacglcgalgbside_hs[g]")                                   
"S_galgalfucfucgalacglcgalacglcgal14acglcgalgluside_hs[c][e][g]".("M_galgalfucfucgalacglcgalacglcgal14acglcgalgluside_hs[c]", "M_galgalfucfucgalacglcgalacglcgal14acglcgalgluside_hs[e]", "M_galgalfucfucgalacglcgalacglcgal14acglcgalgluside_hs[g]")                                   
"S_galgalgalthcrm_hs[c][e][g]".("M_galgalgalthcrm_hs[c]", "M_galgalgalthcrm_hs[e]", "M_galgalgalthcrm_hs[g]")                                   
"S_galgluside_hs[c][e][g][r]".("M_galgluside_hs[c]", "M_galgluside_hs[e]", "M_galgluside_hs[g]", "M_galgluside_hs[r]")                                  
"S_galt[c][e]".("M_galt[c]", "M_galt[e]")                                   
"S_gam[c][e]".("M_gam[c]", "M_gam[e]")                                  
"S_gbside_hs[c][e][g][l]".("M_gbside_hs[c]", "M_gbside_hs[e]", "M_gbside_hs[g]", "M_gbside_hs[l]")                                  
"S_gchola[c][e]".("M_gchola[c]", "M_gchola[e]")                                 
"S_gd3_hs[c][e][g][l][m]".("M_gd3_hs[c]", "M_gd3_hs[e]", "M_gd3_hs[g]", "M_gd3_hs[l]", "M_gd3_hs[m]")                                   
"S_gdp[c][e][g][m]".("M_gdp[c]", "M_gdp[e]", "M_gdp[g]", "M_gdp[m]")                                    
"S_glc_D[c][e][l][r]".("M_glc_D[c]", "M_glc_D[e]", "M_glc_D[l]", "M_glc_D[r]")                                  
"S_glc3meacp[c][e][r]".("M_glc3meacp[c]", "M_glc3meacp[e]", "M_glc3meacp[r]")                                   
"S_glcr[c][e]".("M_glcr[c]", "M_glcr[e]")                                   
"S_glcur[c][e][l][r]".("M_glcur[c]", "M_glcur[e]", "M_glcur[l]", "M_glcur[r]")                                  
"S_gln_L[c][e][m]".("M_gln_L[c]", "M_gln_L[e]", "M_gln_L[m]")                                   
"S_glu_L[c][e][l][m]".("M_glu_L[c]", "M_glu_L[e]", "M_glu_L[l]", "M_glu_L[m]")                                  
"S_gluside_hs[c][e][g][l][r]".("M_gluside_hs[c]", "M_gluside_hs[e]", "M_gluside_hs[g]", "M_gluside_hs[l]", "M_gluside_hs[r]")                                   
"S_glutcon[c][e][m]".("M_glutcon[c]", "M_glutcon[e]", "M_glutcon[m]")                                   
"S_glx[c][e][m][x]".("M_glx[c]", "M_glx[e]", "M_glx[m]", "M_glx[x]")                                    
"S_gly[c][e][m][x]".("M_gly[c]", "M_gly[e]", "M_gly[m]", "M_gly[x]")                                    
"S_glyald[c][e][m]".("M_glyald[c]", "M_glyald[e]", "M_glyald[m]")                                   
"S_glyc[c][e][m]".("M_glyc[c]", "M_glyc[e]", "M_glyc[m]")                                   
"S_glyc_R[c][e][m]".("M_glyc_R[c]", "M_glyc_R[e]", "M_glyc_R[m]")                                   
"S_glyc_S[c][e]".("M_glyc_S[c]", "M_glyc_S[e]")                                 
"S_glyc2p[c][e]".("M_glyc2p[c]", "M_glyc2p[e]")                                 
"S_glyc3p[c][e][m]".("M_glyc3p[c]", "M_glyc3p[e]", "M_glyc3p[m]")                                   
"S_glyclt[c][e][m][x]".("M_glyclt[c]", "M_glyclt[e]", "M_glyclt[m]", "M_glyclt[x]")                                 
"S_glygn2[c][e]".("M_glygn2[c]", "M_glygn2[e]")                                 
"S_glz[c][e][r]".("M_glz[c]", "M_glz[e]", "M_glz[r]")                                   
"S_gm1_hs[c][e][g][l][n]".("M_gm1_hs[c]", "M_gm1_hs[e]", "M_gm1_hs[g]", "M_gm1_hs[l]", "M_gm1_hs[n]")                                   
"S_gmp[c][e][g][n]".("M_gmp[c]", "M_gmp[e]", "M_gmp[g]", "M_gmp[n]")                                    
"S_gq1b_hs[c][e]".("M_gq1b_hs[c]", "M_gq1b_hs[e]")                                  
"S_gsn[c][e]".("M_gsn[c]", "M_gsn[e]")                                  
"S_gt1a_hs[c][e]".("M_gt1a_hs[c]", "M_gt1a_hs[e]")                                  
"S_gthox[c][e][m][r]".("M_gthox[c]", "M_gthox[e]", "M_gthox[m]", "M_gthox[r]")                                  
"S_gthrd[c][e][m][r]".("M_gthrd[c]", "M_gthrd[e]", "M_gthrd[m]", "M_gthrd[r]")                                  
"S_gtp[c][e][m]".("M_gtp[c]", "M_gtp[e]", "M_gtp[m]")                                   
"S_gua[c][e]".("M_gua[c]", "M_gua[e]")                                  
"S_gudac[c][e]".("M_gudac[c]", "M_gudac[e]")                                    
"S_h[c][e][g][i][l][m][n][r][x]".("M_h[c]", "M_h[e]", "M_h[g]", "M_h[i]", "M_h[l]", "M_h[m]", "M_h[n]", "M_h[r]", "M_h[x]")                                 
"S_h2o[c][e][g][l][m][n][r][x]".("M_h2o[c]", "M_h2o[e]", "M_h2o[g]", "M_h2o[l]", "M_h2o[m]", "M_h2o[n]", "M_h2o[r]", "M_h2o[x]")                                    
"S_h2o2[c][e][l][m][r][x]".("M_h2o2[c]", "M_h2o2[e]", "M_h2o2[l]", "M_h2o2[m]", "M_h2o2[r]", "M_h2o2[x]")                                   
"S_ha[e][l]".("M_ha[e]", "M_ha[l]")                                 
"S_ha_pre1[e][l]".("M_ha_pre1[e]", "M_ha_pre1[l]")                                  
"S_HC00900[c][e][m]".("M_HC00900[c]", "M_HC00900[e]", "M_HC00900[m]")                                   
"S_HC02020[c][e][r]".("M_HC02020[c]", "M_HC02020[e]", "M_HC02020[r]")                                   
"S_HC02180[c][e][r]".("M_HC02180[c]", "M_HC02180[e]", "M_HC02180[r]")                                   
"S_HC02187[c][e]".("M_HC02187[c]", "M_HC02187[e]")                                  
"S_HC02191[c][e][r]".("M_HC02191[c]", "M_HC02191[e]", "M_HC02191[r]")                                   
"S_HC02192[c][e]".("M_HC02192[c]", "M_HC02192[e]")                                  
"S_HC02193[c][e]".("M_HC02193[c]", "M_HC02193[e]")                                  
"S_HC02194[c][e]".("M_HC02194[c]", "M_HC02194[e]")                                  
"S_HC02195[c][e]".("M_HC02195[c]", "M_HC02195[e]")                                  
"S_HC02196[c][e]".("M_HC02196[c]", "M_HC02196[e]")                                  
"S_HC02197[c][e]".("M_HC02197[c]", "M_HC02197[e]")                                  
"S_HC02198[c][e]".("M_HC02198[c]", "M_HC02198[e]")                                  
"S_HC02202[c][e]".("M_HC02202[c]", "M_HC02202[e]")                                  
"S_HC02203[c][e]".("M_HC02203[c]", "M_HC02203[e]")                                  
"S_HC02204[c][e]".("M_HC02204[c]", "M_HC02204[e]")                                  
"S_HC02205[c][e]".("M_HC02205[c]", "M_HC02205[e]")                                  
"S_HC02206[c][e]".("M_HC02206[c]", "M_HC02206[e]")                                  
"S_HC02207[c][e]".("M_HC02207[c]", "M_HC02207[e]")                                  
"S_HC02208[c][e]".("M_HC02208[c]", "M_HC02208[e]")                                  
"S_HC02210[c][e]".("M_HC02210[c]", "M_HC02210[e]")                                  
"S_HC02213[c][e]".("M_HC02213[c]", "M_HC02213[e]")                                  
"S_HC02214[c][e]".("M_HC02214[c]", "M_HC02214[e]")                                  
"S_HC02216[c][e]".("M_HC02216[c]", "M_HC02216[e]")                                  
"S_HC02217[c][e][r]".("M_HC02217[c]", "M_HC02217[e]", "M_HC02217[r]")                                   
"S_HC02220[c][e]".("M_HC02220[c]", "M_HC02220[e]")                                  
"S_hca24g[c][e][r]".("M_hca24g[c]", "M_hca24g[e]", "M_hca24g[r]")                                   
"S_hco3[c][e][m]".("M_hco3[c]", "M_hco3[e]", "M_hco3[m]")                                   
"S_hcoumarin[c][e]".("M_hcoumarin[c]", "M_hcoumarin[e]")                                    
"S_hcys_L[c][e]".("M_hcys_L[c]", "M_hcys_L[e]")                                 
"S_hdca[c][e][l][r][x]".("M_hdca[c]", "M_hdca[e]", "M_hdca[l]", "M_hdca[r]", "M_hdca[x]")                                   
"S_hdca24g[c][e][r]".("M_hdca24g[c]", "M_hdca24g[e]", "M_hdca24g[r]")                                   
"S_hdca6g[c][e][r]".("M_hdca6g[c]", "M_hdca6g[e]", "M_hdca6g[r]")                                   
"S_hdcea[c][e][m][r]".("M_hdcea[c]", "M_hdcea[e]", "M_hdcea[m]", "M_hdcea[r]")                                  
"S_hdcecrn[c][e]".("M_hdcecrn[c]", "M_hdcecrn[e]")                                  
"S_hdd2crn[c][e][m]".("M_hdd2crn[c]", "M_hdd2crn[e]", "M_hdd2crn[m]")                                   
"S_hestratriol[c][e][l][r]".("M_hestratriol[c]", "M_hestratriol[e]", "M_hestratriol[l]", "M_hestratriol[r]")                                    
"S_hexc[c][e][r]".("M_hexc[c]", "M_hexc[e]", "M_hexc[r]")                                   
"S_hexdiac[c][e][r]".("M_hexdiac[c]", "M_hexdiac[e]", "M_hexdiac[r]")                                   
"S_hexgly[c][e]".("M_hexgly[c]", "M_hexgly[e]")                                 
"S_hgentis[c][e]".("M_hgentis[c]", "M_hgentis[e]")                                  
"S_his_L[c][e]".("M_his_L[c]", "M_his_L[e]")                                    
"S_hista[c][e]".("M_hista[c]", "M_hista[e]")                                    
"S_hmcr[c][e]".("M_hmcr[c]", "M_hmcr[e]")                                   
"S_hom_L[c][e]".("M_hom_L[c]", "M_hom_L[e]")                                    
"S_homoval[c][e][m]".("M_homoval[c]", "M_homoval[e]", "M_homoval[m]")                                   
"S_hpdca[c][e][r]".("M_hpdca[c]", "M_hpdca[e]", "M_hpdca[r]")                                   
"S_hspg[e][g][l]".("M_hspg[e]", "M_hspg[g]", "M_hspg[l]")                                   
"S_htaxol[c][e]".("M_htaxol[c]", "M_htaxol[e]")                                 
"S_hxa[c][e][m][x]".("M_hxa[c]", "M_hxa[e]", "M_hxa[m]", "M_hxa[x]")                                    
"S_hxan[c][e]".("M_hxan[c]", "M_hxan[e]")                                   
"S_hxcoa[c][e][m][x]".("M_hxcoa[c]", "M_hxcoa[e]", "M_hxcoa[m]", "M_hxcoa[x]")                                  
"S_hyochol[c][e][r]".("M_hyochol[c]", "M_hyochol[e]", "M_hyochol[r]")                                   
"S_i[c][e]".("M_i[c]", "M_i[e]")                                    
"S_ibup_R[c][e][r]".("M_ibup_R[c]", "M_ibup_R[e]", "M_ibup_R[r]")                                   
"S_ibup_S[c][e][r]".("M_ibup_S[c]", "M_ibup_S[e]", "M_ibup_S[r]")                                   
"S_ibupgluc[c][e][r]".("M_ibupgluc[c]", "M_ibupgluc[e]", "M_ibupgluc[r]")                                   
"S_icdchol[c][e]".("M_icdchol[c]", "M_icdchol[e]")                                  
"S_icit[c][e][m][x]".("M_icit[c]", "M_icit[e]", "M_icit[m]", "M_icit[x]")                                   
"S_idour[c][e][l]".("M_idour[c]", "M_idour[e]", "M_idour[l]")                                   
"S_idp[c][e][m]".("M_idp[c]", "M_idp[e]", "M_idp[m]")                                   
"S_IL6_L_lysine[c][e][n]".("M_IL6_L_lysine[c]", "M_IL6_L_lysine[e]", "M_IL6_L_lysine[n]")                                   
"S_ile_L[c][e]".("M_ile_L[c]", "M_ile_L[e]")                                    
"S_im4ac[c][e]".("M_im4ac[c]", "M_im4ac[e]")                                    
"S_imp[c][e]".("M_imp[c]", "M_imp[e]")                                  
"S_ind3ac[c][e][m]".("M_ind3ac[c]", "M_ind3ac[e]", "M_ind3ac[m]")                                   
"S_inost[c][e][r]".("M_inost[c]", "M_inost[e]", "M_inost[r]")                                   
"S_ins[c][e]".("M_ins[c]", "M_ins[e]")                                  
"S_isochol[c][e]".("M_isochol[c]", "M_isochol[e]")                                  
"S_isolvstacid[c][e]".("M_isolvstacid[c]", "M_isolvstacid[e]")                                  
"S_itacon[c][e][m]".("M_itacon[c]", "M_itacon[e]", "M_itacon[m]")                                   
"S_itp[c][e][m]".("M_itp[c]", "M_itp[e]", "M_itp[m]")                                   
"S_k[c][e][g]".("M_k[c]", "M_k[e]", "M_k[g]")                                   
"S_ksii_core2[e][g]".("M_ksii_core2[e]", "M_ksii_core2[g]")                                 
"S_ksii_core4[e][g]".("M_ksii_core4[e]", "M_ksii_core4[g]")                                 
"S_kynate[c][e]".("M_kynate[c]", "M_kynate[e]")                                 
"S_L2aadp[c][e][m]".("M_L2aadp[c]", "M_L2aadp[e]", "M_L2aadp[m]")                                   
"S_lac_D[c][e]".("M_lac_D[c]", "M_lac_D[e]")                                    
"S_lac_L[c][e][m][x]".("M_lac_L[c]", "M_lac_L[e]", "M_lac_L[m]", "M_lac_L[x]")                                  
"S_lanost[c][e][r]".("M_lanost[c]", "M_lanost[e]", "M_lanost[r]")                                   
"S_lca24g[c][e][r]".("M_lca24g[c]", "M_lca24g[e]", "M_lca24g[r]")                                   
"S_lca3g[c][e][r]".("M_lca3g[c]", "M_lca3g[e]", "M_lca3g[r]")                                   
"S_Lcyst[c][e]".("M_Lcyst[c]", "M_Lcyst[e]")                                    
"S_Lcystin[c][e]".("M_Lcystin[c]", "M_Lcystin[e]")                                  
"S_leu_L[c][e]".("M_leu_L[c]", "M_leu_L[e]")                                    
"S_leuktrA4[c][e]".("M_leuktrA4[c]", "M_leuktrA4[e]")                                   
"S_leuktrB4[c][e][m][r][x]".("M_leuktrB4[c]", "M_leuktrB4[e]", "M_leuktrB4[m]", "M_leuktrB4[r]", "M_leuktrB4[x]")                                   
"S_leuktrB4wcooh[c][e][m][r][x]".("M_leuktrB4wcooh[c]", "M_leuktrB4wcooh[e]", "M_leuktrB4wcooh[m]", "M_leuktrB4wcooh[r]", "M_leuktrB4wcooh[x]")                                 
"S_leuktrB4woh[c][e][m][r]".("M_leuktrB4woh[c]", "M_leuktrB4woh[e]", "M_leuktrB4woh[m]", "M_leuktrB4woh[r]")                                    
"S_leuktrC4[c][e]".("M_leuktrC4[c]", "M_leuktrC4[e]")                                   
"S_leuktrD4[c][e]".("M_leuktrD4[c]", "M_leuktrD4[e]")                                   
"S_leuktrE4[c][e]".("M_leuktrE4[c]", "M_leuktrE4[e]")                                   
"S_leuktrF4[c][e]".("M_leuktrF4[c]", "M_leuktrF4[e]")                                   
"S_lgnc[c][e][r]".("M_lgnc[c]", "M_lgnc[e]", "M_lgnc[r]")                                   
"S_Lhcystin[c][e]".("M_Lhcystin[c]", "M_Lhcystin[e]")                                   
"S_Lkynr[c][e]".("M_Lkynr[c]", "M_Lkynr[e]")                                    
"S_lneldc[c][e][r]".("M_lneldc[c]", "M_lneldc[e]", "M_lneldc[r]")                                   
"S_lneldccrn[c][e][m]".("M_lneldccrn[c]", "M_lneldccrn[e]", "M_lneldccrn[m]")                                   
"S_lnlc[c][e][l][r]".("M_lnlc[c]", "M_lnlc[e]", "M_lnlc[l]", "M_lnlc[r]")                                   
"S_lnlccrn[c][e][m][x]".("M_lnlccrn[c]", "M_lnlccrn[e]", "M_lnlccrn[m]", "M_lnlccrn[x]")                                    
"S_lnlnca[c][e][l][r]".("M_lnlnca[c]", "M_lnlnca[e]", "M_lnlnca[l]", "M_lnlnca[r]")                                 
"S_lnlncg[c][e][l][r]".("M_lnlncg[c]", "M_lnlncg[e]", "M_lnlncg[l]", "M_lnlncg[r]")                                 
"S_lpchol_hs[c][e]".("M_lpchol_hs[c]", "M_lpchol_hs[e]")                                    
"S_lstn[c][e][r]".("M_lstn[c]", "M_lstn[e]", "M_lstn[r]")                                   
"S_lstnm7[c][e][r]".("M_lstnm7[c]", "M_lstnm7[e]", "M_lstnm7[r]")                                   
"S_lthstrl[c][e][r]".("M_lthstrl[c]", "M_lthstrl[e]", "M_lthstrl[r]")                                   
"S_lvst[c][e][r]".("M_lvst[c]", "M_lvst[e]", "M_lvst[r]")                                   
"S_lys_L[c][e]".("M_lys_L[c]", "M_lys_L[e]")                                    
"S_M00003[c][e][r]".("M_M00003[c]", "M_M00003[e]", "M_M00003[r]")                                   
"S_M00008[c][e][r]".("M_M00008[c]", "M_M00008[e]", "M_M00008[r]")                                   
"S_M00010[c][e][r]".("M_M00010[c]", "M_M00010[e]", "M_M00010[r]")                                   
"S_M00017[c][e][r]".("M_M00017[c]", "M_M00017[e]", "M_M00017[r]")                                   
"S_M00019[c][e][r]".("M_M00019[c]", "M_M00019[e]", "M_M00019[r]")                                   
"S_M00021[c][e][r]".("M_M00021[c]", "M_M00021[e]", "M_M00021[r]")                                   
"S_M00115[c][e]".("M_M00115[c]", "M_M00115[e]")                                 
"S_M00117[c][e][r]".("M_M00117[c]", "M_M00117[e]", "M_M00117[r]")                                   
"S_M00260[c][e]".("M_M00260[c]", "M_M00260[e]")                                 
"S_M00265[c][e]".("M_M00265[c]", "M_M00265[e]")                                 
"S_M00315[c][e]".("M_M00315[c]", "M_M00315[e]")                                 
"S_M00341[c][e][r]".("M_M00341[c]", "M_M00341[e]", "M_M00341[r]")                                   
"S_M01197[c][e][r]".("M_M01197[c]", "M_M01197[e]", "M_M01197[r]")                                   
"S_M01207[c][e][r]".("M_M01207[c]", "M_M01207[e]", "M_M01207[r]")                                   
"S_M01235[c][e][r]".("M_M01235[c]", "M_M01235[e]", "M_M01235[r]")                                   
"S_M01238[c][e][r]".("M_M01238[c]", "M_M01238[e]", "M_M01238[r]")                                   
"S_M01582[c][e][r]".("M_M01582[c]", "M_M01582[e]", "M_M01582[r]")                                   
"S_M01870[e][g]".("M_M01870[e]", "M_M01870[g]")                                 
"S_M01881[c][e]".("M_M01881[c]", "M_M01881[e]")                                 
"S_M01989[c][e]".("M_M01989[c]", "M_M01989[e]")                                 
"S_M02053[c][e][r]".("M_M02053[c]", "M_M02053[e]", "M_M02053[r]")                                   
"S_M02108[c][e]".("M_M02108[c]", "M_M02108[e]")                                 
"S_M02155[c][e][r]".("M_M02155[c]", "M_M02155[e]", "M_M02155[r]")                                   
"S_M02446[c][e]".("M_M02446[c]", "M_M02446[e]")                                 
"S_M02447[c][e]".("M_M02447[c]", "M_M02447[e]")                                 
"S_M02449[c][e]".("M_M02449[c]", "M_M02449[e]")                                 
"S_M02451[c][e]".("M_M02451[c]", "M_M02451[e]")                                 
"S_M02457[c][e][r]".("M_M02457[c]", "M_M02457[e]", "M_M02457[r]")                                   
"S_M02613[c][e][r]".("M_M02613[c]", "M_M02613[e]", "M_M02613[r]")                                   
"S_M02745[c][e][r]".("M_M02745[c]", "M_M02745[e]", "M_M02745[r]")                                   
"S_M03045[c][e][r]".("M_M03045[c]", "M_M03045[e]", "M_M03045[r]")                                   
"S_M03051[c][e][r]".("M_M03051[c]", "M_M03051[e]", "M_M03051[r]")                                   
"S_M03117[c][e]".("M_M03117[c]", "M_M03117[e]")                                 
"S_M03131[c][e]".("M_M03131[c]", "M_M03131[e]")                                 
"S_M03134[c][e]".("M_M03134[c]", "M_M03134[e]")                                 
"S_M03153[c][e][r]".("M_M03153[c]", "M_M03153[e]", "M_M03153[r]")                                   
"S_mag_hs[c][e]".("M_mag_hs[c]", "M_mag_hs[e]")                                 
"S_mal_L[c][e][m][x]".("M_mal_L[c]", "M_mal_L[e]", "M_mal_L[m]", "M_mal_L[x]")                                  
"S_malt[c][e]".("M_malt[c]", "M_malt[e]")                                   
"S_malttr[c][e]".("M_malttr[c]", "M_malttr[e]")                                 
"S_maltttr[c][e]".("M_maltttr[c]", "M_maltttr[e]")                                  
"S_man[c][e][l]".("M_man[c]", "M_man[e]", "M_man[l]")                                   
"S_mdz[c][e][r]".("M_mdz[c]", "M_mdz[e]", "M_mdz[r]")                                   
"S_meoh[c][e][l]".("M_meoh[c]", "M_meoh[e]", "M_meoh[l]")                                   
"S_mepi[c][e]".("M_mepi[c]", "M_mepi[e]")                                   
"S_met_L[c][e][m]".("M_met_L[c]", "M_met_L[e]", "M_met_L[m]")                                   
"S_mev_R[c][e]".("M_mev_R[c]", "M_mev_R[e]")                                    
"S_mhglz[c][e][r]".("M_mhglz[c]", "M_mhglz[e]", "M_mhglz[r]")                                   
"S_mhista[c][e]".("M_mhista[c]", "M_mhista[e]")                                 
"S_mi1p_D[c][e]".("M_mi1p_D[c]", "M_mi1p_D[e]")                                 
"S_mlthf[c][e][m]".("M_mlthf[c]", "M_mlthf[e]", "M_mlthf[m]")                                   
"S_mma[c][e]".("M_mma[c]", "M_mma[e]")                                  
"S_mthgxl[c][e]".("M_mthgxl[c]", "M_mthgxl[e]")                                 
"S_n2m2nmasn[e][l]".("M_n2m2nmasn[e]", "M_n2m2nmasn[l]")                                    
"S_n5m2masn[c][e][g]".("M_n5m2masn[c]", "M_n5m2masn[e]", "M_n5m2masn[g]")                                   
"S_na1[c][e][g]".("M_na1[c]", "M_na1[e]", "M_na1[g]")                                   
"S_nac[c][e]".("M_nac[c]", "M_nac[e]")                                  
"S_nad[c][e][m][n][r][x]".("M_nad[c]", "M_nad[e]", "M_nad[m]", "M_nad[n]", "M_nad[r]", "M_nad[x]")                                  
"S_nadh[c][e][m][r][x]".("M_nadh[c]", "M_nadh[e]", "M_nadh[m]", "M_nadh[r]", "M_nadh[x]")                                   
"S_nadp[c][e][m][r][x]".("M_nadp[c]", "M_nadp[e]", "M_nadp[m]", "M_nadp[r]", "M_nadp[x]")                                   
"S_ncam[c][e]".("M_ncam[c]", "M_ncam[e]")                                   
"S_nfdac[c][e][r]".("M_nfdac[c]", "M_nfdac[e]", "M_nfdac[r]")                                   
"S_nfdoh[c][e][r]".("M_nfdoh[c]", "M_nfdoh[e]", "M_nfdoh[r]")                                   
"S_nh4[c][e][m][n][r][x]".("M_nh4[c]", "M_nh4[e]", "M_nh4[m]", "M_nh4[n]", "M_nh4[r]", "M_nh4[x]")                                  
"S_nicrnt[c][e][n]".("M_nicrnt[c]", "M_nicrnt[e]", "M_nicrnt[n]")                                   
"S_no[c][e]".("M_no[c]", "M_no[e]")                                 
"S_normete_L[c][e]".("M_normete_L[c]", "M_normete_L[e]")                                    
"S_nrpphr[c][e]".("M_nrpphr[c]", "M_nrpphr[e]")                                 
"S_nrpphrsf[c][e]".("M_nrpphrsf[c]", "M_nrpphrsf[e]")                                   
"S_nrvnc[c][e][r]".("M_nrvnc[c]", "M_nrvnc[e]", "M_nrvnc[r]")                                   
"S_nwharg[c][e]".("M_nwharg[c]", "M_nwharg[e]")                                 
"S_o2[c][e][m][n][r][x]".("M_o2[c]", "M_o2[e]", "M_o2[m]", "M_o2[n]", "M_o2[r]", "M_o2[x]")                                 
"S_o2s[c][e][m]".("M_o2s[c]", "M_o2s[e]", "M_o2s[m]")                                   
"S_oaa[c][e][m][x]".("M_oaa[c]", "M_oaa[e]", "M_oaa[m]", "M_oaa[x]")                                    
"S_oagd3_hs[c][e][g]".("M_oagd3_hs[c]", "M_oagd3_hs[e]", "M_oagd3_hs[g]")                                   
"S_ocdca[c][e][r]".("M_ocdca[c]", "M_ocdca[e]", "M_ocdca[r]")                                   
"S_ocdcea[c][e][l][r]".("M_ocdcea[c]", "M_ocdcea[e]", "M_ocdcea[l]", "M_ocdcea[r]")                                 
"S_octa[c][e]".("M_octa[c]", "M_octa[e]")                                   
"S_odecrn[c][e][m][r]".("M_odecrn[c]", "M_odecrn[e]", "M_odecrn[m]", "M_odecrn[r]")                                 
"S_oh1[c][e]".("M_oh1[c]", "M_oh1[e]")                                  
"S_orn[c][e][m]".("M_orn[c]", "M_orn[e]", "M_orn[m]")                                   
"S_orn_D[c][e][x]".("M_orn_D[c]", "M_orn_D[e]", "M_orn_D[x]")                                   
"S_orot[c][e]".("M_orot[c]", "M_orot[e]")                                   
"S_orot5p[c][e]".("M_orot5p[c]", "M_orot5p[e]")                                 
"S_oxa[c][e][x]".("M_oxa[c]", "M_oxa[e]", "M_oxa[x]")                                   
"S_oxyp[c][e]".("M_oxyp[c]", "M_oxyp[e]")                                   
"S_pa_hs[c][e][m][r]".("M_pa_hs[c]", "M_pa_hs[e]", "M_pa_hs[m]", "M_pa_hs[r]")                                  
"S_pac[c][e][m]".("M_pac[c]", "M_pac[e]", "M_pac[m]")                                   
"S_paf_hs[c][e]".("M_paf_hs[c]", "M_paf_hs[e]")                                 
"S_pail_hs[c][e][n][r]".("M_pail_hs[c]", "M_pail_hs[e]", "M_pail_hs[n]", "M_pail_hs[r]")                                    
"S_pailar_hs[c][e]".("M_pailar_hs[c]", "M_pailar_hs[e]")                                    
"S_pailpalm_hs[c][e]".("M_pailpalm_hs[c]", "M_pailpalm_hs[e]")                                  
"S_pchol_hs[c][e][g][r]".("M_pchol_hs[c]", "M_pchol_hs[e]", "M_pchol_hs[g]", "M_pchol_hs[r]")                                   
"S_pchol2linl_hs[c][e]".("M_pchol2linl_hs[c]", "M_pchol2linl_hs[e]")                                    
"S_pchol2ole_hs[c][e]".("M_pchol2ole_hs[c]", "M_pchol2ole_hs[e]")                                   
"S_pchol2palm_hs[c][e]".("M_pchol2palm_hs[c]", "M_pchol2palm_hs[e]")                                    
"S_pchol2ste_hs[c][e]".("M_pchol2ste_hs[c]", "M_pchol2ste_hs[e]")                                   
"S_pcholar_hs[c][e]".("M_pcholar_hs[c]", "M_pcholar_hs[e]")                                 
"S_pcholdoc_hs[c][e]".("M_pcholdoc_hs[c]", "M_pcholdoc_hs[e]")                                  
"S_pcholeic_hs[c][e]".("M_pcholeic_hs[c]", "M_pcholeic_hs[e]")                                  
"S_pcholet_hs[c][e]".("M_pcholet_hs[c]", "M_pcholet_hs[e]")                                 
"S_pcholhep_hs[c][e]".("M_pcholhep_hs[c]", "M_pcholhep_hs[e]")                                  
"S_pchollinl_hs[c][e]".("M_pchollinl_hs[c]", "M_pchollinl_hs[e]")                                   
"S_pcholmyr_hs[c][e]".("M_pcholmyr_hs[c]", "M_pcholmyr_hs[e]")                                  
"S_pcholn15_hs[c][e]".("M_pcholn15_hs[c]", "M_pcholn15_hs[e]")                                  
"S_pcholn183_hs[c][e]".("M_pcholn183_hs[c]", "M_pcholn183_hs[e]")                                   
"S_pcholn1836_hs[c][e]".("M_pcholn1836_hs[c]", "M_pcholn1836_hs[e]")                                    
"S_pcholn19_hs[c][e]".("M_pcholn19_hs[c]", "M_pcholn19_hs[e]")                                  
"S_pcholn201_hs[c][e]".("M_pcholn201_hs[c]", "M_pcholn201_hs[e]")                                   
"S_pcholn203_hs[c][e]".("M_pcholn203_hs[c]", "M_pcholn203_hs[e]")                                   
"S_pcholn204_hs[c][e]".("M_pcholn204_hs[c]", "M_pcholn204_hs[e]")                                   
"S_pcholn205_hs[c][e]".("M_pcholn205_hs[c]", "M_pcholn205_hs[e]")                                   
"S_pcholn224_hs[c][e]".("M_pcholn224_hs[c]", "M_pcholn224_hs[e]")                                   
"S_pcholn225_hs[c][e]".("M_pcholn225_hs[c]", "M_pcholn225_hs[e]")                                   
"S_pcholn2254_hs[c][e]".("M_pcholn2254_hs[c]", "M_pcholn2254_hs[e]")                                    
"S_pcholn226_hs[c][e]".("M_pcholn226_hs[c]", "M_pcholn226_hs[e]")                                   
"S_pcholn24_hs[c][e]".("M_pcholn24_hs[c]", "M_pcholn24_hs[e]")                                  
"S_pcholn261_hs[c][e]".("M_pcholn261_hs[c]", "M_pcholn261_hs[e]")                                   
"S_pcholn28_hs[c][e]".("M_pcholn28_hs[c]", "M_pcholn28_hs[e]")                                  
"S_pcholn281_hs[c][e]".("M_pcholn281_hs[c]", "M_pcholn281_hs[e]")                                   
"S_pcholole_hs[c][e]".("M_pcholole_hs[c]", "M_pcholole_hs[e]")                                  
"S_pcholpalm_hs[c][e]".("M_pcholpalm_hs[c]", "M_pcholpalm_hs[e]")                                   
"S_pcholpalme_hs[c][e]".("M_pcholpalme_hs[c]", "M_pcholpalme_hs[e]")                                    
"S_pcholste_hs[c][e]".("M_pcholste_hs[c]", "M_pcholste_hs[e]")                                  
"S_pcollg5hlys[c][e]".("M_pcollg5hlys[c]", "M_pcollg5hlys[e]")                                  
"S_pcrn[c][e][x]".("M_pcrn[c]", "M_pcrn[e]", "M_pcrn[x]")                                   
"S_pe_hs[c][e][r]".("M_pe_hs[c]", "M_pe_hs[e]", "M_pe_hs[r]")                                   
"S_pe12_hs[c][e]".("M_pe12_hs[c]", "M_pe12_hs[e]")                                  
"S_pe13_hs[c][e]".("M_pe13_hs[c]", "M_pe13_hs[e]")                                  
"S_pe14_hs[c][e]".("M_pe14_hs[c]", "M_pe14_hs[e]")                                  
"S_pe15_hs[c][e]".("M_pe15_hs[c]", "M_pe15_hs[e]")                                  
"S_pe161_hs[c][e]".("M_pe161_hs[c]", "M_pe161_hs[e]")                                   
"S_pe17_hs[c][e]".("M_pe17_hs[c]", "M_pe17_hs[e]")                                  
"S_pe203_hs[c][e]".("M_pe203_hs[c]", "M_pe203_hs[e]")                                   
"S_pe224_hs[c][e]".("M_pe224_hs[c]", "M_pe224_hs[e]")                                   
"S_pe226_hs[c][e]".("M_pe226_hs[c]", "M_pe226_hs[e]")                                   
"S_pe2linl_hs[c][e]".("M_pe2linl_hs[c]", "M_pe2linl_hs[e]")                                 
"S_pear_hs[c][e]".("M_pear_hs[c]", "M_pear_hs[e]")                                  
"S_pedh203_hs[c][e]".("M_pedh203_hs[c]", "M_pedh203_hs[e]")                                 
"S_pelinl_hs[c][e]".("M_pelinl_hs[c]", "M_pelinl_hs[e]")                                    
"S_peole_hs[c][e]".("M_peole_hs[c]", "M_peole_hs[e]")                                   
"S_pep[c][e]".("M_pep[c]", "M_pep[e]")                                  
"S_pepalm_hs[c][e]".("M_pepalm_hs[c]", "M_pepalm_hs[e]")                                    
"S_peplys[c][e]".("M_peplys[c]", "M_peplys[e]")                                 
"S_peptide[c][e]".("M_peptide[c]", "M_peptide[e]")                                  
"S_peste_hs[c][e]".("M_peste_hs[c]", "M_peste_hs[e]")                                   
"S_pglyc_hs[c][e]".("M_pglyc_hs[c]", "M_pglyc_hs[e]")                                   
"S_phe_L[c][e][m]".("M_phe_L[c]", "M_phe_L[e]", "M_phe_L[m]")                                   
"S_pheacgly[c][e][m]".("M_pheacgly[c]", "M_pheacgly[e]", "M_pheacgly[m]")                                   
"S_pheme[c][e][m]".("M_pheme[c]", "M_pheme[e]", "M_pheme[m]")                                   
"S_phlac[c][e]".("M_phlac[c]", "M_phlac[e]")                                    
"S_phpyr[c][e]".("M_phpyr[c]", "M_phpyr[e]")                                    
"S_phyt[c][e][x]".("M_phyt[c]", "M_phyt[e]", "M_phyt[x]")                                   
"S_pi[c][e][g][l][m][n][r]".("M_pi[c]", "M_pi[e]", "M_pi[g]", "M_pi[l]", "M_pi[m]", "M_pi[n]", "M_pi[r]")                                   
"S_pmtcrn[c][e][m]".("M_pmtcrn[c]", "M_pmtcrn[e]", "M_pmtcrn[m]")                                   
"S_pnto_R[c][e]".("M_pnto_R[c]", "M_pnto_R[e]")                                 
"S_ppa[c][e][m]".("M_ppa[c]", "M_ppa[e]", "M_ppa[m]")                                   
"S_ppbng[c][e]".("M_ppbng[c]", "M_ppbng[e]")                                    
"S_ppi[c][e][m][n][r][x]".("M_ppi[c]", "M_ppi[e]", "M_ppi[m]", "M_ppi[n]", "M_ppi[r]", "M_ppi[x]")                                  
"S_ppiogly[c][e][m]".("M_ppiogly[c]", "M_ppiogly[e]", "M_ppiogly[m]")                                   
"S_prgstrn[c][e][r]".("M_prgstrn[c]", "M_prgstrn[e]", "M_prgstrn[r]")                                   
"S_prist[c][e][x]".("M_prist[c]", "M_prist[e]", "M_prist[x]")                                   
"S_pro_D[c][e]".("M_pro_D[c]", "M_pro_D[e]")                                    
"S_pro_L[c][e][m]".("M_pro_L[c]", "M_pro_L[e]", "M_pro_L[m]")                                   
"S_profvs[c][e]".("M_profvs[c]", "M_profvs[e]")                                 
"S_prostgd2[c][e]".("M_prostgd2[c]", "M_prostgd2[e]")                                   
"S_prostge1[c][e]".("M_prostge1[c]", "M_prostge1[e]")                                   
"S_prostge2[c][e][r]".("M_prostge2[c]", "M_prostge2[e]", "M_prostge2[r]")                                   
"S_prostgf2[c][e]".("M_prostgf2[c]", "M_prostgf2[e]")                                   
"S_prostgh2[c][e][r]".("M_prostgh2[c]", "M_prostgh2[e]", "M_prostgh2[r]")                                   
"S_prostgi2[c][e]".("M_prostgi2[c]", "M_prostgi2[e]")                                   
"S_ps_hs[c][e]".("M_ps_hs[c]", "M_ps_hs[e]")                                    
"S_pser_L[c][e]".("M_pser_L[c]", "M_pser_L[e]")                                 
"S_ptdca[c][e][r]".("M_ptdca[c]", "M_ptdca[e]", "M_ptdca[r]")                                   
"S_ptrc[c][e]".("M_ptrc[c]", "M_ptrc[e]")                                   
"S_ptth[c][e][m]".("M_ptth[c]", "M_ptth[e]", "M_ptth[m]")                                   
"S_ptvst[c][e][r]".("M_ptvst[c]", "M_ptvst[e]", "M_ptvst[r]")                                   
"S_ptvstlac[c][e][r]".("M_ptvstlac[c]", "M_ptvstlac[e]", "M_ptvstlac[r]")                                   
"S_ptvstm13[c][e][r]".("M_ptvstm13[c]", "M_ptvstm13[e]", "M_ptvstm13[r]")                                   
"S_pvs[c][e][r]".("M_pvs[c]", "M_pvs[e]", "M_pvs[r]")                                   
"S_pvsgluc[c][e]".("M_pvsgluc[c]", "M_pvsgluc[e]")                                  
"S_pydam[c][e]".("M_pydam[c]", "M_pydam[e]")                                    
"S_pydx[c][e]".("M_pydx[c]", "M_pydx[e]")                                   
"S_pydxn[c][e]".("M_pydxn[c]", "M_pydxn[e]")                                    
"S_pyr[c][e][m][x]".("M_pyr[c]", "M_pyr[e]", "M_pyr[m]", "M_pyr[x]")                                    
"S_q10[c][e][m]".("M_q10[c]", "M_q10[e]", "M_q10[m]")                                   
"S_q10h2[c][e][m]".("M_q10h2[c]", "M_q10h2[e]", "M_q10h2[m]")                                   
"S_rbl_D[c][e]".("M_rbl_D[c]", "M_rbl_D[e]")                                    
"S_retfa[c][e]".("M_retfa[c]", "M_retfa[e]")                                    
"S_retinal[c][e][r]".("M_retinal[c]", "M_retinal[e]", "M_retinal[r]")                                   
"S_retinol[c][e][r]".("M_retinol[c]", "M_retinol[e]", "M_retinol[r]")                                   
"S_rib_D[c][e]".("M_rib_D[c]", "M_rib_D[e]")                                    
"S_ribflv[c][e]".("M_ribflv[c]", "M_ribflv[e]")                                 
"S_Rtotal[c][e][g][l]".("M_Rtotal[c]", "M_Rtotal[e]", "M_Rtotal[g]", "M_Rtotal[l]")                                 
"S_Rtotal2[c][e]".("M_Rtotal2[c]", "M_Rtotal2[e]")                                  
"S_s2l2fn2m2masn[e][l]".("M_s2l2fn2m2masn[e]", "M_s2l2fn2m2masn[l]")                                    
"S_s2l2n2m2m[c][e][l]".("M_s2l2n2m2m[c]", "M_s2l2n2m2m[e]", "M_s2l2n2m2m[l]")                                   
"S_s2l2n2m2masn[e][l]".("M_s2l2n2m2masn[e]", "M_s2l2n2m2masn[l]")                                   
"S_saccrp_L[c][e][m]".("M_saccrp_L[c]", "M_saccrp_L[e]", "M_saccrp_L[m]")                                   
"S_sbt_D[c][e]".("M_sbt_D[c]", "M_sbt_D[e]")                                    
"S_sebacid[c][e][x]".("M_sebacid[c]", "M_sebacid[e]", "M_sebacid[x]")                                   
"S_selmeth[c][e]".("M_selmeth[c]", "M_selmeth[e]")                                  
"S_ser_L[c][e][m][x]".("M_ser_L[c]", "M_ser_L[e]", "M_ser_L[m]", "M_ser_L[x]")                                  
"S_slfcys[c][e]".("M_slfcys[c]", "M_slfcys[e]")                                 
"S_smv[c][e][r]".("M_smv[c]", "M_smv[e]", "M_smv[r]")                                   
"S_smvacid[c][e]".("M_smvacid[c]", "M_smvacid[e]")                                  
"S_so3[c][e]".("M_so3[c]", "M_so3[e]")                                  
"S_so4[c][e][l][r]".("M_so4[c]", "M_so4[e]", "M_so4[l]", "M_so4[r]")                                    
"S_spc_hs[c][e]".("M_spc_hs[c]", "M_spc_hs[e]")                                 
"S_sph1p[c][e][n]".("M_sph1p[c]", "M_sph1p[e]", "M_sph1p[n]")                                   
"S_sphgn[c][e][g][n]".("M_sphgn[c]", "M_sphgn[e]", "M_sphgn[g]", "M_sphgn[n]")                                  
"S_sphings[c][e][g][l][n]".("M_sphings[c]", "M_sphings[e]", "M_sphings[g]", "M_sphings[l]", "M_sphings[n]")                                 
"S_sphmyln_hs[c][e][g][l][r]".("M_sphmyln_hs[c]", "M_sphmyln_hs[e]", "M_sphmyln_hs[g]", "M_sphmyln_hs[l]", "M_sphmyln_hs[r]")                                   
"S_sphmyln180241_hs[c][e]".("M_sphmyln180241_hs[c]", "M_sphmyln180241_hs[e]")                                   
"S_sphmyln18114_hs[c][e]".("M_sphmyln18114_hs[c]", "M_sphmyln18114_hs[e]")                                  
"S_sphmyln18115_hs[c][e]".("M_sphmyln18115_hs[c]", "M_sphmyln18115_hs[e]")                                  
"S_sphmyln18116_hs[c][e]".("M_sphmyln18116_hs[c]", "M_sphmyln18116_hs[e]")                                  
"S_sphmyln181161_hs[c][e]".("M_sphmyln181161_hs[c]", "M_sphmyln181161_hs[e]")                                   
"S_sphmyln18117_hs[c][e]".("M_sphmyln18117_hs[c]", "M_sphmyln18117_hs[e]")                                  
"S_sphmyln18118_hs[c][e]".("M_sphmyln18118_hs[c]", "M_sphmyln18118_hs[e]")                                  
"S_sphmyln181181_hs[c][e]".("M_sphmyln181181_hs[c]", "M_sphmyln181181_hs[e]")                                   
"S_sphmyln18120_hs[c][e]".("M_sphmyln18120_hs[c]", "M_sphmyln18120_hs[e]")                                  
"S_sphmyln181201_hs[c][e]".("M_sphmyln181201_hs[c]", "M_sphmyln181201_hs[e]")                                   
"S_sphmyln18121_hs[c][e]".("M_sphmyln18121_hs[c]", "M_sphmyln18121_hs[e]")                                  
"S_sphmyln18122_hs[c][e]".("M_sphmyln18122_hs[c]", "M_sphmyln18122_hs[e]")                                  
"S_sphmyln181221_hs[c][e]".("M_sphmyln181221_hs[c]", "M_sphmyln181221_hs[e]")                                   
"S_sphmyln18123_hs[c][e]".("M_sphmyln18123_hs[c]", "M_sphmyln18123_hs[e]")                                  
"S_sphmyln1824_hs[c][e]".("M_sphmyln1824_hs[c]", "M_sphmyln1824_hs[e]")                                 
"S_sphmyln1825_hs[c][e]".("M_sphmyln1825_hs[c]", "M_sphmyln1825_hs[e]")                                 
"S_sphs1p[c][e][n]".("M_sphs1p[c]", "M_sphs1p[e]", "M_sphs1p[n]")                                   
"S_spmd[c][e]".("M_spmd[c]", "M_spmd[e]")                                   
"S_sprm[c][e]".("M_sprm[c]", "M_sprm[e]")                                   
"S_sql[c][e][r]".("M_sql[c]", "M_sql[e]", "M_sql[r]")                                   
"S_srtn[c][e]".("M_srtn[c]", "M_srtn[e]")                                   
"S_stcrn[c][e][m][r]".("M_stcrn[c]", "M_stcrn[e]", "M_stcrn[m]", "M_stcrn[r]")                                  
"S_strdnc[c][e][l][r]".("M_strdnc[c]", "M_strdnc[e]", "M_strdnc[l]", "M_strdnc[r]")                                 
"S_subeac[c][e][x]".("M_subeac[c]", "M_subeac[e]", "M_subeac[x]")                                   
"S_subgly[c][e]".("M_subgly[c]", "M_subgly[e]")                                 
"S_succ[c][e][m][x]".("M_succ[c]", "M_succ[e]", "M_succ[m]", "M_succ[x]")                                   
"S_sucsal[c][e][m]".("M_sucsal[c]", "M_sucsal[e]", "M_sucsal[m]")                                   
"S_T4hcinnm[c][e][m]".("M_T4hcinnm[c]", "M_T4hcinnm[e]", "M_T4hcinnm[m]")                                   
"S_tacr[c][e][r]".("M_tacr[c]", "M_tacr[e]", "M_tacr[r]")                                   
"S_tagat_D[c][e]".("M_tagat_D[c]", "M_tagat_D[e]")                                  
"S_tau_L_lysine[c][e][n]".("M_tau_L_lysine[c]", "M_tau_L_lysine[e]", "M_tau_L_lysine[n]")                                   
"S_taur[c][e]".("M_taur[c]", "M_taur[e]")                                   
"S_taxol[c][e]".("M_taxol[c]", "M_taxol[e]")                                    
"S_tchola[c][e]".("M_tchola[c]", "M_tchola[e]")                                 
"S_tdchola[c][e]".("M_tdchola[c]", "M_tdchola[e]")                                  
"S_tdechola[c][e]".("M_tdechola[c]", "M_tdechola[e]")                                   
"S_tetdec2crn[c][e]".("M_tetdec2crn[c]", "M_tetdec2crn[e]")                                 
"S_tetdece1crn[c][e]".("M_tetdece1crn[c]", "M_tetdece1crn[e]")                                  
"S_tethex3[c][e][r]".("M_tethex3[c]", "M_tethex3[e]", "M_tethex3[r]")                                   
"S_tetpent3[c][e][r]".("M_tetpent3[c]", "M_tetpent3[e]", "M_tetpent3[r]")                                   
"S_tetpent6[c][e][r]".("M_tetpent6[c]", "M_tetpent6[e]", "M_tetpent6[r]")                                   
"S_tettet6[c][e][r]".("M_tettet6[c]", "M_tettet6[e]", "M_tettet6[r]")                                   
"S_thbpt[c][e]".("M_thbpt[c]", "M_thbpt[e]")                                    
"S_thcholstoic[c][e][m][r][x]".("M_thcholstoic[c]", "M_thcholstoic[e]", "M_thcholstoic[m]", "M_thcholstoic[r]", "M_thcholstoic[x]")                                 
"S_thf[c][e][l][m]".("M_thf[c]", "M_thf[e]", "M_thf[l]", "M_thf[m]")                                    
"S_thm[c][e]".("M_thm[c]", "M_thm[e]")                                  
"S_thmtp[c][e]".("M_thmtp[c]", "M_thmtp[e]")                                    
"S_thr_L[c][e]".("M_thr_L[c]", "M_thr_L[e]")                                    
"S_thym[c][e]".("M_thym[c]", "M_thym[e]")                                   
"S_thymd[c][e][m]".("M_thymd[c]", "M_thymd[e]", "M_thymd[m]")                                   
"S_thyochol[c][e]".("M_thyochol[c]", "M_thyochol[e]")                                   
"S_thyox_L[c][e]".("M_thyox_L[c]", "M_thyox_L[e]")                                  
"S_tiggly[c][e][m]".("M_tiggly[c]", "M_tiggly[e]", "M_tiggly[m]")                                   
"S_tlacfvs[c][e][r]".("M_tlacfvs[c]", "M_tlacfvs[e]", "M_tlacfvs[r]")                                   
"S_tmlys[c][e]".("M_tmlys[c]", "M_tmlys[e]")                                    
"S_tmndnc[c][e][r]".("M_tmndnc[c]", "M_tmndnc[e]", "M_tmndnc[r]")                                   
"S_TNFA_L_lysine[c][e][n]".("M_TNFA_L_lysine[c]", "M_TNFA_L_lysine[e]", "M_TNFA_L_lysine[n]")                                   
"S_tre[c][e]".("M_tre[c]", "M_tre[e]")                                  
"S_triodthy[c][e]".("M_triodthy[c]", "M_triodthy[e]")                                   
"S_triodthysuf[c][e]".("M_triodthysuf[c]", "M_triodthysuf[e]")                                  
"S_tripvs[c][e]".("M_tripvs[c]", "M_tripvs[e]")                                 
"S_trp_L[c][e]".("M_trp_L[c]", "M_trp_L[e]")                                    
"S_trypta[c][e]".("M_trypta[c]", "M_trypta[e]")                                 
"S_tststerone[c][e][r]".("M_tststerone[c]", "M_tststerone[e]", "M_tststerone[r]")                                   
"S_tststerones[c][e]".("M_tststerones[c]", "M_tststerones[e]")                                  
"S_ttdca[c][e][r]".("M_ttdca[c]", "M_ttdca[e]", "M_ttdca[r]")                                   
"S_ttdcea[c][e][r]".("M_ttdcea[c]", "M_ttdcea[e]", "M_ttdcea[r]")                                   
"S_ttdcrn[c][e][m]".("M_ttdcrn[c]", "M_ttdcrn[e]", "M_ttdcrn[m]")                                   
"S_txa2[c][e][r]".("M_txa2[c]", "M_txa2[e]", "M_txa2[r]")                                   
"S_Tyr_ggn[c][e]".("M_Tyr_ggn[c]", "M_Tyr_ggn[e]")                                  
"S_tyr_L[c][e]".("M_tyr_L[c]", "M_tyr_L[e]")                                    
"S_uchol[c][e]".("M_uchol[c]", "M_uchol[e]")                                    
"S_udp[c][e][g][l][n][r]".("M_udp[c]", "M_udp[e]", "M_udp[g]", "M_udp[l]", "M_udp[n]", "M_udp[r]")                                  
"S_udpglcur[c][e][g][r]".("M_udpglcur[c]", "M_udpglcur[e]", "M_udpglcur[g]", "M_udpglcur[r]")                                   
"S_ump[c][e][g][l][n][r]".("M_ump[c]", "M_ump[e]", "M_ump[g]", "M_ump[l]", "M_ump[n]", "M_ump[r]")                                  
"S_ura[c][e]".("M_ura[c]", "M_ura[e]")                                  
"S_urate[c][e]".("M_urate[c]", "M_urate[e]")                                    
"S_urcan[c][e]".("M_urcan[c]", "M_urcan[e]")                                    
"S_urea[c][e][m]".("M_urea[c]", "M_urea[e]", "M_urea[m]")                                   
"S_uri[c][e][l]".("M_uri[c]", "M_uri[e]", "M_uri[l]")                                   
"S_utp[c][e][n]".("M_utp[c]", "M_utp[e]", "M_utp[n]")                                   
"S_vacc[c][e][r]".("M_vacc[c]", "M_vacc[e]", "M_vacc[r]")                                   
"S_val_L[c][e]".("M_val_L[c]", "M_val_L[e]")                                    
"S_vitd3[c][e]".("M_vitd3[c]", "M_vitd3[e]")                                    
"S_wharachd[c][e][r]".("M_wharachd[c]", "M_wharachd[e]", "M_wharachd[r]")                                   
"S_whhdca[c][e]".("M_whhdca[c]", "M_whhdca[e]")                                 
"S_whtststerone[c][e]".("M_whtststerone[c]", "M_whtststerone[e]")                                   
"S_xan[c][e]".("M_xan[c]", "M_xan[e]")                                  
"S_xmp[c][e]".("M_xmp[c]", "M_xmp[e]")                                  
"S_xol25oh[c][e][r]".("M_xol25oh[c]", "M_xol25oh[e]", "M_xol25oh[r]")                                   
"S_xol27oh[c][e][m][r]".("M_xol27oh[c]", "M_xol27oh[e]", "M_xol27oh[m]", "M_xol27oh[r]")                                    
"S_xol7ah3[c][e]".("M_xol7ah3[c]", "M_xol7ah3[e]")                                  
"S_xol7aone[c][e][m][r]".("M_xol7aone[c]", "M_xol7aone[e]", "M_xol7aone[m]", "M_xol7aone[r]")                                   
"S_xoldiolone[c][e]".("M_xoldiolone[c]", "M_xoldiolone[e]")                                 
"S_xolest_hs[c][e]".("M_xolest_hs[c]", "M_xolest_hs[e]")                                    
"S_xolest2_hs[c][e]".("M_xolest2_hs[c]", "M_xolest2_hs[e]")                                 
"S_xoltri25[c][e][r]".("M_xoltri25[c]", "M_xoltri25[e]", "M_xoltri25[r]")                                   
"S_xoltri27[c][e][r]".("M_xoltri27[c]", "M_xoltri27[e]", "M_xoltri27[r]")                                   
"S_xtsn[c][e]".("M_xtsn[c]", "M_xtsn[e]")                                   
"S_xyl_D[c][e][l]".("M_xyl_D[c]", "M_xyl_D[e]", "M_xyl_D[l]")                                   
"S_xylt[c][e]".("M_xylt[c]", "M_xylt[e]")                                   
"S_xylu_D[c][e]".("M_xylu_D[c]", "M_xylu_D[e]")                                 
"S_xylu_L[c][e]".("M_xylu_L[c]", "M_xylu_L[e]")                                 
                                    
/                                   
                                    
            
* Based on the model, a user can revise the following subsets and parameters                                    
BioCompound_pool(BioCompound) "Biocompounds pool defined on the model"                                  
/                                   
                                    
/                                   
                                    
BioCompound_exp(BioCompound) "observed BioCompounds measured from LC-MASS experiments"                                  
/                                   
                                    
"S_pyr[c]",                                 
"S_akg[m]",                                 
"S_glu_L[m]",                                   
"S_pyr[m]",                                 
"S_accoa[m]",                                   
"S_cit[m]",                                 
"S_icit[m]",                                    
"S_succoa[m]",                                  
"S_mal_L[c]",                                   
"S_mal_L[m]",                                   
"S_gln_L[c]",                                   
"S_gln_L[m]",                                   
"S_gln_L[e]",                                   
"S_glc_D[e]",                                   
"S_oaa[m]",                                 
"S_lac_L[c]",                                   
"S_succ[m]",                                    
"S_HC00342[m]",                                 
*"S_gln_L[c][m]",                                    
*"S_ile_L[c][m]",                                    
*"S_leu_L[c][m]",                                    
*"S_val_L[c][m]",                                    
*"S_met_L[c][m]",                                    
"S_trp_L[c]",                                   
"S_phe_L[c]",                                   
"S_tyr_L[c]",                                   
"S_glu_L[c]"                                   
                                    
                                    
/                                   
                                    
BioCompound_warburg(BioCompound) "observed BioCompounds accessed from literature for analyzing Warburg effects"                                 
/                                   
                                    
* Warburg hypothesis                                    
"S_pyr[c]",                                 
"S_akg[m]",                                 
"S_glu_L[m]",                                   
"S_pyr[m]",                                 
"S_accoa[m]",                                   
"S_cit[m]",                                 
"S_icit[m]",                                    
"S_succoa[m]",                                  
"S_mal_L[c]",                                   
"S_mal_L[m]",                                   
"S_gln_L[c]",                                   
"S_gln_L[m]",                                   
"S_gln_L[e]",                                   
"S_glc_D[e]",                                   
"S_oaa[m]",                                 
"S_lac_L[c]",                                   
"S_succ[m]",                                    
"S_HC00342[m]",                                 
*"S_gln_L[c][m]",                                    
*"S_ile_L[c][m]",                                    
*"S_leu_L[c][m]",                                    
*"S_val_L[c][m]",                                    
*"S_met_L[c][m]",                                    
"S_trp_L[c]",                                   
"S_phe_L[c]",                                   
                                    
* Ref.Pavlova & Thompson, The emerging hallmarks of cancer metabolism, Cell Metabolism, 2016                                    
"S_tyr_L[c]",                                   
"S_glu_L[c]"                                   
/;                                  
                                    
parameters                                  
*  positive value: increasing results computed from LC-MASS experimental data                                   
**  negative value: decreasing results computed from LC-MASS experimental data                                  
*  1: increasing observation acceessed from literature relating to Warburg effects                                  
* -1: decreasing observation acceessed from literature relating to Warburg effects                                  
Experiment_RFC(BioCompound) "rate of difference change for each BioCompound obtained from LC-MASS experiments and from literature of warburg effects, log2(Disease/Normal)"                                 
/                                   
                                    
* Warburg hypothesis                                    
"S_pyr[c]"  1.0000000000                                
"S_akg[m]"  1.0000000000                                
"S_glu_L[m]"    1.0000000000                                
"S_pyr[m]"  -1.0000000000                               
"S_accoa[m]"    -1.0000000000                               
"S_cit[m]"  1.0000000000                                
"S_icit[m]" 1.0000000000                                
"S_succoa[m]"   1.0000000000                                
"S_mal_L[c]"    1.0000000000                                
"S_mal_L[m]"    1.0000000000                                
"S_gln_L[c]"    1.0000000000                                
"S_gln_L[m]"    1.0000000000                                
"S_gln_L[e]"    1.0000000000                                
"S_glc_D[e]"    1.0000000000                                
"S_oaa[m]"  -1.0000000000                               
"S_lac_L[c]"    1.0000000000                                
"S_succ[m]" 1.0000000000                                
"S_HC00342[m]"  1.0000000000                                
*"S_gln_L[c][m]" 1.0000000000                                
*"S_ile_L[c][m]" 1.0000000000                                
*"S_leu_L[c][m]" 1.0000000000                                
*"S_val_L[c][m]" 1.0000000000                                
*"S_met_L[c][m]" 1.0000000000                                
"S_trp_L[c]"    1.0000000000                                
"S_phe_L[c]"    1.0000000000                                
                                    
* Ref.Pavlova & Thompson, The emerging hallmarks of cancer metabolism, Cell Metabolism, 2016                                    
"S_tyr_L[c]"    1.0000000000                                
"S_glu_L[c]"    1.0000000000                                
                                    
$ontext                                 
* Warburg hypothesis and experinets from LC/MS datat                                    
"S_ile_L_c_m"     1.110029093                                   
"S_leu_L_c_m"     0.94073056                                    
"S_val_L_c_m"     0.949497581                                   
"S_met_L_c"       0.951513196                                   
"S_trp_L_c"       0.463622457                                   
"S_phe_L_c"       0.803640357                                   
                                    
* LC/MS                                     
******************(BL HT CA)***************************************                                 
"S_betald_c_m"    -1.86144762484735                                 
"S_asp_L_c_m"      1.42932136994144                                 
"S_asn_L_c"        1.1659440877706                                  
"S_Nacasp_c_m"     1.99048295843318                                 
"S_3mlda_c"       -1.70557039789067                                 
"S_Lpipecol_x"     1.33485426933163                                 
"S_Lkynr_c"        2.86050598795403                                 
"S_4mop_c_m"      -2.0782590139205                                  
*    "S_ile_L_c_m"      1.11002909279937                                    
"S_3mop_c_m"      -2.65744525452268                                 
"S_3mob_c_m"      -2.1752728727679                                  
"S_amet_c_m_r"     3.24996103893073                                 
"S_ahcys_c_m_r"    1.88962929067343                                 
***    "S_cyst_L_c"       2.78245050312714                                  
"S_cys_L_c"        2.77080790748875                                 
"S_3sala_c_m"      1.4608473879589                                  
***    "S_4hpro_LT_c_m"   1.43060643092981                                  
"S_ptrc_c"         2.77123061952708                                 
"S_5mta_c"         3.04500604200744                                 
***    "S_gthrd_c_m_r"    2.38014759931603                                  
"S_gthox_c_m"      1.01592568999025                                 
"S_lgt_S_c"        2.20310716660741                                 
"S_cgly_c"         1.65622176328646                                 
"S_glucys_c"       1.42368573044214                                 
"S_carn_c"        -2.56405143513947                                 
"S_glyleu_c"       2.75567809611696                                 
"S_leugly_c"       1.81393507048132                                 
"S_progly_c"       1.80231731440359                                 
***    "S_glc_D_c_g_l_r"       -1.45482236538471                                    
"S_2pg_c"         -1.47032895165222                                 
"S_3pg_c_m"       -1.72642443438462                                 
"S_pep_c_m"       -1.31940558511865                                 
"S_pyr_c_m_x"      1.69064057861569                                 
***    "S_glu_L_c_l_m_r"  1.85039939677025                                  
***    "S_icit_c_m"       2.55816965483461                                  
***    "S_rbt_c"    2.00072116724365                                    
"S_xylt_c"         1.48583896687906                                 
"S_malt_c"        -1.99539074674741                                 
"S_man6p_c"        1.01106620140621                                 
"S_gal1p_c"        1.61955386898162                                 
"S_udpg_c_r"       1.70119416132531                                 
"S_udpgal_c_g"     1.63849094171046                                 
"S_udpglcur_c_r"   2.2885357502938                                  
***    "S_uacgam_c_g_r"   2.9924240277823                                   
"S_gam6p_c"        1.10768786931437                                 
"S_acgam6p_c"      1.79223067383318                                 
"S_cit_c_m"       -1.24605322791223                                 
"S_c4dc_c_x"      -1.08834676269147                                 
"S_clpnd_c"        1.44509101484404147                                  
"S_crvnc_c"        1.00432160595009                                 
***    "S_dcsptn1_c"      1.86366098238948                                  
***    "S_c8crn_m_x_c"    -1.13828278949271                                 
***    "S_ttdcrn_c_m"     1.0453730710523                                   
***    "S_pmtcrn_c_m_r"    1.251385833216                                   
"S_stcrn_c_m"       1.88596475675397                                    
"S_cdpchol_c"       3.16966849952309                                    
"S_cdpea_c"         1.56759412074444                                    
"S_lpchol_hs_c"     1.20820508950445                                    
"S_pglyc_hs_c"      1.05443175398842                                    
"S_glyc3p_c_m"     -2.17657670931474                                    
"S_dag_hs_c_r"      1.05609792428003                                    
"S_mag_hs_c"        1.40184887473608                                    
"S_sphings_c_l"     1.83005245627156                                    
"S_dheas_c"        -1.03682184382611                                    
***    "S_dgchol_c"       -1.05139915250664                                 
"S_imp_c"    -1.45719717257261                                  
"S_xtsn_c"    1.03548315212869                                  
"S_din_c"     1.9654703200606                                   
"S_amp_c_m_r_x"     1.8395968531951                                 
"S_ade_c"     1.43098102487046                                  
"S_gua_c"     1.43071346769515                                  
***    "S_dgsn_c_m"        2.10356477927152                                 
"S_orot_c"    2.39635132406325                                  
"S_ump_c_g_n_r"     1.33925142745084                                    
"S_ura_c"     1.47700373998213                                  
***    "S_56dura_c"        1.57729588247209                                 
"S_thym_c"    2.1641748371336                                   
***    "S_56dthm_c"        1.8807638772429                                  
"S_quln_c"    3.32009470773801                                  
***    "S_1mncam_c"        2.00259451670845                                 
"S_coa_c_l_m_r_x"   1.06129233847829                                    
"S_ascb_L_c"        4.69279541328972                                    
***    "S_CE2705_c_n"      2.0355183428167                                  
"S_pheme_c_m"      -1.42973138442188                                    
"S_thmpp_c_m"       1.73902717439587                                    
"S_pydx_c"    1.15036470461199                                  
"S_4hbz_m"         -1.07157282312431                                    
                                    
                                    
                                    
* LC/MS                                 
                                    
****Table 3. List of Identified Metabolite Biomarkers for CRC Diagnosis Reported Once in the Last 6 Years                                   
"S_glu_L[c][e][l][m][r]"       -1                                   
"S_glyclt[c][e][m][x]"         -1                                   
"S_ddca[c][e][r]"               1                                   
"S_C01601[c][e]"               -1                                   
"S_ptdca[c][e][r]"              1                                   
"S_crvnc[c][e][l][r]"          -1                                   
                                    
*****Warburg hypothesis and experimets from Metabolic Profiling of Human Colorectal Cancer                                  
"S_gal[c][e][l]"              -0.662003536                                  
"S_arachd[c][e][r][x]"        -0.263611599                                  
"S_fum[c][m]"                 -0.323732592                                  
"S_glc_D[c][e][g][l][r]"      -1.446148032                                  
"S_mal_L[c][e][m][x]"         -0.416962376                                  
"S_phe_L[c][e][m]"             0.786596362                                  
"S_uri[c][e][l]"               1.01720929                                   
$offtext                                    
/;                                  
