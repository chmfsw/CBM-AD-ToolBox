$onempty
sets
$onMulti
  enzymes(universalSet<) "implicit subset of enzymes defined in BL model"
    /
      'E0001',      'E0002',      'E0003',      'E0004',      'E0006',      'E0007',      'E0008',      'E0009',      'E0010',      'E0011',
      'E0012',      'E0013',      'E0014',      'E0015',      'E0016',      'E0017',      'E0018',      'E0019',      'E0020',      'E0026',
      'E0027',      'E0028',      'E0029',      'E0030',      'E0031',      'E0032',      'E0033',      'E0034',      'E0035',      'E0036',
      'E0037',      'E0038',      'E0039',      'E0040',      'E0041',      'E0042',      'E0043',      'E0044',      'E0045',      'E0047',
      'E0048',      'E0049',      'E0050',      'E0051',      'E0052',      'E0053',      'E0054',      'E0055',      'E0056',      'E0057',
      'E0058',      'E0059',      'E0060',      'E0063',      'E0064',      'E0065',      'E0066',      'E0067',      'E0068',      'E0069',
      'E0070',      'E0071',      'E0072',      'E0073',      'E0074',      'E0075',      'E0076',      'E0077',      'E0079',      'E0080',
      'E0081',      'E0082',      'E0083',      'E0084',      'E0085',      'E0086',      'E0087',      'E0088',      'E0089',      'E0090',
      'E0091',      'E0092',      'E0093',      'E0094',      'E0095',      'E0096',      'E0097',      'E0098',      'E0099',      'E0100',
      'E0101',      'E0102',      'E0103',      'E0104',      'E0105',      'E0106',      'E0107',      'E0108',      'E0109',      'E0110',
      'E0111',      'E0112',      'E0114',      'E0115',      'E0116',      'E0117',      'E0118',      'E0119',      'E0120',      'E0121',
      'E0122',      'E0123',      'E0124',      'E0125',      'E0126',      'E0127',      'E0128',      'E0129',      'E0131',      'E0132',
      'E0134',      'E0135',      'E0136',      'E0137',      'E0138',      'E0139',      'E0140',      'E0141',      'E0142',      'E0143',
      'E0144',      'E0146',      'E0148',      'E0149',      'E0150',      'E0151',      'E0152',      'E0153',      'E0154',      'E0155',
      'E0156',      'E0159',      'E0160',      'E0161',      'E0162',      'E0163',      'E0164',      'E0165',      'E0166',      'E0167',
      'E0168',      'E0169',      'E0170',      'E0171',      'E0172',      'E0173',      'E0174',      'E0175',      'E0176',      'E0177',
      'E0178',      'E0179',      'E0180',      'E0181',      'E0182',      'E0183',      'E0184',      'E0185',      'E0186',      'E0187',
      'E0188',      'E0189',      'E0190',      'E0191',      'E0192',      'E0193',      'E0194',      'E0195',      'E0196',      'E0197',
      'E0199',      'E0201',      'E0203',      'E0204',      'E0205',      'E0206',      'E0209',      'E0210',      'E0211',      'E0212',
      'E0213',      'E0215',      'E0216',      'E0218',      'E0219',      'E0220',      'E0221',      'E0222',      'E0223',      'E0224',
      'E0225',      'E0226',      'E0227',      'E0228',      'E0229',      'E0230',      'E0231',      'E0232',      'E0233',      'E0234',
      'E0235',      'E0236',      'E0241',      'E0242',      'E0243',      'E0244',      'E0245',      'E0246',      'E0247',      'E0248',
      'E0249',      'E0250',      'E0251',      'E0252',      'E0253',      'E0254',      'E0255',      'E0256',      'E0257',      'E0258',
      'E0259',      'E0260',      'E0261',      'E0262',      'E0263',      'E0264',      'E0265',      'E0266',      'E0267',      'E0268',
      'E0269',      'E0270',      'E0271',      'E0272',      'E0273',      'E0274',      'E0275',      'E0276',      'E0277',      'E0278',
      'E0279',      'E0280',      'E0281',      'E0282',      'E0283',      'E0284',      'E0285',      'E0286',      'E0287',      'E0288',
      'E0289',      'E0291',      'E0292',      'E0293',      'E0294',      'E0295',      'E0296',      'E0301',      'E0302',      'E0303',
      'E0304',      'E0305',      'E0306',      'E0495',      'E0496',      'E0497',      'E0498',      'E0499',      'E0500',      'E0501',
      'E0505',      'E0506',      'E0507',      'E0508',      'E0509',      'E0510',      'E0511',      'E0512',      'E0513',      'E0514',
      'E0515',      'E0516',      'E0517',      'E0519',      'E0521',      'E0522',      'E0523',      'E0524',      'E0527',      'E0528',
      'E0529',      'E0530',      'E0533',      'E0534',      'E0536',      'E0537',      'E0538',      'E0539',      'E0540',      'E0541',
      'E0542',      'E0547',      'E0548',      'E0549',      'E0550',      'E0551',      'E0552',      'E0553',      'E0554',      'E0555',
      'E0556',      'E0557',      'E0558',      'E0559',      'E0562',      'E0563',      'E0564',      'E0565',      'E0566',      'E0567',
      'E0568',      'E0569',      'E0570',      'E0571',      'E0572',      'E0573',      'E0574',      'E0575',      'E0576',      'E0577',
      'E0579',      'E0580',      'E0581',      'E0582',      'E0583',      'E0584',      'E0585',      'E0586',      'E0588',      'E0589',
      'E0590',      'E0591',      'E0593',      'E0594',      'E0595',      'E0596',      'E0598',      'E0599',      'E0600',      'E0601',
      'E0602',      'E0603',      'E0604',      'E0610',      'E0611',      'E0612',      'E0613',      'E0614',      'E0615',      'E0616',
      'E0617',      'E0618',      'E0619',      'E0620',      'E0621',      'E0622',      'E0623',      'E0624',      'E0625',      'E0626',
      'E0627',      'E0628',      'E0629',      'E0630',      'E0631',      'E0632',      'E0633',      'E0634',      'E0636',      'E0637',
      'E0640',      'E0643',      'E0644',      'E0645',      'E0646',      'E0647',      'E0648',      'E0649',      'E0650',      'E0651',
      'E0652',      'E0653',      'E0654',      'E0655',      'E0656',      'E0657',      'E0658',      'E0659',      'E0660',      'E0661',
      'E0662',      'E0663',      'E0664',      'E0665',      'E0666',      'E0667',      'E0668',      'E0669',      'E0671',      'E0672',
      'E0673',      'E0676',      'E0677',      'E0678',      'E0679',      'E0680',      'E0681',      'E0682',      'E0683',      'E0684',
      'E0685',      'E0686',      'E0687',      'E0688',      'E0689',      'E0690',      'E0691',      'E0696',      'E0697',      'E0699',
      'E0701',      'E0707',      'E0708',      'E0709',      'E0710',      'E0711',      'E0712',      'E0713',      'E0714',      'E0715',
      'E0716',      'E0717',      'E0718',      'E0719',      'E0720',      'E0721',      'E0722',      'E0723',      'E0724',      'E0725',
      'E0726',      'E0727',      'E0728',      'E0729',      'E0732',      'E0733',      'E0734',      'E0735',      'E0736',      'E0737',
      'E0738',      'E0739',      'E0740',      'E0741',      'E0742',      'E0743',      'E0744',      'E0745',      'E0746',      'E0747',
      'E0748',      'E0749',      'E0750',      'E0752',      'E0753',      'E0754',      'E0755',      'E0756',      'E0757',      'E0758',
      'E0759',      'E0760',      'E0761',      'E0762',      'E0763',      'E0764',      'E0765',      'E0766',      'E0767',      'E0768',
      'E0769',      'E0770',      'E0771',      'E0772',      'E0773',      'E0775',      'E0776',      'E0778',      'E0779',      'E0780',
      'E0781',      'E0782',      'E0783',      'E0784',      'E0786',      'E0787',      'E0788',      'E0789',      'E0791',      'E0792',
      'E0793',      'E0794',      'E0795',      'E0796',      'E0797',      'E0798',      'E0799',      'E0800',      'E0801',      'E0803',
      'E0804',      'E0805',      'E0806',      'E0808',      'E0809',      'E0810',      'E0811',      'E0812',      'E0813',      'E0814',
      'E0815',      'E0816',      'E0817',      'E0818',      'E0819',      'E0820',      'E0821',      'E0822',      'E0823',      'E0824',
      'E0825',      'E0826',      'E0827',      'E0828',      'E0829',      'E0830',      'E0831',      'E0832',      'E0833',      'E0834',
      'E0835',      'E0836',      'E0837',      'E0838',      'E0839',      'E0840',      'E0841',      'E0842',      'E0843',      'E0844',
      'E0845',      'E0846',      'E0847',      'E0848',      'E0849',      'E0850',      'E0851',      'E0852',      'E0858',      'E0859',
      'E0860',      'E0861',      'E0862',      'E0864',      'E0865',      'E0866',      'E0867',      'E0868',      'E0869',      'E0870',
      'E0871',      'E0872',      'E0873',      'E0874',      'E0875',      'E0876',      'E0877',      'E0878',      'E0879',      'E0880',
      'E0881',      'E0882',      'E0883',      'E0884',      'E0885',      'E0886',      'E0887',      'E0888',      'E0889',      'E0890',
      'E0891',      'E0892',      'E0893',      'E0894',      'E0895',      'E0896',      'E0899',      'E0900',      'E0901',      'E0902',
      'E0903',      'E0904',      'E0905',      'E0906',      'E0907',      'E0911',      'E0912',      'E0913',      'E0916',      'E0917',
      'E0918',      'E0919',      'E0920',      'E0921',      'E0922',      'E0923',      'E0926',      'E0927',      'E0928',      'E0929',
      'E0930',      'E0931',      'E0932',      'E0933',      'E0934',      'E0935',      'E0936',      'E0937',      'E0938',      'E0939',
      'E0940',      'E0941',      'E0942',      'E0943',      'E0944',      'E0945',      'E0946',      'E0947',      'E0948',      'E0949',
      'E0950',      'E0951',      'E0952',      'E0953',      'E0954',      'E0955',      'E0956',      'E0957',      'E0958',      'E0959',
      'E0960',      'E0961',      'E0962',      'E0963',      'E0964',      'E0965',      'E0966',      'E0967',      'E0968',      'E0970',
      'E0971',      'E0972',      'E0973',      'E0974',      'E0975',      'E0976',      'E0977',      'E0978',      'E0979',      'E0980',
      'E0981',      'E0982',      'E0983',      'E0984',      'E0985',      'E0986',      'E0987',      'E0988',      'E0989',      'E0990',
      'E0991',      'E0992',      'E0993',      'E0994',      'E0995',      'E0996',      'E0999',      'E1002',      'E1003',      'E1004',
      'E1005',      'E1006',      'E1009',      'E1010',      'E1011',      'E1012',      'E1016',      'E1017',      'E1018',      'E1019',
      'E1021',      'E1022',      'E1024',      'E1025',      'E1026',      'E1027',      'E1028',      'E1029',      'E1030',      'E1031',
      'E1032',      'E1033',      'E1037',      'E1038',      'E1039',      'E1040',      'E1041',      'E1042',      'E1043',      'E1044',
      'E1045',      'E1046',      'E1047',      'E1048',      'E1049',      'E1050',      'E1051',      'E1052',      'E1053',      'E1054',
      'E1056',      'E1057',      'E1058',      'E1059',      'E1060',      'E1061',      'E1065',      'E1066',      'E1067',      'E1068',
      'E1069',      'E1070',      'E1071',      'E1072',      'E1073',      'E1087',      'E1088',      'E1090',      'E1092',      'E1093',
      'E1094',      'E1095',      'E1098',      'E1100',      'E1101',      'E1102',      'E1103',      'E1104',      'E1105',      'E1106',
      'E1107',      'E1108',      'E1109',      'E1111',      'E1112',      'E1113',      'E1114',      'E1116',      'E1117',      'E1123',
      'E1124',      'E1128',      'E1131',      'E1143',      'E1144',      'E1145',      'E1146',      'E1147',      'E1148',      'E1149',
      'E1150',      'E1151',      'E1152',      'E1153',      'E1154',      'E1155',      'E1157',      'E1159',      'E1160',      'E1161',
      'E1162',      'E1163',      'E1164',      'E1165',      'E1166',      'E1169',      'E1170',      'E1171',      'E1172',      'E1174',
      'E1176',      'E1177',      'E1178',      'E1179',      'E1180',      'E1181',      'E1182',      'E1183',      'E1185',      'E1186',
      'E1187',      'E1188',      'E1189',      'E1190',      'E1192',      'E1193',      'E1194',      'E1197',      'E1198',      'E1199',
      'E1200',      'E1201',      'E1202',      'E1204',      'E1205',      'E1207',      'E1209',      'E1210',      'E1211',      'E1212',
      'E1213',      'E1214',      'E1215',      'E1216',      'E1217',      'E1218',      'E1219',      'E1221',      'E1224',      'E1225',
      'E1227',      'E1228',      'E1229',      'E1230',      'E1231',      'E1232',      'E1233',      'E1234',      'E1235',      'E1236',
      'E1238',      'E1239',      'E1240',      'E1241',      'E1243',      'E1244',      'E1245',      'E1246',      'E1247',      'E1248',
      'E1249',      'E1250',      'E1251',      'E1252',      'E1253',      'E1254',      'E1255',      'E1256',      'E1257',      'E1258',
      'E1259',      'E1260',      'E1261',      'E1262',      'E1263',      'E1264',      'E1265',      'E1266',      'E1267',      'E1268',
      'E1269',      'E1270',      'E1271',      'E1272',      'E1273',      'E1274',      'E1275',      'E1276',      'E1277',      'E1278',
      'E1279',      'E1280',      'E1281',      'E1282',      'E1283',      'E1284',      'E1285',      'E1286',      'E1287',      'E1288',
      'E1289',      'E1290',      'E1291',      'E1292',      'E1293',      'E1294',      'E1297',      'E1299',      'E1301',      'E1302',
      'E1303',      'E1304',      'E1305',      'E1309',      'E1310',      'E1311',      'E1312',      'E1313',      'E1314',      'E1317',
      'E1318',      'E1319',      'E1320',      'E1322',      'E1323',      'E1324',      'E1325',      'E1326',      'E1327',      'E1328',
      'E1329',      'E1330',      'E1331',      'E1332',      'E1333',      'E1334',      'E1335',      'E1336',      'E1337',      'E1338',
      'E1339',      'E1340',      'E1341',      'E1342',      'E1343',      'E1344',      'E1345',      'E1346',      'E1347',      'E1348',
      'E1349',      'E1350',      'E1351',      'E1352',      'E1353',      'E1354',      'E1355',      'E1356',      'E1357',      'E1358',
      'E1359',      'E1360',      'E1361',      'E1362',      'E1363',      'E1364',      'E1365',      'E1366',      'E1367',      'E1368',
      'E1369',      'E1370',      'E1371',      'E1372',      'E1373',      'E1374',      'E1375',      'E1376',      'E1377',      'E1378',
      'E1379',      'E1380',      'E1381',      'E1382',      'E1383',      'E1384',      'E1385',      'E1386',      'E1387',      'E1388',
      'E1389',      'E1390',      'E1391',      'E1392',      'E1393',      'E1394',      'E1395',      'E1396',      'E1398',      'E1399',
      'E1400',      'E1401',      'E1402',      'E1403',      'E1404',      'E1405',      'E1406',      'E1407',      'E1408',      'E1409',
      'E1412',      'E1416',      'E1417',      'E1418',      'E1419',      'E1420',      'E1425',      'E1426',      'E1427',      'E1430',
      'E1431',      'E1432',      'E1433',      'E1434',      'E1435',      'E1436',      'E1437',      'E1438',      'E1439',      'E1440',
      'E1442',      'E1443',      'E1444',      'E1445',      'E1446',      'E1447',      'E1448',      'E1449',      'E1450',      'E1451',
      'E1452',      'E1453',      'E1454',      'E1455',      'E1456',      'E1457',      'E1458',      'E1459',      'E1460',      'E1461',
      'E1462',      'E1463',      'E1464',      'E1465',      'E1466',      'E1467',      'E1468',      'E1469',      'E1470',      'E1471',
      'E1472',      'E1473',      'E1474',      'E1475',      'E1476',      'E1477',      'E1478',      'E1479',      'E1481',      'E1483',
      'E1486',      'E1488',      'E1489',      'E1490',      'E1491',      'E1492',      'E1493',      'E1494',      'E1495',      'E1496',
      'E1497',      'E1498',      'E1499',      'E1500',      'E1501',      'E1502',      'E1503',      'E1504',      'E1505',      'E1507',
      'E1512',      'E1513',      'E1514',      'E1515',      'E1531',      'E1533',      'E1534',      'E1535',      'E1536',      'E1537',
      'E1538',      'E1539',      'E1540',      'E1542',      'E1543',      'E1544',      'E1545',      'E1546',      'E1547',      'E1549',
      'E1550',      'E1551',      'E1552',      'E1553',      'E1554',      'E1555',      'E1556',      'E1557',      'E1560',      'E1561',
      'E1566',      'E1568',      'E1569',      'E1570',      'E1571',      'E1573',      'E1576',      'E1577',      'E1578',      'E1579',
      'E1580',      'E1581',      'E1582',      'E1583',      'E1584',      'E1585',      'E1586',      'E1587',      'E1588',      'E1589',
      'E1590',      'E1591',      'E1592',      'E1593',      'E1594',      'E1596',      'E1597',      'E1602',      'E1603',      'E1604',
      'E1608',      'E1609',      'E1610',      'E1611',      'E1612',      'E1613',      'E1614',      'E1615',      'E1616',      'E1617',
      'E1618',      'E1619',      'E1620',      'E1621',      'E1622',      'E1623',      'E1624',      'E1625',      'E1628',      'E1629',
      'E1632',      'E1634',      'E1635',      'E1636',      'E1640',      'E1641',      'E1642',      'E1643',      'E1644',      'E1645',
      'E1646',      'E1647',      'E1648',      'E1649',      'E1653',      'E1654',      'E1655',      'E1656',      'E1659',      'E1660',
      'E1661',      'E1664',      'E1665',      'E1666',      'E1667',      'E1668',      'E1669',      'E1676',      'E1677',      'E1678',
      'E1679',      'E1680',      'E1681',      'E1682',      'E1684',      'E1685',      'E1686',      'E1687',      'E1688',      'E1689',
      'E1690',      'E1691',      'E1692',      'E1693',      'E1694',      'E1695',      'E1696',      'E1697',      'E1698',      'E1699',
      'E1700',      'E1701',      'E1702',      'E1703',      'E1704',      'E1705',      'E1707',      'E1709',      'E1710',      'E1712',
      'E1713',      'E1714',      'E1715',      'E1716',      'E1720',      'E1721',      'E1722',      'E1724',      'E1726',      'E1727',
      'E1728',      'E1729',      'E1730',      'E1731',      'E1732',      'E1733',      'E1734',      'E1735',      'E1736',      'E1737',
      'E1738',      'E1739',      'E1743',      'E1745',      'E1747',      'E1748',      'E1749',      'E1750',      'E1751',      'E1752',
      'E1753',      'E1754',      'E1755',      'E1756',      'E1757',      'E1758',      'E1761',      'E1765',      'E1767',      'E1768',
      'E1769',      'E1770',      'E1771',      'E1772',      'E1773',      'E1774',      'E1775',      'E1776',      'E1777',      'E1778',
      'E1779',      'E1780',      'E1781',      'E1782',      'E1783',      'E1784',      'E1785',      'E1786',      'E1787',      'E1790',
      'E1791',      'E1793',      'E1794',      'E1795',      'E1796',      'E1798',      'E1800',      'E1805',      'E1806',      'E1807',
      'E1809',      'E1810',      'E1811',      'E1812',      'E1813',      'E1814',      'E1815',      'E1817',      'E1819',      'E1820',
      'E1822',      'E1823',      'E1824',      'E1825',      'E1826',      'E1827',      'E1829',      'E1830',      'E1831',      'E1832',
      'E1833',      'E1834',      'E1835',      'E1836',      'E1837',      'E1838',      'E1839',      'E1840',      'E1841',      'E1843',
      'E1844',      'E1845',      'E1847',      'E1848',      'E1849',      'E1850',      'E1851',      'E1852',      'E1853',      'E1854',
      'E1855',      'E1856',      'E1857',      'E1858',      'E1860',      'E1862',      'E1863',      'E1864',      'E1865',      'E1866',
      'E1867',      'E1868',      'E1869',      'E1870',      'E1871',      'E1872',      'E1873',      'E1874',      'E1875',      'E1878',
      'E1879',      'E1881',      'E1882',      'E1883',      'E1884',      'E1890',      'E1891',      'E1892',      'E1893',      'E1894',
      'E1895',      'E1896',      'E1897',      'E1898',      'E1899',      'E1900',      'E1902',      'E1903',      'E1905',      'E1906',
      'E1907',      'E1908',      'E1909',      'E1910',      'E1911',      'E1917',      'E1918',      'E1921',      'E1922',      'E1923',
      'E1924',      'E1925',      'E1926',      'E1929',      'E1930',      'E1931',      'E1932',      'E1934',      'E1935',      'E1936',
      'E1937',      'E1938',      'E1941',      'E1942',      'E1943',      'E1944',      'E1945',      'E1946',      'E1947',      'E1949',
      'E1950',      'E1951',      'E1952',      'E1953',      'E1954',      'E1955',      'E1956',      'E1957',      'E1958',      'E1959',
      'E1960',      'E1961',      'E1962',      'E1963',      'E1964',      'E1965',      'E1966',      'E1967',      'E1971',      'E1972',
      'E1973',      'E1974',      'E1975',      'E1976',      'E1977',      'E1978',      'E1979',      'E1980',      'E1981',      'E1982',
      'E1983',      'E1984',      'E1987',      'E1988',      'E1989',      'E1990',      'E1991',      'E1992',      'E1993',      'E1994',
      'E1995',      'E1996',      'E1997',      'E1998',      'E1999',      'E2000',      'E2001',      'E2002',      'E2003',      'E2004',
      'E2005',      'E2006',      'E2007',      'E2011',      'E2013',      'E2014',      'E2015',      'E2016',      'E2018',      'E2019',
      'E2020',      'E2021',      'E2022',      'E2023',      'E2024',      'E2025',      'E2026',      'E2027',      'E2028',      'E2029',
      'E2030',      'E2031',      'E2032',      'E2033',      'E2034',      'E2035',      'E2037',      'E2038',      'E2039',      'E2044',
      'E2048',      'E2049',      'E2050',      'E2051',      'E2053',      'E2054',      'E2055',      'E2056',      'E2057',      'E2058',
      'E2059',      'E2060',      'E2061',      'E2062',      'E2063',      'E2064',      'E2065',      'E2066',      'E2067',      'E2068',
      'E2069',      'E2070',      'E2071',      'E2072',      'E2073',      'E2074',      'E2075',      'E2076',      'E2077',      'E2078',
      'E2079',      'E2080',      'E2081',      'E2082',      'E2083',      'E2084',      'E2085',      'E2086',      'E2087',      'E2088',
      'E2089',      'E2090',      'E2091',      'E2092',      'E2093',      'E2094',      'E2095',      'E2096',      'E2097',      'E2098',
      'E2099',      'E2100',      'E2101',      'E2102',      'E2103',      'E2104',      'E2105',      'E2106',      'E2107',      'E2108',
      'E2109',      'E2110',      'E2111',      'E2112',      'E2113',      'E2114',      'E2115',      'E2116',      'E2117',      'E2118',
      'E2119',      'E2120',      'E2121',      'E2122',      'E2123',      'E2124',      'E2125',      'E2126',      'E2127',      'E2128',
      'E2129',      'E2130',      'E2131',      'E2132',      'E2134',      'E2135',      'E2136',      'E2137',      'E2139',      'E2140',
      'E2141',      'E2142',      'E2143',      'E2144',      'E2145',      'E2146',      'E2149',      'E2150',      'E2151',      'E2152',
      'E2153',      'E2154',      'E2155',      'E2158',      'E2159',      'E2160',      'E2161',      'E2162',      'E2163',      'E2164',
      'E2165',      'E2166',      'E2167',      'E2168',      'E2169',      'E2170',      'E2171',      'E2172',      'E2174',      'E2175',
      'E2176',      'E2177',      'E2178',      'E2185',      'E2186',      'E2187',      'E2190',      'E2191',      'E2192',      'E2193',
      'E2199',      'E2200',      'E2201',      'E2202',      'E2203',      'E2204',      'E2205',      'E2206',      'E2207',      'E2208',
      'E2209',      'E2210',      'E2211',      'E2212',      'E2213',      'E2214',      'E2215',      'E2216',      'E2217',      'E2218',
      'E2219',      'E2221',      'E2222',      'E2223',      'E2224',      'E2225',      'E2226',      'E2227',      'E2228',      'E2229',
      'E2230',      'E2231',      'E2232',      'E2233',      'E2234',      'E2235',      'E2236',      'E2237',      'E2238',      'E2239',
      'E2240',      'E2241',      'E2242',      'E2243',      'E2244',      'E2245',      'E2246',      'E2247',      'E2248',      'E2249',
      'E2250',      'E2251',      'E2252',      'E2253',      'E2254',      'E2255',      'E2256',      'E2257',      'E2258',      'E2259',
      'E2260',      'E2262',      'E2263',      'E2266',      'E2267',      'E2270',      'E2271',      'E2273',      'E2274',      'E2275',
      'E2276',      'E2282',      'E2297',      'E2300',      'E2301',      'E2302',      'E2303',      'E2304',      'E2305',      'E2306',
      'E2307',      'E2308',      'E2309',      'E2310',      'E2311',      'E2312',      'E2315',      'E2316',      'E2317',      'E2318',
      'E2319',      'E2320',      'E2321',      'E2322',      'E2323',      'E2324',      'E2325',      'E2326',      'E2327',      'E2328',
      'E2329',      'E2330',      'E2331',      'E2332',      'E2333',      'E2334',      'E2335',      'E2336',      'E2337',      'E2338',
      'E2339',      'E2340',      'E2341',      'E2342',      'E2343',      'E2344',      'E2345',      'E2346',      'E2347',      'E2348',
      'E2349',      'E2350',      'E2351',      'E2352',      'E2353',      'E2354',      'E2355',      'E2356',      'E2357',      'E2358',
      'E2359',      'E2360',      'E2361',      'E2362',      'E2363',      'E2364',      'E2365',      'E2366',      'E2367',      'E2368',
      'E2369',      'E2370',      'E2371',      'E2372',      'E2373',      'E2374',      'E2375',      'E2376',      'E2377',      'E2378',
      'E2379',      'E2380',      'E2381',      'E2382',      'E2383',      'E2384',      'E2385',      'E2386',      'E2387',      'E2388',
      'E2389',      'E2390',      'E2391',      'E2392',      'E2393',      'E2394',      'E2395',      'E2396',      'E2397',      'E2398',
      'E2399',      'E2400',      'E2401',      'E2402',      'E2403',      'E2404',      'E2405',      'E2406',      'E2407',      'E2408',
      'E2409',      'E2410',      'E2411',      'E2412',      'E2413',      'E2414',      'E2415',      'E2416',      'E2417',      'E2418',
      'E2419',      'E2420',      'E2421',      'E2422',      'E2423',      'E2424',      'E2425',      'E2426',      'E2427',      'E2428',
      'E2429',      'E2430',      'E2431',      'E2432',      'E2433',      'E2434',      'E2435',      'E2436',      'E2437',      'E2438',
      'E2439',      'E2440',      'E2441',      'E2442',      'E2443',      'E2444',      'E2445',      'E2446',      'E2447',      'E2448',
      'E2449',      'E2450',      'E2451',      'E2452',      'E2453',      'E2454',      'E2455',      'E2456',      'E2457',      'E2458',
      'E2459',      'E2460',      'E2461',      'E2462',      'E2463',      'E2464',      'E2465',      'E2466',      'E2467',      'E2468',
      'E2469',      'E2470',      'E2471',      'E2472',      'E2473',      'E2474',      'E2475',      'E2476',      'E2477',      'E2478',
      'E2479',      'E2480',      'E2481',      'E2482',      'E2483',      'E2484',      'E2485',      'E2486',      'E2487',      'E2488',
      'E2489',      'E2490',      'E2491',      'E2492',      'E2493',      'E2494'

********** Non-GPR association enzymes = Met_NonGPR_enz + transport_enz + exchange_enz + DM_sink_enz ----------
      'ER_10FTHF5GLUtl',      'ER_10FTHF5GLUtm',      'ER_10FTHF6GLUtl',      'ER_10FTHF6GLUtm',
      'ER_10FTHF7GLUtl',      'ER_10FTHF7GLUtm',      'ER_10FTHFtl',      'ER_10FTHFtm',
      'ER_24NPHte',      'ER_25HVITD2tin_m',      'ER_25HVITD3tin_m',      'ER_2DR1PP',
      'ER_2MCITt',      'ER_34DHOXPEGt',      'ER_35CGMPtn',      'ER_3DPHBH1',
      'ER_3DPHBH2',      'ER_3HBCOAHLm',      'ER_3MLDAt',      'ER_3MOBt2im',
      'ER_3MOPt2im',      'ER_4ABUTtm',      'ER_4HBZCOAFm',      'ER_4HBZFm',
      'ER_4MOPt2im',      'ER_4NPHSFte',      'ER_4NPHte',      'ER_5ADTSTSTERONESte',
      'ER_5ADTSTSTERONEte',      'ER_5AOPtm',      'ER_5DHFtl',      'ER_5THFtl',
      'ER_5THFtm',      'ER_6DHFtl',      'ER_6DHFtm',      'ER_6HTSTSTERONEte',
      'ER_6HTSTSTERONEtr',      'ER_6THFtl',      'ER_6THFtm',      'ER_7DHCHSTEROLtr',
      'ER_7DHFtl',      'ER_7DHFtm',      'ER_7THFtl',      'ER_7THFtm',
      'ER_AASAD3m',      'ER_ABTD',      'ER_ACACtx',      'ER_ACALDtm',
      'ER_ACCOAtn',      'ER_ACGAGBSIDEtg',      'ER_ACGAGBSIDEtl',      'ER_ACGALK',
      'ER_ACGALK2',      'ER_ACGALtlg',      'ER_ACGALtly',      'ER_ACGAMtly',
      'ER_ACGBGBSIDEtg',      'ER_ACGBGBSIDEtl',      'ER_ACHtn',      'ER_ACNACNGAL14ACGLCGALGLUSIDEte',
      'ER_ACNACNGALGBSIDEte',      'ER_ACNACNGALGBSIDEtg',      'ER_ACNAMtn',      'ER_ACNGALACGLCGAL14ACGLCGALGLUSIDEte',
      'ER_ACNGALACGLCGAL14ACGLCGALGLUSIDEtg',      'ER_ACNMLr',      'ER_ACt2m',      'ER_ACt2r',
      'ER_ACtg',      'ER_ADCim',      'ER_ADNK1m',      'ER_ADRNCOAtx',
      'ER_ADRNt',      'ER_AFLATOXINte',      'ER_AHCYStr',      'ER_AKGtp',
      'ER_AMETr',      'ER_AMPtp',      'ER_ANDRSTRNte',      'ER_ANDRSTRNtr',
      'ER_AQCOBALt',      'ER_ARAB_Lt',      'ER_ARACHCOAtx',      'ER_ARACHDCOAtx',
      'ER_ARACHDtr',      'ER_ARACHt',      'ER_R_group_phosphotase_1',      'ER_R_group_phosphotase_3',
      'ER_ARTFR208',      'ER_ARTPLM3',      'ER_ASCBOX',      'ER_ASCBt',
      'ER_ASPDxt',      'ER_ATP1ter',      'ER_ATP2ter',      'ER_ATPtn',
      'ER_ATPtx',      'ER_B3GALTg',      'ER_BALAtmr',      'ER_BHBt',
      'ER_BHBtm',      'ER_BILDGLCURtr',      'ER_BILIRUBtr',      'ER_BZt',
      'ER_BZtr',      'ER_C226COAtx',      'ER_C226CRNt',      'ER_CAROtr',
      'ER_CBL2OR',      'ER_CBPter',      'ER_CDPDAGtm',      'ER_CHOLPtg',
      'ER_CHOLPtl',      'ER_CHOLtn',      'ER_CITMCOAHm',      'ER_CITMCOALm',
      'ER_CLPNDCOAtx',      'ER_CLPNDt',      'ER_CMPACNAtn',      'ER_CO2ter',
      'ER_CO2tg',      'ER_CO2tm',      'ER_CO2tp',      'ER_COAtg',
      'ER_COAtl',      'ER_COAtn',      'ER_COAtp',      'ER_COAtr',
      'ER_COQ5m',      'ER_CORE5GTg',      'ER_CORE7GTg',      'ER_COUCOAFm',
      'ER_COUMARINte',      'ER_CRMPte',      'ER_CRNCAR3tp',      'ER_CRNtx',
      'ER_CRTSTRNt',      'ER_CRVNCtr',      'ER_CSAPASEly',      'ER_CSBPASEly',
      'ER_CSCPASEly',      'ER_CSDPASEly',      'ER_CSEPASEly',      'ER_CSPG_At',
      'ER_CSPG_Atly',      'ER_CSPG_Btly',      'ER_CSPG_Ct',      'ER_CSPG_Ctly',
      'ER_CSPG_Dt',      'ER_CSPG_Dtly',      'ER_CSPG_Et',      'ER_CSPG_Etly',
      'ER_CTPtn',      'ER_CYSGLTH',      'ER_CYTDK2m',      'ER_D_3AIBt',
      'ER_DADNK',      'ER_DAG_HSter',      'ER_DAGt',      'ER_DALAxt',
      'ER_DATPtn',      'ER_DCK1m',      'ER_DCSPTN1COAtx',      'ER_DCSPTN1t',
      'ER_DCTPtn',      'ER_DECDPtm',      'ER_DEDOLP1_L',      'ER_DEDOLP2_L',
      'ER_DEDOLR_L',      'ER_DESAT22_1p',      'ER_DESAT22_2p',      'ER_DGCHOLte',
      'ER_DGCHOLtx',      'ER_DGK2m',      'ER_DGSNtm',      'ER_DGTPtn',
      'ER_DGULND',      'ER_DHEAStr',      'ER_DHEAtr',      'ER_DHFtl',
      'ER_DHFtm',      'ER_DHPR2',      'ER_DIGALSIDEtl',      'ER_DKMPPD',
      'ER_DM_Asn_X_Ser_Thr_ly_',      'ER_DM_core5_g_',      'ER_DM_core7_g_',      'ER_DM_datp_m_',
      'ER_DM_datp_n_',      'ER_DM_dctp_m_',      'ER_DM_dctp_n_',      'ER_DM_dem2emgacpail_prot_hs_r_',
      'ER_DM_dgpi_prot_hs_r_',      'ER_DM_dgtp_m_',      'ER_DM_dgtp_n_',      'ER_DM_dttp_m_',
      'ER_DM_dttp_n_',      'ER_DM_ethamp_r_',      'ER_DM_gncore2_g_',      'ER_DM_gpi_sig_er_',
      'ER_DM_kdn_c_',      'ER_DM_mem2emgacpail_prot_hs_r_',      'ER_DM_Ser_Thr_ly_',      'ER_DM_Ser_Gly_Ala_X_Gly_ly_',
      'ER_DM_sprm_c_',      'ER_DM_T_antigen_g_',      'ER_DMHPTCRNt',      'ER_DMHPTCRNte',
      'ER_DMNONCOACRNCPT1',      'ER_DMNONCRNt',      'ER_DNADtn',      'ER_DOLMANP_Uter',
      'ER_DOLPMT4_Uer',      'ER_DOPASFt',      'ER_DPCOAtl',      'ER_DPHMBDCm',
      'ER_DPPS',      'ER_DRIBt',      'ER_DSAT',      'ER_DTDPtn',
      'ER_DTTPtn',      'ER_EAFLATOXINte',      'ER_EBASTINEOHte',      'ER_EBASTINEOHtr',
      'ER_EBASTINEte',      'ER_EBASTINEtr',      'ER_EICOSTETt',      'ER_ENGASE2ly',
      'ER_ENGASE3ly',      'ER_ESTRADIOLt',      'ER_ESTRADIOLtr',      'ER_ESTRIOLtr',
      'ER_ESTRONEtr',      'ER_EX_10fthf[e]',      'ER_EX_10fthf5glu[e]',      'ER_EX_10fthf6glu[e]',
      'ER_EX_10fthf7glu[e]',      'ER_EX_13_cis_retnglc[e]',      'ER_EX_24nph[e]',      'ER_EX_2hb[e]',
      'ER_EX_2mcit[e]',      'ER_EX_34dhoxpeg[e]',      'ER_EX_35cgmp[e]',      'ER_EX_3aib[e]',
      'ER_EX_3aib_D[e]',      'ER_EX_3mlda[e]',      'ER_EX_4nph[e]',      'ER_EX_4nphsf[e]',
      'ER_EX_5adtststerone[e]',      'ER_EX_5adtststerones[e]',      'ER_EX_5dhf[e]',      'ER_EX_5fthf[e]',
      'ER_EX_5htrp[e]',      'ER_EX_5mthf[e]',      'ER_EX_5thf[e]',      'ER_EX_6dhf[e]',
      'ER_EX_6htststerone[e]',      'ER_EX_6thf[e]',      'ER_EX_7dhf[e]',      'ER_EX_7thf[e]',
      'ER_EX_acetone[e]',      'ER_EX_ach[e]',      'ER_EX_acnacngal14acglcgalgluside_hs[e]',      'ER_EX_acnacngalgbside_hs[e]',
      'ER_EX_acngalacglcgal14acglcgalgluside_hs[e]',      'ER_EX_adp[e]',      'ER_EX_adprbp[e]',      'ER_EX_adrn[e]',
      'ER_EX_adrnl[e]',      'ER_EX_aflatoxin[e]',      'ER_EX_ala_B[e]',      'ER_EX_ala_D[e]',
      'ER_EX_amp[e]',      'ER_EX_andrstrn[e]',      'ER_EX_aprgstrn[e]',      'ER_EX_aqcobal[e]',
      'ER_EX_arach[e]',      'ER_EX_arachd[e]',      'ER_EX_ascb_L[e]',      'ER_EX_asp_D[e]',
      'ER_EX_atp[e]',      'ER_EX_avite1[e]',      'ER_EX_bhb[e]',      'ER_EX_bildglcur[e]',
      'ER_EX_bilglcur[e]',      'ER_EX_bilirub[e]',      'ER_EX_camp[e]',      'ER_EX_caro[e]',
      'ER_EX_chol[e]',      'ER_EX_cholate[e]',      'ER_EX_chsterol[e]',      'ER_EX_chtn[e]',
      'ER_EX_clpnd[e]',      'ER_EX_cmp[e]',      'ER_EX_coumarin[e]',      'ER_EX_creat[e]',
      'ER_EX_crmp_hs[e]',      'ER_EX_crn[e]',      'ER_EX_crtstrn[e]',      'ER_EX_crvnc[e]',
      'ER_EX_cspg_a[e]',      'ER_EX_cspg_b[e]',      'ER_EX_cspg_c[e]',      'ER_EX_cspg_d[e]',
      'ER_EX_cspg_e[e]',      'ER_EX_dag_hs[e]',      'ER_EX_dcsptn1[e]',      'ER_EX_dgchol[e]',
      'ER_EX_dhdascb[e]',      'ER_EX_dheas[e]',      'ER_EX_dhf[e]',      'ER_EX_dlnlcg[e]',
      'ER_EX_dmhptcrn[e]',      'ER_EX_dopa[e]',      'ER_EX_dopasf[e]',      'ER_EX_eaflatoxin[e]',
      'ER_EX_ebastine[e]',      'ER_EX_ebastineoh[e]',      'ER_EX_eicostet[e]',      'ER_EX_elaid[e]',
      'ER_EX_estradiol[e]',      'ER_EX_estrones[e]',      'ER_EX_fuc13galacglcgal14acglcgalgluside_hs[e]',      'ER_EX_fuc14galacglcgalgluside_hs[e]',
      'ER_EX_fucacgalfucgalacglcgalgluside_hs[e]',      'ER_EX_fucfuc12gal14acglcgalgluside_hs[e]',      'ER_EX_fucfucfucgalacglc13galacglcgal14acglcgalgluside_hs[e]',      'ER_EX_fucfucgalacglcgalgluside_hs[e]',
      'ER_EX_fucgal14acglcgalgluside_hs[e]',      'ER_EX_fucgalfucgalacglcgalgluside_hs[e]',      'ER_EX_fuc_L[e]',      'ER_EX_galacglcgalgbside_hs[e]',
      'ER_EX_galgalfucfucgalacglcgalacglcgal14acglcgalgluside_hs[e]',      'ER_EX_galgalgalthcrm_hs[e]',      'ER_EX_gbside_hs[e]',      'ER_EX_gchola[e]',
      'ER_EX_gdp[e]',      'ER_EX_gluala[e]',      'ER_EX_glyc_S[e]',      'ER_EX_glygn2[e]',
      'ER_EX_glygn4[e]',      'ER_EX_glygn5[e]',      'ER_EX_gmp[e]',      'ER_EX_gq1b_hs[e]',
      'ER_EX_gsn[e]',      'ER_EX_gt1a_hs[e]',      'ER_EX_gthox[e]',      'ER_EX_gthrd[e]',
      'ER_EX_gtp[e]',      'ER_EX_h2o2[e]',      'ER_EX_ha[e]',      'ER_EX_ha_pre1[e]',
      'ER_EX_hco3[e]',      'ER_EX_hcoumarin[e]',      'ER_EX_hdca[e]',      'ER_EX_hdcea[e]',
      'ER_EX_hestratriol[e]',      'ER_EX_hexc[e]',      'ER_EX_hista[e]',      'ER_EX_hom_L[e]',
      'ER_EX_hpdca[e]',      'ER_EX_hspg[e]',      'ER_EX_htaxol[e]',      'ER_EX_i[e]',
      'ER_EX_idp[e]',      'ER_EX_imp[e]',      'ER_EX_ksi[e]',      'ER_EX_ksi_deg1[e]',
      'ER_EX_ksii_core2[e]',      'ER_EX_ksii_core4[e]',      'ER_EX_lac_D[e]',      'ER_EX_Lcystin[e]',
      'ER_EX_leuktrA4[e]',      'ER_EX_leuktrB4[e]',      'ER_EX_leuktrC4[e]',      'ER_EX_leuktrD4[e]',
      'ER_EX_leuktrE4[e]',      'ER_EX_leuktrF4[e]',      'ER_EX_lgnc[e]',      'ER_EX_lneldc[e]',
      'ER_EX_lnlc[e]',      'ER_EX_lnlnca[e]',      'ER_EX_lnlncg[e]',      'ER_EX_lpchol_hs[e]',
      'ER_EX_mag_hs[e]',      'ER_EX_meoh[e]',      'ER_EX_mthgxl[e]',      'ER_EX_n2m2nmasn[e]',
      'ER_EX_nad[e]',      'ER_EX_nadp[e]',      'ER_EX_ncam[e]',      'ER_EX_no[e]',
      'ER_EX_nrpphr[e]',      'ER_EX_nrpphrsf[e]',      'ER_EX_nrvnc[e]',      'ER_EX_o2s[e]',
      'ER_EX_oagd3_hs[e]',      'ER_EX_oagt3_hs[e]',      'ER_EX_ocdca[e]',      'ER_EX_ocdcea[e]',
      'ER_EX_octa[e]',      'ER_EX_oxa[e]',      'ER_EX_pchol_hs[e]',      'ER_EX_pe_hs[e]',
      'ER_EX_peplys[e]',      'ER_EX_pglyc_hs[e]',      'ER_EX_phyt[e]',      'ER_EX_prgstrn[e]',
      'ER_EX_prostgd2[e]',      'ER_EX_prostge1[e]',      'ER_EX_prostge2[e]',      'ER_EX_ps_hs[e]',
      'ER_EX_ptdca[e]',      'ER_EX_retfa[e]',      'ER_EX_retinol[e]',      'ER_EX_retn[e]',
      'ER_EX_Rtotal[e]',      'ER_EX_Rtotal2[e]',      'ER_EX_Rtotal3[e]',      'ER_EX_s2l2fn2m2masn[e]',
      'ER_EX_s2l2n2m2masn[e]',      'ER_EX_spc_hs[e]',      'ER_EX_sph1p[e]',      'ER_EX_sphs1p[e]',
      'ER_EX_srtn[e]',      'ER_EX_strch1[e]',      'ER_EX_strch2[e]',      'ER_EX_strdnc[e]',
      'ER_EX_tagat_D[e]',      'ER_EX_taxol[e]',      'ER_EX_tchola[e]',      'ER_EX_tdchola[e]',
      'ER_EX_tethex3[e]',      'ER_EX_tetpent3[e]',      'ER_EX_tetpent6[e]',      'ER_EX_tettet6[e]',
      'ER_EX_thf[e]',      'ER_EX_thmtp[e]',      'ER_EX_thym[e]',      'ER_EX_thyox_L[e]',
      'ER_EX_tmndnc[e]',      'ER_EX_triodthy[e]',      'ER_EX_triodthysuf[e]',      'ER_EX_tststerone[e]',
      'ER_EX_tststerones[e]',      'ER_EX_ttdca[e]',      'ER_EX_txa2[e]',      'ER_EX_Tyr_ggn[e]',
      'ER_EX_udp[e]',      'ER_EX_ump[e]',      'ER_EX_urate[e]',      'ER_EX_utp[e]',
      'ER_EX_vacc[e]',      'ER_EX_vitd3[e]',      'ER_EX_whhdca[e]',      'ER_EX_whtststerone[e]',
      'ER_EX_xolest_hs[e]',      'ER_EX_xolest2_hs[e]',      'ER_EX_xoltri24[e]',      'ER_EX_xoltri27[e]',
      'ER_EX_xylt[e]',      'ER_F1Atg',      'ER_FADH2tru',      'ER_FADH2tx',
      'ER_FADtru',      'ER_FADtx',      'ER_FALDtly',      'ER_FCOAH',
      'ER_FE2t',      'ER_FE2tm',      'ER_FORMCOAtx',      'ER_FORt2m',
      'ER_FORtr',      'ER_FRDPtr',      'ER_FUC13GALACGLCGAL14ACGLCGALGLUSIDEte',      'ER_FUC13GALACGLCGAL14ACGLCGALGLUSIDEtg',
      'ER_FUC14GALACGLCGALGLUSIDEte',      'ER_FUC14GALACGLCGALGLUSIDEtg',      'ER_FUCACGALFUCGALACGLCGALGLUSIDEte',      'ER_FUCFUC12GAL14ACGLCGALGLUSIDEte',
      'ER_FUCFUC12GAL14ACGLCGALGLUSIDEtg',      'ER_FUCFUCFUCGALACGLC13GALACGLCGAL14ACGLCGALGLUSIDEte',      'ER_FUCFUCFUCGALACGLC13GALACGLCGAL14ACGLCGALGLUSIDEtg',      'ER_FUCFUCGALACGLCGALGLUSIDEte',
      'ER_FUCFUCGALACGLCGALGLUSIDEtg',      'ER_FUCGAL14ACGLCGALGLUSIDEte',      'ER_FUCGAL14ACGLCGALGLUSIDEtg',      'ER_FUCGALFUCGALACGLCGALGLUSIDEte',
      'ER_FUCtly',      'ER_G5SADrm',      'ER_GACPAILter',      'ER_GALACGLCGALGBSIDEte',
      'ER_GALACGLCGALGBSIDEtg',      'ER_GALGALFUCFUCGALACGLCGALACGLCGAL14ACGLCGALGLUSIDEte',      'ER_GALGALFUCFUCGALACGLCGALACGLCGAL14ACGLCGALGLUSIDEtg',      'ER_GALGALGALTHCRMte',
      'ER_GALGALGALTHCRMtg',      'ER_GALGLUSIDEtg',      'ER_GALSIDEtl',      'ER_GALtly',
      'ER_GBSIDEte',      'ER_GBSIDEtl',      'ER_GCHOLAte',      'ER_GDPtg',
      'ER_GGT_L',      'ER_GGT6',      'ER_GLACter',      'ER_GLCMter',
      'ER_GLCter',      'ER_GLCtly',      'ER_GLCURter',      'ER_GLNtm',
      'ER_GLUt7l',      'ER_GLXtm',      'ER_GLXtp',      'ER_GLYC3Ptm',
      'ER_GLYCK2',      'ER_GLYCLTDym',      'ER_GLYCLTtp',      'ER_GLYC_St',
      'ER_GLYCtm',      'ER_GLYtm',      'ER_GLYtp',      'ER_GMPtg',
      'ER_GMPtn',      'ER_GQ1Bte',      'ER_GT1Ate',      'ER_GTHDH',
      'ER_GTHRDtr',      'ER_GULN3D',      'ER_GULNDer',      'ER_GULNter',
      'ER_H2O2t',      'ER_H2O2tly',      'ER_H2O2tm',      'ER_H2O2tp',
      'ER_H2Oter',      'ER_H2Otg',      'ER_H2Otly',      'ER_H2Otn',
      'ER_H2Otp',      'ER_HAtly',      'ER_HCOUMARINte',      'ER_HDCAter',
      'ER_HDD2COAtx',      'ER_HESTRATRIOLte',      'ER_HESTRATRIOLtr',      'ER_HEXCCOAtx',
      'ER_HEXCt',      'ER_HMGCOAtm',      'ER_HMGCOAtx',      'ER_HPDCAt',
      'ER_HPYRDC',      'ER_HPYRDCm',      'ER_HPYRtp',      'ER_HSAT1ly',
      'ER_HSAT2ly',      'ER_HSAT3ly',      'ER_HSAT4ly',      'ER_HSPASEly',
      'ER_HSPGt',      'ER_HSPGtly',      'ER_HTAXOLte',      'ER_Htg',
      'ER_Htr',      'ER_Htx',      'ER_ILEt5m',      'ER_IPDPtx',
      'ER_KDNH',      'ER_KSII_CORE2t',      'ER_KSII_CORE2tly',      'ER_KSII_CORE4t',
      'ER_KSII_CORE4tly',      'ER_KSItly',      'ER_KYNATESYN',      'ER_LEUKTRB4tr',
      'ER_LEUKTRD4t',      'ER_LEUt5m',      'ER_LGNCCOAtx',      'ER_LINKDEG1ly',
      'ER_LINKDEG2ly',      'ER_LINKDEG3ly',      'ER_LINKDEG4ly',      'ER_LNELDCt',
      'ER_LPCHOLt',      'ER_LTC4CP',      'ER_LTD4DP',      'ER_MAGt',
      'ER_MANtly',      'ER_MCITS',      'ER_MDRPD',      'ER_MEOHt2',
      'ER_MEOHtly',      'ER_MGSA',      'ER_MGSA2',      'ER_MI134P4P',
      'ER_MI13PP',      'ER_MI14P4P',      'ER_MINOHPtn',      'ER_MTHGXLt',
      'ER_N2M2NMASNtly',      'ER_N4Tg',      'ER_NADHtpu',      'ER_NADHtru',
      'ER_NADPHtru',      'ER_NADPHtxu',      'ER_NADPtru',      'ER_NADPtxu',
      'ER_NADtn',      'ER_NADtru',      'ER_NAGAlby',      'ER_NAGLCAly',
      'ER_NCAMUP',      'ER_NH4tn',      'ER_NH4tp',      'ER_NICRNS',
      'ER_NICRNTtn',      'ER_NMNtn',      'ER_NOt',      'ER_NRPPHRSFt',
      'ER_NRVNCCOAtx',      'ER_O2St',      'ER_O2Stm',      'ER_O2ter',
      'ER_O2tm',      'ER_O2tn',      'ER_O2tp',      'ER_OAGD3te',
      'ER_OAGD3tg',      'ER_OAGT3te',      'ER_OCCOAtm',      'ER_OCCOAtx',
      'ER_OCTAt',      'ER_ODECOAtx',      'ER_OXAtp',      'ER_P450LTB4r',
      'ER_PAFS',      'ER_PAIL_HStn',      'ER_PAIL45P_HStn',      'ER_PAIL4P_HStn',
      'ER_PAN4PP',      'ER_PAPtg',      'ER_PCHOL_HSter',      'ER_PCHOL_HStg',
      'ER_PE_HSter',      'ER_PEt',      'ER_PGLYCt',      'ER_PHEMEtm',
      'ER_PHYTt',      'ER_PI45P4P',      'ER_PI4P5Kn',      'ER_PI4PP',
      'ER_PI5P4Kn',      'ER_PIK3n',      'ER_PIK4n',      'ER_PIK5n',
      'ER_PItg',      'ER_PItn',      'ER_PMTCOAtx',      'ER_PPAn',
      'ER_PPAt',      'ER_PPAtm',      'ER_PPItr',      'ER_PPItx',
      'ER_PPMI12346Ptn',      'ER_PPPG9tm',      'ER_PRGSTRNt',      'ER_PRISTANALtx',
      'ER_PRISTCOAtx',      'ER_PRISTtx',      'ER_PROSTGH2t',      'ER_PROSTGI2t',
      'ER_PROtm',      'ER_PSt3',      'ER_PTDCAt',      'ER_QUILSYN',
      'ER_RADH',      'ER_RADH2',      'ER_RAI1',      'ER_RAI2',
      'ER_RAtn',      'ER_RETHe',      'ER_RETI1',      'ER_RETI2',
      'ER_RETI3',      'ER_RETNGLCt2',      'ER_RETNGLCt2r',      'ER_RETNt',
      'ER_RETNtr2',      'ER_RIBt',      'ER_RIBt2',      'ER_RTOTAL2t',
      'ER_RTOTALt',      'ER_Rtotaltl',      'ER_S2L2FN2M2MASNtly',      'ER_S2L2N2M2MASNtly',
      'ER_S2TASE4ly',      'ER_S2TASE5ly',      'ER_S3TASE1ly',      'ER_S3TASE2ly',
      'ER_S3TASE3ly',      'ER_S4T4g',      'ER_S4T5g',      'ER_Ser_Thrtg',
      'ER_SERtp',      'ER_sink_citr[c]',      'ER_sink_pre_prot[r]',      'ER_SO4tl',
      'ER_SPC_HSt',      'ER_SPH1Pte',      'ER_SPHINGStl',      'ER_SPHMYLNtg',
      'ER_SPHMYLNtl',      'ER_SPHS1Pte',      'ER_SPMDOX',      'ER_STCOAtx',
      'ER_STRDNCt',      'ER_SUCCtp',      'ER_T4HCINNMFM',      'ER_TAGAT_Dt',
      'ER_TAXOLte',      'ER_TCHOLAte',      'ER_TDCHOLAte',      'ER_TETHEX3COAtx',
      'ER_TETHEX3t',      'ER_TETPENT3COAtx',      'ER_TETPENT3t',      'ER_TETPENT6COAtx',
      'ER_TETPENT6t',      'ER_TETTET6COAtx',      'ER_TETTET6t',      'ER_THCHOLSTOICtm',
      'ER_THFtl',      'ER_THFtm',      'ER_TMNDNCCOAtx',      'ER_TMNDNCt',
      'ER_TRIODTHYSUFt',      'ER_TRIOK',      'ER_TSTSTERONESte',      'ER_TSTSTERONEt',
      'ER_TSTSTERONEtr',      'ER_TXA2te',      'ER_TXA2tr',      'ER_UAGALDP',
      'ER_UDPACGALtl',      'ER_UDPGLCAtg',      'ER_UDPtl',      'ER_UDPXYLter',
      'ER_UMPtr',      'ER_URATEt',      'ER_UROLACer',      'ER_UTPtn',
      'ER_VACCt',      'ER_VALt5m',      'ER_VITD3t',      'ER_WHHDCAte',
      'ER_WHTSTSTERONEte',      'ER_XOL27OHtm',      'ER_XOL7AONEtr',      'ER_XOLEST2te',
      'ER_XOLESTte',      'ER_XOLTRI24te',      'ER_XOLTRI27tc',      'ER_XOLTRI27te',
      'ER_XSERtg',      'ER_XYLTD_Dr',      'ER_XYLtly',      'ER_XYLTt',
      'ER_EX_4abutn[e]',      'ER_EX_acmana[e]',      'ER_EX_ahdt[e]',      'ER_EX_ctp[e]',
      'ER_EX_dgmp[e]',      'ER_EX_dgtp[e]',      'ER_EX_dha[e]',      'ER_EX_dhap[e]',
      'ER_EX_dtmp[e]',      'ER_EX_dttp[e]',      'ER_EX_fald[e]',      'ER_EX_HC01104[e]',
      'ER_EX_HC01361[e]',      'ER_EX_HC01440[e]',      'ER_EX_HC01441[e]',      'ER_EX_HC01444[e]',
      'ER_EX_HC01446[e]',      'ER_EX_HC01577[e]',      'ER_EX_HC01700[e]',      'ER_EX_HC02160[e]',
      'ER_EX_HC02161[e]',      'ER_EX_itp[e]',      'ER_EX_orot[e]',      'ER_EX_prpp[e]',
      'ER_r0002',      'ER_r0156',      'ER_r0179',      'ER_r0236',
      'ER_r0330',      'ER_r0365',      'ER_r0480',      'ER_r0527',
      'ER_r0647',      'ER_r0784',      'ER_r0788',      'ER_r0789',
      'ER_r0809',      'ER_r0818',      'ER_r0838',      'ER_r0839',
      'ER_r0841',      'ER_r0853',      'ER_r0859',      'ER_r0886',
      'ER_r0892',      'ER_r0899',      'ER_r0926',      'ER_r0927',
      'ER_r0936',      'ER_r0937',      'ER_r0944',      'ER_r0950',
      'ER_r0962',      'ER_r0968',      'ER_r0970',      'ER_r0973',
      'ER_r0974',      'ER_r0986',      'ER_r0987',      'ER_r0989',
      'ER_r0990',      'ER_r0994',      'ER_r1000',      'ER_r1003',
      'ER_r1011',      'ER_r1012',      'ER_r1013',      'ER_r1014',
      'ER_r1018',      'ER_r1019',      'ER_r1030',      'ER_r1050',
      'ER_r1088',      'ER_r1106',      'ER_r1109',      'ER_r1116',
      'ER_r1117',      'ER_r1134',      'ER_r1146',      'ER_r1148',
      'ER_r1150',      'ER_r1159',      'ER_r1291',      'ER_r1292',
      'ER_r1298',      'ER_r1299',      'ER_r1301',      'ER_r1302',
      'ER_r1303',      'ER_r1304',      'ER_r1318',      'ER_r1364',
      'ER_r1365',      'ER_r1367',      'ER_r1368',      'ER_r1377',
      'ER_r1384',      'ER_r1400',      'ER_r1421',      'ER_r1423',
      'ER_r1435',      'ER_r1436',      'ER_r1437',      'ER_r1459',
      'ER_r1467',      'ER_r1468',      'ER_r1493',      'ER_r1512',
      'ER_r2508',      'ER_r2509',      'ER_r2510',      'ER_r2511',
      'ER_r2514',      'ER_r2519',      'ER_r2521',      'ER_r2537',
      'ER_r2538',      'ER_r2539',      'ER_EX_so3[e]',      'ER_EX_sprm[e]',
      'ER_RE0124C',      'ER_RE0452M',      'ER_RE0453C',      'ER_RE0570C',
      'ER_RE0571C',      'ER_RE0574C',      'ER_RE0575C',      'ER_RE0576C',
      'ER_RE0581C',      'ER_RE0583C',      'ER_RE0691C',      'ER_RE0830C',
      'ER_RE0908C',      'ER_RE0915C',      'ER_RE0916C',      'ER_RE0918C',
      'ER_RE0958C',      'ER_RE1234C',      'ER_RE1303C',      'ER_RE1342C',
      'ER_RE1447N',      'ER_RE1448N',      'ER_RE1530C',      'ER_RE1711C',
      'ER_RE1804C',      'ER_RE1807C',      'ER_RE1826C',      'ER_RE1836C',
      'ER_RE1897C',      'ER_RE1898C',      'ER_RE1915C',      'ER_RE1916C',
      'ER_RE1919C',      'ER_RE1921C',      'ER_RE1978C',      'ER_RE2069C',
      'ER_RE2080C',      'ER_RE2112C',      'ER_RE2235C',      'ER_RE2327C',
      'ER_RE2407C',      'ER_RE2410C',      'ER_RE2426C',      'ER_RE2526C',
      'ER_RE2562C',      'ER_RE2563C',      'ER_RE2625C',      'ER_RE2626C',
      'ER_RE2655R',      'ER_RE2659R',      'ER_RE2666C',      'ER_RE2677C',
      'ER_RE2677N',      'ER_RE2799C',      'ER_RE2814R',      'ER_RE2974N',
      'ER_RE3011R',      'ER_RE3016R',      'ER_RE3017R',      'ER_RE3033C',
      'ER_RE3044C',      'ER_RE3050R',      'ER_RE3052C',      'ER_RE3073X',
      'ER_RE3104C',      'ER_RE3106C',      'ER_RE3112C',      'ER_RE3113C',
      'ER_RE3119C',      'ER_RE3121C',      'ER_RE3122C',      'ER_RE3152C',
      'ER_RE3153C',      'ER_RE3154C',      'ER_RE3162C',      'ER_RE3163C',
      'ER_RE3164C',      'ER_RE3166C',      'ER_RE3167C',      'ER_RE3168C',
      'ER_RE3169C',      'ER_RE3171C',      'ER_RE3172C',      'ER_RE3173C',
      'ER_RE3175C',      'ER_RE3176C',      'ER_RE3180C',      'ER_RE3181C',
      'ER_RE3227C',      'ER_RE3228C',      'ER_RE3229C',      'ER_RE3230C',
      'ER_RE3231C',      'ER_RE3232C',      'ER_RE3234C',      'ER_RE3235C',
      'ER_RE3236C',      'ER_RE3237C',      'ER_RE3238C',      'ER_RE3239C',
      'ER_RE3242C',      'ER_RE3243C',      'ER_RE3244C',      'ER_RE3245C',
      'ER_RE3267E',      'ER_RE3270C',      'ER_RE3272N',      'ER_RE3286C',
      'ER_RE3288C',      'ER_RE3347C',      'ER_RE3352C',      'ER_RE3422C',
      'ER_RE3430M',      'ER_RE3430X',      'ER_RE3434C',      'ER_RE3435C',
      'ER_RE3436C',      'ER_RE3437C',      'ER_RE3475C',      'ER_RE3485C',
      'ER_RE3493C',      'ER_RE3496C',      'ER_RE3513C',      'ER_RE3513R',
      'ER_RE3525M',      'ER_RE3526M',      'ER_RE3556C',      'ER_RE3565C',
      'ER_RE3566C',      'ER_RE3567C',      'ER_RE3568C',      'ER_RE3570C',
      'ER_RE3587C',      'ER_RE3637C',      'ER_EX_prostgh2[e]',      'ER_EX_prostgi2[e]',
      'ER_EX_cdp[e]',      'ER_EX_dtdp[e]',      'ER_EX_HC00955[e]',      'ER_EX_citr_L[e]',
      'ER_EX_C02470[e]',      'ER_EX_C02528[e]',      'ER_EX_HC02195[e]',      'ER_EX_HC02196[e]',
      'ER_EX_HC02220[e]',      'ER_EX_HC02191[e]',      'ER_EX_HC02194[e]',      'ER_EX_HC02197[e]',
      'ER_EX_HC02198[e]',      'ER_EX_HC02187[e]',      'ER_EX_HC02180[e]',      'ER_EX_HC02202[e]',
      'ER_EX_HC02203[e]',      'ER_EX_HC02204[e]',      'ER_EX_HC02205[e]',      'ER_EX_HC02206[e]',
      'ER_EX_HC02207[e]',      'ER_EX_HC02213[e]',      'ER_EX_HC02217[e]',      'ER_EX_maltpt[e]',
      'ER_EX_CE2915[e]',      'ER_EX_CE4722[e]',      'ER_EX_CE2916[e]',      'ER_EX_CE4723[e]',
      'ER_EX_CE2917[e]',      'ER_EX_CE4724[e]',      'ER_EX_malthp[e]',      'ER_EX_CE2839[e]',
      'ER_EX_CE2838[e]',      'ER_EX_CE1950[e]',      'ER_EX_cynt[e]',      'ER_EX_CE5786[e]',
      'ER_EX_CE5788[e]',      'ER_EX_CE5789[e]',      'ER_EX_CE5797[e]',      'ER_EX_CE5798[e]',
      'ER_EX_CE5867[e]',      'ER_EX_CE5868[e]',      'ER_EX_CE5869[e]',      'ER_EX_CE4633[e]',
      'ER_EX_CE4881[e]',      'ER_EX_crm_hs[e]',      'ER_EX_CE0074[e]',      'ER_EX_cdpea[e]',
      'ER_EX_12dgr120[e]',      'ER_biomass_reaction',      'ER_ADPACDAc',      'ER_ADPACtx',
      'ER_BCRNe',      'ER_sink_c101coa[c]',      'ER_C101CRNe',      'ER_C10CRNe',
      'ER_C12DCACT',      'ER_C12DCe',      'ER_C16DCe',      'ER_C3DCe',
      'ER_C4CRNe',      'ER_C4DCe',      'ER_C6CRNe',      'ER_sink_c81coa[c]',
      'ER_C81CRNe',      'ER_C8CRNe',      'ER_C8DCe',      'ER_sink_dd2coa[c]',
      'ER_DDCRNe',      'ER_DDECCRNe',      'ER_DDECE1CRNe',      'ER_DECCRNe',
      'ER_sink_decdicoa[c]',      'ER_DECDICRNe',      'ER_DOCOSACTDe',      'ER_DOCOSACTDr',
      'ER_EX_3bcrn[e]',      'ER_EX_3ddcrn[e]',      'ER_EX_3deccrn[e]',      'ER_EX_3octdec2crn[e]',
      'ER_EX_3octdece1crn[e]',      'ER_EX_3tdcrn[e]',      'ER_EX_c101crn[e]',      'ER_EX_c10crn[e]',
      'ER_EX_c12dc[e]',      'ER_EX_c16dc[e]',      'ER_EX_c3dc[e]',      'ER_EX_c4crn[e]',
      'ER_EX_c4dc[e]',      'ER_EX_c51crn[e]',      'ER_EX_c6crn[e]',      'ER_EX_c81crn[e]',
      'ER_EX_c8crn[e]',      'ER_EX_c8dc[e]',      'ER_EX_ddece1crn[e]',      'ER_EX_ddecrn[e]',
      'ER_EX_decdicrn[e]',      'ER_EX_doco13ac[e]',      'ER_EX_docosac[e]',      'ER_EX_tetdec2crn[e]',
      'ER_EX_tetdece1crn[e]',      'ER_EX_dca[e]',      'ER_FAOXC5C5OHm',      'ER_HEXDIACtr',
      'ER_HOCTDEC2CRNe',      'ER_HTDCRNe',      'ER_OCTDECE1CRNe',      'ER_sink_octdececoa[c]',
      'ER_SEBACACT',      'ER_SEBACIDtx',      'ER_SUBEACtx',      'ER_SUBERICACT',
      'ER_SUCCACT',      'ER_TDCRNe',      'ER_sink_tetdec2coa[c]',      'ER_TETDEC2CRNe',
      'ER_sink_tetdece1coa[c]',      'ER_TETDECE1CRNe',      'ER_TIGCRNe',      'ER_BTNTe',
      'ER_SBTle',      'ER_1a25DHVITD3TRn',      'ER_3AIB_Dtm',      'ER_5MTHFt2le',
      'ER_ADNK4',      'ER_AHCYStd',      'ER_ALA-DTDe',      'ER_AMETtd',
      'ER_ARACHFATPc',      'ER_ASPDTDe',      'ER_ASPte',      'ER_CHSTEROLtrc',
      'ER_CRNrtx',      'ER_Coqe',      'ER_DATPtm',      'ER_DCTPtm',
      'ER_DGTPtm',      'ER_DHAPtc',      'ER_DM_1a25dhvitd3[n]',      'ER_DM_taur[c]',
      'ER_DM_pmtcoa[r]',      'ER_DTTPtm',      'ER_EX_4hpro[e]',      'ER_EX_carn[e]',
      'ER_EX_dchac[e]',      'ER_EX_sfcys[e]',      'ER_EX_cysam[e]',      'ER_EX_fmn[e]',
      'ER_EX_oh1[e]',      'ER_EX_ptth[e]',      'ER_EX_q10[e]',      'ER_EX_q10h2[e]',
      'ER_FOLt2le',      'ER_FRDPtcr',      'ER_GLU5SAtmc',      'ER_GLYC3PFADm',
      'ER_GLYCTDle',      'ER_INSK',      'ER_KHte',      'ER_LACLt',
      'ER_MAL_Ltx',      'ER_MDHx',      'ER_NADtm',      'ER_NADtx',
      'ER_PNTEHe',      'ER_PPItm',      'ER_PRO_Dtde',      'ER_PTCRTD',
      'ER_Q10H2e',      'ER_SFCYSc',      'ER_SFCYSe',      'ER_sink_5hpet[c]',
      'ER_TAURCHAe',      'ER_TTDCAFATPc',      'ER_q10h2tc',      'ER_q10tm',
      'ER_34HPPte',      'ER_3MOBte',      'ER_3MOPte',      'ER_4MOPte',
      'ER_5MTAte',      'ER_AHCYSte',      'ER_AICARte',      'ER_CBASPte',
      'ER_DM_4hrpo',      'ER_DM_Lcystin',      'ER_DM_fol',      'ER_DM_pnto_R',
      'ER_EX_34hpp[e]',      'ER_EX_3mob[e]',      'ER_EX_3mop[e]',      'ER_EX_4mop[e]',
      'ER_EX_5mta[e]',      'ER_EX_ahcys[e]',      'ER_EX_aicar[e]',      'ER_EX_cbasp[e]',
      'ER_MAL_Lte',      'ER_IDOURte',      'ER_EX_idour[e]',      'ER_GLYALDtr',
      'ER_PEPtr',      'ER_GUDACtr',      'ER_GUDACtr2',      'ER_KYNATEtr2',
      'ER_3ANTHRNtr',      'ER_2PGtr',      'ER_CARNtr',      'ER_CHOLPtr',
      'ER_DCMPtr',      'ER_DHAPtr',      'ER_ETHAMPtr',      'ER_FUMtr',
      'ER_GLCURtr',      'ER_ICITtr',      'ER_L2AADPtr',      'ER_XANtr',
      'ER_XMPtr',      'ER_XTSNtr',      'ER_3PGtr',      'ER_UDPGLCURtr',
      'ER_IMPtr',      'ER_GLYC3tr',      'ER_NICRNtr',      'ER_OROT5Ptr',
      'ER_EX_2pg[e]',      'ER_EX_5hoxindoa[e]',      'ER_EX_cholp[e]',      'ER_EX_dcmp[e]',
      'ER_EX_ethamp[e]',      'ER_EX_glyald[e]',      'ER_EX_gudac[e]',      'ER_EX_hcys_L[e]',
      'ER_EX_icit[e]',      'ER_EX_kynate[e]',      'ER_EX_L2aadp[e]',      'ER_EX_Lkynr[e]',
      'ER_EX_pep[e]',      'ER_EX_xmp[e]',      'ER_EX_xtsn[e]',      'ER_EX_3pg[e]',
      'ER_EX_3hanthrn[e]',      'ER_EX_udpglcur[e]',      'ER_EX_nicrnt[e]',      'ER_EX_orot5p[e]',
      'ER_EX_glyc3p[e]',      'ER_ARGSUCte',      'ER_EX_argsuc[e]',      'ER_EX_acrn[e]',
      'ER_EX_pcrn[e]',      'ER_EX_lneldccrn[e]',      'ER_EX_odecrn[e]',      'ER_EX_stcrn[e]',
      'ER_EX_pmtcrn[e]',      'ER_EX_hdcecrn[e]',      'ER_DM_ascb_L[c]',      'ER_biomass_maintenance_noTrTr',
      'ER_ADPOHc',      'ER_PHLAC',      'ER_3MHISc',      'ER_HMCRNc',
      'ER_CE4843HYDc',      'ER_HXCOAc',      'ER_HDCAc',      'ER_ELAIDCRNte',
      'ER_LNLCCRNNAt',      'ER_PHLACHt',      'ER_TTDCRNNAt',      'ER_15HPETATP',
      'ER_15KPROSTGF2t',      'ER_2OXOADPt',      'ER_34HPLte',      'ER_3HMPtd',
      'ER_3HPPt',      'ER_3MHISt1',      'ER_3MHISt2',      'ER_3MHISt3',
      'ER_3MOXTYRt',      'ER_3UIBtd',      'ER_4TMEABUTNt1',      'ER_4TMEABUTNt2',
      'ER_56DTHMt',      'ER_56DTHMtd',      'ER_56DURAt',      'ER_56DURAtd',
      'ER_5AOPt',      'ER_7DHCHSTEROLtd',      'ER_ACGLUtd',      'ER_ACLYSt',
      'ER_ACLYStm',      'ER_ADPACtd',      'ER_ADPOHt',      'ER_ALLTNt',
      'ER_C02712tm',      'ER_C03990tr',      'ER_C04483t2',      'ER_C04717td',
      'ER_C04805td',      'ER_C05463t2',      'ER_C05953t',      'ER_C05957t',
      'ER_C05957td',      'ER_C06314t',      'ER_C06315t',      'ER_C06439t',
      'ER_C11695td',      'ER_C14768td',      'ER_C14769td1',      'ER_EX_C14769[e]',
      'ER_C14770ATP',      'ER_C14771ATP',      'ER_C14825td',      'ER_C14826td',
      'ER_CE1273t2',      'ER_CE2510t',      'ER_CE2513td',      'ER_CE2537ATP',
      'ER_CE4843td',      'ER_CE5304t',      'ER_CE6247t',      'ER_DODECANACtd',
      'ER_ELAIDCRNtd',      'ER_EX_12HPET[e]',      'ER_EX_15HPET[e]',      'ER_EX_15kprostgf2[e]',
      'ER_EX_2oxoadp[e]',      'ER_EX_34hpl[e]',      'ER_EX_3hmp[e]',      'ER_EX_3hpp[e]',
      'ER_EX_3mhis[e]',      'ER_EX_3uib[e]',      'ER_EX_4tmeabutn[e]',      'ER_EX_56dthm[e]',
      'ER_EX_56dura[e]',      'ER_EX_7dhchsterol[e]',      'ER_EX_aclys[e]',      'ER_EX_adpac[e]',
      'ER_EX_adpoh[e]',      'ER_EX_amet[e]',      'ER_EX_aracheth[e]',      'ER_EX_C04717[e]',
      'ER_EX_C04805[e]',      'ER_EX_C05957[e]',      'ER_EX_C06314[e]',      'ER_EX_C06315[e]',
      'ER_EX_C11695[e]',      'ER_EX_C14768[e]',      'ER_EX_C14770[e]',      'ER_EX_C14771[e]',
      'ER_EX_C14825[e]',      'ER_EX_C14826[e]',      'ER_EX_CE2537[e]',      'ER_EX_CE4843[e]',
      'ER_EX_CE5304[e]',      'ER_EX_CE6247[e]',      'ER_EX_CE7172[e]',      'ER_EX_didecaeth[e]',
      'ER_EX_diholineth[e]',      'ER_EX_docohxeth[e]',      'ER_EX_docteteth[e]',      'ER_EX_dodecanac[e]',
      'ER_EX_elaidcrn[e]',      'ER_EX_forglu[e]',      'ER_EX_HC00900[e]',      'ER_EX_hepdeceth[e]',
      'ER_EX_hexdeceeth[e]',      'ER_EX_hexdiac[e]',      'ER_EX_hgentis[e]',      'ER_EX_hmcr[e]',
      'ER_EX_hxcoa[e]',      'ER_EX_leuktrB4wcooh[e]',      'ER_EX_leuktrB4woh[e]',      'ER_EX_lineth[e]',
      'ER_EX_lnlccrn[e]',      'ER_EX_lthstrl[e]',      'ER_EX_mev_R[e]',      'ER_EX_mi1p_D[e]',
      'ER_EX_nwharg[e]',      'ER_EX_oleth[e]',      'ER_EX_pailar_hs[e]',      'ER_EX_pailpalm_hs[e]',
      'ER_EX_pchol2linl_hs[e]',      'ER_EX_pchol2ole_hs[e]',      'ER_EX_pchol2palm_hs[e]',      'ER_EX_pchol2ste_hs[e]',
      'ER_EX_pcholar_hs[e]',      'ER_EX_pcholdoc_hs[e]',      'ER_EX_pcholeic_hs[e]',      'ER_EX_pcholet_hs[e]',
      'ER_EX_pcholhep_hs[e]',      'ER_EX_pchollinl_hs[e]',      'ER_EX_pcholmyr_hs[e]',      'ER_EX_pcholn15_hs[e]',
      'ER_EX_pcholn183_hs[e]',      'ER_EX_pcholn1836_hs[e]',      'ER_EX_pcholn19_hs[e]',      'ER_EX_pcholn201_hs[e]',
      'ER_EX_pcholn203_hs[e]',      'ER_EX_pcholn204_hs[e]',      'ER_EX_pcholn205_hs[e]',      'ER_EX_pcholn224_hs[e]',
      'ER_EX_pcholn225_hs[e]',      'ER_EX_pcholn2254_hs[e]',      'ER_EX_pcholn226_hs[e]',      'ER_EX_pcholn24_hs[e]',
      'ER_EX_pcholn261_hs[e]',      'ER_EX_pcholn28_hs[e]',      'ER_EX_pcholn281_hs[e]',      'ER_EX_pcholole_hs[e]',
      'ER_EX_pcholpalm_hs[e]',      'ER_EX_pcholpalme_hs[e]',      'ER_EX_pcholste_hs[e]',      'ER_EX_pcollg5hlys[e]',
      'ER_EX_pe12_hs[e]',      'ER_EX_pe13_hs[e]',      'ER_EX_pe14_hs[e]',      'ER_EX_pe15_hs[e]',
      'ER_EX_pe161_hs[e]',      'ER_EX_pe17_hs[e]',      'ER_EX_pe203_hs[e]',      'ER_EX_pe224_hs[e]',
      'ER_EX_pe226_hs[e]',      'ER_EX_pe2linl_hs[e]',      'ER_EX_pear_hs[e]',      'ER_EX_pedh203_hs[e]',
      'ER_EX_pelinl_hs[e]',      'ER_EX_pendecaeth[e]',      'ER_EX_peole_hs[e]',      'ER_EX_pepalm_hs[e]',
      'ER_EX_peste_hs[e]',      'ER_EX_pmeth[e]',      'ER_EX_saccrp_L[e]',      'ER_EX_sebacid[e]',
      'ER_EX_sphmyln180241_hs[e]',      'ER_EX_sphmyln18114_hs[e]',      'ER_EX_sphmyln18115_hs[e]',      'ER_EX_sphmyln18116_hs[e]',
      'ER_EX_sphmyln181161_hs[e]',      'ER_EX_sphmyln18117_hs[e]',      'ER_EX_sphmyln18118_hs[e]',      'ER_EX_sphmyln181181_hs[e]',
      'ER_EX_sphmyln18120_hs[e]',      'ER_EX_sphmyln181201_hs[e]',      'ER_EX_sphmyln18121_hs[e]',      'ER_EX_sphmyln18122_hs[e]',
      'ER_EX_sphmyln181221_hs[e]',      'ER_EX_sphmyln18123_hs[e]',      'ER_EX_sphmyln1824_hs[e]',      'ER_EX_sphmyln1825_hs[e]',
      'ER_EX_steeth[e]',      'ER_EX_subeac[e]',      'ER_EX_tetdecaeth[e]',      'ER_EX_tmlys[e]',
      'ER_EX_trideceth[e]',      'ER_EX_ttdcrn[e]',      'ER_EX_urcan[e]',      'ER_EX_wharachd[e]',
      'ER_FORGLUt',      'ER_GALTt',      'ER_LYSACm',      'ER_GLYC_Rt',
      'ER_GLYCLTtd',      'ER_HC00900t1',      'ER_HC00900t2',      'ER_HC00900t3',
      'ER_HC00900t4',      'ER_HC02149td',      'ER_HEXDIACtd',      'ER_HGENTISt',
      'ER_HMCRNt',      'ER_HXCOAm',      'ER_HXCOAte',      'ER_HXCOAtx',
      'ER_HXCOAx',      'ER_IND3ACt',      'ER_LCYSTt',      'ER_LEUKTRB4WCOOHt',
      'ER_LEUKTRB4WOHt',      'ER_LEUKTRB4WOHtr',      'ER_LNLCCRNtd',      'ER_LTHSTRLt',
      'ER_MEV_Rt',      'ER_MI1Pt',      'ER_NWHARGtd',      'ER_OAAt',
      'ER_pac',      'ER_PCOLLG5HLYStd',      'ER_PROSTGI2c',      'ER_PSERtr',
      'ER_SACCRP_Lte',      'ER_SACCRP_Ltm',      'ER_SEBACIDtd',      'ER_SUBEACtd',
      'ER_TMLYStd',      'ER_TXB2c',      'ER_URCANt',      'ER_WHARACHDtr',
      'ER_EX_estriol[e]',      'ER_DDCAFATP',      'ER_EX_3moxtyr[e]',      'ER_EX_5aop[e]',
      'ER_EX_acglu[e]',      'ER_EX_alltn[e]',      'ER_EX_CE2510[e]',      'ER_EX_ddca[e]',
      'ER_EX_glyc_R[e]',      'ER_EX_glyclt[e]',      'ER_EX_Lcyst[e]',      'ER_EX_oaa[e]',
      'ER_EX_pac[e]',      'ER_EX_phlac[e]',      'ER_EX_pser_L[e]',      'ER_EX_ttdcea[e]',
      'ER_TTDCEAt',      'ER_DCHOLESTANCOAc',      'ER_XOL27OHtmc',      'ER_r0202m',
      'ER_PHEACGLYsec',      'ER_EX_pheacgly[e]',      'ER_EX_bz[e]',      'ER_NORMETEt',
      'ER_MEPIt',      'ER_TREt',      'ER_C05300t',      'ER_RETINALt',
      'ER_MALTTTRt',      'ER_1MNCAMt',      'ER_DHBPTt',      'ER_THBPTt',
      'ER_EX_normete_L[e]',      'ER_EX_mepi[e]',      'ER_EX_C05300[e]',      'ER_EX_retinal[e]',
      'ER_EX_maltttr[e]',      'ER_EX_1mncam[e]',      'ER_EX_dhbpt[e]',      'ER_EX_thbpt[e]',
      'ER_EX_adprib[e]',      'ER_EX_homoval[e]',      'ER_GLYCLTtm',      'ER_TYMc',
      'ER_PCHOL2PALM_HSte',      'ER_PE224_HSte',      'ER_PCHOLN261_HSte',      'ER_PCHOLN281_HSte',
      'ER_PCHOLN28_HSte',      'ER_ACRNtr',      'ER_HDCECRNtr',      'ER_LNELDCCRNtr',
      'ER_ODECRNtr',      'ER_PMTCRNtr',      'ER_STCRNtr',      'ER_EX_sphmyln_hs[e]',
      'ER_PHEACGLYtm',      'ER_HXAt1',      'ER_HXAt2',      'ER_HXAt3',
      'ER_EX_hxa[e]',      'ER_PACCOALm',      'ER_PACALDtm',      'ER_LHCYSTIN',
      'ER_LHCYSTINt',      'ER_EX_Lhcystin[e]',      'ER_PA_HStm',      'ER_FldAct',
      'ER_MALOAtm',      'ER_MLTHFtm',      'ER_2MOPtm',      'ER_MMALtm',
      'ER_PGPP_hsc',      'ER_CE2512te',      'ER_r2514e',      'ER_r2514m',
      'ER_FAS180',      'ER_5AOPt2',      'ER_ACNAMt2',      'ER_ADRNLtu',
      'ER_DM_pe_hs[c]',      'ER_DM_akg[c]',      'ER_DM_for[c]',      'ER_DM_mi1345p[c]',
      'ER_DM_mi134p[c]',      'ER_DM_mi145p[c]',      'ER_DM_mi14p[c]',      'ER_DM_pchol_hs[c]',
      'ER_ETHAt',      'ER_HCYSte',      'ER_OROte',      'ER_PPPGOc',
      'ER_SPRMt2r',      'ER_THMtrbc',      'ER_UGT1A10c',      'ER_UNK3r',
      'ER_ACGALtr',      'ER_ACNAMtr',      'ER_CORE4t',      'ER_S2L2N2M2Mt',
      'ER_EX_core4[e]',      'ER_EX_f1a[e]',      'ER_EX_s2l2n2m2m[e]',      'ER_EX_acgal[e]',
      'ER_EX_acnam[e]',      'ER_EX_pa_hs[e]',      'ER_DM_C02712[c]',      'ER_F1Ate',
      'ER_34HPLtm',      'ER_3HMPtm',      'ER_3HPPtm',      'ER_ACGLUtm',
      'ER_PGP_hs_tm',      'ER_PROSTGE2t2r',      'ER_ESTR2r',      'ER_LTHSTRLtr',
      'ER_PGLYCtm',      'ER_sink_25hvitd2[c]',      'ER_sink_C02528[c]',      'ER_sink_HC02191[c]',
      'ER_sink_HC02194[c]',      'ER_sink_HC02195[c]',      'ER_sink_HC02196[c]',      'ER_sink_HC02197[c]',
      'ER_sink_HC02198[c]',      'ER_sink_HC02220[c]',      'ER_sink_Tyr_ggn[c]',      'ER_sink_avite1[c]',
      'ER_sink_btn[c]',      'ER_sink_c226coa[c]',      'ER_sink_chol[c]',      'ER_sink_cholate[c]',
      'ER_sink_coa[c]',      'ER_sink_crvnc[c]',      'ER_sink_dgchol[c]',      'ER_sink_doco13ecoa[c]',
      'ER_sink_fad[c]',      'ER_sink_fe3[c]',      'ER_sink_gchola[c]',      'ER_sink_glygn2[c]',
      'ER_sink_hdca[c]',      'ER_sink_lnlc[c]',      'ER_sink_lnlccoa[c]',      'ER_sink_lnlncacoa[c]',
      'ER_sink_lnlncgcoa[c]',      'ER_sink_nad[c]',      'ER_sink_nadp[c]',      'ER_sink_odecoa[c]',
      'ER_sink_pmtcoa[c]',      'ER_sink_pydam[c]',      'ER_sink_pydx[c]',      'ER_sink_pydxn[c]',
      'ER_sink_retfa[c]',      'ER_sink_retinol[c]',      'ER_sink_stcoa[c]',      'ER_sink_tag_hs[c]',
      'ER_sink_tchola[c]',      'ER_sink_tdchola[c]',      'ER_sink_thf[c]',      'ER_sink_thmpp[c]',
      'ER_sink_thmtp[c]',      'ER_sink_tmndnc[c]',      'ER_sink_tmndnccoa[c]',      'ER_sink_vitd3[c]',
      'ER_DXTRNt',      'ER_EX_dxtrn[e]',      'ER_EX_dhcholestanate[e]',      'ER_sink_dhcholestanate[c]',
      'ER_EX_thcholstoic[e]',      'ER_sink_thcholstoic[c]',      'ER_EX_xol7ah3[e]',      'ER_sink_xol7ah3[c]',
      'ER_EX_xol7aone[e]',      'ER_sink_xol7aone[c]',      'ER_EX_xoldiolone[e]',      'ER_sink_xoldiolone[c]',
      'ER_EX_7klitchol[e]',      'ER_sink_7klitchol[c]',      'ER_sink_dchac[c]',      'ER_EX_2obut[e]',
      'ER_EX_glcn[e]',      'ER_CO2t',      'ER_DM_atp_c_',      'ER_EX_acac[e]',
      'ER_EX_adn[e]',      'ER_EX_akg[e]',      'ER_EX_asn_L[e]',      'ER_EX_asp_L[e]',
      'ER_EX_but[e]',      'ER_EX_cgly[e]',      'ER_EX_co2[e]',      'ER_EX_cytd[e]',
      'ER_EX_dad_2[e]',      'ER_EX_dcyt[e]',      'ER_EX_dgsn[e]',      'ER_EX_din[e]',
      'ER_EX_duri[e]',      'ER_EX_fe2[e]',      'ER_EX_fe3[e]',      'ER_EX_fum[e]',
      'ER_EX_gal[e]',      'ER_EX_glu_L[e]',      'ER_EX_h[e]',      'ER_EX_h2o[e]',
      'ER_EX_ile_L[e]',      'ER_EX_ins[e]',      'ER_EX_k[e]',      'ER_EX_lac_L[e]',
      'ER_EX_leu_L[e]',      'ER_EX_lys_L[e]',      'ER_EX_mal_L[e]',      'ER_EX_met_L[e]',
      'ER_EX_na1[e]',      'ER_EX_no2[e]',      'ER_EX_o2[e]',      'ER_EX_orn[e]',
      'ER_EX_pi[e]',      'ER_EX_ppi[e]',      'ER_EX_pro_L[e]',      'ER_EX_ribflv[e]',
      'ER_EX_ser_L[e]',      'ER_EX_so4[e]',      'ER_EX_succ[e]',      'ER_EX_thymd[e]',
      'ER_EX_urea[e]',      'ER_EX_uri[e]',      'ER_EX_val_L[e]',      'ER_FCLTc',
      'ER_FT',      'ER_G5SADs',      'ER_O2t',      'ER_PIt6b',
      'ER_URIDK3',      'ER_EX_pnto_R[e]',      'ER_EX_gly[e]',      'ER_EX_cys_L[e]',
      'ER_EX_ala_L[e]',      'ER_EX_his_L[e]',      'ER_EX_thr_L[e]',      'ER_EX_gln_L[e]',
      'ER_EX_phe_L[e]',      'ER_EX_tyr_L[e]',      'ER_EX_arg_L[e]',      'ER_EX_for[e]',
      'ER_EX_nac[e]',      'ER_EX_ind3ac[e]',      'ER_EX_nh4[e]',      'ER_EX_ac[e]',
      'ER_CSND',      'ER_EX_acgam[e]',      'ER_EX_cit[e]',      'ER_EX_csn[e]',
      'ER_EX_drib[e]',      'ER_EX_etha[e]',      'ER_EX_fol[e]',      'ER_EX_fru[e]',
      'ER_EX_galt[e]',      'ER_EX_glcr[e]',      'ER_EX_glcur[e]',      'ER_EX_glyc[e]',
      'ER_EX_hxan[e]',      'ER_EX_malt[e]',      'ER_EX_malthx[e]',      'ER_EX_malttr[e]',
      'ER_EX_man[e]',      'ER_EX_ptrc[e]',      'ER_EX_rib_D[e]',      'ER_EX_spmd[e]',
      'ER_EX_thm[e]',      'ER_EX_trp_L[e]',      'ER_EX_ura[e]',      'ER_EX_xan[e]',
      'ER_EX_xyl_D[e]',      'ER_NTD5_a',      'ER_OAADC',      'ER_EX_pydxn[e]',
      'ER_PYDXNtr',      'ER_EX_pydx[e]',      'ER_PYDXtr',      'ER_EX_pydam[e]',
      'ER_PYDAMtr',      'ER_EX_4hbz[e]',      'ER_EX_ppa[e]',      'ER_EX_arab_L[e]',
      'ER_EX_gam[e]',      'ER_EX_pyr[e]',      'ER_EX_tre[e]',      'ER_EX_btn[e]',
      'ER_EX_lcts[e]',      'ER_EX_ade[e]',      'ER_EX_etoh[e]',      'ER_ETOHt',
      'ER_EX_acald[e]',      'ER_ACALDt',      'ER_EX_sucr[e]',      'ER_EX_pheme[e]',
      'ER_MTRI',      'ER_EX_gua[e]',      'ER_EX_4abut[e]',      'ER_OBDHc',
      'ER_EX_phpyr[e]',      'ER_EX_lanost[e]',      'ER_3MOX4HOXMte',      'ER_EX_3mox4hoxm[e]',
      'ER_2H3MVte',      'ER_EX_2h3mv[e]',      'ER_2HIVte',      'ER_EX_2hiv[e]',
      'ER_2M3HBUc',      'ER_2M3HBUtm',      'ER_2M3HBUte',      'ER_EX_2m3hbu[e]',
      'ER_3H3MGLTc',      'ER_3H3MGLTte',      'ER_EX_3h3mglt[e]',      'ER_3MGLUTACc',
      'ER_3MGLUTACtm',      'ER_3MGLUTACte',      'ER_EX_3mglutac[e]',      'ER_PPIOGLYtm',
      'ER_PPIOGLYte',      'ER_EX_ppiogly[e]',      'ER_TIGGLYtm',      'ER_TIGGLYte',
      'ER_EX_tiggly[e]',      'ER_GLUTACOAm',      'ER_GLUTCONm',      'ER_GLUTCONtm',
      'ER_GLUTCONte',      'ER_EX_glutcon[e]',      'ER_3HIVAcm',      'ER_3HIVActm',
      'ER_3HIVActe',      'ER_EX_3hivac[e]',      'ER_3HADPACx',      'ER_3HADPACtxc',
      'ER_3HADPACte',      'ER_EX_3hadpac[e]',      'ER_3OHSEBACx',      'ER_3OHSEBACtxc',
      'ER_3OHSEBACte',      'ER_EX_3ohsebac[e]',      'ER_3OHSUBACx',      'ER_3OHSUBACtxc',
      'ER_3OHSUBACte',      'ER_EX_3ohsubac[e]',      'ER_CAPROICc',      'ER_5OHHEXAc',
      'ER_5OHHEXAte',      'ER_EX_5ohhexa[e]',      'ER_ETHMALCOAc',      'ER_ETHMALACc',
      'ER_ETHMALACte',      'ER_EX_ethmalac[e]',      'ER_HEXGLYte',      'ER_EX_hexgly[e]',
      'ER_SUBGLYte',      'ER_EX_subgly[e]',      'ER_4OHBUTm',      'ER_4OHBUTtmc',
      'ER_4OHBUTtce',      'ER_EX_4ohbut[e]',      'ER_12HPETUPKt',      'ER_15HPETUPKt',
      'ER_3AIBSYMPt',      'ER_CE7172UPKt',      'ER_PAIL_hs_SECt',      'ER_PAILPALM_HSSECt',
      'ER_PAILR_HSSECt',      'ER_SPHMYLN_HsSECt',      'ER_SPHMYLN180241_hs_SECt',      'ER_SPHMYLN18114_hs_SECt',
      'ER_SPHMYLN18115_hs_SECt',      'ER_SPHMYLN18116_hs_SECt',      'ER_SPHMYLN181161_hs_SECt',      'ER_SPHMYLN18117_hs_SECt',
      'ER_SPHMYLN18118_hs_SECt',      'ER_SPHMYLN181181_hs_SECt',      'ER_SPHMYLN18120_hs_SECt',      'ER_SPHMYLN181201_hs_SECt',
      'ER_SPHMYLN18121_hs_SECt',      'ER_SPHMYLN18122_hs_SECt',      'ER_SPHMYLN181221_hs_SECt',      'ER_SPHMYLN18123_hs_SECt',
      'ER_SPHMYLN1824_hs_SECt',      'ER_SPHMYLN1825_hs_SECt',      'ER_3AIBt1',      'ER_AK2LGCHOLt1',
      'ER_PAFt1',      'ER_PCHOL2LINL_HSt1e',      'ER_PCHOL2OLE_HSt1e',      'ER_PCHOL2STE_HSt1e',
      'ER_PCHOLAR_HSt1e',      'ER_PCHOLDOC_HSt1e',      'ER_PCHOLEIC_HSt1e',      'ER_PCHOLET_HSt1e',
      'ER_PCHOLHEP_HSt1e',      'ER_PCHOLLINL_HSt1e',      'ER_PCHOLMYR_Hst1e',      'ER_PCHOLN15_HSt1e',
      'ER_PCHOLN183_HSt1e',      'ER_PCHOLN1836_HSt1e',      'ER_PCHOLN19_HSt1e',      'ER_PCHOLN201_HSt1e',
      'ER_PCHOLN203_HSt1e',      'ER_PCHOLN204_HSt1e',      'ER_PCHOLN205_HSt1e',      'ER_PCHOLN224_HSt1e',
      'ER_PCHOLN225_HSt1e',      'ER_PCHOLN2254_HSt1e',      'ER_PCHLN225_HSt1e',      'ER_PCHOLN264_HSt1e',
      'ER_PCHOLOLE_HSt1e',      'ER_PEPALM_HSt1e',      'ER_PCHOLPALME-HSt1e',      'ER_PCHOLSTE_HSt1e',
      'ER_PE12_HSt1e',      'ER_Pe13_HSt1e',      'ER_PE14_HSt1e',      'ER_PE15_HSt1e',
      'ER_PE161_HSt1e',      'ER_PE17_HSt1e',      'ER_PE203_HSt1e',      'ER_PE226_HSt1e',
      'ER_PE2LINL_HSt1e',      'ER_PEAR_HSt1e',      'ER_PEDH203_HSt1e',      'ER_PELINL_HSt1e',
      'ER_PEOLE_HSt1e',      'ER_PELPALM_HSt1e',      'ER_PESTE_HSt1e',      'ER_EIC21114TRte',
      'ER_EX_eic21114tr[e]',      'ER_5EIPENCte',      'ER_EX_5eipenc[e]',      'ER_ISOBUTtm',
      'ER_ISOBUTte',      'ER_EX_CE4969[e]',      'ER_NACCYStm',      'ER_NACCYSte',
      'ER_EX_CE1310[e]',      'ER_AGRMtm',      'ER_EX_agm[e]',      'ER_T4HCINNMtm',
      'ER_EX_T4hcinnm[e]',      'ER_4HBZte',      'ER_SUCSALtm',      'ER_SUCSALte',
      'ER_EX_sucsal[e]',      'ER_CE7081tr',      'ER_CE7081tm',      'ER_EX_CE7081[e]',
      'ER_EGMEtr',      'ER_EGMEte',      'ER_EX_egme[e]',      'ER_SQLtr',
      'ER_SQLte',      'ER_EX_sql[e]',      'ER_ORN_Dte',      'ER_EX_orn_D[e]',
      'ER_5G2OXPTtx',      'ER_5G2OXPTte',      'ER_EX_5g2oxpt[e]',      'ER_DHEAte',
      'ER_EX_dhea[e]',      'ER_ANDRSTANDRtr',      'ER_EX_andrstandn[e]',      'ER_ESTRONEte',
      'ER_EX_estrone[e]',      'ER_HC02020tr',      'ER_HC02020te',      'ER_EX_HC02020[e]',
      'ER_XOL27OHte',      'ER_EX_xol27oh[e]',      'ER_XOL25OHtr',      'ER_XOL25OHte',
      'ER_EX_xol25oh[e]',      'ER_DSMSTEROLtr',      'ER_DSMSTEROLte',      'ER_EX_dsmsterol[e]',
      'ER_CHSTEROLSte',      'ER_EX_chsterols[e]',      'ER_3ITYR_Lte',      'ER_EX_3ityr_L[e]',
      'ER_35DIODTYRte',      'ER_EX_35diotyr[e]',      'ER_13_CIS_RETNte',      'ER_EX_13_cis_retn[e]',
      'ER_LDL_HSDEG',      'ER_EX_34dhoxmand[e]',      'ER_EX_CE7090[e]',      'ER_EX_CE7085[e]',
      'ER_EX_CE7096[e]',      'ER_EX_CE4877[e]',      'ER_EX_CE1447[e]',      'ER_EX_CE6205[e]',
      'ER_EX_trypta[e]',      'ER_C05767te',      'ER_EX_C05767[e]',      'ER_C05770te3',
      'ER_EX_C05770[e]',      'ER_EX_mhista[e]',      'ER_PPBNGte',      'ER_EX_ppbng[e]',
      'ER_EX_mma[e]',      'ER_12PPDRte',      'ER_EX_12ppd_R[e]',      'ER_AMETAMte',
      'ER_EX_ametam[e]',      'ER_XYLULte',      'ER_EX_xylu_L[e]',      'ER_XYLUDte',
      'ER_EX_xylu_D[e]',      'ER_GLCNte',      'ER_SPHGNSte',      'ER_EX_sphings[e]',
      'ER_HDD2CRNte',      'ER_EX_hdd2crn[e]',      'ER_IM4ACte',      'ER_EX_im4ac[e]',
      'ER_EX_CE1918[e]',      'ER_EX_mlthf[e]',      'ER_EX_CE2705[e]',      'ER_SPHGNte',
      'ER_EX_sphgn[e]',      'ER_EX_N1aspmd[e]',      'ER_C13856te',      'ER_EX_1a25dhvitd3[e]',
      'ER_PRISTte',      'ER_EX_prist[e]',      'ER_CE2049te',      'ER_EX_CE2049[e]',
      'ER_CE2047te',      'ER_EX_CE2047[e]',      'ER_LANOSTte',      'ER_FDPte',
      'ER_EX_fdp[e]',      'ER_EX_coke[e]',      'ER_COKEte',      'ER_COKEtr',
      'ER_EX_5a2opntn[e]',      'ER_5A2OPNTNte',      'ER_5A2OPNTNtx',      'ER_ARG_Dtx',
      'ER_ARG_Dte',      'ER_EX_arg_D[e]',      'ER_LANOSTtr',      'ER_EX_ldl_hs[e]',
      'ER_EX_HC00005[e]',      'ER_CE1261t',      'ER_DOPAOQNOX',      'ER_DOPAOQCYS',
      'ER_DACT',      'ER_CE5629t',      'ER_EX_CE5629[e]',      'ER_CRMte',
      'ER_EX_gd3_hs[e]',      'ER_EX_gluside_hs[e]',      'ER_GALGLUSIDEtg2',      'ER_GD3tg',
      'ER_GD3tl',      'ER_GLUSIDEte',      'ER_GLUSIDEtg',      'ER_GLUSIDEtl',
      'ER_GM1tg',      'ER_GM1tl',      'ER_SPHMYLNtl2',      'ER_RE3477C1',
      'ER_NH4tr',      'ER_UDPGALt2n',      'ER_THCRMtl',      'ER_DAG_HStg',
      'ER_SPHGNtn',      'ER_SPHGNtg',      'ER_SPHINGStn',      'ER_SPHINGStg',
      'ER_DHCRMtg',      'ER_GDA1tn',      'ER_sink_34dhpac[c]',      'ER_34DHPEt',
      'ER_EX_34dhpe[e]',      'ER_DM_sph1p[n]',      'ER_DM_sphs1p[n]',      'ER_DM_gm1_hs[n]',
      'ER_DM_gda1_hs[n]',      'ER_DM_6hddopaqn[c]',      'ER_GALSIDEtn',      'ER_CERT1tn',
      'ER_Rtotaltg',      'ER_GD1Atg',      'ER_GD1Atn',      'ER_ATPtg',
      'ER_GD3tlc',      'ER_GD3tm',      'ER_DM_pail35p_hs[n]',      'ER_DM_gd3_hs[m]',
      'ER_CATr',      'ER_S2L2N2M2Mtl',      'ER_DM_k[g]',      'ER_DM_na1[g]',
      'ER_DM_retn[n]',      'ER_DM_15HPET[n]',      'ER_DM_15HPET[x]',      'ER_DM_15HPET[r]',
      'ER_sink_Ser_Gly_Ala_X_Gly[r]',      'ER_EX_pail_hs[e]',      'ER_EX_CE5026[e]',      'ER_EX_CE1261[e]',
      'ER_EX_galgluside_hs[e]',      'ER_EX_gm1_hs[e]',      'ER_HMR_0015',      'ER_HMR_0020',
      'ER_HMR_0157',      'ER_HMR_0166',      'ER_HMR_0172',      'ER_HMR_0178',
      'ER_HMR_0182',      'ER_HMR_0185',      'ER_HMR_0763',      'ER_HMR_0769',
      'ER_HMR_0771',      'ER_HMR_0809',      'ER_HMR_0831',      'ER_HMR_0912',
      'ER_HMR_0913',      'ER_HMR_0962',      'ER_HMR_0984',      'ER_HMR_1095',
      'ER_HMR_1104',      'ER_HMR_1135',      'ER_HMR_1242',      'ER_HMR_1243',
      'ER_HMR_1283',      'ER_HMR_1284',      'ER_HMR_1306',      'ER_HMR_1311',
      'ER_HMR_1315',      'ER_HMR_1316',      'ER_HMR_1317',      'ER_HMR_1332',
      'ER_HMR_1623',      'ER_HMR_1701',      'ER_HMR_1744',      'ER_HMR_1745',
      'ER_HMR_1752',      'ER_HMR_1753',      'ER_HMR_1758',      'ER_HMR_1759',
      'ER_HMR_1834',      'ER_HMR_2087',      'ER_HMR_2090',      'ER_HMR_2127',
      'ER_HMR_2374',      'ER_HMR_2376',      'ER_HMR_2391',      'ER_HMR_2393',
      'ER_HMR_2495',      'ER_HMR_2569',      'ER_HMR_2571',      'ER_HMR_3053',
      'ER_HMR_3056',      'ER_HMR_3106',      'ER_HMR_3396',      'ER_HMR_3397',
      'ER_HMR_3478',      'ER_HMR_3520',      'ER_HMR_3597',      'ER_HMR_3951',
      'ER_HMR_3953',      'ER_HMR_3996',      'ER_HMR_4078',      'ER_HMR_4266',
      'ER_HMR_4664',      'ER_HMR_4672',      'ER_HMR_4782',      'ER_HMR_4783',
      'ER_HMR_4831',      'ER_HMR_4957',      'ER_HMR_5101',      'ER_HMR_5409',
      'ER_HMR_6500',      'ER_HMR_6611',      'ER_HMR_6629',      'ER_HMR_6784',
      'ER_HMR_6785',      'ER_HMR_6786',      'ER_HMR_7198',      'ER_HMR_7330',
      'ER_HMR_7712',      'ER_HMR_7715',      'ER_HMR_7898',      'ER_HMR_7900',
      'ER_HMR_7944',      'ER_HMR_7977',      'ER_HMR_8023',      'ER_HMR_8084',
      'ER_HMR_8086',      'ER_HMR_8090',      'ER_HMR_8374',      'ER_HMR_8418',
      'ER_HMR_8505',      'ER_HMR_8562',      'ER_HMR_8567',      'ER_HMR_8776',
      'ER_HMR_9019',      'ER_HMR_9174',      'ER_HMR_9175',      'ER_HMR_9176',
      'ER_HMR_9179',      'ER_HMR_9180',      'ER_HMR_9184',      'ER_HMR_9185',
      'ER_HMR_9188',      'ER_HMR_9189',      'ER_HMR_9612',      'ER_HMR_9625',
      'ER_HMR_9626',      'ER_HMR_9627',      'ER_HMR_9628',      'ER_HMR_9634',
      'ER_HMR_9638',      'ER_HMR_9639',      'ER_HMR_9640',      'ER_HMR_9647',
      'ER_HMR_9648',      'ER_HMR_9652',      'ER_HMR_9665',      'ER_HMR_9667',
      'ER_HMR_9676',      'ER_HMR_9678',      'ER_HMR_9679',      'ER_HMR_9680',
      'ER_HMR_9718',      'ER_HMR_9720',      'ER_HMR_9797',      'ER_HMR_6672',
      'ER_EX_nadh[e]',      'ER_EX_glc_D[e]',      'ER_EX_sbt_D[e]',      'ER_CDCA24Gtr',
      'ER_CDCA3Gtr',      'ER_DM_12dhchol[c]',      'ER_DM_3dhcdchol[c]',      'ER_DM_3dhchol[c]',
      'ER_DM_3dhdchol[c]',      'ER_DM_3dhlchol[c]',      'ER_DM_7dhcdchol[c]',      'ER_DM_7dhchol[c]',
      'ER_DM_cdca24g[c]',      'ER_DM_cdca3g[c]',      'ER_DM_coprost[c]',      'ER_DM_hca24g[c]',
      'ER_DM_hdca24g[c]',      'ER_DM_hdca6g[c]',      'ER_DM_hyochol[c]',      'ER_DM_icdchol[c]',
      'ER_DM_isochol[c]',      'ER_DM_lca24g[c]',      'ER_DM_lca3g[c]',      'ER_DM_thyochol[c]',
      'ER_DM_uchol[c]',      'ER_EX_12dhchol[e]',      'ER_EX_3dhcdchol[e]',      'ER_EX_3dhchol[e]',
      'ER_EX_3dhdchol[e]',      'ER_EX_3dhlchol[e]',      'ER_EX_7dhcdchol[e]',      'ER_EX_7dhchol[e]',
      'ER_EX_cdca24g[e]',      'ER_EX_cdca3g[e]',      'ER_EX_coprost[e]',      'ER_EX_hca24g[e]',
      'ER_EX_hdca24g[e]',      'ER_EX_hdca6g[e]',      'ER_EX_hyochol[e]',      'ER_EX_icdchol[e]',
      'ER_EX_isochol[e]',      'ER_EX_lca24g[e]',      'ER_EX_lca3g[e]',      'ER_EX_thyochol[e]',
      'ER_EX_uchol[e]',      'ER_HCA24Gtr',      'ER_HDCA6Gtr',      'ER_HYOCHOLtr',
      'ER_LCA24Gtr',      'ER_LCA3Gtr',      'ER_M02155tr',      'ER_12HTACRtep',
      'ER_14MDZtev',      'ER_1HIBUPGLUC_Sthv',      'ER_1HIBUP_Sthv',      'ER_1HMDZGLUChc',
      'ER_1OHMDZtep',      'ER_2HATVACIDtep',      'ER_2HATVLACtep',      'ER_2HIBUPGLUC_Sthv',
      'ER_2HIBUP_Rthv',      'ER_2HIBUP_Sthv',      'ER_35DSMVteb',      'ER_3HIBUPGLUC_Sthv',
      'ER_3HIBUP_Rthv',      'ER_3HIBUP_Sthv',      'ER_3HLVSTACtbc',      'ER_3HPVSTETtev',
      'ER_3HPVStep',      'ER_3HSMVACIDteb',      'ER_3ISPVStep',      'ER_3MEACMPhc',
      'ER_3OHACMPtev',      'ER_4HATVACIDtep',      'ER_4HATVLACtep',      'ER_4HMDGLUCtev',
      'ER_4OHMDZtev',      'ER_56DHPVStev',      'ER_56EPPVStev',      'ER_5OHFVSGLUhc',
      'ER_5OHFVSGLUtev',      'ER_5OHFVSteb',      'ER_6BHGLZtev',      'ER_6CSMVACIDteb',
      'ER_6EPVStep',      'ER_6HLVSTthep',      'ER_6HMSMVACIDteb',      'ER_6HSMVACIDteb',
      'ER_6MELVSTthep',      'ER_6OHFVSGLUhc',      'ER_6OHFVSGLUtev',      'ER_7BHGLZtev',
      'ER_7HPVStev',      'ER_ACMPdt',      'ER_AM1CSAtep',      'ER_AM9CSAtep',
      'ER_ATVACIDhr',      'ER_ATVACIDtdu',      'ER_ATVLACh2r',      'ER_ATVLAChr',
      'ER_ATVLACtdhc',      'ER_Am19CStev',      'ER_CARBIBUP_SGLUthv',      'ER_CARIBUP_Sthv',
      'ER_CRVSM24tev',      'ER_CRVStu',      'ER_CSAtd',      'ER_DEOXFVStev',
      'ER_DSPVStev',      'ER_EPOXTAChr',      'ER_EPOXTACtev',      'ER_EX_12htacr[e]',
      'ER_EX_14hmdz[e]',      'ER_EX_1hibup_S[e]',      'ER_EX_1hibupglu_S[e]',      'ER_EX_1hmdgluc[e]',
      'ER_EX_1ohmdz[e]',      'ER_EX_2hatvacid[e]',      'ER_EX_2hatvlac[e]',      'ER_EX_2hatvlacgluc[e]',
      'ER_EX_2hibup_R[e]',      'ER_EX_2hibup_S[e]',      'ER_EX_2hibupglu_S[e]',      'ER_EX_35dsmv[e]',
      'ER_EX_3hibup_R[e]',      'ER_EX_3hibup_S[e]',      'ER_EX_3hibupglu_S[e]',      'ER_EX_3hlvstacid[e]',
      'ER_EX_3hpvs[e]',      'ER_EX_3hpvstet[e]',      'ER_EX_3hsmvacid[e]',      'ER_EX_3ohacmp[e]',
      'ER_EX_4hatvacid[e]',      'ER_EX_4hatvlac[e]',      'ER_EX_4hmdgluc[e]',      'ER_EX_4ohmdz[e]',
      'ER_EX_5ohfvs[e]',      'ER_EX_5ohfvsglu[e]',      'ER_EX_6bhglz[e]',      'ER_EX_6csmvacid[e]',
      'ER_EX_6hlvst[e]',      'ER_EX_6hmsmvacid[e]',      'ER_EX_6hsmvacid[e]',      'ER_EX_6melvacid[e]',
      'ER_EX_6melvst[e]',      'ER_EX_6ohfvsglu[e]',      'ER_EX_7bhglz[e]',      'ER_EX_acmp[e]',
      'ER_EX_am19cs[e]',      'ER_EX_am1csa[e]',      'ER_EX_am9csa[e]',      'ER_EX_atvacid[e]',
      'ER_EX_atvlac[e]',      'ER_EX_caribup_s[e]',      'ER_EX_caribupglu_S[e]',      'ER_EX_crvs[e]',
      'ER_EX_crvsm24[e]',      'ER_EX_csa[e]',      'ER_EX_deoxfvs[e]',      'ER_EX_epoxtac[e]',
      'ER_EX_fvs[e]',      'ER_EX_glc3meacp[e]',      'ER_EX_glz[e]',      'ER_EX_ibup_R[e]',
      'ER_EX_ibup_S[e]',      'ER_EX_ibupgluc[e]',      'ER_EX_isolvstacid[e]',      'ER_EX_lstn[e]',
      'ER_EX_lstnm7[e]',      'ER_EX_lvst[e]',      'ER_EX_mdz[e]',      'ER_EX_nfdac[e]',
      'ER_EX_nfdoh[e]',      'ER_EX_profvs[e]',      'ER_EX_ptvst[e]',      'ER_EX_ptvstlac[e]',
      'ER_EX_pvs[e]',      'ER_EX_smv[e]',      'ER_EX_smvacid[e]',      'ER_EX_tacr[e]',
      'ER_EX_tlacfvs[e]',      'ER_FVShc',      'ER_FVStep',      'ER_GLC3MEACPtev',
      'ER_GLZtd',      'ER_IBUPGLUCtchep',      'ER_IBUPGLUCtpvb',      'ER_IBUP_Rtdhep',
      'ER_IBUP_Rtdu',      'ER_IBUP_Stdhep',      'ER_IBUP_Stdu',      'ER_ISOLVSTAChep',
      'ER_LSTNM7TDhc',      'ER_LSTNM7thc',      'ER_LSTNRATt',      'ER_LSTNtd',
      'ER_LVACLAChep',      'ER_LVSTtu',      'ER_MDZtd',      'ER_NFDACtep',
      'ER_NFDOHtep',      'ER_OXYPtepv',      'ER_PROFVShc',      'ER_PROFVStev',
      'ER_PTVSTLAChc',      'ER_PTVSTLACtev',      'ER_PTVSTtep',      'ER_PVSGLUCtev',
      'ER_PVSHtu',      'ER_PVStep',      'ER_RSVGLUChc',      'ER_RSVLAChv',
      'ER_SMVACIDtev',      'ER_SMVtv',      'ER_TACRDtsc',      'ER_TLACFVStev',
      'ER_TRIPVStev',      'ER_12HTACRitr',      'ER_14HMDZitr',      'ER_1HIBUP_Sitr',
      'ER_1HIBUPGLUitr',      'ER_1HMDGLUCitr',      'ER_2HATVLACGLUCitr',      'ER_2HIBUP_Ritr',
      'ER_2HIBUP_Sitr',      'ER_2HIBUPGLUC_Sitr',      'ER_35DSMVitr',      'ER_3HIBUP_Ritr',
      'ER_3HIBUPGLUC_Sitr',      'ER_3HLVSTitr',      'ER_3HPVSitr',      'ER_3HPVSCOAitm',
      'ER_3HPVSCOAitx',      'ER_3HPVSTETCOAitm',      'ER_3HPVSTETCOAitx',      'ER_3HSMVitr',
      'ER_3MEACMPitr',      'ER_3OHACMPitr',      'ER_4HATVACIDitr',      'ER_4HATVLACitr',
      'ER_4HMDGLUCitr',      'ER_4OHMDZitr',      'ER_5OHFVSitr',      'ER_5OHFVSGLUitr',
      'ER_6CSMVitr',      'ER_6HLVSTitr',      'ER_6HLVSTACIDitr',      'ER_6HMSMVitr',
      'ER_6HSMVitr',      'ER_6MELVACIDitr',      'ER_6MELVSTitr',      'ER_6OHFVSGLUitr',
      'ER_ACMPitr',      'ER_AM19CSitr',      'ER_CARIBUP_Sitr',      'ER_CARIBUPGLU_Sitr',
      'ER_CRVSitr',      'ER_CRVSM24itr',      'ER_CSAitr',      'ER_DEOXFVSitx',
      'ER_EPOXTACitr',      'ER_FVSitx',      'ER_FVSCOAitx',      'ER_GLC3MEACPitr',
      'ER_GLZitr',      'ER_IBUP_Ritr',      'ER_IBUP_Sitr',      'ER_IBUPGLUCitr',
      'ER_LSTNitr',      'ER_LSTNM7itr',      'ER_LVSTitr',      'ER_LVSTACIDitr',
      'ER_MDZitr',      'ER_NFDOHitr',      'ER_PROFVSCOAitx',      'ER_PTVSTLACitr',
      'ER_PTVSTM13itr',      'ER_PTVSTM13te',      'ER_EX_ptvstm13[e]',      'ER_PVSitr',
      'ER_RSVLACitr',      'ER_TACRitr',      'ER_TLACFVSitr',      'ER_3HPVSCOAhc',
      'ER_3HPVSTEThc',      'ER_FVSCOAhc',      'ER_1OHMDZitr',      'ER_NFDACitr',
      'ER_H2O2itr',      'ER_ATVACIDitr',      'ER_ATVLACitr',      'ER_SMVitr',
      'ER_6BHGLZitr',      'ER_7BHGLZitr',      'ER_RSVitr',      'ER_PTVSTitr',
      'ER_3HIBUP_Sitr',      'ER_FVSitr',      'ER_AM1CSAitr',      'ER_AM9CSAitr',
      'ER_2HATVACIDitr',      'ER_EX_caproic[e]',      'ER_1A25HVITD2t',      'ER_1A25HVITD2tm',
      'ER_EX_1a25dhvitd2[e]',      'ER_EX_C13856[e]',      'ER_EX_M00234[e]',      'ER_EX_M01807[e]',
      'ER_EX_M00503[e]',      'ER_EX_M00003[e]',      'ER_EX_M00008[e]',      'ER_EX_M00010[e]',
      'ER_EX_M00017[e]',      'ER_EX_M00019[e]',      'ER_EX_M00021[e]',      'ER_EX_M00115[e]',
      'ER_EX_M00117[e]',      'ER_EX_M00260[e]',      'ER_EX_M00265[e]',      'ER_EX_M00315[e]',
      'ER_EX_M00341[e]',      'ER_EX_M01197[e]',      'ER_EX_M01207[e]',      'ER_EX_M01235[e]',
      'ER_EX_M01238[e]',      'ER_EX_M01582[e]',      'ER_EX_M02053[e]',      'ER_EX_M02457[e]',
      'ER_EX_M02613[e]',      'ER_EX_M02745[e]',      'ER_EX_M03045[e]',      'ER_EX_M03051[e]',
      'ER_EX_M03153[e]',      'ER_EX_M02560[e]',      'ER_EX_C01601[e]',      'ER_EX_M02108[e]',
      'ER_EX_M03117[e]',      'ER_EX_M03134[e]',      'ER_EX_M01111[e]',      'ER_EX_h2co3[e]',
      'ER_EX_M01870[e]',      'ER_EX_ditp[e]',      'ER_EX_M02446[e]',      'ER_EX_M02447[e]',
      'ER_EX_M02449[e]',      'ER_EX_M02451[e]',      'ER_EX_itacon[e]',      'ER_EX_adpman[e]',
      'ER_EX_rbl_D[e]',      'ER_EX_M02155[e]',      'ER_EX_M01989[e]',      'ER_EX_M03131[e]',
      'ER_EX_n5m2masn[e]',      'ER_EX_dolichol_L[e]',      'ER_sink_his_L[c]',      'ER_sink_ile_L[c]',
      'ER_sink_leu_L[c]',      'ER_sink_lys_L[c]',      'ER_sink_met_L[c]',      'ER_sink_phe_L[c]',
      'ER_sink_thr_L[c]',      'ER_sink_trp_L[c]',      'ER_sink_val_L[c]',      'ER_sink_ala_L[c]',
      'ER_sink_arg_L[c]',      'ER_sink_asn_L[c]',      'ER_sink_asp_L[c]',      'ER_sink_cys_L[c]',
      'ER_sink_gln_L[c]',      'ER_sink_glu_L[c]',      'ER_sink_pro_L[c]',      'ER_sink_ser_L[c]',
      'ER_sink_tyr_L[c]',      'ER_sink_gly[c]',      'ER_sink_4abut[l]',      'ER_DM_5cysdopa[c]',
      'ER_DM_4abut[c]',      'ER_DM_srtn[c]',      'ER_DM_ach[c]',      'ER_DM_hista[c]',
      'ER_DM_kynate[c]',      'ER_DM_tym[c]',      'ER_DM_Lkynr[c]',      'ER_DM_cbl2[m]',
      'ER_DCMPtm',      'ER_ATPS4mi',      'ER_KER_02243',      'ER_KER_02407',
      'ER_KER_10600',      'ER_ITPtm',      'ER_IDPtm',      'ER_CE_Peptide',
      'ER_EX_Peptide',      'ER_Ubiquitin_syn',      'ER_DM_Ubiquitin',      'ER_Abeta_syn',
      'ER_DM_Abeta',      'ER_Abeta_L_lysine',      'ER_CE_Abeta_L_lysine',      'ER_CN_Abeta_L_lysine',
      'ER_EX_Abeta_L_lysine',      'ER_EN_Abeta_L_lysine',      'ER_Abeta_Deg',      'ER_Tau_syn',
      'ER_DM_Tau',      'ER_Tau_L_lysine',      'ER_CE_Tau_L_lysine',      'ER_CN_Tau_L_lysine',
      'ER_EX_Tau_L_lysine',      'ER_EN_Tau_L_lysine',      'ER_Tau_Deg',      'ER_TNFA_syn',
      'ER_DM_TNFA',      'ER_TNFA_L_lysine',      'ER_CE_TNFA_L_lysine',      'ER_CN_TNFA_L_lysine',
      'ER_EX_TNFA_L_lysine',      'ER_EN_TNFA_L_lysine',      'ER_TNFA_Deg',      'ER_IL6_syn',
      'ER_DM_IL6',      'ER_IL6_L_lysine',      'ER_CE_IL6_L_lysine',      'ER_CN_IL6_L_lysine',
      'ER_EX_IL6_L_lysine',      'ER_EN_IL6_L_lysine',      'ER_IL6_Deg'
    /

  Met_NonGPR_enz(enzymes) "metabolic reactions without Gene association in BL model"
    /
********** Non-GPR association enzymes ----------
      'ER_2DR1PP',      'ER_3DPHBH1',      'ER_3DPHBH2',      'ER_3HBCOAHLm',
      'ER_4HBZCOAFm',      'ER_4HBZFm',      'ER_AASAD3m',      'ER_ABTD',
      'ER_ACGALK',      'ER_ACGALK2',      'ER_ACNMLr',      'ER_ADCim',
      'ER_ADNK1m',      'ER_R_group_phosphotase_1',      'ER_R_group_phosphotase_3',      'ER_ARTPLM3',
      'ER_ASCBOX',      'ER_B3GALTg',      'ER_CBL2OR',      'ER_CITMCOAHm',
      'ER_CITMCOALm',      'ER_COQ5m',      'ER_CORE5GTg',      'ER_CORE7GTg',
      'ER_COUCOAFm',      'ER_CSAPASEly',      'ER_CSBPASEly',      'ER_CSCPASEly',
      'ER_CSDPASEly',      'ER_CSEPASEly',      'ER_CYSGLTH',      'ER_CYTDK2m',
      'ER_DADNK',      'ER_DCK1m',      'ER_DEDOLP1_L',      'ER_DEDOLP2_L',
      'ER_DEDOLR_L',      'ER_DESAT22_1p',      'ER_DESAT22_2p',      'ER_DGK2m',
      'ER_DGULND',      'ER_DHPR2',      'ER_DKMPPD',      'ER_DMNONCOACRNCPT1',
      'ER_DPHMBDCm',      'ER_DPPS',      'ER_DSAT',      'ER_ENGASE2ly',
      'ER_ENGASE3ly',      'ER_FCOAH',      'ER_G5SADrm',      'ER_GGT_L',
      'ER_GGT6',      'ER_GLYCK2',      'ER_GLYCLTDym',      'ER_GTHDH',
      'ER_GULN3D',      'ER_GULNDer',      'ER_HPYRDC',      'ER_HPYRDCm',
      'ER_HSPASEly',      'ER_KDNH',      'ER_KYNATESYN',      'ER_LINKDEG1ly',
      'ER_LINKDEG2ly',      'ER_LINKDEG3ly',      'ER_LINKDEG4ly',      'ER_LTC4CP',
      'ER_LTD4DP',      'ER_MCITS',      'ER_MDRPD',      'ER_MGSA',
      'ER_MGSA2',      'ER_MI134P4P',      'ER_MI13PP',      'ER_MI14P4P',
      'ER_N4Tg',      'ER_NAGAlby',      'ER_NAGLCAly',      'ER_NICRNS',
      'ER_P450LTB4r',      'ER_PAFS',      'ER_PAN4PP',      'ER_PI45P4P',
      'ER_PI4P5Kn',      'ER_PI4PP',      'ER_PI5P4Kn',      'ER_PIK3n',
      'ER_PIK4n',      'ER_PIK5n',      'ER_PPAn',      'ER_QUILSYN',
      'ER_RADH',      'ER_RADH2',      'ER_RAI1',      'ER_RAI2',
      'ER_RETHe',      'ER_RETI1',      'ER_RETI2',      'ER_RETI3',
      'ER_S2TASE4ly',      'ER_S2TASE5ly',      'ER_S3TASE1ly',      'ER_S3TASE2ly',
      'ER_S3TASE3ly',      'ER_S4T4g',      'ER_S4T5g',      'ER_SPMDOX',
      'ER_T4HCINNMFM',      'ER_TRIOK',      'ER_UAGALDP',      'ER_UROLACer',
      'ER_XYLTD_Dr',      'ER_r0156',      'ER_r0179',      'ER_r0236',
      'ER_r0330',      'ER_r0365',      'ER_r0480',      'ER_r0527',
      'ER_r0647',      'ER_r0784',      'ER_r0788',      'ER_r0789',
      'ER_r1109',      'ER_r1134',      'ER_r1146',      'ER_r1377',
      'ER_r1384',      'ER_RE0124C',      'ER_RE0452M',      'ER_RE0453C',
      'ER_RE0570C',      'ER_RE0571C',      'ER_RE0574C',      'ER_RE0575C',
      'ER_RE0576C',      'ER_RE0581C',      'ER_RE0583C',      'ER_RE0691C',
      'ER_RE0830C',      'ER_RE0908C',      'ER_RE0915C',      'ER_RE0916C',
      'ER_RE0918C',      'ER_RE0958C',      'ER_RE1234C',      'ER_RE1303C',
      'ER_RE1342C',      'ER_RE1447N',      'ER_RE1448N',      'ER_RE1530C',
      'ER_RE1711C',      'ER_RE1804C',      'ER_RE1807C',      'ER_RE1826C',
      'ER_RE1836C',      'ER_RE1897C',      'ER_RE1898C',      'ER_RE1915C',
      'ER_RE1916C',      'ER_RE1919C',      'ER_RE1921C',      'ER_RE1978C',
      'ER_RE2069C',      'ER_RE2080C',      'ER_RE2112C',      'ER_RE2235C',
      'ER_RE2327C',      'ER_RE2407C',      'ER_RE2410C',      'ER_RE2426C',
      'ER_RE2526C',      'ER_RE2562C',      'ER_RE2563C',      'ER_RE2625C',
      'ER_RE2626C',      'ER_RE2655R',      'ER_RE2659R',      'ER_RE2666C',
      'ER_RE2677C',      'ER_RE2677N',      'ER_RE2799C',      'ER_RE2814R',
      'ER_RE2974N',      'ER_RE3011R',      'ER_RE3016R',      'ER_RE3017R',
      'ER_RE3033C',      'ER_RE3044C',      'ER_RE3050R',      'ER_RE3052C',
      'ER_RE3073X',      'ER_RE3104C',      'ER_RE3106C',      'ER_RE3112C',
      'ER_RE3113C',      'ER_RE3119C',      'ER_RE3121C',      'ER_RE3122C',
      'ER_RE3152C',      'ER_RE3153C',      'ER_RE3154C',      'ER_RE3162C',
      'ER_RE3163C',      'ER_RE3164C',      'ER_RE3166C',      'ER_RE3167C',
      'ER_RE3168C',      'ER_RE3169C',      'ER_RE3171C',      'ER_RE3172C',
      'ER_RE3173C',      'ER_RE3175C',      'ER_RE3176C',      'ER_RE3180C',
      'ER_RE3181C',      'ER_RE3227C',      'ER_RE3228C',      'ER_RE3229C',
      'ER_RE3230C',      'ER_RE3231C',      'ER_RE3232C',      'ER_RE3234C',
      'ER_RE3235C',      'ER_RE3236C',      'ER_RE3237C',      'ER_RE3238C',
      'ER_RE3239C',      'ER_RE3242C',      'ER_RE3243C',      'ER_RE3244C',
      'ER_RE3245C',      'ER_RE3267E',      'ER_RE3270C',      'ER_RE3272N',
      'ER_RE3286C',      'ER_RE3288C',      'ER_RE3347C',      'ER_RE3352C',
      'ER_RE3422C',      'ER_RE3430M',      'ER_RE3430X',      'ER_RE3434C',
      'ER_RE3435C',      'ER_RE3436C',      'ER_RE3437C',      'ER_RE3475C',
      'ER_RE3485C',      'ER_RE3493C',      'ER_RE3496C',      'ER_RE3513C',
      'ER_RE3513R',      'ER_RE3525M',      'ER_RE3526M',      'ER_RE3556C',
      'ER_RE3565C',      'ER_RE3566C',      'ER_RE3567C',      'ER_RE3568C',
      'ER_RE3570C',      'ER_RE3587C',      'ER_RE3637C',      'ER_ADPACDAc',
      'ER_C12DCACT',      'ER_FAOXC5C5OHm',      'ER_SEBACACT',      'ER_SUBERICACT',
      'ER_SUCCACT',      'ER_ADNK4',      'ER_GLYC3PFADm',      'ER_INSK',
      'ER_MDHx',      'ER_PNTEHe',      'ER_SFCYSc',      'ER_biomass_maintenance_noTrTr',
      'ER_ADPOHc',      'ER_PHLAC',      'ER_3MHISc',      'ER_HMCRNc',
      'ER_CE4843HYDc',      'ER_HXCOAc',      'ER_HDCAc',      'ER_LYSACm',
      'ER_HXCOAm',      'ER_HXCOAx',      'ER_PROSTGI2c',      'ER_TXB2c',
      'ER_DCHOLESTANCOAc',      'ER_r0202m',      'ER_TYMc',      'ER_PACCOALm',
      'ER_LHCYSTIN',      'ER_FldAct',      'ER_PGPP_hsc',      'ER_FAS180',
      'ER_PPPGOc',      'ER_UGT1A10c',      'ER_UNK3r',      'ER_ESTR2r',
      'ER_DM_atp_c_',      'ER_FCLTc',      'ER_FT',      'ER_G5SADs',
      'ER_URIDK3',      'ER_CSND',      'ER_NTD5_a',      'ER_OAADC',
      'ER_MTRI',      'ER_OBDHc',      'ER_2M3HBUc',      'ER_3H3MGLTc',
      'ER_3MGLUTACc',      'ER_GLUTACOAm',      'ER_GLUTCONm',      'ER_3HIVAcm',
      'ER_3HADPACx',      'ER_3OHSEBACx',      'ER_3OHSUBACx',      'ER_CAPROICc',
      'ER_5OHHEXAc',      'ER_ETHMALCOAc',      'ER_ETHMALACc',      'ER_4OHBUTm',
      'ER_LDL_HSDEG',      'ER_DOPAOQNOX',      'ER_DOPAOQCYS',      'ER_DACT',
      'ER_RE3477C1',      'ER_CATr',      'ER_HMR_0015',      'ER_HMR_0763',
      'ER_HMR_0809',      'ER_HMR_0912',      'ER_HMR_1315',      'ER_HMR_1317',
      'ER_HMR_1332',      'ER_HMR_1834',      'ER_HMR_2374',      'ER_HMR_2376',
      'ER_HMR_2391',      'ER_HMR_2393',      'ER_HMR_2495',      'ER_HMR_2571',
      'ER_HMR_3053',      'ER_HMR_3056',      'ER_HMR_3396',      'ER_HMR_3397',
      'ER_HMR_3996',      'ER_HMR_4078',      'ER_HMR_4664',      'ER_HMR_4672',
      'ER_HMR_4782',      'ER_HMR_4783',      'ER_HMR_4831',      'ER_HMR_5409',
      'ER_HMR_6611',      'ER_HMR_6784',      'ER_HMR_6785',      'ER_HMR_6786',
      'ER_HMR_9718',      'ER_HMR_9797',      'ER_HMR_6672',      'ER_3MEACMPhc',
      'ER_5OHFVSGLUhc',      'ER_6OHFVSGLUhc',      'ER_ATVACIDhr',      'ER_ATVLACh2r',
      'ER_ATVLAChr',      'ER_EPOXTAChr',      'ER_FVShc',      'ER_ISOLVSTAChep',
      'ER_LVACLAChep',      'ER_PROFVShc',      'ER_PTVSTLAChc',      'ER_RSVGLUChc',
      'ER_RSVLAChv',      'ER_3HPVSCOAhc',      'ER_3HPVSTEThc',      'ER_FVSCOAhc',
      'ER_KER_02243',      'ER_KER_02407',      'ER_KER_10600',      'ER_Ubiquitin_syn',
      'ER_Abeta_syn',      'ER_Abeta_L_lysine',      'ER_Abeta_Deg',      'ER_Tau_syn',
      'ER_Tau_L_lysine',      'ER_Tau_Deg',      'ER_TNFA_syn',      'ER_TNFA_L_lysine',
      'ER_TNFA_Deg',      'ER_IL6_syn',      'ER_IL6_L_lysine',      'ER_IL6_Deg'

    /

  transport_enz(enzymes) "transport reactions without Gene association in BL model"
    /
********** Non-GPR association enzymes ----------
      'ER_10FTHF5GLUtl',      'ER_10FTHF5GLUtm',      'ER_10FTHF6GLUtl',      'ER_10FTHF6GLUtm',
      'ER_10FTHF7GLUtl',      'ER_10FTHF7GLUtm',      'ER_10FTHFtl',      'ER_10FTHFtm',
      'ER_24NPHte',      'ER_25HVITD2tin_m',      'ER_25HVITD3tin_m',      'ER_2MCITt',
      'ER_34DHOXPEGt',      'ER_35CGMPtn',      'ER_3MLDAt',      'ER_3MOBt2im',
      'ER_3MOPt2im',      'ER_4ABUTtm',      'ER_4MOPt2im',      'ER_4NPHSFte',
      'ER_4NPHte',      'ER_5ADTSTSTERONESte',      'ER_5ADTSTSTERONEte',      'ER_5AOPtm',
      'ER_5DHFtl',      'ER_5THFtl',      'ER_5THFtm',      'ER_6DHFtl',
      'ER_6DHFtm',      'ER_6HTSTSTERONEte',      'ER_6HTSTSTERONEtr',      'ER_6THFtl',
      'ER_6THFtm',      'ER_7DHCHSTEROLtr',      'ER_7DHFtl',      'ER_7DHFtm',
      'ER_7THFtl',      'ER_7THFtm',      'ER_ACACtx',      'ER_ACALDtm',
      'ER_ACCOAtn',      'ER_ACGAGBSIDEtg',      'ER_ACGAGBSIDEtl',      'ER_ACGALtlg',
      'ER_ACGALtly',      'ER_ACGAMtly',      'ER_ACGBGBSIDEtg',      'ER_ACGBGBSIDEtl',
      'ER_ACHtn',      'ER_ACNACNGAL14ACGLCGALGLUSIDEte',      'ER_ACNACNGALGBSIDEte',      'ER_ACNACNGALGBSIDEtg',
      'ER_ACNAMtn',      'ER_ACNGALACGLCGAL14ACGLCGALGLUSIDEte',      'ER_ACNGALACGLCGAL14ACGLCGALGLUSIDEtg',      'ER_ACt2m',
      'ER_ACt2r',      'ER_ACtg',      'ER_ADRNCOAtx',      'ER_ADRNt',
      'ER_AFLATOXINte',      'ER_AHCYStr',      'ER_AKGtp',      'ER_AMETr',
      'ER_AMPtp',      'ER_ANDRSTRNte',      'ER_ANDRSTRNtr',      'ER_AQCOBALt',
      'ER_ARAB_Lt',      'ER_ARACHCOAtx',      'ER_ARACHDCOAtx',      'ER_ARACHDtr',
      'ER_ARACHt',      'ER_ARTFR208',      'ER_ASCBt',      'ER_ASPDxt',
      'ER_ATP1ter',      'ER_ATP2ter',      'ER_ATPtn',      'ER_ATPtx',
      'ER_BALAtmr',      'ER_BHBt',      'ER_BHBtm',      'ER_BILDGLCURtr',
      'ER_BILIRUBtr',      'ER_BZt',      'ER_BZtr',      'ER_C226COAtx',
      'ER_C226CRNt',      'ER_CAROtr',      'ER_CBPter',      'ER_CDPDAGtm',
      'ER_CHOLPtg',      'ER_CHOLPtl',      'ER_CHOLtn',      'ER_CLPNDCOAtx',
      'ER_CLPNDt',      'ER_CMPACNAtn',      'ER_CO2ter',      'ER_CO2tg',
      'ER_CO2tm',      'ER_CO2tp',      'ER_COAtg',      'ER_COAtl',
      'ER_COAtn',      'ER_COAtp',      'ER_COAtr',      'ER_COUMARINte',
      'ER_CRMPte',      'ER_CRNCAR3tp',      'ER_CRNtx',      'ER_CRTSTRNt',
      'ER_CRVNCtr',      'ER_CSPG_At',      'ER_CSPG_Atly',      'ER_CSPG_Btly',
      'ER_CSPG_Ct',      'ER_CSPG_Ctly',      'ER_CSPG_Dt',      'ER_CSPG_Dtly',
      'ER_CSPG_Et',      'ER_CSPG_Etly',      'ER_CTPtn',      'ER_D_3AIBt',
      'ER_DAG_HSter',      'ER_DAGt',      'ER_DALAxt',      'ER_DATPtn',
      'ER_DCSPTN1COAtx',      'ER_DCSPTN1t',      'ER_DCTPtn',      'ER_DECDPtm',
      'ER_DGCHOLte',      'ER_DGCHOLtx',      'ER_DGSNtm',      'ER_DGTPtn',
      'ER_DHEAStr',      'ER_DHEAtr',      'ER_DHFtl',      'ER_DHFtm',
      'ER_DIGALSIDEtl',      'ER_DMHPTCRNt',      'ER_DMHPTCRNte',      'ER_DMNONCRNt',
      'ER_DNADtn',      'ER_DOLMANP_Uter',      'ER_DOLPMT4_Uer',      'ER_DOPASFt',
      'ER_DPCOAtl',      'ER_DRIBt',      'ER_DTDPtn',      'ER_DTTPtn',
      'ER_EAFLATOXINte',      'ER_EBASTINEOHte',      'ER_EBASTINEOHtr',      'ER_EBASTINEte',
      'ER_EBASTINEtr',      'ER_EICOSTETt',      'ER_ESTRADIOLt',      'ER_ESTRADIOLtr',
      'ER_ESTRIOLtr',      'ER_ESTRONEtr',      'ER_F1Atg',      'ER_FADH2tru',
      'ER_FADH2tx',      'ER_FADtru',      'ER_FADtx',      'ER_FALDtly',
      'ER_FE2t',      'ER_FE2tm',      'ER_FORMCOAtx',      'ER_FORt2m',
      'ER_FORtr',      'ER_FRDPtr',      'ER_FUC13GALACGLCGAL14ACGLCGALGLUSIDEte',      'ER_FUC13GALACGLCGAL14ACGLCGALGLUSIDEtg',
      'ER_FUC14GALACGLCGALGLUSIDEte',      'ER_FUC14GALACGLCGALGLUSIDEtg',      'ER_FUCACGALFUCGALACGLCGALGLUSIDEte',      'ER_FUCFUC12GAL14ACGLCGALGLUSIDEte',
      'ER_FUCFUC12GAL14ACGLCGALGLUSIDEtg',      'ER_FUCFUCFUCGALACGLC13GALACGLCGAL14ACGLCGALGLUSIDEte',      'ER_FUCFUCFUCGALACGLC13GALACGLCGAL14ACGLCGALGLUSIDEtg',      'ER_FUCFUCGALACGLCGALGLUSIDEte',
      'ER_FUCFUCGALACGLCGALGLUSIDEtg',      'ER_FUCGAL14ACGLCGALGLUSIDEte',      'ER_FUCGAL14ACGLCGALGLUSIDEtg',      'ER_FUCGALFUCGALACGLCGALGLUSIDEte',
      'ER_FUCtly',      'ER_GACPAILter',      'ER_GALACGLCGALGBSIDEte',      'ER_GALACGLCGALGBSIDEtg',
      'ER_GALGALFUCFUCGALACGLCGALACGLCGAL14ACGLCGALGLUSIDEte',      'ER_GALGALFUCFUCGALACGLCGALACGLCGAL14ACGLCGALGLUSIDEtg',      'ER_GALGALGALTHCRMte',      'ER_GALGALGALTHCRMtg',
      'ER_GALGLUSIDEtg',      'ER_GALSIDEtl',      'ER_GALtly',      'ER_GBSIDEte',
      'ER_GBSIDEtl',      'ER_GCHOLAte',      'ER_GDPtg',      'ER_GLACter',
      'ER_GLCMter',      'ER_GLCter',      'ER_GLCtly',      'ER_GLCURter',
      'ER_GLNtm',      'ER_GLUt7l',      'ER_GLXtm',      'ER_GLXtp',
      'ER_GLYC3Ptm',      'ER_GLYCLTtp',      'ER_GLYC_St',      'ER_GLYCtm',
      'ER_GLYtm',      'ER_GLYtp',      'ER_GMPtg',      'ER_GMPtn',
      'ER_GQ1Bte',      'ER_GT1Ate',      'ER_GTHRDtr',      'ER_GULNter',
      'ER_H2O2t',      'ER_H2O2tly',      'ER_H2O2tm',      'ER_H2O2tp',
      'ER_H2Oter',      'ER_H2Otg',      'ER_H2Otly',      'ER_H2Otn',
      'ER_H2Otp',      'ER_HAtly',      'ER_HCOUMARINte',      'ER_HDCAter',
      'ER_HDD2COAtx',      'ER_HESTRATRIOLte',      'ER_HESTRATRIOLtr',      'ER_HEXCCOAtx',
      'ER_HEXCt',      'ER_HMGCOAtm',      'ER_HMGCOAtx',      'ER_HPDCAt',
      'ER_HPYRtp',      'ER_HSAT1ly',      'ER_HSAT2ly',      'ER_HSAT3ly',
      'ER_HSAT4ly',      'ER_HSPGt',      'ER_HSPGtly',      'ER_HTAXOLte',
      'ER_Htg',      'ER_Htr',      'ER_Htx',      'ER_ILEt5m',
      'ER_IPDPtx',      'ER_KSII_CORE2t',      'ER_KSII_CORE2tly',      'ER_KSII_CORE4t',
      'ER_KSII_CORE4tly',      'ER_KSItly',      'ER_LEUKTRB4tr',      'ER_LEUKTRD4t',
      'ER_LEUt5m',      'ER_LGNCCOAtx',      'ER_LNELDCt',      'ER_LPCHOLt',
      'ER_MAGt',      'ER_MANtly',      'ER_MEOHt2',      'ER_MEOHtly',
      'ER_MINOHPtn',      'ER_MTHGXLt',      'ER_N2M2NMASNtly',      'ER_NADHtpu',
      'ER_NADHtru',      'ER_NADPHtru',      'ER_NADPHtxu',      'ER_NADPtru',
      'ER_NADPtxu',      'ER_NADtn',      'ER_NADtru',      'ER_NCAMUP',
      'ER_NH4tn',      'ER_NH4tp',      'ER_NICRNTtn',      'ER_NMNtn',
      'ER_NOt',      'ER_NRPPHRSFt',      'ER_NRVNCCOAtx',      'ER_O2St',
      'ER_O2Stm',      'ER_O2ter',      'ER_O2tm',      'ER_O2tn',
      'ER_O2tp',      'ER_OAGD3te',      'ER_OAGD3tg',      'ER_OAGT3te',
      'ER_OCCOAtm',      'ER_OCCOAtx',      'ER_OCTAt',      'ER_ODECOAtx',
      'ER_OXAtp',      'ER_PAIL_HStn',      'ER_PAIL45P_HStn',      'ER_PAIL4P_HStn',
      'ER_PAPtg',      'ER_PCHOL_HSter',      'ER_PCHOL_HStg',      'ER_PE_HSter',
      'ER_PEt',      'ER_PGLYCt',      'ER_PHEMEtm',      'ER_PHYTt',
      'ER_PItg',      'ER_PItn',      'ER_PMTCOAtx',      'ER_PPAt',
      'ER_PPAtm',      'ER_PPItr',      'ER_PPItx',      'ER_PPMI12346Ptn',
      'ER_PPPG9tm',      'ER_PRGSTRNt',      'ER_PRISTANALtx',      'ER_PRISTCOAtx',
      'ER_PRISTtx',      'ER_PROSTGH2t',      'ER_PROSTGI2t',      'ER_PROtm',
      'ER_PSt3',      'ER_PTDCAt',      'ER_RAtn',      'ER_RETNGLCt2',
      'ER_RETNGLCt2r',      'ER_RETNt',      'ER_RETNtr2',      'ER_RIBt',
      'ER_RIBt2',      'ER_RTOTAL2t',      'ER_RTOTALt',      'ER_Rtotaltl',
      'ER_S2L2FN2M2MASNtly',      'ER_S2L2N2M2MASNtly',      'ER_Ser_Thrtg',      'ER_SERtp',
      'ER_SO4tl',      'ER_SPC_HSt',      'ER_SPH1Pte',      'ER_SPHINGStl',
      'ER_SPHMYLNtg',      'ER_SPHMYLNtl',      'ER_SPHS1Pte',      'ER_STCOAtx',
      'ER_STRDNCt',      'ER_SUCCtp',      'ER_TAGAT_Dt',      'ER_TAXOLte',
      'ER_TCHOLAte',      'ER_TDCHOLAte',      'ER_TETHEX3COAtx',      'ER_TETHEX3t',
      'ER_TETPENT3COAtx',      'ER_TETPENT3t',      'ER_TETPENT6COAtx',      'ER_TETPENT6t',
      'ER_TETTET6COAtx',      'ER_TETTET6t',      'ER_THCHOLSTOICtm',      'ER_THFtl',
      'ER_THFtm',      'ER_TMNDNCCOAtx',      'ER_TMNDNCt',      'ER_TRIODTHYSUFt',
      'ER_TSTSTERONESte',      'ER_TSTSTERONEt',      'ER_TSTSTERONEtr',      'ER_TXA2te',
      'ER_TXA2tr',      'ER_UDPACGALtl',      'ER_UDPGLCAtg',      'ER_UDPtl',
      'ER_UDPXYLter',      'ER_UMPtr',      'ER_URATEt',      'ER_UTPtn',
      'ER_VACCt',      'ER_VALt5m',      'ER_VITD3t',      'ER_WHHDCAte',
      'ER_WHTSTSTERONEte',      'ER_XOL27OHtm',      'ER_XOL7AONEtr',      'ER_XOLEST2te',
      'ER_XOLESTte',      'ER_XOLTRI24te',      'ER_XOLTRI27tc',      'ER_XOLTRI27te',
      'ER_XSERtg',      'ER_XYLtly',      'ER_XYLTt',      'ER_r0002',
      'ER_r0809',      'ER_r0818',      'ER_r0838',      'ER_r0839',
      'ER_r0841',      'ER_r0853',      'ER_r0859',      'ER_r0886',
      'ER_r0892',      'ER_r0899',      'ER_r0926',      'ER_r0927',
      'ER_r0936',      'ER_r0937',      'ER_r0944',      'ER_r0950',
      'ER_r0962',      'ER_r0968',      'ER_r0970',      'ER_r0973',
      'ER_r0974',      'ER_r0986',      'ER_r0987',      'ER_r0989',
      'ER_r0990',      'ER_r0994',      'ER_r1000',      'ER_r1003',
      'ER_r1011',      'ER_r1012',      'ER_r1013',      'ER_r1014',
      'ER_r1018',      'ER_r1019',      'ER_r1030',      'ER_r1050',
      'ER_r1088',      'ER_r1106',      'ER_r1116',      'ER_r1117',
      'ER_r1148',      'ER_r1150',      'ER_r1159',      'ER_r1291',
      'ER_r1292',      'ER_r1298',      'ER_r1299',      'ER_r1301',
      'ER_r1302',      'ER_r1303',      'ER_r1304',      'ER_r1318',
      'ER_r1364',      'ER_r1365',      'ER_r1367',      'ER_r1368',
      'ER_r1400',      'ER_r1421',      'ER_r1423',      'ER_r1435',
      'ER_r1436',      'ER_r1437',      'ER_r1459',      'ER_r1467',
      'ER_r1468',      'ER_r1493',      'ER_r1512',      'ER_r2508',
      'ER_r2509',      'ER_r2510',      'ER_r2511',      'ER_r2514',
      'ER_r2519',      'ER_r2521',      'ER_r2537',      'ER_r2538',
      'ER_r2539',      'ER_biomass_reaction',      'ER_ADPACtx',      'ER_BCRNe',
      'ER_C101CRNe',      'ER_C10CRNe',      'ER_C12DCe',      'ER_C16DCe',
      'ER_C3DCe',      'ER_C4CRNe',      'ER_C4DCe',      'ER_C6CRNe',
      'ER_C81CRNe',      'ER_C8CRNe',      'ER_C8DCe',      'ER_DDCRNe',
      'ER_DDECCRNe',      'ER_DDECE1CRNe',      'ER_DECCRNe',      'ER_DECDICRNe',
      'ER_DOCOSACTDe',      'ER_DOCOSACTDr',      'ER_HEXDIACtr',      'ER_HOCTDEC2CRNe',
      'ER_HTDCRNe',      'ER_OCTDECE1CRNe',      'ER_SEBACIDtx',      'ER_SUBEACtx',
      'ER_TDCRNe',      'ER_TETDEC2CRNe',      'ER_TETDECE1CRNe',      'ER_TIGCRNe',
      'ER_BTNTe',      'ER_SBTle',      'ER_1a25DHVITD3TRn',      'ER_3AIB_Dtm',
      'ER_5MTHFt2le',      'ER_AHCYStd',      'ER_ALA-DTDe',      'ER_AMETtd',
      'ER_ARACHFATPc',      'ER_ASPDTDe',      'ER_ASPte',      'ER_CHSTEROLtrc',
      'ER_CRNrtx',      'ER_Coqe',      'ER_DATPtm',      'ER_DCTPtm',
      'ER_DGTPtm',      'ER_DHAPtc',      'ER_DTTPtm',      'ER_FOLt2le',
      'ER_FRDPtcr',      'ER_GLU5SAtmc',      'ER_GLYCTDle',      'ER_KHte',
      'ER_LACLt',      'ER_MAL_Ltx',      'ER_NADtm',      'ER_NADtx',
      'ER_PPItm',      'ER_PRO_Dtde',      'ER_PTCRTD',      'ER_Q10H2e',
      'ER_SFCYSe',      'ER_TAURCHAe',      'ER_TTDCAFATPc',      'ER_q10h2tc',
      'ER_q10tm',      'ER_34HPPte',      'ER_3MOBte',      'ER_3MOPte',
      'ER_4MOPte',      'ER_5MTAte',      'ER_AHCYSte',      'ER_AICARte',
      'ER_CBASPte',      'ER_MAL_Lte',      'ER_IDOURte',      'ER_GLYALDtr',
      'ER_PEPtr',      'ER_GUDACtr',      'ER_GUDACtr2',      'ER_KYNATEtr2',
      'ER_3ANTHRNtr',      'ER_2PGtr',      'ER_CARNtr',      'ER_CHOLPtr',
      'ER_DCMPtr',      'ER_DHAPtr',      'ER_ETHAMPtr',      'ER_FUMtr',
      'ER_GLCURtr',      'ER_ICITtr',      'ER_L2AADPtr',      'ER_XANtr',
      'ER_XMPtr',      'ER_XTSNtr',      'ER_3PGtr',      'ER_UDPGLCURtr',
      'ER_IMPtr',      'ER_GLYC3tr',      'ER_NICRNtr',      'ER_OROT5Ptr',
      'ER_ARGSUCte',      'ER_ELAIDCRNte',      'ER_LNLCCRNNAt',      'ER_PHLACHt',
      'ER_TTDCRNNAt',      'ER_15HPETATP',      'ER_15KPROSTGF2t',      'ER_2OXOADPt',
      'ER_34HPLte',      'ER_3HMPtd',      'ER_3HPPt',      'ER_3MHISt1',
      'ER_3MHISt2',      'ER_3MHISt3',      'ER_3MOXTYRt',      'ER_3UIBtd',
      'ER_4TMEABUTNt1',      'ER_4TMEABUTNt2',      'ER_56DTHMt',      'ER_56DTHMtd',
      'ER_56DURAt',      'ER_56DURAtd',      'ER_5AOPt',      'ER_7DHCHSTEROLtd',
      'ER_ACGLUtd',      'ER_ACLYSt',      'ER_ACLYStm',      'ER_ADPACtd',
      'ER_ADPOHt',      'ER_ALLTNt',      'ER_C02712tm',      'ER_C03990tr',
      'ER_C04483t2',      'ER_C04717td',      'ER_C04805td',      'ER_C05463t2',
      'ER_C05953t',      'ER_C05957t',      'ER_C05957td',      'ER_C06314t',
      'ER_C06315t',      'ER_C06439t',      'ER_C11695td',      'ER_C14768td',
      'ER_C14769td1',      'ER_C14770ATP',      'ER_C14771ATP',      'ER_C14825td',
      'ER_C14826td',      'ER_CE1273t2',      'ER_CE2510t',      'ER_CE2513td',
      'ER_CE2537ATP',      'ER_CE4843td',      'ER_CE5304t',      'ER_CE6247t',
      'ER_DODECANACtd',      'ER_ELAIDCRNtd',      'ER_FORGLUt',      'ER_GALTt',
      'ER_GLYC_Rt',      'ER_GLYCLTtd',      'ER_HC00900t1',      'ER_HC00900t2',
      'ER_HC00900t3',      'ER_HC00900t4',      'ER_HC02149td',      'ER_HEXDIACtd',
      'ER_HGENTISt',      'ER_HMCRNt',      'ER_HXCOAte',      'ER_HXCOAtx',
      'ER_IND3ACt',      'ER_LCYSTt',      'ER_LEUKTRB4WCOOHt',      'ER_LEUKTRB4WOHt',
      'ER_LEUKTRB4WOHtr',      'ER_LNLCCRNtd',      'ER_LTHSTRLt',      'ER_MEV_Rt',
      'ER_MI1Pt',      'ER_NWHARGtd',      'ER_OAAt',      'ER_pac',
      'ER_PCOLLG5HLYStd',      'ER_PSERtr',      'ER_SACCRP_Lte',      'ER_SACCRP_Ltm',
      'ER_SEBACIDtd',      'ER_SUBEACtd',      'ER_TMLYStd',      'ER_URCANt',
      'ER_WHARACHDtr',      'ER_DDCAFATP',      'ER_TTDCEAt',      'ER_XOL27OHtmc',
      'ER_PHEACGLYsec',      'ER_NORMETEt',      'ER_MEPIt',      'ER_TREt',
      'ER_C05300t',      'ER_RETINALt',      'ER_MALTTTRt',      'ER_1MNCAMt',
      'ER_DHBPTt',      'ER_THBPTt',      'ER_GLYCLTtm',      'ER_PCHOL2PALM_HSte',
      'ER_PE224_HSte',      'ER_PCHOLN261_HSte',      'ER_PCHOLN281_HSte',      'ER_PCHOLN28_HSte',
      'ER_ACRNtr',      'ER_HDCECRNtr',      'ER_LNELDCCRNtr',      'ER_ODECRNtr',
      'ER_PMTCRNtr',      'ER_STCRNtr',      'ER_PHEACGLYtm',      'ER_HXAt1',
      'ER_HXAt2',      'ER_HXAt3',      'ER_PACALDtm',      'ER_LHCYSTINt',
      'ER_PA_HStm',      'ER_MALOAtm',      'ER_MLTHFtm',      'ER_2MOPtm',
      'ER_MMALtm',      'ER_CE2512te',      'ER_r2514e',      'ER_r2514m',
      'ER_5AOPt2',      'ER_ACNAMt2',      'ER_ADRNLtu',      'ER_ETHAt',
      'ER_HCYSte',      'ER_OROte',      'ER_SPRMt2r',      'ER_THMtrbc',
      'ER_ACGALtr',      'ER_ACNAMtr',      'ER_CORE4t',      'ER_S2L2N2M2Mt',
      'ER_F1Ate',      'ER_34HPLtm',      'ER_3HMPtm',      'ER_3HPPtm',
      'ER_ACGLUtm',      'ER_PGP_hs_tm',      'ER_PROSTGE2t2r',      'ER_LTHSTRLtr',
      'ER_PGLYCtm',      'ER_DXTRNt',      'ER_CO2t',      'ER_O2t',
      'ER_PIt6b',      'ER_PYDXNtr',      'ER_PYDXtr',      'ER_PYDAMtr',
      'ER_ETOHt',      'ER_ACALDt',      'ER_3MOX4HOXMte',      'ER_2H3MVte',
      'ER_2HIVte',      'ER_2M3HBUtm',      'ER_2M3HBUte',      'ER_3H3MGLTte',
      'ER_3MGLUTACtm',      'ER_3MGLUTACte',      'ER_PPIOGLYtm',      'ER_PPIOGLYte',
      'ER_TIGGLYtm',      'ER_TIGGLYte',      'ER_GLUTCONtm',      'ER_GLUTCONte',
      'ER_3HIVActm',      'ER_3HIVActe',      'ER_3HADPACtxc',      'ER_3HADPACte',
      'ER_3OHSEBACtxc',      'ER_3OHSEBACte',      'ER_3OHSUBACtxc',      'ER_3OHSUBACte',
      'ER_5OHHEXAte',      'ER_ETHMALACte',      'ER_HEXGLYte',      'ER_SUBGLYte',
      'ER_4OHBUTtmc',      'ER_4OHBUTtce',      'ER_12HPETUPKt',      'ER_15HPETUPKt',
      'ER_3AIBSYMPt',      'ER_CE7172UPKt',      'ER_PAIL_hs_SECt',      'ER_PAILPALM_HSSECt',
      'ER_PAILR_HSSECt',      'ER_SPHMYLN_HsSECt',      'ER_SPHMYLN180241_hs_SECt',      'ER_SPHMYLN18114_hs_SECt',
      'ER_SPHMYLN18115_hs_SECt',      'ER_SPHMYLN18116_hs_SECt',      'ER_SPHMYLN181161_hs_SECt',      'ER_SPHMYLN18117_hs_SECt',
      'ER_SPHMYLN18118_hs_SECt',      'ER_SPHMYLN181181_hs_SECt',      'ER_SPHMYLN18120_hs_SECt',      'ER_SPHMYLN181201_hs_SECt',
      'ER_SPHMYLN18121_hs_SECt',      'ER_SPHMYLN18122_hs_SECt',      'ER_SPHMYLN181221_hs_SECt',      'ER_SPHMYLN18123_hs_SECt',
      'ER_SPHMYLN1824_hs_SECt',      'ER_SPHMYLN1825_hs_SECt',      'ER_3AIBt1',      'ER_AK2LGCHOLt1',
      'ER_PAFt1',      'ER_PCHOL2LINL_HSt1e',      'ER_PCHOL2OLE_HSt1e',      'ER_PCHOL2STE_HSt1e',
      'ER_PCHOLAR_HSt1e',      'ER_PCHOLDOC_HSt1e',      'ER_PCHOLEIC_HSt1e',      'ER_PCHOLET_HSt1e',
      'ER_PCHOLHEP_HSt1e',      'ER_PCHOLLINL_HSt1e',      'ER_PCHOLMYR_Hst1e',      'ER_PCHOLN15_HSt1e',
      'ER_PCHOLN183_HSt1e',      'ER_PCHOLN1836_HSt1e',      'ER_PCHOLN19_HSt1e',      'ER_PCHOLN201_HSt1e',
      'ER_PCHOLN203_HSt1e',      'ER_PCHOLN204_HSt1e',      'ER_PCHOLN205_HSt1e',      'ER_PCHOLN224_HSt1e',
      'ER_PCHOLN225_HSt1e',      'ER_PCHOLN2254_HSt1e',      'ER_PCHLN225_HSt1e',      'ER_PCHOLN264_HSt1e',
      'ER_PCHOLOLE_HSt1e',      'ER_PEPALM_HSt1e',      'ER_PCHOLPALME-HSt1e',      'ER_PCHOLSTE_HSt1e',
      'ER_PE12_HSt1e',      'ER_Pe13_HSt1e',      'ER_PE14_HSt1e',      'ER_PE15_HSt1e',
      'ER_PE161_HSt1e',      'ER_PE17_HSt1e',      'ER_PE203_HSt1e',      'ER_PE226_HSt1e',
      'ER_PE2LINL_HSt1e',      'ER_PEAR_HSt1e',      'ER_PEDH203_HSt1e',      'ER_PELINL_HSt1e',
      'ER_PEOLE_HSt1e',      'ER_PELPALM_HSt1e',      'ER_PESTE_HSt1e',      'ER_EIC21114TRte',
      'ER_5EIPENCte',      'ER_ISOBUTtm',      'ER_ISOBUTte',      'ER_NACCYStm',
      'ER_NACCYSte',      'ER_AGRMtm',      'ER_T4HCINNMtm',      'ER_4HBZte',
      'ER_SUCSALtm',      'ER_SUCSALte',      'ER_CE7081tr',      'ER_CE7081tm',
      'ER_EGMEtr',      'ER_EGMEte',      'ER_SQLtr',      'ER_SQLte',
      'ER_ORN_Dte',      'ER_5G2OXPTtx',      'ER_5G2OXPTte',      'ER_DHEAte',
      'ER_ANDRSTANDRtr',      'ER_ESTRONEte',      'ER_HC02020tr',      'ER_HC02020te',
      'ER_XOL27OHte',      'ER_XOL25OHtr',      'ER_XOL25OHte',      'ER_DSMSTEROLtr',
      'ER_DSMSTEROLte',      'ER_CHSTEROLSte',      'ER_3ITYR_Lte',      'ER_35DIODTYRte',
      'ER_13_CIS_RETNte',      'ER_C05767te',      'ER_C05770te3',      'ER_PPBNGte',
      'ER_12PPDRte',      'ER_AMETAMte',      'ER_XYLULte',      'ER_XYLUDte',
      'ER_GLCNte',      'ER_SPHGNSte',      'ER_HDD2CRNte',      'ER_IM4ACte',
      'ER_SPHGNte',      'ER_C13856te',      'ER_PRISTte',      'ER_CE2049te',
      'ER_CE2047te',      'ER_LANOSTte',      'ER_FDPte',      'ER_COKEte',
      'ER_COKEtr',      'ER_5A2OPNTNte',      'ER_5A2OPNTNtx',      'ER_ARG_Dtx',
      'ER_ARG_Dte',      'ER_LANOSTtr',      'ER_CE1261t',      'ER_CE5629t',
      'ER_CRMte',      'ER_GALGLUSIDEtg2',      'ER_GD3tg',      'ER_GD3tl',
      'ER_GLUSIDEte',      'ER_GLUSIDEtg',      'ER_GLUSIDEtl',      'ER_GM1tg',
      'ER_GM1tl',      'ER_SPHMYLNtl2',      'ER_NH4tr',      'ER_UDPGALt2n',
      'ER_THCRMtl',      'ER_DAG_HStg',      'ER_SPHGNtn',      'ER_SPHGNtg',
      'ER_SPHINGStn',      'ER_SPHINGStg',      'ER_DHCRMtg',      'ER_GDA1tn',
      'ER_34DHPEt',      'ER_GALSIDEtn',      'ER_CERT1tn',      'ER_Rtotaltg',
      'ER_GD1Atg',      'ER_GD1Atn',      'ER_ATPtg',      'ER_GD3tlc',
      'ER_GD3tm',      'ER_S2L2N2M2Mtl',      'ER_HMR_0020',      'ER_HMR_0157',
      'ER_HMR_0166',      'ER_HMR_0172',      'ER_HMR_0178',      'ER_HMR_0182',
      'ER_HMR_0185',      'ER_HMR_0769',      'ER_HMR_0771',      'ER_HMR_0831',
      'ER_HMR_0913',      'ER_HMR_0962',      'ER_HMR_0984',      'ER_HMR_1095',
      'ER_HMR_1104',      'ER_HMR_1135',      'ER_HMR_1242',      'ER_HMR_1243',
      'ER_HMR_1283',      'ER_HMR_1284',      'ER_HMR_1306',      'ER_HMR_1311',
      'ER_HMR_1316',      'ER_HMR_1623',      'ER_HMR_1701',      'ER_HMR_1744',
      'ER_HMR_1745',      'ER_HMR_1752',      'ER_HMR_1753',      'ER_HMR_1758',
      'ER_HMR_1759',      'ER_HMR_2087',      'ER_HMR_2090',      'ER_HMR_2127',
      'ER_HMR_2569',      'ER_HMR_3106',      'ER_HMR_3478',      'ER_HMR_3520',
      'ER_HMR_3597',      'ER_HMR_3951',      'ER_HMR_3953',      'ER_HMR_4266',
      'ER_HMR_4957',      'ER_HMR_5101',      'ER_HMR_6500',      'ER_HMR_6629',
      'ER_HMR_7198',      'ER_HMR_7330',      'ER_HMR_7712',      'ER_HMR_7715',
      'ER_HMR_7898',      'ER_HMR_7900',      'ER_HMR_7944',      'ER_HMR_7977',
      'ER_HMR_8023',      'ER_HMR_8084',      'ER_HMR_8086',      'ER_HMR_8090',
      'ER_HMR_8374',      'ER_HMR_8418',      'ER_HMR_8505',      'ER_HMR_8562',
      'ER_HMR_8567',      'ER_HMR_8776',      'ER_HMR_9019',      'ER_HMR_9174',
      'ER_HMR_9175',      'ER_HMR_9176',      'ER_HMR_9179',      'ER_HMR_9180',
      'ER_HMR_9184',      'ER_HMR_9185',      'ER_HMR_9188',      'ER_HMR_9189',
      'ER_HMR_9612',      'ER_HMR_9625',      'ER_HMR_9626',      'ER_HMR_9627',
      'ER_HMR_9628',      'ER_HMR_9634',      'ER_HMR_9638',      'ER_HMR_9639',
      'ER_HMR_9640',      'ER_HMR_9647',      'ER_HMR_9648',      'ER_HMR_9652',
      'ER_HMR_9665',      'ER_HMR_9667',      'ER_HMR_9676',      'ER_HMR_9678',
      'ER_HMR_9679',      'ER_HMR_9680',      'ER_HMR_9720',      'ER_CDCA24Gtr',
      'ER_CDCA3Gtr',      'ER_HCA24Gtr',      'ER_HDCA6Gtr',      'ER_HYOCHOLtr',
      'ER_LCA24Gtr',      'ER_LCA3Gtr',      'ER_M02155tr',      'ER_12HTACRtep',
      'ER_14MDZtev',      'ER_1HIBUPGLUC_Sthv',      'ER_1HIBUP_Sthv',      'ER_1HMDZGLUChc',
      'ER_1OHMDZtep',      'ER_2HATVACIDtep',      'ER_2HATVLACtep',      'ER_2HIBUPGLUC_Sthv',
      'ER_2HIBUP_Rthv',      'ER_2HIBUP_Sthv',      'ER_35DSMVteb',      'ER_3HIBUPGLUC_Sthv',
      'ER_3HIBUP_Rthv',      'ER_3HIBUP_Sthv',      'ER_3HLVSTACtbc',      'ER_3HPVSTETtev',
      'ER_3HPVStep',      'ER_3HSMVACIDteb',      'ER_3ISPVStep',      'ER_3OHACMPtev',
      'ER_4HATVACIDtep',      'ER_4HATVLACtep',      'ER_4HMDGLUCtev',      'ER_4OHMDZtev',
      'ER_56DHPVStev',      'ER_56EPPVStev',      'ER_5OHFVSGLUtev',      'ER_5OHFVSteb',
      'ER_6BHGLZtev',      'ER_6CSMVACIDteb',      'ER_6EPVStep',      'ER_6HLVSTthep',
      'ER_6HMSMVACIDteb',      'ER_6HSMVACIDteb',      'ER_6MELVSTthep',      'ER_6OHFVSGLUtev',
      'ER_7BHGLZtev',      'ER_7HPVStev',      'ER_ACMPdt',      'ER_AM1CSAtep',
      'ER_AM9CSAtep',      'ER_ATVACIDtdu',      'ER_ATVLACtdhc',      'ER_Am19CStev',
      'ER_CARBIBUP_SGLUthv',      'ER_CARIBUP_Sthv',      'ER_CRVSM24tev',      'ER_CRVStu',
      'ER_CSAtd',      'ER_DEOXFVStev',      'ER_DSPVStev',      'ER_EPOXTACtev',
      'ER_FVStep',      'ER_GLC3MEACPtev',      'ER_GLZtd',      'ER_IBUPGLUCtchep',
      'ER_IBUPGLUCtpvb',      'ER_IBUP_Rtdhep',      'ER_IBUP_Rtdu',      'ER_IBUP_Stdhep',
      'ER_IBUP_Stdu',      'ER_LSTNM7TDhc',      'ER_LSTNM7thc',      'ER_LSTNRATt',
      'ER_LSTNtd',      'ER_LVSTtu',      'ER_MDZtd',      'ER_NFDACtep',
      'ER_NFDOHtep',      'ER_OXYPtepv',      'ER_PROFVStev',      'ER_PTVSTLACtev',
      'ER_PTVSTtep',      'ER_PVSGLUCtev',      'ER_PVSHtu',      'ER_PVStep',
      'ER_SMVACIDtev',      'ER_SMVtv',      'ER_TACRDtsc',      'ER_TLACFVStev',
      'ER_TRIPVStev',      'ER_12HTACRitr',      'ER_14HMDZitr',      'ER_1HIBUP_Sitr',
      'ER_1HIBUPGLUitr',      'ER_1HMDGLUCitr',      'ER_2HATVLACGLUCitr',      'ER_2HIBUP_Ritr',
      'ER_2HIBUP_Sitr',      'ER_2HIBUPGLUC_Sitr',      'ER_35DSMVitr',      'ER_3HIBUP_Ritr',
      'ER_3HIBUPGLUC_Sitr',      'ER_3HLVSTitr',      'ER_3HPVSitr',      'ER_3HPVSCOAitm',
      'ER_3HPVSCOAitx',      'ER_3HPVSTETCOAitm',      'ER_3HPVSTETCOAitx',      'ER_3HSMVitr',
      'ER_3MEACMPitr',      'ER_3OHACMPitr',      'ER_4HATVACIDitr',      'ER_4HATVLACitr',
      'ER_4HMDGLUCitr',      'ER_4OHMDZitr',      'ER_5OHFVSitr',      'ER_5OHFVSGLUitr',
      'ER_6CSMVitr',      'ER_6HLVSTitr',      'ER_6HLVSTACIDitr',      'ER_6HMSMVitr',
      'ER_6HSMVitr',      'ER_6MELVACIDitr',      'ER_6MELVSTitr',      'ER_6OHFVSGLUitr',
      'ER_ACMPitr',      'ER_AM19CSitr',      'ER_CARIBUP_Sitr',      'ER_CARIBUPGLU_Sitr',
      'ER_CRVSitr',      'ER_CRVSM24itr',      'ER_CSAitr',      'ER_DEOXFVSitx',
      'ER_EPOXTACitr',      'ER_FVSitx',      'ER_FVSCOAitx',      'ER_GLC3MEACPitr',
      'ER_GLZitr',      'ER_IBUP_Ritr',      'ER_IBUP_Sitr',      'ER_IBUPGLUCitr',
      'ER_LSTNitr',      'ER_LSTNM7itr',      'ER_LVSTitr',      'ER_LVSTACIDitr',
      'ER_MDZitr',      'ER_NFDOHitr',      'ER_PROFVSCOAitx',      'ER_PTVSTLACitr',
      'ER_PTVSTM13itr',      'ER_PTVSTM13te',      'ER_PVSitr',      'ER_RSVLACitr',
      'ER_TACRitr',      'ER_TLACFVSitr',      'ER_1OHMDZitr',      'ER_NFDACitr',
      'ER_H2O2itr',      'ER_ATVACIDitr',      'ER_ATVLACitr',      'ER_SMVitr',
      'ER_6BHGLZitr',      'ER_7BHGLZitr',      'ER_RSVitr',      'ER_PTVSTitr',
      'ER_3HIBUP_Sitr',      'ER_FVSitr',      'ER_AM1CSAitr',      'ER_AM9CSAitr',
      'ER_2HATVACIDitr',      'ER_1A25HVITD2t',      'ER_1A25HVITD2tm',      'ER_DCMPtm',
      'ER_ATPS4mi',      'ER_ITPtm',      'ER_IDPtm',      'ER_CE_Peptide',
      'ER_CE_Abeta_L_lysine',      'ER_CN_Abeta_L_lysine',      'ER_EN_Abeta_L_lysine',      'ER_CE_Tau_L_lysine',
      'ER_CN_Tau_L_lysine',      'ER_EN_Tau_L_lysine',      'ER_CE_TNFA_L_lysine',      'ER_CN_TNFA_L_lysine',
      'ER_EN_TNFA_L_lysine',      'ER_CE_IL6_L_lysine',      'ER_CN_IL6_L_lysine',      'ER_EN_IL6_L_lysine'

    /

  DM_sink_enz(enzymes) "Demand and sink reactions without Gene association in BL model"
    /
********** Non-GPR association enzymes ----------
      'ER_DM_Asn_X_Ser_Thr_ly_',      'ER_DM_core5_g_',      'ER_DM_core7_g_',      'ER_DM_datp_m_',
      'ER_DM_datp_n_',      'ER_DM_dctp_m_',      'ER_DM_dctp_n_',      'ER_DM_dem2emgacpail_prot_hs_r_',
      'ER_DM_dgpi_prot_hs_r_',      'ER_DM_dgtp_m_',      'ER_DM_dgtp_n_',      'ER_DM_dttp_m_',
      'ER_DM_dttp_n_',      'ER_DM_ethamp_r_',      'ER_DM_gncore2_g_',      'ER_DM_gpi_sig_er_',
      'ER_DM_kdn_c_',      'ER_DM_mem2emgacpail_prot_hs_r_',      'ER_DM_Ser_Thr_ly_',      'ER_DM_Ser_Gly_Ala_X_Gly_ly_',
      'ER_DM_sprm_c_',      'ER_DM_T_antigen_g_',      'ER_sink_citr[c]',      'ER_sink_pre_prot[r]',
      'ER_sink_c101coa[c]',      'ER_sink_c81coa[c]',      'ER_sink_dd2coa[c]',      'ER_sink_decdicoa[c]',
      'ER_sink_octdececoa[c]',      'ER_sink_tetdec2coa[c]',      'ER_sink_tetdece1coa[c]',      'ER_DM_1a25dhvitd3[n]',
      'ER_DM_taur[c]',      'ER_DM_pmtcoa[r]',      'ER_sink_5hpet[c]',      'ER_DM_4hrpo',
      'ER_DM_Lcystin',      'ER_DM_fol',      'ER_DM_pnto_R',      'ER_DM_ascb_L[c]',
      'ER_DM_pe_hs[c]',      'ER_DM_akg[c]',      'ER_DM_for[c]',      'ER_DM_mi1345p[c]',
      'ER_DM_mi134p[c]',      'ER_DM_mi145p[c]',      'ER_DM_mi14p[c]',      'ER_DM_pchol_hs[c]',
      'ER_DM_C02712[c]',      'ER_sink_25hvitd2[c]',      'ER_sink_C02528[c]',      'ER_sink_HC02191[c]',
      'ER_sink_HC02194[c]',      'ER_sink_HC02195[c]',      'ER_sink_HC02196[c]',      'ER_sink_HC02197[c]',
      'ER_sink_HC02198[c]',      'ER_sink_HC02220[c]',      'ER_sink_Tyr_ggn[c]',      'ER_sink_avite1[c]',
      'ER_sink_btn[c]',      'ER_sink_c226coa[c]',      'ER_sink_chol[c]',      'ER_sink_cholate[c]',
      'ER_sink_coa[c]',      'ER_sink_crvnc[c]',      'ER_sink_dgchol[c]',      'ER_sink_doco13ecoa[c]',
      'ER_sink_fad[c]',      'ER_sink_fe3[c]',      'ER_sink_gchola[c]',      'ER_sink_glygn2[c]',
      'ER_sink_hdca[c]',      'ER_sink_lnlc[c]',      'ER_sink_lnlccoa[c]',      'ER_sink_lnlncacoa[c]',
      'ER_sink_lnlncgcoa[c]',      'ER_sink_nad[c]',      'ER_sink_nadp[c]',      'ER_sink_odecoa[c]',
      'ER_sink_pmtcoa[c]',      'ER_sink_pydam[c]',      'ER_sink_pydx[c]',      'ER_sink_pydxn[c]',
      'ER_sink_retfa[c]',      'ER_sink_retinol[c]',      'ER_sink_stcoa[c]',      'ER_sink_tag_hs[c]',
      'ER_sink_tchola[c]',      'ER_sink_tdchola[c]',      'ER_sink_thf[c]',      'ER_sink_thmpp[c]',
      'ER_sink_thmtp[c]',      'ER_sink_tmndnc[c]',      'ER_sink_tmndnccoa[c]',      'ER_sink_vitd3[c]',
      'ER_sink_dhcholestanate[c]',      'ER_sink_thcholstoic[c]',      'ER_sink_xol7ah3[c]',      'ER_sink_xol7aone[c]',
      'ER_sink_xoldiolone[c]',      'ER_sink_7klitchol[c]',      'ER_sink_dchac[c]',      'ER_DM_atp_c_',
      'ER_sink_34dhpac[c]',      'ER_DM_sph1p[n]',      'ER_DM_sphs1p[n]',      'ER_DM_gm1_hs[n]',
      'ER_DM_gda1_hs[n]',      'ER_DM_6hddopaqn[c]',      'ER_DM_pail35p_hs[n]',      'ER_DM_gd3_hs[m]',
      'ER_DM_k[g]',      'ER_DM_na1[g]',      'ER_DM_retn[n]',      'ER_DM_15HPET[n]',
      'ER_DM_15HPET[x]',      'ER_DM_15HPET[r]',      'ER_sink_Ser_Gly_Ala_X_Gly[r]',      'ER_DM_12dhchol[c]',
      'ER_DM_3dhcdchol[c]',      'ER_DM_3dhchol[c]',      'ER_DM_3dhdchol[c]',      'ER_DM_3dhlchol[c]',
      'ER_DM_7dhcdchol[c]',      'ER_DM_7dhchol[c]',      'ER_DM_cdca24g[c]',      'ER_DM_cdca3g[c]',
      'ER_DM_coprost[c]',      'ER_DM_hca24g[c]',      'ER_DM_hdca24g[c]',      'ER_DM_hdca6g[c]',
      'ER_DM_hyochol[c]',      'ER_DM_icdchol[c]',      'ER_DM_isochol[c]',      'ER_DM_lca24g[c]',
      'ER_DM_lca3g[c]',      'ER_DM_thyochol[c]',      'ER_DM_uchol[c]',      'ER_sink_his_L[c]',
      'ER_sink_ile_L[c]',      'ER_sink_leu_L[c]',      'ER_sink_lys_L[c]',      'ER_sink_met_L[c]',
      'ER_sink_phe_L[c]',      'ER_sink_thr_L[c]',      'ER_sink_trp_L[c]',      'ER_sink_val_L[c]',
      'ER_sink_ala_L[c]',      'ER_sink_arg_L[c]',      'ER_sink_asn_L[c]',      'ER_sink_asp_L[c]',
      'ER_sink_cys_L[c]',      'ER_sink_gln_L[c]',      'ER_sink_glu_L[c]',      'ER_sink_pro_L[c]',
      'ER_sink_ser_L[c]',      'ER_sink_tyr_L[c]',      'ER_sink_gly[c]',      'ER_sink_4abut[l]',
      'ER_DM_5cysdopa[c]',      'ER_DM_4abut[c]',      'ER_DM_srtn[c]',      'ER_DM_ach[c]',
      'ER_DM_hista[c]',      'ER_DM_kynate[c]',      'ER_DM_tym[c]',      'ER_DM_Lkynr[c]',
      'ER_DM_cbl2[m]',      'ER_DM_Ubiquitin',      'ER_DM_Abeta',      'ER_DM_Tau',
      'ER_DM_TNFA',      'ER_DM_IL6'
    /

  exchange_enz(enzymes) "exchange reactions without Gene association in BL model"
    /
********** Non-GPR association enzymes ----------
      'ER_EX_10fthf[e]',      'ER_EX_10fthf5glu[e]',      'ER_EX_10fthf6glu[e]',      'ER_EX_10fthf7glu[e]',
      'ER_EX_13_cis_retnglc[e]',      'ER_EX_24nph[e]',      'ER_EX_2hb[e]',      'ER_EX_2mcit[e]',
      'ER_EX_34dhoxpeg[e]',      'ER_EX_35cgmp[e]',      'ER_EX_3aib[e]',      'ER_EX_3aib_D[e]',
      'ER_EX_3mlda[e]',      'ER_EX_4nph[e]',      'ER_EX_4nphsf[e]',      'ER_EX_5adtststerone[e]',
      'ER_EX_5adtststerones[e]',      'ER_EX_5dhf[e]',      'ER_EX_5fthf[e]',      'ER_EX_5htrp[e]',
      'ER_EX_5mthf[e]',      'ER_EX_5thf[e]',      'ER_EX_6dhf[e]',      'ER_EX_6htststerone[e]',
      'ER_EX_6thf[e]',      'ER_EX_7dhf[e]',      'ER_EX_7thf[e]',      'ER_EX_acetone[e]',
      'ER_EX_ach[e]',      'ER_EX_acnacngal14acglcgalgluside_hs[e]',      'ER_EX_acnacngalgbside_hs[e]',      'ER_EX_acngalacglcgal14acglcgalgluside_hs[e]',
      'ER_EX_adp[e]',      'ER_EX_adprbp[e]',      'ER_EX_adrn[e]',      'ER_EX_adrnl[e]',
      'ER_EX_aflatoxin[e]',      'ER_EX_ala_B[e]',      'ER_EX_ala_D[e]',      'ER_EX_amp[e]',
      'ER_EX_andrstrn[e]',      'ER_EX_aprgstrn[e]',      'ER_EX_aqcobal[e]',      'ER_EX_arach[e]',
      'ER_EX_arachd[e]',      'ER_EX_ascb_L[e]',      'ER_EX_asp_D[e]',      'ER_EX_atp[e]',
      'ER_EX_avite1[e]',      'ER_EX_bhb[e]',      'ER_EX_bildglcur[e]',      'ER_EX_bilglcur[e]',
      'ER_EX_bilirub[e]',      'ER_EX_camp[e]',      'ER_EX_caro[e]',      'ER_EX_chol[e]',
      'ER_EX_cholate[e]',      'ER_EX_chsterol[e]',      'ER_EX_chtn[e]',      'ER_EX_clpnd[e]',
      'ER_EX_cmp[e]',      'ER_EX_coumarin[e]',      'ER_EX_creat[e]',      'ER_EX_crmp_hs[e]',
      'ER_EX_crn[e]',      'ER_EX_crtstrn[e]',      'ER_EX_crvnc[e]',      'ER_EX_cspg_a[e]',
      'ER_EX_cspg_b[e]',      'ER_EX_cspg_c[e]',      'ER_EX_cspg_d[e]',      'ER_EX_cspg_e[e]',
      'ER_EX_dag_hs[e]',      'ER_EX_dcsptn1[e]',      'ER_EX_dgchol[e]',      'ER_EX_dhdascb[e]',
      'ER_EX_dheas[e]',      'ER_EX_dhf[e]',      'ER_EX_dlnlcg[e]',      'ER_EX_dmhptcrn[e]',
      'ER_EX_dopa[e]',      'ER_EX_dopasf[e]',      'ER_EX_eaflatoxin[e]',      'ER_EX_ebastine[e]',
      'ER_EX_ebastineoh[e]',      'ER_EX_eicostet[e]',      'ER_EX_elaid[e]',      'ER_EX_estradiol[e]',
      'ER_EX_estrones[e]',      'ER_EX_fuc13galacglcgal14acglcgalgluside_hs[e]',      'ER_EX_fuc14galacglcgalgluside_hs[e]',      'ER_EX_fucacgalfucgalacglcgalgluside_hs[e]',
      'ER_EX_fucfuc12gal14acglcgalgluside_hs[e]',      'ER_EX_fucfucfucgalacglc13galacglcgal14acglcgalgluside_hs[e]',      'ER_EX_fucfucgalacglcgalgluside_hs[e]',      'ER_EX_fucgal14acglcgalgluside_hs[e]',
      'ER_EX_fucgalfucgalacglcgalgluside_hs[e]',      'ER_EX_fuc_L[e]',      'ER_EX_galacglcgalgbside_hs[e]',      'ER_EX_galgalfucfucgalacglcgalacglcgal14acglcgalgluside_hs[e]',
      'ER_EX_galgalgalthcrm_hs[e]',      'ER_EX_gbside_hs[e]',      'ER_EX_gchola[e]',      'ER_EX_gdp[e]',
      'ER_EX_gluala[e]',      'ER_EX_glyc_S[e]',      'ER_EX_glygn2[e]',      'ER_EX_glygn4[e]',
      'ER_EX_glygn5[e]',      'ER_EX_gmp[e]',      'ER_EX_gq1b_hs[e]',      'ER_EX_gsn[e]',
      'ER_EX_gt1a_hs[e]',      'ER_EX_gthox[e]',      'ER_EX_gthrd[e]',      'ER_EX_gtp[e]',
      'ER_EX_h2o2[e]',      'ER_EX_ha[e]',      'ER_EX_ha_pre1[e]',      'ER_EX_hco3[e]',
      'ER_EX_hcoumarin[e]',      'ER_EX_hdca[e]',      'ER_EX_hdcea[e]',      'ER_EX_hestratriol[e]',
      'ER_EX_hexc[e]',      'ER_EX_hista[e]',      'ER_EX_hom_L[e]',      'ER_EX_hpdca[e]',
      'ER_EX_hspg[e]',      'ER_EX_htaxol[e]',      'ER_EX_i[e]',      'ER_EX_idp[e]',
      'ER_EX_imp[e]',      'ER_EX_ksi[e]',      'ER_EX_ksi_deg1[e]',      'ER_EX_ksii_core2[e]',
      'ER_EX_ksii_core4[e]',      'ER_EX_lac_D[e]',      'ER_EX_Lcystin[e]',      'ER_EX_leuktrA4[e]',
      'ER_EX_leuktrB4[e]',      'ER_EX_leuktrC4[e]',      'ER_EX_leuktrD4[e]',      'ER_EX_leuktrE4[e]',
      'ER_EX_leuktrF4[e]',      'ER_EX_lgnc[e]',      'ER_EX_lneldc[e]',      'ER_EX_lnlc[e]',
      'ER_EX_lnlnca[e]',      'ER_EX_lnlncg[e]',      'ER_EX_lpchol_hs[e]',      'ER_EX_mag_hs[e]',
      'ER_EX_meoh[e]',      'ER_EX_mthgxl[e]',      'ER_EX_n2m2nmasn[e]',      'ER_EX_nad[e]',
      'ER_EX_nadp[e]',      'ER_EX_ncam[e]',      'ER_EX_no[e]',      'ER_EX_nrpphr[e]',
      'ER_EX_nrpphrsf[e]',      'ER_EX_nrvnc[e]',      'ER_EX_o2s[e]',      'ER_EX_oagd3_hs[e]',
      'ER_EX_oagt3_hs[e]',      'ER_EX_ocdca[e]',      'ER_EX_ocdcea[e]',      'ER_EX_octa[e]',
      'ER_EX_oxa[e]',      'ER_EX_pchol_hs[e]',      'ER_EX_pe_hs[e]',      'ER_EX_peplys[e]',
      'ER_EX_pglyc_hs[e]',      'ER_EX_phyt[e]',      'ER_EX_prgstrn[e]',      'ER_EX_prostgd2[e]',
      'ER_EX_prostge1[e]',      'ER_EX_prostge2[e]',      'ER_EX_ps_hs[e]',      'ER_EX_ptdca[e]',
      'ER_EX_retfa[e]',      'ER_EX_retinol[e]',      'ER_EX_retn[e]',      'ER_EX_Rtotal[e]',
      'ER_EX_Rtotal2[e]',      'ER_EX_Rtotal3[e]',      'ER_EX_s2l2fn2m2masn[e]',      'ER_EX_s2l2n2m2masn[e]',
      'ER_EX_spc_hs[e]',      'ER_EX_sph1p[e]',      'ER_EX_sphs1p[e]',      'ER_EX_srtn[e]',
      'ER_EX_strch1[e]',      'ER_EX_strch2[e]',      'ER_EX_strdnc[e]',      'ER_EX_tagat_D[e]',
      'ER_EX_taxol[e]',      'ER_EX_tchola[e]',      'ER_EX_tdchola[e]',      'ER_EX_tethex3[e]',
      'ER_EX_tetpent3[e]',      'ER_EX_tetpent6[e]',      'ER_EX_tettet6[e]',      'ER_EX_thf[e]',
      'ER_EX_thmtp[e]',      'ER_EX_thym[e]',      'ER_EX_thyox_L[e]',      'ER_EX_tmndnc[e]',
      'ER_EX_triodthy[e]',      'ER_EX_triodthysuf[e]',      'ER_EX_tststerone[e]',      'ER_EX_tststerones[e]',
      'ER_EX_ttdca[e]',      'ER_EX_txa2[e]',      'ER_EX_Tyr_ggn[e]',      'ER_EX_udp[e]',
      'ER_EX_ump[e]',      'ER_EX_urate[e]',      'ER_EX_utp[e]',      'ER_EX_vacc[e]',
      'ER_EX_vitd3[e]',      'ER_EX_whhdca[e]',      'ER_EX_whtststerone[e]',      'ER_EX_xolest_hs[e]',
      'ER_EX_xolest2_hs[e]',      'ER_EX_xoltri24[e]',      'ER_EX_xoltri27[e]',      'ER_EX_xylt[e]',
      'ER_EX_4abutn[e]',      'ER_EX_acmana[e]',      'ER_EX_ahdt[e]',      'ER_EX_ctp[e]',
      'ER_EX_dgmp[e]',      'ER_EX_dgtp[e]',      'ER_EX_dha[e]',      'ER_EX_dhap[e]',
      'ER_EX_dtmp[e]',      'ER_EX_dttp[e]',      'ER_EX_fald[e]',      'ER_EX_HC01104[e]',
      'ER_EX_HC01361[e]',      'ER_EX_HC01440[e]',      'ER_EX_HC01441[e]',      'ER_EX_HC01444[e]',
      'ER_EX_HC01446[e]',      'ER_EX_HC01577[e]',      'ER_EX_HC01700[e]',      'ER_EX_HC02160[e]',
      'ER_EX_HC02161[e]',      'ER_EX_itp[e]',      'ER_EX_orot[e]',      'ER_EX_prpp[e]',
      'ER_EX_so3[e]',      'ER_EX_sprm[e]',      'ER_EX_prostgh2[e]',      'ER_EX_prostgi2[e]',
      'ER_EX_cdp[e]',      'ER_EX_dtdp[e]',      'ER_EX_HC00955[e]',      'ER_EX_citr_L[e]',
      'ER_EX_C02470[e]',      'ER_EX_C02528[e]',      'ER_EX_HC02195[e]',      'ER_EX_HC02196[e]',
      'ER_EX_HC02220[e]',      'ER_EX_HC02191[e]',      'ER_EX_HC02194[e]',      'ER_EX_HC02197[e]',
      'ER_EX_HC02198[e]',      'ER_EX_HC02187[e]',      'ER_EX_HC02180[e]',      'ER_EX_HC02202[e]',
      'ER_EX_HC02203[e]',      'ER_EX_HC02204[e]',      'ER_EX_HC02205[e]',      'ER_EX_HC02206[e]',
      'ER_EX_HC02207[e]',      'ER_EX_HC02213[e]',      'ER_EX_HC02217[e]',      'ER_EX_maltpt[e]',
      'ER_EX_CE2915[e]',      'ER_EX_CE4722[e]',      'ER_EX_CE2916[e]',      'ER_EX_CE4723[e]',
      'ER_EX_CE2917[e]',      'ER_EX_CE4724[e]',      'ER_EX_malthp[e]',      'ER_EX_CE2839[e]',
      'ER_EX_CE2838[e]',      'ER_EX_CE1950[e]',      'ER_EX_cynt[e]',      'ER_EX_CE5786[e]',
      'ER_EX_CE5788[e]',      'ER_EX_CE5789[e]',      'ER_EX_CE5797[e]',      'ER_EX_CE5798[e]',
      'ER_EX_CE5867[e]',      'ER_EX_CE5868[e]',      'ER_EX_CE5869[e]',      'ER_EX_CE4633[e]',
      'ER_EX_CE4881[e]',      'ER_EX_crm_hs[e]',      'ER_EX_CE0074[e]',      'ER_EX_cdpea[e]',
      'ER_EX_12dgr120[e]',      'ER_EX_3bcrn[e]',      'ER_EX_3ddcrn[e]',      'ER_EX_3deccrn[e]',
      'ER_EX_3octdec2crn[e]',      'ER_EX_3octdece1crn[e]',      'ER_EX_3tdcrn[e]',      'ER_EX_c101crn[e]',
      'ER_EX_c10crn[e]',      'ER_EX_c12dc[e]',      'ER_EX_c16dc[e]',      'ER_EX_c3dc[e]',
      'ER_EX_c4crn[e]',      'ER_EX_c4dc[e]',      'ER_EX_c51crn[e]',      'ER_EX_c6crn[e]',
      'ER_EX_c81crn[e]',      'ER_EX_c8crn[e]',      'ER_EX_c8dc[e]',      'ER_EX_ddece1crn[e]',
      'ER_EX_ddecrn[e]',      'ER_EX_decdicrn[e]',      'ER_EX_doco13ac[e]',      'ER_EX_docosac[e]',
      'ER_EX_tetdec2crn[e]',      'ER_EX_tetdece1crn[e]',      'ER_EX_dca[e]',      'ER_EX_4hpro[e]',
      'ER_EX_carn[e]',      'ER_EX_dchac[e]',      'ER_EX_sfcys[e]',      'ER_EX_cysam[e]',
      'ER_EX_fmn[e]',      'ER_EX_oh1[e]',      'ER_EX_ptth[e]',      'ER_EX_q10[e]',
      'ER_EX_q10h2[e]',      'ER_EX_34hpp[e]',      'ER_EX_3mob[e]',      'ER_EX_3mop[e]',
      'ER_EX_4mop[e]',      'ER_EX_5mta[e]',      'ER_EX_ahcys[e]',      'ER_EX_aicar[e]',
      'ER_EX_cbasp[e]',      'ER_EX_idour[e]',      'ER_EX_2pg[e]',      'ER_EX_5hoxindoa[e]',
      'ER_EX_cholp[e]',      'ER_EX_dcmp[e]',      'ER_EX_ethamp[e]',      'ER_EX_glyald[e]',
      'ER_EX_gudac[e]',      'ER_EX_hcys_L[e]',      'ER_EX_icit[e]',      'ER_EX_kynate[e]',
      'ER_EX_L2aadp[e]',      'ER_EX_Lkynr[e]',      'ER_EX_pep[e]',      'ER_EX_xmp[e]',
      'ER_EX_xtsn[e]',      'ER_EX_3pg[e]',      'ER_EX_3hanthrn[e]',      'ER_EX_udpglcur[e]',
      'ER_EX_nicrnt[e]',      'ER_EX_orot5p[e]',      'ER_EX_glyc3p[e]',      'ER_EX_argsuc[e]',
      'ER_EX_acrn[e]',      'ER_EX_pcrn[e]',      'ER_EX_lneldccrn[e]',      'ER_EX_odecrn[e]',
      'ER_EX_stcrn[e]',      'ER_EX_pmtcrn[e]',      'ER_EX_hdcecrn[e]',      'ER_EX_C14769[e]',
      'ER_EX_12HPET[e]',      'ER_EX_15HPET[e]',      'ER_EX_15kprostgf2[e]',      'ER_EX_2oxoadp[e]',
      'ER_EX_34hpl[e]',      'ER_EX_3hmp[e]',      'ER_EX_3hpp[e]',      'ER_EX_3mhis[e]',
      'ER_EX_3uib[e]',      'ER_EX_4tmeabutn[e]',      'ER_EX_56dthm[e]',      'ER_EX_56dura[e]',
      'ER_EX_7dhchsterol[e]',      'ER_EX_aclys[e]',      'ER_EX_adpac[e]',      'ER_EX_adpoh[e]',
      'ER_EX_amet[e]',      'ER_EX_aracheth[e]',      'ER_EX_C04717[e]',      'ER_EX_C04805[e]',
      'ER_EX_C05957[e]',      'ER_EX_C06314[e]',      'ER_EX_C06315[e]',      'ER_EX_C11695[e]',
      'ER_EX_C14768[e]',      'ER_EX_C14770[e]',      'ER_EX_C14771[e]',      'ER_EX_C14825[e]',
      'ER_EX_C14826[e]',      'ER_EX_CE2537[e]',      'ER_EX_CE4843[e]',      'ER_EX_CE5304[e]',
      'ER_EX_CE6247[e]',      'ER_EX_CE7172[e]',      'ER_EX_didecaeth[e]',      'ER_EX_diholineth[e]',
      'ER_EX_docohxeth[e]',      'ER_EX_docteteth[e]',      'ER_EX_dodecanac[e]',      'ER_EX_elaidcrn[e]',
      'ER_EX_forglu[e]',      'ER_EX_HC00900[e]',      'ER_EX_hepdeceth[e]',      'ER_EX_hexdeceeth[e]',
      'ER_EX_hexdiac[e]',      'ER_EX_hgentis[e]',      'ER_EX_hmcr[e]',      'ER_EX_hxcoa[e]',
      'ER_EX_leuktrB4wcooh[e]',      'ER_EX_leuktrB4woh[e]',      'ER_EX_lineth[e]',      'ER_EX_lnlccrn[e]',
      'ER_EX_lthstrl[e]',      'ER_EX_mev_R[e]',      'ER_EX_mi1p_D[e]',      'ER_EX_nwharg[e]',
      'ER_EX_oleth[e]',      'ER_EX_pailar_hs[e]',      'ER_EX_pailpalm_hs[e]',      'ER_EX_pchol2linl_hs[e]',
      'ER_EX_pchol2ole_hs[e]',      'ER_EX_pchol2palm_hs[e]',      'ER_EX_pchol2ste_hs[e]',      'ER_EX_pcholar_hs[e]',
      'ER_EX_pcholdoc_hs[e]',      'ER_EX_pcholeic_hs[e]',      'ER_EX_pcholet_hs[e]',      'ER_EX_pcholhep_hs[e]',
      'ER_EX_pchollinl_hs[e]',      'ER_EX_pcholmyr_hs[e]',      'ER_EX_pcholn15_hs[e]',      'ER_EX_pcholn183_hs[e]',
      'ER_EX_pcholn1836_hs[e]',      'ER_EX_pcholn19_hs[e]',      'ER_EX_pcholn201_hs[e]',      'ER_EX_pcholn203_hs[e]',
      'ER_EX_pcholn204_hs[e]',      'ER_EX_pcholn205_hs[e]',      'ER_EX_pcholn224_hs[e]',      'ER_EX_pcholn225_hs[e]',
      'ER_EX_pcholn2254_hs[e]',      'ER_EX_pcholn226_hs[e]',      'ER_EX_pcholn24_hs[e]',      'ER_EX_pcholn261_hs[e]',
      'ER_EX_pcholn28_hs[e]',      'ER_EX_pcholn281_hs[e]',      'ER_EX_pcholole_hs[e]',      'ER_EX_pcholpalm_hs[e]',
      'ER_EX_pcholpalme_hs[e]',      'ER_EX_pcholste_hs[e]',      'ER_EX_pcollg5hlys[e]',      'ER_EX_pe12_hs[e]',
      'ER_EX_pe13_hs[e]',      'ER_EX_pe14_hs[e]',      'ER_EX_pe15_hs[e]',      'ER_EX_pe161_hs[e]',
      'ER_EX_pe17_hs[e]',      'ER_EX_pe203_hs[e]',      'ER_EX_pe224_hs[e]',      'ER_EX_pe226_hs[e]',
      'ER_EX_pe2linl_hs[e]',      'ER_EX_pear_hs[e]',      'ER_EX_pedh203_hs[e]',      'ER_EX_pelinl_hs[e]',
      'ER_EX_pendecaeth[e]',      'ER_EX_peole_hs[e]',      'ER_EX_pepalm_hs[e]',      'ER_EX_peste_hs[e]',
      'ER_EX_pmeth[e]',      'ER_EX_saccrp_L[e]',      'ER_EX_sebacid[e]',      'ER_EX_sphmyln180241_hs[e]',
      'ER_EX_sphmyln18114_hs[e]',      'ER_EX_sphmyln18115_hs[e]',      'ER_EX_sphmyln18116_hs[e]',      'ER_EX_sphmyln181161_hs[e]',
      'ER_EX_sphmyln18117_hs[e]',      'ER_EX_sphmyln18118_hs[e]',      'ER_EX_sphmyln181181_hs[e]',      'ER_EX_sphmyln18120_hs[e]',
      'ER_EX_sphmyln181201_hs[e]',      'ER_EX_sphmyln18121_hs[e]',      'ER_EX_sphmyln18122_hs[e]',      'ER_EX_sphmyln181221_hs[e]',
      'ER_EX_sphmyln18123_hs[e]',      'ER_EX_sphmyln1824_hs[e]',      'ER_EX_sphmyln1825_hs[e]',      'ER_EX_steeth[e]',
      'ER_EX_subeac[e]',      'ER_EX_tetdecaeth[e]',      'ER_EX_tmlys[e]',      'ER_EX_trideceth[e]',
      'ER_EX_ttdcrn[e]',      'ER_EX_urcan[e]',      'ER_EX_wharachd[e]',      'ER_EX_estriol[e]',
      'ER_EX_3moxtyr[e]',      'ER_EX_5aop[e]',      'ER_EX_acglu[e]',      'ER_EX_alltn[e]',
      'ER_EX_CE2510[e]',      'ER_EX_ddca[e]',      'ER_EX_glyc_R[e]',      'ER_EX_glyclt[e]',
      'ER_EX_Lcyst[e]',      'ER_EX_oaa[e]',      'ER_EX_pac[e]',      'ER_EX_phlac[e]',
      'ER_EX_pser_L[e]',      'ER_EX_ttdcea[e]',      'ER_EX_pheacgly[e]',      'ER_EX_bz[e]',
      'ER_EX_normete_L[e]',      'ER_EX_mepi[e]',      'ER_EX_C05300[e]',      'ER_EX_retinal[e]',
      'ER_EX_maltttr[e]',      'ER_EX_1mncam[e]',      'ER_EX_dhbpt[e]',      'ER_EX_thbpt[e]',
      'ER_EX_adprib[e]',      'ER_EX_homoval[e]',      'ER_EX_sphmyln_hs[e]',      'ER_EX_hxa[e]',
      'ER_EX_Lhcystin[e]',      'ER_EX_core4[e]',      'ER_EX_f1a[e]',      'ER_EX_s2l2n2m2m[e]',
      'ER_EX_acgal[e]',      'ER_EX_acnam[e]',      'ER_EX_pa_hs[e]',      'ER_EX_dxtrn[e]',
      'ER_EX_dhcholestanate[e]',      'ER_EX_thcholstoic[e]',      'ER_EX_xol7ah3[e]',      'ER_EX_xol7aone[e]',
      'ER_EX_xoldiolone[e]',      'ER_EX_7klitchol[e]',      'ER_EX_2obut[e]',      'ER_EX_glcn[e]',
      'ER_EX_acac[e]',      'ER_EX_adn[e]',      'ER_EX_akg[e]',      'ER_EX_asn_L[e]',
      'ER_EX_asp_L[e]',      'ER_EX_but[e]',      'ER_EX_cgly[e]',      'ER_EX_co2[e]',
      'ER_EX_cytd[e]',      'ER_EX_dad_2[e]',      'ER_EX_dcyt[e]',      'ER_EX_dgsn[e]',
      'ER_EX_din[e]',      'ER_EX_duri[e]',      'ER_EX_fe2[e]',      'ER_EX_fe3[e]',
      'ER_EX_fum[e]',      'ER_EX_gal[e]',      'ER_EX_glu_L[e]',      'ER_EX_h[e]',
      'ER_EX_h2o[e]',      'ER_EX_ile_L[e]',      'ER_EX_ins[e]',      'ER_EX_k[e]',
      'ER_EX_lac_L[e]',      'ER_EX_leu_L[e]',      'ER_EX_lys_L[e]',      'ER_EX_mal_L[e]',
      'ER_EX_met_L[e]',      'ER_EX_na1[e]',      'ER_EX_no2[e]',      'ER_EX_o2[e]',
      'ER_EX_orn[e]',      'ER_EX_pi[e]',      'ER_EX_ppi[e]',      'ER_EX_pro_L[e]',
      'ER_EX_ribflv[e]',      'ER_EX_ser_L[e]',      'ER_EX_so4[e]',      'ER_EX_succ[e]',
      'ER_EX_thymd[e]',      'ER_EX_urea[e]',      'ER_EX_uri[e]',      'ER_EX_val_L[e]',
      'ER_EX_pnto_R[e]',      'ER_EX_gly[e]',      'ER_EX_cys_L[e]',      'ER_EX_ala_L[e]',
      'ER_EX_his_L[e]',      'ER_EX_thr_L[e]',      'ER_EX_gln_L[e]',      'ER_EX_phe_L[e]',
      'ER_EX_tyr_L[e]',      'ER_EX_arg_L[e]',      'ER_EX_for[e]',      'ER_EX_nac[e]',
      'ER_EX_ind3ac[e]',      'ER_EX_nh4[e]',      'ER_EX_ac[e]',      'ER_EX_acgam[e]',
      'ER_EX_cit[e]',      'ER_EX_csn[e]',      'ER_EX_drib[e]',      'ER_EX_etha[e]',
      'ER_EX_fol[e]',      'ER_EX_fru[e]',      'ER_EX_galt[e]',      'ER_EX_glcr[e]',
      'ER_EX_glcur[e]',      'ER_EX_glyc[e]',      'ER_EX_hxan[e]',      'ER_EX_malt[e]',
      'ER_EX_malthx[e]',      'ER_EX_malttr[e]',      'ER_EX_man[e]',      'ER_EX_ptrc[e]',
      'ER_EX_rib_D[e]',      'ER_EX_spmd[e]',      'ER_EX_thm[e]',      'ER_EX_trp_L[e]',
      'ER_EX_ura[e]',      'ER_EX_xan[e]',      'ER_EX_xyl_D[e]',      'ER_EX_pydxn[e]',
      'ER_EX_pydx[e]',      'ER_EX_pydam[e]',      'ER_EX_4hbz[e]',      'ER_EX_ppa[e]',
      'ER_EX_arab_L[e]',      'ER_EX_gam[e]',      'ER_EX_pyr[e]',      'ER_EX_tre[e]',
      'ER_EX_btn[e]',      'ER_EX_lcts[e]',      'ER_EX_ade[e]',      'ER_EX_etoh[e]',
      'ER_EX_acald[e]',      'ER_EX_sucr[e]',      'ER_EX_pheme[e]',      'ER_EX_gua[e]',
      'ER_EX_4abut[e]',      'ER_EX_phpyr[e]',      'ER_EX_lanost[e]',      'ER_EX_3mox4hoxm[e]',
      'ER_EX_2h3mv[e]',      'ER_EX_2hiv[e]',      'ER_EX_2m3hbu[e]',      'ER_EX_3h3mglt[e]',
      'ER_EX_3mglutac[e]',      'ER_EX_ppiogly[e]',      'ER_EX_tiggly[e]',      'ER_EX_glutcon[e]',
      'ER_EX_3hivac[e]',      'ER_EX_3hadpac[e]',      'ER_EX_3ohsebac[e]',      'ER_EX_3ohsubac[e]',
      'ER_EX_5ohhexa[e]',      'ER_EX_ethmalac[e]',      'ER_EX_hexgly[e]',      'ER_EX_subgly[e]',
      'ER_EX_4ohbut[e]',      'ER_EX_eic21114tr[e]',      'ER_EX_5eipenc[e]',      'ER_EX_CE4969[e]',
      'ER_EX_CE1310[e]',      'ER_EX_agm[e]',      'ER_EX_T4hcinnm[e]',      'ER_EX_sucsal[e]',
      'ER_EX_CE7081[e]',      'ER_EX_egme[e]',      'ER_EX_sql[e]',      'ER_EX_orn_D[e]',
      'ER_EX_5g2oxpt[e]',      'ER_EX_dhea[e]',      'ER_EX_andrstandn[e]',      'ER_EX_estrone[e]',
      'ER_EX_HC02020[e]',      'ER_EX_xol27oh[e]',      'ER_EX_xol25oh[e]',      'ER_EX_dsmsterol[e]',
      'ER_EX_chsterols[e]',      'ER_EX_3ityr_L[e]',      'ER_EX_35diotyr[e]',      'ER_EX_13_cis_retn[e]',
      'ER_EX_34dhoxmand[e]',      'ER_EX_CE7090[e]',      'ER_EX_CE7085[e]',      'ER_EX_CE7096[e]',
      'ER_EX_CE4877[e]',      'ER_EX_CE1447[e]',      'ER_EX_CE6205[e]',      'ER_EX_trypta[e]',
      'ER_EX_C05767[e]',      'ER_EX_C05770[e]',      'ER_EX_mhista[e]',      'ER_EX_ppbng[e]',
      'ER_EX_mma[e]',      'ER_EX_12ppd_R[e]',      'ER_EX_ametam[e]',      'ER_EX_xylu_L[e]',
      'ER_EX_xylu_D[e]',      'ER_EX_sphings[e]',      'ER_EX_hdd2crn[e]',      'ER_EX_im4ac[e]',
      'ER_EX_CE1918[e]',      'ER_EX_mlthf[e]',      'ER_EX_CE2705[e]',      'ER_EX_sphgn[e]',
      'ER_EX_N1aspmd[e]',      'ER_EX_1a25dhvitd3[e]',      'ER_EX_prist[e]',      'ER_EX_CE2049[e]',
      'ER_EX_CE2047[e]',      'ER_EX_fdp[e]',      'ER_EX_coke[e]',      'ER_EX_5a2opntn[e]',
      'ER_EX_arg_D[e]',      'ER_EX_ldl_hs[e]',      'ER_EX_HC00005[e]',      'ER_EX_CE5629[e]',
      'ER_EX_gd3_hs[e]',      'ER_EX_gluside_hs[e]',      'ER_EX_34dhpe[e]',      'ER_EX_pail_hs[e]',
      'ER_EX_CE5026[e]',      'ER_EX_CE1261[e]',      'ER_EX_galgluside_hs[e]',      'ER_EX_gm1_hs[e]',
      'ER_EX_nadh[e]',      'ER_EX_glc_D[e]',      'ER_EX_sbt_D[e]',      'ER_EX_12dhchol[e]',
      'ER_EX_3dhcdchol[e]',      'ER_EX_3dhchol[e]',      'ER_EX_3dhdchol[e]',      'ER_EX_3dhlchol[e]',
      'ER_EX_7dhcdchol[e]',      'ER_EX_7dhchol[e]',      'ER_EX_cdca24g[e]',      'ER_EX_cdca3g[e]',
      'ER_EX_coprost[e]',      'ER_EX_hca24g[e]',      'ER_EX_hdca24g[e]',      'ER_EX_hdca6g[e]',
      'ER_EX_hyochol[e]',      'ER_EX_icdchol[e]',      'ER_EX_isochol[e]',      'ER_EX_lca24g[e]',
      'ER_EX_lca3g[e]',      'ER_EX_thyochol[e]',      'ER_EX_uchol[e]',      'ER_EX_12htacr[e]',
      'ER_EX_14hmdz[e]',      'ER_EX_1hibup_S[e]',      'ER_EX_1hibupglu_S[e]',      'ER_EX_1hmdgluc[e]',
      'ER_EX_1ohmdz[e]',      'ER_EX_2hatvacid[e]',      'ER_EX_2hatvlac[e]',      'ER_EX_2hatvlacgluc[e]',
      'ER_EX_2hibup_R[e]',      'ER_EX_2hibup_S[e]',      'ER_EX_2hibupglu_S[e]',      'ER_EX_35dsmv[e]',
      'ER_EX_3hibup_R[e]',      'ER_EX_3hibup_S[e]',      'ER_EX_3hibupglu_S[e]',      'ER_EX_3hlvstacid[e]',
      'ER_EX_3hpvs[e]',      'ER_EX_3hpvstet[e]',      'ER_EX_3hsmvacid[e]',      'ER_EX_3ohacmp[e]',
      'ER_EX_4hatvacid[e]',      'ER_EX_4hatvlac[e]',      'ER_EX_4hmdgluc[e]',      'ER_EX_4ohmdz[e]',
      'ER_EX_5ohfvs[e]',      'ER_EX_5ohfvsglu[e]',      'ER_EX_6bhglz[e]',      'ER_EX_6csmvacid[e]',
      'ER_EX_6hlvst[e]',      'ER_EX_6hmsmvacid[e]',      'ER_EX_6hsmvacid[e]',      'ER_EX_6melvacid[e]',
      'ER_EX_6melvst[e]',      'ER_EX_6ohfvsglu[e]',      'ER_EX_7bhglz[e]',      'ER_EX_acmp[e]',
      'ER_EX_am19cs[e]',      'ER_EX_am1csa[e]',      'ER_EX_am9csa[e]',      'ER_EX_atvacid[e]',
      'ER_EX_atvlac[e]',      'ER_EX_caribup_s[e]',      'ER_EX_caribupglu_S[e]',      'ER_EX_crvs[e]',
      'ER_EX_crvsm24[e]',      'ER_EX_csa[e]',      'ER_EX_deoxfvs[e]',      'ER_EX_epoxtac[e]',
      'ER_EX_fvs[e]',      'ER_EX_glc3meacp[e]',      'ER_EX_glz[e]',      'ER_EX_ibup_R[e]',
      'ER_EX_ibup_S[e]',      'ER_EX_ibupgluc[e]',      'ER_EX_isolvstacid[e]',      'ER_EX_lstn[e]',
      'ER_EX_lstnm7[e]',      'ER_EX_lvst[e]',      'ER_EX_mdz[e]',      'ER_EX_nfdac[e]',
      'ER_EX_nfdoh[e]',      'ER_EX_profvs[e]',      'ER_EX_ptvst[e]',      'ER_EX_ptvstlac[e]',
      'ER_EX_pvs[e]',      'ER_EX_smv[e]',      'ER_EX_smvacid[e]',      'ER_EX_tacr[e]',
      'ER_EX_tlacfvs[e]',      'ER_EX_ptvstm13[e]',      'ER_EX_caproic[e]',      'ER_EX_1a25dhvitd2[e]',
      'ER_EX_C13856[e]',      'ER_EX_M00234[e]',      'ER_EX_M01807[e]',      'ER_EX_M00503[e]',
      'ER_EX_M00003[e]',      'ER_EX_M00008[e]',      'ER_EX_M00010[e]',      'ER_EX_M00017[e]',
      'ER_EX_M00019[e]',      'ER_EX_M00021[e]',      'ER_EX_M00115[e]',      'ER_EX_M00117[e]',
      'ER_EX_M00260[e]',      'ER_EX_M00265[e]',      'ER_EX_M00315[e]',      'ER_EX_M00341[e]',
      'ER_EX_M01197[e]',      'ER_EX_M01207[e]',      'ER_EX_M01235[e]',      'ER_EX_M01238[e]',
      'ER_EX_M01582[e]',      'ER_EX_M02053[e]',      'ER_EX_M02457[e]',      'ER_EX_M02613[e]',
      'ER_EX_M02745[e]',      'ER_EX_M03045[e]',      'ER_EX_M03051[e]',      'ER_EX_M03153[e]',
      'ER_EX_M02560[e]',      'ER_EX_C01601[e]',      'ER_EX_M02108[e]',      'ER_EX_M03117[e]',
      'ER_EX_M03134[e]',      'ER_EX_M01111[e]',      'ER_EX_h2co3[e]',      'ER_EX_M01870[e]',
      'ER_EX_ditp[e]',      'ER_EX_M02446[e]',      'ER_EX_M02447[e]',      'ER_EX_M02449[e]',
      'ER_EX_M02451[e]',      'ER_EX_itacon[e]',      'ER_EX_adpman[e]',      'ER_EX_rbl_D[e]',
      'ER_EX_M02155[e]',      'ER_EX_M01989[e]',      'ER_EX_M03131[e]',      'ER_EX_n5m2masn[e]',
      'ER_EX_dolichol_L[e]',      'ER_EX_Peptide',      'ER_EX_Abeta_L_lysine',      'ER_EX_Tau_L_lysine',
      'ER_EX_TNFA_L_lysine',      'ER_EX_IL6_L_lysine'
    /

  feasible_enz(enzymes) "feasible candidate enzymes, excludes redundant identical_enz"
    /
      'E0001',      'E0002',      'E0003',      'E0004',      'E0006',      'E0007',      'E0008',      'E0009',      'E0010',      'E0012',
      'E0014',      'E0017',      'E0018',      'E0019',      'E0020',      'E0026',      'E0028',      'E0030',      'E0033',      'E0034',
      'E0036',      'E0037',      'E0038',      'E0039',      'E0040',      'E0041',      'E0043',      'E0044',      'E0045',      'E0047',
      'E0048',      'E0049',      'E0050',      'E0051',      'E0052',      'E0053',      'E0054',      'E0055',      'E0057',      'E0058',
      'E0063',      'E0065',      'E0066',      'E0068',      'E0074',      'E0075',      'E0076',      'E0079',      'E0081',      'E0083',
      'E0088',      'E0089',      'E0090',      'E0091',      'E0092',      'E0093',      'E0096',      'E0098',      'E0099',      'E0100',
      'E0101',      'E0102',      'E0104',      'E0105',      'E0107',      'E0108',      'E0109',      'E0110',      'E0111',      'E0112',
      'E0114',      'E0115',      'E0117',      'E0118',      'E0119',      'E0120',      'E0122',      'E0123',      'E0124',      'E0125',
      'E0127',      'E0128',      'E0129',      'E0131',      'E0132',      'E0134',      'E0135',      'E0136',      'E0137',      'E0138',
      'E0140',      'E0141',      'E0142',      'E0143',      'E0144',      'E0146',      'E0148',      'E0149',      'E0150',      'E0151',
      'E0155',      'E0156',      'E0159',      'E0170',      'E0171',      'E0172',      'E0173',      'E0174',      'E0175',      'E0176',
      'E0177',      'E0178',      'E0179',      'E0180',      'E0182',      'E0184',      'E0185',      'E0187',      'E0189',      'E0190',
      'E0191',      'E0192',      'E0195',      'E0196',      'E0197',      'E0199',      'E0209',      'E0210',      'E0211',      'E0212',
      'E0213',      'E0215',      'E0216',      'E0218',      'E0219',      'E0220',      'E0221',      'E0222',      'E0223',      'E0224',
      'E0228',      'E0229',      'E0230',      'E0231',      'E0232',      'E0233',      'E0236',      'E0241',      'E0242',      'E0246',
      'E0247',      'E0248',      'E0249',      'E0250',      'E0251',      'E0252',      'E0253',      'E0255',      'E0256',      'E0257',
      'E0258',      'E0260',      'E0261',      'E0262',      'E0263',      'E0264',      'E0265',      'E0268',      'E0273',      'E0274',
      'E0275',      'E0279',      'E0280',      'E0282',      'E0283',      'E0284',      'E0285',      'E0286',      'E0288',      'E0289',
      'E0291',      'E0292',      'E0293',      'E0294',      'E0295',      'E0301',      'E0302',      'E0495',      'E0497',      'E0500',
      'E0501',      'E0505',      'E0506',      'E0507',      'E0510',      'E0511',      'E0512',      'E0516',      'E0517',      'E0519',
      'E0521',      'E0522',      'E0527',      'E0528',      'E0529',      'E0530',      'E0533',      'E0534',      'E0536',      'E0537',
      'E0538',      'E0539',      'E0540',      'E0541',      'E0542',      'E0547',      'E0548',      'E0556',      'E0557',      'E0562',
      'E0563',      'E0565',      'E0567',      'E0568',      'E0569',      'E0571',      'E0572',      'E0573',      'E0574',      'E0579',
      'E0581',      'E0582',      'E0583',      'E0584',      'E0585',      'E0588',      'E0589',      'E0593',      'E0594',      'E0595',
      'E0596',      'E0598',      'E0599',      'E0602',      'E0603',      'E0604',      'E0610',      'E0611',      'E0612',      'E0614',
      'E0615',      'E0616',      'E0617',      'E0618',      'E0619',      'E0620',      'E0621',      'E0622',      'E0623',      'E0624',
      'E0625',      'E0626',      'E0627',      'E0628',      'E0629',      'E0630',      'E0631',      'E0633',      'E0634',      'E0636',
      'E0637',      'E0640',      'E0643',      'E0645',      'E0646',      'E0647',      'E0661',      'E0662',      'E0665',      'E0667',
      'E0668',      'E0669',      'E0671',      'E0672',      'E0673',      'E0676',      'E0681',      'E0682',      'E0683',      'E0684',
      'E0685',      'E0686',      'E0687',      'E0690',      'E0691',      'E0696',      'E0697',      'E0699',      'E0701',      'E0707',
      'E0708',      'E0713',      'E0714',      'E0715',      'E0716',      'E0717',      'E0718',      'E0719',      'E0720',      'E0721',
      'E0722',      'E0723',      'E0724',      'E0725',      'E0726',      'E0727',      'E0728',      'E0729',      'E0732',      'E0734',
      'E0736',      'E0737',      'E0738',      'E0739',      'E0740',      'E0741',      'E0742',      'E0743',      'E0744',      'E0745',
      'E0747',      'E0752',      'E0753',      'E0755',      'E0757',      'E0758',      'E0759',      'E0760',      'E0761',      'E0762',
      'E0764',      'E0766',      'E0767',      'E0772',      'E0775',      'E0776',      'E0778',      'E0779',      'E0780',      'E0781',
      'E0782',      'E0783',      'E0786',      'E0787',      'E0788',      'E0789',      'E0791',      'E0792',      'E0793',      'E0794',
      'E0795',      'E0796',      'E0799',      'E0800',      'E0801',      'E0803',      'E0804',      'E0805',      'E0808',      'E0809',
      'E0810',      'E0811',      'E0812',      'E0814',      'E0816',      'E0828',      'E0832',      'E0833',      'E0834',      'E0835',
      'E0836',      'E0837',      'E0838',      'E0839',      'E0844',      'E0845',      'E0846',      'E0848',      'E0849',      'E0850',
      'E0851',      'E0852',      'E0858',      'E0859',      'E0860',      'E0861',      'E0862',      'E0864',      'E0865',      'E0866',
      'E0867',      'E0868',      'E0869',      'E0873',      'E0874',      'E0878',      'E0879',      'E0880',      'E0881',      'E0886',
      'E0887',      'E0893',      'E0896',      'E0899',      'E0900',      'E0901',      'E0903',      'E0906',      'E0907',      'E0911',
      'E0912',      'E0916',      'E0920',      'E0921',      'E0922',      'E0923',      'E0926',      'E0927',      'E0928',      'E0929',
      'E0930',      'E0932',      'E0935',      'E0938',      'E0940',      'E0943',      'E0945',      'E0946',      'E0947',      'E0948',
      'E0950',      'E0960',      'E0961',      'E0963',      'E0964',      'E0965',      'E0966',      'E0970',      'E0971',      'E0972',
      'E0973',      'E0974',      'E0976',      'E0980',      'E0981',      'E0983',      'E0986',      'E0999',      'E1002',      'E1003',
      'E1004',      'E1005',      'E1006',      'E1009',      'E1010',      'E1011',      'E1012',      'E1016',      'E1018',      'E1019',
      'E1021',      'E1022',      'E1025',      'E1026',      'E1027',      'E1028',      'E1032',      'E1033',      'E1037',      'E1038',
      'E1040',      'E1041',      'E1042',      'E1043',      'E1046',      'E1047',      'E1048',      'E1049',      'E1051',      'E1052',
      'E1053',      'E1054',      'E1056',      'E1057',      'E1058',      'E1059',      'E1060',      'E1061',      'E1065',      'E1066',
      'E1067',      'E1069',      'E1072',      'E1073',      'E1087',      'E1088',      'E1090',      'E1092',      'E1093',      'E1094',
      'E1100',      'E1101',      'E1102',      'E1103',      'E1111',      'E1114',      'E1116',      'E1123',      'E1124',      'E1128',
      'E1131',      'E1143',      'E1146',      'E1148',      'E1149',      'E1155',      'E1157',      'E1159',      'E1160',      'E1161',
      'E1164',      'E1165',      'E1166',      'E1169',      'E1170',      'E1171',      'E1174',      'E1176',      'E1177',      'E1182',
      'E1183',      'E1185',      'E1186',      'E1187',      'E1188',      'E1189',      'E1190',      'E1192',      'E1194',      'E1197',
      'E1198',      'E1199',      'E1204',      'E1207',      'E1209',      'E1210',      'E1211',      'E1212',      'E1213',      'E1215',
      'E1216',      'E1217',      'E1218',      'E1224',      'E1225',      'E1227',      'E1228',      'E1230',      'E1231',      'E1232',
      'E1233',      'E1234',      'E1238',      'E1239',      'E1240',      'E1241',      'E1243',      'E1245',      'E1246',      'E1248',
      'E1249',      'E1260',      'E1271',      'E1294',      'E1297',      'E1299',      'E1301',      'E1302',      'E1303',      'E1304',
      'E1309',      'E1311',      'E1317',      'E1318',      'E1320',      'E1322',      'E1323',      'E1324',      'E1325',      'E1326',
      'E1329',      'E1332',      'E1343',      'E1345',      'E1363',      'E1366',      'E1373',      'E1374',      'E1376',      'E1383',
      'E1387',      'E1388',      'E1389',      'E1391',      'E1395',      'E1398',      'E1402',      'E1403',      'E1405',      'E1406',
      'E1407',      'E1408',      'E1409',      'E1412',      'E1416',      'E1417',      'E1418',      'E1420',      'E1425',      'E1426',
      'E1430',      'E1431',      'E1432',      'E1433',      'E1434',      'E1435',      'E1437',      'E1439',      'E1440',      'E1442',
      'E1443',      'E1445',      'E1446',      'E1447',      'E1448',      'E1449',      'E1451',      'E1452',      'E1453',      'E1454',
      'E1455',      'E1458',      'E1462',      'E1464',      'E1469',      'E1470',      'E1471',      'E1472',      'E1476',      'E1477',
      'E1478',      'E1479',      'E1481',      'E1483',      'E1486',      'E1488',      'E1489',      'E1490',      'E1492',      'E1493',
      'E1494',      'E1496',      'E1497',      'E1498',      'E1499',      'E1500',      'E1507',      'E1512',      'E1513',      'E1514',
      'E1515',      'E1531',      'E1533',      'E1536',      'E1537',      'E1538',      'E1539',      'E1540',      'E1542',      'E1544',
      'E1546',      'E1547',      'E1549',      'E1550',      'E1551',      'E1554',      'E1556',      'E1560',      'E1561',      'E1566',
      'E1568',      'E1569',      'E1570',      'E1571',      'E1573',      'E1576',      'E1577',      'E1578',      'E1579',      'E1580',
      'E1581',      'E1582',      'E1583',      'E1585',      'E1586',      'E1587',      'E1588',      'E1590',      'E1593',      'E1594',
      'E1596',      'E1602',      'E1608',      'E1609',      'E1610',      'E1611',      'E1614',      'E1615',      'E1616',      'E1617',
      'E1618',      'E1619',      'E1625',      'E1628',      'E1632',      'E1634',      'E1636',      'E1640',      'E1641',      'E1642',
      'E1644',      'E1646',      'E1647',      'E1648',      'E1649',      'E1653',      'E1654',      'E1655',      'E1656',      'E1661',
      'E1664',      'E1666',      'E1676',      'E1677',      'E1678',      'E1679',      'E1680',      'E1681',      'E1684',      'E1685',
      'E1687',      'E1689',      'E1690',      'E1691',      'E1699',      'E1701',      'E1703',      'E1705',      'E1707',      'E1709',
      'E1710',      'E1712',      'E1713',      'E1715',      'E1716',      'E1720',      'E1721',      'E1722',      'E1724',      'E1726',
      'E1734',      'E1735',      'E1736',      'E1743',      'E1745',      'E1748',      'E1749',      'E1751',      'E1752',      'E1753',
      'E1754',      'E1757',      'E1758',      'E1761',      'E1765',      'E1767',      'E1768',      'E1769',      'E1770',      'E1771',
      'E1772',      'E1774',      'E1775',      'E1776',      'E1780',      'E1784',      'E1785',      'E1787',      'E1790',      'E1791',
      'E1793',      'E1795',      'E1796',      'E1798',      'E1800',      'E1805',      'E1806',      'E1807',      'E1809',      'E1810',
      'E1812',      'E1813',      'E1814',      'E1815',      'E1817',      'E1819',      'E1820',      'E1822',      'E1823',      'E1824',
      'E1827',      'E1829',      'E1830',      'E1832',      'E1834',      'E1836',      'E1840',      'E1843',      'E1844',      'E1845',
      'E1847',      'E1848',      'E1850',      'E1851',      'E1854',      'E1855',      'E1856',      'E1857',      'E1860',      'E1862',
      'E1863',      'E1867',      'E1868',      'E1870',      'E1872',      'E1874',      'E1878',      'E1879',      'E1882',      'E1890',
      'E1891',      'E1892',      'E1895',      'E1896',      'E1898',      'E1899',      'E1902',      'E1905',      'E1908',      'E1909',
      'E1910',      'E1917',      'E1921',      'E1922',      'E1923',      'E1929',      'E1931',      'E1934',      'E1935',      'E1938',
      'E1941',      'E1943',      'E1945',      'E1946',      'E1949',      'E1950',      'E1960',      'E1961',      'E1962',      'E1964',
      'E1971',      'E1973',      'E1975',      'E1978',      'E1981',      'E1984',      'E1987',      'E1989',      'E1990',      'E1991',
      'E1992',      'E2003',      'E2007',      'E2011',      'E2013',      'E2014',      'E2018',      'E2022',      'E2024',      'E2025',
      'E2026',      'E2027',      'E2028',      'E2029',      'E2030',      'E2031',      'E2032',      'E2033',      'E2034',      'E2035',
      'E2037',      'E2038',      'E2044',      'E2049',      'E2050',      'E2077',      'E2081',      'E2082',      'E2089',      'E2090',
      'E2092',      'E2094',      'E2095',      'E2107',      'E2114',      'E2126',      'E2134',      'E2135',      'E2136',      'E2137',
      'E2139',      'E2140',      'E2142',      'E2146',      'E2149',      'E2150',      'E2151',      'E2152',      'E2153',      'E2154',
      'E2159',      'E2161',      'E2163',      'E2166',      'E2171',      'E2172',      'E2174',      'E2175',      'E2176',      'E2178',
      'E2185',      'E2190',      'E2193',      'E2200',      'E2219',      'E2221',      'E2222',      'E2224',      'E2225',      'E2226',
      'E2228',      'E2230',      'E2231',      'E2232',      'E2256',      'E2262',      'E2263',      'E2266',      'E2270',      'E2273',
      'E2276',      'E2282',      'E2297',      'E2300',      'E2302',      'E2304',      'E2305',      'E2307',      'E2315',      'E2316',
      'E2318',      'E2492',      'E2494'

********** Non-GPR association enzymes ----------
      'ER_10FTHF5GLUtl',      'ER_10FTHF5GLUtm',      'ER_10FTHF6GLUtl',      'ER_10FTHF6GLUtm',
      'ER_10FTHF7GLUtl',      'ER_10FTHF7GLUtm',      'ER_10FTHFtl',      'ER_10FTHFtm',
      'ER_24NPHte',      'ER_25HVITD2tin_m',      'ER_25HVITD3tin_m',      'ER_2DR1PP',
      'ER_2MCITt',      'ER_34DHOXPEGt',      'ER_35CGMPtn',      'ER_3DPHBH1',
      'ER_3DPHBH2',      'ER_3HBCOAHLm',      'ER_3MLDAt',      'ER_3MOBt2im',
      'ER_3MOPt2im',      'ER_4ABUTtm',      'ER_4HBZCOAFm',      'ER_4HBZFm',
      'ER_4MOPt2im',      'ER_4NPHSFte',      'ER_4NPHte',      'ER_5ADTSTSTERONESte',
      'ER_5ADTSTSTERONEte',      'ER_5AOPtm',      'ER_5DHFtl',      'ER_5THFtl',
      'ER_5THFtm',      'ER_6DHFtl',      'ER_6DHFtm',      'ER_6HTSTSTERONEte',
      'ER_6HTSTSTERONEtr',      'ER_6THFtl',      'ER_6THFtm',      'ER_7DHCHSTEROLtr',
      'ER_7DHFtl',      'ER_7DHFtm',      'ER_7THFtl',      'ER_7THFtm',
      'ER_AASAD3m',      'ER_ABTD',      'ER_ACACtx',      'ER_ACALDtm',
      'ER_ACCOAtn',      'ER_ACGAGBSIDEtg',      'ER_ACGAGBSIDEtl',      'ER_ACGALK',
      'ER_ACGALK2',      'ER_ACGALtlg',      'ER_ACGALtly',      'ER_ACGAMtly',
      'ER_ACGBGBSIDEtg',      'ER_ACGBGBSIDEtl',      'ER_ACHtn',      'ER_ACNACNGAL14ACGLCGALGLUSIDEte',
      'ER_ACNACNGALGBSIDEte',      'ER_ACNACNGALGBSIDEtg',      'ER_ACNAMtn',      'ER_ACNGALACGLCGAL14ACGLCGALGLUSIDEte',
      'ER_ACNGALACGLCGAL14ACGLCGALGLUSIDEtg',      'ER_ACNMLr',      'ER_ACt2m',      'ER_ACt2r',
      'ER_ACtg',      'ER_ADCim',      'ER_ADNK1m',      'ER_ADRNCOAtx',
      'ER_ADRNt',      'ER_AFLATOXINte',      'ER_AHCYStr',      'ER_AKGtp',
      'ER_AMETr',      'ER_AMPtp',      'ER_ANDRSTRNte',      'ER_ANDRSTRNtr',
      'ER_AQCOBALt',      'ER_ARAB_Lt',      'ER_ARACHCOAtx',      'ER_ARACHDCOAtx',
      'ER_ARACHDtr',      'ER_ARACHt',      'ER_R_group_phosphotase_1',      'ER_R_group_phosphotase_3',
      'ER_ARTFR208',      'ER_ARTPLM3',      'ER_ASCBOX',      'ER_ASCBt',
      'ER_ASPDxt',      'ER_ATP1ter',      'ER_ATP2ter',      'ER_ATPtn',
      'ER_ATPtx',      'ER_B3GALTg',      'ER_BALAtmr',      'ER_BHBt',
      'ER_BHBtm',      'ER_BILDGLCURtr',      'ER_BILIRUBtr',      'ER_BZt',
      'ER_BZtr',      'ER_C226COAtx',      'ER_C226CRNt',      'ER_CAROtr',
      'ER_CBL2OR',      'ER_CBPter',      'ER_CDPDAGtm',      'ER_CHOLPtg',
      'ER_CHOLPtl',      'ER_CHOLtn',      'ER_CITMCOAHm',      'ER_CITMCOALm',
      'ER_CLPNDCOAtx',      'ER_CLPNDt',      'ER_CMPACNAtn',      'ER_CO2ter',
      'ER_CO2tg',      'ER_CO2tm',      'ER_CO2tp',      'ER_COAtg',
      'ER_COAtl',      'ER_COAtn',      'ER_COAtp',      'ER_COAtr',
      'ER_COQ5m',      'ER_CORE5GTg',      'ER_CORE7GTg',      'ER_COUCOAFm',
      'ER_COUMARINte',      'ER_CRMPte',      'ER_CRNCAR3tp',      'ER_CRNtx',
      'ER_CRTSTRNt',      'ER_CRVNCtr',      'ER_CSAPASEly',      'ER_CSBPASEly',
      'ER_CSCPASEly',      'ER_CSDPASEly',      'ER_CSEPASEly',      'ER_CSPG_At',
      'ER_CSPG_Atly',      'ER_CSPG_Btly',      'ER_CSPG_Ct',      'ER_CSPG_Ctly',
      'ER_CSPG_Dt',      'ER_CSPG_Dtly',      'ER_CSPG_Et',      'ER_CSPG_Etly',
      'ER_CTPtn',      'ER_CYSGLTH',      'ER_CYTDK2m',      'ER_D_3AIBt',
      'ER_DADNK',      'ER_DAG_HSter',      'ER_DAGt',      'ER_DALAxt',
      'ER_DATPtn',      'ER_DCK1m',      'ER_DCSPTN1COAtx',      'ER_DCSPTN1t',
      'ER_DCTPtn',      'ER_DECDPtm',      'ER_DEDOLP1_L',      'ER_DEDOLP2_L',
      'ER_DEDOLR_L',      'ER_DESAT22_1p',      'ER_DESAT22_2p',      'ER_DGCHOLte',
      'ER_DGCHOLtx',      'ER_DGK2m',      'ER_DGSNtm',      'ER_DGTPtn',
      'ER_DGULND',      'ER_DHEAStr',      'ER_DHEAtr',      'ER_DHFtl',
      'ER_DHFtm',      'ER_DHPR2',      'ER_DIGALSIDEtl',      'ER_DKMPPD',
      'ER_DM_Asn_X_Ser_Thr_ly_',      'ER_DM_core5_g_',      'ER_DM_core7_g_',      'ER_DM_datp_m_',
      'ER_DM_datp_n_',      'ER_DM_dctp_m_',      'ER_DM_dctp_n_',      'ER_DM_dem2emgacpail_prot_hs_r_',
      'ER_DM_dgpi_prot_hs_r_',      'ER_DM_dgtp_m_',      'ER_DM_dgtp_n_',      'ER_DM_dttp_m_',
      'ER_DM_dttp_n_',      'ER_DM_ethamp_r_',      'ER_DM_gncore2_g_',      'ER_DM_gpi_sig_er_',
      'ER_DM_kdn_c_',      'ER_DM_mem2emgacpail_prot_hs_r_',      'ER_DM_Ser_Thr_ly_',      'ER_DM_Ser_Gly_Ala_X_Gly_ly_',
      'ER_DM_sprm_c_',      'ER_DM_T_antigen_g_',      'ER_DMHPTCRNt',      'ER_DMHPTCRNte',
      'ER_DMNONCOACRNCPT1',      'ER_DMNONCRNt',      'ER_DNADtn',      'ER_DOLMANP_Uter',
      'ER_DOLPMT4_Uer',      'ER_DOPASFt',      'ER_DPCOAtl',      'ER_DPHMBDCm',
      'ER_DPPS',      'ER_DRIBt',      'ER_DSAT',      'ER_DTDPtn',
      'ER_DTTPtn',      'ER_EAFLATOXINte',      'ER_EBASTINEOHte',      'ER_EBASTINEOHtr',
      'ER_EBASTINEte',      'ER_EBASTINEtr',      'ER_EICOSTETt',      'ER_ENGASE2ly',
      'ER_ENGASE3ly',      'ER_ESTRADIOLt',      'ER_ESTRADIOLtr',      'ER_ESTRIOLtr',
      'ER_ESTRONEtr',      'ER_EX_10fthf[e]',      'ER_EX_10fthf5glu[e]',      'ER_EX_10fthf6glu[e]',
      'ER_EX_10fthf7glu[e]',      'ER_EX_13_cis_retnglc[e]',      'ER_EX_24nph[e]',      'ER_EX_2hb[e]',
      'ER_EX_2mcit[e]',      'ER_EX_34dhoxpeg[e]',      'ER_EX_35cgmp[e]',      'ER_EX_3aib[e]',
      'ER_EX_3aib_D[e]',      'ER_EX_3mlda[e]',      'ER_EX_4nph[e]',      'ER_EX_4nphsf[e]',
      'ER_EX_5adtststerone[e]',      'ER_EX_5adtststerones[e]',      'ER_EX_5dhf[e]',      'ER_EX_5fthf[e]',
      'ER_EX_5htrp[e]',      'ER_EX_5mthf[e]',      'ER_EX_5thf[e]',      'ER_EX_6dhf[e]',
      'ER_EX_6htststerone[e]',      'ER_EX_6thf[e]',      'ER_EX_7dhf[e]',      'ER_EX_7thf[e]',
      'ER_EX_acetone[e]',      'ER_EX_ach[e]',      'ER_EX_acnacngal14acglcgalgluside_hs[e]',      'ER_EX_acnacngalgbside_hs[e]',
      'ER_EX_acngalacglcgal14acglcgalgluside_hs[e]',      'ER_EX_adp[e]',      'ER_EX_adprbp[e]',      'ER_EX_adrn[e]',
      'ER_EX_adrnl[e]',      'ER_EX_aflatoxin[e]',      'ER_EX_ala_B[e]',      'ER_EX_ala_D[e]',
      'ER_EX_amp[e]',      'ER_EX_andrstrn[e]',      'ER_EX_aprgstrn[e]',      'ER_EX_aqcobal[e]',
      'ER_EX_arach[e]',      'ER_EX_arachd[e]',      'ER_EX_ascb_L[e]',      'ER_EX_asp_D[e]',
      'ER_EX_atp[e]',      'ER_EX_avite1[e]',      'ER_EX_bhb[e]',      'ER_EX_bildglcur[e]',
      'ER_EX_bilglcur[e]',      'ER_EX_bilirub[e]',      'ER_EX_camp[e]',      'ER_EX_caro[e]',
      'ER_EX_chol[e]',      'ER_EX_cholate[e]',      'ER_EX_chsterol[e]',      'ER_EX_chtn[e]',
      'ER_EX_clpnd[e]',      'ER_EX_cmp[e]',      'ER_EX_coumarin[e]',      'ER_EX_creat[e]',
      'ER_EX_crmp_hs[e]',      'ER_EX_crn[e]',      'ER_EX_crtstrn[e]',      'ER_EX_crvnc[e]',
      'ER_EX_cspg_a[e]',      'ER_EX_cspg_b[e]',      'ER_EX_cspg_c[e]',      'ER_EX_cspg_d[e]',
      'ER_EX_cspg_e[e]',      'ER_EX_dag_hs[e]',      'ER_EX_dcsptn1[e]',      'ER_EX_dgchol[e]',
      'ER_EX_dhdascb[e]',      'ER_EX_dheas[e]',      'ER_EX_dhf[e]',      'ER_EX_dlnlcg[e]',
      'ER_EX_dmhptcrn[e]',      'ER_EX_dopa[e]',      'ER_EX_dopasf[e]',      'ER_EX_eaflatoxin[e]',
      'ER_EX_ebastine[e]',      'ER_EX_ebastineoh[e]',      'ER_EX_eicostet[e]',      'ER_EX_elaid[e]',
      'ER_EX_estradiol[e]',      'ER_EX_estrones[e]',      'ER_EX_fuc13galacglcgal14acglcgalgluside_hs[e]',      'ER_EX_fuc14galacglcgalgluside_hs[e]',
      'ER_EX_fucacgalfucgalacglcgalgluside_hs[e]',      'ER_EX_fucfuc12gal14acglcgalgluside_hs[e]',      'ER_EX_fucfucfucgalacglc13galacglcgal14acglcgalgluside_hs[e]',      'ER_EX_fucfucgalacglcgalgluside_hs[e]',
      'ER_EX_fucgal14acglcgalgluside_hs[e]',      'ER_EX_fucgalfucgalacglcgalgluside_hs[e]',      'ER_EX_fuc_L[e]',      'ER_EX_galacglcgalgbside_hs[e]',
      'ER_EX_galgalfucfucgalacglcgalacglcgal14acglcgalgluside_hs[e]',      'ER_EX_galgalgalthcrm_hs[e]',      'ER_EX_gbside_hs[e]',      'ER_EX_gchola[e]',
      'ER_EX_gdp[e]',      'ER_EX_gluala[e]',      'ER_EX_glyc_S[e]',      'ER_EX_glygn2[e]',
      'ER_EX_glygn4[e]',      'ER_EX_glygn5[e]',      'ER_EX_gmp[e]',      'ER_EX_gq1b_hs[e]',
      'ER_EX_gsn[e]',      'ER_EX_gt1a_hs[e]',      'ER_EX_gthox[e]',      'ER_EX_gthrd[e]',
      'ER_EX_gtp[e]',      'ER_EX_h2o2[e]',      'ER_EX_ha[e]',      'ER_EX_ha_pre1[e]',
      'ER_EX_hco3[e]',      'ER_EX_hcoumarin[e]',      'ER_EX_hdca[e]',      'ER_EX_hdcea[e]',
      'ER_EX_hestratriol[e]',      'ER_EX_hexc[e]',      'ER_EX_hista[e]',      'ER_EX_hom_L[e]',
      'ER_EX_hpdca[e]',      'ER_EX_hspg[e]',      'ER_EX_htaxol[e]',      'ER_EX_i[e]',
      'ER_EX_idp[e]',      'ER_EX_imp[e]',      'ER_EX_ksi[e]',      'ER_EX_ksi_deg1[e]',
      'ER_EX_ksii_core2[e]',      'ER_EX_ksii_core4[e]',      'ER_EX_lac_D[e]',      'ER_EX_Lcystin[e]',
      'ER_EX_leuktrA4[e]',      'ER_EX_leuktrB4[e]',      'ER_EX_leuktrC4[e]',      'ER_EX_leuktrD4[e]',
      'ER_EX_leuktrE4[e]',      'ER_EX_leuktrF4[e]',      'ER_EX_lgnc[e]',      'ER_EX_lneldc[e]',
      'ER_EX_lnlc[e]',      'ER_EX_lnlnca[e]',      'ER_EX_lnlncg[e]',      'ER_EX_lpchol_hs[e]',
      'ER_EX_mag_hs[e]',      'ER_EX_meoh[e]',      'ER_EX_mthgxl[e]',      'ER_EX_n2m2nmasn[e]',
      'ER_EX_nad[e]',      'ER_EX_nadp[e]',      'ER_EX_ncam[e]',      'ER_EX_no[e]',
      'ER_EX_nrpphr[e]',      'ER_EX_nrpphrsf[e]',      'ER_EX_nrvnc[e]',      'ER_EX_o2s[e]',
      'ER_EX_oagd3_hs[e]',      'ER_EX_oagt3_hs[e]',      'ER_EX_ocdca[e]',      'ER_EX_ocdcea[e]',
      'ER_EX_octa[e]',      'ER_EX_oxa[e]',      'ER_EX_pchol_hs[e]',      'ER_EX_pe_hs[e]',
      'ER_EX_peplys[e]',      'ER_EX_pglyc_hs[e]',      'ER_EX_phyt[e]',      'ER_EX_prgstrn[e]',
      'ER_EX_prostgd2[e]',      'ER_EX_prostge1[e]',      'ER_EX_prostge2[e]',      'ER_EX_ps_hs[e]',
      'ER_EX_ptdca[e]',      'ER_EX_retfa[e]',      'ER_EX_retinol[e]',      'ER_EX_retn[e]',
      'ER_EX_Rtotal[e]',      'ER_EX_Rtotal2[e]',      'ER_EX_Rtotal3[e]',      'ER_EX_s2l2fn2m2masn[e]',
      'ER_EX_s2l2n2m2masn[e]',      'ER_EX_spc_hs[e]',      'ER_EX_sph1p[e]',      'ER_EX_sphs1p[e]',
      'ER_EX_srtn[e]',      'ER_EX_strch1[e]',      'ER_EX_strch2[e]',      'ER_EX_strdnc[e]',
      'ER_EX_tagat_D[e]',      'ER_EX_taxol[e]',      'ER_EX_tchola[e]',      'ER_EX_tdchola[e]',
      'ER_EX_tethex3[e]',      'ER_EX_tetpent3[e]',      'ER_EX_tetpent6[e]',      'ER_EX_tettet6[e]',
      'ER_EX_thf[e]',      'ER_EX_thmtp[e]',      'ER_EX_thym[e]',      'ER_EX_thyox_L[e]',
      'ER_EX_tmndnc[e]',      'ER_EX_triodthy[e]',      'ER_EX_triodthysuf[e]',      'ER_EX_tststerone[e]',
      'ER_EX_tststerones[e]',      'ER_EX_ttdca[e]',      'ER_EX_txa2[e]',      'ER_EX_Tyr_ggn[e]',
      'ER_EX_udp[e]',      'ER_EX_ump[e]',      'ER_EX_urate[e]',      'ER_EX_utp[e]',
      'ER_EX_vacc[e]',      'ER_EX_vitd3[e]',      'ER_EX_whhdca[e]',      'ER_EX_whtststerone[e]',
      'ER_EX_xolest_hs[e]',      'ER_EX_xolest2_hs[e]',      'ER_EX_xoltri24[e]',      'ER_EX_xoltri27[e]',
      'ER_EX_xylt[e]',      'ER_F1Atg',      'ER_FADH2tru',      'ER_FADH2tx',
      'ER_FADtru',      'ER_FADtx',      'ER_FALDtly',      'ER_FCOAH',
      'ER_FE2t',      'ER_FE2tm',      'ER_FORMCOAtx',      'ER_FORt2m',
      'ER_FORtr',      'ER_FRDPtr',      'ER_FUC13GALACGLCGAL14ACGLCGALGLUSIDEte',      'ER_FUC13GALACGLCGAL14ACGLCGALGLUSIDEtg',
      'ER_FUC14GALACGLCGALGLUSIDEte',      'ER_FUC14GALACGLCGALGLUSIDEtg',      'ER_FUCACGALFUCGALACGLCGALGLUSIDEte',      'ER_FUCFUC12GAL14ACGLCGALGLUSIDEte',
      'ER_FUCFUC12GAL14ACGLCGALGLUSIDEtg',      'ER_FUCFUCFUCGALACGLC13GALACGLCGAL14ACGLCGALGLUSIDEte',      'ER_FUCFUCFUCGALACGLC13GALACGLCGAL14ACGLCGALGLUSIDEtg',      'ER_FUCFUCGALACGLCGALGLUSIDEte',
      'ER_FUCFUCGALACGLCGALGLUSIDEtg',      'ER_FUCGAL14ACGLCGALGLUSIDEte',      'ER_FUCGAL14ACGLCGALGLUSIDEtg',      'ER_FUCGALFUCGALACGLCGALGLUSIDEte',
      'ER_FUCtly',      'ER_G5SADrm',      'ER_GACPAILter',      'ER_GALACGLCGALGBSIDEte',
      'ER_GALACGLCGALGBSIDEtg',      'ER_GALGALFUCFUCGALACGLCGALACGLCGAL14ACGLCGALGLUSIDEte',      'ER_GALGALFUCFUCGALACGLCGALACGLCGAL14ACGLCGALGLUSIDEtg',      'ER_GALGALGALTHCRMte',
      'ER_GALGALGALTHCRMtg',      'ER_GALGLUSIDEtg',      'ER_GALSIDEtl',      'ER_GALtly',
      'ER_GBSIDEte',      'ER_GBSIDEtl',      'ER_GCHOLAte',      'ER_GDPtg',
      'ER_GGT_L',      'ER_GGT6',      'ER_GLACter',      'ER_GLCMter',
      'ER_GLCter',      'ER_GLCtly',      'ER_GLCURter',      'ER_GLNtm',
      'ER_GLUt7l',      'ER_GLXtm',      'ER_GLXtp',      'ER_GLYC3Ptm',
      'ER_GLYCK2',      'ER_GLYCLTDym',      'ER_GLYCLTtp',      'ER_GLYC_St',
      'ER_GLYCtm',      'ER_GLYtm',      'ER_GLYtp',      'ER_GMPtg',
      'ER_GMPtn',      'ER_GQ1Bte',      'ER_GT1Ate',      'ER_GTHDH',
      'ER_GTHRDtr',      'ER_GULN3D',      'ER_GULNDer',      'ER_GULNter',
      'ER_H2O2t',      'ER_H2O2tly',      'ER_H2O2tm',      'ER_H2O2tp',
      'ER_H2Oter',      'ER_H2Otg',      'ER_H2Otly',      'ER_H2Otn',
      'ER_H2Otp',      'ER_HAtly',      'ER_HCOUMARINte',      'ER_HDCAter',
      'ER_HDD2COAtx',      'ER_HESTRATRIOLte',      'ER_HESTRATRIOLtr',      'ER_HEXCCOAtx',
      'ER_HEXCt',      'ER_HMGCOAtm',      'ER_HMGCOAtx',      'ER_HPDCAt',
      'ER_HPYRDC',      'ER_HPYRDCm',      'ER_HPYRtp',      'ER_HSAT1ly',
      'ER_HSAT2ly',      'ER_HSAT3ly',      'ER_HSAT4ly',      'ER_HSPASEly',
      'ER_HSPGt',      'ER_HSPGtly',      'ER_HTAXOLte',      'ER_Htg',
      'ER_Htr',      'ER_Htx',      'ER_ILEt5m',      'ER_IPDPtx',
      'ER_KDNH',      'ER_KSII_CORE2t',      'ER_KSII_CORE2tly',      'ER_KSII_CORE4t',
      'ER_KSII_CORE4tly',      'ER_KSItly',      'ER_KYNATESYN',      'ER_LEUKTRB4tr',
      'ER_LEUKTRD4t',      'ER_LEUt5m',      'ER_LGNCCOAtx',      'ER_LINKDEG1ly',
      'ER_LINKDEG2ly',      'ER_LINKDEG3ly',      'ER_LINKDEG4ly',      'ER_LNELDCt',
      'ER_LPCHOLt',      'ER_LTC4CP',      'ER_LTD4DP',      'ER_MAGt',
      'ER_MANtly',      'ER_MCITS',      'ER_MDRPD',      'ER_MEOHt2',
      'ER_MEOHtly',      'ER_MGSA',      'ER_MGSA2',      'ER_MI134P4P',
      'ER_MI13PP',      'ER_MI14P4P',      'ER_MINOHPtn',      'ER_MTHGXLt',
      'ER_N2M2NMASNtly',      'ER_N4Tg',      'ER_NADHtpu',      'ER_NADHtru',
      'ER_NADPHtru',      'ER_NADPHtxu',      'ER_NADPtru',      'ER_NADPtxu',
      'ER_NADtn',      'ER_NADtru',      'ER_NAGAlby',      'ER_NAGLCAly',
      'ER_NCAMUP',      'ER_NH4tn',      'ER_NH4tp',      'ER_NICRNS',
      'ER_NICRNTtn',      'ER_NMNtn',      'ER_NOt',      'ER_NRPPHRSFt',
      'ER_NRVNCCOAtx',      'ER_O2St',      'ER_O2Stm',      'ER_O2ter',
      'ER_O2tm',      'ER_O2tn',      'ER_O2tp',      'ER_OAGD3te',
      'ER_OAGD3tg',      'ER_OAGT3te',      'ER_OCCOAtm',      'ER_OCCOAtx',
      'ER_OCTAt',      'ER_ODECOAtx',      'ER_OXAtp',      'ER_P450LTB4r',
      'ER_PAFS',      'ER_PAIL_HStn',      'ER_PAIL45P_HStn',      'ER_PAIL4P_HStn',
      'ER_PAN4PP',      'ER_PAPtg',      'ER_PCHOL_HSter',      'ER_PCHOL_HStg',
      'ER_PE_HSter',      'ER_PEt',      'ER_PGLYCt',      'ER_PHEMEtm',
      'ER_PHYTt',      'ER_PI45P4P',      'ER_PI4P5Kn',      'ER_PI4PP',
      'ER_PI5P4Kn',      'ER_PIK3n',      'ER_PIK4n',      'ER_PIK5n',
      'ER_PItg',      'ER_PItn',      'ER_PMTCOAtx',      'ER_PPAn',
      'ER_PPAt',      'ER_PPAtm',      'ER_PPItr',      'ER_PPItx',
      'ER_PPMI12346Ptn',      'ER_PPPG9tm',      'ER_PRGSTRNt',      'ER_PRISTANALtx',
      'ER_PRISTCOAtx',      'ER_PRISTtx',      'ER_PROSTGH2t',      'ER_PROSTGI2t',
      'ER_PROtm',      'ER_PSt3',      'ER_PTDCAt',      'ER_QUILSYN',
      'ER_RADH',      'ER_RADH2',      'ER_RAI1',      'ER_RAI2',
      'ER_RAtn',      'ER_RETHe',      'ER_RETI1',      'ER_RETI2',
      'ER_RETI3',      'ER_RETNGLCt2',      'ER_RETNGLCt2r',      'ER_RETNt',
      'ER_RETNtr2',      'ER_RIBt',      'ER_RIBt2',      'ER_RTOTAL2t',
      'ER_RTOTALt',      'ER_Rtotaltl',      'ER_S2L2FN2M2MASNtly',      'ER_S2L2N2M2MASNtly',
      'ER_S2TASE4ly',      'ER_S2TASE5ly',      'ER_S3TASE1ly',      'ER_S3TASE2ly',
      'ER_S3TASE3ly',      'ER_S4T4g',      'ER_S4T5g',      'ER_Ser_Thrtg',
      'ER_SERtp',      'ER_sink_citr[c]',      'ER_sink_pre_prot[r]',      'ER_SO4tl',
      'ER_SPC_HSt',      'ER_SPH1Pte',      'ER_SPHINGStl',      'ER_SPHMYLNtg',
      'ER_SPHMYLNtl',      'ER_SPHS1Pte',      'ER_SPMDOX',      'ER_STCOAtx',
      'ER_STRDNCt',      'ER_SUCCtp',      'ER_T4HCINNMFM',      'ER_TAGAT_Dt',
      'ER_TAXOLte',      'ER_TCHOLAte',      'ER_TDCHOLAte',      'ER_TETHEX3COAtx',
      'ER_TETHEX3t',      'ER_TETPENT3COAtx',      'ER_TETPENT3t',      'ER_TETPENT6COAtx',
      'ER_TETPENT6t',      'ER_TETTET6COAtx',      'ER_TETTET6t',      'ER_THCHOLSTOICtm',
      'ER_THFtl',      'ER_THFtm',      'ER_TMNDNCCOAtx',      'ER_TMNDNCt',
      'ER_TRIODTHYSUFt',      'ER_TRIOK',      'ER_TSTSTERONESte',      'ER_TSTSTERONEt',
      'ER_TSTSTERONEtr',      'ER_TXA2te',      'ER_TXA2tr',      'ER_UAGALDP',
      'ER_UDPACGALtl',      'ER_UDPGLCAtg',      'ER_UDPtl',      'ER_UDPXYLter',
      'ER_UMPtr',      'ER_URATEt',      'ER_UROLACer',      'ER_UTPtn',
      'ER_VACCt',      'ER_VALt5m',      'ER_VITD3t',      'ER_WHHDCAte',
      'ER_WHTSTSTERONEte',      'ER_XOL27OHtm',      'ER_XOL7AONEtr',      'ER_XOLEST2te',
      'ER_XOLESTte',      'ER_XOLTRI24te',      'ER_XOLTRI27tc',      'ER_XOLTRI27te',
      'ER_XSERtg',      'ER_XYLTD_Dr',      'ER_XYLtly',      'ER_XYLTt',
      'ER_EX_4abutn[e]',      'ER_EX_acmana[e]',      'ER_EX_ahdt[e]',      'ER_EX_ctp[e]',
      'ER_EX_dgmp[e]',      'ER_EX_dgtp[e]',      'ER_EX_dha[e]',      'ER_EX_dhap[e]',
      'ER_EX_dtmp[e]',      'ER_EX_dttp[e]',      'ER_EX_fald[e]',      'ER_EX_HC01104[e]',
      'ER_EX_HC01361[e]',      'ER_EX_HC01440[e]',      'ER_EX_HC01441[e]',      'ER_EX_HC01444[e]',
      'ER_EX_HC01446[e]',      'ER_EX_HC01577[e]',      'ER_EX_HC01700[e]',      'ER_EX_HC02160[e]',
      'ER_EX_HC02161[e]',      'ER_EX_itp[e]',      'ER_EX_orot[e]',      'ER_EX_prpp[e]',
      'ER_r0002',      'ER_r0156',      'ER_r0179',      'ER_r0236',
      'ER_r0330',      'ER_r0365',      'ER_r0480',      'ER_r0527',
      'ER_r0647',      'ER_r0784',      'ER_r0788',      'ER_r0789',
      'ER_r0809',      'ER_r0818',      'ER_r0838',      'ER_r0839',
      'ER_r0841',      'ER_r0853',      'ER_r0859',      'ER_r0886',
      'ER_r0892',      'ER_r0899',      'ER_r0926',      'ER_r0927',
      'ER_r0936',      'ER_r0937',      'ER_r0944',      'ER_r0950',
      'ER_r0962',      'ER_r0968',      'ER_r0970',      'ER_r0973',
      'ER_r0974',      'ER_r0986',      'ER_r0987',      'ER_r0989',
      'ER_r0990',      'ER_r0994',      'ER_r1000',      'ER_r1003',
      'ER_r1011',      'ER_r1012',      'ER_r1013',      'ER_r1014',
      'ER_r1018',      'ER_r1019',      'ER_r1030',      'ER_r1050',
      'ER_r1088',      'ER_r1106',      'ER_r1109',      'ER_r1116',
      'ER_r1117',      'ER_r1134',      'ER_r1146',      'ER_r1148',
      'ER_r1150',      'ER_r1159',      'ER_r1291',      'ER_r1292',
      'ER_r1298',      'ER_r1299',      'ER_r1301',      'ER_r1302',
      'ER_r1303',      'ER_r1304',      'ER_r1318',      'ER_r1364',
      'ER_r1365',      'ER_r1367',      'ER_r1368',      'ER_r1377',
      'ER_r1384',      'ER_r1400',      'ER_r1421',      'ER_r1423',
      'ER_r1435',      'ER_r1436',      'ER_r1437',      'ER_r1459',
      'ER_r1467',      'ER_r1468',      'ER_r1493',      'ER_r1512',
      'ER_r2508',      'ER_r2509',      'ER_r2510',      'ER_r2511',
      'ER_r2514',      'ER_r2519',      'ER_r2521',      'ER_r2537',
      'ER_r2538',      'ER_r2539',      'ER_EX_so3[e]',      'ER_EX_sprm[e]',
      'ER_RE0124C',      'ER_RE0452M',      'ER_RE0453C',      'ER_RE0570C',
      'ER_RE0571C',      'ER_RE0574C',      'ER_RE0575C',      'ER_RE0576C',
      'ER_RE0581C',      'ER_RE0583C',      'ER_RE0691C',      'ER_RE0830C',
      'ER_RE0908C',      'ER_RE0915C',      'ER_RE0916C',      'ER_RE0918C',
      'ER_RE0958C',      'ER_RE1234C',      'ER_RE1303C',      'ER_RE1342C',
      'ER_RE1447N',      'ER_RE1448N',      'ER_RE1530C',      'ER_RE1711C',
      'ER_RE1804C',      'ER_RE1807C',      'ER_RE1826C',      'ER_RE1836C',
      'ER_RE1897C',      'ER_RE1898C',      'ER_RE1915C',      'ER_RE1916C',
      'ER_RE1919C',      'ER_RE1921C',      'ER_RE1978C',      'ER_RE2069C',
      'ER_RE2080C',      'ER_RE2112C',      'ER_RE2235C',      'ER_RE2327C',
      'ER_RE2407C',      'ER_RE2410C',      'ER_RE2426C',      'ER_RE2526C',
      'ER_RE2562C',      'ER_RE2563C',      'ER_RE2625C',      'ER_RE2626C',
      'ER_RE2655R',      'ER_RE2659R',      'ER_RE2666C',      'ER_RE2677C',
      'ER_RE2677N',      'ER_RE2799C',      'ER_RE2814R',      'ER_RE2974N',
      'ER_RE3011R',      'ER_RE3016R',      'ER_RE3017R',      'ER_RE3033C',
      'ER_RE3044C',      'ER_RE3050R',      'ER_RE3052C',      'ER_RE3073X',
      'ER_RE3104C',      'ER_RE3106C',      'ER_RE3112C',      'ER_RE3113C',
      'ER_RE3119C',      'ER_RE3121C',      'ER_RE3122C',      'ER_RE3152C',
      'ER_RE3153C',      'ER_RE3154C',      'ER_RE3162C',      'ER_RE3163C',
      'ER_RE3164C',      'ER_RE3166C',      'ER_RE3167C',      'ER_RE3168C',
      'ER_RE3169C',      'ER_RE3171C',      'ER_RE3172C',      'ER_RE3173C',
      'ER_RE3175C',      'ER_RE3176C',      'ER_RE3180C',      'ER_RE3181C',
      'ER_RE3227C',      'ER_RE3228C',      'ER_RE3229C',      'ER_RE3230C',
      'ER_RE3231C',      'ER_RE3232C',      'ER_RE3234C',      'ER_RE3235C',
      'ER_RE3236C',      'ER_RE3237C',      'ER_RE3238C',      'ER_RE3239C',
      'ER_RE3242C',      'ER_RE3243C',      'ER_RE3244C',      'ER_RE3245C',
      'ER_RE3267E',      'ER_RE3270C',      'ER_RE3272N',      'ER_RE3286C',
      'ER_RE3288C',      'ER_RE3347C',      'ER_RE3352C',      'ER_RE3422C',
      'ER_RE3430M',      'ER_RE3430X',      'ER_RE3434C',      'ER_RE3435C',
      'ER_RE3436C',      'ER_RE3437C',      'ER_RE3475C',      'ER_RE3485C',
      'ER_RE3493C',      'ER_RE3496C',      'ER_RE3513C',      'ER_RE3513R',
      'ER_RE3525M',      'ER_RE3526M',      'ER_RE3556C',      'ER_RE3565C',
      'ER_RE3566C',      'ER_RE3567C',      'ER_RE3568C',      'ER_RE3570C',
      'ER_RE3587C',      'ER_RE3637C',      'ER_EX_prostgh2[e]',      'ER_EX_prostgi2[e]',
      'ER_EX_cdp[e]',      'ER_EX_dtdp[e]',      'ER_EX_HC00955[e]',      'ER_EX_citr_L[e]',
      'ER_EX_C02470[e]',      'ER_EX_C02528[e]',      'ER_EX_HC02195[e]',      'ER_EX_HC02196[e]',
      'ER_EX_HC02220[e]',      'ER_EX_HC02191[e]',      'ER_EX_HC02194[e]',      'ER_EX_HC02197[e]',
      'ER_EX_HC02198[e]',      'ER_EX_HC02187[e]',      'ER_EX_HC02180[e]',      'ER_EX_HC02202[e]',
      'ER_EX_HC02203[e]',      'ER_EX_HC02204[e]',      'ER_EX_HC02205[e]',      'ER_EX_HC02206[e]',
      'ER_EX_HC02207[e]',      'ER_EX_HC02213[e]',      'ER_EX_HC02217[e]',      'ER_EX_maltpt[e]',
      'ER_EX_CE2915[e]',      'ER_EX_CE4722[e]',      'ER_EX_CE2916[e]',      'ER_EX_CE4723[e]',
      'ER_EX_CE2917[e]',      'ER_EX_CE4724[e]',      'ER_EX_malthp[e]',      'ER_EX_CE2839[e]',
      'ER_EX_CE2838[e]',      'ER_EX_CE1950[e]',      'ER_EX_cynt[e]',      'ER_EX_CE5786[e]',
      'ER_EX_CE5788[e]',      'ER_EX_CE5789[e]',      'ER_EX_CE5797[e]',      'ER_EX_CE5798[e]',
      'ER_EX_CE5867[e]',      'ER_EX_CE5868[e]',      'ER_EX_CE5869[e]',      'ER_EX_CE4633[e]',
      'ER_EX_CE4881[e]',      'ER_EX_crm_hs[e]',      'ER_EX_CE0074[e]',      'ER_EX_cdpea[e]',
      'ER_EX_12dgr120[e]',      'ER_biomass_reaction',      'ER_ADPACDAc',      'ER_ADPACtx',
      'ER_BCRNe',      'ER_sink_c101coa[c]',      'ER_C101CRNe',      'ER_C10CRNe',
      'ER_C12DCACT',      'ER_C12DCe',      'ER_C16DCe',      'ER_C3DCe',
      'ER_C4CRNe',      'ER_C4DCe',      'ER_C6CRNe',      'ER_sink_c81coa[c]',
      'ER_C81CRNe',      'ER_C8CRNe',      'ER_C8DCe',      'ER_sink_dd2coa[c]',
      'ER_DDCRNe',      'ER_DDECCRNe',      'ER_DDECE1CRNe',      'ER_DECCRNe',
      'ER_sink_decdicoa[c]',      'ER_DECDICRNe',      'ER_DOCOSACTDe',      'ER_DOCOSACTDr',
      'ER_EX_3bcrn[e]',      'ER_EX_3ddcrn[e]',      'ER_EX_3deccrn[e]',      'ER_EX_3octdec2crn[e]',
      'ER_EX_3octdece1crn[e]',      'ER_EX_3tdcrn[e]',      'ER_EX_c101crn[e]',      'ER_EX_c10crn[e]',
      'ER_EX_c12dc[e]',      'ER_EX_c16dc[e]',      'ER_EX_c3dc[e]',      'ER_EX_c4crn[e]',
      'ER_EX_c4dc[e]',      'ER_EX_c51crn[e]',      'ER_EX_c6crn[e]',      'ER_EX_c81crn[e]',
      'ER_EX_c8crn[e]',      'ER_EX_c8dc[e]',      'ER_EX_ddece1crn[e]',      'ER_EX_ddecrn[e]',
      'ER_EX_decdicrn[e]',      'ER_EX_doco13ac[e]',      'ER_EX_docosac[e]',      'ER_EX_tetdec2crn[e]',
      'ER_EX_tetdece1crn[e]',      'ER_EX_dca[e]',      'ER_FAOXC5C5OHm',      'ER_HEXDIACtr',
      'ER_HOCTDEC2CRNe',      'ER_HTDCRNe',      'ER_OCTDECE1CRNe',      'ER_sink_octdececoa[c]',
      'ER_SEBACACT',      'ER_SEBACIDtx',      'ER_SUBEACtx',      'ER_SUBERICACT',
      'ER_SUCCACT',      'ER_TDCRNe',      'ER_sink_tetdec2coa[c]',      'ER_TETDEC2CRNe',
      'ER_sink_tetdece1coa[c]',      'ER_TETDECE1CRNe',      'ER_TIGCRNe',      'ER_BTNTe',
      'ER_SBTle',      'ER_1a25DHVITD3TRn',      'ER_3AIB_Dtm',      'ER_5MTHFt2le',
      'ER_ADNK4',      'ER_AHCYStd',      'ER_ALA-DTDe',      'ER_AMETtd',
      'ER_ARACHFATPc',      'ER_ASPDTDe',      'ER_ASPte',      'ER_CHSTEROLtrc',
      'ER_CRNrtx',      'ER_Coqe',      'ER_DATPtm',      'ER_DCTPtm',
      'ER_DGTPtm',      'ER_DHAPtc',      'ER_DM_1a25dhvitd3[n]',      'ER_DM_taur[c]',
      'ER_DM_pmtcoa[r]',      'ER_DTTPtm',      'ER_EX_4hpro[e]',      'ER_EX_carn[e]',
      'ER_EX_dchac[e]',      'ER_EX_sfcys[e]',      'ER_EX_cysam[e]',      'ER_EX_fmn[e]',
      'ER_EX_oh1[e]',      'ER_EX_ptth[e]',      'ER_EX_q10[e]',      'ER_EX_q10h2[e]',
      'ER_FOLt2le',      'ER_FRDPtcr',      'ER_GLU5SAtmc',      'ER_GLYC3PFADm',
      'ER_GLYCTDle',      'ER_INSK',      'ER_KHte',      'ER_LACLt',
      'ER_MAL_Ltx',      'ER_MDHx',      'ER_NADtm',      'ER_NADtx',
      'ER_PNTEHe',      'ER_PPItm',      'ER_PRO_Dtde',      'ER_PTCRTD',
      'ER_Q10H2e',      'ER_SFCYSc',      'ER_SFCYSe',      'ER_sink_5hpet[c]',
      'ER_TAURCHAe',      'ER_TTDCAFATPc',      'ER_q10h2tc',      'ER_q10tm',
      'ER_34HPPte',      'ER_3MOBte',      'ER_3MOPte',      'ER_4MOPte',
      'ER_5MTAte',      'ER_AHCYSte',      'ER_AICARte',      'ER_CBASPte',
      'ER_DM_4hrpo',      'ER_DM_Lcystin',      'ER_DM_fol',      'ER_DM_pnto_R',
      'ER_EX_34hpp[e]',      'ER_EX_3mob[e]',      'ER_EX_3mop[e]',      'ER_EX_4mop[e]',
      'ER_EX_5mta[e]',      'ER_EX_ahcys[e]',      'ER_EX_aicar[e]',      'ER_EX_cbasp[e]',
      'ER_MAL_Lte',      'ER_IDOURte',      'ER_EX_idour[e]',      'ER_GLYALDtr',
      'ER_PEPtr',      'ER_GUDACtr',      'ER_GUDACtr2',      'ER_KYNATEtr2',
      'ER_3ANTHRNtr',      'ER_2PGtr',      'ER_CARNtr',      'ER_CHOLPtr',
      'ER_DCMPtr',      'ER_DHAPtr',      'ER_ETHAMPtr',      'ER_FUMtr',
      'ER_GLCURtr',      'ER_ICITtr',      'ER_L2AADPtr',      'ER_XANtr',
      'ER_XMPtr',      'ER_XTSNtr',      'ER_3PGtr',      'ER_UDPGLCURtr',
      'ER_IMPtr',      'ER_GLYC3tr',      'ER_NICRNtr',      'ER_OROT5Ptr',
      'ER_EX_2pg[e]',      'ER_EX_5hoxindoa[e]',      'ER_EX_cholp[e]',      'ER_EX_dcmp[e]',
      'ER_EX_ethamp[e]',      'ER_EX_glyald[e]',      'ER_EX_gudac[e]',      'ER_EX_hcys_L[e]',
      'ER_EX_icit[e]',      'ER_EX_kynate[e]',      'ER_EX_L2aadp[e]',      'ER_EX_Lkynr[e]',
      'ER_EX_pep[e]',      'ER_EX_xmp[e]',      'ER_EX_xtsn[e]',      'ER_EX_3pg[e]',
      'ER_EX_3hanthrn[e]',      'ER_EX_udpglcur[e]',      'ER_EX_nicrnt[e]',      'ER_EX_orot5p[e]',
      'ER_EX_glyc3p[e]',      'ER_ARGSUCte',      'ER_EX_argsuc[e]',      'ER_EX_acrn[e]',
      'ER_EX_pcrn[e]',      'ER_EX_lneldccrn[e]',      'ER_EX_odecrn[e]',      'ER_EX_stcrn[e]',
      'ER_EX_pmtcrn[e]',      'ER_EX_hdcecrn[e]',      'ER_DM_ascb_L[c]',      'ER_biomass_maintenance_noTrTr',
      'ER_ADPOHc',      'ER_PHLAC',      'ER_3MHISc',      'ER_HMCRNc',
      'ER_CE4843HYDc',      'ER_HXCOAc',      'ER_HDCAc',      'ER_ELAIDCRNte',
      'ER_LNLCCRNNAt',      'ER_PHLACHt',      'ER_TTDCRNNAt',      'ER_15HPETATP',
      'ER_15KPROSTGF2t',      'ER_2OXOADPt',      'ER_34HPLte',      'ER_3HMPtd',
      'ER_3HPPt',      'ER_3MHISt1',      'ER_3MHISt2',      'ER_3MHISt3',
      'ER_3MOXTYRt',      'ER_3UIBtd',      'ER_4TMEABUTNt1',      'ER_4TMEABUTNt2',
      'ER_56DTHMt',      'ER_56DTHMtd',      'ER_56DURAt',      'ER_56DURAtd',
      'ER_5AOPt',      'ER_7DHCHSTEROLtd',      'ER_ACGLUtd',      'ER_ACLYSt',
      'ER_ACLYStm',      'ER_ADPACtd',      'ER_ADPOHt',      'ER_ALLTNt',
      'ER_C02712tm',      'ER_C03990tr',      'ER_C04483t2',      'ER_C04717td',
      'ER_C04805td',      'ER_C05463t2',      'ER_C05953t',      'ER_C05957t',
      'ER_C05957td',      'ER_C06314t',      'ER_C06315t',      'ER_C06439t',
      'ER_C11695td',      'ER_C14768td',      'ER_C14769td1',      'ER_EX_C14769[e]',
      'ER_C14770ATP',      'ER_C14771ATP',      'ER_C14825td',      'ER_C14826td',
      'ER_CE1273t2',      'ER_CE2510t',      'ER_CE2513td',      'ER_CE2537ATP',
      'ER_CE4843td',      'ER_CE5304t',      'ER_CE6247t',      'ER_DODECANACtd',
      'ER_ELAIDCRNtd',      'ER_EX_12HPET[e]',      'ER_EX_15HPET[e]',      'ER_EX_15kprostgf2[e]',
      'ER_EX_2oxoadp[e]',      'ER_EX_34hpl[e]',      'ER_EX_3hmp[e]',      'ER_EX_3hpp[e]',
      'ER_EX_3mhis[e]',      'ER_EX_3uib[e]',      'ER_EX_4tmeabutn[e]',      'ER_EX_56dthm[e]',
      'ER_EX_56dura[e]',      'ER_EX_7dhchsterol[e]',      'ER_EX_aclys[e]',      'ER_EX_adpac[e]',
      'ER_EX_adpoh[e]',      'ER_EX_amet[e]',      'ER_EX_aracheth[e]',      'ER_EX_C04717[e]',
      'ER_EX_C04805[e]',      'ER_EX_C05957[e]',      'ER_EX_C06314[e]',      'ER_EX_C06315[e]',
      'ER_EX_C11695[e]',      'ER_EX_C14768[e]',      'ER_EX_C14770[e]',      'ER_EX_C14771[e]',
      'ER_EX_C14825[e]',      'ER_EX_C14826[e]',      'ER_EX_CE2537[e]',      'ER_EX_CE4843[e]',
      'ER_EX_CE5304[e]',      'ER_EX_CE6247[e]',      'ER_EX_CE7172[e]',      'ER_EX_didecaeth[e]',
      'ER_EX_diholineth[e]',      'ER_EX_docohxeth[e]',      'ER_EX_docteteth[e]',      'ER_EX_dodecanac[e]',
      'ER_EX_elaidcrn[e]',      'ER_EX_forglu[e]',      'ER_EX_HC00900[e]',      'ER_EX_hepdeceth[e]',
      'ER_EX_hexdeceeth[e]',      'ER_EX_hexdiac[e]',      'ER_EX_hgentis[e]',      'ER_EX_hmcr[e]',
      'ER_EX_hxcoa[e]',      'ER_EX_leuktrB4wcooh[e]',      'ER_EX_leuktrB4woh[e]',      'ER_EX_lineth[e]',
      'ER_EX_lnlccrn[e]',      'ER_EX_lthstrl[e]',      'ER_EX_mev_R[e]',      'ER_EX_mi1p_D[e]',
      'ER_EX_nwharg[e]',      'ER_EX_oleth[e]',      'ER_EX_pailar_hs[e]',      'ER_EX_pailpalm_hs[e]',
      'ER_EX_pchol2linl_hs[e]',      'ER_EX_pchol2ole_hs[e]',      'ER_EX_pchol2palm_hs[e]',      'ER_EX_pchol2ste_hs[e]',
      'ER_EX_pcholar_hs[e]',      'ER_EX_pcholdoc_hs[e]',      'ER_EX_pcholeic_hs[e]',      'ER_EX_pcholet_hs[e]',
      'ER_EX_pcholhep_hs[e]',      'ER_EX_pchollinl_hs[e]',      'ER_EX_pcholmyr_hs[e]',      'ER_EX_pcholn15_hs[e]',
      'ER_EX_pcholn183_hs[e]',      'ER_EX_pcholn1836_hs[e]',      'ER_EX_pcholn19_hs[e]',      'ER_EX_pcholn201_hs[e]',
      'ER_EX_pcholn203_hs[e]',      'ER_EX_pcholn204_hs[e]',      'ER_EX_pcholn205_hs[e]',      'ER_EX_pcholn224_hs[e]',
      'ER_EX_pcholn225_hs[e]',      'ER_EX_pcholn2254_hs[e]',      'ER_EX_pcholn226_hs[e]',      'ER_EX_pcholn24_hs[e]',
      'ER_EX_pcholn261_hs[e]',      'ER_EX_pcholn28_hs[e]',      'ER_EX_pcholn281_hs[e]',      'ER_EX_pcholole_hs[e]',
      'ER_EX_pcholpalm_hs[e]',      'ER_EX_pcholpalme_hs[e]',      'ER_EX_pcholste_hs[e]',      'ER_EX_pcollg5hlys[e]',
      'ER_EX_pe12_hs[e]',      'ER_EX_pe13_hs[e]',      'ER_EX_pe14_hs[e]',      'ER_EX_pe15_hs[e]',
      'ER_EX_pe161_hs[e]',      'ER_EX_pe17_hs[e]',      'ER_EX_pe203_hs[e]',      'ER_EX_pe224_hs[e]',
      'ER_EX_pe226_hs[e]',      'ER_EX_pe2linl_hs[e]',      'ER_EX_pear_hs[e]',      'ER_EX_pedh203_hs[e]',
      'ER_EX_pelinl_hs[e]',      'ER_EX_pendecaeth[e]',      'ER_EX_peole_hs[e]',      'ER_EX_pepalm_hs[e]',
      'ER_EX_peste_hs[e]',      'ER_EX_pmeth[e]',      'ER_EX_saccrp_L[e]',      'ER_EX_sebacid[e]',
      'ER_EX_sphmyln180241_hs[e]',      'ER_EX_sphmyln18114_hs[e]',      'ER_EX_sphmyln18115_hs[e]',      'ER_EX_sphmyln18116_hs[e]',
      'ER_EX_sphmyln181161_hs[e]',      'ER_EX_sphmyln18117_hs[e]',      'ER_EX_sphmyln18118_hs[e]',      'ER_EX_sphmyln181181_hs[e]',
      'ER_EX_sphmyln18120_hs[e]',      'ER_EX_sphmyln181201_hs[e]',      'ER_EX_sphmyln18121_hs[e]',      'ER_EX_sphmyln18122_hs[e]',
      'ER_EX_sphmyln181221_hs[e]',      'ER_EX_sphmyln18123_hs[e]',      'ER_EX_sphmyln1824_hs[e]',      'ER_EX_sphmyln1825_hs[e]',
      'ER_EX_steeth[e]',      'ER_EX_subeac[e]',      'ER_EX_tetdecaeth[e]',      'ER_EX_tmlys[e]',
      'ER_EX_trideceth[e]',      'ER_EX_ttdcrn[e]',      'ER_EX_urcan[e]',      'ER_EX_wharachd[e]',
      'ER_FORGLUt',      'ER_GALTt',      'ER_LYSACm',      'ER_GLYC_Rt',
      'ER_GLYCLTtd',      'ER_HC00900t1',      'ER_HC00900t2',      'ER_HC00900t3',
      'ER_HC00900t4',      'ER_HC02149td',      'ER_HEXDIACtd',      'ER_HGENTISt',
      'ER_HMCRNt',      'ER_HXCOAm',      'ER_HXCOAte',      'ER_HXCOAtx',
      'ER_HXCOAx',      'ER_IND3ACt',      'ER_LCYSTt',      'ER_LEUKTRB4WCOOHt',
      'ER_LEUKTRB4WOHt',      'ER_LEUKTRB4WOHtr',      'ER_LNLCCRNtd',      'ER_LTHSTRLt',
      'ER_MEV_Rt',      'ER_MI1Pt',      'ER_NWHARGtd',      'ER_OAAt',
      'ER_pac',      'ER_PCOLLG5HLYStd',      'ER_PROSTGI2c',      'ER_PSERtr',
      'ER_SACCRP_Lte',      'ER_SACCRP_Ltm',      'ER_SEBACIDtd',      'ER_SUBEACtd',
      'ER_TMLYStd',      'ER_TXB2c',      'ER_URCANt',      'ER_WHARACHDtr',
      'ER_EX_estriol[e]',      'ER_DDCAFATP',      'ER_EX_3moxtyr[e]',      'ER_EX_5aop[e]',
      'ER_EX_acglu[e]',      'ER_EX_alltn[e]',      'ER_EX_CE2510[e]',      'ER_EX_ddca[e]',
      'ER_EX_glyc_R[e]',      'ER_EX_glyclt[e]',      'ER_EX_Lcyst[e]',      'ER_EX_oaa[e]',
      'ER_EX_pac[e]',      'ER_EX_phlac[e]',      'ER_EX_pser_L[e]',      'ER_EX_ttdcea[e]',
      'ER_TTDCEAt',      'ER_DCHOLESTANCOAc',      'ER_XOL27OHtmc',      'ER_r0202m',
      'ER_PHEACGLYsec',      'ER_EX_pheacgly[e]',      'ER_EX_bz[e]',      'ER_NORMETEt',
      'ER_MEPIt',      'ER_TREt',      'ER_C05300t',      'ER_RETINALt',
      'ER_MALTTTRt',      'ER_1MNCAMt',      'ER_DHBPTt',      'ER_THBPTt',
      'ER_EX_normete_L[e]',      'ER_EX_mepi[e]',      'ER_EX_C05300[e]',      'ER_EX_retinal[e]',
      'ER_EX_maltttr[e]',      'ER_EX_1mncam[e]',      'ER_EX_dhbpt[e]',      'ER_EX_thbpt[e]',
      'ER_EX_adprib[e]',      'ER_EX_homoval[e]',      'ER_GLYCLTtm',      'ER_TYMc',
      'ER_PCHOL2PALM_HSte',      'ER_PE224_HSte',      'ER_PCHOLN261_HSte',      'ER_PCHOLN281_HSte',
      'ER_PCHOLN28_HSte',      'ER_ACRNtr',      'ER_HDCECRNtr',      'ER_LNELDCCRNtr',
      'ER_ODECRNtr',      'ER_PMTCRNtr',      'ER_STCRNtr',      'ER_EX_sphmyln_hs[e]',
      'ER_PHEACGLYtm',      'ER_HXAt1',      'ER_HXAt2',      'ER_HXAt3',
      'ER_EX_hxa[e]',      'ER_PACCOALm',      'ER_PACALDtm',      'ER_LHCYSTIN',
      'ER_LHCYSTINt',      'ER_EX_Lhcystin[e]',      'ER_PA_HStm',      'ER_FldAct',
      'ER_MALOAtm',      'ER_MLTHFtm',      'ER_2MOPtm',      'ER_MMALtm',
      'ER_PGPP_hsc',      'ER_CE2512te',      'ER_r2514e',      'ER_r2514m',
      'ER_FAS180',      'ER_5AOPt2',      'ER_ACNAMt2',      'ER_ADRNLtu',
      'ER_DM_pe_hs[c]',      'ER_DM_akg[c]',      'ER_DM_for[c]',      'ER_DM_mi1345p[c]',
      'ER_DM_mi134p[c]',      'ER_DM_mi145p[c]',      'ER_DM_mi14p[c]',      'ER_DM_pchol_hs[c]',
      'ER_ETHAt',      'ER_HCYSte',      'ER_OROte',      'ER_PPPGOc',
      'ER_SPRMt2r',      'ER_THMtrbc',      'ER_UGT1A10c',      'ER_UNK3r',
      'ER_ACGALtr',      'ER_ACNAMtr',      'ER_CORE4t',      'ER_S2L2N2M2Mt',
      'ER_EX_core4[e]',      'ER_EX_f1a[e]',      'ER_EX_s2l2n2m2m[e]',      'ER_EX_acgal[e]',
      'ER_EX_acnam[e]',      'ER_EX_pa_hs[e]',      'ER_DM_C02712[c]',      'ER_F1Ate',
      'ER_34HPLtm',      'ER_3HMPtm',      'ER_3HPPtm',      'ER_ACGLUtm',
      'ER_PGP_hs_tm',      'ER_PROSTGE2t2r',      'ER_ESTR2r',      'ER_LTHSTRLtr',
      'ER_PGLYCtm',      'ER_sink_25hvitd2[c]',      'ER_sink_C02528[c]',      'ER_sink_HC02191[c]',
      'ER_sink_HC02194[c]',      'ER_sink_HC02195[c]',      'ER_sink_HC02196[c]',      'ER_sink_HC02197[c]',
      'ER_sink_HC02198[c]',      'ER_sink_HC02220[c]',      'ER_sink_Tyr_ggn[c]',      'ER_sink_avite1[c]',
      'ER_sink_btn[c]',      'ER_sink_c226coa[c]',      'ER_sink_chol[c]',      'ER_sink_cholate[c]',
      'ER_sink_coa[c]',      'ER_sink_crvnc[c]',      'ER_sink_dgchol[c]',      'ER_sink_doco13ecoa[c]',
      'ER_sink_fad[c]',      'ER_sink_fe3[c]',      'ER_sink_gchola[c]',      'ER_sink_glygn2[c]',
      'ER_sink_hdca[c]',      'ER_sink_lnlc[c]',      'ER_sink_lnlccoa[c]',      'ER_sink_lnlncacoa[c]',
      'ER_sink_lnlncgcoa[c]',      'ER_sink_nad[c]',      'ER_sink_nadp[c]',      'ER_sink_odecoa[c]',
      'ER_sink_pmtcoa[c]',      'ER_sink_pydam[c]',      'ER_sink_pydx[c]',      'ER_sink_pydxn[c]',
      'ER_sink_retfa[c]',      'ER_sink_retinol[c]',      'ER_sink_stcoa[c]',      'ER_sink_tag_hs[c]',
      'ER_sink_tchola[c]',      'ER_sink_tdchola[c]',      'ER_sink_thf[c]',      'ER_sink_thmpp[c]',
      'ER_sink_thmtp[c]',      'ER_sink_tmndnc[c]',      'ER_sink_tmndnccoa[c]',      'ER_sink_vitd3[c]',
      'ER_DXTRNt',      'ER_EX_dxtrn[e]',      'ER_EX_dhcholestanate[e]',      'ER_sink_dhcholestanate[c]',
      'ER_EX_thcholstoic[e]',      'ER_sink_thcholstoic[c]',      'ER_EX_xol7ah3[e]',      'ER_sink_xol7ah3[c]',
      'ER_EX_xol7aone[e]',      'ER_sink_xol7aone[c]',      'ER_EX_xoldiolone[e]',      'ER_sink_xoldiolone[c]',
      'ER_EX_7klitchol[e]',      'ER_sink_7klitchol[c]',      'ER_sink_dchac[c]',      'ER_EX_2obut[e]',
      'ER_EX_glcn[e]',      'ER_CO2t',      'ER_DM_atp_c_',      'ER_EX_acac[e]',
      'ER_EX_adn[e]',      'ER_EX_akg[e]',      'ER_EX_asn_L[e]',      'ER_EX_asp_L[e]',
      'ER_EX_but[e]',      'ER_EX_cgly[e]',      'ER_EX_co2[e]',      'ER_EX_cytd[e]',
      'ER_EX_dad_2[e]',      'ER_EX_dcyt[e]',      'ER_EX_dgsn[e]',      'ER_EX_din[e]',
      'ER_EX_duri[e]',      'ER_EX_fe2[e]',      'ER_EX_fe3[e]',      'ER_EX_fum[e]',
      'ER_EX_gal[e]',      'ER_EX_glu_L[e]',      'ER_EX_h[e]',      'ER_EX_h2o[e]',
      'ER_EX_ile_L[e]',      'ER_EX_ins[e]',      'ER_EX_k[e]',      'ER_EX_lac_L[e]',
      'ER_EX_leu_L[e]',      'ER_EX_lys_L[e]',      'ER_EX_mal_L[e]',      'ER_EX_met_L[e]',
      'ER_EX_na1[e]',      'ER_EX_no2[e]',      'ER_EX_o2[e]',      'ER_EX_orn[e]',
      'ER_EX_pi[e]',      'ER_EX_ppi[e]',      'ER_EX_pro_L[e]',      'ER_EX_ribflv[e]',
      'ER_EX_ser_L[e]',      'ER_EX_so4[e]',      'ER_EX_succ[e]',      'ER_EX_thymd[e]',
      'ER_EX_urea[e]',      'ER_EX_uri[e]',      'ER_EX_val_L[e]',      'ER_FCLTc',
      'ER_FT',      'ER_G5SADs',      'ER_O2t',      'ER_PIt6b',
      'ER_URIDK3',      'ER_EX_pnto_R[e]',      'ER_EX_gly[e]',      'ER_EX_cys_L[e]',
      'ER_EX_ala_L[e]',      'ER_EX_his_L[e]',      'ER_EX_thr_L[e]',      'ER_EX_gln_L[e]',
      'ER_EX_phe_L[e]',      'ER_EX_tyr_L[e]',      'ER_EX_arg_L[e]',      'ER_EX_for[e]',
      'ER_EX_nac[e]',      'ER_EX_ind3ac[e]',      'ER_EX_nh4[e]',      'ER_EX_ac[e]',
      'ER_CSND',      'ER_EX_acgam[e]',      'ER_EX_cit[e]',      'ER_EX_csn[e]',
      'ER_EX_drib[e]',      'ER_EX_etha[e]',      'ER_EX_fol[e]',      'ER_EX_fru[e]',
      'ER_EX_galt[e]',      'ER_EX_glcr[e]',      'ER_EX_glcur[e]',      'ER_EX_glyc[e]',
      'ER_EX_hxan[e]',      'ER_EX_malt[e]',      'ER_EX_malthx[e]',      'ER_EX_malttr[e]',
      'ER_EX_man[e]',      'ER_EX_ptrc[e]',      'ER_EX_rib_D[e]',      'ER_EX_spmd[e]',
      'ER_EX_thm[e]',      'ER_EX_trp_L[e]',      'ER_EX_ura[e]',      'ER_EX_xan[e]',
      'ER_EX_xyl_D[e]',      'ER_NTD5_a',      'ER_OAADC',      'ER_EX_pydxn[e]',
      'ER_PYDXNtr',      'ER_EX_pydx[e]',      'ER_PYDXtr',      'ER_EX_pydam[e]',
      'ER_PYDAMtr',      'ER_EX_4hbz[e]',      'ER_EX_ppa[e]',      'ER_EX_arab_L[e]',
      'ER_EX_gam[e]',      'ER_EX_pyr[e]',      'ER_EX_tre[e]',      'ER_EX_btn[e]',
      'ER_EX_lcts[e]',      'ER_EX_ade[e]',      'ER_EX_etoh[e]',      'ER_ETOHt',
      'ER_EX_acald[e]',      'ER_ACALDt',      'ER_EX_sucr[e]',      'ER_EX_pheme[e]',
      'ER_MTRI',      'ER_EX_gua[e]',      'ER_EX_4abut[e]',      'ER_OBDHc',
      'ER_EX_phpyr[e]',      'ER_EX_lanost[e]',      'ER_3MOX4HOXMte',      'ER_EX_3mox4hoxm[e]',
      'ER_2H3MVte',      'ER_EX_2h3mv[e]',      'ER_2HIVte',      'ER_EX_2hiv[e]',
      'ER_2M3HBUc',      'ER_2M3HBUtm',      'ER_2M3HBUte',      'ER_EX_2m3hbu[e]',
      'ER_3H3MGLTc',      'ER_3H3MGLTte',      'ER_EX_3h3mglt[e]',      'ER_3MGLUTACc',
      'ER_3MGLUTACtm',      'ER_3MGLUTACte',      'ER_EX_3mglutac[e]',      'ER_PPIOGLYtm',
      'ER_PPIOGLYte',      'ER_EX_ppiogly[e]',      'ER_TIGGLYtm',      'ER_TIGGLYte',
      'ER_EX_tiggly[e]',      'ER_GLUTACOAm',      'ER_GLUTCONm',      'ER_GLUTCONtm',
      'ER_GLUTCONte',      'ER_EX_glutcon[e]',      'ER_3HIVAcm',      'ER_3HIVActm',
      'ER_3HIVActe',      'ER_EX_3hivac[e]',      'ER_3HADPACx',      'ER_3HADPACtxc',
      'ER_3HADPACte',      'ER_EX_3hadpac[e]',      'ER_3OHSEBACx',      'ER_3OHSEBACtxc',
      'ER_3OHSEBACte',      'ER_EX_3ohsebac[e]',      'ER_3OHSUBACx',      'ER_3OHSUBACtxc',
      'ER_3OHSUBACte',      'ER_EX_3ohsubac[e]',      'ER_CAPROICc',      'ER_5OHHEXAc',
      'ER_5OHHEXAte',      'ER_EX_5ohhexa[e]',      'ER_ETHMALCOAc',      'ER_ETHMALACc',
      'ER_ETHMALACte',      'ER_EX_ethmalac[e]',      'ER_HEXGLYte',      'ER_EX_hexgly[e]',
      'ER_SUBGLYte',      'ER_EX_subgly[e]',      'ER_4OHBUTm',      'ER_4OHBUTtmc',
      'ER_4OHBUTtce',      'ER_EX_4ohbut[e]',      'ER_12HPETUPKt',      'ER_15HPETUPKt',
      'ER_3AIBSYMPt',      'ER_CE7172UPKt',      'ER_PAIL_hs_SECt',      'ER_PAILPALM_HSSECt',
      'ER_PAILR_HSSECt',      'ER_SPHMYLN_HsSECt',      'ER_SPHMYLN180241_hs_SECt',      'ER_SPHMYLN18114_hs_SECt',
      'ER_SPHMYLN18115_hs_SECt',      'ER_SPHMYLN18116_hs_SECt',      'ER_SPHMYLN181161_hs_SECt',      'ER_SPHMYLN18117_hs_SECt',
      'ER_SPHMYLN18118_hs_SECt',      'ER_SPHMYLN181181_hs_SECt',      'ER_SPHMYLN18120_hs_SECt',      'ER_SPHMYLN181201_hs_SECt',
      'ER_SPHMYLN18121_hs_SECt',      'ER_SPHMYLN18122_hs_SECt',      'ER_SPHMYLN181221_hs_SECt',      'ER_SPHMYLN18123_hs_SECt',
      'ER_SPHMYLN1824_hs_SECt',      'ER_SPHMYLN1825_hs_SECt',      'ER_3AIBt1',      'ER_AK2LGCHOLt1',
      'ER_PAFt1',      'ER_PCHOL2LINL_HSt1e',      'ER_PCHOL2OLE_HSt1e',      'ER_PCHOL2STE_HSt1e',
      'ER_PCHOLAR_HSt1e',      'ER_PCHOLDOC_HSt1e',      'ER_PCHOLEIC_HSt1e',      'ER_PCHOLET_HSt1e',
      'ER_PCHOLHEP_HSt1e',      'ER_PCHOLLINL_HSt1e',      'ER_PCHOLMYR_Hst1e',      'ER_PCHOLN15_HSt1e',
      'ER_PCHOLN183_HSt1e',      'ER_PCHOLN1836_HSt1e',      'ER_PCHOLN19_HSt1e',      'ER_PCHOLN201_HSt1e',
      'ER_PCHOLN203_HSt1e',      'ER_PCHOLN204_HSt1e',      'ER_PCHOLN205_HSt1e',      'ER_PCHOLN224_HSt1e',
      'ER_PCHOLN225_HSt1e',      'ER_PCHOLN2254_HSt1e',      'ER_PCHLN225_HSt1e',      'ER_PCHOLN264_HSt1e',
      'ER_PCHOLOLE_HSt1e',      'ER_PEPALM_HSt1e',      'ER_PCHOLPALME-HSt1e',      'ER_PCHOLSTE_HSt1e',
      'ER_PE12_HSt1e',      'ER_Pe13_HSt1e',      'ER_PE14_HSt1e',      'ER_PE15_HSt1e',
      'ER_PE161_HSt1e',      'ER_PE17_HSt1e',      'ER_PE203_HSt1e',      'ER_PE226_HSt1e',
      'ER_PE2LINL_HSt1e',      'ER_PEAR_HSt1e',      'ER_PEDH203_HSt1e',      'ER_PELINL_HSt1e',
      'ER_PEOLE_HSt1e',      'ER_PELPALM_HSt1e',      'ER_PESTE_HSt1e',      'ER_EIC21114TRte',
      'ER_EX_eic21114tr[e]',      'ER_5EIPENCte',      'ER_EX_5eipenc[e]',      'ER_ISOBUTtm',
      'ER_ISOBUTte',      'ER_EX_CE4969[e]',      'ER_NACCYStm',      'ER_NACCYSte',
      'ER_EX_CE1310[e]',      'ER_AGRMtm',      'ER_EX_agm[e]',      'ER_T4HCINNMtm',
      'ER_EX_T4hcinnm[e]',      'ER_4HBZte',      'ER_SUCSALtm',      'ER_SUCSALte',
      'ER_EX_sucsal[e]',      'ER_CE7081tr',      'ER_CE7081tm',      'ER_EX_CE7081[e]',
      'ER_EGMEtr',      'ER_EGMEte',      'ER_EX_egme[e]',      'ER_SQLtr',
      'ER_SQLte',      'ER_EX_sql[e]',      'ER_ORN_Dte',      'ER_EX_orn_D[e]',
      'ER_5G2OXPTtx',      'ER_5G2OXPTte',      'ER_EX_5g2oxpt[e]',      'ER_DHEAte',
      'ER_EX_dhea[e]',      'ER_ANDRSTANDRtr',      'ER_EX_andrstandn[e]',      'ER_ESTRONEte',
      'ER_EX_estrone[e]',      'ER_HC02020tr',      'ER_HC02020te',      'ER_EX_HC02020[e]',
      'ER_XOL27OHte',      'ER_EX_xol27oh[e]',      'ER_XOL25OHtr',      'ER_XOL25OHte',
      'ER_EX_xol25oh[e]',      'ER_DSMSTEROLtr',      'ER_DSMSTEROLte',      'ER_EX_dsmsterol[e]',
      'ER_CHSTEROLSte',      'ER_EX_chsterols[e]',      'ER_3ITYR_Lte',      'ER_EX_3ityr_L[e]',
      'ER_35DIODTYRte',      'ER_EX_35diotyr[e]',      'ER_13_CIS_RETNte',      'ER_EX_13_cis_retn[e]',
      'ER_LDL_HSDEG',      'ER_EX_34dhoxmand[e]',      'ER_EX_CE7090[e]',      'ER_EX_CE7085[e]',
      'ER_EX_CE7096[e]',      'ER_EX_CE4877[e]',      'ER_EX_CE1447[e]',      'ER_EX_CE6205[e]',
      'ER_EX_trypta[e]',      'ER_C05767te',      'ER_EX_C05767[e]',      'ER_C05770te3',
      'ER_EX_C05770[e]',      'ER_EX_mhista[e]',      'ER_PPBNGte',      'ER_EX_ppbng[e]',
      'ER_EX_mma[e]',      'ER_12PPDRte',      'ER_EX_12ppd_R[e]',      'ER_AMETAMte',
      'ER_EX_ametam[e]',      'ER_XYLULte',      'ER_EX_xylu_L[e]',      'ER_XYLUDte',
      'ER_EX_xylu_D[e]',      'ER_GLCNte',      'ER_SPHGNSte',      'ER_EX_sphings[e]',
      'ER_HDD2CRNte',      'ER_EX_hdd2crn[e]',      'ER_IM4ACte',      'ER_EX_im4ac[e]',
      'ER_EX_CE1918[e]',      'ER_EX_mlthf[e]',      'ER_EX_CE2705[e]',      'ER_SPHGNte',
      'ER_EX_sphgn[e]',      'ER_EX_N1aspmd[e]',      'ER_C13856te',      'ER_EX_1a25dhvitd3[e]',
      'ER_PRISTte',      'ER_EX_prist[e]',      'ER_CE2049te',      'ER_EX_CE2049[e]',
      'ER_CE2047te',      'ER_EX_CE2047[e]',      'ER_LANOSTte',      'ER_FDPte',
      'ER_EX_fdp[e]',      'ER_EX_coke[e]',      'ER_COKEte',      'ER_COKEtr',
      'ER_EX_5a2opntn[e]',      'ER_5A2OPNTNte',      'ER_5A2OPNTNtx',      'ER_ARG_Dtx',
      'ER_ARG_Dte',      'ER_EX_arg_D[e]',      'ER_LANOSTtr',      'ER_EX_ldl_hs[e]',
      'ER_EX_HC00005[e]',      'ER_CE1261t',      'ER_DOPAOQNOX',      'ER_DOPAOQCYS',
      'ER_DACT',      'ER_CE5629t',      'ER_EX_CE5629[e]',      'ER_CRMte',
      'ER_EX_gd3_hs[e]',      'ER_EX_gluside_hs[e]',      'ER_GALGLUSIDEtg2',      'ER_GD3tg',
      'ER_GD3tl',      'ER_GLUSIDEte',      'ER_GLUSIDEtg',      'ER_GLUSIDEtl',
      'ER_GM1tg',      'ER_GM1tl',      'ER_SPHMYLNtl2',      'ER_RE3477C1',
      'ER_NH4tr',      'ER_UDPGALt2n',      'ER_THCRMtl',      'ER_DAG_HStg',
      'ER_SPHGNtn',      'ER_SPHGNtg',      'ER_SPHINGStn',      'ER_SPHINGStg',
      'ER_DHCRMtg',      'ER_GDA1tn',      'ER_sink_34dhpac[c]',      'ER_34DHPEt',
      'ER_EX_34dhpe[e]',      'ER_DM_sph1p[n]',      'ER_DM_sphs1p[n]',      'ER_DM_gm1_hs[n]',
      'ER_DM_gda1_hs[n]',      'ER_DM_6hddopaqn[c]',      'ER_GALSIDEtn',      'ER_CERT1tn',
      'ER_Rtotaltg',      'ER_GD1Atg',      'ER_GD1Atn',      'ER_ATPtg',
      'ER_GD3tlc',      'ER_GD3tm',      'ER_DM_pail35p_hs[n]',      'ER_DM_gd3_hs[m]',
      'ER_CATr',      'ER_S2L2N2M2Mtl',      'ER_DM_k[g]',      'ER_DM_na1[g]',
      'ER_DM_retn[n]',      'ER_DM_15HPET[n]',      'ER_DM_15HPET[x]',      'ER_DM_15HPET[r]',
      'ER_sink_Ser_Gly_Ala_X_Gly[r]',      'ER_EX_pail_hs[e]',      'ER_EX_CE5026[e]',      'ER_EX_CE1261[e]',
      'ER_EX_galgluside_hs[e]',      'ER_EX_gm1_hs[e]',      'ER_HMR_0015',      'ER_HMR_0020',
      'ER_HMR_0157',      'ER_HMR_0166',      'ER_HMR_0172',      'ER_HMR_0178',
      'ER_HMR_0182',      'ER_HMR_0185',      'ER_HMR_0763',      'ER_HMR_0769',
      'ER_HMR_0771',      'ER_HMR_0809',      'ER_HMR_0831',      'ER_HMR_0912',
      'ER_HMR_0913',      'ER_HMR_0962',      'ER_HMR_0984',      'ER_HMR_1095',
      'ER_HMR_1104',      'ER_HMR_1135',      'ER_HMR_1242',      'ER_HMR_1243',
      'ER_HMR_1283',      'ER_HMR_1284',      'ER_HMR_1306',      'ER_HMR_1311',
      'ER_HMR_1315',      'ER_HMR_1316',      'ER_HMR_1317',      'ER_HMR_1332',
      'ER_HMR_1623',      'ER_HMR_1701',      'ER_HMR_1744',      'ER_HMR_1745',
      'ER_HMR_1752',      'ER_HMR_1753',      'ER_HMR_1758',      'ER_HMR_1759',
      'ER_HMR_1834',      'ER_HMR_2087',      'ER_HMR_2090',      'ER_HMR_2127',
      'ER_HMR_2374',      'ER_HMR_2376',      'ER_HMR_2391',      'ER_HMR_2393',
      'ER_HMR_2495',      'ER_HMR_2569',      'ER_HMR_2571',      'ER_HMR_3053',
      'ER_HMR_3056',      'ER_HMR_3106',      'ER_HMR_3396',      'ER_HMR_3397',
      'ER_HMR_3478',      'ER_HMR_3520',      'ER_HMR_3597',      'ER_HMR_3951',
      'ER_HMR_3953',      'ER_HMR_3996',      'ER_HMR_4078',      'ER_HMR_4266',
      'ER_HMR_4664',      'ER_HMR_4672',      'ER_HMR_4782',      'ER_HMR_4783',
      'ER_HMR_4831',      'ER_HMR_4957',      'ER_HMR_5101',      'ER_HMR_5409',
      'ER_HMR_6500',      'ER_HMR_6611',      'ER_HMR_6629',      'ER_HMR_6784',
      'ER_HMR_6785',      'ER_HMR_6786',      'ER_HMR_7198',      'ER_HMR_7330',
      'ER_HMR_7712',      'ER_HMR_7715',      'ER_HMR_7898',      'ER_HMR_7900',
      'ER_HMR_7944',      'ER_HMR_7977',      'ER_HMR_8023',      'ER_HMR_8084',
      'ER_HMR_8086',      'ER_HMR_8090',      'ER_HMR_8374',      'ER_HMR_8418',
      'ER_HMR_8505',      'ER_HMR_8562',      'ER_HMR_8567',      'ER_HMR_8776',
      'ER_HMR_9019',      'ER_HMR_9174',      'ER_HMR_9175',      'ER_HMR_9176',
      'ER_HMR_9179',      'ER_HMR_9180',      'ER_HMR_9184',      'ER_HMR_9185',
      'ER_HMR_9188',      'ER_HMR_9189',      'ER_HMR_9612',      'ER_HMR_9625',
      'ER_HMR_9626',      'ER_HMR_9627',      'ER_HMR_9628',      'ER_HMR_9634',
      'ER_HMR_9638',      'ER_HMR_9639',      'ER_HMR_9640',      'ER_HMR_9647',
      'ER_HMR_9648',      'ER_HMR_9652',      'ER_HMR_9665',      'ER_HMR_9667',
      'ER_HMR_9676',      'ER_HMR_9678',      'ER_HMR_9679',      'ER_HMR_9680',
      'ER_HMR_9718',      'ER_HMR_9720',      'ER_HMR_9797',      'ER_HMR_6672',
      'ER_EX_nadh[e]',      'ER_EX_glc_D[e]',      'ER_EX_sbt_D[e]',      'ER_CDCA24Gtr',
      'ER_CDCA3Gtr',      'ER_DM_12dhchol[c]',      'ER_DM_3dhcdchol[c]',      'ER_DM_3dhchol[c]',
      'ER_DM_3dhdchol[c]',      'ER_DM_3dhlchol[c]',      'ER_DM_7dhcdchol[c]',      'ER_DM_7dhchol[c]',
      'ER_DM_cdca24g[c]',      'ER_DM_cdca3g[c]',      'ER_DM_coprost[c]',      'ER_DM_hca24g[c]',
      'ER_DM_hdca24g[c]',      'ER_DM_hdca6g[c]',      'ER_DM_hyochol[c]',      'ER_DM_icdchol[c]',
      'ER_DM_isochol[c]',      'ER_DM_lca24g[c]',      'ER_DM_lca3g[c]',      'ER_DM_thyochol[c]',
      'ER_DM_uchol[c]',      'ER_EX_12dhchol[e]',      'ER_EX_3dhcdchol[e]',      'ER_EX_3dhchol[e]',
      'ER_EX_3dhdchol[e]',      'ER_EX_3dhlchol[e]',      'ER_EX_7dhcdchol[e]',      'ER_EX_7dhchol[e]',
      'ER_EX_cdca24g[e]',      'ER_EX_cdca3g[e]',      'ER_EX_coprost[e]',      'ER_EX_hca24g[e]',
      'ER_EX_hdca24g[e]',      'ER_EX_hdca6g[e]',      'ER_EX_hyochol[e]',      'ER_EX_icdchol[e]',
      'ER_EX_isochol[e]',      'ER_EX_lca24g[e]',      'ER_EX_lca3g[e]',      'ER_EX_thyochol[e]',
      'ER_EX_uchol[e]',      'ER_HCA24Gtr',      'ER_HDCA6Gtr',      'ER_HYOCHOLtr',
      'ER_LCA24Gtr',      'ER_LCA3Gtr',      'ER_M02155tr',      'ER_12HTACRtep',
      'ER_14MDZtev',      'ER_1HIBUPGLUC_Sthv',      'ER_1HIBUP_Sthv',      'ER_1HMDZGLUChc',
      'ER_1OHMDZtep',      'ER_2HATVACIDtep',      'ER_2HATVLACtep',      'ER_2HIBUPGLUC_Sthv',
      'ER_2HIBUP_Rthv',      'ER_2HIBUP_Sthv',      'ER_35DSMVteb',      'ER_3HIBUPGLUC_Sthv',
      'ER_3HIBUP_Rthv',      'ER_3HIBUP_Sthv',      'ER_3HLVSTACtbc',      'ER_3HPVSTETtev',
      'ER_3HPVStep',      'ER_3HSMVACIDteb',      'ER_3ISPVStep',      'ER_3MEACMPhc',
      'ER_3OHACMPtev',      'ER_4HATVACIDtep',      'ER_4HATVLACtep',      'ER_4HMDGLUCtev',
      'ER_4OHMDZtev',      'ER_56DHPVStev',      'ER_56EPPVStev',      'ER_5OHFVSGLUhc',
      'ER_5OHFVSGLUtev',      'ER_5OHFVSteb',      'ER_6BHGLZtev',      'ER_6CSMVACIDteb',
      'ER_6EPVStep',      'ER_6HLVSTthep',      'ER_6HMSMVACIDteb',      'ER_6HSMVACIDteb',
      'ER_6MELVSTthep',      'ER_6OHFVSGLUhc',      'ER_6OHFVSGLUtev',      'ER_7BHGLZtev',
      'ER_7HPVStev',      'ER_ACMPdt',      'ER_AM1CSAtep',      'ER_AM9CSAtep',
      'ER_ATVACIDhr',      'ER_ATVACIDtdu',      'ER_ATVLACh2r',      'ER_ATVLAChr',
      'ER_ATVLACtdhc',      'ER_Am19CStev',      'ER_CARBIBUP_SGLUthv',      'ER_CARIBUP_Sthv',
      'ER_CRVSM24tev',      'ER_CRVStu',      'ER_CSAtd',      'ER_DEOXFVStev',
      'ER_DSPVStev',      'ER_EPOXTAChr',      'ER_EPOXTACtev',      'ER_EX_12htacr[e]',
      'ER_EX_14hmdz[e]',      'ER_EX_1hibup_S[e]',      'ER_EX_1hibupglu_S[e]',      'ER_EX_1hmdgluc[e]',
      'ER_EX_1ohmdz[e]',      'ER_EX_2hatvacid[e]',      'ER_EX_2hatvlac[e]',      'ER_EX_2hatvlacgluc[e]',
      'ER_EX_2hibup_R[e]',      'ER_EX_2hibup_S[e]',      'ER_EX_2hibupglu_S[e]',      'ER_EX_35dsmv[e]',
      'ER_EX_3hibup_R[e]',      'ER_EX_3hibup_S[e]',      'ER_EX_3hibupglu_S[e]',      'ER_EX_3hlvstacid[e]',
      'ER_EX_3hpvs[e]',      'ER_EX_3hpvstet[e]',      'ER_EX_3hsmvacid[e]',      'ER_EX_3ohacmp[e]',
      'ER_EX_4hatvacid[e]',      'ER_EX_4hatvlac[e]',      'ER_EX_4hmdgluc[e]',      'ER_EX_4ohmdz[e]',
      'ER_EX_5ohfvs[e]',      'ER_EX_5ohfvsglu[e]',      'ER_EX_6bhglz[e]',      'ER_EX_6csmvacid[e]',
      'ER_EX_6hlvst[e]',      'ER_EX_6hmsmvacid[e]',      'ER_EX_6hsmvacid[e]',      'ER_EX_6melvacid[e]',
      'ER_EX_6melvst[e]',      'ER_EX_6ohfvsglu[e]',      'ER_EX_7bhglz[e]',      'ER_EX_acmp[e]',
      'ER_EX_am19cs[e]',      'ER_EX_am1csa[e]',      'ER_EX_am9csa[e]',      'ER_EX_atvacid[e]',
      'ER_EX_atvlac[e]',      'ER_EX_caribup_s[e]',      'ER_EX_caribupglu_S[e]',      'ER_EX_crvs[e]',
      'ER_EX_crvsm24[e]',      'ER_EX_csa[e]',      'ER_EX_deoxfvs[e]',      'ER_EX_epoxtac[e]',
      'ER_EX_fvs[e]',      'ER_EX_glc3meacp[e]',      'ER_EX_glz[e]',      'ER_EX_ibup_R[e]',
      'ER_EX_ibup_S[e]',      'ER_EX_ibupgluc[e]',      'ER_EX_isolvstacid[e]',      'ER_EX_lstn[e]',
      'ER_EX_lstnm7[e]',      'ER_EX_lvst[e]',      'ER_EX_mdz[e]',      'ER_EX_nfdac[e]',
      'ER_EX_nfdoh[e]',      'ER_EX_profvs[e]',      'ER_EX_ptvst[e]',      'ER_EX_ptvstlac[e]',
      'ER_EX_pvs[e]',      'ER_EX_smv[e]',      'ER_EX_smvacid[e]',      'ER_EX_tacr[e]',
      'ER_EX_tlacfvs[e]',      'ER_FVShc',      'ER_FVStep',      'ER_GLC3MEACPtev',
      'ER_GLZtd',      'ER_IBUPGLUCtchep',      'ER_IBUPGLUCtpvb',      'ER_IBUP_Rtdhep',
      'ER_IBUP_Rtdu',      'ER_IBUP_Stdhep',      'ER_IBUP_Stdu',      'ER_ISOLVSTAChep',
      'ER_LSTNM7TDhc',      'ER_LSTNM7thc',      'ER_LSTNRATt',      'ER_LSTNtd',
      'ER_LVACLAChep',      'ER_LVSTtu',      'ER_MDZtd',      'ER_NFDACtep',
      'ER_NFDOHtep',      'ER_OXYPtepv',      'ER_PROFVShc',      'ER_PROFVStev',
      'ER_PTVSTLAChc',      'ER_PTVSTLACtev',      'ER_PTVSTtep',      'ER_PVSGLUCtev',
      'ER_PVSHtu',      'ER_PVStep',      'ER_RSVGLUChc',      'ER_RSVLAChv',
      'ER_SMVACIDtev',      'ER_SMVtv',      'ER_TACRDtsc',      'ER_TLACFVStev',
      'ER_TRIPVStev',      'ER_12HTACRitr',      'ER_14HMDZitr',      'ER_1HIBUP_Sitr',
      'ER_1HIBUPGLUitr',      'ER_1HMDGLUCitr',      'ER_2HATVLACGLUCitr',      'ER_2HIBUP_Ritr',
      'ER_2HIBUP_Sitr',      'ER_2HIBUPGLUC_Sitr',      'ER_35DSMVitr',      'ER_3HIBUP_Ritr',
      'ER_3HIBUPGLUC_Sitr',      'ER_3HLVSTitr',      'ER_3HPVSitr',      'ER_3HPVSCOAitm',
      'ER_3HPVSCOAitx',      'ER_3HPVSTETCOAitm',      'ER_3HPVSTETCOAitx',      'ER_3HSMVitr',
      'ER_3MEACMPitr',      'ER_3OHACMPitr',      'ER_4HATVACIDitr',      'ER_4HATVLACitr',
      'ER_4HMDGLUCitr',      'ER_4OHMDZitr',      'ER_5OHFVSitr',      'ER_5OHFVSGLUitr',
      'ER_6CSMVitr',      'ER_6HLVSTitr',      'ER_6HLVSTACIDitr',      'ER_6HMSMVitr',
      'ER_6HSMVitr',      'ER_6MELVACIDitr',      'ER_6MELVSTitr',      'ER_6OHFVSGLUitr',
      'ER_ACMPitr',      'ER_AM19CSitr',      'ER_CARIBUP_Sitr',      'ER_CARIBUPGLU_Sitr',
      'ER_CRVSitr',      'ER_CRVSM24itr',      'ER_CSAitr',      'ER_DEOXFVSitx',
      'ER_EPOXTACitr',      'ER_FVSitx',      'ER_FVSCOAitx',      'ER_GLC3MEACPitr',
      'ER_GLZitr',      'ER_IBUP_Ritr',      'ER_IBUP_Sitr',      'ER_IBUPGLUCitr',
      'ER_LSTNitr',      'ER_LSTNM7itr',      'ER_LVSTitr',      'ER_LVSTACIDitr',
      'ER_MDZitr',      'ER_NFDOHitr',      'ER_PROFVSCOAitx',      'ER_PTVSTLACitr',
      'ER_PTVSTM13itr',      'ER_PTVSTM13te',      'ER_EX_ptvstm13[e]',      'ER_PVSitr',
      'ER_RSVLACitr',      'ER_TACRitr',      'ER_TLACFVSitr',      'ER_3HPVSCOAhc',
      'ER_3HPVSTEThc',      'ER_FVSCOAhc',      'ER_1OHMDZitr',      'ER_NFDACitr',
      'ER_H2O2itr',      'ER_ATVACIDitr',      'ER_ATVLACitr',      'ER_SMVitr',
      'ER_6BHGLZitr',      'ER_7BHGLZitr',      'ER_RSVitr',      'ER_PTVSTitr',
      'ER_3HIBUP_Sitr',      'ER_FVSitr',      'ER_AM1CSAitr',      'ER_AM9CSAitr',
      'ER_2HATVACIDitr',      'ER_EX_caproic[e]',      'ER_1A25HVITD2t',      'ER_1A25HVITD2tm',
      'ER_EX_1a25dhvitd2[e]',      'ER_EX_C13856[e]',      'ER_EX_M00234[e]',      'ER_EX_M01807[e]',
      'ER_EX_M00503[e]',      'ER_EX_M00003[e]',      'ER_EX_M00008[e]',      'ER_EX_M00010[e]',
      'ER_EX_M00017[e]',      'ER_EX_M00019[e]',      'ER_EX_M00021[e]',      'ER_EX_M00115[e]',
      'ER_EX_M00117[e]',      'ER_EX_M00260[e]',      'ER_EX_M00265[e]',      'ER_EX_M00315[e]',
      'ER_EX_M00341[e]',      'ER_EX_M01197[e]',      'ER_EX_M01207[e]',      'ER_EX_M01235[e]',
      'ER_EX_M01238[e]',      'ER_EX_M01582[e]',      'ER_EX_M02053[e]',      'ER_EX_M02457[e]',
      'ER_EX_M02613[e]',      'ER_EX_M02745[e]',      'ER_EX_M03045[e]',      'ER_EX_M03051[e]',
      'ER_EX_M03153[e]',      'ER_EX_M02560[e]',      'ER_EX_C01601[e]',      'ER_EX_M02108[e]',
      'ER_EX_M03117[e]',      'ER_EX_M03134[e]',      'ER_EX_M01111[e]',      'ER_EX_h2co3[e]',
      'ER_EX_M01870[e]',      'ER_EX_ditp[e]',      'ER_EX_M02446[e]',      'ER_EX_M02447[e]',
      'ER_EX_M02449[e]',      'ER_EX_M02451[e]',      'ER_EX_itacon[e]',      'ER_EX_adpman[e]',
      'ER_EX_rbl_D[e]',      'ER_EX_M02155[e]',      'ER_EX_M01989[e]',      'ER_EX_M03131[e]',
      'ER_EX_n5m2masn[e]',      'ER_EX_dolichol_L[e]',      'ER_sink_his_L[c]',      'ER_sink_ile_L[c]',
      'ER_sink_leu_L[c]',      'ER_sink_lys_L[c]',      'ER_sink_met_L[c]',      'ER_sink_phe_L[c]',
      'ER_sink_thr_L[c]',      'ER_sink_trp_L[c]',      'ER_sink_val_L[c]',      'ER_sink_ala_L[c]',
      'ER_sink_arg_L[c]',      'ER_sink_asn_L[c]',      'ER_sink_asp_L[c]',      'ER_sink_cys_L[c]',
      'ER_sink_gln_L[c]',      'ER_sink_glu_L[c]',      'ER_sink_pro_L[c]',      'ER_sink_ser_L[c]',
      'ER_sink_tyr_L[c]',      'ER_sink_gly[c]',      'ER_sink_4abut[l]',      'ER_DM_5cysdopa[c]',
      'ER_DM_4abut[c]',      'ER_DM_srtn[c]',      'ER_DM_ach[c]',      'ER_DM_hista[c]',
      'ER_DM_kynate[c]',      'ER_DM_tym[c]',      'ER_DM_Lkynr[c]',      'ER_DM_cbl2[m]',
      'ER_DCMPtm',      'ER_ATPS4mi',      'ER_KER_02243',      'ER_KER_02407',
      'ER_KER_10600',      'ER_ITPtm',      'ER_IDPtm',      'ER_CE_Peptide',
      'ER_EX_Peptide',      'ER_Ubiquitin_syn',      'ER_DM_Ubiquitin',      'ER_Abeta_syn',
      'ER_DM_Abeta',      'ER_Abeta_L_lysine',      'ER_CE_Abeta_L_lysine',      'ER_CN_Abeta_L_lysine',
      'ER_EX_Abeta_L_lysine',      'ER_EN_Abeta_L_lysine',      'ER_Abeta_Deg',      'ER_Tau_syn',
      'ER_DM_Tau',      'ER_Tau_L_lysine',      'ER_CE_Tau_L_lysine',      'ER_CN_Tau_L_lysine',
      'ER_EX_Tau_L_lysine',      'ER_EN_Tau_L_lysine',      'ER_Tau_Deg',      'ER_TNFA_syn',
      'ER_DM_TNFA',      'ER_TNFA_L_lysine',      'ER_CE_TNFA_L_lysine',      'ER_CN_TNFA_L_lysine',
      'ER_EX_TNFA_L_lysine',      'ER_EN_TNFA_L_lysine',      'ER_TNFA_Deg',      'ER_IL6_syn',
      'ER_DM_IL6',      'ER_IL6_L_lysine',      'ER_CE_IL6_L_lysine',      'ER_CN_IL6_L_lysine',
      'ER_EX_IL6_L_lysine',      'ER_EN_IL6_L_lysine',      'ER_IL6_Deg'
    /

  genes "genes defined in BL model"
    /
      '8639.1',      '26.1',      '314.2',      '314.1',      '1594.1',      '10993.1',      '6818.1',      '89874.1',      '92483.1',      '3948.2',
      '55293.1',      '3945.1',      '3939.1',      '160287.1',      '3948.1',      '9123.1',      '9194.1',      '6566.1',      '4967.2',      '1738.1',
      '8050.1',      '1743.1',      '4967.1',      '130.1',      '127.1',      '125.1',      '124.1',      '131.1',      '126.1',      '128.1',
      '137872.1',      '1312.1',      '1312.2',      '117247.1',      '218.1',      '222.1',      '220.1',      '221.1',      '3242.1',      '18.1',
      '18.2',      '23498.1',      '55268.1',      '51166.1',      '883.1',      '51166.2',      '1644.1',      '4128.1',      '4129.1',      '10165.1',
      '8604.1',      '51380.1',      '2571.1',      '2572.1',      '2571.2',      '8659.1',      '8659.2',      '6799.1',      '6817.3',      '6799.2',
      '6818.2',      '6817.2',      '6817.4',      '6817.1',      '6818.3',      '6817.5',      '4363.1',      '6822.1',      '6573.1',      '6573.2',
      '6570.1',      '6571.1',      '2348.5',      '2348.3',      '2348.1',      '2348.6',      '2352.1',      '2348.4',      '2348.2',      '4125.1',
      '53947.1',      '51146.1',      '28.1',      '206358.1',      '6529.1',      '6538.1',      '6540.1',      '6539.1',      '38.1',      '3032.1',
      '10449.1',      '3030.1',      '39.1',      '30.1',      '32.1',      '9197.1',      '84532.1',      '79611.1',      '64841.1',      '55577.1',
      '5238.1',      '9487.1',      '162417.1',      '43.1',      '6572.1',      '47.1',      '47.2',      '54187.1',      '26503.1',      '140838.1',
      '54.1',      '51205.1',      '36.1',      '34.1',      '80724.1',      '35.1',      '84129.1',      '27034.1',      '28976.1',      '3712.1',
      '51.1',      '51.2',      '50.1',      '48.1',      '8309.1',      '52.1',      '52.3',      '52.2',      '55.1',      '788.1',
      '55902.1',      '65985.1',      '55902.2',      '1571.1',      '3177.1',      '205.3',      '205.1',      '204.1',      '204.3',      '204.2',
      '205.2',      '26289.1',      '26289.2',      '112.1',      '55811.1',      '109.1',      '112.2',      '114.1',      '108.1',      '113.1',
      '107.1',      '196883.1',      '115.1',      '111.1',      '2030.1',      '9154.2',      '9154.1',      '64078.1',      '9153.1',      '55315.1',
      '11164.1',      '952.1',      '1375.1',      '1375.3',      '1375.4',      '126129.1',      '1374.1',      '1375.2',      '1376.1',      '9060.1',
      '9061.1',      '158.1',      '158.2',      '79369.1',      '10678.1',      '11041.1',      '146712.1',      '374907.1',      '93010.1',      '374907.2',
      '10678.2',      '10331.1',      '10555.1',      '56895.1',      '56894.1',      '55326.1',      '10554.1',      '129642.1',      '189.1',      '3073.1',
      '3074.1',      '10606.1',      '1468.1',      '64849.1',      '1645.1',      '1109.1',      '6718.1',      '6510.1',      '6509.1',      '56301.1',
      '6520.1',      '212.1',      '23464.1',      '211.2',      '211.1',      '54407.1',      '6542.1',      '11254.1',      '6541.1',      '81539.1',
      '55089.1',      '84889.1',      '340024.1',      '57393.1',      '59272.1',      '284273.2',      '284273.1',      '10327.1',      '10327.2',      '216.1',
      '8854.2',      '501.1',      '8854.1',      '223.1',      '224.1',      '8854.3',      '219.1',      '217.1',      '239.1',      '247.1',
      '246.1',      '240.1',      '8574.1',      '231.1',      '23600.1',      '23600.2',      '115286.3',      '115286.2',      '115286.1',      '271.2',
      '270.1',      '271.1',      '272.1',      '271.3',      '290.1',      '280.1',      '278.1',      '276.1',      '277.1',      '6519.1',
      '11136.1',      '276.2',      '279.1',      '10998.1',      '113451.1',      '9057.1',      '384.1',      '445.1',      '445.2',      '83884.1',
      '10166.1',      '427.1',      '427.2',      '9962.2',      '9963.1',      '9962.1',      '9963.2',      '790.1',      '6511.1',      '6505.1',
      '6507.1',      '6506.1',      '6512.1',      '954.1',      '954.2',      '953.1',      '956.1',      '955.1',      '957.1',      '377841.1',
      '4126.1',      '8706.4',      '8706.1',      '8706.3',      '8706.2',      '8705.1',      '10317.4',      '10317.1',      '10317.3',      '10317.2',
      '10317.5',      '84002.1',      '570.1',      '140679.1',      '53630.1',      '622.2',      '622.3',      '622.1',      '10599.1',      '1244.1',
      '8714.1',      '28234.1',      '9488.1',      '10380.1',      '8884.1',      '80704.1',      '51733.1',      '7108.1',      '50814.1',      '3295.1',
      '6307.1',      '847.1',      '6547.6',      '6547.4',      '6547.2',      '6546.1',      '6547.1',      '6547.5',      '6543.1',      '6547.3',
      '166785.1',      '2538.1',      '57818.1',      '92579.1',      '873.1',      '10423.1',      '10423.2',      '1040.1',      '8760.1',      '10390.1',
      '56994.1',      '64781.1',      '64781.2',      '10087.1',      '6565.1',      '9023.1',      '1103.4',      '1103.2',      '1103.3',      '1103.1',
      '5130.1',      '9468.1',      '6579.1',      '6554.1',      '6555.1',      '8714.3',      '8647.1',      '8714.2',      '1120.2',      '1119.1',
      '1120.1',      '1119.2',      '6582.1',      '6584.1',      '6582.2',      '6820.1',      '19.1',      '27159.1',      '54682.1',      '1118.1',
      '27159.2',      '9058.1',      '6576.1',      '5172.1',      '65010.1',      '65010.3',      '65010.2',      '54675.1',      '10559.1',      '55907.1',
      '8034.1',      '8824.1',      '51805.1',      '51004.1',      '51004.2',      '10229.1',      '9245.1',      '2650.1',      '51301.1',      '192134.1',
      '6535.1',      '386757.1',      '1384.1',      '6583.1',      '1431.1',      '1431.2',      '54677.1',      '1384.2',      '8140.1',      '23428.1',
      '23657.1',      '7371.1',      '83549.1',      '51727.1',      '129607.1',      '9162.1',      '1607.1',      '8525.2',      '160851.1',      '1608.1',
      '1607.2',      '8525.1',      '8527.1',      '1606.1',      '160851.2',      '8526.1',      '8525.3',      '8527.2',      '1609.1',      '1610.1',
      '2745.1',      '51022.2',      '51022.1',      '8528.2',      '8528.1',      '1632.1',      '10455.1',      '1633.1',      '6319.1',      '9415.1',
      '3992.1',      '1716.5',      '1716.1',      '1716.4',      '1716.2',      '1716.3',      '6515.1',      '6513.1',      '6517.1',      '1718.1',
      '1581.1',      '1717.1',      '8560.1',      '8560.2',      '123099.1',      '11309.1',      '6783.1',      '23539.1',      '2224.1',      '60386.1',
      '79087.1',      '6581.1',      '669.2',      '5223.1',      '5224.2',      '5224.1',      '669.1',      '4597.1',      '51071.1',      '1806.1',
      '7083.1',      '7084.1',      '1854.1',      '3704.1',      '10682.1',      '1892.1',      '549.1',      '1891.1',      '1962.1',      '11001.1',
      '28231.1',      '53919.1',      '10257.1',      '28232.1',      '55500.1',      '55224.1',      '8790.1',      '51086.1',      '2181.1',      '2182.1',
      '2180.1',      '2181.2',      '51703.1',      '81616.1',      '23305.1',      '2182.2',      '116285.1',      '5167.1',      '5169.1',      '6785.1',
      '79071.1',      '60481.1',      '54898.1',      '3028.1',      '2194.1',      '376497.2',      '10999.1',      '376497.1',      '11000.1',      '226.2',
      '229.1',      '226.3',      '230.1',      '226.1',      '2203.1',      '5210.1',      '5207.1',      '5209.1',      '5208.1',      '8789.1',
      '2235.1',      '2235.2',      '79901.1',      '197258.1',      '1719.1',      '2356.1',      '29988.1',      '6514.1',      '155184.1',      '6518.1',
      '66035.1',      '25902.1',      '4522.1',      '2519.1',      '2517.1',      '2271.1',      '2523.1',      '2525.1',      '10690.1',      '8703.1',
      '8704.2',      '8704.1',      '2683.1',      '9334.1',      '2820.1',      '5832.1',      '2539.1',      '2542.1',      '2593.1',      '2593.2',
      '5476.1',      '2720.1',      '2588.1',      '4758.1',      '2581.1',      '2583.1',      '55790.1',      '55454.1',      '79586.1',      '22856.1',
      '337876.1',      '26290.1',      '79695.1',      '2589.1',      '50614.1',      '8693.1',      '55568.2',      '114805.1',      '11226.1',      '117248.1',
      '11227.1',      '55568.1',      '2590.1',      '51809.1',      '79623.1',      '63917.1',      '2591.1',      '81031.1',      '126792.1',      '11285.1',
      '8972.1',      '2618.1',      '2618.2',      '175.1',      '2629.2',      '2629.3',      '2629.4',      '2629.5',      '2629.1',      '26301.1',
      '4329.1',      '7915.1',      '7915.2',      '275.1',      '2731.1',      '2653.1',      '2651.1',      '55343.1',      '7264.1',      '8836.1',
      '2687.1',      '6472.1',      '6470.1',      '6470.2',      '2717.1',      '2990.1',      '8372.1',      '26035.1',      '54480.1',      '2131.1',
      '2132.1',      '27087.2',      '135152.1',      '27087.1',      '26229.1',      '4669.1',      '64579.1',      '3340.1',      '9348.1',      '8509.1',
      '2137.1',      '2135.1',      '2134.1',      '56606.1',      '154091.1',      '11182.1',      '56606.2',      '144195.1',      '6523.1',      '178.4',
      '178.5',      '178.1',      '178.3',      '178.2',      '178.6',      '5834.1',      '5837.1',      '5836.1',      '2729.1',      '2730.1',
      '10841.1',      '10841.2',      '2744.1',      '27165.2',      '27165.1',      '83733.1',      '79751.1',      '2639.1',      '2639.2',      '54363.1',
      '51179.2',      '51179.1',      '2710.2',      '2712.1',      '2710.1',      '2713.1',      '3029.1',      '6536.1',      '6536.2',      '5226.1',
      '284098.1',      '80055.1',      '93183.1',      '54965.1',      '2936.1',      '7001.3',      '5052.3',      '2877.1',      '2876.2',      '5052.2',
      '2876.1',      '5052.1',      '7001.1',      '2879.1',      '7001.2',      '2878.1',      '257202.1',      '2882.1',      '10935.1',      '10935.2',
      '2937.1',      '2679.1',      '2678.1',      '2678.3',      '2678.2',      '2977.1',      '2983.1',      '4882.2',      '2982.1',      '2974.1',
      '2986.1',      '4882.1',      '2984.1',      '4881.1',      '3000.1',      '9615.1',      '763.1',      '11238.1',      '23556.1',      '23556.2',
      '55650.1',      '53905.1',      '50506.1',      '53905.2',      '5281.1',      '84720.1',      '54872.1',      '80235.1',      '10026.1',      '8733.1',
      '128869.1',      '94005.1',      '51604.1',      '3033.1',      '3038.2',      '3036.1',      '3038.1',      '3037.1',      '27235.1',      '6522.1',
      '83697.1',      '6521.1',      '6508.2',      '6508.1',      '2645.1',      '3099.1',      '3098.3',      '2645.2',      '80201.1',      '3098.2',
      '2645.3',      '3098.1',      '3098.4',      '3101.1',      '3098.5',      '3067.1',      '3157.1',      '3157.2',      '3158.1',      '3155.1',
      '54511.1',      '26061.1',      '197257.1',      '197257.2',      '6448.1',      '3292.1',      '7923.1',      '3294.1',      '51478.1',      '3284.1',
      '80270.1',      '3420.1',      '3421.1',      '3419.1',      '3417.1',      '3418.1',      '7173.4',      '7173.1',      '7173.3',      '7173.2',
      '7173.5',      '3425.1',      '587.1',      '6526.1',      '3422.1',      '91734.1',      '160728.1',      '8802.1',      '8801.1',      '8803.1',
      '6560.1',      '10723.1',      '9990.1',      '57468.1',      '3795.1',      '3795.2',      '84679.1',      '23315.1',      '8564.1',      '3938.1',
      '53.1',      '387775.1',      '124637.1',      '366.1',      '11283.1',      '4047.1',      '5321.1',      '4023.1',      '3990.1',      '1056.1',
      '80339.1',      '11343.1',      '11343.2',      '50487.1',      '9227.1',      '6309.1',      '4190.1',      '4200.1',      '10873.1',      '1557.1',
      '1543.1',      '1545.1',      '1544.1',      '4598.1',      '3635.1',      '8867.2',      '3636.1',      '27124.2',      '8867.1',      '27124.1',
      '3633.1',      '56623.1',      '3632.1',      '3706.1',      '80271.1',      '3707.1',      '51477.1',      '3631.1',      '8821.1',      '4507.1',
      '10797.1',      '4668.1',      '6528.1',      '6548.1',      '6550.1',      '6549.1',      '84735.1',      '55748.1',      '6559.1',      '123041.2',
      '57419.1',      '9187.1',      '123041.3',      '25769.1',      '123041.1',      '124583.1',      '9583.1',      '4832.1',      '4831.1',      '4830.1',
      '10201.1',      '29922.2',      '29922.1',      '4833.1',      '57127.1',      '6005.1',      '349565.1',      '64802.1',      '23057.1',      '23057.2',
      '4837.1',      '4846.1',      '201288.1',      '4842.1',      '4843.2',      '4843.1',      '645740.1',      '4860.1',      '6580.1',      '30833.1',
      '5251.1',      '56953.1',      '4907.1',      '3704.2',      '6476.1',      '5019.1',      '64064.1',      '1629.1',      '594.1',      '593.1',
      '7372.1',      '1836.1',      '10861.1',      '10861.3',      '10861.2',      '1811.1',      '1584.1',      '1585.1',      '1588.1',      '1576.1',
      '1589.1',      '1593.1',      '1553.1',      '1548.1',      '1562.1',      '1558.1',      '1558.2',      '1559.1',      '1565.1',      '1572.1',
      '64816.1',      '1577.1',      '1551.1',      '66002.1',      '4051.1',      '8529.1',      '9420.1',      '1582.1',      '5831.1',      '5831.2',
      '5051.1',      '5049.1',      '5050.1',      '5048.1',      '347734.1',      '57194.1',      '5338.1',      '5337.1',      '5091.1',      '5091.2',
      '5244.1',      '5244.3',      '5244.2',      '5139.1',      '5142.1',      '5151.3',      '5153.1',      '5150.2',      '5143.1',      '5150.1',
      '5137.1',      '5144.1',      '5136.2',      '5140.2',      '5151.2',      '10846.1',      '5151.5',      '5140.1',      '5141.1',      '5138.1',
      '5136.1',      '5151.4',      '5151.1',      '27115.1',      '50940.1',      '8622.1',      '5146.1',      '5152.17',      '5152.6',      '5152.11',
      '5152.2',      '8654.2',      '5152.10',      '5145.1',      '5158.1',      '5149.1',      '5152.12',      '5152.15',      '5152.5',      '5152.20',
      '5152.19',      '5152.16',      '8654.3',      '5152.14',      '5152.13',      '5152.7',      '5152.3',      '8654.1',      '5152.18',      '5147.1',
      '5148.1',      '5152.4',      '5152.1',      '55163.1',      '5105.1',      '8310.1',      '5833.1',      '10400.2',      '10400.1',      '10400.3',
      '80142.4',      '80142.2',      '9536.1',      '80142.1',      '9536.2',      '80142.3',      '9489.1',      '5743.1',      '5742.1',      '5053.1',
      '5264.1',      '5728.1',      '8871.1',      '8394.1',      '23396.1',      '8395.1',      '55361.1',      '5297.1',      '5298.1',      '5293.1',
      '8503.1',      '5296.1',      '5290.1',      '5295.1',      '5291.1',      '10870.1',      '5294.1',      '23533.1',      '4952.1',      '4952.2',
      '23236.2',      '5336.1',      '9651.1',      '113026.1',      '89869.1',      '84812.1',      '5330.1',      '5335.1',      '51196.1',      '5333.1',
      '5332.2',      '5331.1',      '5335.2',      '5334.1',      '5332.1',      '257068.1',      '23236.1',      '23007.1',      '5287.1',      '5286.1',
      '5288.1',      '200576.2',      '8396.1',      '200576.3',      '79837.1',      '8396.2',      '5305.1',      '200576.1',      '5289.1',      '5279.1',
      '51227.1',      '5277.1',      '5283.1',      '9091.1',      '8818.1',      '8398.1',      '5320.1',      '8398.2',      '81579.1',      '5322.1',
      '64600.1',      '100137049.1',      '123745.1',      '5319.1',      '26279.1',      '8399.1',      '30814.1',      '10654.1',      '117283.1',      '9807.2',
      '9807.1',      '51447.3',      '51447.4',      '51447.6',      '51447.5',      '51447.1',      '51447.2',      '27068.4',      '27068.1',      '27068.3',
      '27068.2',      '8612.1',      '8611.1',      '8613.1',      '8611.2',      '5498.1',      '8288.1',      '9588.1',      '4353.1',      '6578.1',
      '10965.1',      '10005.1',      '10005.3',      '10005.2',      '122970.1',      '7378.2',      '151531.1',      '7378.1',      '64080.1',      '5959.1',
      '8608.1',      '157506.1',      '112724.1',      '145226.1',      '51109.1',      '195814.1',      '57665.1',      '50700.1',      '8228.1',      '54981.1',
      '6484.1',      '6482.1',      '6483.1',      '6482.2',      '10090.1',      '9653.1',      '3423.1',      '3423.2',      '9957.1',      '9951.1',
      '222537.1',      '9956.1',      '9955.1',      '9953.1',      '64711.1',      '113189.1',      '50515.1',      '166012.1',      '55501.1',      '411.2',
      '411.1',      '23563.2',      '9435.1',      '23563.1',      '10164.1',      '4166.1',      '8534.1',      '9469.1',      '56548.1',      '266722.1',
      '9394.1',      '90161.2',      '90161.1',      '2799.1',      '10157.1',      '118881.1',      '3176.1',      '81537.1',      '6342.1',      '9056.1',
      '2098.1',      '8869.1',      '56848.1',      '8877.1',      '130752.1',      '55512.1',      '55512.2',      '339221.1',      '55627.1',      '6609.1',
      '6610.1',      '259230.1',      '115111.1',      '115019.2',      '115111.2',      '116369.2',      '284129.1',      '116369.1',      '115019.1',      '6646.1',
      '6611.1',      '6723.1',      '6713.1',      '2222.1',      '10402.1',      '256435.1',      '30815.1',      '81849.1',      '6489.1',      '29906.1',
      '412.1',      '6389.1',      '6392.1',      '6391.1',      '6390.1',      '6821.1',      '5092.1',      '5092.2',      '23530.2',      '23530.1',
      '79178.1',      '6567.1',      '55217.1',      '7296.3',      '7296.1',      '7296.4',      '7296.2',      '80162.1',      '11181.1',      '7166.1',
      '121278.1',      '6561.1',      '6916.1',      '10020.1',      '7355.1',      '7358.1',      '23169.1',      '80146.1',      '84912.1',      '11046.1',
      '54576.1',      '54575.1',      '54578.1',      '54579.1',      '54600.1',      '54658.1',      '54659.1',      '54577.1',      '54657.1',      '7364.1',
      '54490.1',      '7367.1',      '10720.1',      '7363.1',      '7365.1',      '7366.1',      '54963.1',      '7498.1',      '64131.1',      '64132.1',
      '1356.1',      '2512.1',      '2495.1',      '94033.1',      '10587.1',      '80347.1',      '22978.1',      '84618.1',      '51251.1',      '93034.1',
      '100526794.1',      '3251.1',      '353.1',      '56954.1',      '5313.1',      '92086.1',      '728441.1',      '102724197.1',      '2686.1',      '124975.1',
      '91227.1',      '5211.1',      '29926.1',      '29925.1',      '249.1',      '51292.1',      '2766.1',      '57571.1',      '11332.1',      '5538.1',
      '641371.1',      '9374.1',      '55825.1',      '51102.1',      '37.1',      '33.1',      '132158.1',      '93100.1',      '23475.1',      '50484.1',
      '6240.1',      '6241.1',      '79966.1',      '10588.1',      '79646.1',      '80025.1',      '53354.1',      '55229.1',      '29920.1',      '7389.1',
      '1595.1',      '130367.1',      '23443.1',      '64240.1',      '64241.1',      '284111.1',      '8435.1',      '3988.1',      '771.1',      '760.1',
      '768.1',      '23632.1',      '765.1',      '759.1',      '762.1',      '766.1',      '767.1',      '377677.1',      '10057.1',      '6568.1',
      '54020.1',      '215.1',      '641372.1',      '25830.1',      '84569.1',      '4025.1',      '93492.1',      '10249.1',      '1580.1',      '1555.1',
      '1549.1',      '1573.1',      '199974.1',      '260293.1',      '29785.1',      '57834.1',      '1215.1',      '1357.1',      '1358.1',      '57094.1',
      '93979.1',      '1636.1',      '9331.1',      '5315.1',      '26063.1',      '1666.1',      '874.1',      '10901.1',      '126410.1',      '2053.1',
      '8897.1',      '8897.3',      '8897.2',      '8898.1',      '2880.1',      '115584.1',      '6534.1',      '1622.1',      '225.1',      '28965.1',
      '23205.1',      '54716.1',      '113235.1',      '2168.1',      '9390.1',      '248.1',      '4524.1',      '65263.1',      '28982.1',      '6120.1',
      '6120.2',      '10864.1',      '9356.1',      '9376.1',      '120103.1',      '85320.1',      '222962.1',      '9429.1',      '55867.1',      '360.1',
      '364.1',      '89872.1',      '21.1',      '10057.2',      '125206.1',      '200010.1',      '6524.1',      '159963.1',      '79581.1',      '55065.1',
      '3764.1',      '6833.1',      '10060.1',      '3767.1',      '5950.1',      '64220.1',      '5947.1',      '5948.1',      '949.1',      '29881.1',
      '2350.1',      '3248.1',      '166929.1',      '3658.1',      '122481.1',      '203.1',      '159.1',      '122622.1',      '122622.2',      '11212.1',
      '383.1',      '1371.1',      '1503.1',      '56474.1',      '2987.1',      '9453.1',      '2023.1',      '2027.1',      '2027.2',      '2026.1',
      '9843.1',      '80308.1',      '80308.2',      '7360.1',      '7360.2',      '2597.1',      '26330.1',      '2673.1',      '9945.1',      '1800.1',
      '2762.1',      '761.1',      '766.2',      '771.2',      '3145.1',      '586.1',      '3614.1',      '3615.1',      '3614.2',      '682.1',
      '29926.2',      '29925.2',      '4351.1',      '100287639.1',      '441024.1',      '389015.1',      '6553.1',      '5230.1',      '375056.1',      '5232.1',
      '5236.1',      '55276.1',      '5372.1',      '5373.1',      '210.1',      '210.2',      '58510.1',      '153201.1',      '221823.2',      '5631.1',
      '221823.1',      '5634.1',      '8781.1',      '5723.1',      '55312.1',      '79896.1',      '7086.1',      '84076.1',      '8277.1',      '27010.1',
      '2582.1',      '2582.2',      '6675.1',      '91373.1',      '7390.1',      '6563.1',      '8170.1',      '100507855.1',      '31.5',      '31.4',
      '31.2',      '31.3',      '31.1',      '93034.2',      '55191.1',      '132.1',      '132.2',      '112611.1',      '98.1',      '97.2',
      '97.1',      '171425.1',      '171425.2',      '132789.1',      '10007.1',      '2584.1',      '2585.2',      '2585.1',      '2592.1',      '2592.3',
      '2592.2',      '5471.1',      '84264.2',      '84264.1',      '3034.1',      '3612.1',      '3613.1',      '8776.1',      '2978.1',      '4953.1',
      '5214.1',      '5211.2',      '5213.1',      '10050.1',      '10786.1',      '10246.1',      '6569.1',      '10568.1',      '5198.1',      '5315.2',
      '5313.2',      '5315.3',      '113675.1',      '1635.1',      '10560.1',      '191.1',      '10768.2',      '10768.1',      '5205.1',      '57198.1',
      '23250.1',      '286410.1',      '5243.1',      '55856.1',      '7350.1',      '26027.1',      '10058.1',      '51458.1',      '948.1',      '10928.1',
      '1728.1',      '125981.1',      '55331.1',      '340485.1',      '57704.1',      '4759.1',      '10825.1',      '3991.1',      '9388.1',      '13.1',
      '747.1',      '221955.1',      '5408.1',      '5406.1',      '57104.1',      '8513.1',      '5407.1',      '119548.1',      '2170.1',      '2169.1',
      '2173.1',      '2171.1',      '2172.1',      '2167.1',      '646486.1',      '646480.1',      '6296.1',      '348158.1',      '54988.1',      '123876.1',
      '341392.1',      '344967.1',      '51099.1',      '154141.1',      '253558.1',      '9663.1',      '64748.1',      '9890.1',      '79948.1',      '64900.1',
      '23175.1',      '84513.1',      '196051.1',      '85465.1',      '23646.1',      '122618.1',      '201164.1',      '590.1',      '55750.1',      '79603.1',
      '91012.1',      '29956.1',      '204219.1',      '253782.1',      '10715.1',      '56624.1',      '55830.1',      '55624.1',      '55757.1',      '168391.1',
      '83468.1',      '8702.1',      '140687.1',      '3703.1',      '56886.1',      '283358.1',      '8473.1',      '8707.1',      '148789.1',      '56983.1',
      '201595.1',      '124872.1',      '146664.1',      '8708.1',      '84750.1',      '2529.1',      '338707.1',      '145173.1',      '200810.1',      '2526.1',
      '170384.1',      '360203.1',      '152586.1',      '644378.1',      '84752.1',      '644974.1',      '284004.1',      '79411.1',      '27090.1',      '129807.1',
      '2524.1',      '2527.1',      '2528.1',      '113612.1',      '493869.1',      '64180.1',      '64174.1',      '10728.1',      '8644.1',      '10826.1',
      '266740.1',      '3930.1',      '4645.1',      '3069.1',      '4864.1',      '1646.1',      '8630.1',      '158160.1',      '51144.1',      '51170.1',
      '64834.1',      '83401.1',      '79993.1',      '51495.1',      '192286.1',      '9200.1',      '401494.1',      '201562.1',      '9524.1',      '253017.1',
      '3995.1',      '1155.1',      '114571.1',      '123096.1',      '57016.1',      '93650.1',      '92370.1',      '390928.1',      '8974.1',      '5033.1',
      '283208.1',      '8041.1',      '9108.1',      '29085.1',      '55613.1',      '23371.1',      '51559.1',      '9896.1',      '163404.1',      '51496.1',
      '374462.1',      '9107.1',      '8446.1',      '138639.1',      '84814.1',      '64419.1',      '23203.1',      '22876.1',      '403313.1',      '22908.1',
      '145553.1',      '9562.1',      '138429.1',      '10170.1',      '9249.1',      '220074.1',      '1735.1',      '1734.1',      '1733.1',      '27284.1',
      '6819.1',      '84274.1',      '55904.1',      '58508.1',      '9739.1',      '6839.1',      '84444.1',      '9757.1',      '7468.1',      '51111.1',
      '55870.1',      '4297.1',      '84787.1',      '83852.1',      '23067.1',      '9869.1',      '80854.1',      '54904.1',      '79723.1',      '64324.1',
      '8085.1',      '6419.1',      '79813.1',      '29072.1',      '387893.1',      '64754.1',      '10919.1',      '28972.1',      '9789.1',      '60559.1',
      '23478.1',      '90701.1',      '4249.1',      '25834.1',      '23262.1',      '9677.1',      '221223.1',      '23491.1',      '1066.1',      '123688.1',
      '85007.1',      '123264.1',      '200931.1',      '10941.1',      '79799.1',      '0',      '5446.1',      '7384.1',      '7388.1',      '4519.1',
      '29796.1',      '10975.1',      '7385.1',      '1537.1',      '7386.1',      '27089.1',      '7381.1',      '9016.1',      '7352.2',      '7352.1',
      '7351.1',      '9016.2',      '9481.1',      '1351.1',      '1347.1',      '1329.1',      '1327.1',      '341947.1',      '9167.1',      '1350.1',
      '4512.1',      '1349.1',      '1339.1',      '1345.1',      '4513.1',      '9377.1',      '125965.1',      '4514.1',      '170712.1',      '1346.1',
      '1340.1',      '84701.1',      '1337.1',      '29796.2',      '9810.1',      '56254.1',      '10054.1',      '10055.1',      '6045.1',      '6015.1',
      '23072.1',      '23077.1',      '29116.1',      '9690.1',      '54476.1',      '55148.1',      '9604.1',      '23304.1',      '55236.1',      '25897.1',
      '23327.1',      '4734.1',      '55658.1',      '56852.1',      '6596.1',      '7321.1',      '55743.1',      '23609.1',      '29089.1',      '7319.1',
      '3093.1',      '83737.1',      '51619.1',      '4850.1',      '11342.1',      '57531.1',      '10075.1',      '8315.1',      '79594.1',      '55072.1',
      '25831.1',      '51257.1',      '997.1',      '57820.1',      '54941.1',      '57534.1',      '4281.1',      '23295.1',      '10273.1',      '7329.1',
      '8925.1',      '55284.1',      '51366.1',      '79872.1',      '4899.1',      '54926.1',      '9148.1',      '27338.1',      '26001.1',      '64750.1',
      '7323.1',      '9354.1',      '867.1',      '9025.1',      '55819.1',      '7337.1',      '868.1',      '55120.1',      '57448.1',      '127544.1',
      '81847.1',      '7320.1',      '22954.1',      '5930.1',      '11059.1',      '79654.1',      '23352.1',      '8924.1',      '9040.1',      '10277.1',
      '7317.1',      '7322.1',      '84231.1',      '85363.1',      '7326.1',      '79589.1',      '23608.1',      '51444.1',      '4193.1',      '64844.1',
      '255488.1',      '580.1',      '57520.1',      '8916.1',      '91445.1',      '92979.1',      '92912.1',      '23624.1',      '64326.1',      '130507.1',
      '57574.1',      '9039.1',      '55016.1',      '10299.1',      '154214.1',      '257218.1',      '115426.1',      '90678.1',      '26091.1',      '89910.1',
      '9781.1',      '9320.1',      '81559.1',      '57630.1',      '153769.1',      '9246.1',      '84676.1',      '65264.1',      '197131.1',      '267.1',
      '118424.1',      '55585.1',      '84447.1',      '151112.1',      '284996.1',      '64320.1',      '25898.1',      '63891.1',      '285671.1',      '143279.1',
      '220972.1',      '5896.1',      '149603.1',      '55159.1',      '10477.1',      '7324.1',      '11236.1',      '344558.1',      '162333.1',      '115123.1',
      '11065.1',      '158506.1',      '63893.1',      '220441.1',      '148581.1',      '7334.1',      '7681.1',      '223082.1',      '221687.1',      '64219.1',
      '6478.1',      '10193.1',      '7318.1',      '7325.1',      '7267.1',      '441061.1',      '140739.1',      '7327.1',      '5071.1',      '7332.1',
      '84937.1',      '7328.1',      '378884.1',      '168433.1',      '6477.1',      '51592.1',      '142678.1',      '10210.1',      '54708.1',      '11060.1',
      '57154.1',      '51465.1',      '9666.1',      '9867.1',      '6048.1',      '54492.1',      '134111.1',      '7844.1',      '27246.1',      '29128.1',
      '389898.1'

********** Non-GPR association genes ----------
      'GR_10FTHF5GLUtl',      'GR_10FTHF5GLUtm',      'GR_10FTHF6GLUtl',      'GR_10FTHF6GLUtm',
      'GR_10FTHF7GLUtl',      'GR_10FTHF7GLUtm',      'GR_10FTHFtl',      'GR_10FTHFtm',
      'GR_24NPHte',      'GR_25HVITD2tin_m',      'GR_25HVITD3tin_m',      'GR_2DR1PP',
      'GR_2MCITt',      'GR_34DHOXPEGt',      'GR_35CGMPtn',      'GR_3DPHBH1',
      'GR_3DPHBH2',      'GR_3HBCOAHLm',      'GR_3MLDAt',      'GR_3MOBt2im',
      'GR_3MOPt2im',      'GR_4ABUTtm',      'GR_4HBZCOAFm',      'GR_4HBZFm',
      'GR_4MOPt2im',      'GR_4NPHSFte',      'GR_4NPHte',      'GR_5ADTSTSTERONESte',
      'GR_5ADTSTSTERONEte',      'GR_5AOPtm',      'GR_5DHFtl',      'GR_5THFtl',
      'GR_5THFtm',      'GR_6DHFtl',      'GR_6DHFtm',      'GR_6HTSTSTERONEte',
      'GR_6HTSTSTERONEtr',      'GR_6THFtl',      'GR_6THFtm',      'GR_7DHCHSTEROLtr',
      'GR_7DHFtl',      'GR_7DHFtm',      'GR_7THFtl',      'GR_7THFtm',
      'GR_AASAD3m',      'GR_ABTD',      'GR_ACACtx',      'GR_ACALDtm',
      'GR_ACCOAtn',      'GR_ACGAGBSIDEtg',      'GR_ACGAGBSIDEtl',      'GR_ACGALK',
      'GR_ACGALK2',      'GR_ACGALtlg',      'GR_ACGALtly',      'GR_ACGAMtly',
      'GR_ACGBGBSIDEtg',      'GR_ACGBGBSIDEtl',      'GR_ACHtn',      'GR_ACNACNGAL14ACGLCGALGLUSIDEte',
      'GR_ACNACNGALGBSIDEte',      'GR_ACNACNGALGBSIDEtg',      'GR_ACNAMtn',      'GR_ACNGALACGLCGAL14ACGLCGALGLUSIDEte',
      'GR_ACNGALACGLCGAL14ACGLCGALGLUSIDEtg',      'GR_ACNMLr',      'GR_ACt2m',      'GR_ACt2r',
      'GR_ACtg',      'GR_ADCim',      'GR_ADNK1m',      'GR_ADRNCOAtx',
      'GR_ADRNt',      'GR_AFLATOXINte',      'GR_AHCYStr',      'GR_AKGtp',
      'GR_AMETr',      'GR_AMPtp',      'GR_ANDRSTRNte',      'GR_ANDRSTRNtr',
      'GR_AQCOBALt',      'GR_ARAB_Lt',      'GR_ARACHCOAtx',      'GR_ARACHDCOAtx',
      'GR_ARACHDtr',      'GR_ARACHt',      'GR_R_group_phosphotase_1',      'GR_R_group_phosphotase_3',
      'GR_ARTFR208',      'GR_ARTPLM3',      'GR_ASCBOX',      'GR_ASCBt',
      'GR_ASPDxt',      'GR_ATP1ter',      'GR_ATP2ter',      'GR_ATPtn',
      'GR_ATPtx',      'GR_B3GALTg',      'GR_BALAtmr',      'GR_BHBt',
      'GR_BHBtm',      'GR_BILDGLCURtr',      'GR_BILIRUBtr',      'GR_BZt',
      'GR_BZtr',      'GR_C226COAtx',      'GR_C226CRNt',      'GR_CAROtr',
      'GR_CBL2OR',      'GR_CBPter',      'GR_CDPDAGtm',      'GR_CHOLPtg',
      'GR_CHOLPtl',      'GR_CHOLtn',      'GR_CITMCOAHm',      'GR_CITMCOALm',
      'GR_CLPNDCOAtx',      'GR_CLPNDt',      'GR_CMPACNAtn',      'GR_CO2ter',
      'GR_CO2tg',      'GR_CO2tm',      'GR_CO2tp',      'GR_COAtg',
      'GR_COAtl',      'GR_COAtn',      'GR_COAtp',      'GR_COAtr',
      'GR_COQ5m',      'GR_CORE5GTg',      'GR_CORE7GTg',      'GR_COUCOAFm',
      'GR_COUMARINte',      'GR_CRMPte',      'GR_CRNCAR3tp',      'GR_CRNtx',
      'GR_CRTSTRNt',      'GR_CRVNCtr',      'GR_CSAPASEly',      'GR_CSBPASEly',
      'GR_CSCPASEly',      'GR_CSDPASEly',      'GR_CSEPASEly',      'GR_CSPG_At',
      'GR_CSPG_Atly',      'GR_CSPG_Btly',      'GR_CSPG_Ct',      'GR_CSPG_Ctly',
      'GR_CSPG_Dt',      'GR_CSPG_Dtly',      'GR_CSPG_Et',      'GR_CSPG_Etly',
      'GR_CTPtn',      'GR_CYSGLTH',      'GR_CYTDK2m',      'GR_D_3AIBt',
      'GR_DADNK',      'GR_DAG_HSter',      'GR_DAGt',      'GR_DALAxt',
      'GR_DATPtn',      'GR_DCK1m',      'GR_DCSPTN1COAtx',      'GR_DCSPTN1t',
      'GR_DCTPtn',      'GR_DECDPtm',      'GR_DEDOLP1_L',      'GR_DEDOLP2_L',
      'GR_DEDOLR_L',      'GR_DESAT22_1p',      'GR_DESAT22_2p',      'GR_DGCHOLte',
      'GR_DGCHOLtx',      'GR_DGK2m',      'GR_DGSNtm',      'GR_DGTPtn',
      'GR_DGULND',      'GR_DHEAStr',      'GR_DHEAtr',      'GR_DHFtl',
      'GR_DHFtm',      'GR_DHPR2',      'GR_DIGALSIDEtl',      'GR_DKMPPD',
      'GR_DM_Asn_X_Ser_Thr_ly_',      'GR_DM_core5_g_',      'GR_DM_core7_g_',      'GR_DM_datp_m_',
      'GR_DM_datp_n_',      'GR_DM_dctp_m_',      'GR_DM_dctp_n_',      'GR_DM_dem2emgacpail_prot_hs_r_',
      'GR_DM_dgpi_prot_hs_r_',      'GR_DM_dgtp_m_',      'GR_DM_dgtp_n_',      'GR_DM_dttp_m_',
      'GR_DM_dttp_n_',      'GR_DM_ethamp_r_',      'GR_DM_gncore2_g_',      'GR_DM_gpi_sig_er_',
      'GR_DM_kdn_c_',      'GR_DM_mem2emgacpail_prot_hs_r_',      'GR_DM_Ser_Thr_ly_',      'GR_DM_Ser_Gly_Ala_X_Gly_ly_',
      'GR_DM_sprm_c_',      'GR_DM_T_antigen_g_',      'GR_DMHPTCRNt',      'GR_DMHPTCRNte',
      'GR_DMNONCOACRNCPT1',      'GR_DMNONCRNt',      'GR_DNADtn',      'GR_DOLMANP_Uter',
      'GR_DOLPMT4_Uer',      'GR_DOPASFt',      'GR_DPCOAtl',      'GR_DPHMBDCm',
      'GR_DPPS',      'GR_DRIBt',      'GR_DSAT',      'GR_DTDPtn',
      'GR_DTTPtn',      'GR_EAFLATOXINte',      'GR_EBASTINEOHte',      'GR_EBASTINEOHtr',
      'GR_EBASTINEte',      'GR_EBASTINEtr',      'GR_EICOSTETt',      'GR_ENGASE2ly',
      'GR_ENGASE3ly',      'GR_ESTRADIOLt',      'GR_ESTRADIOLtr',      'GR_ESTRIOLtr',
      'GR_ESTRONEtr',      'GR_EX_10fthf[e]',      'GR_EX_10fthf5glu[e]',      'GR_EX_10fthf6glu[e]',
      'GR_EX_10fthf7glu[e]',      'GR_EX_13_cis_retnglc[e]',      'GR_EX_24nph[e]',      'GR_EX_2hb[e]',
      'GR_EX_2mcit[e]',      'GR_EX_34dhoxpeg[e]',      'GR_EX_35cgmp[e]',      'GR_EX_3aib[e]',
      'GR_EX_3aib_D[e]',      'GR_EX_3mlda[e]',      'GR_EX_4nph[e]',      'GR_EX_4nphsf[e]',
      'GR_EX_5adtststerone[e]',      'GR_EX_5adtststerones[e]',      'GR_EX_5dhf[e]',      'GR_EX_5fthf[e]',
      'GR_EX_5htrp[e]',      'GR_EX_5mthf[e]',      'GR_EX_5thf[e]',      'GR_EX_6dhf[e]',
      'GR_EX_6htststerone[e]',      'GR_EX_6thf[e]',      'GR_EX_7dhf[e]',      'GR_EX_7thf[e]',
      'GR_EX_acetone[e]',      'GR_EX_ach[e]',      'GR_EX_acnacngal14acglcgalgluside_hs[e]',      'GR_EX_acnacngalgbside_hs[e]',
      'GR_EX_acngalacglcgal14acglcgalgluside_hs[e]',      'GR_EX_adp[e]',      'GR_EX_adprbp[e]',      'GR_EX_adrn[e]',
      'GR_EX_adrnl[e]',      'GR_EX_aflatoxin[e]',      'GR_EX_ala_B[e]',      'GR_EX_ala_D[e]',
      'GR_EX_amp[e]',      'GR_EX_andrstrn[e]',      'GR_EX_aprgstrn[e]',      'GR_EX_aqcobal[e]',
      'GR_EX_arach[e]',      'GR_EX_arachd[e]',      'GR_EX_ascb_L[e]',      'GR_EX_asp_D[e]',
      'GR_EX_atp[e]',      'GR_EX_avite1[e]',      'GR_EX_bhb[e]',      'GR_EX_bildglcur[e]',
      'GR_EX_bilglcur[e]',      'GR_EX_bilirub[e]',      'GR_EX_camp[e]',      'GR_EX_caro[e]',
      'GR_EX_chol[e]',      'GR_EX_cholate[e]',      'GR_EX_chsterol[e]',      'GR_EX_chtn[e]',
      'GR_EX_clpnd[e]',      'GR_EX_cmp[e]',      'GR_EX_coumarin[e]',      'GR_EX_creat[e]',
      'GR_EX_crmp_hs[e]',      'GR_EX_crn[e]',      'GR_EX_crtstrn[e]',      'GR_EX_crvnc[e]',
      'GR_EX_cspg_a[e]',      'GR_EX_cspg_b[e]',      'GR_EX_cspg_c[e]',      'GR_EX_cspg_d[e]',
      'GR_EX_cspg_e[e]',      'GR_EX_dag_hs[e]',      'GR_EX_dcsptn1[e]',      'GR_EX_dgchol[e]',
      'GR_EX_dhdascb[e]',      'GR_EX_dheas[e]',      'GR_EX_dhf[e]',      'GR_EX_dlnlcg[e]',
      'GR_EX_dmhptcrn[e]',      'GR_EX_dopa[e]',      'GR_EX_dopasf[e]',      'GR_EX_eaflatoxin[e]',
      'GR_EX_ebastine[e]',      'GR_EX_ebastineoh[e]',      'GR_EX_eicostet[e]',      'GR_EX_elaid[e]',
      'GR_EX_estradiol[e]',      'GR_EX_estrones[e]',      'GR_EX_fuc13galacglcgal14acglcgalgluside_hs[e]',      'GR_EX_fuc14galacglcgalgluside_hs[e]',
      'GR_EX_fucacgalfucgalacglcgalgluside_hs[e]',      'GR_EX_fucfuc12gal14acglcgalgluside_hs[e]',      'GR_EX_fucfucfucgalacglc13galacglcgal14acglcgalgluside_hs[e]',      'GR_EX_fucfucgalacglcgalgluside_hs[e]',
      'GR_EX_fucgal14acglcgalgluside_hs[e]',      'GR_EX_fucgalfucgalacglcgalgluside_hs[e]',      'GR_EX_fuc_L[e]',      'GR_EX_galacglcgalgbside_hs[e]',
      'GR_EX_galgalfucfucgalacglcgalacglcgal14acglcgalgluside_hs[e]',      'GR_EX_galgalgalthcrm_hs[e]',      'GR_EX_gbside_hs[e]',      'GR_EX_gchola[e]',
      'GR_EX_gdp[e]',      'GR_EX_gluala[e]',      'GR_EX_glyc_S[e]',      'GR_EX_glygn2[e]',
      'GR_EX_glygn4[e]',      'GR_EX_glygn5[e]',      'GR_EX_gmp[e]',      'GR_EX_gq1b_hs[e]',
      'GR_EX_gsn[e]',      'GR_EX_gt1a_hs[e]',      'GR_EX_gthox[e]',      'GR_EX_gthrd[e]',
      'GR_EX_gtp[e]',      'GR_EX_h2o2[e]',      'GR_EX_ha[e]',      'GR_EX_ha_pre1[e]',
      'GR_EX_hco3[e]',      'GR_EX_hcoumarin[e]',      'GR_EX_hdca[e]',      'GR_EX_hdcea[e]',
      'GR_EX_hestratriol[e]',      'GR_EX_hexc[e]',      'GR_EX_hista[e]',      'GR_EX_hom_L[e]',
      'GR_EX_hpdca[e]',      'GR_EX_hspg[e]',      'GR_EX_htaxol[e]',      'GR_EX_i[e]',
      'GR_EX_idp[e]',      'GR_EX_imp[e]',      'GR_EX_ksi[e]',      'GR_EX_ksi_deg1[e]',
      'GR_EX_ksii_core2[e]',      'GR_EX_ksii_core4[e]',      'GR_EX_lac_D[e]',      'GR_EX_Lcystin[e]',
      'GR_EX_leuktrA4[e]',      'GR_EX_leuktrB4[e]',      'GR_EX_leuktrC4[e]',      'GR_EX_leuktrD4[e]',
      'GR_EX_leuktrE4[e]',      'GR_EX_leuktrF4[e]',      'GR_EX_lgnc[e]',      'GR_EX_lneldc[e]',
      'GR_EX_lnlc[e]',      'GR_EX_lnlnca[e]',      'GR_EX_lnlncg[e]',      'GR_EX_lpchol_hs[e]',
      'GR_EX_mag_hs[e]',      'GR_EX_meoh[e]',      'GR_EX_mthgxl[e]',      'GR_EX_n2m2nmasn[e]',
      'GR_EX_nad[e]',      'GR_EX_nadp[e]',      'GR_EX_ncam[e]',      'GR_EX_no[e]',
      'GR_EX_nrpphr[e]',      'GR_EX_nrpphrsf[e]',      'GR_EX_nrvnc[e]',      'GR_EX_o2s[e]',
      'GR_EX_oagd3_hs[e]',      'GR_EX_oagt3_hs[e]',      'GR_EX_ocdca[e]',      'GR_EX_ocdcea[e]',
      'GR_EX_octa[e]',      'GR_EX_oxa[e]',      'GR_EX_pchol_hs[e]',      'GR_EX_pe_hs[e]',
      'GR_EX_peplys[e]',      'GR_EX_pglyc_hs[e]',      'GR_EX_phyt[e]',      'GR_EX_prgstrn[e]',
      'GR_EX_prostgd2[e]',      'GR_EX_prostge1[e]',      'GR_EX_prostge2[e]',      'GR_EX_ps_hs[e]',
      'GR_EX_ptdca[e]',      'GR_EX_retfa[e]',      'GR_EX_retinol[e]',      'GR_EX_retn[e]',
      'GR_EX_Rtotal[e]',      'GR_EX_Rtotal2[e]',      'GR_EX_Rtotal3[e]',      'GR_EX_s2l2fn2m2masn[e]',
      'GR_EX_s2l2n2m2masn[e]',      'GR_EX_spc_hs[e]',      'GR_EX_sph1p[e]',      'GR_EX_sphs1p[e]',
      'GR_EX_srtn[e]',      'GR_EX_strch1[e]',      'GR_EX_strch2[e]',      'GR_EX_strdnc[e]',
      'GR_EX_tagat_D[e]',      'GR_EX_taxol[e]',      'GR_EX_tchola[e]',      'GR_EX_tdchola[e]',
      'GR_EX_tethex3[e]',      'GR_EX_tetpent3[e]',      'GR_EX_tetpent6[e]',      'GR_EX_tettet6[e]',
      'GR_EX_thf[e]',      'GR_EX_thmtp[e]',      'GR_EX_thym[e]',      'GR_EX_thyox_L[e]',
      'GR_EX_tmndnc[e]',      'GR_EX_triodthy[e]',      'GR_EX_triodthysuf[e]',      'GR_EX_tststerone[e]',
      'GR_EX_tststerones[e]',      'GR_EX_ttdca[e]',      'GR_EX_txa2[e]',      'GR_EX_Tyr_ggn[e]',
      'GR_EX_udp[e]',      'GR_EX_ump[e]',      'GR_EX_urate[e]',      'GR_EX_utp[e]',
      'GR_EX_vacc[e]',      'GR_EX_vitd3[e]',      'GR_EX_whhdca[e]',      'GR_EX_whtststerone[e]',
      'GR_EX_xolest_hs[e]',      'GR_EX_xolest2_hs[e]',      'GR_EX_xoltri24[e]',      'GR_EX_xoltri27[e]',
      'GR_EX_xylt[e]',      'GR_F1Atg',      'GR_FADH2tru',      'GR_FADH2tx',
      'GR_FADtru',      'GR_FADtx',      'GR_FALDtly',      'GR_FCOAH',
      'GR_FE2t',      'GR_FE2tm',      'GR_FORMCOAtx',      'GR_FORt2m',
      'GR_FORtr',      'GR_FRDPtr',      'GR_FUC13GALACGLCGAL14ACGLCGALGLUSIDEte',      'GR_FUC13GALACGLCGAL14ACGLCGALGLUSIDEtg',
      'GR_FUC14GALACGLCGALGLUSIDEte',      'GR_FUC14GALACGLCGALGLUSIDEtg',      'GR_FUCACGALFUCGALACGLCGALGLUSIDEte',      'GR_FUCFUC12GAL14ACGLCGALGLUSIDEte',
      'GR_FUCFUC12GAL14ACGLCGALGLUSIDEtg',      'GR_FUCFUCFUCGALACGLC13GALACGLCGAL14ACGLCGALGLUSIDEte',      'GR_FUCFUCFUCGALACGLC13GALACGLCGAL14ACGLCGALGLUSIDEtg',      'GR_FUCFUCGALACGLCGALGLUSIDEte',
      'GR_FUCFUCGALACGLCGALGLUSIDEtg',      'GR_FUCGAL14ACGLCGALGLUSIDEte',      'GR_FUCGAL14ACGLCGALGLUSIDEtg',      'GR_FUCGALFUCGALACGLCGALGLUSIDEte',
      'GR_FUCtly',      'GR_G5SADrm',      'GR_GACPAILter',      'GR_GALACGLCGALGBSIDEte',
      'GR_GALACGLCGALGBSIDEtg',      'GR_GALGALFUCFUCGALACGLCGALACGLCGAL14ACGLCGALGLUSIDEte',      'GR_GALGALFUCFUCGALACGLCGALACGLCGAL14ACGLCGALGLUSIDEtg',      'GR_GALGALGALTHCRMte',
      'GR_GALGALGALTHCRMtg',      'GR_GALGLUSIDEtg',      'GR_GALSIDEtl',      'GR_GALtly',
      'GR_GBSIDEte',      'GR_GBSIDEtl',      'GR_GCHOLAte',      'GR_GDPtg',
      'GR_GGT_L',      'GR_GGT6',      'GR_GLACter',      'GR_GLCMter',
      'GR_GLCter',      'GR_GLCtly',      'GR_GLCURter',      'GR_GLNtm',
      'GR_GLUt7l',      'GR_GLXtm',      'GR_GLXtp',      'GR_GLYC3Ptm',
      'GR_GLYCK2',      'GR_GLYCLTDym',      'GR_GLYCLTtp',      'GR_GLYC_St',
      'GR_GLYCtm',      'GR_GLYtm',      'GR_GLYtp',      'GR_GMPtg',
      'GR_GMPtn',      'GR_GQ1Bte',      'GR_GT1Ate',      'GR_GTHDH',
      'GR_GTHRDtr',      'GR_GULN3D',      'GR_GULNDer',      'GR_GULNter',
      'GR_H2O2t',      'GR_H2O2tly',      'GR_H2O2tm',      'GR_H2O2tp',
      'GR_H2Oter',      'GR_H2Otg',      'GR_H2Otly',      'GR_H2Otn',
      'GR_H2Otp',      'GR_HAtly',      'GR_HCOUMARINte',      'GR_HDCAter',
      'GR_HDD2COAtx',      'GR_HESTRATRIOLte',      'GR_HESTRATRIOLtr',      'GR_HEXCCOAtx',
      'GR_HEXCt',      'GR_HMGCOAtm',      'GR_HMGCOAtx',      'GR_HPDCAt',
      'GR_HPYRDC',      'GR_HPYRDCm',      'GR_HPYRtp',      'GR_HSAT1ly',
      'GR_HSAT2ly',      'GR_HSAT3ly',      'GR_HSAT4ly',      'GR_HSPASEly',
      'GR_HSPGt',      'GR_HSPGtly',      'GR_HTAXOLte',      'GR_Htg',
      'GR_Htr',      'GR_Htx',      'GR_ILEt5m',      'GR_IPDPtx',
      'GR_KDNH',      'GR_KSII_CORE2t',      'GR_KSII_CORE2tly',      'GR_KSII_CORE4t',
      'GR_KSII_CORE4tly',      'GR_KSItly',      'GR_KYNATESYN',      'GR_LEUKTRB4tr',
      'GR_LEUKTRD4t',      'GR_LEUt5m',      'GR_LGNCCOAtx',      'GR_LINKDEG1ly',
      'GR_LINKDEG2ly',      'GR_LINKDEG3ly',      'GR_LINKDEG4ly',      'GR_LNELDCt',
      'GR_LPCHOLt',      'GR_LTC4CP',      'GR_LTD4DP',      'GR_MAGt',
      'GR_MANtly',      'GR_MCITS',      'GR_MDRPD',      'GR_MEOHt2',
      'GR_MEOHtly',      'GR_MGSA',      'GR_MGSA2',      'GR_MI134P4P',
      'GR_MI13PP',      'GR_MI14P4P',      'GR_MINOHPtn',      'GR_MTHGXLt',
      'GR_N2M2NMASNtly',      'GR_N4Tg',      'GR_NADHtpu',      'GR_NADHtru',
      'GR_NADPHtru',      'GR_NADPHtxu',      'GR_NADPtru',      'GR_NADPtxu',
      'GR_NADtn',      'GR_NADtru',      'GR_NAGAlby',      'GR_NAGLCAly',
      'GR_NCAMUP',      'GR_NH4tn',      'GR_NH4tp',      'GR_NICRNS',
      'GR_NICRNTtn',      'GR_NMNtn',      'GR_NOt',      'GR_NRPPHRSFt',
      'GR_NRVNCCOAtx',      'GR_O2St',      'GR_O2Stm',      'GR_O2ter',
      'GR_O2tm',      'GR_O2tn',      'GR_O2tp',      'GR_OAGD3te',
      'GR_OAGD3tg',      'GR_OAGT3te',      'GR_OCCOAtm',      'GR_OCCOAtx',
      'GR_OCTAt',      'GR_ODECOAtx',      'GR_OXAtp',      'GR_P450LTB4r',
      'GR_PAFS',      'GR_PAIL_HStn',      'GR_PAIL45P_HStn',      'GR_PAIL4P_HStn',
      'GR_PAN4PP',      'GR_PAPtg',      'GR_PCHOL_HSter',      'GR_PCHOL_HStg',
      'GR_PE_HSter',      'GR_PEt',      'GR_PGLYCt',      'GR_PHEMEtm',
      'GR_PHYTt',      'GR_PI45P4P',      'GR_PI4P5Kn',      'GR_PI4PP',
      'GR_PI5P4Kn',      'GR_PIK3n',      'GR_PIK4n',      'GR_PIK5n',
      'GR_PItg',      'GR_PItn',      'GR_PMTCOAtx',      'GR_PPAn',
      'GR_PPAt',      'GR_PPAtm',      'GR_PPItr',      'GR_PPItx',
      'GR_PPMI12346Ptn',      'GR_PPPG9tm',      'GR_PRGSTRNt',      'GR_PRISTANALtx',
      'GR_PRISTCOAtx',      'GR_PRISTtx',      'GR_PROSTGH2t',      'GR_PROSTGI2t',
      'GR_PROtm',      'GR_PSt3',      'GR_PTDCAt',      'GR_QUILSYN',
      'GR_RADH',      'GR_RADH2',      'GR_RAI1',      'GR_RAI2',
      'GR_RAtn',      'GR_RETHe',      'GR_RETI1',      'GR_RETI2',
      'GR_RETI3',      'GR_RETNGLCt2',      'GR_RETNGLCt2r',      'GR_RETNt',
      'GR_RETNtr2',      'GR_RIBt',      'GR_RIBt2',      'GR_RTOTAL2t',
      'GR_RTOTALt',      'GR_Rtotaltl',      'GR_S2L2FN2M2MASNtly',      'GR_S2L2N2M2MASNtly',
      'GR_S2TASE4ly',      'GR_S2TASE5ly',      'GR_S3TASE1ly',      'GR_S3TASE2ly',
      'GR_S3TASE3ly',      'GR_S4T4g',      'GR_S4T5g',      'GR_Ser_Thrtg',
      'GR_SERtp',      'GR_sink_citr[c]',      'GR_sink_pre_prot[r]',      'GR_SO4tl',
      'GR_SPC_HSt',      'GR_SPH1Pte',      'GR_SPHINGStl',      'GR_SPHMYLNtg',
      'GR_SPHMYLNtl',      'GR_SPHS1Pte',      'GR_SPMDOX',      'GR_STCOAtx',
      'GR_STRDNCt',      'GR_SUCCtp',      'GR_T4HCINNMFM',      'GR_TAGAT_Dt',
      'GR_TAXOLte',      'GR_TCHOLAte',      'GR_TDCHOLAte',      'GR_TETHEX3COAtx',
      'GR_TETHEX3t',      'GR_TETPENT3COAtx',      'GR_TETPENT3t',      'GR_TETPENT6COAtx',
      'GR_TETPENT6t',      'GR_TETTET6COAtx',      'GR_TETTET6t',      'GR_THCHOLSTOICtm',
      'GR_THFtl',      'GR_THFtm',      'GR_TMNDNCCOAtx',      'GR_TMNDNCt',
      'GR_TRIODTHYSUFt',      'GR_TRIOK',      'GR_TSTSTERONESte',      'GR_TSTSTERONEt',
      'GR_TSTSTERONEtr',      'GR_TXA2te',      'GR_TXA2tr',      'GR_UAGALDP',
      'GR_UDPACGALtl',      'GR_UDPGLCAtg',      'GR_UDPtl',      'GR_UDPXYLter',
      'GR_UMPtr',      'GR_URATEt',      'GR_UROLACer',      'GR_UTPtn',
      'GR_VACCt',      'GR_VALt5m',      'GR_VITD3t',      'GR_WHHDCAte',
      'GR_WHTSTSTERONEte',      'GR_XOL27OHtm',      'GR_XOL7AONEtr',      'GR_XOLEST2te',
      'GR_XOLESTte',      'GR_XOLTRI24te',      'GR_XOLTRI27tc',      'GR_XOLTRI27te',
      'GR_XSERtg',      'GR_XYLTD_Dr',      'GR_XYLtly',      'GR_XYLTt',
      'GR_EX_4abutn[e]',      'GR_EX_acmana[e]',      'GR_EX_ahdt[e]',      'GR_EX_ctp[e]',
      'GR_EX_dgmp[e]',      'GR_EX_dgtp[e]',      'GR_EX_dha[e]',      'GR_EX_dhap[e]',
      'GR_EX_dtmp[e]',      'GR_EX_dttp[e]',      'GR_EX_fald[e]',      'GR_EX_HC01104[e]',
      'GR_EX_HC01361[e]',      'GR_EX_HC01440[e]',      'GR_EX_HC01441[e]',      'GR_EX_HC01444[e]',
      'GR_EX_HC01446[e]',      'GR_EX_HC01577[e]',      'GR_EX_HC01700[e]',      'GR_EX_HC02160[e]',
      'GR_EX_HC02161[e]',      'GR_EX_itp[e]',      'GR_EX_orot[e]',      'GR_EX_prpp[e]',
      'GR_r0002',      'GR_r0156',      'GR_r0179',      'GR_r0236',
      'GR_r0330',      'GR_r0365',      'GR_r0480',      'GR_r0527',
      'GR_r0647',      'GR_r0784',      'GR_r0788',      'GR_r0789',
      'GR_r0809',      'GR_r0818',      'GR_r0838',      'GR_r0839',
      'GR_r0841',      'GR_r0853',      'GR_r0859',      'GR_r0886',
      'GR_r0892',      'GR_r0899',      'GR_r0926',      'GR_r0927',
      'GR_r0936',      'GR_r0937',      'GR_r0944',      'GR_r0950',
      'GR_r0962',      'GR_r0968',      'GR_r0970',      'GR_r0973',
      'GR_r0974',      'GR_r0986',      'GR_r0987',      'GR_r0989',
      'GR_r0990',      'GR_r0994',      'GR_r1000',      'GR_r1003',
      'GR_r1011',      'GR_r1012',      'GR_r1013',      'GR_r1014',
      'GR_r1018',      'GR_r1019',      'GR_r1030',      'GR_r1050',
      'GR_r1088',      'GR_r1106',      'GR_r1109',      'GR_r1116',
      'GR_r1117',      'GR_r1134',      'GR_r1146',      'GR_r1148',
      'GR_r1150',      'GR_r1159',      'GR_r1291',      'GR_r1292',
      'GR_r1298',      'GR_r1299',      'GR_r1301',      'GR_r1302',
      'GR_r1303',      'GR_r1304',      'GR_r1318',      'GR_r1364',
      'GR_r1365',      'GR_r1367',      'GR_r1368',      'GR_r1377',
      'GR_r1384',      'GR_r1400',      'GR_r1421',      'GR_r1423',
      'GR_r1435',      'GR_r1436',      'GR_r1437',      'GR_r1459',
      'GR_r1467',      'GR_r1468',      'GR_r1493',      'GR_r1512',
      'GR_r2508',      'GR_r2509',      'GR_r2510',      'GR_r2511',
      'GR_r2514',      'GR_r2519',      'GR_r2521',      'GR_r2537',
      'GR_r2538',      'GR_r2539',      'GR_EX_so3[e]',      'GR_EX_sprm[e]',
      'GR_RE0124C',      'GR_RE0452M',      'GR_RE0453C',      'GR_RE0570C',
      'GR_RE0571C',      'GR_RE0574C',      'GR_RE0575C',      'GR_RE0576C',
      'GR_RE0581C',      'GR_RE0583C',      'GR_RE0691C',      'GR_RE0830C',
      'GR_RE0908C',      'GR_RE0915C',      'GR_RE0916C',      'GR_RE0918C',
      'GR_RE0958C',      'GR_RE1234C',      'GR_RE1303C',      'GR_RE1342C',
      'GR_RE1447N',      'GR_RE1448N',      'GR_RE1530C',      'GR_RE1711C',
      'GR_RE1804C',      'GR_RE1807C',      'GR_RE1826C',      'GR_RE1836C',
      'GR_RE1897C',      'GR_RE1898C',      'GR_RE1915C',      'GR_RE1916C',
      'GR_RE1919C',      'GR_RE1921C',      'GR_RE1978C',      'GR_RE2069C',
      'GR_RE2080C',      'GR_RE2112C',      'GR_RE2235C',      'GR_RE2327C',
      'GR_RE2407C',      'GR_RE2410C',      'GR_RE2426C',      'GR_RE2526C',
      'GR_RE2562C',      'GR_RE2563C',      'GR_RE2625C',      'GR_RE2626C',
      'GR_RE2655R',      'GR_RE2659R',      'GR_RE2666C',      'GR_RE2677C',
      'GR_RE2677N',      'GR_RE2799C',      'GR_RE2814R',      'GR_RE2974N',
      'GR_RE3011R',      'GR_RE3016R',      'GR_RE3017R',      'GR_RE3033C',
      'GR_RE3044C',      'GR_RE3050R',      'GR_RE3052C',      'GR_RE3073X',
      'GR_RE3104C',      'GR_RE3106C',      'GR_RE3112C',      'GR_RE3113C',
      'GR_RE3119C',      'GR_RE3121C',      'GR_RE3122C',      'GR_RE3152C',
      'GR_RE3153C',      'GR_RE3154C',      'GR_RE3162C',      'GR_RE3163C',
      'GR_RE3164C',      'GR_RE3166C',      'GR_RE3167C',      'GR_RE3168C',
      'GR_RE3169C',      'GR_RE3171C',      'GR_RE3172C',      'GR_RE3173C',
      'GR_RE3175C',      'GR_RE3176C',      'GR_RE3180C',      'GR_RE3181C',
      'GR_RE3227C',      'GR_RE3228C',      'GR_RE3229C',      'GR_RE3230C',
      'GR_RE3231C',      'GR_RE3232C',      'GR_RE3234C',      'GR_RE3235C',
      'GR_RE3236C',      'GR_RE3237C',      'GR_RE3238C',      'GR_RE3239C',
      'GR_RE3242C',      'GR_RE3243C',      'GR_RE3244C',      'GR_RE3245C',
      'GR_RE3267E',      'GR_RE3270C',      'GR_RE3272N',      'GR_RE3286C',
      'GR_RE3288C',      'GR_RE3347C',      'GR_RE3352C',      'GR_RE3422C',
      'GR_RE3430M',      'GR_RE3430X',      'GR_RE3434C',      'GR_RE3435C',
      'GR_RE3436C',      'GR_RE3437C',      'GR_RE3475C',      'GR_RE3485C',
      'GR_RE3493C',      'GR_RE3496C',      'GR_RE3513C',      'GR_RE3513R',
      'GR_RE3525M',      'GR_RE3526M',      'GR_RE3556C',      'GR_RE3565C',
      'GR_RE3566C',      'GR_RE3567C',      'GR_RE3568C',      'GR_RE3570C',
      'GR_RE3587C',      'GR_RE3637C',      'GR_EX_prostgh2[e]',      'GR_EX_prostgi2[e]',
      'GR_EX_cdp[e]',      'GR_EX_dtdp[e]',      'GR_EX_HC00955[e]',      'GR_EX_citr_L[e]',
      'GR_EX_C02470[e]',      'GR_EX_C02528[e]',      'GR_EX_HC02195[e]',      'GR_EX_HC02196[e]',
      'GR_EX_HC02220[e]',      'GR_EX_HC02191[e]',      'GR_EX_HC02194[e]',      'GR_EX_HC02197[e]',
      'GR_EX_HC02198[e]',      'GR_EX_HC02187[e]',      'GR_EX_HC02180[e]',      'GR_EX_HC02202[e]',
      'GR_EX_HC02203[e]',      'GR_EX_HC02204[e]',      'GR_EX_HC02205[e]',      'GR_EX_HC02206[e]',
      'GR_EX_HC02207[e]',      'GR_EX_HC02213[e]',      'GR_EX_HC02217[e]',      'GR_EX_maltpt[e]',
      'GR_EX_CE2915[e]',      'GR_EX_CE4722[e]',      'GR_EX_CE2916[e]',      'GR_EX_CE4723[e]',
      'GR_EX_CE2917[e]',      'GR_EX_CE4724[e]',      'GR_EX_malthp[e]',      'GR_EX_CE2839[e]',
      'GR_EX_CE2838[e]',      'GR_EX_CE1950[e]',      'GR_EX_cynt[e]',      'GR_EX_CE5786[e]',
      'GR_EX_CE5788[e]',      'GR_EX_CE5789[e]',      'GR_EX_CE5797[e]',      'GR_EX_CE5798[e]',
      'GR_EX_CE5867[e]',      'GR_EX_CE5868[e]',      'GR_EX_CE5869[e]',      'GR_EX_CE4633[e]',
      'GR_EX_CE4881[e]',      'GR_EX_crm_hs[e]',      'GR_EX_CE0074[e]',      'GR_EX_cdpea[e]',
      'GR_EX_12dgr120[e]',      'GR_biomass_reaction',      'GR_ADPACDAc',      'GR_ADPACtx',
      'GR_BCRNe',      'GR_sink_c101coa[c]',      'GR_C101CRNe',      'GR_C10CRNe',
      'GR_C12DCACT',      'GR_C12DCe',      'GR_C16DCe',      'GR_C3DCe',
      'GR_C4CRNe',      'GR_C4DCe',      'GR_C6CRNe',      'GR_sink_c81coa[c]',
      'GR_C81CRNe',      'GR_C8CRNe',      'GR_C8DCe',      'GR_sink_dd2coa[c]',
      'GR_DDCRNe',      'GR_DDECCRNe',      'GR_DDECE1CRNe',      'GR_DECCRNe',
      'GR_sink_decdicoa[c]',      'GR_DECDICRNe',      'GR_DOCOSACTDe',      'GR_DOCOSACTDr',
      'GR_EX_3bcrn[e]',      'GR_EX_3ddcrn[e]',      'GR_EX_3deccrn[e]',      'GR_EX_3octdec2crn[e]',
      'GR_EX_3octdece1crn[e]',      'GR_EX_3tdcrn[e]',      'GR_EX_c101crn[e]',      'GR_EX_c10crn[e]',
      'GR_EX_c12dc[e]',      'GR_EX_c16dc[e]',      'GR_EX_c3dc[e]',      'GR_EX_c4crn[e]',
      'GR_EX_c4dc[e]',      'GR_EX_c51crn[e]',      'GR_EX_c6crn[e]',      'GR_EX_c81crn[e]',
      'GR_EX_c8crn[e]',      'GR_EX_c8dc[e]',      'GR_EX_ddece1crn[e]',      'GR_EX_ddecrn[e]',
      'GR_EX_decdicrn[e]',      'GR_EX_doco13ac[e]',      'GR_EX_docosac[e]',      'GR_EX_tetdec2crn[e]',
      'GR_EX_tetdece1crn[e]',      'GR_EX_dca[e]',      'GR_FAOXC5C5OHm',      'GR_HEXDIACtr',
      'GR_HOCTDEC2CRNe',      'GR_HTDCRNe',      'GR_OCTDECE1CRNe',      'GR_sink_octdececoa[c]',
      'GR_SEBACACT',      'GR_SEBACIDtx',      'GR_SUBEACtx',      'GR_SUBERICACT',
      'GR_SUCCACT',      'GR_TDCRNe',      'GR_sink_tetdec2coa[c]',      'GR_TETDEC2CRNe',
      'GR_sink_tetdece1coa[c]',      'GR_TETDECE1CRNe',      'GR_TIGCRNe',      'GR_BTNTe',
      'GR_SBTle',      'GR_1a25DHVITD3TRn',      'GR_3AIB_Dtm',      'GR_5MTHFt2le',
      'GR_ADNK4',      'GR_AHCYStd',      'GR_ALA-DTDe',      'GR_AMETtd',
      'GR_ARACHFATPc',      'GR_ASPDTDe',      'GR_ASPte',      'GR_CHSTEROLtrc',
      'GR_CRNrtx',      'GR_Coqe',      'GR_DATPtm',      'GR_DCTPtm',
      'GR_DGTPtm',      'GR_DHAPtc',      'GR_DM_1a25dhvitd3[n]',      'GR_DM_taur[c]',
      'GR_DM_pmtcoa[r]',      'GR_DTTPtm',      'GR_EX_4hpro[e]',      'GR_EX_carn[e]',
      'GR_EX_dchac[e]',      'GR_EX_sfcys[e]',      'GR_EX_cysam[e]',      'GR_EX_fmn[e]',
      'GR_EX_oh1[e]',      'GR_EX_ptth[e]',      'GR_EX_q10[e]',      'GR_EX_q10h2[e]',
      'GR_FOLt2le',      'GR_FRDPtcr',      'GR_GLU5SAtmc',      'GR_GLYC3PFADm',
      'GR_GLYCTDle',      'GR_INSK',      'GR_KHte',      'GR_LACLt',
      'GR_MAL_Ltx',      'GR_MDHx',      'GR_NADtm',      'GR_NADtx',
      'GR_PNTEHe',      'GR_PPItm',      'GR_PRO_Dtde',      'GR_PTCRTD',
      'GR_Q10H2e',      'GR_SFCYSc',      'GR_SFCYSe',      'GR_sink_5hpet[c]',
      'GR_TAURCHAe',      'GR_TTDCAFATPc',      'GR_q10h2tc',      'GR_q10tm',
      'GR_34HPPte',      'GR_3MOBte',      'GR_3MOPte',      'GR_4MOPte',
      'GR_5MTAte',      'GR_AHCYSte',      'GR_AICARte',      'GR_CBASPte',
      'GR_DM_4hrpo',      'GR_DM_Lcystin',      'GR_DM_fol',      'GR_DM_pnto_R',
      'GR_EX_34hpp[e]',      'GR_EX_3mob[e]',      'GR_EX_3mop[e]',      'GR_EX_4mop[e]',
      'GR_EX_5mta[e]',      'GR_EX_ahcys[e]',      'GR_EX_aicar[e]',      'GR_EX_cbasp[e]',
      'GR_MAL_Lte',      'GR_IDOURte',      'GR_EX_idour[e]',      'GR_GLYALDtr',
      'GR_PEPtr',      'GR_GUDACtr',      'GR_GUDACtr2',      'GR_KYNATEtr2',
      'GR_3ANTHRNtr',      'GR_2PGtr',      'GR_CARNtr',      'GR_CHOLPtr',
      'GR_DCMPtr',      'GR_DHAPtr',      'GR_ETHAMPtr',      'GR_FUMtr',
      'GR_GLCURtr',      'GR_ICITtr',      'GR_L2AADPtr',      'GR_XANtr',
      'GR_XMPtr',      'GR_XTSNtr',      'GR_3PGtr',      'GR_UDPGLCURtr',
      'GR_IMPtr',      'GR_GLYC3tr',      'GR_NICRNtr',      'GR_OROT5Ptr',
      'GR_EX_2pg[e]',      'GR_EX_5hoxindoa[e]',      'GR_EX_cholp[e]',      'GR_EX_dcmp[e]',
      'GR_EX_ethamp[e]',      'GR_EX_glyald[e]',      'GR_EX_gudac[e]',      'GR_EX_hcys_L[e]',
      'GR_EX_icit[e]',      'GR_EX_kynate[e]',      'GR_EX_L2aadp[e]',      'GR_EX_Lkynr[e]',
      'GR_EX_pep[e]',      'GR_EX_xmp[e]',      'GR_EX_xtsn[e]',      'GR_EX_3pg[e]',
      'GR_EX_3hanthrn[e]',      'GR_EX_udpglcur[e]',      'GR_EX_nicrnt[e]',      'GR_EX_orot5p[e]',
      'GR_EX_glyc3p[e]',      'GR_ARGSUCte',      'GR_EX_argsuc[e]',      'GR_EX_acrn[e]',
      'GR_EX_pcrn[e]',      'GR_EX_lneldccrn[e]',      'GR_EX_odecrn[e]',      'GR_EX_stcrn[e]',
      'GR_EX_pmtcrn[e]',      'GR_EX_hdcecrn[e]',      'GR_DM_ascb_L[c]',      'GR_biomass_maintenance_noTrTr',
      'GR_ADPOHc',      'GR_PHLAC',      'GR_3MHISc',      'GR_HMCRNc',
      'GR_CE4843HYDc',      'GR_HXCOAc',      'GR_HDCAc',      'GR_ELAIDCRNte',
      'GR_LNLCCRNNAt',      'GR_PHLACHt',      'GR_TTDCRNNAt',      'GR_15HPETATP',
      'GR_15KPROSTGF2t',      'GR_2OXOADPt',      'GR_34HPLte',      'GR_3HMPtd',
      'GR_3HPPt',      'GR_3MHISt1',      'GR_3MHISt2',      'GR_3MHISt3',
      'GR_3MOXTYRt',      'GR_3UIBtd',      'GR_4TMEABUTNt1',      'GR_4TMEABUTNt2',
      'GR_56DTHMt',      'GR_56DTHMtd',      'GR_56DURAt',      'GR_56DURAtd',
      'GR_5AOPt',      'GR_7DHCHSTEROLtd',      'GR_ACGLUtd',      'GR_ACLYSt',
      'GR_ACLYStm',      'GR_ADPACtd',      'GR_ADPOHt',      'GR_ALLTNt',
      'GR_C02712tm',      'GR_C03990tr',      'GR_C04483t2',      'GR_C04717td',
      'GR_C04805td',      'GR_C05463t2',      'GR_C05953t',      'GR_C05957t',
      'GR_C05957td',      'GR_C06314t',      'GR_C06315t',      'GR_C06439t',
      'GR_C11695td',      'GR_C14768td',      'GR_C14769td1',      'GR_EX_C14769[e]',
      'GR_C14770ATP',      'GR_C14771ATP',      'GR_C14825td',      'GR_C14826td',
      'GR_CE1273t2',      'GR_CE2510t',      'GR_CE2513td',      'GR_CE2537ATP',
      'GR_CE4843td',      'GR_CE5304t',      'GR_CE6247t',      'GR_DODECANACtd',
      'GR_ELAIDCRNtd',      'GR_EX_12HPET[e]',      'GR_EX_15HPET[e]',      'GR_EX_15kprostgf2[e]',
      'GR_EX_2oxoadp[e]',      'GR_EX_34hpl[e]',      'GR_EX_3hmp[e]',      'GR_EX_3hpp[e]',
      'GR_EX_3mhis[e]',      'GR_EX_3uib[e]',      'GR_EX_4tmeabutn[e]',      'GR_EX_56dthm[e]',
      'GR_EX_56dura[e]',      'GR_EX_7dhchsterol[e]',      'GR_EX_aclys[e]',      'GR_EX_adpac[e]',
      'GR_EX_adpoh[e]',      'GR_EX_amet[e]',      'GR_EX_aracheth[e]',      'GR_EX_C04717[e]',
      'GR_EX_C04805[e]',      'GR_EX_C05957[e]',      'GR_EX_C06314[e]',      'GR_EX_C06315[e]',
      'GR_EX_C11695[e]',      'GR_EX_C14768[e]',      'GR_EX_C14770[e]',      'GR_EX_C14771[e]',
      'GR_EX_C14825[e]',      'GR_EX_C14826[e]',      'GR_EX_CE2537[e]',      'GR_EX_CE4843[e]',
      'GR_EX_CE5304[e]',      'GR_EX_CE6247[e]',      'GR_EX_CE7172[e]',      'GR_EX_didecaeth[e]',
      'GR_EX_diholineth[e]',      'GR_EX_docohxeth[e]',      'GR_EX_docteteth[e]',      'GR_EX_dodecanac[e]',
      'GR_EX_elaidcrn[e]',      'GR_EX_forglu[e]',      'GR_EX_HC00900[e]',      'GR_EX_hepdeceth[e]',
      'GR_EX_hexdeceeth[e]',      'GR_EX_hexdiac[e]',      'GR_EX_hgentis[e]',      'GR_EX_hmcr[e]',
      'GR_EX_hxcoa[e]',      'GR_EX_leuktrB4wcooh[e]',      'GR_EX_leuktrB4woh[e]',      'GR_EX_lineth[e]',
      'GR_EX_lnlccrn[e]',      'GR_EX_lthstrl[e]',      'GR_EX_mev_R[e]',      'GR_EX_mi1p_D[e]',
      'GR_EX_nwharg[e]',      'GR_EX_oleth[e]',      'GR_EX_pailar_hs[e]',      'GR_EX_pailpalm_hs[e]',
      'GR_EX_pchol2linl_hs[e]',      'GR_EX_pchol2ole_hs[e]',      'GR_EX_pchol2palm_hs[e]',      'GR_EX_pchol2ste_hs[e]',
      'GR_EX_pcholar_hs[e]',      'GR_EX_pcholdoc_hs[e]',      'GR_EX_pcholeic_hs[e]',      'GR_EX_pcholet_hs[e]',
      'GR_EX_pcholhep_hs[e]',      'GR_EX_pchollinl_hs[e]',      'GR_EX_pcholmyr_hs[e]',      'GR_EX_pcholn15_hs[e]',
      'GR_EX_pcholn183_hs[e]',      'GR_EX_pcholn1836_hs[e]',      'GR_EX_pcholn19_hs[e]',      'GR_EX_pcholn201_hs[e]',
      'GR_EX_pcholn203_hs[e]',      'GR_EX_pcholn204_hs[e]',      'GR_EX_pcholn205_hs[e]',      'GR_EX_pcholn224_hs[e]',
      'GR_EX_pcholn225_hs[e]',      'GR_EX_pcholn2254_hs[e]',      'GR_EX_pcholn226_hs[e]',      'GR_EX_pcholn24_hs[e]',
      'GR_EX_pcholn261_hs[e]',      'GR_EX_pcholn28_hs[e]',      'GR_EX_pcholn281_hs[e]',      'GR_EX_pcholole_hs[e]',
      'GR_EX_pcholpalm_hs[e]',      'GR_EX_pcholpalme_hs[e]',      'GR_EX_pcholste_hs[e]',      'GR_EX_pcollg5hlys[e]',
      'GR_EX_pe12_hs[e]',      'GR_EX_pe13_hs[e]',      'GR_EX_pe14_hs[e]',      'GR_EX_pe15_hs[e]',
      'GR_EX_pe161_hs[e]',      'GR_EX_pe17_hs[e]',      'GR_EX_pe203_hs[e]',      'GR_EX_pe224_hs[e]',
      'GR_EX_pe226_hs[e]',      'GR_EX_pe2linl_hs[e]',      'GR_EX_pear_hs[e]',      'GR_EX_pedh203_hs[e]',
      'GR_EX_pelinl_hs[e]',      'GR_EX_pendecaeth[e]',      'GR_EX_peole_hs[e]',      'GR_EX_pepalm_hs[e]',
      'GR_EX_peste_hs[e]',      'GR_EX_pmeth[e]',      'GR_EX_saccrp_L[e]',      'GR_EX_sebacid[e]',
      'GR_EX_sphmyln180241_hs[e]',      'GR_EX_sphmyln18114_hs[e]',      'GR_EX_sphmyln18115_hs[e]',      'GR_EX_sphmyln18116_hs[e]',
      'GR_EX_sphmyln181161_hs[e]',      'GR_EX_sphmyln18117_hs[e]',      'GR_EX_sphmyln18118_hs[e]',      'GR_EX_sphmyln181181_hs[e]',
      'GR_EX_sphmyln18120_hs[e]',      'GR_EX_sphmyln181201_hs[e]',      'GR_EX_sphmyln18121_hs[e]',      'GR_EX_sphmyln18122_hs[e]',
      'GR_EX_sphmyln181221_hs[e]',      'GR_EX_sphmyln18123_hs[e]',      'GR_EX_sphmyln1824_hs[e]',      'GR_EX_sphmyln1825_hs[e]',
      'GR_EX_steeth[e]',      'GR_EX_subeac[e]',      'GR_EX_tetdecaeth[e]',      'GR_EX_tmlys[e]',
      'GR_EX_trideceth[e]',      'GR_EX_ttdcrn[e]',      'GR_EX_urcan[e]',      'GR_EX_wharachd[e]',
      'GR_FORGLUt',      'GR_GALTt',      'GR_LYSACm',      'GR_GLYC_Rt',
      'GR_GLYCLTtd',      'GR_HC00900t1',      'GR_HC00900t2',      'GR_HC00900t3',
      'GR_HC00900t4',      'GR_HC02149td',      'GR_HEXDIACtd',      'GR_HGENTISt',
      'GR_HMCRNt',      'GR_HXCOAm',      'GR_HXCOAte',      'GR_HXCOAtx',
      'GR_HXCOAx',      'GR_IND3ACt',      'GR_LCYSTt',      'GR_LEUKTRB4WCOOHt',
      'GR_LEUKTRB4WOHt',      'GR_LEUKTRB4WOHtr',      'GR_LNLCCRNtd',      'GR_LTHSTRLt',
      'GR_MEV_Rt',      'GR_MI1Pt',      'GR_NWHARGtd',      'GR_OAAt',
      'GR_pac',      'GR_PCOLLG5HLYStd',      'GR_PROSTGI2c',      'GR_PSERtr',
      'GR_SACCRP_Lte',      'GR_SACCRP_Ltm',      'GR_SEBACIDtd',      'GR_SUBEACtd',
      'GR_TMLYStd',      'GR_TXB2c',      'GR_URCANt',      'GR_WHARACHDtr',
      'GR_EX_estriol[e]',      'GR_DDCAFATP',      'GR_EX_3moxtyr[e]',      'GR_EX_5aop[e]',
      'GR_EX_acglu[e]',      'GR_EX_alltn[e]',      'GR_EX_CE2510[e]',      'GR_EX_ddca[e]',
      'GR_EX_glyc_R[e]',      'GR_EX_glyclt[e]',      'GR_EX_Lcyst[e]',      'GR_EX_oaa[e]',
      'GR_EX_pac[e]',      'GR_EX_phlac[e]',      'GR_EX_pser_L[e]',      'GR_EX_ttdcea[e]',
      'GR_TTDCEAt',      'GR_DCHOLESTANCOAc',      'GR_XOL27OHtmc',      'GR_r0202m',
      'GR_PHEACGLYsec',      'GR_EX_pheacgly[e]',      'GR_EX_bz[e]',      'GR_NORMETEt',
      'GR_MEPIt',      'GR_TREt',      'GR_C05300t',      'GR_RETINALt',
      'GR_MALTTTRt',      'GR_1MNCAMt',      'GR_DHBPTt',      'GR_THBPTt',
      'GR_EX_normete_L[e]',      'GR_EX_mepi[e]',      'GR_EX_C05300[e]',      'GR_EX_retinal[e]',
      'GR_EX_maltttr[e]',      'GR_EX_1mncam[e]',      'GR_EX_dhbpt[e]',      'GR_EX_thbpt[e]',
      'GR_EX_adprib[e]',      'GR_EX_homoval[e]',      'GR_GLYCLTtm',      'GR_TYMc',
      'GR_PCHOL2PALM_HSte',      'GR_PE224_HSte',      'GR_PCHOLN261_HSte',      'GR_PCHOLN281_HSte',
      'GR_PCHOLN28_HSte',      'GR_ACRNtr',      'GR_HDCECRNtr',      'GR_LNELDCCRNtr',
      'GR_ODECRNtr',      'GR_PMTCRNtr',      'GR_STCRNtr',      'GR_EX_sphmyln_hs[e]',
      'GR_PHEACGLYtm',      'GR_HXAt1',      'GR_HXAt2',      'GR_HXAt3',
      'GR_EX_hxa[e]',      'GR_PACCOALm',      'GR_PACALDtm',      'GR_LHCYSTIN',
      'GR_LHCYSTINt',      'GR_EX_Lhcystin[e]',      'GR_PA_HStm',      'GR_FldAct',
      'GR_MALOAtm',      'GR_MLTHFtm',      'GR_2MOPtm',      'GR_MMALtm',
      'GR_PGPP_hsc',      'GR_CE2512te',      'GR_r2514e',      'GR_r2514m',
      'GR_FAS180',      'GR_5AOPt2',      'GR_ACNAMt2',      'GR_ADRNLtu',
      'GR_DM_pe_hs[c]',      'GR_DM_akg[c]',      'GR_DM_for[c]',      'GR_DM_mi1345p[c]',
      'GR_DM_mi134p[c]',      'GR_DM_mi145p[c]',      'GR_DM_mi14p[c]',      'GR_DM_pchol_hs[c]',
      'GR_ETHAt',      'GR_HCYSte',      'GR_OROte',      'GR_PPPGOc',
      'GR_SPRMt2r',      'GR_THMtrbc',      'GR_UGT1A10c',      'GR_UNK3r',
      'GR_ACGALtr',      'GR_ACNAMtr',      'GR_CORE4t',      'GR_S2L2N2M2Mt',
      'GR_EX_core4[e]',      'GR_EX_f1a[e]',      'GR_EX_s2l2n2m2m[e]',      'GR_EX_acgal[e]',
      'GR_EX_acnam[e]',      'GR_EX_pa_hs[e]',      'GR_DM_C02712[c]',      'GR_F1Ate',
      'GR_34HPLtm',      'GR_3HMPtm',      'GR_3HPPtm',      'GR_ACGLUtm',
      'GR_PGP_hs_tm',      'GR_PROSTGE2t2r',      'GR_ESTR2r',      'GR_LTHSTRLtr',
      'GR_PGLYCtm',      'GR_sink_25hvitd2[c]',      'GR_sink_C02528[c]',      'GR_sink_HC02191[c]',
      'GR_sink_HC02194[c]',      'GR_sink_HC02195[c]',      'GR_sink_HC02196[c]',      'GR_sink_HC02197[c]',
      'GR_sink_HC02198[c]',      'GR_sink_HC02220[c]',      'GR_sink_Tyr_ggn[c]',      'GR_sink_avite1[c]',
      'GR_sink_btn[c]',      'GR_sink_c226coa[c]',      'GR_sink_chol[c]',      'GR_sink_cholate[c]',
      'GR_sink_coa[c]',      'GR_sink_crvnc[c]',      'GR_sink_dgchol[c]',      'GR_sink_doco13ecoa[c]',
      'GR_sink_fad[c]',      'GR_sink_fe3[c]',      'GR_sink_gchola[c]',      'GR_sink_glygn2[c]',
      'GR_sink_hdca[c]',      'GR_sink_lnlc[c]',      'GR_sink_lnlccoa[c]',      'GR_sink_lnlncacoa[c]',
      'GR_sink_lnlncgcoa[c]',      'GR_sink_nad[c]',      'GR_sink_nadp[c]',      'GR_sink_odecoa[c]',
      'GR_sink_pmtcoa[c]',      'GR_sink_pydam[c]',      'GR_sink_pydx[c]',      'GR_sink_pydxn[c]',
      'GR_sink_retfa[c]',      'GR_sink_retinol[c]',      'GR_sink_stcoa[c]',      'GR_sink_tag_hs[c]',
      'GR_sink_tchola[c]',      'GR_sink_tdchola[c]',      'GR_sink_thf[c]',      'GR_sink_thmpp[c]',
      'GR_sink_thmtp[c]',      'GR_sink_tmndnc[c]',      'GR_sink_tmndnccoa[c]',      'GR_sink_vitd3[c]',
      'GR_DXTRNt',      'GR_EX_dxtrn[e]',      'GR_EX_dhcholestanate[e]',      'GR_sink_dhcholestanate[c]',
      'GR_EX_thcholstoic[e]',      'GR_sink_thcholstoic[c]',      'GR_EX_xol7ah3[e]',      'GR_sink_xol7ah3[c]',
      'GR_EX_xol7aone[e]',      'GR_sink_xol7aone[c]',      'GR_EX_xoldiolone[e]',      'GR_sink_xoldiolone[c]',
      'GR_EX_7klitchol[e]',      'GR_sink_7klitchol[c]',      'GR_sink_dchac[c]',      'GR_EX_2obut[e]',
      'GR_EX_glcn[e]',      'GR_CO2t',      'GR_DM_atp_c_',      'GR_EX_acac[e]',
      'GR_EX_adn[e]',      'GR_EX_akg[e]',      'GR_EX_asn_L[e]',      'GR_EX_asp_L[e]',
      'GR_EX_but[e]',      'GR_EX_cgly[e]',      'GR_EX_co2[e]',      'GR_EX_cytd[e]',
      'GR_EX_dad_2[e]',      'GR_EX_dcyt[e]',      'GR_EX_dgsn[e]',      'GR_EX_din[e]',
      'GR_EX_duri[e]',      'GR_EX_fe2[e]',      'GR_EX_fe3[e]',      'GR_EX_fum[e]',
      'GR_EX_gal[e]',      'GR_EX_glu_L[e]',      'GR_EX_h[e]',      'GR_EX_h2o[e]',
      'GR_EX_ile_L[e]',      'GR_EX_ins[e]',      'GR_EX_k[e]',      'GR_EX_lac_L[e]',
      'GR_EX_leu_L[e]',      'GR_EX_lys_L[e]',      'GR_EX_mal_L[e]',      'GR_EX_met_L[e]',
      'GR_EX_na1[e]',      'GR_EX_no2[e]',      'GR_EX_o2[e]',      'GR_EX_orn[e]',
      'GR_EX_pi[e]',      'GR_EX_ppi[e]',      'GR_EX_pro_L[e]',      'GR_EX_ribflv[e]',
      'GR_EX_ser_L[e]',      'GR_EX_so4[e]',      'GR_EX_succ[e]',      'GR_EX_thymd[e]',
      'GR_EX_urea[e]',      'GR_EX_uri[e]',      'GR_EX_val_L[e]',      'GR_FCLTc',
      'GR_FT',      'GR_G5SADs',      'GR_O2t',      'GR_PIt6b',
      'GR_URIDK3',      'GR_EX_pnto_R[e]',      'GR_EX_gly[e]',      'GR_EX_cys_L[e]',
      'GR_EX_ala_L[e]',      'GR_EX_his_L[e]',      'GR_EX_thr_L[e]',      'GR_EX_gln_L[e]',
      'GR_EX_phe_L[e]',      'GR_EX_tyr_L[e]',      'GR_EX_arg_L[e]',      'GR_EX_for[e]',
      'GR_EX_nac[e]',      'GR_EX_ind3ac[e]',      'GR_EX_nh4[e]',      'GR_EX_ac[e]',
      'GR_CSND',      'GR_EX_acgam[e]',      'GR_EX_cit[e]',      'GR_EX_csn[e]',
      'GR_EX_drib[e]',      'GR_EX_etha[e]',      'GR_EX_fol[e]',      'GR_EX_fru[e]',
      'GR_EX_galt[e]',      'GR_EX_glcr[e]',      'GR_EX_glcur[e]',      'GR_EX_glyc[e]',
      'GR_EX_hxan[e]',      'GR_EX_malt[e]',      'GR_EX_malthx[e]',      'GR_EX_malttr[e]',
      'GR_EX_man[e]',      'GR_EX_ptrc[e]',      'GR_EX_rib_D[e]',      'GR_EX_spmd[e]',
      'GR_EX_thm[e]',      'GR_EX_trp_L[e]',      'GR_EX_ura[e]',      'GR_EX_xan[e]',
      'GR_EX_xyl_D[e]',      'GR_NTD5_a',      'GR_OAADC',      'GR_EX_pydxn[e]',
      'GR_PYDXNtr',      'GR_EX_pydx[e]',      'GR_PYDXtr',      'GR_EX_pydam[e]',
      'GR_PYDAMtr',      'GR_EX_4hbz[e]',      'GR_EX_ppa[e]',      'GR_EX_arab_L[e]',
      'GR_EX_gam[e]',      'GR_EX_pyr[e]',      'GR_EX_tre[e]',      'GR_EX_btn[e]',
      'GR_EX_lcts[e]',      'GR_EX_ade[e]',      'GR_EX_etoh[e]',      'GR_ETOHt',
      'GR_EX_acald[e]',      'GR_ACALDt',      'GR_EX_sucr[e]',      'GR_EX_pheme[e]',
      'GR_MTRI',      'GR_EX_gua[e]',      'GR_EX_4abut[e]',      'GR_OBDHc',
      'GR_EX_phpyr[e]',      'GR_EX_lanost[e]',      'GR_3MOX4HOXMte',      'GR_EX_3mox4hoxm[e]',
      'GR_2H3MVte',      'GR_EX_2h3mv[e]',      'GR_2HIVte',      'GR_EX_2hiv[e]',
      'GR_2M3HBUc',      'GR_2M3HBUtm',      'GR_2M3HBUte',      'GR_EX_2m3hbu[e]',
      'GR_3H3MGLTc',      'GR_3H3MGLTte',      'GR_EX_3h3mglt[e]',      'GR_3MGLUTACc',
      'GR_3MGLUTACtm',      'GR_3MGLUTACte',      'GR_EX_3mglutac[e]',      'GR_PPIOGLYtm',
      'GR_PPIOGLYte',      'GR_EX_ppiogly[e]',      'GR_TIGGLYtm',      'GR_TIGGLYte',
      'GR_EX_tiggly[e]',      'GR_GLUTACOAm',      'GR_GLUTCONm',      'GR_GLUTCONtm',
      'GR_GLUTCONte',      'GR_EX_glutcon[e]',      'GR_3HIVAcm',      'GR_3HIVActm',
      'GR_3HIVActe',      'GR_EX_3hivac[e]',      'GR_3HADPACx',      'GR_3HADPACtxc',
      'GR_3HADPACte',      'GR_EX_3hadpac[e]',      'GR_3OHSEBACx',      'GR_3OHSEBACtxc',
      'GR_3OHSEBACte',      'GR_EX_3ohsebac[e]',      'GR_3OHSUBACx',      'GR_3OHSUBACtxc',
      'GR_3OHSUBACte',      'GR_EX_3ohsubac[e]',      'GR_CAPROICc',      'GR_5OHHEXAc',
      'GR_5OHHEXAte',      'GR_EX_5ohhexa[e]',      'GR_ETHMALCOAc',      'GR_ETHMALACc',
      'GR_ETHMALACte',      'GR_EX_ethmalac[e]',      'GR_HEXGLYte',      'GR_EX_hexgly[e]',
      'GR_SUBGLYte',      'GR_EX_subgly[e]',      'GR_4OHBUTm',      'GR_4OHBUTtmc',
      'GR_4OHBUTtce',      'GR_EX_4ohbut[e]',      'GR_12HPETUPKt',      'GR_15HPETUPKt',
      'GR_3AIBSYMPt',      'GR_CE7172UPKt',      'GR_PAIL_hs_SECt',      'GR_PAILPALM_HSSECt',
      'GR_PAILR_HSSECt',      'GR_SPHMYLN_HsSECt',      'GR_SPHMYLN180241_hs_SECt',      'GR_SPHMYLN18114_hs_SECt',
      'GR_SPHMYLN18115_hs_SECt',      'GR_SPHMYLN18116_hs_SECt',      'GR_SPHMYLN181161_hs_SECt',      'GR_SPHMYLN18117_hs_SECt',
      'GR_SPHMYLN18118_hs_SECt',      'GR_SPHMYLN181181_hs_SECt',      'GR_SPHMYLN18120_hs_SECt',      'GR_SPHMYLN181201_hs_SECt',
      'GR_SPHMYLN18121_hs_SECt',      'GR_SPHMYLN18122_hs_SECt',      'GR_SPHMYLN181221_hs_SECt',      'GR_SPHMYLN18123_hs_SECt',
      'GR_SPHMYLN1824_hs_SECt',      'GR_SPHMYLN1825_hs_SECt',      'GR_3AIBt1',      'GR_AK2LGCHOLt1',
      'GR_PAFt1',      'GR_PCHOL2LINL_HSt1e',      'GR_PCHOL2OLE_HSt1e',      'GR_PCHOL2STE_HSt1e',
      'GR_PCHOLAR_HSt1e',      'GR_PCHOLDOC_HSt1e',      'GR_PCHOLEIC_HSt1e',      'GR_PCHOLET_HSt1e',
      'GR_PCHOLHEP_HSt1e',      'GR_PCHOLLINL_HSt1e',      'GR_PCHOLMYR_Hst1e',      'GR_PCHOLN15_HSt1e',
      'GR_PCHOLN183_HSt1e',      'GR_PCHOLN1836_HSt1e',      'GR_PCHOLN19_HSt1e',      'GR_PCHOLN201_HSt1e',
      'GR_PCHOLN203_HSt1e',      'GR_PCHOLN204_HSt1e',      'GR_PCHOLN205_HSt1e',      'GR_PCHOLN224_HSt1e',
      'GR_PCHOLN225_HSt1e',      'GR_PCHOLN2254_HSt1e',      'GR_PCHLN225_HSt1e',      'GR_PCHOLN264_HSt1e',
      'GR_PCHOLOLE_HSt1e',      'GR_PEPALM_HSt1e',      'GR_PCHOLPALME-HSt1e',      'GR_PCHOLSTE_HSt1e',
      'GR_PE12_HSt1e',      'GR_Pe13_HSt1e',      'GR_PE14_HSt1e',      'GR_PE15_HSt1e',
      'GR_PE161_HSt1e',      'GR_PE17_HSt1e',      'GR_PE203_HSt1e',      'GR_PE226_HSt1e',
      'GR_PE2LINL_HSt1e',      'GR_PEAR_HSt1e',      'GR_PEDH203_HSt1e',      'GR_PELINL_HSt1e',
      'GR_PEOLE_HSt1e',      'GR_PELPALM_HSt1e',      'GR_PESTE_HSt1e',      'GR_EIC21114TRte',
      'GR_EX_eic21114tr[e]',      'GR_5EIPENCte',      'GR_EX_5eipenc[e]',      'GR_ISOBUTtm',
      'GR_ISOBUTte',      'GR_EX_CE4969[e]',      'GR_NACCYStm',      'GR_NACCYSte',
      'GR_EX_CE1310[e]',      'GR_AGRMtm',      'GR_EX_agm[e]',      'GR_T4HCINNMtm',
      'GR_EX_T4hcinnm[e]',      'GR_4HBZte',      'GR_SUCSALtm',      'GR_SUCSALte',
      'GR_EX_sucsal[e]',      'GR_CE7081tr',      'GR_CE7081tm',      'GR_EX_CE7081[e]',
      'GR_EGMEtr',      'GR_EGMEte',      'GR_EX_egme[e]',      'GR_SQLtr',
      'GR_SQLte',      'GR_EX_sql[e]',      'GR_ORN_Dte',      'GR_EX_orn_D[e]',
      'GR_5G2OXPTtx',      'GR_5G2OXPTte',      'GR_EX_5g2oxpt[e]',      'GR_DHEAte',
      'GR_EX_dhea[e]',      'GR_ANDRSTANDRtr',      'GR_EX_andrstandn[e]',      'GR_ESTRONEte',
      'GR_EX_estrone[e]',      'GR_HC02020tr',      'GR_HC02020te',      'GR_EX_HC02020[e]',
      'GR_XOL27OHte',      'GR_EX_xol27oh[e]',      'GR_XOL25OHtr',      'GR_XOL25OHte',
      'GR_EX_xol25oh[e]',      'GR_DSMSTEROLtr',      'GR_DSMSTEROLte',      'GR_EX_dsmsterol[e]',
      'GR_CHSTEROLSte',      'GR_EX_chsterols[e]',      'GR_3ITYR_Lte',      'GR_EX_3ityr_L[e]',
      'GR_35DIODTYRte',      'GR_EX_35diotyr[e]',      'GR_13_CIS_RETNte',      'GR_EX_13_cis_retn[e]',
      'GR_LDL_HSDEG',      'GR_EX_34dhoxmand[e]',      'GR_EX_CE7090[e]',      'GR_EX_CE7085[e]',
      'GR_EX_CE7096[e]',      'GR_EX_CE4877[e]',      'GR_EX_CE1447[e]',      'GR_EX_CE6205[e]',
      'GR_EX_trypta[e]',      'GR_C05767te',      'GR_EX_C05767[e]',      'GR_C05770te3',
      'GR_EX_C05770[e]',      'GR_EX_mhista[e]',      'GR_PPBNGte',      'GR_EX_ppbng[e]',
      'GR_EX_mma[e]',      'GR_12PPDRte',      'GR_EX_12ppd_R[e]',      'GR_AMETAMte',
      'GR_EX_ametam[e]',      'GR_XYLULte',      'GR_EX_xylu_L[e]',      'GR_XYLUDte',
      'GR_EX_xylu_D[e]',      'GR_GLCNte',      'GR_SPHGNSte',      'GR_EX_sphings[e]',
      'GR_HDD2CRNte',      'GR_EX_hdd2crn[e]',      'GR_IM4ACte',      'GR_EX_im4ac[e]',
      'GR_EX_CE1918[e]',      'GR_EX_mlthf[e]',      'GR_EX_CE2705[e]',      'GR_SPHGNte',
      'GR_EX_sphgn[e]',      'GR_EX_N1aspmd[e]',      'GR_C13856te',      'GR_EX_1a25dhvitd3[e]',
      'GR_PRISTte',      'GR_EX_prist[e]',      'GR_CE2049te',      'GR_EX_CE2049[e]',
      'GR_CE2047te',      'GR_EX_CE2047[e]',      'GR_LANOSTte',      'GR_FDPte',
      'GR_EX_fdp[e]',      'GR_EX_coke[e]',      'GR_COKEte',      'GR_COKEtr',
      'GR_EX_5a2opntn[e]',      'GR_5A2OPNTNte',      'GR_5A2OPNTNtx',      'GR_ARG_Dtx',
      'GR_ARG_Dte',      'GR_EX_arg_D[e]',      'GR_LANOSTtr',      'GR_EX_ldl_hs[e]',
      'GR_EX_HC00005[e]',      'GR_CE1261t',      'GR_DOPAOQNOX',      'GR_DOPAOQCYS',
      'GR_DACT',      'GR_CE5629t',      'GR_EX_CE5629[e]',      'GR_CRMte',
      'GR_EX_gd3_hs[e]',      'GR_EX_gluside_hs[e]',      'GR_GALGLUSIDEtg2',      'GR_GD3tg',
      'GR_GD3tl',      'GR_GLUSIDEte',      'GR_GLUSIDEtg',      'GR_GLUSIDEtl',
      'GR_GM1tg',      'GR_GM1tl',      'GR_SPHMYLNtl2',      'GR_RE3477C1',
      'GR_NH4tr',      'GR_UDPGALt2n',      'GR_THCRMtl',      'GR_DAG_HStg',
      'GR_SPHGNtn',      'GR_SPHGNtg',      'GR_SPHINGStn',      'GR_SPHINGStg',
      'GR_DHCRMtg',      'GR_GDA1tn',      'GR_sink_34dhpac[c]',      'GR_34DHPEt',
      'GR_EX_34dhpe[e]',      'GR_DM_sph1p[n]',      'GR_DM_sphs1p[n]',      'GR_DM_gm1_hs[n]',
      'GR_DM_gda1_hs[n]',      'GR_DM_6hddopaqn[c]',      'GR_GALSIDEtn',      'GR_CERT1tn',
      'GR_Rtotaltg',      'GR_GD1Atg',      'GR_GD1Atn',      'GR_ATPtg',
      'GR_GD3tlc',      'GR_GD3tm',      'GR_DM_pail35p_hs[n]',      'GR_DM_gd3_hs[m]',
      'GR_CATr',      'GR_S2L2N2M2Mtl',      'GR_DM_k[g]',      'GR_DM_na1[g]',
      'GR_DM_retn[n]',      'GR_DM_15HPET[n]',      'GR_DM_15HPET[x]',      'GR_DM_15HPET[r]',
      'GR_sink_Ser_Gly_Ala_X_Gly[r]',      'GR_EX_pail_hs[e]',      'GR_EX_CE5026[e]',      'GR_EX_CE1261[e]',
      'GR_EX_galgluside_hs[e]',      'GR_EX_gm1_hs[e]',      'GR_HMR_0015',      'GR_HMR_0020',
      'GR_HMR_0157',      'GR_HMR_0166',      'GR_HMR_0172',      'GR_HMR_0178',
      'GR_HMR_0182',      'GR_HMR_0185',      'GR_HMR_0763',      'GR_HMR_0769',
      'GR_HMR_0771',      'GR_HMR_0809',      'GR_HMR_0831',      'GR_HMR_0912',
      'GR_HMR_0913',      'GR_HMR_0962',      'GR_HMR_0984',      'GR_HMR_1095',
      'GR_HMR_1104',      'GR_HMR_1135',      'GR_HMR_1242',      'GR_HMR_1243',
      'GR_HMR_1283',      'GR_HMR_1284',      'GR_HMR_1306',      'GR_HMR_1311',
      'GR_HMR_1315',      'GR_HMR_1316',      'GR_HMR_1317',      'GR_HMR_1332',
      'GR_HMR_1623',      'GR_HMR_1701',      'GR_HMR_1744',      'GR_HMR_1745',
      'GR_HMR_1752',      'GR_HMR_1753',      'GR_HMR_1758',      'GR_HMR_1759',
      'GR_HMR_1834',      'GR_HMR_2087',      'GR_HMR_2090',      'GR_HMR_2127',
      'GR_HMR_2374',      'GR_HMR_2376',      'GR_HMR_2391',      'GR_HMR_2393',
      'GR_HMR_2495',      'GR_HMR_2569',      'GR_HMR_2571',      'GR_HMR_3053',
      'GR_HMR_3056',      'GR_HMR_3106',      'GR_HMR_3396',      'GR_HMR_3397',
      'GR_HMR_3478',      'GR_HMR_3520',      'GR_HMR_3597',      'GR_HMR_3951',
      'GR_HMR_3953',      'GR_HMR_3996',      'GR_HMR_4078',      'GR_HMR_4266',
      'GR_HMR_4664',      'GR_HMR_4672',      'GR_HMR_4782',      'GR_HMR_4783',
      'GR_HMR_4831',      'GR_HMR_4957',      'GR_HMR_5101',      'GR_HMR_5409',
      'GR_HMR_6500',      'GR_HMR_6611',      'GR_HMR_6629',      'GR_HMR_6784',
      'GR_HMR_6785',      'GR_HMR_6786',      'GR_HMR_7198',      'GR_HMR_7330',
      'GR_HMR_7712',      'GR_HMR_7715',      'GR_HMR_7898',      'GR_HMR_7900',
      'GR_HMR_7944',      'GR_HMR_7977',      'GR_HMR_8023',      'GR_HMR_8084',
      'GR_HMR_8086',      'GR_HMR_8090',      'GR_HMR_8374',      'GR_HMR_8418',
      'GR_HMR_8505',      'GR_HMR_8562',      'GR_HMR_8567',      'GR_HMR_8776',
      'GR_HMR_9019',      'GR_HMR_9174',      'GR_HMR_9175',      'GR_HMR_9176',
      'GR_HMR_9179',      'GR_HMR_9180',      'GR_HMR_9184',      'GR_HMR_9185',
      'GR_HMR_9188',      'GR_HMR_9189',      'GR_HMR_9612',      'GR_HMR_9625',
      'GR_HMR_9626',      'GR_HMR_9627',      'GR_HMR_9628',      'GR_HMR_9634',
      'GR_HMR_9638',      'GR_HMR_9639',      'GR_HMR_9640',      'GR_HMR_9647',
      'GR_HMR_9648',      'GR_HMR_9652',      'GR_HMR_9665',      'GR_HMR_9667',
      'GR_HMR_9676',      'GR_HMR_9678',      'GR_HMR_9679',      'GR_HMR_9680',
      'GR_HMR_9718',      'GR_HMR_9720',      'GR_HMR_9797',      'GR_HMR_6672',
      'GR_EX_nadh[e]',      'GR_EX_glc_D[e]',      'GR_EX_sbt_D[e]',      'GR_CDCA24Gtr',
      'GR_CDCA3Gtr',      'GR_DM_12dhchol[c]',      'GR_DM_3dhcdchol[c]',      'GR_DM_3dhchol[c]',
      'GR_DM_3dhdchol[c]',      'GR_DM_3dhlchol[c]',      'GR_DM_7dhcdchol[c]',      'GR_DM_7dhchol[c]',
      'GR_DM_cdca24g[c]',      'GR_DM_cdca3g[c]',      'GR_DM_coprost[c]',      'GR_DM_hca24g[c]',
      'GR_DM_hdca24g[c]',      'GR_DM_hdca6g[c]',      'GR_DM_hyochol[c]',      'GR_DM_icdchol[c]',
      'GR_DM_isochol[c]',      'GR_DM_lca24g[c]',      'GR_DM_lca3g[c]',      'GR_DM_thyochol[c]',
      'GR_DM_uchol[c]',      'GR_EX_12dhchol[e]',      'GR_EX_3dhcdchol[e]',      'GR_EX_3dhchol[e]',
      'GR_EX_3dhdchol[e]',      'GR_EX_3dhlchol[e]',      'GR_EX_7dhcdchol[e]',      'GR_EX_7dhchol[e]',
      'GR_EX_cdca24g[e]',      'GR_EX_cdca3g[e]',      'GR_EX_coprost[e]',      'GR_EX_hca24g[e]',
      'GR_EX_hdca24g[e]',      'GR_EX_hdca6g[e]',      'GR_EX_hyochol[e]',      'GR_EX_icdchol[e]',
      'GR_EX_isochol[e]',      'GR_EX_lca24g[e]',      'GR_EX_lca3g[e]',      'GR_EX_thyochol[e]',
      'GR_EX_uchol[e]',      'GR_HCA24Gtr',      'GR_HDCA6Gtr',      'GR_HYOCHOLtr',
      'GR_LCA24Gtr',      'GR_LCA3Gtr',      'GR_M02155tr',      'GR_12HTACRtep',
      'GR_14MDZtev',      'GR_1HIBUPGLUC_Sthv',      'GR_1HIBUP_Sthv',      'GR_1HMDZGLUChc',
      'GR_1OHMDZtep',      'GR_2HATVACIDtep',      'GR_2HATVLACtep',      'GR_2HIBUPGLUC_Sthv',
      'GR_2HIBUP_Rthv',      'GR_2HIBUP_Sthv',      'GR_35DSMVteb',      'GR_3HIBUPGLUC_Sthv',
      'GR_3HIBUP_Rthv',      'GR_3HIBUP_Sthv',      'GR_3HLVSTACtbc',      'GR_3HPVSTETtev',
      'GR_3HPVStep',      'GR_3HSMVACIDteb',      'GR_3ISPVStep',      'GR_3MEACMPhc',
      'GR_3OHACMPtev',      'GR_4HATVACIDtep',      'GR_4HATVLACtep',      'GR_4HMDGLUCtev',
      'GR_4OHMDZtev',      'GR_56DHPVStev',      'GR_56EPPVStev',      'GR_5OHFVSGLUhc',
      'GR_5OHFVSGLUtev',      'GR_5OHFVSteb',      'GR_6BHGLZtev',      'GR_6CSMVACIDteb',
      'GR_6EPVStep',      'GR_6HLVSTthep',      'GR_6HMSMVACIDteb',      'GR_6HSMVACIDteb',
      'GR_6MELVSTthep',      'GR_6OHFVSGLUhc',      'GR_6OHFVSGLUtev',      'GR_7BHGLZtev',
      'GR_7HPVStev',      'GR_ACMPdt',      'GR_AM1CSAtep',      'GR_AM9CSAtep',
      'GR_ATVACIDhr',      'GR_ATVACIDtdu',      'GR_ATVLACh2r',      'GR_ATVLAChr',
      'GR_ATVLACtdhc',      'GR_Am19CStev',      'GR_CARBIBUP_SGLUthv',      'GR_CARIBUP_Sthv',
      'GR_CRVSM24tev',      'GR_CRVStu',      'GR_CSAtd',      'GR_DEOXFVStev',
      'GR_DSPVStev',      'GR_EPOXTAChr',      'GR_EPOXTACtev',      'GR_EX_12htacr[e]',
      'GR_EX_14hmdz[e]',      'GR_EX_1hibup_S[e]',      'GR_EX_1hibupglu_S[e]',      'GR_EX_1hmdgluc[e]',
      'GR_EX_1ohmdz[e]',      'GR_EX_2hatvacid[e]',      'GR_EX_2hatvlac[e]',      'GR_EX_2hatvlacgluc[e]',
      'GR_EX_2hibup_R[e]',      'GR_EX_2hibup_S[e]',      'GR_EX_2hibupglu_S[e]',      'GR_EX_35dsmv[e]',
      'GR_EX_3hibup_R[e]',      'GR_EX_3hibup_S[e]',      'GR_EX_3hibupglu_S[e]',      'GR_EX_3hlvstacid[e]',
      'GR_EX_3hpvs[e]',      'GR_EX_3hpvstet[e]',      'GR_EX_3hsmvacid[e]',      'GR_EX_3ohacmp[e]',
      'GR_EX_4hatvacid[e]',      'GR_EX_4hatvlac[e]',      'GR_EX_4hmdgluc[e]',      'GR_EX_4ohmdz[e]',
      'GR_EX_5ohfvs[e]',      'GR_EX_5ohfvsglu[e]',      'GR_EX_6bhglz[e]',      'GR_EX_6csmvacid[e]',
      'GR_EX_6hlvst[e]',      'GR_EX_6hmsmvacid[e]',      'GR_EX_6hsmvacid[e]',      'GR_EX_6melvacid[e]',
      'GR_EX_6melvst[e]',      'GR_EX_6ohfvsglu[e]',      'GR_EX_7bhglz[e]',      'GR_EX_acmp[e]',
      'GR_EX_am19cs[e]',      'GR_EX_am1csa[e]',      'GR_EX_am9csa[e]',      'GR_EX_atvacid[e]',
      'GR_EX_atvlac[e]',      'GR_EX_caribup_s[e]',      'GR_EX_caribupglu_S[e]',      'GR_EX_crvs[e]',
      'GR_EX_crvsm24[e]',      'GR_EX_csa[e]',      'GR_EX_deoxfvs[e]',      'GR_EX_epoxtac[e]',
      'GR_EX_fvs[e]',      'GR_EX_glc3meacp[e]',      'GR_EX_glz[e]',      'GR_EX_ibup_R[e]',
      'GR_EX_ibup_S[e]',      'GR_EX_ibupgluc[e]',      'GR_EX_isolvstacid[e]',      'GR_EX_lstn[e]',
      'GR_EX_lstnm7[e]',      'GR_EX_lvst[e]',      'GR_EX_mdz[e]',      'GR_EX_nfdac[e]',
      'GR_EX_nfdoh[e]',      'GR_EX_profvs[e]',      'GR_EX_ptvst[e]',      'GR_EX_ptvstlac[e]',
      'GR_EX_pvs[e]',      'GR_EX_smv[e]',      'GR_EX_smvacid[e]',      'GR_EX_tacr[e]',
      'GR_EX_tlacfvs[e]',      'GR_FVShc',      'GR_FVStep',      'GR_GLC3MEACPtev',
      'GR_GLZtd',      'GR_IBUPGLUCtchep',      'GR_IBUPGLUCtpvb',      'GR_IBUP_Rtdhep',
      'GR_IBUP_Rtdu',      'GR_IBUP_Stdhep',      'GR_IBUP_Stdu',      'GR_ISOLVSTAChep',
      'GR_LSTNM7TDhc',      'GR_LSTNM7thc',      'GR_LSTNRATt',      'GR_LSTNtd',
      'GR_LVACLAChep',      'GR_LVSTtu',      'GR_MDZtd',      'GR_NFDACtep',
      'GR_NFDOHtep',      'GR_OXYPtepv',      'GR_PROFVShc',      'GR_PROFVStev',
      'GR_PTVSTLAChc',      'GR_PTVSTLACtev',      'GR_PTVSTtep',      'GR_PVSGLUCtev',
      'GR_PVSHtu',      'GR_PVStep',      'GR_RSVGLUChc',      'GR_RSVLAChv',
      'GR_SMVACIDtev',      'GR_SMVtv',      'GR_TACRDtsc',      'GR_TLACFVStev',
      'GR_TRIPVStev',      'GR_12HTACRitr',      'GR_14HMDZitr',      'GR_1HIBUP_Sitr',
      'GR_1HIBUPGLUitr',      'GR_1HMDGLUCitr',      'GR_2HATVLACGLUCitr',      'GR_2HIBUP_Ritr',
      'GR_2HIBUP_Sitr',      'GR_2HIBUPGLUC_Sitr',      'GR_35DSMVitr',      'GR_3HIBUP_Ritr',
      'GR_3HIBUPGLUC_Sitr',      'GR_3HLVSTitr',      'GR_3HPVSitr',      'GR_3HPVSCOAitm',
      'GR_3HPVSCOAitx',      'GR_3HPVSTETCOAitm',      'GR_3HPVSTETCOAitx',      'GR_3HSMVitr',
      'GR_3MEACMPitr',      'GR_3OHACMPitr',      'GR_4HATVACIDitr',      'GR_4HATVLACitr',
      'GR_4HMDGLUCitr',      'GR_4OHMDZitr',      'GR_5OHFVSitr',      'GR_5OHFVSGLUitr',
      'GR_6CSMVitr',      'GR_6HLVSTitr',      'GR_6HLVSTACIDitr',      'GR_6HMSMVitr',
      'GR_6HSMVitr',      'GR_6MELVACIDitr',      'GR_6MELVSTitr',      'GR_6OHFVSGLUitr',
      'GR_ACMPitr',      'GR_AM19CSitr',      'GR_CARIBUP_Sitr',      'GR_CARIBUPGLU_Sitr',
      'GR_CRVSitr',      'GR_CRVSM24itr',      'GR_CSAitr',      'GR_DEOXFVSitx',
      'GR_EPOXTACitr',      'GR_FVSitx',      'GR_FVSCOAitx',      'GR_GLC3MEACPitr',
      'GR_GLZitr',      'GR_IBUP_Ritr',      'GR_IBUP_Sitr',      'GR_IBUPGLUCitr',
      'GR_LSTNitr',      'GR_LSTNM7itr',      'GR_LVSTitr',      'GR_LVSTACIDitr',
      'GR_MDZitr',      'GR_NFDOHitr',      'GR_PROFVSCOAitx',      'GR_PTVSTLACitr',
      'GR_PTVSTM13itr',      'GR_PTVSTM13te',      'GR_EX_ptvstm13[e]',      'GR_PVSitr',
      'GR_RSVLACitr',      'GR_TACRitr',      'GR_TLACFVSitr',      'GR_3HPVSCOAhc',
      'GR_3HPVSTEThc',      'GR_FVSCOAhc',      'GR_1OHMDZitr',      'GR_NFDACitr',
      'GR_H2O2itr',      'GR_ATVACIDitr',      'GR_ATVLACitr',      'GR_SMVitr',
      'GR_6BHGLZitr',      'GR_7BHGLZitr',      'GR_RSVitr',      'GR_PTVSTitr',
      'GR_3HIBUP_Sitr',      'GR_FVSitr',      'GR_AM1CSAitr',      'GR_AM9CSAitr',
      'GR_2HATVACIDitr',      'GR_EX_caproic[e]',      'GR_1A25HVITD2t',      'GR_1A25HVITD2tm',
      'GR_EX_1a25dhvitd2[e]',      'GR_EX_C13856[e]',      'GR_EX_M00234[e]',      'GR_EX_M01807[e]',
      'GR_EX_M00503[e]',      'GR_EX_M00003[e]',      'GR_EX_M00008[e]',      'GR_EX_M00010[e]',
      'GR_EX_M00017[e]',      'GR_EX_M00019[e]',      'GR_EX_M00021[e]',      'GR_EX_M00115[e]',
      'GR_EX_M00117[e]',      'GR_EX_M00260[e]',      'GR_EX_M00265[e]',      'GR_EX_M00315[e]',
      'GR_EX_M00341[e]',      'GR_EX_M01197[e]',      'GR_EX_M01207[e]',      'GR_EX_M01235[e]',
      'GR_EX_M01238[e]',      'GR_EX_M01582[e]',      'GR_EX_M02053[e]',      'GR_EX_M02457[e]',
      'GR_EX_M02613[e]',      'GR_EX_M02745[e]',      'GR_EX_M03045[e]',      'GR_EX_M03051[e]',
      'GR_EX_M03153[e]',      'GR_EX_M02560[e]',      'GR_EX_C01601[e]',      'GR_EX_M02108[e]',
      'GR_EX_M03117[e]',      'GR_EX_M03134[e]',      'GR_EX_M01111[e]',      'GR_EX_h2co3[e]',
      'GR_EX_M01870[e]',      'GR_EX_ditp[e]',      'GR_EX_M02446[e]',      'GR_EX_M02447[e]',
      'GR_EX_M02449[e]',      'GR_EX_M02451[e]',      'GR_EX_itacon[e]',      'GR_EX_adpman[e]',
      'GR_EX_rbl_D[e]',      'GR_EX_M02155[e]',      'GR_EX_M01989[e]',      'GR_EX_M03131[e]',
      'GR_EX_n5m2masn[e]',      'GR_EX_dolichol_L[e]',      'GR_sink_his_L[c]',      'GR_sink_ile_L[c]',
      'GR_sink_leu_L[c]',      'GR_sink_lys_L[c]',      'GR_sink_met_L[c]',      'GR_sink_phe_L[c]',
      'GR_sink_thr_L[c]',      'GR_sink_trp_L[c]',      'GR_sink_val_L[c]',      'GR_sink_ala_L[c]',
      'GR_sink_arg_L[c]',      'GR_sink_asn_L[c]',      'GR_sink_asp_L[c]',      'GR_sink_cys_L[c]',
      'GR_sink_gln_L[c]',      'GR_sink_glu_L[c]',      'GR_sink_pro_L[c]',      'GR_sink_ser_L[c]',
      'GR_sink_tyr_L[c]',      'GR_sink_gly[c]',      'GR_sink_4abut[l]',      'GR_DM_5cysdopa[c]',
      'GR_DM_4abut[c]',      'GR_DM_srtn[c]',      'GR_DM_ach[c]',      'GR_DM_hista[c]',
      'GR_DM_kynate[c]',      'GR_DM_tym[c]',      'GR_DM_Lkynr[c]',      'GR_DM_cbl2[m]',
      'GR_DCMPtm',      'GR_ATPS4mi',      'GR_KER_02243',      'GR_KER_02407',
      'GR_KER_10600',      'GR_ITPtm',      'GR_IDPtm',      'GR_CE_Peptide',
      'GR_EX_Peptide',      'GR_Ubiquitin_syn',      'GR_DM_Ubiquitin',      'GR_Abeta_syn',
      'GR_DM_Abeta',      'GR_Abeta_L_lysine',      'GR_CE_Abeta_L_lysine',      'GR_CN_Abeta_L_lysine',
      'GR_EX_Abeta_L_lysine',      'GR_EN_Abeta_L_lysine',      'GR_Abeta_Deg',      'GR_Tau_syn',
      'GR_DM_Tau',      'GR_Tau_L_lysine',      'GR_CE_Tau_L_lysine',      'GR_CN_Tau_L_lysine',
      'GR_EX_Tau_L_lysine',      'GR_EN_Tau_L_lysine',      'GR_Tau_Deg',      'GR_TNFA_syn',
      'GR_DM_TNFA',      'GR_TNFA_L_lysine',      'GR_CE_TNFA_L_lysine',      'GR_CN_TNFA_L_lysine',
      'GR_EX_TNFA_L_lysine',      'GR_EN_TNFA_L_lysine',      'GR_TNFA_Deg',      'GR_IL6_syn',
      'GR_DM_IL6',      'GR_IL6_L_lysine',      'GR_CE_IL6_L_lysine',      'GR_CN_IL6_L_lysine',
      'GR_EX_IL6_L_lysine',      'GR_EN_IL6_L_lysine',      'GR_IL6_Deg'
    /

  enzymes_NCA(enzymes) "enzymes are not existed in CA model (HT only)"
    /
      'E0018',      'E0115',      'E0116',      'E0176',      'E0510',      'E0538',      'E0556',      'E0573',      'E0696',      'E0714',
      'E0788',      'E0791',      'E0800',      'E0811',      'E0946',      'E0948',      'E0949',      'E0999',      'E1021',      'E1088',
      'E1090',      'E1166',      'E1204',      'E1205',      'E1210',      'E1239',      'E1246',      'E1247',      'E1297',      'E1324',
      'E1405',      'E1488',      'E1498',      'E1632',      'E1678',      'E1709',      'E1724',      'E1736',      'E1737',      'E1738',
      'E1739',      'E1765',      'E1806',      'E1824',      'E1825',      'E1826',      'E1827',      'E1844',      'E1845',      'E1867',
      'E1892',      'E1893',      'E1894',      'E1895',      'E1921',      'E1971',      'E1972',      'E1991',      'E2013',      'E2018',
      'E2020',      'E2021',      'E2028',      'E2034',      'E2154',      'E2155'

********** Non-GPR association enzymes ----------
      'ER_ACNACNGALGBSIDEte',      'ER_ACNACNGALGBSIDEtg',      'ER_AQCOBALt',      'ER_B3GALTg',
      'ER_BALAtmr',      'ER_C226COAtx',      'ER_CBL2OR',      'ER_CLPNDCOAtx',
      'ER_COUMARINte',      'ER_CRMPte',      'ER_CRTSTRNt',      'ER_D_3AIBt',
      'ER_DESAT22_2p',      'ER_DHPR2',      'ER_DM_gncore2_g_',      'ER_EX_3aib_D[e]',
      'ER_EX_acnacngalgbside_hs[e]',      'ER_EX_aprgstrn[e]',      'ER_EX_aqcobal[e]',      'ER_EX_avite1[e]',
      'ER_EX_coumarin[e]',      'ER_EX_crmp_hs[e]',      'ER_EX_crtstrn[e]',      'ER_EX_fuc14galacglcgalgluside_hs[e]',
      'ER_EX_fucfuc12gal14acglcgalgluside_hs[e]',      'ER_EX_fucfucgalacglcgalgluside_hs[e]',      'ER_EX_fuc_L[e]',      'ER_EX_gdp[e]',
      'ER_EX_gluala[e]',      'ER_EX_gmp[e]',      'ER_EX_gtp[e]',      'ER_EX_hcoumarin[e]',
      'ER_EX_hestratriol[e]',      'ER_EX_idp[e]',      'ER_EX_ksi_deg1[e]',      'ER_EX_lac_D[e]',
      'ER_EX_prgstrn[e]',      'ER_EX_s2l2fn2m2masn[e]',      'ER_EX_s2l2n2m2masn[e]',      'ER_EX_spc_hs[e]',
      'ER_EX_sph1p[e]',      'ER_EX_sphs1p[e]',      'ER_EX_srtn[e]',      'ER_EX_thym[e]',
      'ER_EX_udp[e]',      'ER_EX_xolest2_hs[e]',      'ER_F1Atg',      'ER_FRDPtr',
      'ER_FUC14GALACGLCGALGLUSIDEte',      'ER_FUC14GALACGLCGALGLUSIDEtg',      'ER_FUCFUC12GAL14ACGLCGALGLUSIDEte',      'ER_FUCFUC12GAL14ACGLCGALGLUSIDEtg',
      'ER_FUCFUCGALACGLCGALGLUSIDEte',      'ER_FUCFUCGALACGLCGALGLUSIDEtg',      'ER_GLACter',      'ER_GLYCK2',
      'ER_GTHDH',      'ER_HCOUMARINte',      'ER_HESTRATRIOLte',      'ER_HESTRATRIOLtr',
      'ER_IPDPtx',      'ER_MI134P4P',      'ER_MI13PP',      'ER_N4Tg',
      'ER_PAIL4P_HStn',      'ER_PCHOL_HStg',      'ER_PPAn',      'ER_PRGSTRNt',
      'ER_PRISTCOAtx',      'ER_S2L2FN2M2MASNtly',      'ER_S2L2N2M2MASNtly',      'ER_SPC_HSt',
      'ER_SPH1Pte',      'ER_SPHS1Pte',      'ER_TETHEX3COAtx',      'ER_TETPENT3COAtx',
      'ER_TETTET6COAtx',      'ER_TETTET6t',      'ER_TMNDNCt',      'ER_UROLACer',
      'ER_UTPtn',      'ER_EX_ahdt[e]',      'ER_EX_ctp[e]',      'ER_EX_dha[e]',
      'ER_EX_dtmp[e]',      'ER_EX_dttp[e]',      'ER_EX_HC01104[e]',      'ER_EX_HC01361[e]',
      'ER_r0365',      'ER_r1013',      'ER_r1088',      'ER_RE1711C',
      'ER_RE1915C',      'ER_RE1916C',      'ER_RE1978C',      'ER_RE2426C',
      'ER_RE2562C',      'ER_RE2563C',      'ER_RE2677N',      'ER_RE2799C',
      'ER_RE3016R',      'ER_RE3017R',      'ER_RE3180C',      'ER_RE3181C',
      'ER_RE3272N',      'ER_RE3422C',      'ER_EX_prostgi2[e]',      'ER_EX_cdp[e]',
      'ER_EX_dtdp[e]',      'ER_EX_CE5789[e]',      'ER_EX_CE5797[e]',      'ER_EX_CE5798[e]',
      'ER_C16DCe',      'ER_EX_c16dc[e]',      'ER_HEXDIACtr',      'ER_SUBEACtx',
      'ER_3AIB_Dtm',      'ER_ALA-DTDe',      'ER_EX_dchac[e]',      'ER_EX_sfcys[e]',
      'ER_INSK',      'ER_KHte',      'ER_SFCYSc',      'ER_SFCYSe',
      'ER_EX_5hoxindoa[e]',      'ER_PHLAC',      'ER_PHLACHt',      'ER_15KPROSTGF2t',
      'ER_3HPPt',      'ER_3UIBtd',      'ER_56DTHMt',      'ER_56DTHMtd',
      'ER_ADPACtd',      'ER_C11695td',      'ER_CE5304t',      'ER_CE6247t',
      'ER_EX_15kprostgf2[e]',      'ER_EX_3hpp[e]',      'ER_EX_3uib[e]',      'ER_EX_56dthm[e]',
      'ER_EX_adpac[e]',      'ER_EX_C11695[e]',      'ER_EX_CE5304[e]',      'ER_EX_CE6247[e]',
      'ER_EX_pchol2linl_hs[e]',      'ER_EX_pchol2ole_hs[e]',      'ER_EX_pchol2ste_hs[e]',      'ER_EX_pcholar_hs[e]',
      'ER_EX_pcholdoc_hs[e]',      'ER_EX_pcholeic_hs[e]',      'ER_EX_pcholet_hs[e]',      'ER_EX_pcholhep_hs[e]',
      'ER_EX_pchollinl_hs[e]',      'ER_EX_pcholmyr_hs[e]',      'ER_EX_pcholn15_hs[e]',      'ER_EX_pcholn183_hs[e]',
      'ER_EX_pcholn1836_hs[e]',      'ER_EX_pcholn19_hs[e]',      'ER_EX_pcholn201_hs[e]',      'ER_EX_pcholn203_hs[e]',
      'ER_EX_pcholn204_hs[e]',      'ER_EX_pcholn205_hs[e]',      'ER_EX_pcholn224_hs[e]',      'ER_EX_pcholn225_hs[e]',
      'ER_EX_pcholn2254_hs[e]',      'ER_EX_pcholn226_hs[e]',      'ER_EX_pcholn24_hs[e]',      'ER_EX_pcholole_hs[e]',
      'ER_EX_pcholpalm_hs[e]',      'ER_EX_pcholpalme_hs[e]',      'ER_EX_pcholste_hs[e]',      'ER_EX_sebacid[e]',
      'ER_EX_sphmyln180241_hs[e]',      'ER_EX_sphmyln18114_hs[e]',      'ER_EX_sphmyln18115_hs[e]',      'ER_EX_sphmyln18116_hs[e]',
      'ER_EX_sphmyln181161_hs[e]',      'ER_EX_sphmyln18117_hs[e]',      'ER_EX_sphmyln18118_hs[e]',      'ER_EX_sphmyln181181_hs[e]',
      'ER_EX_sphmyln18120_hs[e]',      'ER_EX_sphmyln181201_hs[e]',      'ER_EX_sphmyln18121_hs[e]',      'ER_EX_sphmyln18122_hs[e]',
      'ER_EX_sphmyln181221_hs[e]',      'ER_EX_sphmyln18123_hs[e]',      'ER_EX_sphmyln1824_hs[e]',      'ER_EX_sphmyln1825_hs[e]',
      'ER_PROSTGI2c',      'ER_SEBACIDtd',      'ER_EX_phlac[e]',      'ER_FldAct',
      'ER_MALOAtm',      'ER_FAS180',      'ER_S2L2N2M2Mt',      'ER_EX_s2l2n2m2m[e]',
      'ER_3HPPtm',      'ER_sink_avite1[c]',      'ER_sink_fad[c]',      'ER_sink_fe3[c]',
      'ER_EX_duri[e]',      'ER_EX_glcr[e]',      'ER_OAADC',      'ER_EX_pyr[e]',
      'ER_OBDHc',      'ER_EX_phpyr[e]',      'ER_PPIOGLYtm',      'ER_PPIOGLYte',
      'ER_EX_ppiogly[e]',      'ER_3HADPACx',      'ER_3HADPACtxc',      'ER_3HADPACte',
      'ER_EX_3hadpac[e]',      'ER_3OHSEBACx',      'ER_3OHSEBACtxc',      'ER_3OHSEBACte',
      'ER_EX_3ohsebac[e]',      'ER_3OHSUBACx',      'ER_3OHSUBACtxc',      'ER_3OHSUBACte',
      'ER_EX_3ohsubac[e]',      'ER_HEXGLYte',      'ER_EX_hexgly[e]',      'ER_SUBGLYte',
      'ER_EX_subgly[e]',      'ER_SPHMYLN180241_hs_SECt',      'ER_SPHMYLN18114_hs_SECt',      'ER_SPHMYLN18115_hs_SECt',
      'ER_SPHMYLN18116_hs_SECt',      'ER_SPHMYLN181161_hs_SECt',      'ER_SPHMYLN18117_hs_SECt',      'ER_SPHMYLN18118_hs_SECt',
      'ER_SPHMYLN181181_hs_SECt',      'ER_SPHMYLN18120_hs_SECt',      'ER_SPHMYLN181201_hs_SECt',      'ER_SPHMYLN18121_hs_SECt',
      'ER_SPHMYLN18122_hs_SECt',      'ER_SPHMYLN181221_hs_SECt',      'ER_SPHMYLN18123_hs_SECt',      'ER_SPHMYLN1824_hs_SECt',
      'ER_SPHMYLN1825_hs_SECt',      'ER_AK2LGCHOLt1',      'ER_PAFt1',      'ER_PCHOL2LINL_HSt1e',
      'ER_PCHOL2OLE_HSt1e',      'ER_PCHOL2STE_HSt1e',      'ER_PCHOLAR_HSt1e',      'ER_PCHOLDOC_HSt1e',
      'ER_PCHOLEIC_HSt1e',      'ER_PCHOLET_HSt1e',      'ER_PCHOLHEP_HSt1e',      'ER_PCHOLLINL_HSt1e',
      'ER_PCHOLMYR_Hst1e',      'ER_PCHOLN15_HSt1e',      'ER_PCHOLN183_HSt1e',      'ER_PCHOLN1836_HSt1e',
      'ER_PCHOLN19_HSt1e',      'ER_PCHOLN201_HSt1e',      'ER_PCHOLN203_HSt1e',      'ER_PCHOLN204_HSt1e',
      'ER_PCHOLN205_HSt1e',      'ER_PCHOLN224_HSt1e',      'ER_PCHOLN225_HSt1e',      'ER_PCHOLN2254_HSt1e',
      'ER_PCHLN225_HSt1e',      'ER_PCHOLN264_HSt1e',      'ER_PCHOLOLE_HSt1e',      'ER_PEPALM_HSt1e',
      'ER_PCHOLPALME-HSt1e',      'ER_PCHOLSTE_HSt1e',      'ER_ESTRONEte',      'ER_EX_estrone[e]',
      'ER_HC02020tr',      'ER_HC02020te',      'ER_EX_HC02020[e]',      'ER_XOL25OHtr',
      'ER_XOL25OHte',      'ER_EX_xol25oh[e]',      'ER_EX_CE6205[e]',      'ER_EX_CE1918[e]',
      'ER_C13856te',      'ER_CE1261t',      'ER_GM1tg',      'ER_UDPGALt2n',
      'ER_DAG_HStg',      'ER_GALSIDEtn',      'ER_CERT1tn',      'ER_GD1Atg',
      'ER_S2L2N2M2Mtl',      'ER_EX_CE5026[e]',      'ER_EX_CE1261[e]',      'ER_HMR_0912',
      'ER_HMR_0913',      'ER_HMR_2495',      'ER_HMR_4831',      'ER_HMR_7977',
      'ER_HMR_9184',      'ER_EX_nadh[e]',      'ER_1HMDZGLUChc',      'ER_4HMDGLUCtev',
      'ER_ATVLACh2r',      'ER_ATVLAChr',      'ER_EX_1hmdgluc[e]',      'ER_EX_2hatvlacgluc[e]',
      'ER_EX_4hmdgluc[e]',      'ER_EX_pvs[e]',      'ER_EX_tlacfvs[e]',      'ER_FVShc',
      'ER_IBUPGLUCtpvb',      'ER_PVSHtu',      'ER_PVStep',      'ER_TLACFVStev',
      'ER_1HMDGLUCitr',      'ER_2HATVLACGLUCitr',      'ER_3HPVSitr',      'ER_4HMDGLUCitr',
      'ER_PVSitr',      'ER_TLACFVSitr',      'ER_EX_C13856[e]',      'ER_EX_M01111[e]',
      'ER_EX_adpman[e]',      'ER_DM_hista[c]',      'ER_DM_cbl2[m]'
    /

  enzymes_NHT(enzymes) "enzymes are not existed in HT model (CA only)"
    /
      'E0038',      'E0047',      'E0055',      'E0056',      'E0104',      'E0107',      'E0220',      'E0223',      'E0283',      'E0284',
      'E0286',      'E0287',      'E0289',      'E0519',      'E0536',      'E0547',      'E0548',      'E0549',      'E0550',      'E0551',
      'E0552',      'E0553',      'E0554',      'E0555',      'E0604',      'E0636',      'E0637',      'E0849',      'E0904',      'E0905',
      'E0923',      'E1022',      'E1027',      'E1029',      'E1030',      'E1031',      'E1033',      'E1069',      'E1070',      'E1072',
      'E1098',      'E1114',      'E1123',      'E1149',      'E1150',      'E1151',      'E1152',      'E1153',      'E1154',      'E1211',
      'E1230',      'E1317',      'E1329',      'E1330',      'E1331',      'E1478',      'E1531',      'E1537',      'E1544',      'E1545',
      'E1546',      'E1560',      'E1573',      'E1602',      'E1603',      'E1604',      'E1615',      'E1687',      'E1701',      'E1702',
      'E1703',      'E1704',      'E1715',      'E1721',      'E1768',      'E1791',      'E1793',      'E1794',      'E1817',      'E1829',
      'E1874',      'E1875',      'E1881',      'E1932',      'E1964',      'E1965',      'E1966',      'E1967',      'E2030',      'E2031',
      'E2033',      'E2035',      'E2276'

********** Non-GPR association enzymes ----------
      'ER_3HBCOAHLm',      'ER_6THFtl',      'ER_7THFtl',      'ER_ACGAGBSIDEtg',
      'ER_ACGAGBSIDEtl',      'ER_ACNACNGAL14ACGLCGALGLUSIDEte',      'ER_ACNGALACGLCGAL14ACGLCGALGLUSIDEte',      'ER_ACNGALACGLCGAL14ACGLCGALGLUSIDEtg',
      'ER_ANDRSTRNte',      'ER_CO2tg',      'ER_COAtg',      'ER_CSBPASEly',
      'ER_CSCPASEly',      'ER_CSDPASEly',      'ER_CSPG_Btly',      'ER_CSPG_Ctly',
      'ER_CSPG_Dtly',      'ER_DKMPPD',      'ER_DM_dctp_n_',      'ER_DM_dgtp_n_',
      'ER_DSAT',      'ER_ENGASE3ly',      'ER_EX_10fthf[e]',      'ER_EX_10fthf5glu[e]',
      'ER_EX_10fthf6glu[e]',      'ER_EX_10fthf7glu[e]',      'ER_EX_35cgmp[e]',      'ER_EX_5dhf[e]',
      'ER_EX_5thf[e]',      'ER_EX_6dhf[e]',      'ER_EX_7dhf[e]',      'ER_EX_acnacngal14acglcgalgluside_hs[e]',
      'ER_EX_acngalacglcgal14acglcgalgluside_hs[e]',      'ER_EX_andrstrn[e]',      'ER_EX_camp[e]',      'ER_EX_cspg_b[e]',
      'ER_EX_dhf[e]',      'ER_EX_fucgal14acglcgalgluside_hs[e]',      'ER_EX_galgalfucfucgalacglcgalacglcgal14acglcgalgluside_hs[e]',      'ER_EX_glygn2[e]',
      'ER_EX_glygn4[e]',      'ER_EX_o2s[e]',      'ER_EX_oagd3_hs[e]',      'ER_EX_oagt3_hs[e]',
      'ER_EX_retn[e]',      'ER_EX_Rtotal3[e]',      'ER_EX_tmndnc[e]',      'ER_EX_xoltri24[e]',
      'ER_EX_xoltri27[e]',      'ER_FUCGAL14ACGLCGALGLUSIDEte',      'ER_FUCGAL14ACGLCGALGLUSIDEtg',      'ER_GALGALFUCFUCGALACGLCGALACGLCGAL14ACGLCGALGLUSIDEte',
      'ER_GALGALFUCFUCGALACGLCGALACGLCGAL14ACGLCGALGLUSIDEtg',      'ER_GLXtm',      'ER_GLYC3Ptm',      'ER_GLYCLTDym',
      'ER_ILEt5m',      'ER_KSII_CORE2tly',      'ER_KSII_CORE4tly',      'ER_KSItly',
      'ER_LEUt5m',      'ER_LINKDEG3ly',      'ER_MDRPD',      'ER_O2St',
      'ER_OAGD3te',      'ER_OAGD3tg',      'ER_OAGT3te',      'ER_PIK3n',
      'ER_PPAtm',      'ER_QUILSYN',      'ER_RADH',      'ER_RADH2',
      'ER_RAtn',      'ER_RETNt',      'ER_S2TASE4ly',      'ER_S2TASE5ly',
      'ER_UDPXYLter',      'ER_VALt5m',      'ER_XOLTRI24te',      'ER_XOLTRI27tc',
      'ER_XOLTRI27te',      'ER_EX_HC01440[e]',      'ER_EX_HC01441[e]',      'ER_EX_HC02160[e]',
      'ER_EX_HC02161[e]',      'ER_EX_prpp[e]',      'ER_r0841',      'ER_r0886',
      'ER_r1000',      'ER_r1109',      'ER_r1159',      'ER_r1301',
      'ER_r1302',      'ER_r1303',      'ER_r1304',      'ER_r2509',
      'ER_r2510',      'ER_r2514',      'ER_RE0124C',      'ER_RE0915C',
      'ER_RE0958C',      'ER_RE1234C',      'ER_RE1804C',      'ER_RE1826C',
      'ER_RE1919C',      'ER_RE1921C',      'ER_RE2080C',      'ER_RE2235C',
      'ER_RE2526C',      'ER_RE2625C',      'ER_RE2626C',      'ER_RE2974N',
      'ER_RE3033C',      'ER_RE3347C',      'ER_RE3434C',      'ER_RE3435C',
      'ER_RE3436C',      'ER_RE3437C',      'ER_RE3475C',      'ER_RE3485C',
      'ER_RE3493C',      'ER_EX_maltpt[e]',      'ER_EX_malthp[e]',      'ER_EX_CE2839[e]',
      'ER_EX_CE2838[e]',      'ER_EX_CE0074[e]',      'ER_C8DCe',      'ER_DOCOSACTDr',
      'ER_EX_3octdec2crn[e]',      'ER_EX_c51crn[e]',      'ER_EX_c8dc[e]',      'ER_HOCTDEC2CRNe',
      'ER_TDCRNe',      'ER_TIGCRNe',      'ER_DCTPtm',      'ER_EX_4hpro[e]',
      'ER_EX_oh1[e]',      'ER_GLU5SAtmc',      'ER_TTDCAFATPc',      'ER_3ANTHRNtr',
      'ER_EX_hcys_L[e]',      'ER_EX_3hanthrn[e]',      'ER_ARGSUCte',      'ER_EX_argsuc[e]',
      'ER_EX_acrn[e]',      'ER_DM_ascb_L[c]',      'ER_3HMPtd',      'ER_3MOXTYRt',
      'ER_ACLYSt',      'ER_ACLYStm',      'ER_C14825td',      'ER_EX_3hmp[e]',
      'ER_EX_aclys[e]',      'ER_EX_C14825[e]',      'ER_LYSACm',      'ER_HC00900t3',
      'ER_EX_3moxtyr[e]',      'ER_C05300t',      'ER_MALTTTRt',      'ER_EX_C05300[e]',
      'ER_EX_maltttr[e]',      'ER_ACRNtr',      'ER_PGPP_hsc',      'ER_DM_mi1345p[c]',
      'ER_DM_mi134p[c]',      'ER_DM_mi145p[c]',      'ER_DM_mi14p[c]',      'ER_HCYSte',
      'ER_UNK3r',      'ER_3HMPtm',      'ER_PGP_hs_tm',      'ER_PGLYCtm',
      'ER_sink_retfa[c]',      'ER_EX_glcn[e]',      'ER_G5SADs',      'ER_EX_malthx[e]',
      'ER_MTRI',      'ER_2M3HBUc',      'ER_2M3HBUtm',      'ER_2M3HBUte',
      'ER_EX_2m3hbu[e]',      'ER_3MGLUTACc',      'ER_3MGLUTACtm',      'ER_3MGLUTACte',
      'ER_EX_3mglutac[e]',      'ER_ETHMALCOAc',      'ER_ETHMALACc',      'ER_ETHMALACte',
      'ER_EX_ethmalac[e]',      'ER_PAIL_hs_SECt',      'ER_AGRMtm',      'ER_EX_agm[e]',
      'ER_EX_andrstandn[e]',      'ER_3ITYR_Lte',      'ER_EX_3ityr_L[e]',      'ER_35DIODTYRte',
      'ER_EX_35diotyr[e]',      'ER_LDL_HSDEG',      'ER_EX_CE7090[e]',      'ER_EX_CE7085[e]',
      'ER_EX_CE7096[e]',      'ER_EX_CE4877[e]',      'ER_EX_CE1447[e]',      'ER_GLCNte',
      'ER_EX_N1aspmd[e]',      'ER_EX_1a25dhvitd3[e]',      'ER_CE2049te',      'ER_EX_CE2049[e]',
      'ER_CE2047te',      'ER_EX_CE2047[e]',      'ER_EX_ldl_hs[e]',      'ER_EX_HC00005[e]',
      'ER_DOPAOQNOX',      'ER_DOPAOQCYS',      'ER_DACT',      'ER_CE5629t',
      'ER_EX_CE5629[e]',      'ER_EX_gd3_hs[e]',      'ER_GD3tg',      'ER_GD3tl',
      'ER_GLUSIDEte',      'ER_THCRMtl',      'ER_DM_6hddopaqn[c]',      'ER_GD3tlc',
      'ER_DM_retn[n]',      'ER_EX_pail_hs[e]',      'ER_HMR_0015',      'ER_HMR_0020',
      'ER_HMR_0763',      'ER_HMR_0771',      'ER_HMR_1744',      'ER_HMR_1745',
      'ER_HMR_1752',      'ER_HMR_1753',      'ER_HMR_1758',      'ER_HMR_1759',
      'ER_HMR_3053',      'ER_HMR_3056',      'ER_HMR_3597',      'ER_HMR_3953',
      'ER_HMR_7198',      'ER_HMR_8567',      'ER_HMR_9639',      'ER_EX_M00017[e]',
      'ER_EX_M00117[e]',      'ER_EX_M03051[e]',      'ER_EX_M02560[e]',      'ER_EX_M02446[e]',
      'ER_EX_M02447[e]',      'ER_EX_M02449[e]',      'ER_EX_M02451[e]',      'ER_DM_5cysdopa[c]'

    /

  genes_NCA(genes) "genes are not existed in CA model (HT only)"
    /
      '9123.1',      '47.1',      '47.2',      '11164.1',      '8705.1',      '51733.1',      '166785.1',      '9023.1',      '23539.1',      '51071.1',
      '2519.1',      '2271.1',      '2820.1',      '2583.1',      '2679.1',      '2678.3',      '2678.2',      '3067.1',      '3284.1',      '4200.1',
      '10873.1',      '6005.1',      '1584.1',      '1585.1',      '1589.1',      '57194.1',      '5244.3',      '5244.2',      '55163.1',      '5728.1',
      '8611.2',      '8869.1',      '259230.1',      '249.1',      '54020.1',      '93492.1',      '1357.1',      '1358.1',      '57094.1',      '93979.1',
      '6534.1',      '4524.1',      '360.1',      '364.1',      '89872.1',      '21.1',      '3248.1',      '166929.1',      '9843.1',      '3614.1',
      '3615.1',      '3614.2',      '682.1',      '58510.1',      '171425.1',      '171425.2',      '4953.1',      '10560.1',      '5205.1',      '57198.1',
      '10058.1',      '10928.1',      '3069.1',      '4864.1'

********** Non-GPR association genes ----------
      'GR_ACNACNGALGBSIDEte',      'GR_ACNACNGALGBSIDEtg',      'GR_AQCOBALt',      'GR_B3GALTg',
      'GR_BALAtmr',      'GR_C226COAtx',      'GR_CBL2OR',      'GR_CLPNDCOAtx',
      'GR_COUMARINte',      'GR_CRMPte',      'GR_CRTSTRNt',      'GR_D_3AIBt',
      'GR_DESAT22_2p',      'GR_DHPR2',      'GR_DM_gncore2_g_',      'GR_EX_3aib_D[e]',
      'GR_EX_acnacngalgbside_hs[e]',      'GR_EX_aprgstrn[e]',      'GR_EX_aqcobal[e]',      'GR_EX_avite1[e]',
      'GR_EX_coumarin[e]',      'GR_EX_crmp_hs[e]',      'GR_EX_crtstrn[e]',      'GR_EX_fuc14galacglcgalgluside_hs[e]',
      'GR_EX_fucfuc12gal14acglcgalgluside_hs[e]',      'GR_EX_fucfucgalacglcgalgluside_hs[e]',      'GR_EX_fuc_L[e]',      'GR_EX_gdp[e]',
      'GR_EX_gluala[e]',      'GR_EX_gmp[e]',      'GR_EX_gtp[e]',      'GR_EX_hcoumarin[e]',
      'GR_EX_hestratriol[e]',      'GR_EX_idp[e]',      'GR_EX_ksi_deg1[e]',      'GR_EX_lac_D[e]',
      'GR_EX_prgstrn[e]',      'GR_EX_s2l2fn2m2masn[e]',      'GR_EX_s2l2n2m2masn[e]',      'GR_EX_spc_hs[e]',
      'GR_EX_sph1p[e]',      'GR_EX_sphs1p[e]',      'GR_EX_srtn[e]',      'GR_EX_thym[e]',
      'GR_EX_udp[e]',      'GR_EX_xolest2_hs[e]',      'GR_F1Atg',      'GR_FRDPtr',
      'GR_FUC14GALACGLCGALGLUSIDEte',      'GR_FUC14GALACGLCGALGLUSIDEtg',      'GR_FUCFUC12GAL14ACGLCGALGLUSIDEte',      'GR_FUCFUC12GAL14ACGLCGALGLUSIDEtg',
      'GR_FUCFUCGALACGLCGALGLUSIDEte',      'GR_FUCFUCGALACGLCGALGLUSIDEtg',      'GR_GLACter',      'GR_GLYCK2',
      'GR_GTHDH',      'GR_HCOUMARINte',      'GR_HESTRATRIOLte',      'GR_HESTRATRIOLtr',
      'GR_IPDPtx',      'GR_MI134P4P',      'GR_MI13PP',      'GR_N4Tg',
      'GR_PAIL4P_HStn',      'GR_PCHOL_HStg',      'GR_PPAn',      'GR_PRGSTRNt',
      'GR_PRISTCOAtx',      'GR_S2L2FN2M2MASNtly',      'GR_S2L2N2M2MASNtly',      'GR_SPC_HSt',
      'GR_SPH1Pte',      'GR_SPHS1Pte',      'GR_TETHEX3COAtx',      'GR_TETPENT3COAtx',
      'GR_TETTET6COAtx',      'GR_TETTET6t',      'GR_TMNDNCt',      'GR_UROLACer',
      'GR_UTPtn',      'GR_EX_ahdt[e]',      'GR_EX_ctp[e]',      'GR_EX_dha[e]',
      'GR_EX_dtmp[e]',      'GR_EX_dttp[e]',      'GR_EX_HC01104[e]',      'GR_EX_HC01361[e]',
      'GR_r0365',      'GR_r1013',      'GR_r1088',      'GR_RE1711C',
      'GR_RE1915C',      'GR_RE1916C',      'GR_RE1978C',      'GR_RE2426C',
      'GR_RE2562C',      'GR_RE2563C',      'GR_RE2677N',      'GR_RE2799C',
      'GR_RE3016R',      'GR_RE3017R',      'GR_RE3180C',      'GR_RE3181C',
      'GR_RE3272N',      'GR_RE3422C',      'GR_EX_prostgi2[e]',      'GR_EX_cdp[e]',
      'GR_EX_dtdp[e]',      'GR_EX_CE5789[e]',      'GR_EX_CE5797[e]',      'GR_EX_CE5798[e]',
      'GR_C16DCe',      'GR_EX_c16dc[e]',      'GR_HEXDIACtr',      'GR_SUBEACtx',
      'GR_3AIB_Dtm',      'GR_ALA-DTDe',      'GR_EX_dchac[e]',      'GR_EX_sfcys[e]',
      'GR_INSK',      'GR_KHte',      'GR_SFCYSc',      'GR_SFCYSe',
      'GR_EX_5hoxindoa[e]',      'GR_PHLAC',      'GR_PHLACHt',      'GR_15KPROSTGF2t',
      'GR_3HPPt',      'GR_3UIBtd',      'GR_56DTHMt',      'GR_56DTHMtd',
      'GR_ADPACtd',      'GR_C11695td',      'GR_CE5304t',      'GR_CE6247t',
      'GR_EX_15kprostgf2[e]',      'GR_EX_3hpp[e]',      'GR_EX_3uib[e]',      'GR_EX_56dthm[e]',
      'GR_EX_adpac[e]',      'GR_EX_C11695[e]',      'GR_EX_CE5304[e]',      'GR_EX_CE6247[e]',
      'GR_EX_pchol2linl_hs[e]',      'GR_EX_pchol2ole_hs[e]',      'GR_EX_pchol2ste_hs[e]',      'GR_EX_pcholar_hs[e]',
      'GR_EX_pcholdoc_hs[e]',      'GR_EX_pcholeic_hs[e]',      'GR_EX_pcholet_hs[e]',      'GR_EX_pcholhep_hs[e]',
      'GR_EX_pchollinl_hs[e]',      'GR_EX_pcholmyr_hs[e]',      'GR_EX_pcholn15_hs[e]',      'GR_EX_pcholn183_hs[e]',
      'GR_EX_pcholn1836_hs[e]',      'GR_EX_pcholn19_hs[e]',      'GR_EX_pcholn201_hs[e]',      'GR_EX_pcholn203_hs[e]',
      'GR_EX_pcholn204_hs[e]',      'GR_EX_pcholn205_hs[e]',      'GR_EX_pcholn224_hs[e]',      'GR_EX_pcholn225_hs[e]',
      'GR_EX_pcholn2254_hs[e]',      'GR_EX_pcholn226_hs[e]',      'GR_EX_pcholn24_hs[e]',      'GR_EX_pcholole_hs[e]',
      'GR_EX_pcholpalm_hs[e]',      'GR_EX_pcholpalme_hs[e]',      'GR_EX_pcholste_hs[e]',      'GR_EX_sebacid[e]',
      'GR_EX_sphmyln180241_hs[e]',      'GR_EX_sphmyln18114_hs[e]',      'GR_EX_sphmyln18115_hs[e]',      'GR_EX_sphmyln18116_hs[e]',
      'GR_EX_sphmyln181161_hs[e]',      'GR_EX_sphmyln18117_hs[e]',      'GR_EX_sphmyln18118_hs[e]',      'GR_EX_sphmyln181181_hs[e]',
      'GR_EX_sphmyln18120_hs[e]',      'GR_EX_sphmyln181201_hs[e]',      'GR_EX_sphmyln18121_hs[e]',      'GR_EX_sphmyln18122_hs[e]',
      'GR_EX_sphmyln181221_hs[e]',      'GR_EX_sphmyln18123_hs[e]',      'GR_EX_sphmyln1824_hs[e]',      'GR_EX_sphmyln1825_hs[e]',
      'GR_PROSTGI2c',      'GR_SEBACIDtd',      'GR_EX_phlac[e]',      'GR_FldAct',
      'GR_MALOAtm',      'GR_FAS180',      'GR_S2L2N2M2Mt',      'GR_EX_s2l2n2m2m[e]',
      'GR_3HPPtm',      'GR_sink_avite1[c]',      'GR_sink_fad[c]',      'GR_sink_fe3[c]',
      'GR_EX_duri[e]',      'GR_EX_glcr[e]',      'GR_OAADC',      'GR_EX_pyr[e]',
      'GR_OBDHc',      'GR_EX_phpyr[e]',      'GR_PPIOGLYtm',      'GR_PPIOGLYte',
      'GR_EX_ppiogly[e]',      'GR_3HADPACx',      'GR_3HADPACtxc',      'GR_3HADPACte',
      'GR_EX_3hadpac[e]',      'GR_3OHSEBACx',      'GR_3OHSEBACtxc',      'GR_3OHSEBACte',
      'GR_EX_3ohsebac[e]',      'GR_3OHSUBACx',      'GR_3OHSUBACtxc',      'GR_3OHSUBACte',
      'GR_EX_3ohsubac[e]',      'GR_HEXGLYte',      'GR_EX_hexgly[e]',      'GR_SUBGLYte',
      'GR_EX_subgly[e]',      'GR_SPHMYLN180241_hs_SECt',      'GR_SPHMYLN18114_hs_SECt',      'GR_SPHMYLN18115_hs_SECt',
      'GR_SPHMYLN18116_hs_SECt',      'GR_SPHMYLN181161_hs_SECt',      'GR_SPHMYLN18117_hs_SECt',      'GR_SPHMYLN18118_hs_SECt',
      'GR_SPHMYLN181181_hs_SECt',      'GR_SPHMYLN18120_hs_SECt',      'GR_SPHMYLN181201_hs_SECt',      'GR_SPHMYLN18121_hs_SECt',
      'GR_SPHMYLN18122_hs_SECt',      'GR_SPHMYLN181221_hs_SECt',      'GR_SPHMYLN18123_hs_SECt',      'GR_SPHMYLN1824_hs_SECt',
      'GR_SPHMYLN1825_hs_SECt',      'GR_AK2LGCHOLt1',      'GR_PAFt1',      'GR_PCHOL2LINL_HSt1e',
      'GR_PCHOL2OLE_HSt1e',      'GR_PCHOL2STE_HSt1e',      'GR_PCHOLAR_HSt1e',      'GR_PCHOLDOC_HSt1e',
      'GR_PCHOLEIC_HSt1e',      'GR_PCHOLET_HSt1e',      'GR_PCHOLHEP_HSt1e',      'GR_PCHOLLINL_HSt1e',
      'GR_PCHOLMYR_Hst1e',      'GR_PCHOLN15_HSt1e',      'GR_PCHOLN183_HSt1e',      'GR_PCHOLN1836_HSt1e',
      'GR_PCHOLN19_HSt1e',      'GR_PCHOLN201_HSt1e',      'GR_PCHOLN203_HSt1e',      'GR_PCHOLN204_HSt1e',
      'GR_PCHOLN205_HSt1e',      'GR_PCHOLN224_HSt1e',      'GR_PCHOLN225_HSt1e',      'GR_PCHOLN2254_HSt1e',
      'GR_PCHLN225_HSt1e',      'GR_PCHOLN264_HSt1e',      'GR_PCHOLOLE_HSt1e',      'GR_PEPALM_HSt1e',
      'GR_PCHOLPALME-HSt1e',      'GR_PCHOLSTE_HSt1e',      'GR_ESTRONEte',      'GR_EX_estrone[e]',
      'GR_HC02020tr',      'GR_HC02020te',      'GR_EX_HC02020[e]',      'GR_XOL25OHtr',
      'GR_XOL25OHte',      'GR_EX_xol25oh[e]',      'GR_EX_CE6205[e]',      'GR_EX_CE1918[e]',
      'GR_C13856te',      'GR_CE1261t',      'GR_GM1tg',      'GR_UDPGALt2n',
      'GR_DAG_HStg',      'GR_GALSIDEtn',      'GR_CERT1tn',      'GR_GD1Atg',
      'GR_S2L2N2M2Mtl',      'GR_EX_CE5026[e]',      'GR_EX_CE1261[e]',      'GR_HMR_0912',
      'GR_HMR_0913',      'GR_HMR_2495',      'GR_HMR_4831',      'GR_HMR_7977',
      'GR_HMR_9184',      'GR_EX_nadh[e]',      'GR_1HMDZGLUChc',      'GR_4HMDGLUCtev',
      'GR_ATVLACh2r',      'GR_ATVLAChr',      'GR_EX_1hmdgluc[e]',      'GR_EX_2hatvlacgluc[e]',
      'GR_EX_4hmdgluc[e]',      'GR_EX_pvs[e]',      'GR_EX_tlacfvs[e]',      'GR_FVShc',
      'GR_IBUPGLUCtpvb',      'GR_PVSHtu',      'GR_PVStep',      'GR_TLACFVStev',
      'GR_1HMDGLUCitr',      'GR_2HATVLACGLUCitr',      'GR_3HPVSitr',      'GR_4HMDGLUCitr',
      'GR_PVSitr',      'GR_TLACFVSitr',      'GR_EX_C13856[e]',      'GR_EX_M01111[e]',
      'GR_EX_adpman[e]',      'GR_DM_hista[c]',      'GR_DM_cbl2[m]'
    /

  genes_NHT(genes) "genes are not existed in HT model (CA only)"
    /
      '117247.1',      '23498.1',      '10165.1',      '8604.1',      '9197.1',      '64841.1',      '6718.1',      '56301.1',      '113451.1',      '445.1',
      '445.2',      '10166.1',      '140679.1',      '8884.1',      '847.1',      '6547.6',      '6547.4',      '6547.2',      '6546.1',      '6547.1',
      '6547.5',      '6543.1',      '6547.3',      '6576.1',      '8140.1',      '2651.1',      '83733.1',      '79751.1',      '5226.1',      '80270.1',
      '7173.4',      '7173.3',      '7173.2',      '7173.5',      '587.1',      '11343.1',      '11343.2',      '9227.1',      '51477.1',      '4507.1',
      '123041.2',      '57419.1',      '9187.1',      '123041.3',      '25769.1',      '123041.1',      '1593.1',      '9420.1',      '9489.1',      '55361.1',
      '5297.1',      '5298.1',      '118881.1',      '9056.1',      '10402.1',      '29906.1',      '23530.2',      '23530.1',      '79178.1',      '6561.1',
      '84912.1',      '1356.1',      '2512.1',      '2495.1',      '94033.1',      '3251.1',      '50484.1',      '6240.1',      '6241.1',      '284111.1',
      '10057.1',      '84569.1',      '225.1',      '54716.1',      '120103.1',      '10057.2',      '949.1',      '29881.1',      '2673.1',      '9945.1',
      '112611.1',      '98.1',      '97.2',      '97.1',      '1728.1'

********** Non-GPR association genes ----------
      'GR_3HBCOAHLm',      'GR_6THFtl',      'GR_7THFtl',      'GR_ACGAGBSIDEtg',
      'GR_ACGAGBSIDEtl',      'GR_ACNACNGAL14ACGLCGALGLUSIDEte',      'GR_ACNGALACGLCGAL14ACGLCGALGLUSIDEte',      'GR_ACNGALACGLCGAL14ACGLCGALGLUSIDEtg',
      'GR_ANDRSTRNte',      'GR_CO2tg',      'GR_COAtg',      'GR_CSBPASEly',
      'GR_CSCPASEly',      'GR_CSDPASEly',      'GR_CSPG_Btly',      'GR_CSPG_Ctly',
      'GR_CSPG_Dtly',      'GR_DKMPPD',      'GR_DM_dctp_n_',      'GR_DM_dgtp_n_',
      'GR_DSAT',      'GR_ENGASE3ly',      'GR_EX_10fthf[e]',      'GR_EX_10fthf5glu[e]',
      'GR_EX_10fthf6glu[e]',      'GR_EX_10fthf7glu[e]',      'GR_EX_35cgmp[e]',      'GR_EX_5dhf[e]',
      'GR_EX_5thf[e]',      'GR_EX_6dhf[e]',      'GR_EX_7dhf[e]',      'GR_EX_acnacngal14acglcgalgluside_hs[e]',
      'GR_EX_acngalacglcgal14acglcgalgluside_hs[e]',      'GR_EX_andrstrn[e]',      'GR_EX_camp[e]',      'GR_EX_cspg_b[e]',
      'GR_EX_dhf[e]',      'GR_EX_fucgal14acglcgalgluside_hs[e]',      'GR_EX_galgalfucfucgalacglcgalacglcgal14acglcgalgluside_hs[e]',      'GR_EX_glygn2[e]',
      'GR_EX_glygn4[e]',      'GR_EX_o2s[e]',      'GR_EX_oagd3_hs[e]',      'GR_EX_oagt3_hs[e]',
      'GR_EX_retn[e]',      'GR_EX_Rtotal3[e]',      'GR_EX_tmndnc[e]',      'GR_EX_xoltri24[e]',
      'GR_EX_xoltri27[e]',      'GR_FUCGAL14ACGLCGALGLUSIDEte',      'GR_FUCGAL14ACGLCGALGLUSIDEtg',      'GR_GALGALFUCFUCGALACGLCGALACGLCGAL14ACGLCGALGLUSIDEte',
      'GR_GALGALFUCFUCGALACGLCGALACGLCGAL14ACGLCGALGLUSIDEtg',      'GR_GLXtm',      'GR_GLYC3Ptm',      'GR_GLYCLTDym',
      'GR_ILEt5m',      'GR_KSII_CORE2tly',      'GR_KSII_CORE4tly',      'GR_KSItly',
      'GR_LEUt5m',      'GR_LINKDEG3ly',      'GR_MDRPD',      'GR_O2St',
      'GR_OAGD3te',      'GR_OAGD3tg',      'GR_OAGT3te',      'GR_PIK3n',
      'GR_PPAtm',      'GR_QUILSYN',      'GR_RADH',      'GR_RADH2',
      'GR_RAtn',      'GR_RETNt',      'GR_S2TASE4ly',      'GR_S2TASE5ly',
      'GR_UDPXYLter',      'GR_VALt5m',      'GR_XOLTRI24te',      'GR_XOLTRI27tc',
      'GR_XOLTRI27te',      'GR_EX_HC01440[e]',      'GR_EX_HC01441[e]',      'GR_EX_HC02160[e]',
      'GR_EX_HC02161[e]',      'GR_EX_prpp[e]',      'GR_r0841',      'GR_r0886',
      'GR_r1000',      'GR_r1109',      'GR_r1159',      'GR_r1301',
      'GR_r1302',      'GR_r1303',      'GR_r1304',      'GR_r2509',
      'GR_r2510',      'GR_r2514',      'GR_RE0124C',      'GR_RE0915C',
      'GR_RE0958C',      'GR_RE1234C',      'GR_RE1804C',      'GR_RE1826C',
      'GR_RE1919C',      'GR_RE1921C',      'GR_RE2080C',      'GR_RE2235C',
      'GR_RE2526C',      'GR_RE2625C',      'GR_RE2626C',      'GR_RE2974N',
      'GR_RE3033C',      'GR_RE3347C',      'GR_RE3434C',      'GR_RE3435C',
      'GR_RE3436C',      'GR_RE3437C',      'GR_RE3475C',      'GR_RE3485C',
      'GR_RE3493C',      'GR_EX_maltpt[e]',      'GR_EX_malthp[e]',      'GR_EX_CE2839[e]',
      'GR_EX_CE2838[e]',      'GR_EX_CE0074[e]',      'GR_C8DCe',      'GR_DOCOSACTDr',
      'GR_EX_3octdec2crn[e]',      'GR_EX_c51crn[e]',      'GR_EX_c8dc[e]',      'GR_HOCTDEC2CRNe',
      'GR_TDCRNe',      'GR_TIGCRNe',      'GR_DCTPtm',      'GR_EX_4hpro[e]',
      'GR_EX_oh1[e]',      'GR_GLU5SAtmc',      'GR_TTDCAFATPc',      'GR_3ANTHRNtr',
      'GR_EX_hcys_L[e]',      'GR_EX_3hanthrn[e]',      'GR_ARGSUCte',      'GR_EX_argsuc[e]',
      'GR_EX_acrn[e]',      'GR_DM_ascb_L[c]',      'GR_3HMPtd',      'GR_3MOXTYRt',
      'GR_ACLYSt',      'GR_ACLYStm',      'GR_C14825td',      'GR_EX_3hmp[e]',
      'GR_EX_aclys[e]',      'GR_EX_C14825[e]',      'GR_LYSACm',      'GR_HC00900t3',
      'GR_EX_3moxtyr[e]',      'GR_C05300t',      'GR_MALTTTRt',      'GR_EX_C05300[e]',
      'GR_EX_maltttr[e]',      'GR_ACRNtr',      'GR_PGPP_hsc',      'GR_DM_mi1345p[c]',
      'GR_DM_mi134p[c]',      'GR_DM_mi145p[c]',      'GR_DM_mi14p[c]',      'GR_HCYSte',
      'GR_UNK3r',      'GR_3HMPtm',      'GR_PGP_hs_tm',      'GR_PGLYCtm',
      'GR_sink_retfa[c]',      'GR_EX_glcn[e]',      'GR_G5SADs',      'GR_EX_malthx[e]',
      'GR_MTRI',      'GR_2M3HBUc',      'GR_2M3HBUtm',      'GR_2M3HBUte',
      'GR_EX_2m3hbu[e]',      'GR_3MGLUTACc',      'GR_3MGLUTACtm',      'GR_3MGLUTACte',
      'GR_EX_3mglutac[e]',      'GR_ETHMALCOAc',      'GR_ETHMALACc',      'GR_ETHMALACte',
      'GR_EX_ethmalac[e]',      'GR_PAIL_hs_SECt',      'GR_AGRMtm',      'GR_EX_agm[e]',
      'GR_EX_andrstandn[e]',      'GR_3ITYR_Lte',      'GR_EX_3ityr_L[e]',      'GR_35DIODTYRte',
      'GR_EX_35diotyr[e]',      'GR_LDL_HSDEG',      'GR_EX_CE7090[e]',      'GR_EX_CE7085[e]',
      'GR_EX_CE7096[e]',      'GR_EX_CE4877[e]',      'GR_EX_CE1447[e]',      'GR_GLCNte',
      'GR_EX_N1aspmd[e]',      'GR_EX_1a25dhvitd3[e]',      'GR_CE2049te',      'GR_EX_CE2049[e]',
      'GR_CE2047te',      'GR_EX_CE2047[e]',      'GR_EX_ldl_hs[e]',      'GR_EX_HC00005[e]',
      'GR_DOPAOQNOX',      'GR_DOPAOQCYS',      'GR_DACT',      'GR_CE5629t',
      'GR_EX_CE5629[e]',      'GR_EX_gd3_hs[e]',      'GR_GD3tg',      'GR_GD3tl',
      'GR_GLUSIDEte',      'GR_THCRMtl',      'GR_DM_6hddopaqn[c]',      'GR_GD3tlc',
      'GR_DM_retn[n]',      'GR_EX_pail_hs[e]',      'GR_HMR_0015',      'GR_HMR_0020',
      'GR_HMR_0763',      'GR_HMR_0771',      'GR_HMR_1744',      'GR_HMR_1745',
      'GR_HMR_1752',      'GR_HMR_1753',      'GR_HMR_1758',      'GR_HMR_1759',
      'GR_HMR_3053',      'GR_HMR_3056',      'GR_HMR_3597',      'GR_HMR_3953',
      'GR_HMR_7198',      'GR_HMR_8567',      'GR_HMR_9639',      'GR_EX_M00017[e]',
      'GR_EX_M00117[e]',      'GR_EX_M03051[e]',      'GR_EX_M02560[e]',      'GR_EX_M02446[e]',
      'GR_EX_M02447[e]',      'GR_EX_M02449[e]',      'GR_EX_M02451[e]',      'GR_DM_5cysdopa[c]'

    /

  enzyme_Reg_rxn_v(universalSet, reactions) "reactions are regulated by each enzyme in BL model"
   /
    'E0001'. ('R_13DAMPPOX', 'R_42A12BOOX', 'R_MAOX', 'R_MHISOR', 'R_PTRCOX1')
    'E0002'. ('R_13DAMPPOX', 'R_42A12BOOX', 'R_MAOX', 'R_PEAMNO', 'R_TRYPTAOX')
    'E0003'. ('R_13DAMPPOX', 'R_42A12BOOX', 'R_HISTASE', 'R_MAOX', 'R_MHISOR', 'R_PEAMNO',
              'R_PTRCOX1', 'R_TRYPTAOX')
    'E0004'. ('R_13DAMPPOX', 'R_42A12BOOX', 'R_HISTASE', 'R_MAOX', 'R_TRYPTAOX')
    'E0006'. ('R_25VITD2Hm', 'R_25VITD3Hm', 'R_25HVITD3c')
    'E0007'. ('R_2AMACHYD', 'R_SERHL', 'R_r0060', 'R_THRD_L')
    'E0008'. ('R_2AMACSULT', 'R_5ADTSTSTERONESULT', 'R_CHSTEROLSULT', 'R_DHEASULT', 'R_ESTSULT', 'R_NRPPHRSULT',
              'R_TRIODTHYSULT', 'R_TSTSTERONESULT', 'R_RE0912C', 'R_RE3009C', 'R_HMR_6838', 'R_HMR_6844',
              'R_HMR_6850')
    'E0009'. ('R_2AMADPTm', 'R_2OXOADPTm', 'R_r0879')
    'E0010'. ('R_2HBO', 'R_HPYRR2x', 'R_GLXO1', 'R_LDH_L', 'R_2H3MVc', 'R_2HIVc')
    'E0012'. ('R_2HBO', 'R_GLXO1', 'R_LDH_L', 'R_2H3MVc', 'R_2HIVc')
    'E0014'. ('R_2HBO', 'R_HPYRR2x', 'R_LDH_Lm', 'R_r0173', 'R_GLXO1', 'R_LDH_L',
              'R_2H3MVc', 'R_2HIVc')
    'E0017'. ('R_2HBO', 'R_HPYRR2x', 'R_r0173', 'R_GLXO1', 'R_LDH_L', 'R_2H3MVc',
              'R_2HIVc')
    'E0018'. ('R_2HBt2', 'R_ACETONEt2', 'R_D_LACt2', 'R_L_LACt2r', 'R_PYRt2r', 'R_PHPYRte')
    'E0019'. ('R_2HBt2', 'R_ACETONEt2', 'R_D_LACt2', 'R_PYRt2p', 'R_r1155', 'R_r1454',
              'R_ACACt2', 'R_L_LACt2r', 'R_PYRt2r', 'R_PHPYRte', 'R_2OBUTt')
    'E0020'. ('R_2HBt2', 'R_ACETONEt2', 'R_BTNt2', 'R_D_LACt2', 'R_PYRt2p', 'R_r1155',
              'R_r1454', 'R_r2085', 'R_r2091', 'R_ACACt2', 'R_L_LACt2r', 'R_PYRt2r',
              'R_PHPYRte')
    'E0026'. ('R_2OXOADOXm')
    'E0028'. ('R_34DHOXPEGOX', 'R_ALCD21_D', 'R_ALCD21_L', 'R_ALCD22_D', 'R_ALCD22_L', 'R_ALCD2if',
              'R_r0739', 'R_ALCD1', 'R_HMR_6633')
    'E0030'. ('R_34DHOXPEGOX', 'R_ALCD21_D', 'R_ALCD21_L', 'R_ALCD22_D', 'R_ALCD22_L', 'R_ALCD2if',
              'R_ALCD1')
    'E0033'. ('R_34DHOXPEGOX', 'R_ALCD21_D', 'R_ALCD21_L', 'R_ALCD22_D', 'R_ALCD22_L', 'R_ALCD2if',
              'R_FALDH', 'R_LALDO', 'R_r0739', 'R_r1378', 'R_ALCD1', 'R_HMR_6633')
    'E0034'. ('R_34DHOXPEGOX', 'R_ALCD21_D', 'R_ALCD21_L', 'R_ALCD22_D', 'R_ALCD22_L', 'R_ALCD2if',
              'R_RE3011M', 'R_ALCD1', 'R_HMR_6633')
    'E0036'. ('R_34DHPHAMT', 'R_DOPAMT', 'R_SALMCOM', 'R_HMR_6755')
    'E0037'. ('R_34DHPHAMT', 'R_DOPAMT', 'R_SALMCOM')
    'E0038'. ('R_TRPt')
    'E0039'. ('R_34DHPLACOX', 'R_34DHPLACOX_NADP_', 'R_3MOX4HOXPGALDOX', 'R_3MOX4HOXPGALDOX_NADP_', 'R_4HOXPACDOX_NADP_', 'R_ALDD2y',
              'R_GLACO', 'R_LCADi_D', 'R_MACOXO', 'R_r0545', 'R_r0546', 'R_r0547',
              'R_r0548', 'R_r0752', 'R_r0753', 'R_r0754', 'R_r0755', 'R_r0756',
              'R_r0757', 'R_RE3012R', 'R_GCALDD', 'R_ALDD2x', 'R_LCADi', 'R_HMR_6790')
    'E0040'. ('R_34DHPLACOX', 'R_34DHPLACOX_NADP_', 'R_34DHXMANDACOX_NADP_', 'R_3MOX4HOXPGALDOX', 'R_3MOX4HOXPGALDOX_NADP_', 'R_4HOXPACDOX_NADP_',
              'R_ALDD2y', 'R_GLACO', 'R_LCADi_D', 'R_MACOXO', 'R_r0545', 'R_r0546',
              'R_r0547', 'R_r0548', 'R_r0752', 'R_r0753', 'R_r0754', 'R_r0755',
              'R_r0756', 'R_r0757', 'R_GCALDD', 'R_ALDD2x', 'R_LCADi', 'R_HMR_6790')
    'E0041'. ('R_34DHPLACOX', 'R_3MOX4HOXPGALDOX', 'R_3MOX4HOXPGALDOX_NADP_', 'R_4HOXPACDOX_NADP_', 'R_GLACO', 'R_LCADi_D',
              'R_MACOXO', 'R_r0545', 'R_r0546', 'R_r0547', 'R_r0548', 'R_r0752',
              'R_r0753', 'R_r0754', 'R_r0755', 'R_r0756', 'R_r0757', 'R_GCALDD',
              'R_ALDD2x', 'R_LCADi', 'R_HMR_6790')
    'E0043'. ('R_34HPPOR')
    'E0044'. ('R_3AIBTm', 'R_3AIBtmi', 'R_ABTArm', 'R_APAT2rm', 'R_r0483')
    'E0045'. ('R_3AIBTm', 'R_3AIBtmi', 'R_ABTArm', 'R_APAT2rm')
    'E0047'. ('R_3HAO')
    'E0048'. ('R_3HBCDm')
    'E0049'. ('R_3HKYNAKGAT', 'R_AATAi', 'R_KYNAKGAT', 'R_r0450')
    'E0050'. ('R_3HKYNAKGAT', 'R_KYNAKGAT', 'R_RE1233C', 'R_RE2349C')
    'E0051'. ('R_3HKYNAKGAT', 'R_AATAi', 'R_KYNAKGAT')
    'E0052'. ('R_5HLTDL', 'R_HISDC', 'R_LTDCL', 'R_PHYCBOXL')
    'E0053'. ('R_41R1H2MAE12BOOX', 'R_42A12BOOX', 'R_5HOXINOXDA', 'R_MAOLNOR', 'R_PEAMNO', 'R_TRYPTAOX',
              'R_HMR_6747')
    'E0054'. ('R_41R1H2MAE12BOOX', 'R_42A12BOOX', 'R_5HOXINOXDA', 'R_MACOXO', 'R_MAOLNOR', 'R_PEAMNO',
              'R_TRYPTAOX', 'R_HMR_6747')
    'E0055'. ('R_GLUt2m')
    'E0057'. ('R_LCYSTCBOXL')
    'E0058'. ('R_GLUDC', 'R_LCYSTCBOXL')
    'E0063'. ('R_ALDD20xm', 'R_GCALDDm', 'R_LCADim', 'R_P5CDm')
    'E0065'. ('R_4NPHSULT', 'R_DOPASULT')
    'E0066'. ('R_4NPHSULT', 'R_DOPASULT', 'R_ESTSULT', 'R_TRIODTHYSULT')
    'E0068'. ('R_4NPHSULT', 'R_DOPASULT', 'R_NRPPHRSULT')
    'E0074'. ('R_FOLABCCte', 'R_CE7090te', 'R_CE7085te', 'R_CE7096te', 'R_CE4877te', 'R_CE1447te',
              'R_SPHS1Pt2e', 'R_MLTHFte1', 'R_CE5026t')
    'E0075'. ('R_5ADTSTSTERONESULT', 'R_DHEASULT', 'R_TSTSTERONESULT')
    'E0076'. ('R_5FTHFt2', 'R_5MTHFt2', 'R_FOLt2', 'R_THFt2', 'R_THMTPt', 'R_MLTHFte2')
    'E0079'. ('R_5HTRPVESSEC')
    'E0081'. ('R_5MTHFt')
    'E0083'. ('R_5MTHFt', 'R_r0963', 'R_MLTHFte3')
    'E0088'. ('R_A_MANASEly')
    'E0089'. ('R_A4GALTg')
    'E0090'. ('R_A4GNT2g', 'R_HMR_0765')
    'E0091'. ('R_ABO9g', 'R_HMR_0867', 'R_HMR_0868')
    'E0092'. ('R_ABUTt2rL', 'R_DALAt2r', 'R_PRODt2r', 'R_r2471', 'R_BALAPAT1tc', 'R_TAUPAT1c',
              'R_PROt2r', 'R_GLYt2r', 'R_ALAt2r', 'R_ABUTt2r')
    'E0093'. ('R_ABUTt4_2_r', 'R_HMR_9613')
    'E0096'. ('R_ABUTt4_2_r')
    'E0098'. ('R_RE0512M', 'R_RE1520M', 'R_RE1521M', 'R_RE1522M', 'R_RE1523M', 'R_RE1531M',
              'R_RE1532M', 'R_RE1533M', 'R_RE1534M', 'R_RE3004M', 'R_RE3006M', 'R_RE3177M',
              'R_RE3178M', 'R_RE3179M', 'R_RE3189M', 'R_RE3190M', 'R_RE3191M', 'R_RE3192M',
              'R_RE3193M', 'R_RE3194M', 'R_HMR_3110', 'R_HMR_3114', 'R_HMR_3118', 'R_HMR_3173',
              'R_HMR_3177', 'R_HMR_3181', 'R_HMR_3185', 'R_HMR_3189', 'R_HMR_3193', 'R_HMR_3197',
              'R_HMR_3201', 'R_HMR_3205', 'R_HMR_3221', 'R_HMR_3225', 'R_HMR_3229', 'R_HMR_3233',
              'R_HMR_3237', 'R_HMR_3243', 'R_HMR_3247', 'R_HMR_3398', 'R_HMR_3406', 'R_HMR_3407',
              'R_HMR_3408', 'R_HMR_3409', 'R_HMR_3411', 'R_HMR_3413', 'R_HMR_3414', 'R_HMR_3416',
              'R_HMR_3421', 'R_HMR_3422', 'R_HMR_3423', 'R_HMR_3424', 'R_HMR_3425', 'R_HMR_3426',
              'R_HMR_3427', 'R_HMR_3428', 'R_HMR_3429', 'R_HMR_3431', 'R_HMR_3432', 'R_HMR_3433',
              'R_HMR_3451', 'R_HMR_3455', 'R_HMR_9719', 'R_3HPVSTETCOAhcm')
    'E0099'. ('R_RE1531M', 'R_RE1532M', 'R_RE1533M', 'R_RE1534M', 'R_RE3006M', 'R_RE3189M',
              'R_RE3190M', 'R_RE3191M', 'R_HMR_3110', 'R_HMR_3114', 'R_HMR_3118', 'R_HMR_3173',
              'R_HMR_3177', 'R_HMR_3181', 'R_HMR_3185', 'R_HMR_3189', 'R_HMR_3193', 'R_HMR_3197',
              'R_HMR_3201', 'R_HMR_3205', 'R_HMR_3221', 'R_HMR_3225', 'R_HMR_3229', 'R_HMR_3233',
              'R_HMR_3237', 'R_HMR_3243', 'R_HMR_3247', 'R_HMR_3398', 'R_HMR_3406', 'R_HMR_3407',
              'R_HMR_3408', 'R_HMR_3409', 'R_HMR_3411', 'R_HMR_3413', 'R_HMR_3414', 'R_HMR_3416',
              'R_HMR_3421', 'R_HMR_3422', 'R_HMR_3423', 'R_HMR_3424', 'R_HMR_3425', 'R_HMR_3426',
              'R_HMR_3427', 'R_HMR_3428', 'R_HMR_3429', 'R_HMR_3431', 'R_HMR_3432', 'R_HMR_3433',
              'R_HMR_3451', 'R_HMR_3455', 'R_HMR_9719')
    'E0100'. ('R_ECOAH12m', 'R_ECOAH1m', 'R_ECOAH9m', 'R_HACD1m', 'R_FAOXC163GC142m', 'R_FAOXC184C163m',
              'R_FAOXC225C204m')
    'E0101'. ('R_ACACT1x', 'R_ACACT1r')
    'E0102'. ('R_ACACT6p', 'R_ACACT8p', 'R_ACACT9p', 'R_RE1531X', 'R_RE1532X', 'R_RE1533X',
              'R_RE1534X', 'R_RE2988X', 'R_RE2989X', 'R_RE3158X', 'R_HMR_1653', 'R_HMR_3065',
              'R_HMR_3069', 'R_HMR_3073', 'R_HMR_3097', 'R_HMR_3101', 'R_HMR_3329', 'R_HMR_3333',
              'R_HMR_3337', 'R_HMR_3341', 'R_HMR_3345', 'R_HMR_3349', 'R_HMR_3353', 'R_HMR_3398',
              'R_HMR_3406', 'R_HMR_3407', 'R_HMR_3408', 'R_HMR_3409', 'R_HMR_3411', 'R_HMR_3413',
              'R_HMR_3414', 'R_HMR_3416', 'R_HMR_3421', 'R_HMR_3422', 'R_HMR_3423', 'R_HMR_3424',
              'R_HMR_3425', 'R_HMR_3426', 'R_HMR_3427', 'R_HMR_3428', 'R_HMR_3429', 'R_HMR_3431',
              'R_HMR_3432', 'R_HMR_3433', 'R_HMR_3505', 'R_HMR_9719', 'R_3HPVSTETCOAhcx', 'R_DEOXFVShc',
              'R_PROFVSCOAhc')
    'E0104'. ('R_ACCOAgt', 'R_GAO1', 'R_GAO1g', 'R_GAO2')
    'E0105'. ('R_ACCOALm', 'R_r0221', 'R_r0319', 'R_r0220', 'R_r0318')
    'E0107'. ('R_ACGAM6PSi')
    'E0108'. ('R_ACGAMK', 'R_AMANK')
    'E0109'. ('R_ACGAMPM')
    'E0110'. ('R_ACGPID')
    'E0111'. ('R_ACGSm', 'R_RE2030M', 'R_RE2223M')
    'E0112'. ('R_HMR_0641')
    'E0114'. ('R_ACHVESSEC')
    'E0115'. ('R_ACITL')
    'E0117'. ('R_ACNAM9PL', 'R_ACNAM9PL2')
    'E0118'. ('R_ACNAMlt', 'R_GLCURtly', 'R_IDOURtly')
    'E0119'. ('R_ACNAMPH')
    'E0120'. ('R_ACNAMPH', 'R_ACP1_FMN_', 'R_LAPCOAl', 'R_NTD2l', 'R_HMR_4270')
    'E0122'. ('R_ACOAD10m', 'R_ACOAD1fm', 'R_RE3185M', 'R_RE3186M', 'R_HMR_3156', 'R_HMR_3202')
    'E0123'. ('R_ACOAD10m', 'R_ACOAD1fm', 'R_ACOAD9m', 'R_FAOXC140', 'R_FAOXC160', 'R_FAOXC226',
              'R_FAOXC226205m', 'R_FAOXC80', 'R_r0310', 'R_r0655', 'R_RE3185M', 'R_RE3186M',
              'R_FAOXC101C102m', 'R_FAOXC102C103m', 'R_HMR_3107', 'R_HMR_3111', 'R_HMR_3115', 'R_HMR_3121',
              'R_HMR_3128', 'R_HMR_3135', 'R_HMR_3142', 'R_HMR_3149', 'R_HMR_3170', 'R_HMR_3174',
              'R_HMR_3178', 'R_HMR_3182', 'R_HMR_3186', 'R_HMR_3190', 'R_HMR_3194', 'R_HMR_3198',
              'R_HMR_3218', 'R_HMR_3222', 'R_HMR_3230', 'R_HMR_3234', 'R_HMR_3240', 'R_HMR_3244',
              'R_HMR_3398', 'R_HMR_3406', 'R_HMR_3407', 'R_HMR_3408', 'R_HMR_3409', 'R_HMR_3411',
              'R_HMR_3413', 'R_HMR_3414', 'R_HMR_3416', 'R_HMR_3421', 'R_HMR_3422', 'R_HMR_3423',
              'R_HMR_3424', 'R_HMR_3425', 'R_HMR_3426', 'R_HMR_3427', 'R_HMR_3428', 'R_HMR_3429',
              'R_HMR_3431', 'R_HMR_3432', 'R_HMR_3433', 'R_HMR_3448', 'R_HMR_3452', 'R_HMR_3456',
              'R_HMR_3522', 'R_HMR_9719')
    'E0124'. ('R_ACOAD1fm')
    'E0125'. ('R_ACOAD1fm', 'R_FAOXC140', 'R_FAOXC160', 'R_FAOXC226', 'R_FAOXC226205m', 'R_FAOXC80')
    'E0127'. ('R_ACOAD1fm', 'R_ACOAD9m')
    'E0128'. ('R_ACOAD1fm', 'R_r0706', 'R_HMR_3107', 'R_HMR_3111', 'R_HMR_3115', 'R_HMR_3121',
              'R_HMR_3128', 'R_HMR_3135', 'R_HMR_3142', 'R_HMR_3149', 'R_HMR_3170', 'R_HMR_3174',
              'R_HMR_3178', 'R_HMR_3182', 'R_HMR_3186', 'R_HMR_3190', 'R_HMR_3194', 'R_HMR_3198',
              'R_HMR_3218', 'R_HMR_3222', 'R_HMR_3230', 'R_HMR_3234', 'R_HMR_3240', 'R_HMR_3244',
              'R_HMR_3398', 'R_HMR_3406', 'R_HMR_3407', 'R_HMR_3408', 'R_HMR_3409', 'R_HMR_3411',
              'R_HMR_3413', 'R_HMR_3414', 'R_HMR_3416', 'R_HMR_3421', 'R_HMR_3422', 'R_HMR_3423',
              'R_HMR_3424', 'R_HMR_3425', 'R_HMR_3426', 'R_HMR_3427', 'R_HMR_3428', 'R_HMR_3429',
              'R_HMR_3431', 'R_HMR_3432', 'R_HMR_3433', 'R_HMR_3448', 'R_HMR_3452', 'R_HMR_3456',
              'R_HMR_9719')
    'E0129'. ('R_ACOAD8m', 'R_r0655')
    'E0131'. ('R_ACOAO7p', 'R_r0310', 'R_r1443', 'R_r1444', 'R_r1445', 'R_r1446',
              'R_r1447', 'R_r1448', 'R_r1449', 'R_r1450', 'R_r1451', 'R_RE1516M',
              'R_RE1516X', 'R_RE1517M', 'R_RE1517X', 'R_RE1518M', 'R_RE1518X', 'R_RE1519X',
              'R_RE2985M', 'R_RE2985X', 'R_RE2994X', 'R_RE2997X', 'R_RE2998M', 'R_RE3086X',
              'R_RE3157X', 'R_RE3247M', 'R_RE3624M', 'R_RE3626M', 'R_FAOXC101C102m', 'R_FAOXC101C102x',
              'R_FAOXC102C103x', 'R_FAOXC163C164x', 'R_FAOXC164C165x', 'R_FAOXC204C205x', 'R_FAOXC225C226x', 'R_HMR_1637',
              'R_HMR_3057', 'R_HMR_3062', 'R_HMR_3066', 'R_HMR_3070', 'R_HMR_3074', 'R_HMR_3094',
              'R_HMR_3098', 'R_HMR_3102', 'R_HMR_3321', 'R_HMR_3326', 'R_HMR_3330', 'R_HMR_3334',
              'R_HMR_3338', 'R_HMR_3342', 'R_HMR_3346', 'R_HMR_3350', 'R_3HPVSTETCOAhcx', 'R_DEOXFVShc',
              'R_PROFVSCOAhc')
    'E0132'. ('R_ACOAO7p')
    'E0134'. ('R_ACONTm', 'R_r0317', 'R_r0426')
    'E0135'. ('R_ACONTm', 'R_r0317', 'R_r0426', 'R_ACONT')
    'E0136'. ('R_RE2985X', 'R_RE2994X', 'R_RE2997X', 'R_RE3086X', 'R_RE3157X')
    'E0137'. ('R_ACP1_FMN_', 'R_FMNALKPle', 'R_HMR_4270')
    'E0138'. ('R_ACP1_FMN_', 'R_FMNALKPle')
    'E0140'. ('R_ACP1_FMN_', 'R_LAPCOAl', 'R_NTD2l', 'R_HMR_4270')
    'E0141'. ('R_C160CRNt', 'R_C181CRNt', 'R_LNLNCACRNt', 'R_r2435', 'R_r2436', 'R_C10DCCACT',
              'R_C4tcx', 'R_C6DCCACT', 'R_OCTDECCACT', 'R_SUBERCACT', 'R_HMR_2603', 'R_HMR_2609',
              'R_HMR_2612', 'R_HMR_2621', 'R_HMR_2624', 'R_HMR_2634', 'R_HMR_2644', 'R_HMR_2649',
              'R_HMR_2652', 'R_HMR_2655', 'R_HMR_2661', 'R_HMR_2667', 'R_HMR_2670', 'R_HMR_2673',
              'R_HMR_2676', 'R_HMR_2679', 'R_HMR_2682', 'R_HMR_2685', 'R_HMR_2688', 'R_HMR_2691',
              'R_HMR_2695', 'R_HMR_2700', 'R_HMR_2703', 'R_HMR_2706', 'R_HMR_2709', 'R_HMR_2712',
              'R_HMR_2715', 'R_HMR_2718', 'R_HMR_2722', 'R_HMR_2727', 'R_HMR_2731', 'R_HMR_2734',
              'R_HMR_2737', 'R_HMR_2740', 'R_HMR_2744', 'R_HMR_2748', 'R_HMR_2753', 'R_HMR_2757',
              'R_HMR_2760', 'R_HMR_2764', 'R_HMR_2769', 'R_HMR_2772', 'R_HMR_2775')
    'E0142'. ('R_ACS2', 'R_r0221', 'R_r0319', 'R_ACCOAL', 'R_ACS', 'R_r0220',
              'R_r0318')
    'E0143'. ('R_ACS2', 'R_r0321', 'R_ACS', 'R_AACOAT')
    'E0144'. ('R_ACS2', 'R_ACCOAL', 'R_ACS')
    'E0146'. ('R_ACTLMO', 'R_ACTNMO', 'R_ETOHMO', 'R_P4502E1', 'R_RE2235R', 'R_HMR_0942',
              'R_HMR_0946', 'R_HMR_0950', 'R_HMR_0954', 'R_HMR_2029', 'R_HMR_2457', 'R_3OHACMPhr')
    'E0148'. ('R_ADEt', 'R_ADNt', 'R_CSNt', 'R_CYTDt', 'R_DADNt4', 'R_DCYTt',
              'R_DGSNt', 'R_DINt', 'R_DURIt', 'R_GSNt', 'R_INSt', 'R_THYMDt1',
              'R_THYMt', 'R_URAt', 'R_URIt', 'R_GUAt', 'R_HYXNt', 'R_CE2705t',
              'R_HMR_8475', 'R_HMR_8476')
    'E0149'. ('R_ADK1m')
    'E0150'. ('R_ADK1m', 'R_r0345')
    'E0151'. ('R_ADK1m', 'R_ADK1', 'R_r0345')
    'E0155'. ('R_ADK3', 'R_ADKd', 'R_CYTK3', 'R_CYTK4', 'R_ADK1', 'R_r0345')
    'E0156'. ('R_ADK3', 'R_ADKd', 'R_CYTK3', 'R_CYTK4', 'R_ADK1')
    'E0159'. ('R_ADNCYC')
    'E0170'. ('R_ADNt', 'R_ADNtm', 'R_CYTDt', 'R_CYTDtm', 'R_GSNt', 'R_INSt',
              'R_THYMDt1', 'R_THYMDtm', 'R_URIt', 'R_CE2705t', 'R_HMR_8475', 'R_HMR_8476')
    'E0171'. ('R_ADNt4', 'R_CYTDt4', 'R_URIt4')
    'E0172'. ('R_ADNt4', 'R_CYTDt4', 'R_URIt4', 'R_r1043', 'R_r1044')
    'E0173'. ('R_ADNt4', 'R_CYTDt4', 'R_URIt4', 'R_r1043', 'R_r1044', 'R_r1045',
              'R_HMR_6359', 'R_HMR_6363', 'R_HMR_6364')
    'E0174'. ('R_ADNt4', 'R_URIt4', 'R_r1045')
    'E0175'. ('R_Uritl')
    'E0176'. ('R_ADPMAN', 'R_ADPRDP')
    'E0177'. ('R_ADPRIBt', 'R_NADNe', 'R_NADPNe')
    'E0178'. ('R_ADRNCPT1', 'R_ARACHCPT1', 'R_C160CPT1', 'R_C161CPT1', 'R_C161CPT12', 'R_C180CPT1',
              'R_C181CPT1', 'R_C204CPT1', 'R_C226CPT1', 'R_CLPNDCPT1', 'R_DCSPTN1CPT1', 'R_DLNLCGCPT1',
              'R_EICOSTETCPT1', 'R_ELAIDCPT1', 'R_HPDCACRNCPT1', 'R_LNELDCCPT1', 'R_LNLCCPT1', 'R_LNLNCACPT1',
              'R_LNLNCGCPT1', 'R_PTDCACRNCPT1', 'R_STRDNCCPT1', 'R_TMNDNCCPT1', 'R_C100CPT1', 'R_C101CPT1',
              'R_C102CPT1', 'R_C10DCc', 'R_C10OHc', 'R_C120CPT1', 'R_C121CPT1', 'R_C12OHc',
              'R_C140CPT1', 'R_C141CPT1', 'R_C142CPT1', 'R_C14OHc', 'R_C16DCc', 'R_C181OHc',
              'R_C182OHc', 'R_C30CPT1', 'R_C40CPT1', 'R_C4OHc', 'R_C51CPT1', 'R_C60CPT1',
              'R_C6DCc', 'R_C80CPT1', 'R_C81CPT1', 'R_C8DCc', 'R_FAOXC12DCc', 'R_FAOXC3DC',
              'R_FAOXC4C4DCc', 'R_OCTDECCPT1', 'R_HMR_2602', 'R_HMR_2608', 'R_HMR_2611', 'R_HMR_2620',
              'R_HMR_2633', 'R_HMR_2648', 'R_HMR_2651', 'R_HMR_2657', 'R_HMR_2660', 'R_HMR_2666',
              'R_HMR_2669', 'R_HMR_2675', 'R_HMR_2681', 'R_HMR_2684', 'R_HMR_2687', 'R_HMR_2690',
              'R_HMR_2693', 'R_HMR_2699', 'R_HMR_2702', 'R_HMR_2705', 'R_HMR_2708', 'R_HMR_2711',
              'R_HMR_2733', 'R_HMR_2736', 'R_HMR_2739', 'R_HMR_2768', 'R_HMR_2771', 'R_HMR_2774')
    'E0179'. ('R_ADRNCPT1', 'R_ARACHCPT1', 'R_C160CPT1', 'R_C161CPT1', 'R_C161CPT12', 'R_C180CPT1',
              'R_C181CPT1', 'R_C204CPT1', 'R_C226CPT1', 'R_CLPNDCPT1', 'R_DCSPTN1CPT1', 'R_DLNLCGCPT1',
              'R_EICOSTETCPT1', 'R_ELAIDCPT1', 'R_HPDCACRNCPT1', 'R_LNELDCCPT1', 'R_LNLCCPT1', 'R_LNLNCACPT1',
              'R_LNLNCGCPT1', 'R_PTDCACRNCPT1', 'R_STRDNCCPT1', 'R_TMNDNCCPT1')
    'E0180'. ('R_ADRNCPT1', 'R_ARACHCPT1', 'R_C161CPT1', 'R_C161CPT12', 'R_C180CPT1', 'R_C181CPT1',
              'R_C204CPT1', 'R_C226CPT1', 'R_CLPNDCPT1', 'R_DCSPTN1CPT1', 'R_DLNLCGCPT1', 'R_EICOSTETCPT1',
              'R_ELAIDCPT1', 'R_LNELDCCPT1', 'R_LNLCCPT1', 'R_LNLNCACPT1', 'R_LNLNCGCPT1', 'R_PTDCACRNCPT1',
              'R_STRDNCCPT1', 'R_TMNDNCCPT1')
    'E0182'. ('R_ADRNCPT1', 'R_ARACHCPT1', 'R_C160CPT1', 'R_C160CPT2', 'R_C161CPT1', 'R_C161CPT12',
              'R_C180CPT1', 'R_C181CPT1', 'R_C204CPT1', 'R_C226CPT1', 'R_CLPNDCPT1', 'R_DCSPTN1CPT1',
              'R_DLNLCGCPT1', 'R_EICOSTETCPT1', 'R_ELAIDCPT1', 'R_HPDCACRNCPT1', 'R_LNELDCCPT1', 'R_LNLCCPT1',
              'R_LNLNCACPT1', 'R_LNLNCGCPT1', 'R_PTDCACRNCPT1', 'R_STRDNCCPT1', 'R_TMNDNCCPT1', 'R_C100CPT1',
              'R_C101CPT1', 'R_C102CPT1', 'R_C10DCc', 'R_C10OHc', 'R_C120CPT1', 'R_C121CPT1',
              'R_C12OHc', 'R_C140CPT1', 'R_C141CPT1', 'R_C142CPT1', 'R_C14OHc', 'R_C16DCc',
              'R_C181OHc', 'R_C182OHc', 'R_C30CPT1', 'R_C40CPT1', 'R_C4OHc', 'R_C51CPT1',
              'R_C60CPT1', 'R_C6DCc', 'R_C80CPT1', 'R_C81CPT1', 'R_C8DCc', 'R_FAOXC12DCc',
              'R_FAOXC3DC', 'R_FAOXC4C4DCc', 'R_OCTDECCPT1', 'R_HMR_2602', 'R_HMR_2608', 'R_HMR_2611',
              'R_HMR_2620', 'R_HMR_2633', 'R_HMR_2648', 'R_HMR_2651', 'R_HMR_2657', 'R_HMR_2660',
              'R_HMR_2666', 'R_HMR_2669', 'R_HMR_2675', 'R_HMR_2681', 'R_HMR_2684', 'R_HMR_2687',
              'R_HMR_2690', 'R_HMR_2693', 'R_HMR_2699', 'R_HMR_2702', 'R_HMR_2705', 'R_HMR_2708',
              'R_HMR_2711', 'R_HMR_2733', 'R_HMR_2736', 'R_HMR_2739', 'R_HMR_2768', 'R_HMR_2771',
              'R_HMR_2774')
    'E0184'. ('R_ADRNCPT2', 'R_ARACHCPT2', 'R_C160CPT2', 'R_C161CPT22', 'R_C180CPT2', 'R_C204CPT2',
              'R_C226CPT2', 'R_CLPNDCPT2', 'R_DCSPTN1CPT2', 'R_DLNLCGCPT2', 'R_DMHPTCRNCPT2', 'R_DMNONCRNCPT2',
              'R_EICOSTETCPT2', 'R_ELAIDCPT2', 'R_HPDCACRNCPT2', 'R_LNELDCCPT2', 'R_LNLCCPT2', 'R_LNLNCACPT2',
              'R_LNLNCGCPT2', 'R_PTDCACRNCPT2', 'R_STRDNCCPT2', 'R_TMNDNCCPT2', 'R_TTDCPT2', 'R_OCTDECCPT2',
              'R_HMR_2604', 'R_HMR_2610', 'R_HMR_2613', 'R_HMR_2622', 'R_HMR_2635', 'R_HMR_2650',
              'R_HMR_2653', 'R_HMR_2659', 'R_HMR_2662', 'R_HMR_2668', 'R_HMR_2671', 'R_HMR_2677',
              'R_HMR_2683', 'R_HMR_2686', 'R_HMR_2689', 'R_HMR_2692', 'R_HMR_2697', 'R_HMR_2701',
              'R_HMR_2704', 'R_HMR_2707', 'R_HMR_2710', 'R_HMR_2713', 'R_HMR_2735', 'R_HMR_2738',
              'R_HMR_2741', 'R_HMR_2770', 'R_HMR_2773', 'R_HMR_2776')
    'E0185'. ('R_ADSK', 'R_SADT')
    'E0187'. ('R_ADSL1', 'R_ADSL2')
    'E0189'. ('R_AG13T16g', 'R_AG13T17g', 'R_AG13T18g', 'R_AG13T1g', 'R_AG13T2g', 'R_AG13T3g',
              'R_HMR_0765', 'R_HMR_0889')
    'E0190'. ('R_AG13T16g', 'R_AG13T17g', 'R_AG13T18g', 'R_AG13T1g', 'R_AG13T2g', 'R_AG13T3g',
              'R_B3GNT11g', 'R_B3GNT12g', 'R_HMR_0765', 'R_HMR_0889')
    'E0191'. ('R_AG13T16g', 'R_AG13T17g', 'R_AG13T18g', 'R_AG13T1g', 'R_AG13T2g', 'R_AG13T3g',
              'R_HMR_0889')
    'E0192'. ('R_AG13T16g', 'R_AG13T17g', 'R_AG13T18g', 'R_AG13T1g', 'R_AG13T2g', 'R_AG13T3g',
              'R_HMR_0765')
    'E0195'. ('R_AG13T16g', 'R_AG13T17g', 'R_AG13T18g', 'R_AG13T1g', 'R_AG13T2g', 'R_AG13T3g')
    'E0196'. ('R_AG13T16g', 'R_AG13T17g', 'R_AG13T18g', 'R_AG13T1g', 'R_AG13T2g', 'R_AG13T3g',
              'R_B3GNT12g')
    'E0197'. ('R_AG13T16g', 'R_AG13T17g', 'R_AG13T18g', 'R_AG13T1g', 'R_AG13T2g', 'R_AG13T3g',
              'R_B3GNT310g', 'R_B3GNT312g', 'R_B3GNT314g', 'R_B3GNT315g', 'R_B3GNT31g', 'R_B3GNT32g',
              'R_B3GNT33g', 'R_B3GNT34g', 'R_B3GNT35g', 'R_B3GNT36g', 'R_B3GNT39g', 'R_HMR_0765',
              'R_HMR_0889')
    'E0199'. ('R_HMR_0593')
    'E0209'. ('R_SPTix', 'R_r0160')
    'E0210'. ('R_AHEXASE2ly', 'R_NACHEX1ly', 'R_NACHEX21ly', 'R_NACHEX22ly', 'R_NACHEX25ly', 'R_NACHEX27ly',
              'R_NACHEX2ly', 'R_NACHEX3ly', 'R_NACHEX8ly', 'R_NACHEX9ly', 'R_NACHEXA10ly', 'R_NACHEXA11ly',
              'R_NACHEXA12ly', 'R_NACHEXA13ly', 'R_NACHEXA14ly', 'R_NACHEXA15ly', 'R_NACHEXA16ly', 'R_NACHEXA17ly',
              'R_NACHEXA18ly', 'R_NACHEXA19ly', 'R_NACHEXA1ly', 'R_NACHEXA20ly', 'R_NACHEXA21ly', 'R_NACHEXA22ly',
              'R_NACHEXA2ly', 'R_NACHEXA3ly', 'R_NACHEXA4ly', 'R_NACHEXA5ly', 'R_NACHEXA6ly', 'R_NACHEXA7ly',
              'R_NACHEXA8ly', 'R_NACHEXA9ly', 'R_HMR_0807', 'R_HMR_0808', 'R_HMR_0821', 'R_HMR_0828')
    'E0211'. ('R_AHEXASE2ly', 'R_NACHEX1ly', 'R_NACHEX21ly', 'R_NACHEX22ly', 'R_NACHEX25ly', 'R_NACHEX27ly',
              'R_NACHEX2ly', 'R_NACHEX8ly', 'R_NACHEX9ly', 'R_HMR_0807', 'R_HMR_0808', 'R_HMR_0821',
              'R_HMR_0828')
    'E0212'. ('R_AHEXASE2ly', 'R_NACHEX1ly', 'R_NACHEX21ly', 'R_NACHEX22ly', 'R_NACHEX25ly', 'R_NACHEX27ly',
              'R_NACHEX2ly', 'R_NACHEX3ly', 'R_NACHEX8ly', 'R_NACHEX9ly', 'R_NACHEXA10ly', 'R_NACHEXA11ly',
              'R_NACHEXA12ly', 'R_NACHEXA13ly', 'R_NACHEXA14ly', 'R_NACHEXA15ly', 'R_NACHEXA16ly', 'R_NACHEXA17ly',
              'R_NACHEXA18ly', 'R_NACHEXA19ly', 'R_NACHEXA1ly', 'R_NACHEXA20ly', 'R_NACHEXA21ly', 'R_NACHEXA22ly',
              'R_NACHEXA2ly', 'R_NACHEXA3ly', 'R_NACHEXA4ly', 'R_NACHEXA5ly', 'R_NACHEXA6ly', 'R_NACHEXA7ly',
              'R_NACHEXA8ly', 'R_NACHEXA9ly')
    'E0213'. ('R_AIRCr', 'R_PRASCS')
    'E0215'. ('R_FUMtm', 'R_r0821', 'R_r0822')
    'E0216'. ('R_HMR_5996')
    'E0218'. ('R_AKR1C1', 'R_HMR_2016', 'R_HMR_2018')
    'E0219'. ('R_AKR1C41', 'R_AKR1C42', 'R_HSD3A1r', 'R_HSD3A2r', 'R_r0747', 'R_r0750',
              'R_HMR_1742', 'R_HMR_1743', 'R_HMR_1770', 'R_HMR_1771', 'R_HMR_2016', 'R_HMR_2018')
    'E0220'. ('R_AKR1D', 'R_AKR1D2', 'R_HMR_1740', 'R_HMR_1741', 'R_HMR_1768', 'R_HMR_1769',
              'R_HMR_2014')
    'E0221'. ('R_ALAASNNaEx', 'R_ALACYSNaEx', 'R_ALAGLNNaEx', 'R_ALASERNaEx', 'R_ALATHRNaEx', 'R_ASNALANaEx',
              'R_ASNCYSNaEx', 'R_ASNGLNNaEx', 'R_ASNSERNaEx', 'R_ASNTHRNaEx', 'R_CYSALANaEx', 'R_CYSASNNaEx',
              'R_CYSGLNNaEx', 'R_CYSSERNaEx', 'R_CYSTHRNaEx', 'R_GLNALANaEx', 'R_GLNASNNaEx', 'R_GLNCYSNaEx',
              'R_GLNSERNaEx', 'R_GLNTHRNaEx', 'R_SERALANaEx', 'R_SERASNNaEx', 'R_SERCYSNaEx', 'R_SERGLNNaEx',
              'R_SERTHRNaEx', 'R_THRALANaEx', 'R_THRASNNaEx', 'R_THRCYSNaEx', 'R_THRGLNNaEx', 'R_THRSERNaEx',
              'R_HDD2CRNte2')
    'E0222'. ('R_ALACYSNaEx', 'R_ALASERNaEx', 'R_ALATHRNaEx', 'R_CYSALANaEx', 'R_CYSSERNaEx', 'R_CYSTHRNaEx',
              'R_SERALANaEx', 'R_SERCYSNaEx', 'R_SERTHRNaEx', 'R_THRALANaEx', 'R_THRCYSNaEx', 'R_THRSERNaEx',
              'R_4HPROLTASCT1')
    'E0223'. ('R_ALADGLNexR', 'R_ALADGLYexR', 'R_ALAGLNexR', 'R_ALAGLYexR', 'R_CYSGLUexR', 'R_CYSGLYexR',
              'R_SERDGLNexR', 'R_SERDGLYexR', 'R_SERGLNexR', 'R_SERGLYexR', 'R_THRGLNexR', 'R_THRGLYexR')
    'E0224'. ('R_ALASm')
    'E0228'. ('R_ALAt4', 'R_PHEt4')
    'E0229'. ('R_ALAt4', 'R_HOMt4', 'R_LEUt4', 'R_LYStiDF', 'R_ORNtiDF', 'R_PHEt4',
              'R_r0817', 'R_ARGtD')
    'E0230'. ('R_ALAt4', 'R_LEUt4', 'R_PHEt4', 'R_HMR_9593')
    'E0231'. ('R_ALAt4', 'R_HOMt4', 'R_LEUt4', 'R_LYStiDF', 'R_ORNtiDF', 'R_PHEt4',
              'R_ARGtD')
    'E0232'. ('R_ALAt4', 'R_LEUt4', 'R_PHEt4')
    'E0233'. ('R_ALAt4', 'R_LEUt4', 'R_LYStiDF', 'R_PHEt4')
    'E0236'. ('R_ALAt4', 'R_LEUt4')
    'E0241'. ('R_ALCD21_D', 'R_ALCD21_L', 'R_ALCD22_D', 'R_ALCD22_L', 'R_ALCD2if', 'R_ALCD1')
    'E0242'. ('R_ALCD21_D', 'R_ALCD21_L', 'R_ALCD22_D', 'R_ALCD22_L', 'R_ALCD2if', 'R_ALCD1',
              'R_HMR_6633')
    'E0246'. ('R_ALCD2yf', 'R_ALR2', 'R_ALR3', 'R_ARABR', 'R_GALOR', 'R_PPDOy',
              'R_SBTR', 'R_r0245', 'R_r0246', 'R_RE0383C', 'R_34DHPEAR')
    'E0247'. ('R_ALCD2yf', 'R_ALR2', 'R_ALR3', 'R_ARABR', 'R_GALOR', 'R_PPDOy',
              'R_SBTR')
    'E0248'. ('R_ALDD20x', 'R_BAMPPALDOX', 'R_GLACO', 'R_LCADi_D', 'R_GCALDD', 'R_ALDD2x',
              'R_IMACTD', 'R_LCADi', 'R_HMR_6647')
    'E0249'. ('R_ALDD20x', 'R_ALDD2y', 'R_BAMPPALDOX', 'R_GLACO', 'R_LCADi_D', 'R_GCALDD',
              'R_ALDD2x', 'R_IMACTD', 'R_LCADi')
    'E0250'. ('R_ALDD20x', 'R_BAMPPALDOX', 'R_LCADi_D', 'R_r0393', 'R_r0642', 'R_r0643',
              'R_r0688', 'R_r0758', 'R_RE3012M', 'R_GCALDD', 'R_ALDD2x', 'R_IMACTD',
              'R_LCADi', 'R_r0392', 'R_HMR_4079')
    'E0251'. ('R_ALDD20x', 'R_ALDD2y', 'R_BAMPPALDOX', 'R_GLACO', 'R_LCADi_D', 'R_GCALDD',
              'R_ALDD2x', 'R_IMACTD', 'R_LCADi', 'R_HMR_6647')
    'E0252'. ('R_ALDD20x', 'R_ALDD2y', 'R_BAMPPALDOX', 'R_GLACO', 'R_LCADi_D', 'R_TMABADH',
              'R_r0393', 'R_r0642', 'R_r0643', 'R_r0688', 'R_r0758', 'R_GCALDD',
              'R_ALDD2x', 'R_IMACTD', 'R_LCADi', 'R_r0392', 'R_HMR_4079')
    'E0253'. ('R_ALDD20x', 'R_ALDD21', 'R_ALDD2y', 'R_BAMPPALDOX', 'R_GLACO', 'R_LCADi_D',
              'R_r0393', 'R_r0642', 'R_r0643', 'R_r0688', 'R_r0758', 'R_RE3012R',
              'R_GCALDD', 'R_ALDD2x', 'R_IMACTD', 'R_LCADi', 'R_r0392', 'R_HMR_4079')
    'E0255'. ('R_ALDD20xm', 'R_ALDD2xm', 'R_ALDD2y', 'R_GCALDDm', 'R_LCADim', 'R_r0393',
              'R_r0642', 'R_r0643', 'R_r0688', 'R_r0758', 'R_RE3012M', 'R_ALDD2x',
              'R_r0392', 'R_HMR_4079')
    'E0256'. ('R_ALDD20xm', 'R_ALDD2xm', 'R_GCALDDm', 'R_LCADim', 'R_r0393', 'R_r0642',
              'R_r0643', 'R_r0688', 'R_r0758', 'R_RE3012M', 'R_r0392', 'R_HMR_4079')
    'E0257'. ('R_ALOX12', 'R_RE3036C', 'R_RE3041C', 'R_RE3525C', 'R_HMR_1030', 'R_HMR_1033',
              'R_HMR_1037', 'R_HMR_1039')
    'E0258'. ('R_ALOX15', 'R_HMR_0985', 'R_HMR_0986', 'R_HMR_0987', 'R_HMR_1388', 'R_HMR_2440')
    'E0260'. ('R_ALOX5', 'R_ALOX52', 'R_HMR_1077')
    'E0261'. ('R_ALR2', 'R_ALR3', 'R_ARABR', 'R_PPDOy', 'R_SBTR')
    'E0262'. ('R_ALR2', 'R_ALR3', 'R_ARABR', 'R_GALOR', 'R_PPDOy', 'R_SBTR',
              'R_r0245', 'R_r0246', 'R_HMR_3855', 'R_HMR_4592')
    'E0263'. ('R_AMACR2p', 'R_RE2624M', 'R_RE2759X', 'R_RE3195M', 'R_HMR_1760', 'R_HMR_1761',
              'R_HMR_3491', 'R_HMR_1635')
    'E0264'. ('R_AMACR2p')
    'E0265'. ('R_AMETt2m')
    'E0268'. ('R_AMPDA')
    'E0273'. ('R_AMPTASECGe', 'R_AMPTASECG')
    'E0274'. ('R_AMY1e', 'R_AMY2e', 'R_LEUt4', 'R_HMR_9191')
    'E0275'. ('R_AMY1e', 'R_AMY2e', 'R_RE0915E', 'R_RE0926E', 'R_RE0935E', 'R_RE0944E',
              'R_RE0958E', 'R_HMR_8570', 'R_HMR_8571', 'R_HMR_8572', 'R_HMR_8573', 'R_HMR_8574',
              'R_HMR_8575', 'R_HMR_8576', 'R_HMR_8577', 'R_HMR_8578', 'R_HMR_8579', 'R_HMR_8580',
              'R_HMR_8582')
    'E0279'. ('R_AMY1e', 'R_AMY2e', 'R_CYSTSERex')
    'E0280'. ('R_AMY1e', 'R_AMY2e')
    'E0282'. ('R_ARACHDt2', 'R_DLNLCGt', 'R_FATP4t', 'R_FATP5t', 'R_FATP6t', 'R_FATP7t',
              'R_FATP8t', 'R_FATP9t', 'R_HDCAtr', 'R_LNLCt', 'R_LNLNCAt', 'R_LNLNCGt',
              'R_OCDCAtr', 'R_OCDCEAtr', 'R_VLCS2r', 'R_r0573', 'R_r0650', 'R_r0651',
              'R_r0983', 'R_r0984', 'R_DOCO13EFATP', 'R_OCT11EFATP', 'R_CE2510ABCt', 'R_CE2537ABCt',
              'R_NRVNCABCt', 'R_HMR_1620', 'R_HMR_1627', 'R_HMR_1665', 'R_HMR_1666', 'R_HMR_1754',
              'R_HMR_1756')
    'E0283'. ('R_ARGDCm')
    'E0284'. ('R_ARGLYSex', 'R_ARGN1ASPMDte')
    'E0285'. ('R_ARGNm', 'R_ARGN')
    'E0286'. ('R_ARGSS')
    'E0288'. ('R_ARGtm', 'R_CITRtm', 'R_LYStm', 'R_ORNt3m', 'R_ORNt4m', 'R_r2399',
              'R_r2404')
    'E0289'. ('R_ARGtm', 'R_CITRtm', 'R_LYStm', 'R_ORNt3m', 'R_ORNt4m')
    'E0291'. ('R_ASAH1', 'R_HMR_0753')
    'E0292'. ('R_ASAH1')
    'E0293'. ('R_ASCBt4')
    'E0294'. ('R_ASCBt4', 'R_r2370', 'R_ASCBSVCTtc')
    'E0295'. ('R_ASCBt4', 'R_ASCBSVCTtc')
    'E0301'. ('R_ASPCTr', 'R_CBPS')
    'E0302'. ('R_ASPDt6', 'R_ASPt6', 'R_GLUt6')
    'E0495'. ('R_ATPH1e', 'R_ATPH2e')
    'E0497'. ('R_ATPH1e', 'R_ATPH2e', 'R_NDP10ex', 'R_NDP3ex', 'R_NDP7ex', 'R_NDP8ex',
              'R_NTP3e', 'R_r0028', 'R_r0139', 'R_r0149', 'R_r0181', 'R_r0494',
              'R_r0497')
    'E0500'. ('R_ATPH1e', 'R_ATPH2e', 'R_NDP7er')
    'E0501'. ('R_ATPH2e', 'R_NDP10ex', 'R_NDP3ex', 'R_NDP7ex', 'R_NDP8ex', 'R_NTP3e',
              'R_r0028', 'R_r0139', 'R_r0149', 'R_r0181', 'R_r0494', 'R_r0497')
    'E0505'. ('R_B_MANNASEly')
    'E0506'. ('R_B3GALT3g')
    'E0507'. ('R_B3GALT3g', 'R_HMR_0805', 'R_HMR_0806')
    'E0510'. ('R_B3GALT41g')
    'E0511'. ('R_B3GALT5g')
    'E0512'. ('R_B3GALT5g', 'R_HMR_0765', 'R_HMR_0860')
    'E0516'. ('R_B3GNT51g', 'R_HMR_0765', 'R_HMR_0859')
    'E0517'. ('R_BAAT3x', 'R_r0629', 'R_r0630', 'R_RE0344C', 'R_RE0577C', 'R_RE0578C',
              'R_RE0579C', 'R_RE1834C', 'R_RE1834X', 'R_RE1835C', 'R_RE2649C', 'R_HMR_0189',
              'R_HMR_0193', 'R_HMR_0197', 'R_HMR_0201', 'R_HMR_0206', 'R_HMR_0210', 'R_HMR_0214',
              'R_HMR_0230', 'R_HMR_0234', 'R_HMR_0238', 'R_HMR_0242', 'R_HMR_0246', 'R_HMR_0256',
              'R_HMR_0260', 'R_HMR_0268', 'R_HMR_0272', 'R_HMR_0276', 'R_HMR_0280', 'R_HMR_0290',
              'R_HMR_0298', 'R_HMR_0302', 'R_HMR_0306', 'R_HMR_0310', 'R_HMR_0324', 'R_HMR_0328',
              'R_HMR_0342', 'R_HMR_0346', 'R_HMR_0350', 'R_HMR_0354', 'R_HMR_0358', 'R_HMR_0362',
              'R_HMR_0366', 'R_HMR_0370', 'R_HMR_0374', 'R_HMR_0378', 'R_HMR_0382', 'R_HMR_0386',
              'R_HMR_0390', 'R_HMR_0394', 'R_HMR_0398', 'R_HMR_0402', 'R_HMR_0406', 'R_HMR_0410',
              'R_HMR_0414', 'R_HMR_0418', 'R_HMR_0422', 'R_HMR_0426', 'R_HMR_0430', 'R_HMR_0434',
              'R_HMR_0438')
    'E0519'. ('R_BALAVECSEC', 'R_GABAVESSEC', 'R_GLYVESSEC')
    'E0521'. ('R_BCDO')
    'E0522'. ('R_BDHm')
    'E0527'. ('R_ESTRONESt', 'R_TCHOLAt', 'R_THYOXt', 'R_TRIODTHYt', 'R_r2198', 'R_r2199',
              'R_r2200', 'R_r2201', 'R_r2202', 'R_12DHCHOLt', 'R_3DHCDCHOLt', 'R_3DHCHOLt',
              'R_3DHDCAt', 'R_3DHLCAt', 'R_7DHCDCHOLt', 'R_7DHCHOLt', 'R_COPROSTt', 'R_HYOCHOLt',
              'R_ICDCHOLt', 'R_ISOCHOLt', 'R_THYOCHOLt', 'R_UCHOLt', 'R_UDCHOLt')
    'E0528'. ('R_FOLABCCte', 'R_HC02194te', 'R_HC02220te', 'R_C05770te', 'R_MLTHFte1', 'R_12DHCHOLabc',
              'R_3DHCDCHOLabc', 'R_3DHCHOLabc', 'R_3DHDCAabc', 'R_3DHLCAabc', 'R_7DHCDCHOLabc', 'R_7DHCHOLabc',
              'R_CDCA24Gte', 'R_CDCA3Gte', 'R_COPROSTabc', 'R_HCA24Gte', 'R_HDCA24Gte', 'R_HDCA6Gte',
              'R_HYOCHOLabc', 'R_ICDCHOLabc', 'R_ISOCHOLabc', 'R_LCA24Gte', 'R_LCA3Gte', 'R_THYOCHOLabc',
              'R_UCHOLabc', 'R_2HATVLACGLUCteb', 'R_3HPVSTETteb', 'R_3HPVSteb', 'R_3ISPVSteb', 'R_56DHPVSteb',
              'R_56EPPVSteb', 'R_6EPSteb', 'R_7HPVSteb', 'R_DSPVSteb', 'R_PVSGLUCteb', 'R_TRIPVSteb')
    'E0529'. ('R_CHOLATEt3', 'R_GCHOLAt3', 'R_TCHOLAt3', 'R_C03990ATP', 'R_C04483t1', 'R_C05463t1',
              'R_CE1273t1', 'R_HC02195te', 'R_HC02196te', 'R_HC02194te', 'R_HC02220te', 'R_DHCHOLESTANATEATP',
              'R_THCHOLSTOICATP', 'R_XOL7AH3ATP', 'R_XOL7AONEATP', 'R_XOLDIOLONEATP', 'R_7KILTCHOLATP', 'R_12DHCHOLabc',
              'R_3DHCDCHOLabc', 'R_3DHCHOLabc', 'R_3DHDCAabc', 'R_3DHLCAabc', 'R_7DHCDCHOLabc', 'R_7DHCHOLabc',
              'R_CDCA24Gte', 'R_CDCA3Gte', 'R_COPROSTabc', 'R_HCA24Gte', 'R_HDCA24Gte', 'R_HDCA6Gte',
              'R_HYOCHOLabc', 'R_ICDCHOLabc', 'R_ISOCHOLabc', 'R_LCA24Gte', 'R_LCA3Gte', 'R_THYOCHOLabc',
              'R_UCHOLabc')
    'E0530'. ('R_ESTRONESt', 'R_TCHOLAt', 'R_TRIODTHYt', 'R_12DHCHOLt', 'R_3DHCDCHOLt', 'R_3DHCHOLt',
              'R_3DHDCAt', 'R_3DHLCAt', 'R_7DHCDCHOLt', 'R_7DHCHOLt', 'R_COPROSTt', 'R_HYOCHOLt',
              'R_ICDCHOLt', 'R_ISOCHOLt', 'R_THYOCHOLt', 'R_UCHOLt', 'R_UDCHOLt')
    'E0533'. ('R_BMTer_U', 'R_H3MTer_U', 'R_HMR_0765')
    'E0534'. ('R_BPNT2', 'R_BPNT')
    'E0536'. ('R_BTNt3i', 'R_BTNt3ile', 'R_HMR_9609')
    'E0537'. ('R_BTNt4i', 'R_THMt3')
    'E0538'. ('R_BUP2')
    'E0539'. ('R_C14STRr', 'R_RE3134C', 'R_HMR_1540', 'R_HMR_1484')
    'E0540'. ('R_C3STDH1Pr', 'R_C3STDH1r', 'R_C4STMO2Pr', 'R_C4STMO2r', 'R_HMR_1495', 'R_HMR_1496',
              'R_HMR_1505', 'R_HMR_1546', 'R_HMR_1551')
    'E0541'. ('R_C3STKR2r', 'R_HACD1x', 'R_HSD17B42x', 'R_HSD17B4x', 'R_r0743', 'R_r0744',
              'R_RE0512M', 'R_RE0512X', 'R_RE1525M', 'R_RE1525X', 'R_RE1526M', 'R_RE1526X',
              'R_RE1527M', 'R_RE1527X', 'R_RE2987X', 'R_RE2991X', 'R_RE3005M', 'R_RE3082X',
              'R_RE3156X', 'R_RE3177M', 'R_RE3178M', 'R_RE3179M', 'R_HMR_3059', 'R_HMR_3064',
              'R_HMR_3068', 'R_HMR_3072', 'R_HMR_3076', 'R_HMR_3096', 'R_HMR_3100', 'R_HMR_3328',
              'R_HMR_3332', 'R_HMR_3336', 'R_HMR_3340', 'R_HMR_3344', 'R_HMR_3348', 'R_HMR_3352',
              'R_HMR_1644', 'R_3HPVSTETCOAhcx', 'R_DEOXFVShc', 'R_PROFVSCOAhc')
    'E0542'. ('R_C4STMO2r', 'R_HMR_1490', 'R_HMR_1493', 'R_HMR_1494', 'R_HMR_1502', 'R_HMR_1503',
              'R_HMR_1504', 'R_HMR_1543', 'R_HMR_1544', 'R_HMR_1545', 'R_HMR_1548', 'R_HMR_1549',
              'R_HMR_1550')
    'E0547'. ('R_CATm')
    'E0548'. ('R_CAt7r')
    'E0556'. ('R_CBL2tm')
    'E0557'. ('R_CBPPer', 'R_G6PPer', 'R_PPAer')
    'E0562'. ('R_RE3476C', 'R_HMR_1102', 'R_HMR_0980')
    'E0563'. ('R_CDIPTr')
    'E0565'. ('R_CDSm')
    'E0567'. ('R_HMR_0614', 'R_HMR_0625')
    'E0568'. ('R_HMR_0625')
    'E0569'. ('R_CERK')
    'E0571'. ('R_CERT1gt', 'R_CERT1rt', 'R_CERT2gt', 'R_CERT2rt')
    'E0572'. ('R_CGLYt3_2_')
    'E0573'. ('R_CH25H', 'R_HMR_1785', 'R_HMR_1786')
    'E0574'. ('R_CHAT', 'R_CHATn')
    'E0579'. ('R_CHLPCTD')
    'E0581'. ('R_ESTRONESt', 'R_PROSTGE2t', 'R_TCHOLAt', 'R_THYOXt', 'R_TRIODTHYt', 'R_r2139',
              'R_r2140', 'R_r2141', 'R_r2142', 'R_r2143', 'R_r2144', 'R_r2145',
              'R_r2149', 'R_r2150', 'R_r2193', 'R_r2194', 'R_r2195', 'R_r2196',
              'R_r2197', 'R_r2308', 'R_r2309', 'R_r2310', 'R_r2311', 'R_r2312')
    'E0582'. ('R_CHOLATEt2', 'R_ESTRONESt2', 'R_GCHOLAt2', 'R_TCHOLAt2', 'R_r1015', 'R_r1163',
              'R_r1495', 'R_r1497', 'R_r1498', 'R_r1499', 'R_r1500', 'R_r1501',
              'R_r1502', 'R_r1503', 'R_C03990t', 'R_DHCHOLESTANATEt', 'R_THCHOLSTOICt', 'R_XOL7AH3t',
              'R_XOL7AONEt', 'R_7KILTCHOLt', 'R_12DHCHOLt2', 'R_3DHCDCHOLt2', 'R_3DHCHOLt2', 'R_3DHDCAt2',
              'R_3DHLCAt2', 'R_7DHCDCHOLt2', 'R_7DHCHOLt2', 'R_COPROSTt2', 'R_HYOCHOLt2', 'R_ICDCHOLt2',
              'R_ISOCHOLt2', 'R_THYOCHOLt2', 'R_UCHOLt2', 'R_UDCHOLt2')
    'E0583'. ('R_CHOLATEt2', 'R_GCHOLAt2', 'R_TCHOLAt2', 'R_12DHCHOLt2', 'R_3DHCDCHOLt2', 'R_3DHCHOLt2',
              'R_3DHDCAt2', 'R_3DHLCAt2', 'R_7DHCDCHOLt2', 'R_7DHCHOLt2', 'R_COPROSTt2', 'R_HYOCHOLt2',
              'R_ICDCHOLt2', 'R_ISOCHOLt2', 'R_THYOCHOLt2', 'R_UCHOLt2', 'R_UDCHOLt2')
    'E0584'. ('R_CHOLATEt3', 'R_GCHOLAt3', 'R_TCHOLAt3', 'R_HC02194te', 'R_HC02220te', 'R_12DHCHOLabc',
              'R_3DHCDCHOLabc', 'R_3DHCHOLabc', 'R_3DHDCAabc', 'R_3DHLCAabc', 'R_7DHCDCHOLabc', 'R_7DHCHOLabc',
              'R_CDCA24Gte', 'R_CDCA3Gte', 'R_COPROSTabc', 'R_HCA24Gte', 'R_HDCA24Gte', 'R_HDCA6Gte',
              'R_HYOCHOLabc', 'R_ICDCHOLabc', 'R_ISOCHOLabc', 'R_LCA24Gte', 'R_LCA3Gte', 'R_THYOCHOLabc',
              'R_UCHOLabc')
    'E0585'. ('R_CHOLATEt3', 'R_r1026', 'R_r1028', 'R_GCHOLAt3', 'R_TCHOLAt3', 'R_C03990ATP',
              'R_C04483t1', 'R_C05463t1', 'R_CE1273t1', 'R_HC02195te', 'R_HC02196te', 'R_HC02194te',
              'R_DHCHOLESTANATEATP', 'R_THCHOLSTOICATP', 'R_XOL7AH3ATP', 'R_XOL7AONEATP', 'R_XOLDIOLONEATP', 'R_7KILTCHOLATP',
              'R_12DHCHOLabc', 'R_3DHCDCHOLabc', 'R_3DHCHOLabc', 'R_3DHDCAabc', 'R_3DHLCAabc', 'R_7DHCDCHOLabc',
              'R_7DHCHOLabc', 'R_CDCA24Gte', 'R_CDCA3Gte', 'R_COPROSTabc', 'R_HCA24Gte', 'R_HDCA24Gte',
              'R_HDCA6Gte', 'R_HYOCHOLabc', 'R_ICDCHOLabc', 'R_ISOCHOLabc', 'R_LCA24Gte', 'R_LCA3Gte',
              'R_THYOCHOLabc', 'R_UCHOLabc', 'R_3HPVSTETteb', 'R_3HPVSteb', 'R_3ISPVSteb', 'R_56DHPVSteb',
              'R_56EPPVSteb', 'R_6EPSteb', 'R_7HPVSteb', 'R_DSPVSteb', 'R_PVSGLUCteb', 'R_TRIPVSteb')
    'E0588'. ('R_CHOLK')
    'E0589'. ('R_CHOLK', 'R_ETHAK')
    'E0593'. ('R_CHOLtu', 'R_DOPAtu', 'R_HISTAtu', 'R_NRPPHRtu', 'R_PROSTGE2t2', 'R_PROSTGF2t',
              'R_SRTNtu', 'R_AGRMte')
    'E0594'. ('R_CHOLtu', 'R_DOPAtu', 'R_HISTAtu', 'R_HDD2CRNte2', 'R_HMR_2817', 'R_HMR_2821',
              'R_HMR_2851', 'R_HMR_2857', 'R_HMR_2861', 'R_HMR_2865', 'R_HMR_2884', 'R_HMR_2888')
    'E0595'. ('R_CHOLtu', 'R_DOPAtu', 'R_HISTAtu', 'R_NRPPHRtu', 'R_PROSTGE2t2', 'R_PROSTGF2t',
              'R_SRTNtu')
    'E0596'. ('R_CHSTEROLSULT')
    'E0598'. ('R_CHSTEROLtg', 'R_PCt', 'R_r1514', 'R_r1515', 'R_r1516', 'R_r1517',
              'R_r1518', 'R_r1519', 'R_r1520', 'R_r1521', 'R_r1522', 'R_r1523',
              'R_r1525', 'R_r1527', 'R_r1529', 'R_VITEtl', 'R_PSHSABCtc', 'R_CHSTEROLt',
              'R_AK2LGCHOLABCt', 'R_PAFABCt', 'R_PCHLN225_HSABCt', 'R_PCHOL2LINL_HSABCt', 'R_PCHOL2OLE_HSABCt', 'R_PCHOL2STE_HSABCt',
              'R_PCHOLAR_HSABCt', 'R_PCHOLDOC_HSABCt', 'R_PCHOLEIC_HSABCt', 'R_PCHOLET_HSABCt', 'R_PCHOLHEP_HSABCt', 'R_PCHOLLINL_HSABCt',
              'R_PCHOLMYR_HsABCt', 'R_PCHOLN15_HSABCt', 'R_PCHOLN183_HSABCt', 'R_PCHOLN1836_HSABCt', 'R_PCHOLN19_HSABCt', 'R_PCHOLN201_HSABCt',
              'R_PCHOLN203_HSABCt', 'R_PCHOLN204_HSABCt', 'R_PCHOLN205_HSABCt', 'R_PCHOLN224_HSABCt', 'R_PCHOLN225_HSABCt', 'R_PCHOLN2254_HSABCt',
              'R_PCHOLN264_HSABCt', 'R_PCHOLOLE_HSABCt', 'R_PCHOLPALME-HSABCt', 'R_PCHOLSTE_HSABCt', 'R_PEPALM_HSASBCt', 'R_SPHS1Pt2e',
              'R_HMR_0194', 'R_HMR_0207', 'R_HMR_0211', 'R_HMR_0215', 'R_HMR_0235', 'R_HMR_0239',
              'R_HMR_0243', 'R_HMR_0247', 'R_HMR_0253', 'R_HMR_0257', 'R_HMR_0261', 'R_HMR_0273',
              'R_HMR_0277', 'R_HMR_0281', 'R_HMR_0287', 'R_HMR_0291', 'R_HMR_0299', 'R_HMR_0303',
              'R_HMR_0307', 'R_HMR_0311', 'R_HMR_0317', 'R_HMR_0321', 'R_HMR_0325', 'R_HMR_0329',
              'R_HMR_0343', 'R_HMR_0347', 'R_HMR_0359', 'R_HMR_0363', 'R_HMR_0367', 'R_HMR_0371',
              'R_HMR_0375', 'R_HMR_0383', 'R_HMR_0387', 'R_HMR_0391', 'R_HMR_0395', 'R_HMR_0415',
              'R_HMR_0419', 'R_HMR_0423', 'R_HMR_0427', 'R_HMR_0431', 'R_HMR_0435', 'R_HMR_0439')
    'E0599'. ('R_CHTNASE')
    'E0602'. ('R_CHTNASEe')
    'E0603'. ('R_CITt4_2', 'R_SUCCt4_2', 'R_HMR_9610')
    'E0604'. ('R_r1090')
    'E0610'. ('R_CLI2tex')
    'E0611'. ('R_CLHCO3tex2', 'R_CLOHtex2', 'R_CLOXAtex2', 'R_SO4CLtex2', 'R_SO4OXAtex2', 'R_HMR_6533',
              'R_HMR_8670')
    'E0612'. ('R_CLHCO3tex2', 'R_CLOHtex2', 'R_CLOXAtex2', 'R_SO4CLtex2', 'R_SO4OXAtex2')
    'E0614'. ('R_CLS_hs')
    'E0615'. ('R_CMPACNAtg')
    'E0616'. ('R_CMPSAS', 'R_CMPSASn')
    'E0617'. ('R_COAtm')
    'E0618'. ('R_COKECBESr', 'R_HMR_8643')
    'E0619'. ('R_COQ3m', 'R_DHDPBMTm', 'R_HMR_6910')
    'E0620'. ('R_COQ6m', 'R_HMR_6907')
    'E0621'. ('R_COQ6m')
    'E0622'. ('R_COQ7m', 'R_HMR_6909')
    'E0623'. ('R_CORE2GTg', 'R_CORE4GTg')
    'E0624'. ('R_CORE2GTg', 'R_CORE6GTg')
    'E0625'. ('R_CORE2GTg')
    'E0626'. ('R_CORE3GTg', 'R_HMR_0765')
    'E0627'. ('R_CREATt4_2_r', 'R_r0942')
    'E0628'. ('R_CREATt4_2_r')
    'E0629'. ('R_CRNCARtp', 'R_CSNATr', 'R_HMR_2604', 'R_HMR_2610', 'R_HMR_2613', 'R_HMR_2622',
              'R_HMR_2635', 'R_HMR_2650', 'R_HMR_2653', 'R_HMR_2659', 'R_HMR_2662', 'R_HMR_2668',
              'R_HMR_2671', 'R_HMR_2677', 'R_HMR_2683', 'R_HMR_2686', 'R_HMR_2689', 'R_HMR_2692',
              'R_HMR_2697', 'R_HMR_2701', 'R_HMR_2704', 'R_HMR_2707', 'R_HMR_2710', 'R_HMR_2713',
              'R_HMR_2735', 'R_HMR_2738', 'R_HMR_2741', 'R_HMR_2770', 'R_HMR_2773', 'R_HMR_2776',
              'R_HMR_2819', 'R_HMR_2827', 'R_HMR_2852', 'R_HMR_2859', 'R_HMR_2862', 'R_HMR_2866',
              'R_HMR_2886', 'R_HMR_2890')
    'E0630'. ('R_CRNtHa', 'R_HMR_2603', 'R_HMR_2609', 'R_HMR_2612', 'R_HMR_2621', 'R_HMR_2624',
              'R_HMR_2634', 'R_HMR_2644', 'R_HMR_2649', 'R_HMR_2652', 'R_HMR_2655', 'R_HMR_2661',
              'R_HMR_2667', 'R_HMR_2670', 'R_HMR_2673', 'R_HMR_2676', 'R_HMR_2679', 'R_HMR_2682',
              'R_HMR_2685', 'R_HMR_2688', 'R_HMR_2691', 'R_HMR_2695', 'R_HMR_2700', 'R_HMR_2703',
              'R_HMR_2706', 'R_HMR_2709', 'R_HMR_2712', 'R_HMR_2715', 'R_HMR_2718', 'R_HMR_2722',
              'R_HMR_2727', 'R_HMR_2731', 'R_HMR_2734', 'R_HMR_2737', 'R_HMR_2740', 'R_HMR_2744',
              'R_HMR_2748', 'R_HMR_2753', 'R_HMR_2757', 'R_HMR_2760', 'R_HMR_2764', 'R_HMR_2769',
              'R_HMR_2772', 'R_HMR_2775')
    'E0631'. ('R_CSm')
    'E0633'. ('R_CSNAT2x', 'R_ADPCOACROT', 'R_C4x', 'R_SEBCOACROT', 'R_SUBERCROT')
    'E0634'. ('R_CSNAT2x', 'R_CSNAT3x', 'R_CSNATp')
    'E0636'. ('R_CYSGLUexR')
    'E0637'. ('R_CYSGLYexR')
    'E0640'. ('R_CYSTGLUex')
    'E0643'. ('R_CYTDK1', 'R_URIK1', 'R_r0531', 'R_r1156', 'R_HMR_5301')
    'E0645'. ('R_CYTK12n', 'R_CYTK13n', 'R_CYTK14n', 'R_CYTK7n', 'R_CYTK8n', 'R_CYTK9n',
              'R_UMPK3n', 'R_UMPK5n', 'R_UMPK6n')
    'E0646'. ('R_CYTK1m')
    'E0647'. ('R_DAGK_hs')
    'E0661'. ('R_DALAOXx', 'R_DARGOp', 'R_DORNOp')
    'E0662'. ('R_DASCBR')
    'E0665'. ('R_DASPO1p')
    'E0667'. ('R_DCIm', 'R_RE1573M', 'R_RE2992M', 'R_RE2999M', 'R_RE3003M', 'R_RE3628M',
              'R_FAOXC102m', 'R_FAOXC122m', 'R_FAOXC123m', 'R_FAOXC163Gm', 'R_FAOXC184m', 'R_FAOXC225m',
              'R_FAOXC226m', 'R_FAOXC61m', 'R_HMR_3447')
    'E0668'. ('R_DCIm', 'R_RE1573M', 'R_RE1573X', 'R_RE2992M', 'R_RE2992X', 'R_RE2999M',
              'R_RE3002X', 'R_RE3003M', 'R_RE3628M', 'R_FAOXC101x', 'R_FAOXC102x', 'R_FAOXC121x',
              'R_FAOXC122x', 'R_FAOXC123x', 'R_FAOXC163x', 'R_FAOXC164x', 'R_FAOXC184x', 'R_FAOXC225x',
              'R_FAOXC61x', 'R_HMR_3447')
    'E0669'. ('R_DCK1n', 'R_DCK2n', 'R_r0377')
    'E0671'. ('R_HMR_2296')
    'E0672'. ('R_DESAT18_10', 'R_DESAT18_6', 'R_DESAT18_7', 'R_DESAT18_8', 'R_DESAT18_9', 'R_DESAT24_1',
              'R_DESAT14_9', 'R_HMR_2359', 'R_HMR_2365', 'R_HMR_2368', 'R_HMR_2380', 'R_HMR_2472',
              'R_HMR_2484')
    'E0673'. ('R_DESAT18_9', 'R_HMR_2359', 'R_HMR_2365', 'R_HMR_2368', 'R_HMR_2380', 'R_HMR_2472',
              'R_HMR_2484')
    'E0676'. ('R_DGNSKm')
    'E0681'. ('R_DHAAt1r', 'R_GALt1r', 'R_GLCt1r', 'R_XYLt')
    'E0682'. ('R_DHAAt1r', 'R_GALt1r', 'R_GAMt1r', 'R_GLCt1r')
    'E0683'. ('R_DHAAt1r', 'R_GAMt1r', 'R_GLCt1r')
    'E0684'. ('R_DHCR241r', 'R_DHCR242r', 'R_DHCR243r', 'R_r0783', 'R_r1380', 'R_DSREDUCr',
              'R_HMR_1526')
    'E0685'. ('R_DHCR242r')
    'E0686'. ('R_DHCR71r', 'R_DHCR72r', 'R_HMR_1565')
    'E0687'. ('R_DHCRD1')
    'E0690'. ('R_ESTRONESt')
    'E0691'. ('R_DHEASULT', 'R_ESTSULT')
    'E0696'. ('R_D_LACt2', 'R_L_LACt2r')
    'E0697'. ('R_DMATTx', 'R_GRTTx', 'R_HMR_1532')
    'E0699'. ('R_DNDPt10m', 'R_DNDPt11m', 'R_DNDPt12m', 'R_DNDPt13m', 'R_DNDPt14m', 'R_DNDPt15m',
              'R_DNDPt16m', 'R_DNDPt17m', 'R_DNDPt18m', 'R_DNDPt19m', 'R_DNDPt1m', 'R_DNDPt20m',
              'R_DNDPt21m', 'R_DNDPt23m', 'R_DNDPt24m', 'R_DNDPt25m', 'R_DNDPt28m', 'R_DNDPt2m',
              'R_DNDPt30m', 'R_DNDPt31m', 'R_DNDPt32m', 'R_DNDPt37m', 'R_DNDPt38m', 'R_DNDPt39m',
              'R_DNDPt3m', 'R_DNDPt40m', 'R_DNDPt41m', 'R_DNDPt42m', 'R_DNDPt43m', 'R_DNDPt44m',
              'R_DNDPt45m', 'R_DNDPt46m', 'R_DNDPt47m', 'R_DNDPt48m', 'R_DNDPt49m', 'R_DNDPt4m',
              'R_DNDPt50m', 'R_DNDPt51m', 'R_DNDPt52m', 'R_DNDPt53m', 'R_DNDPt54m', 'R_DNDPt55m',
              'R_DNDPt56m', 'R_DNDPt57m', 'R_DNDPt58m', 'R_DNDPt59m', 'R_DNDPt5m', 'R_DNDPt60m',
              'R_DNDPt61m', 'R_DNDPt62m', 'R_DNDPt63m', 'R_DNDPt6m', 'R_DNDPt7m', 'R_r0879',
              'R_r2425')
    'E0701'. ('R_DOLPMT3_Uer')
    'E0707'. ('R_DOPAtu', 'R_HISTAtu', 'R_NRPPHRtu')
    'E0708'. ('R_DPGase', 'R_DPGM', 'R_PGM')
    'E0713'. ('R_DPMVDc')
    'E0714'. ('R_DRPA')
    'E0715'. ('R_DURAD', 'R_DURAD2')
    'E0716'. ('R_DURIK1', 'R_TMDK1')
    'E0717'. ('R_DURIK1', 'R_DURIK1m', 'R_TMDK1m', 'R_RE1530M', 'R_TMDK1')
    'E0718'. ('R_DUTPDPm')
    'E0719'. ('R_DUTPDPm', 'R_NTPP10', 'R_NTPP9', 'R_r0119', 'R_r0166', 'R_r0410',
              'R_HMR_3966')
    'E0720'. ('R_EBP1r', 'R_EBP2r', 'R_RE3136C', 'R_HMR_1512')
    'E0721'. ('R_ECOAH12m', 'R_ECOAH1m', 'R_ECOAH9m', 'R_RE1520M', 'R_RE1521M', 'R_RE1522M',
              'R_RE1523M', 'R_RE3004M', 'R_RE3192M', 'R_RE3193M', 'R_RE3194M', 'R_HMR_3108',
              'R_HMR_3112', 'R_HMR_3116', 'R_HMR_3171', 'R_HMR_3175', 'R_HMR_3179', 'R_HMR_3183',
              'R_HMR_3187', 'R_HMR_3191', 'R_HMR_3195', 'R_HMR_3199', 'R_HMR_3203', 'R_HMR_3219',
              'R_HMR_3223', 'R_HMR_3231', 'R_HMR_3235', 'R_HMR_3241', 'R_HMR_3245', 'R_HMR_3398',
              'R_HMR_3406', 'R_HMR_3407', 'R_HMR_3408', 'R_HMR_3409', 'R_HMR_3411', 'R_HMR_3413',
              'R_HMR_3414', 'R_HMR_3416', 'R_HMR_3421', 'R_HMR_3422', 'R_HMR_3423', 'R_HMR_3424',
              'R_HMR_3425', 'R_HMR_3426', 'R_HMR_3427', 'R_HMR_3428', 'R_HMR_3429', 'R_HMR_3431',
              'R_HMR_3432', 'R_HMR_3433', 'R_HMR_3449', 'R_HMR_3453', 'R_HMR_9719')
    'E0722'. ('R_ECOAH1m', 'R_MGCHrm')
    'E0723'. ('R_ECOAH1x', 'R_RE3000M', 'R_HMR_3447')
    'E0724'. ('R_ECOAH1x', 'R_HACD1x', 'R_RE0512M', 'R_RE0512X', 'R_RE1520M', 'R_RE1520X',
              'R_RE1521M', 'R_RE1521X', 'R_RE1522M', 'R_RE1522X', 'R_RE1523M', 'R_RE1523X',
              'R_RE1525M', 'R_RE1525X', 'R_RE1526M', 'R_RE1526X', 'R_RE1527M', 'R_RE1527X',
              'R_RE1573M', 'R_RE1573X', 'R_RE2986X', 'R_RE2987X', 'R_RE2990X', 'R_RE2991X',
              'R_RE2992M', 'R_RE2992X', 'R_RE2999M', 'R_RE3002X', 'R_RE3003M', 'R_RE3004M',
              'R_RE3005M', 'R_RE3081X', 'R_RE3082X', 'R_RE3156X', 'R_RE3159X', 'R_RE3177M',
              'R_RE3178M', 'R_RE3179M', 'R_RE3192M', 'R_RE3193M', 'R_RE3194M', 'R_RE3628M',
              'R_FAOXC101x', 'R_FAOXC102x', 'R_FAOXC121x', 'R_FAOXC122x', 'R_FAOXC123x', 'R_FAOXC163x',
              'R_FAOXC164x', 'R_FAOXC184x', 'R_FAOXC225x', 'R_FAOXC61x', 'R_HMR_3058', 'R_HMR_3059',
              'R_HMR_3063', 'R_HMR_3064', 'R_HMR_3067', 'R_HMR_3068', 'R_HMR_3071', 'R_HMR_3072',
              'R_HMR_3075', 'R_HMR_3076', 'R_HMR_3095', 'R_HMR_3096', 'R_HMR_3099', 'R_HMR_3100',
              'R_HMR_3327', 'R_HMR_3328', 'R_HMR_3331', 'R_HMR_3332', 'R_HMR_3335', 'R_HMR_3336',
              'R_HMR_3339', 'R_HMR_3340', 'R_HMR_3343', 'R_HMR_3344', 'R_HMR_3347', 'R_HMR_3348',
              'R_HMR_3351', 'R_HMR_3352', 'R_3HPVSTETCOAhcx', 'R_DEOXFVShc', 'R_PROFVSCOAhc')
    'E0725'. ('R_ELAIDt', 'R_FACOAL191', 'R_FACOAL206', 'R_FATP6t', 'R_FATP7t', 'R_FATP8t',
              'R_FATP9t', 'R_HDCEAtr', 'R_LGNCt', 'R_TTDCAtr', 'R_VLCS2r', 'R_VLCSp',
              'R_VLCSr', 'R_r0311', 'R_r0650', 'R_r1251', 'R_r1252', 'R_r1253',
              'R_r1254', 'R_r1255', 'R_r1257', 'R_r1259', 'R_r1260', 'R_r1262',
              'R_r1487', 'R_RE3074X', 'R_RE3079X', 'R_RE3114R', 'R_RE3132R', 'R_RE3146R',
              'R_RE3160R', 'R_DCATDc', 'R_DOCO13EFATP', 'R_FAOXC15ATPx', 'R_FAOXC16BRx', 'R_OCT11EFATP',
              'R_LGNCFATPtc', 'R_DDCAte', 'R_CE2510ABCt', 'R_CE2537ABCt', 'R_NRVNCABCt', 'R_HMR_0188',
              'R_HMR_0192', 'R_HMR_0200', 'R_HMR_0204', 'R_HMR_0209', 'R_HMR_0233', 'R_HMR_0241',
              'R_HMR_0245', 'R_HMR_0255', 'R_HMR_0259', 'R_HMR_0267', 'R_HMR_0271', 'R_HMR_0279',
              'R_HMR_0289', 'R_HMR_0293', 'R_HMR_0297', 'R_HMR_0301', 'R_HMR_0305', 'R_HMR_0309',
              'R_HMR_0319', 'R_HMR_0323', 'R_HMR_0327', 'R_HMR_0345', 'R_HMR_0381', 'R_HMR_0385',
              'R_HMR_0389', 'R_HMR_0393', 'R_HMR_0429', 'R_HMR_0433', 'R_HMR_0437', 'R_HMR_1620',
              'R_HMR_1627', 'R_HMR_1665', 'R_HMR_1666', 'R_HMR_1754', 'R_HMR_1756', 'R_HMR_2942',
              'R_HMR_2943', 'R_HMR_2944', 'R_HMR_2945', 'R_HMR_2946', 'R_HMR_2947', 'R_HMR_2948',
              'R_HMR_2951', 'R_HMR_2954', 'R_HMR_2955', 'R_HMR_2956', 'R_HMR_2961', 'R_HMR_2962',
              'R_HMR_2963', 'R_HMR_2964', 'R_HMR_2965', 'R_HMR_2966', 'R_HMR_2967', 'R_HMR_2968',
              'R_HMR_2969', 'R_HMR_2970', 'R_HMR_2971', 'R_HMR_2972', 'R_HMR_2973', 'R_HMR_2974',
              'R_HMR_2975', 'R_HMR_2976', 'R_HMR_2977', 'R_HMR_2978', 'R_HMR_2979', 'R_HMR_2980',
              'R_HMR_2982', 'R_HMR_2983', 'R_HMR_2985', 'R_HMR_2986', 'R_HMR_2988', 'R_HMR_2989',
              'R_HMR_2990', 'R_HMR_2994', 'R_HMR_2998', 'R_HMR_2999', 'R_HMR_3001', 'R_HMR_3002',
              'R_HMR_3003', 'R_HMR_2957')
    'E0726'. ('R_ESTRONESt', 'R_PROSTGE2t', 'R_TCHOLAt', 'R_THYOXt', 'R_TRIODTHYt')
    'E0727'. ('R_ESTRONESt', 'R_THYOXt', 'R_TRIODTHYt')
    'E0728'. ('R_PROSTGE1t3', 'R_PROSTGE2t3', 'R_r1536', 'R_FOLABCCte', 'R_CAMPt', 'R_CGMPt',
              'R_HC02194te', 'R_HC02220te', 'R_CE7090te', 'R_CE7085te', 'R_CE7096te', 'R_CE4877te',
              'R_CE1447te', 'R_MLTHFte1', 'R_12DHCHOLabc', 'R_3DHCDCHOLabc', 'R_3DHCHOLabc', 'R_7DHCDCHOLabc',
              'R_7DHCHOLabc', 'R_COPROSTabc', 'R_ICDCHOLabc', 'R_ISOCHOLabc', 'R_UCHOLabc')
    'E0729'. ('R_ESTRONESt', 'R_PROSTGE2t')
    'E0732'. ('R_ETHAK')
    'E0734'. ('R_F1PGT')
    'E0736'. ('R_FACOAL150', 'R_FACOAL160i', 'R_FACOAL170', 'R_FACOAL180i', 'R_FACOAL181i', 'R_FACOAL1821',
              'R_FACOAL1831', 'R_FACOAL204', 'R_FACOAL80i', 'R_r0311', 'R_r1251', 'R_r1252',
              'R_r1253', 'R_r1254', 'R_r1255', 'R_r1257', 'R_r1259', 'R_r1260',
              'R_r1262', 'R_r1487', 'R_RE2912M', 'R_RE3074X', 'R_RE3114R', 'R_RE3132R',
              'R_RE3146R', 'R_RE3160R', 'R_HMR_0188', 'R_HMR_0192', 'R_HMR_0200', 'R_HMR_0204',
              'R_HMR_0209', 'R_HMR_0233', 'R_HMR_0241', 'R_HMR_0245', 'R_HMR_0255', 'R_HMR_0259',
              'R_HMR_0267', 'R_HMR_0271', 'R_HMR_0279', 'R_HMR_0289', 'R_HMR_0293', 'R_HMR_0297',
              'R_HMR_0301', 'R_HMR_0305', 'R_HMR_0309', 'R_HMR_0319', 'R_HMR_0323', 'R_HMR_0327',
              'R_HMR_0345', 'R_HMR_0381', 'R_HMR_0385', 'R_HMR_0389', 'R_HMR_0393', 'R_HMR_0429',
              'R_HMR_0433', 'R_HMR_0437', 'R_HMR_2942', 'R_HMR_2943', 'R_HMR_2944', 'R_HMR_2945',
              'R_HMR_2946', 'R_HMR_2947', 'R_HMR_2948', 'R_HMR_2951', 'R_HMR_2954', 'R_HMR_2955',
              'R_HMR_2956', 'R_HMR_2961', 'R_HMR_2962', 'R_HMR_2963', 'R_HMR_2964', 'R_HMR_2965',
              'R_HMR_2966', 'R_HMR_2967', 'R_HMR_2968', 'R_HMR_2969', 'R_HMR_2970', 'R_HMR_2971',
              'R_HMR_2972', 'R_HMR_2973', 'R_HMR_2974', 'R_HMR_2975', 'R_HMR_2976', 'R_HMR_2977',
              'R_HMR_2978', 'R_HMR_2979', 'R_HMR_2980', 'R_HMR_2982', 'R_HMR_2983', 'R_HMR_2985',
              'R_HMR_2986', 'R_HMR_2988', 'R_HMR_2989', 'R_HMR_2990', 'R_HMR_2994', 'R_HMR_2998',
              'R_HMR_2999', 'R_HMR_3001', 'R_HMR_3002', 'R_HMR_3003', 'R_HMR_2957')
    'E0737'. ('R_FACOAL150', 'R_FACOAL160i', 'R_FACOAL170', 'R_FACOAL181i', 'R_FACOAL1821', 'R_FACOAL1831',
              'R_FACOAL204', 'R_r0311', 'R_r1251', 'R_r1252', 'R_r1253', 'R_r1254',
              'R_r1255', 'R_r1257', 'R_r1259', 'R_r1260', 'R_r1262', 'R_r1487',
              'R_RE2912M', 'R_RE3074X', 'R_RE3114R', 'R_RE3132R', 'R_RE3146R', 'R_RE3160R',
              'R_HMR_0188', 'R_HMR_0192', 'R_HMR_0200', 'R_HMR_0204', 'R_HMR_0209', 'R_HMR_0233',
              'R_HMR_0241', 'R_HMR_0245', 'R_HMR_0255', 'R_HMR_0259', 'R_HMR_0267', 'R_HMR_0271',
              'R_HMR_0279', 'R_HMR_0289', 'R_HMR_0293', 'R_HMR_0297', 'R_HMR_0301', 'R_HMR_0305',
              'R_HMR_0309', 'R_HMR_0319', 'R_HMR_0323', 'R_HMR_0327', 'R_HMR_0345', 'R_HMR_0381',
              'R_HMR_0385', 'R_HMR_0389', 'R_HMR_0393', 'R_HMR_0429', 'R_HMR_0433', 'R_HMR_0437',
              'R_HMR_2942', 'R_HMR_2943', 'R_HMR_2944', 'R_HMR_2945', 'R_HMR_2946', 'R_HMR_2947',
              'R_HMR_2948', 'R_HMR_2951', 'R_HMR_2954', 'R_HMR_2955', 'R_HMR_2956', 'R_HMR_2961',
              'R_HMR_2962', 'R_HMR_2963', 'R_HMR_2964', 'R_HMR_2965', 'R_HMR_2966', 'R_HMR_2967',
              'R_HMR_2968', 'R_HMR_2969', 'R_HMR_2970', 'R_HMR_2971', 'R_HMR_2972', 'R_HMR_2973',
              'R_HMR_2974', 'R_HMR_2975', 'R_HMR_2976', 'R_HMR_2977', 'R_HMR_2978', 'R_HMR_2979',
              'R_HMR_2980', 'R_HMR_2982', 'R_HMR_2983', 'R_HMR_2985', 'R_HMR_2986', 'R_HMR_2988',
              'R_HMR_2989', 'R_HMR_2990', 'R_HMR_2994', 'R_HMR_2998', 'R_HMR_2999', 'R_HMR_3001',
              'R_HMR_3002', 'R_HMR_3003', 'R_HMR_2957')
    'E0738'. ('R_FACOAL150', 'R_FACOAL160i', 'R_FACOAL170', 'R_FACOAL180i', 'R_FACOAL181i', 'R_FACOAL1821',
              'R_FACOAL1831', 'R_FACOAL204', 'R_FACOAL244_1', 'R_FACOAL245_1', 'R_FACOAL245_2', 'R_FACOAL246_1',
              'R_r0311', 'R_r1251', 'R_r1252', 'R_r1253', 'R_r1254', 'R_r1255',
              'R_r1257', 'R_r1259', 'R_r1260', 'R_r1262', 'R_r1487', 'R_RE2912M',
              'R_RE3074X', 'R_RE3114R', 'R_RE3132R', 'R_RE3146R', 'R_RE3160R', 'R_HMR_0188',
              'R_HMR_0192', 'R_HMR_0200', 'R_HMR_0204', 'R_HMR_0209', 'R_HMR_0233', 'R_HMR_0241',
              'R_HMR_0245', 'R_HMR_0255', 'R_HMR_0259', 'R_HMR_0267', 'R_HMR_0271', 'R_HMR_0279',
              'R_HMR_0289', 'R_HMR_0293', 'R_HMR_0297', 'R_HMR_0301', 'R_HMR_0305', 'R_HMR_0309',
              'R_HMR_0319', 'R_HMR_0323', 'R_HMR_0327', 'R_HMR_0345', 'R_HMR_0381', 'R_HMR_0385',
              'R_HMR_0389', 'R_HMR_0393', 'R_HMR_0429', 'R_HMR_0433', 'R_HMR_0437', 'R_HMR_2942',
              'R_HMR_2943', 'R_HMR_2944', 'R_HMR_2945', 'R_HMR_2946', 'R_HMR_2947', 'R_HMR_2948',
              'R_HMR_2951', 'R_HMR_2954', 'R_HMR_2955', 'R_HMR_2956', 'R_HMR_2961', 'R_HMR_2962',
              'R_HMR_2963', 'R_HMR_2964', 'R_HMR_2965', 'R_HMR_2966', 'R_HMR_2967', 'R_HMR_2968',
              'R_HMR_2969', 'R_HMR_2970', 'R_HMR_2971', 'R_HMR_2972', 'R_HMR_2973', 'R_HMR_2974',
              'R_HMR_2975', 'R_HMR_2976', 'R_HMR_2977', 'R_HMR_2978', 'R_HMR_2979', 'R_HMR_2980',
              'R_HMR_2982', 'R_HMR_2983', 'R_HMR_2985', 'R_HMR_2986', 'R_HMR_2988', 'R_HMR_2989',
              'R_HMR_2990', 'R_HMR_2994', 'R_HMR_2998', 'R_HMR_2999', 'R_HMR_3001', 'R_HMR_3002',
              'R_HMR_3003', 'R_HMR_2957')
    'E0739'. ('R_FACOAL150', 'R_FACOAL160i', 'R_FACOAL170', 'R_FACOAL180i', 'R_FACOAL181i', 'R_FACOAL204',
              'R_FACOAL80i')
    'E0740'. ('R_FACOAL160i', 'R_FACOAL180i', 'R_FACOAL1831', 'R_r0311', 'R_r1251', 'R_r1252',
              'R_r1253', 'R_r1254', 'R_r1255', 'R_r1257', 'R_r1259', 'R_r1260',
              'R_r1262', 'R_r1487', 'R_RE2912M', 'R_RE3074X', 'R_RE3114R', 'R_RE3132R',
              'R_RE3146R', 'R_RE3160R', 'R_FAOXC16DCr', 'R_HMR_0188', 'R_HMR_0192', 'R_HMR_0200',
              'R_HMR_0204', 'R_HMR_0209', 'R_HMR_0233', 'R_HMR_0241', 'R_HMR_0245', 'R_HMR_0255',
              'R_HMR_0259', 'R_HMR_0267', 'R_HMR_0271', 'R_HMR_0279', 'R_HMR_0289', 'R_HMR_0293',
              'R_HMR_0297', 'R_HMR_0301', 'R_HMR_0305', 'R_HMR_0309', 'R_HMR_0319', 'R_HMR_0323',
              'R_HMR_0327', 'R_HMR_0345', 'R_HMR_0381', 'R_HMR_0385', 'R_HMR_0389', 'R_HMR_0393',
              'R_HMR_0429', 'R_HMR_0433', 'R_HMR_0437', 'R_HMR_2942', 'R_HMR_2943', 'R_HMR_2944',
              'R_HMR_2945', 'R_HMR_2946', 'R_HMR_2947', 'R_HMR_2948', 'R_HMR_2951', 'R_HMR_2954',
              'R_HMR_2955', 'R_HMR_2956', 'R_HMR_2961', 'R_HMR_2962', 'R_HMR_2963', 'R_HMR_2964',
              'R_HMR_2965', 'R_HMR_2966', 'R_HMR_2967', 'R_HMR_2968', 'R_HMR_2969', 'R_HMR_2970',
              'R_HMR_2971', 'R_HMR_2972', 'R_HMR_2973', 'R_HMR_2974', 'R_HMR_2975', 'R_HMR_2976',
              'R_HMR_2977', 'R_HMR_2978', 'R_HMR_2979', 'R_HMR_2980', 'R_HMR_2982', 'R_HMR_2983',
              'R_HMR_2985', 'R_HMR_2986', 'R_HMR_2988', 'R_HMR_2989', 'R_HMR_2990', 'R_HMR_2994',
              'R_HMR_2998', 'R_HMR_2999', 'R_HMR_3001', 'R_HMR_3002', 'R_HMR_3003', 'R_HMR_2957')
    'E0741'. ('R_FACOAL160i', 'R_FACOAL181i', 'R_FACOAL1821', 'R_FACOAL1831', 'R_FACOAL204', 'R_r0311',
              'R_r1251', 'R_r1252', 'R_r1253', 'R_r1254', 'R_r1255', 'R_r1257',
              'R_r1259', 'R_r1260', 'R_r1262', 'R_r1487', 'R_HMR_0188', 'R_HMR_0192',
              'R_HMR_0200', 'R_HMR_0204', 'R_HMR_0209', 'R_HMR_0233', 'R_HMR_0241', 'R_HMR_0245',
              'R_HMR_0255', 'R_HMR_0259', 'R_HMR_0267', 'R_HMR_0271', 'R_HMR_0279', 'R_HMR_0289',
              'R_HMR_0293', 'R_HMR_0297', 'R_HMR_0301', 'R_HMR_0305', 'R_HMR_0309', 'R_HMR_0319',
              'R_HMR_0323', 'R_HMR_0327', 'R_HMR_0345', 'R_HMR_0381', 'R_HMR_0385', 'R_HMR_0389',
              'R_HMR_0393', 'R_HMR_0429', 'R_HMR_0433', 'R_HMR_0437', 'R_HMR_2942', 'R_HMR_2943',
              'R_HMR_2944', 'R_HMR_2945', 'R_HMR_2946', 'R_HMR_2947', 'R_HMR_2948', 'R_HMR_2951',
              'R_HMR_2954', 'R_HMR_2955', 'R_HMR_2956', 'R_HMR_2961', 'R_HMR_2962', 'R_HMR_2963',
              'R_HMR_2964', 'R_HMR_2965', 'R_HMR_2966', 'R_HMR_2967', 'R_HMR_2968', 'R_HMR_2969',
              'R_HMR_2970', 'R_HMR_2971', 'R_HMR_2972', 'R_HMR_2973', 'R_HMR_2974', 'R_HMR_2975',
              'R_HMR_2976', 'R_HMR_2977', 'R_HMR_2978', 'R_HMR_2979', 'R_HMR_2980', 'R_HMR_2982',
              'R_HMR_2983', 'R_HMR_2985', 'R_HMR_2986', 'R_HMR_2988', 'R_HMR_2989', 'R_HMR_2990',
              'R_HMR_2994', 'R_HMR_2998', 'R_HMR_2999', 'R_HMR_3001', 'R_HMR_3002', 'R_HMR_3003',
              'R_HMR_2957')
    'E0742'. ('R_FACOAL1831', 'R_r0311', 'R_r1251', 'R_r1252', 'R_r1253', 'R_r1254',
              'R_r1255', 'R_r1257', 'R_r1259', 'R_r1260', 'R_r1262', 'R_r1487',
              'R_RE2912M', 'R_RE3074X', 'R_RE3114R', 'R_RE3132R', 'R_RE3146R', 'R_RE3160R',
              'R_HMR_0188', 'R_HMR_0192', 'R_HMR_0200', 'R_HMR_0204', 'R_HMR_0209', 'R_HMR_0233',
              'R_HMR_0241', 'R_HMR_0245', 'R_HMR_0255', 'R_HMR_0259', 'R_HMR_0267', 'R_HMR_0271',
              'R_HMR_0279', 'R_HMR_0289', 'R_HMR_0293', 'R_HMR_0297', 'R_HMR_0301', 'R_HMR_0305',
              'R_HMR_0309', 'R_HMR_0319', 'R_HMR_0323', 'R_HMR_0327', 'R_HMR_0345', 'R_HMR_0381',
              'R_HMR_0385', 'R_HMR_0389', 'R_HMR_0393', 'R_HMR_0429', 'R_HMR_0433', 'R_HMR_0437',
              'R_HMR_2942', 'R_HMR_2943', 'R_HMR_2944', 'R_HMR_2945', 'R_HMR_2946', 'R_HMR_2947',
              'R_HMR_2948', 'R_HMR_2951', 'R_HMR_2954', 'R_HMR_2955', 'R_HMR_2956', 'R_HMR_2961',
              'R_HMR_2962', 'R_HMR_2963', 'R_HMR_2964', 'R_HMR_2965', 'R_HMR_2966', 'R_HMR_2967',
              'R_HMR_2968', 'R_HMR_2969', 'R_HMR_2970', 'R_HMR_2971', 'R_HMR_2972', 'R_HMR_2973',
              'R_HMR_2974', 'R_HMR_2975', 'R_HMR_2976', 'R_HMR_2977', 'R_HMR_2978', 'R_HMR_2979',
              'R_HMR_2980', 'R_HMR_2982', 'R_HMR_2983', 'R_HMR_2985', 'R_HMR_2986', 'R_HMR_2988',
              'R_HMR_2989', 'R_HMR_2990', 'R_HMR_2994', 'R_HMR_2998', 'R_HMR_2999', 'R_HMR_3001',
              'R_HMR_3002', 'R_HMR_3003', 'R_HMR_2957')
    'E0743'. ('R_FACOAL204')
    'E0744'. ('R_HMR_0156', 'R_HMR_0165', 'R_HMR_0168', 'R_HMR_0171', 'R_HMR_0177', 'R_HMR_0180',
              'R_HMR_0184')
    'E0745'. ('R_FADDP', 'R_r0591')
    'E0747'. ('R_FAEL183', 'R_FAEL184', 'R_FAEL204', 'R_FAEL205', 'R_RE0569C', 'R_RE3103C',
              'R_RE3110C', 'R_RE3120C', 'R_RE3151C', 'R_RE3161C', 'R_RE3165C', 'R_RE3170C',
              'R_RE3174C', 'R_RE3224C', 'R_RE3225C', 'R_RE3226C', 'R_RE3241C', 'R_HMR_2190',
              'R_HMR_2211', 'R_HMR_2215', 'R_HMR_2259', 'R_HMR_2263', 'R_HMR_2267', 'R_HMR_2332',
              'R_HMR_2342', 'R_HMR_2347', 'R_HMR_2353', 'R_HMR_2361', 'R_HMR_2395', 'R_HMR_2433',
              'R_HMR_2530', 'R_HMR_2540')
    'E0752'. ('R_FAOXC11')
    'E0753'. ('R_FAOXC16080x', 'R_FAOXC180x', 'R_FAOXC183806x', 'R_FAOXC18480x', 'R_FAOXC200180x', 'R_FAOXC2051843x',
              'R_FAOXC2242046x', 'R_FAOXC2251836x', 'R_FAOXC2252053x', 'R_FAOXC226205x', 'R_FAOXC240200x', 'R_FAOXC241181x',
              'R_FAOXC2442246x', 'R_FAOXC2452253x', 'R_FAOXC2452256x', 'R_FAOXC246226x', 'R_FAOXC260240x')
    'E0755'. ('R_FAS100COA', 'R_FAS120COA')
    'E0757'. ('R_FATP1t', 'R_FATP2t', 'R_FATP3t')
    'E0758'. ('R_FATP1t', 'R_DOCO13EFATP', 'R_OCT11EFATP', 'R_ARACHDFATPtc', 'R_CE2510ABCt', 'R_CE2537ABCt',
              'R_NRVNCABCt', 'R_HMR_0155', 'R_HMR_0164', 'R_HMR_0167', 'R_HMR_0170', 'R_HMR_0176',
              'R_HMR_0183', 'R_HMR_0191', 'R_HMR_0203', 'R_HMR_0208', 'R_HMR_0232', 'R_HMR_0240',
              'R_HMR_0244', 'R_HMR_0254', 'R_HMR_0270', 'R_HMR_0278', 'R_HMR_0288', 'R_HMR_0292',
              'R_HMR_0296', 'R_HMR_0300', 'R_HMR_0304', 'R_HMR_0308', 'R_HMR_0322', 'R_HMR_0326',
              'R_HMR_0344', 'R_HMR_0380', 'R_HMR_0384', 'R_HMR_0388', 'R_HMR_0392', 'R_HMR_0428',
              'R_HMR_0432', 'R_HMR_0436')
    'E0759'. ('R_FATP1t', 'R_FATP2t', 'R_FATP3t', 'R_DOCO13EFATP', 'R_OCT11EFATP', 'R_ARACHDFATPtc',
              'R_LGNCFATPtc', 'R_CE2510ABCt', 'R_CE2537ABCt', 'R_NRVNCABCt', 'R_HMR_0155', 'R_HMR_0164',
              'R_HMR_0167', 'R_HMR_0170', 'R_HMR_0176', 'R_HMR_0183', 'R_HMR_0191', 'R_HMR_0203',
              'R_HMR_0208', 'R_HMR_0232', 'R_HMR_0240', 'R_HMR_0244', 'R_HMR_0254', 'R_HMR_0270',
              'R_HMR_0278', 'R_HMR_0288', 'R_HMR_0292', 'R_HMR_0296', 'R_HMR_0300', 'R_HMR_0304',
              'R_HMR_0308', 'R_HMR_0322', 'R_HMR_0326', 'R_HMR_0344', 'R_HMR_0380', 'R_HMR_0384',
              'R_HMR_0388', 'R_HMR_0392', 'R_HMR_0428', 'R_HMR_0432', 'R_HMR_0436')
    'E0760'. ('R_FATP1t', 'R_DOCO13EFATP', 'R_OCT11EFATP', 'R_CE2510ABCt', 'R_CE2537ABCt', 'R_NRVNCABCt',
              'R_HMR_0155', 'R_HMR_0164', 'R_HMR_0167', 'R_HMR_0170', 'R_HMR_0176', 'R_HMR_0183',
              'R_HMR_0191', 'R_HMR_0203', 'R_HMR_0208', 'R_HMR_0232', 'R_HMR_0240', 'R_HMR_0244',
              'R_HMR_0254', 'R_HMR_0270', 'R_HMR_0278', 'R_HMR_0288', 'R_HMR_0292', 'R_HMR_0296',
              'R_HMR_0300', 'R_HMR_0304', 'R_HMR_0308', 'R_HMR_0322', 'R_HMR_0326', 'R_HMR_0344',
              'R_HMR_0380', 'R_HMR_0384', 'R_HMR_0388', 'R_HMR_0392', 'R_HMR_0428', 'R_HMR_0432',
              'R_HMR_0436')
    'E0761'. ('R_FBA4', 'R_FBA', 'R_FBA2')
    'E0762'. ('R_FBA4', 'R_FBA5', 'R_r0407', 'R_FBA', 'R_FBA2', 'R_HMR_8762')
    'E0764'. ('R_FBA4', 'R_r0407', 'R_FBA', 'R_FBA2', 'R_HMR_8762')
    'E0766'. ('R_FBP26', 'R_FBP')
    'E0767'. ('R_FBP26', 'R_PFK26')
    'E0772'. ('R_FCLTm')
    'E0775'. ('R_FE3R2e')
    'E0776'. ('R_FK')
    'E0778'. ('R_FOLR2', 'R_r0224', 'R_r0226', 'R_r0512', 'R_r0514', 'R_DHFR')
    'E0779'. ('R_FPGS2', 'R_FPGS2m', 'R_FPGS3', 'R_FPGS3m', 'R_FPGS4', 'R_FPGS4m',
              'R_FPGS5', 'R_FPGS5m', 'R_FPGS6', 'R_FPGS6m', 'R_FPGS7m', 'R_FPGS8',
              'R_FPGS8m', 'R_FPGS9', 'R_FPGS9m', 'R_FPGSm', 'R_r1382', 'R_FPGS7',
              'R_FPGS')
    'E0780'. ('R_FRUt1r', 'R_GALt1r', 'R_GLCt1r')
    'E0781'. ('R_FRUt1r', 'R_GALt1r', 'R_GAMt1r', 'R_GLCt1r')
    'E0782'. ('R_FRUt1r', 'R_GLCt1r')
    'E0783'. ('R_FRUt1r', 'R_GLCRt1')
    'E0786'. ('R_FTHFLm', 'R_MTHFCm', 'R_MTHFDm')
    'E0787'. ('R_FTHFLm', 'R_MTHFDm', 'R_MTHFC', 'R_MTHFD')
    'E0788'. ('R_FUCASE2e', 'R_FUCASEe')
    'E0789'. ('R_FUCASE2ly', 'R_FUCASEly')
    'E0791'. ('R_FUMm')
    'E0792'. ('R_FUT12g', 'R_FUT14g', 'R_FUT18g', 'R_HMR_0864')
    'E0793'. ('R_FUT34g', 'R_HMR_0870', 'R_HMR_0873', 'R_HMR_0911', 'R_HMR_8271')
    'E0794'. ('R_FUT910g', 'R_FUT911g', 'R_FUT91g', 'R_FUT93g', 'R_FUT98g', 'R_FUT99g',
              'R_HMR_0765', 'R_HMR_0911', 'R_HMR_8287')
    'E0795'. ('R_G14T18g', 'R_G14T19g', 'R_G14T20g', 'R_G14T21g', 'R_G14T2g', 'R_G14T3g',
              'R_G14T4g', 'R_G14T5g', 'R_HMR_0765', 'R_HMR_0875', 'R_HMR_0890')
    'E0796'. ('R_G14T18g', 'R_G14T19g', 'R_G14T20g', 'R_G14T21g', 'R_G14T2g', 'R_G14T3g',
              'R_G14T4g', 'R_G14T5g')
    'E0799'. ('R_G14T18g', 'R_G14T19g', 'R_G14T20g', 'R_G14T21g', 'R_G14T2g', 'R_G14T3g',
              'R_G14T4g', 'R_G14T5g', 'R_HMR_0765')
    'E0800'. ('R_G3PD2m', 'R_r0205', 'R_HMR_0482')
    'E0801'. ('R_G5SDym', 'R_GCALDDm', 'R_GLU5Km', 'R_LCADim')
    'E0803'. ('R_G6PDH2c', 'R_G6PDH2r')
    'E0804'. ('R_G6Pter', 'R_PIter', 'R_r2473')
    'E0805'. ('R_GACMTRc')
    'E0808'. ('R_GALASE10ly', 'R_GALASE11ly', 'R_GALASE12ly', 'R_GALASE13ly', 'R_GALASE14ly', 'R_GALASE15ly',
              'R_GALASE16ly', 'R_GALASE17ly', 'R_GALASE18ly', 'R_GALASE19ly', 'R_GALASE20ly', 'R_GALASE3ly',
              'R_GALASE4ly', 'R_GALASE5ly', 'R_GALASE6ly', 'R_GALASE7ly', 'R_GALASE8ly', 'R_GALASE9ly',
              'R_S6TASE10ly', 'R_S6TASE22ly', 'R_S6TASE25ly', 'R_S6TASE8ly', 'R_S6TASE9ly', 'R_SIAASE2ly',
              'R_SIAASE3ly', 'R_SIAASE4ly')
    'E0809'. ('R_GALASE10ly', 'R_GALASE11ly', 'R_GALASE12ly', 'R_GALASE13ly', 'R_GALASE14ly', 'R_GALASE15ly',
              'R_GALASE16ly', 'R_GALASE17ly', 'R_GALASE18ly', 'R_GALASE19ly', 'R_GALASE20ly', 'R_GALASE3ly',
              'R_GALASE4ly', 'R_GALASE5ly', 'R_GALASE6ly', 'R_GALASE7ly', 'R_GALASE8ly', 'R_GALASE9ly')
    'E0810'. ('R_GALC', 'R_RE2717L', 'R_HMR_0793')
    'E0811'. ('R_GALGT1')
    'E0812'. ('R_GALNACT1g', 'R_GALNACT2g', 'R_GALNACT3g', 'R_GALNACT4g', 'R_GALNACT5g')
    'E0814'. ('R_GALNACT2g', 'R_GALNACT3g', 'R_GALNACT4g', 'R_GALNACT5g', 'R_GLCAT2g', 'R_GLCAT3g',
              'R_GLCAT4g', 'R_GLCAT5g')
    'E0816'. ('R_GALNTg')
    'E0828'. ('R_GALNTg', 'R_HMR_0765')
    'E0832'. ('R_GALt1r', 'R_GLCt1r')
    'E0833'. ('R_GALT2g')
    'E0834'. ('R_GALTg', 'R_HMR_0765')
    'E0835'. ('R_GAMYe', 'R_MALTe', 'R_MLTG1e', 'R_SUCRe')
    'E0836'. ('R_GARFT', 'R_PRAGSr', 'R_r0666')
    'E0837'. ('R_GARFT', 'R_PRAGSr')
    'E0838'. ('R_GASNASE2ly', 'R_GASNASE3ly', 'R_GASNASEly')
    'E0839'. ('R_GBA', 'R_GBAl')
    'E0844'. ('R_GBGT1', 'R_HMR_0765', 'R_HMR_0810')
    'E0845'. ('R_GCALDDm', 'R_LCADim', 'R_MMSAD3m')
    'E0846'. ('R_GCALDDm', 'R_LCADim')
    'E0848'. ('R_GCC2cm')
    'E0849'. ('R_GCNTg')
    'E0850'. ('R_GDPFUCtg')
    'E0851'. ('R_GFUCS', 'R_r0782')
    'E0852'. ('R_GGH_10FTHF5GLUe', 'R_GGH_10FTHF5GLUl', 'R_GGH_10FTHF6GLUe', 'R_GGH_10FTHF6GLUl', 'R_GGH_10FTHF7GLUe', 'R_GGH_10FTHF7GLUl',
              'R_GGH_5DHFe', 'R_GGH_5DHFl', 'R_GGH_5THFe', 'R_GGH_5THFl', 'R_GGH_6DHFe', 'R_GGH_6DHFl',
              'R_GGH_6THFe', 'R_GGH_6THFl', 'R_GGH_7DHFe', 'R_GGH_7DHFl', 'R_GGH_7THFe', 'R_GGH_7THFl',
              'R_r1383')
    'E0858'. ('R_r0129', 'R_r0130', 'R_r0641', 'R_r0648', 'R_r0649', 'R_HMR_1084')
    'E0859'. ('R_GHMT2rm')
    'E0860'. ('R_GHMT2rm', 'R_GHMT3', 'R_GHMT2r')
    'E0861'. ('R_GHMT3', 'R_GHMT2r')
    'E0862'. ('R_GLAl', 'R_r0627', 'R_HMR_0803')
    'E0864'. ('R_GLCAASE1ly', 'R_GLCAASE4ly', 'R_GLCAASE5ly', 'R_GLCAASE6ly', 'R_GLCAASE7ly', 'R_GLCAASE8ly',
              'R_GLCAASE9ly')
    'E0865'. ('R_GLCAASE8ly')
    'E0866'. ('R_GLCAE2g')
    'E0867'. ('R_GLCAT2g', 'R_GLCAT3g', 'R_GLCAT4g', 'R_GLCAT5g')
    'E0868'. ('R_GLCAT6g', 'R_GLCAT7g', 'R_GLCAT8g', 'R_GLCAT9g', 'R_GLCNACT2g', 'R_GLCNACT3g',
              'R_GLCNACT4g', 'R_GLCNACT5g')
    'E0869'. ('R_GLCATg')
    'E0873'. ('R_GLCNACASE1ly', 'R_GLCNACASE2ly', 'R_GLCNACASE3ly', 'R_GLCNACASE4ly', 'R_GLCNACASE5ly')
    'E0874'. ('R_GLCNACDASg')
    'E0878'. ('R_GLCNACT1g', 'R_GLCNACT2g', 'R_GLCNACT3g', 'R_GLCNACT4g', 'R_GLCNACT5g')
    'E0879'. ('R_GLCNACT1g')
    'E0880'. ('R_GLCNACT2g', 'R_GLCNACT3g', 'R_GLCNACT4g', 'R_GLCNACT5g')
    'E0881'. ('R_GLCt1r')
    'E0886'. ('R_GLCt2_2', 'R_NAt', 'R_UREAt5', 'R_GALSGLT1le', 'R_GLCSGLT1le', 'R_GALt2_2',
              'R_UREAt', 'R_HMR_8877', 'R_HMR_8884')
    'E0887'. ('R_GLDBRAN')
    'E0893'. ('R_GLPASE1', 'R_GLPASE2')
    'E0896'. ('R_GLUCYS')
    'E0899'. ('R_GluForTx', 'R_FORTHFC', 'R_HMR_9726')
    'E0900'. ('R_GluForTx', 'R_FORTHFC')
    'E0901'. ('R_GLUNm')
    'E0903'. ('R_GLUNm', 'R_HMR_9802')
    'E0906'. ('R_GLUTCOADHm', 'R_r0541')
    'E0907'. ('R_GLUTCOADHm')
    'E0911'. ('R_GLXO2p', 'R_GLYCTO1p', 'R_HMR_7703')
    'E0912'. ('R_GLXO2p', 'R_GLYCTO1p')
    'E0916'. ('R_GLYKm', 'R_GLYK')
    'E0920'. ('R_GLYOX')
    'E0921'. ('R_GLYt7_211_r', 'R_HMR_9593')
    'E0922'. ('R_GLYt7_211_r')
    'E0923'. ('R_GNDer', 'R_GNDc', 'R_GND')
    'E0926'. ('R_GPIAT')
    'E0927'. ('R_GPIDA2er', 'R_GPIDAer')
    'E0928'. ('R_GPIMTer_U')
    'E0929'. ('R_GTHO', 'R_GTHOm', 'R_r0021', 'R_r0022')
    'E0930'. ('R_GTHP')
    'E0932'. ('R_GTHP', 'R_GTHPe', 'R_HMR_0960', 'R_HMR_0963')
    'E0935'. ('R_GTHP', 'R_GTHPe', 'R_GTHPm', 'R_HMR_0960', 'R_HMR_0963')
    'E0938'. ('R_GTHP', 'R_GTHPm', 'R_HMR_0960', 'R_HMR_0963')
    'E0940'. ('R_GTHPe', 'R_HMR_0960', 'R_HMR_0963')
    'E0943'. ('R_GTHPm')
    'E0945'. ('R_GTHS')
    'E0946'. ('R_GTMLTe', 'R_HMR_1084')
    'E0947'. ('R_GTMLTe', 'R_r0129', 'R_r0130', 'R_r0641', 'R_r0648', 'R_r0649',
              'R_HMR_1084')
    'E0948'. ('R_GTMLTe')
    'E0950'. ('R_GUACYC')
    'E0960'. ('R_GUAD')
    'E0961'. ('R_H2CO3Dm')
    'E0963'. ('R_H2ETer', 'R_H3ETer', 'R_H4ETer', 'R_H6_ETer', 'R_H7_ETer', 'R_HMR_8397',
              'R_HMR_8399')
    'E0964'. ('R_H2ETer', 'R_H3ETer', 'R_H4ETer', 'R_H6_ETer', 'R_H7_ETer')
    'E0965'. ('R_H2MTer_U', 'R_H5MTer_U', 'R_HMR_0765')
    'E0966'. ('R_H2O2syn')
    'E0970'. ('R_H4ET3er', 'R_H6ET3er', 'R_M4CET3er')
    'E0971'. ('R_H6_ET2er')
    'E0972'. ('R_H6MTer_U', 'R_H7MTer_U', 'R_HMR_0765')
    'E0973'. ('R_H7_TAer', 'R_H8TAer', 'R_M4BTAer')
    'E0974'. ('R_HACD1m', 'R_RE0512M', 'R_RE1525M', 'R_RE1526M', 'R_RE1527M', 'R_RE3005M',
              'R_RE3177M', 'R_RE3178M', 'R_RE3179M', 'R_HMR_1651', 'R_HMR_3109', 'R_HMR_3113',
              'R_HMR_3117', 'R_HMR_3172', 'R_HMR_3176', 'R_HMR_3180', 'R_HMR_3184', 'R_HMR_3188',
              'R_HMR_3192', 'R_HMR_3196', 'R_HMR_3200', 'R_HMR_3204', 'R_HMR_3220', 'R_HMR_3224',
              'R_HMR_3232', 'R_HMR_3236', 'R_HMR_3242', 'R_HMR_3246', 'R_HMR_3398', 'R_HMR_3406',
              'R_HMR_3407', 'R_HMR_3408', 'R_HMR_3409', 'R_HMR_3411', 'R_HMR_3413', 'R_HMR_3414',
              'R_HMR_3416', 'R_HMR_3421', 'R_HMR_3422', 'R_HMR_3423', 'R_HMR_3424', 'R_HMR_3425',
              'R_HMR_3426', 'R_HMR_3427', 'R_HMR_3428', 'R_HMR_3429', 'R_HMR_3431', 'R_HMR_3432',
              'R_HMR_3433', 'R_HMR_3450', 'R_HMR_3454', 'R_HMR_9719')
    'E0976'. ('R_HAS1', 'R_HAS2')
    'E0980'. ('R_HBZOPT10m')
    'E0981'. ('R_HCO3_CLt')
    'E0983'. ('R_HCO3_CLt', 'R_5HOXINDOAtr')
    'E0986'. ('R_HEX10', 'R_HEX4', 'R_HEX1', 'R_HEX7')
    'E0999'. ('R_HISDC')
    'E1002'. ('R_HMGCOASi', 'R_r0463')
    'E1003'. ('R_HMGCOASi')
    'E1004'. ('R_HMGCOASim')
    'E1005'. ('R_HMGLm', 'R_HMGLx')
    'E1006'. ('R_HMGLm')
    'E1009'. ('R_HPCLx')
    'E1010'. ('R_HPYRR2x', 'R_LDH_Lm', 'R_GLXO1', 'R_LDH_D', 'R_HMR_3859')
    'E1011'. ('R_HPYRR2x', 'R_GLXO1', 'R_LDH_D')
    'E1012'. ('R_HS1ly', 'R_HS2ly', 'R_HS3ly', 'R_HS4ly')
    'E1016'. ('R_HSD17B1', 'R_HMR_2041')
    'E1018'. ('R_HMR_2041')
    'E1019'. ('R_HSD17B7r', 'R_HSD17B9r', 'R_r1135', 'R_HMR_1509', 'R_HMR_1547', 'R_HMR_1552',
              'R_HMR_2041', 'R_HMR_1500')
    'E1021'. ('R_HSD3B2r', 'R_HSD3B3r')
    'E1022'. ('R_HMR_1738', 'R_HMR_1766')
    'E1025'. ('R_ICDHy', 'R_ICDHyp', 'R_r0083', 'R_r0084', 'R_r0423', 'R_r0424',
              'R_r0425', 'R_r0082', 'R_r0422')
    'E1026'. ('R_ICDHyrm', 'R_r0083', 'R_r0084', 'R_r0423', 'R_r0424', 'R_r0425',
              'R_r0422')
    'E1027'. ('R_IDHPOXOX2b', 'R_IDHPOXOX3', 'R_IDHPOXOX4', 'R_IDHPOXOXb', 'R_THYPX')
    'E1028'. ('R_IDHPOXOX2b', 'R_IDHPOXOX3', 'R_IDHPOXOX4', 'R_IDHPOXOXb', 'R_THYPX', 'R_RE2888C',
              'R_RE3095C', 'R_HMR_2088', 'R_HMR_2089')
    'E1032'. ('R_IDOAASE1ly', 'R_IDOAASE2ly', 'R_IDOAASE3ly', 'R_IDOAASE4ly')
    'E1033'. ('R_ILETAm', 'R_LEUTAm', 'R_VALTAm')
    'E1037'. ('R_NAt', 'R_GLCt4')
    'E1038'. ('R_IPDDIx', 'R_IPDDI')
    'E1040'. ('R_It')
    'E1041'. ('R_ITCOAL1m', 'R_KER_02406')
    'E1042'. ('R_ITCOALm')
    'E1043'. ('R_KCC2t', 'R_KCCt')
    'E1046'. ('R_KCCt')
    'E1047'. ('R_KHK', 'R_KHK2', 'R_KHK3', 'R_HMR_8761')
    'E1048'. ('R_KHK', 'R_KHK2', 'R_KHK3')
    'E1049'. ('R_Kt3g', 'R_NAt3_1g')
    'E1051'. ('R_KYN3OX')
    'E1052'. ('R_LACZe', 'R_HMR_0819', 'R_HMR_0830')
    'E1053'. ('R_LACZe', 'R_r0380', 'R_r0737', 'R_r1411', 'R_BGAL1e', 'R_HMR_0819',
              'R_HMR_0830')
    'E1054'. ('R_LAPCOAl', 'R_NTD2l')
    'E1056'. ('R_LEUKTRA4t', 'R_LEUKTRB4t', 'R_LEUKTRE4t', 'R_LEUKTRF4t', 'R_r2341', 'R_r2342',
              'R_r2343', 'R_r2344', 'R_r2346', 'R_r2347', 'R_r2352', 'R_r2353',
              'R_r2354', 'R_r2355', 'R_r2356', 'R_r2357', 'R_r2358', 'R_r2359',
              'R_r2360', 'R_r2361', 'R_r2362', 'R_r2363', 'R_r2364', 'R_r2365',
              'R_r2366', 'R_r2367', 'R_r2368', 'R_r2369')
    'E1057'. ('R_L_LACDcm', 'R_HMR_3859')
    'E1058'. ('R_L_LACtcm', 'R_UREAtm', 'R_H2OGLYAQPt')
    'E1059'. ('R_LNS14DM', 'R_RE2235R', 'R_HMR_0942', 'R_HMR_0946', 'R_HMR_0950', 'R_HMR_0954',
              'R_HMR_0981', 'R_HMR_1126', 'R_HMR_1127', 'R_HMR_2029', 'R_HMR_2457')
    'E1060'. ('R_LNSTLSr', 'R_HMR_1473')
    'E1061'. ('R_PLA2_2', 'R_PCHOLMYR_HSPLA2', 'R_PCHOLOLE_HSPLA2', 'R_PEOLE_HSPLA2', 'R_PCHOLPALME_HSPLA2', 'R_PCHOLPALM_HSPLA2',
              'R_PEPALM_HSPLA2', 'R_PAILPALM_HSPLA2', 'R_PCHOLSTE_HSPLA2', 'R_PCHOL2LINL_HSPLA2', 'R_PE2LINL_HSPLA2', 'R_PCHOL2OLE_HSPLA2',
              'R_PCHOL2PALM_HSPLA2', 'R_PCHOL2STE_HSPLA2', 'R_PCHOLN15_HSPLA2', 'R_PCHOLAR_HSPLA2', 'R_PCHOLN183_HSPLA2', 'R_PCHOLN1836_HSPLA2',
              'R_PCHOLN19_HSPLA2', 'R_PCHOLN201_HSPLA2', 'R_PCHOLN204_HSPLA2', 'R_PCHOLN205_HSPLA2', 'R_PCHOLN224_HSPLA2', 'R_PCHOLN225_HSPLA2',
              'R_PCHOLN2254_HSPLA2', 'R_PCHOLN226_HSPLA2', 'R_PEAR_HSPLA2', 'R_PE203_HSPLA2', 'R_PE226_HSPLA2', 'R_PE224_HSPLA2',
              'R_PEDH203_HSPLA2', 'R_PEDH12_HSPLA2', 'R_PEDH14_HSPLA2', 'R_PEDH161_HSPLA2', 'R_PEDH13_HSPLA2', 'R_PEDH15_HSPLA2',
              'R_PEDH17_HSPLA2', 'R_PCHOLN203_HSPLA2', 'R_PAILAR_HSPLA2', 'R_PCHOLN24_HSPLA2', 'R_PCHOLN261_HSPLA2', 'R_PCHOLN281_HSPLA2',
              'R_PCHOLN28_HSPLA2', 'R_PCHOLDOC_HSPLA2', 'R_PCHOLDEIC_HSPLA2', 'R_PCHOLDET_HSPLA2', 'R_PCHOLHEP_HSPLA2', 'R_PCHOLLINL_HSPLA2',
              'R_PELINL_HSPLA2')
    'E1065'. ('R_LPS')
    'E1066'. ('R_LPS', 'R_HMR_0003', 'R_HMR_0672')
    'E1067'. ('R_LPS', 'R_r1174', 'R_r1175', 'R_r1177', 'R_r1183', 'R_HMR_0003',
              'R_HMR_0672', 'R_HMR_3684', 'R_HMR_3685', 'R_HMR_3686', 'R_HMR_3687', 'R_HMR_3688',
              'R_HMR_3689', 'R_HMR_3690', 'R_HMR_3692', 'R_HMR_3694', 'R_HMR_3695', 'R_HMR_3696',
              'R_HMR_3698', 'R_HMR_3699', 'R_HMR_3701', 'R_HMR_3703', 'R_HMR_3704', 'R_HMR_3705',
              'R_HMR_3706', 'R_HMR_3707', 'R_HMR_3708', 'R_HMR_3709', 'R_HMR_3710', 'R_HMR_3711',
              'R_HMR_3712', 'R_HMR_3713', 'R_HMR_3714', 'R_HMR_3715', 'R_HMR_3716', 'R_HMR_3717',
              'R_HMR_3718', 'R_HMR_3719', 'R_HMR_3721', 'R_HMR_3722', 'R_HMR_3723', 'R_HMR_3724',
              'R_HMR_3725', 'R_HMR_3726', 'R_HMR_3727', 'R_HMR_3728', 'R_HMR_3729', 'R_HMR_3736',
              'R_HMR_3737', 'R_HMR_3738', 'R_HMR_3739', 'R_HMR_3740', 'R_HMR_3741')
    'E1069'. ('R_LPS3')
    'E1072'. ('R_LRAT')
    'E1073'. ('R_LSTO1r', 'R_HMR_1516')
    'E1087'. ('R_MDH')
    'E1088'. ('R_ME1m', 'R_ME2m')
    'E1090'. ('R_ME2m')
    'E1092'. ('R_MELATNOX', 'R_HMR_0942', 'R_HMR_0946', 'R_HMR_0950', 'R_HMR_0954', 'R_HMR_2029',
              'R_HMR_2457', 'R_6BHGLZhr', 'R_7BHGLZhr', 'R_IBUP_RCYP2hep', 'R_IBUP_RCYP3hep', 'R_IBUP_SCYP2hep',
              'R_IBUP_SCYP3hep')
    'E1093'. ('R_MELATNOX', 'R_RE2235R', 'R_HMR_0942', 'R_HMR_0946', 'R_HMR_0950', 'R_HMR_0954',
              'R_HMR_2029', 'R_HMR_2457')
    'E1094'. ('R_MELATNOX', 'R_P4501B1r', 'R_RE2235R', 'R_HMR_0942', 'R_HMR_0946', 'R_HMR_0950',
              'R_HMR_0954', 'R_HMR_2029', 'R_HMR_2457')
    'E1100'. ('R_MEVK1c')
    'E1101'. ('R_MI1345PP', 'R_MI145PP', 'R_PI345P5P')
    'E1102'. ('R_MI1345PP', 'R_MI145PP', 'R_PI345P5P', 'R_PI45P5P')
    'E1103'. ('R_MI1345PP', 'R_MI145PP', 'R_PI345P5P', 'R_HMR_6545')
    'E1111'. ('R_MI145PK')
    'E1114'. ('R_MI1PS', 'R_HMR_6572')
    'E1116'. ('R_HMR_6549')
    'E1123'. ('R_MTAP')
    'E1124'. ('R_MTHFCm', 'R_MTHFDm', 'R_MTHFD2')
    'E1128'. ('R_NAGA2ly', 'R_NAGAly', 'R_HMR_0811', 'R_HMR_7469')
    'E1131'. ('R_NAIt', 'R_NAt', 'R_UREAt', 'R_HMR_6989')
    'E1143'. ('R_NAt5', 'R_NAt3_1')
    'E1146'. ('R_NBAHH_ir')
    'E1148'. ('R_NCCt')
    'E1149'. ('R_NCKt')
    'E1155'. ('R_NDP10ex', 'R_NDP3ex', 'R_NDP7er', 'R_NDP7ex', 'R_NDP8ex', 'R_NTP3e')
    'E1157'. ('R_NDP7er', 'R_NDP7g')
    'E1159'. ('R_NDPK1', 'R_NDPK2', 'R_NDPK3', 'R_NDPK4', 'R_NDPK5', 'R_NDPK6',
              'R_NDPK7', 'R_NDPK8', 'R_NDPK9')
    'E1160'. ('R_NDPK2n', 'R_NDPK7n', 'R_NDPK8n', 'R_NDPK1', 'R_NDPK2', 'R_NDPK3',
              'R_NDPK4', 'R_NDPK5', 'R_NDPK6', 'R_NDPK7', 'R_NDPK8', 'R_NDPK9')
    'E1161'. ('R_NDPK1m', 'R_NDPK3m', 'R_NDPK5m', 'R_NDPK6m', 'R_NDPK8m', 'R_NDPK1',
              'R_NDPK2', 'R_NDPK3', 'R_NDPK4', 'R_NDPK5', 'R_NDPK6', 'R_NDPK7',
              'R_NDPK8', 'R_NDPK9')
    'E1164'. ('R_NDPK1m', 'R_NDPK3m', 'R_NDPK5m', 'R_NDPK6m', 'R_NDPK8m')
    'E1165'. ('R_NH4t3r', 'R_MMAte')
    'E1166'. ('R_NH4t3r')
    'E1169'. ('R_NMNATm', 'R_NMNATr', 'R_NNATr')
    'E1170'. ('R_NMNATn', 'R_NNATn', 'R_NNATr')
    'E1171'. ('R_NMNATr', 'R_NNATr')
    'E1174'. ('R_NNMT')
    'E1176'. ('R_NOS1', 'R_NOS2', 'R_r0024', 'R_r0145')
    'E1177'. ('R_NOS1', 'R_NOS2')
    'E1182'. ('R_DURIPP', 'R_PUNP3', 'R_PUNP7')
    'E1183'. ('R_NRPPHRtu', 'R_PROSTGE2t2', 'R_PROSTGF2t', 'R_SRTNtu', 'R_HMR_2603', 'R_HMR_2609',
              'R_HMR_2612', 'R_HMR_2621', 'R_HMR_2624', 'R_HMR_2634', 'R_HMR_2644', 'R_HMR_2649',
              'R_HMR_2652', 'R_HMR_2655', 'R_HMR_2661', 'R_HMR_2667', 'R_HMR_2670', 'R_HMR_2673',
              'R_HMR_2676', 'R_HMR_2679', 'R_HMR_2682', 'R_HMR_2685', 'R_HMR_2688', 'R_HMR_2691',
              'R_HMR_2695', 'R_HMR_2700', 'R_HMR_2703', 'R_HMR_2706', 'R_HMR_2709', 'R_HMR_2712',
              'R_HMR_2715', 'R_HMR_2718', 'R_HMR_2722', 'R_HMR_2727', 'R_HMR_2731', 'R_HMR_2734',
              'R_HMR_2737', 'R_HMR_2740', 'R_HMR_2744', 'R_HMR_2748', 'R_HMR_2753', 'R_HMR_2757',
              'R_HMR_2760', 'R_HMR_2764', 'R_HMR_2769', 'R_HMR_2772', 'R_HMR_2775')
    'E1185'. ('R_NTD12', 'R_r0047', 'R_NTD4', 'R_NTD5', 'R_NTD6', 'R_NTD7',
              'R_NTD8', 'R_NTD10', 'R_NT5C', 'R_NTD3', 'R_HMR_6545')
    'E1186'. ('R_NTD12')
    'E1187'. ('R_NTD1m', 'R_NTD5m', 'R_r0047', 'R_HMR_6545')
    'E1188'. ('R_r0047', 'R_NTD4', 'R_NTD5', 'R_NTD6', 'R_NTD8', 'R_NTD9',
              'R_NTD10', 'R_NTD11', 'R_NT5C', 'R_NTD3')
    'E1189'. ('R_NTPP10', 'R_NTPP9')
    'E1190'. ('R_O16G2e', 'R_SUCRe')
    'E1192'. ('R_OCOAT1m')
    'E1194'. ('R_OIVD1m', 'R_OIVD2m', 'R_OIVD3m')
    'E1197'. ('R_ORPT', 'R_OMPDC')
    'E1198'. ('R_OXAHCOtex', 'R_SO4HCOtex', 'R_HMR_6534')
    'E1199'. ('R_OXAHCOtex', 'R_SO4HCOtex')
    'E1204'. ('R_HMR_1993')
    'E1207'. ('R_RE2235R', 'R_HMR_0942', 'R_HMR_0946', 'R_HMR_0950', 'R_HMR_0954', 'R_HMR_2029',
              'R_HMR_2457')
    'E1209'. ('R_P4501B1r', 'R_RE2235R', 'R_HMR_0942', 'R_HMR_0946', 'R_HMR_0950', 'R_HMR_0954',
              'R_HMR_2029', 'R_HMR_2457', 'R_12HTACRhr', 'R_14HMDZALThr', 'R_14HMDZhr', 'R_1OHMDZhr',
              'R_2HATVACIDOXDhc', 'R_2HATVLACOXDhc', 'R_35DSMVhep', 'R_3HPVShc', 'R_3HSMVhep', 'R_4HATVACIDOXDhc',
              'R_4HATVLACOXDhc', 'R_4OHMDZhr', 'R_5OHFVShc', 'R_6CSMVhep', 'R_6HMSMVhep', 'R_6HSMVhep',
              'R_6MSMVhep', 'R_AM19CSALThr', 'R_AM1CSAhr', 'R_AM9CSAhr', 'R_CRVS1M24hc', 'R_CRVS23M24hc',
              'R_CRVSM1hc', 'R_IBUP_RCYP2hep', 'R_IBUP_RCYP3hep', 'R_IBUP_SCYP2hep', 'R_IBUP_SCYP3hep', 'R_LVSTACOXD6Hhep',
              'R_LVSTACOXD6MEhep', 'R_LVSTOXD3Hhep', 'R_LVSTOXD6Hhep', 'R_LVSTOXD6METhep', 'R_NFDACOXDhc')
    'E1210'. ('R_HMR_1992')
    'E1211'. ('R_r0741', 'R_HMR_1746', 'R_HMR_1747', 'R_HMR_1748', 'R_HMR_1749', 'R_HMR_1750',
              'R_HMR_1751')
    'E1212'. ('R_P4502A6', 'R_RE2235R', 'R_HMR_0942', 'R_HMR_0946', 'R_HMR_0950', 'R_HMR_0954',
              'R_HMR_2029', 'R_HMR_2457')
    'E1213'. ('R_P4502A6', 'R_RE2235R', 'R_HMR_0942', 'R_HMR_0946', 'R_HMR_0950', 'R_HMR_0954',
              'R_HMR_2029', 'R_HMR_2457', 'R_3OHACMPhr')
    'E1215'. ('R_P4502C8', 'R_RE2235R', 'R_HMR_0942', 'R_HMR_0946', 'R_HMR_0950', 'R_HMR_0954',
              'R_HMR_2029', 'R_HMR_2457', 'R_2HATVACIDOXDhc', 'R_35DSMVhep', 'R_3HSMVhep', 'R_4HATVACIDOXDhc',
              'R_5OHFVShc', 'R_6BHGLZhr', 'R_6CSMVhep', 'R_6HMSMVhep', 'R_6HSMVhep', 'R_6MSMVhep',
              'R_7BHGLZhr', 'R_CRVS1M24hc', 'R_CRVS23M24hc', 'R_CRVSM1hc', 'R_CRVSM23hc', 'R_IBUP_RCYP2hep',
              'R_IBUP_RCYP3hep', 'R_IBUP_SCYP2hep', 'R_IBUP_SCYP3hep', 'R_LVSTACOXD6Hhep', 'R_LVSTACOXD6MEhep', 'R_LVSTOXD3Hhep',
              'R_LVSTOXD6Hhep', 'R_LVSTOXD6METhep', 'R_PTVSTM13hr')
    'E1216'. ('R_P4502C8')
    'E1217'. ('R_RE2235R', 'R_HMR_0942', 'R_HMR_0946', 'R_HMR_0950', 'R_HMR_0954', 'R_HMR_2029',
              'R_HMR_2457', 'R_5OHFVShc', 'R_6BHGLZhr', 'R_7BHGLZhr', 'R_IBUP_RCYP2hep', 'R_IBUP_RCYP3hep',
              'R_IBUP_SCYP2hep', 'R_IBUP_SCYP3hep', 'R_PROFVSCOAhc', 'R_PTVSTM13hr')
    'E1218'. ('R_RE2235R', 'R_HMR_0942', 'R_HMR_0946', 'R_HMR_0950', 'R_HMR_0954', 'R_HMR_2029',
              'R_HMR_2457', 'R_35DSMVhep', 'R_3HSMVhep', 'R_5OHFVShc', 'R_6BHGLZhr', 'R_6CSMVhep',
              'R_6HMSMVhep', 'R_6HSMVhep', 'R_6MSMVhep')
    'E1224'. ('R_P4503A5', 'R_RE2235R', 'R_HMR_0942', 'R_HMR_0946', 'R_HMR_0950', 'R_HMR_0954',
              'R_HMR_2029', 'R_HMR_2457', 'R_12HTACRhr', 'R_14HMDZALThr', 'R_14HMDZhr', 'R_1OHMDZhr',
              'R_2HATVACIDOXDhc', 'R_2HATVLACOXDhc', 'R_35DSMVhep', 'R_3HSMVhep', 'R_4HATVACIDOXDhc', 'R_4HATVLACOXDhc',
              'R_4OHMDZhr', 'R_6CSMVhep', 'R_6HMSMVhep', 'R_6HSMVhep', 'R_6MSMVhep', 'R_AM19CSALThr',
              'R_AM1CSAhr', 'R_AM9CSAhr', 'R_LVSTACOXD6Hhep', 'R_LVSTACOXD6MEhep', 'R_LVSTOXD3Hhep', 'R_LVSTOXD6Hhep',
              'R_LVSTOXD6METhep', 'R_NFDACOXDhc')
    'E1225'. ('R_P4503A7r', 'R_RE2235R', 'R_HMR_0942', 'R_HMR_0946', 'R_HMR_0950', 'R_HMR_0954',
              'R_HMR_2029', 'R_HMR_2457')
    'E1227'. ('R_P4504F121r', 'R_P4504F122r', 'R_P4504F123r', 'R_RE2235R', 'R_HMR_0942', 'R_HMR_0946',
              'R_HMR_0950', 'R_HMR_0954', 'R_HMR_2029', 'R_HMR_2457')
    'E1228'. ('R_P4504F122r', 'R_RE3014R', 'R_RE3015R', 'R_HMR_0981', 'R_HMR_1126', 'R_HMR_1127',
              'R_3HPVShc')
    'E1230'. ('R_P4507B12r')
    'E1231'. ('R_HMR_1629', 'R_HMR_1630', 'R_HMR_1631', 'R_HMR_1739', 'R_HMR_1767')
    'E1232'. ('R_P5CRm', 'R_P5CRxm', 'R_r0615', 'R_r0616', 'R_r0617', 'R_r0618',
              'R_P5CR')
    'E1233'. ('R_P5CRm', 'R_P5CRxm')
    'E1234'. ('R_PAFH')
    'E1238'. ('R_PAPStg')
    'E1239'. ('R_AK2LGCHOLABCt', 'R_PAFABCt', 'R_PCHLN225_HSABCt', 'R_PCHOL2LINL_HSABCt', 'R_PCHOL2OLE_HSABCt', 'R_PCHOL2STE_HSABCt',
              'R_PCHOLAR_HSABCt', 'R_PCHOLDOC_HSABCt', 'R_PCHOLEIC_HSABCt', 'R_PCHOLET_HSABCt', 'R_PCHOLHEP_HSABCt', 'R_PCHOLLINL_HSABCt',
              'R_PCHOLMYR_HsABCt', 'R_PCHOLN15_HSABCt', 'R_PCHOLN183_HSABCt', 'R_PCHOLN1836_HSABCt', 'R_PCHOLN19_HSABCt', 'R_PCHOLN201_HSABCt',
              'R_PCHOLN203_HSABCt', 'R_PCHOLN204_HSABCt', 'R_PCHOLN205_HSABCt', 'R_PCHOLN224_HSABCt', 'R_PCHOLN225_HSABCt', 'R_PCHOLN2254_HSABCt',
              'R_PCHOLN264_HSABCt', 'R_PCHOLOLE_HSABCt', 'R_PCHOLPALME-HSABCt', 'R_PCHOLSTE_HSABCt', 'R_PEPALM_HSASBCt')
    'E1240'. ('R_PCHOLP_hs', 'R_RE3273C', 'R_RE3301C', 'R_ARACHETH', 'R_DIDECAETH', 'R_DIHOLINETH',
              'R_DOCOHEXETHc', 'R_DOCTETETH', 'R_HEPDECETH', 'R_HEXDECEETH', 'R_OLEETH', 'R_PELINETH',
              'R_PENDECAETH', 'R_PEPALM', 'R_STEETH', 'R_TETDECAETH', 'R_TRIDECETH', 'R_HMR_0629',
              'R_HMR_0642')
    'E1241'. ('R_PCHOLP_hs', 'R_ARACHETH', 'R_DIDECAETH', 'R_DIHOLINETH', 'R_DOCOHEXETHc', 'R_DOCTETETH',
              'R_HEPDECETH', 'R_HEXDECEETH', 'R_OLEETH', 'R_PELINETH', 'R_PENDECAETH', 'R_PEPALM',
              'R_STEETH', 'R_TETDECAETH', 'R_TRIDECETH', 'R_HMR_0629', 'R_HMR_0642')
    'E1243'. ('R_PCm')
    'E1245'. ('R_PCt', 'R_FOLABCCte', 'R_AK2LGCHOLABCt', 'R_PAFABCt', 'R_PCHLN225_HSABCt', 'R_PCHOL2LINL_HSABCt',
              'R_PCHOL2OLE_HSABCt', 'R_PCHOL2STE_HSABCt', 'R_PCHOLAR_HSABCt', 'R_PCHOLDOC_HSABCt', 'R_PCHOLEIC_HSABCt', 'R_PCHOLET_HSABCt',
              'R_PCHOLHEP_HSABCt', 'R_PCHOLLINL_HSABCt', 'R_PCHOLMYR_HsABCt', 'R_PCHOLN15_HSABCt', 'R_PCHOLN183_HSABCt', 'R_PCHOLN1836_HSABCt',
              'R_PCHOLN19_HSABCt', 'R_PCHOLN201_HSABCt', 'R_PCHOLN203_HSABCt', 'R_PCHOLN204_HSABCt', 'R_PCHOLN205_HSABCt', 'R_PCHOLN224_HSABCt',
              'R_PCHOLN225_HSABCt', 'R_PCHOLN2254_HSABCt', 'R_PCHOLN264_HSABCt', 'R_PCHOLOLE_HSABCt', 'R_PCHOLPALME-HSABCt', 'R_PCHOLSTE_HSABCt',
              'R_PEPALM_HSASBCt', 'R_MLTHFte1')
    'E1246'. ('R_PCt')
    'E1248'. ('R_PDE1', 'R_PDE4')
    'E1249'. ('R_PDE1')
    'E1260'. ('R_PDE1', 'R_PDE1g', 'R_PDE4', 'R_PDE4g')
    'E1271'. ('R_PDE4')
    'E1294'. ('R_PDE4n')
    'E1297'. ('R_r0388', 'R_r0389')
    'E1299'. ('R_PEPCK')
    'E1301'. ('R_PEROXx')
    'E1302'. ('R_PETHCT')
    'E1303'. ('R_PETOHMr_hs')
    'E1304'. ('R_PETOHMr_hs', 'R_HMR_0653', 'R_HMR_0654', 'R_HMR_0657')
    'E1309'. ('R_PGESr')
    'E1311'. ('R_PGESr', 'R_HMR_1312')
    'E1317'. ('R_PGPPT', 'R_HMR_0582')
    'E1318'. ('R_PGS', 'R_PGSr', 'R_RE3488R', 'R_HMR_1305', 'R_HMR_1307', 'R_HMR_1390',
              'R_HMR_1392', 'R_HMR_2581', 'R_HMR_2585')
    'E1320'. ('R_PHEt4', 'R_RE0936E', 'R_RE0937E', 'R_RE0938E', 'R_RE2445E')
    'E1322'. ('R_PHETHPTOX2', 'R_r0399')
    'E1323'. ('R_PHYHx')
    'E1324'. ('R_PI345P3P', 'R_HMR_6550', 'R_HMR_6558')
    'E1325'. ('R_PI345P5P', 'R_PI45P5P')
    'E1326'. ('R_PI34P5K', 'R_PI3P4K', 'R_PI3P5K', 'R_PI4P5K', 'R_PIK5', 'R_HMR_6595')
    'E1329'. ('R_PI3P4K', 'R_PI5P4K', 'R_PIK4')
    'E1332'. ('R_PI45P3K', 'R_PI4P3K', 'R_PI5P3K', 'R_PIK3')
    'E1343'. ('R_PI45P5P')
    'E1345'. ('R_PI45PLC', 'R_PI4PLC', 'R_PIPLC')
    'E1363'. ('R_PI4P3K', 'R_PI5P3K', 'R_PIK3', 'R_RE2973N')
    'E1366'. ('R_PI4P5K')
    'E1373'. ('R_PI5P3K', 'R_PIK3')
    'E1374'. ('R_PIACGT')
    'E1376'. ('R_PLA2_2', 'R_PLA2_2e', 'R_PCHOLMYR_HSPLA2', 'R_PCHOLOLE_HSPLA2', 'R_PEOLE_HSPLA2', 'R_PCHOLPALME_HSPLA2',
              'R_PCHOLPALM_HSPLA2', 'R_PEPALM_HSPLA2', 'R_PAILPALM_HSPLA2', 'R_PCHOLSTE_HSPLA2', 'R_PCHOL2LINL_HSPLA2', 'R_PE2LINL_HSPLA2',
              'R_PCHOL2OLE_HSPLA2', 'R_PCHOL2PALM_HSPLA2', 'R_PCHOL2STE_HSPLA2', 'R_PCHOLN15_HSPLA2', 'R_PCHOLAR_HSPLA2', 'R_PCHOLN183_HSPLA2',
              'R_PCHOLN1836_HSPLA2', 'R_PCHOLN19_HSPLA2', 'R_PCHOLN201_HSPLA2', 'R_PCHOLN204_HSPLA2', 'R_PCHOLN205_HSPLA2', 'R_PCHOLN224_HSPLA2',
              'R_PCHOLN225_HSPLA2', 'R_PCHOLN2254_HSPLA2', 'R_PCHOLN226_HSPLA2', 'R_PEAR_HSPLA2', 'R_PE203_HSPLA2', 'R_PE226_HSPLA2',
              'R_PE224_HSPLA2', 'R_PEDH203_HSPLA2', 'R_PEDH12_HSPLA2', 'R_PEDH14_HSPLA2', 'R_PEDH161_HSPLA2', 'R_PEDH13_HSPLA2',
              'R_PEDH15_HSPLA2', 'R_PEDH17_HSPLA2', 'R_PCHOLN203_HSPLA2', 'R_PAILAR_HSPLA2', 'R_PCHOLN24_HSPLA2', 'R_PCHOLN261_HSPLA2',
              'R_PCHOLN281_HSPLA2', 'R_PCHOLN28_HSPLA2', 'R_PCHOLDOC_HSPLA2', 'R_PCHOLDEIC_HSPLA2', 'R_PCHOLDET_HSPLA2', 'R_PCHOLHEP_HSPLA2',
              'R_PCHOLLINL_HSPLA2', 'R_PELINL_HSPLA2')
    'E1383'. ('R_PLA2_2e')
    'E1387'. ('R_PMEVKc')
    'E1388'. ('R_PMI12346PH', 'R_PMI12346PHn', 'R_HMR_7652')
    'E1389'. ('R_PMI12346PH', 'R_PMI12346PHn')
    'E1391'. ('R_PMI12346PHn')
    'E1395'. ('R_PMI12346PHn', 'R_HMR_7652')
    'E1398'. ('R_PPAm')
    'E1402'. ('R_PPAP', 'R_r0787', 'R_HMR_0597', 'R_HMR_0598', 'R_HMR_0601', 'R_HMR_0767',
              'R_HMR_0775')
    'E1403'. ('R_PPAP', 'R_r0787', 'R_HMR_0597', 'R_HMR_0598', 'R_HMR_0601', 'R_HMR_0767',
              'R_HMR_0775', 'R_HMR_0783')
    'E1405'. ('R_PPAP')
    'E1406'. ('R_PPPGOm', 'R_HMR_4757')
    'E1407'. ('R_HMR_2088', 'R_HMR_2089')
    'E1408'. ('R_RE2888C', 'R_RE3095C', 'R_HMR_0960', 'R_HMR_0963', 'R_HMR_2088', 'R_HMR_2089')
    'E1409'. ('R_PRDXl', 'R_HMR_2088', 'R_HMR_2089')
    'E1412'. ('R_PROSTGE2t', 'R_r2313', 'R_r2314', 'R_r2315', 'R_r2316', 'R_r2317',
              'R_r2318', 'R_r2319', 'R_r2320', 'R_r2321', 'R_r2322', 'R_r2323',
              'R_r2324', 'R_r2325', 'R_r2326', 'R_r2327', 'R_r2328', 'R_r2329',
              'R_r2330', 'R_r2331', 'R_r2332', 'R_r2333', 'R_r2334', 'R_r2335')
    'E1416'. ('R_PTE2x', 'R_PTE3x', 'R_r0308', 'R_RE1834M', 'R_RE2649M', 'R_5EIPENCm',
              'R_HMR_0189', 'R_HMR_0193', 'R_HMR_0197', 'R_HMR_0201', 'R_HMR_0206', 'R_HMR_0210',
              'R_HMR_0214', 'R_HMR_0230', 'R_HMR_0234', 'R_HMR_0238', 'R_HMR_0242', 'R_HMR_0246',
              'R_HMR_0256', 'R_HMR_0260', 'R_HMR_0268', 'R_HMR_0272', 'R_HMR_0276', 'R_HMR_0280',
              'R_HMR_0290', 'R_HMR_0298', 'R_HMR_0302', 'R_HMR_0306', 'R_HMR_0310', 'R_HMR_0324',
              'R_HMR_0328', 'R_HMR_0342', 'R_HMR_0346', 'R_HMR_0350', 'R_HMR_0354', 'R_HMR_0358',
              'R_HMR_0362', 'R_HMR_0366', 'R_HMR_0370', 'R_HMR_0374', 'R_HMR_0378', 'R_HMR_0382',
              'R_HMR_0386', 'R_HMR_0390', 'R_HMR_0394', 'R_HMR_0398', 'R_HMR_0402', 'R_HMR_0406',
              'R_HMR_0410', 'R_HMR_0414', 'R_HMR_0418', 'R_HMR_0422', 'R_HMR_0426', 'R_HMR_0430',
              'R_HMR_0434', 'R_HMR_0438', 'R_HMR_2957')
    'E1417'. ('R_PTE2x', 'R_RE1834C', 'R_RE1834X', 'R_ADPCOAPTE', 'R_SBCOAACOTx', 'R_SEBCOAPET',
              'R_5EIPENCm', 'R_HMR_3475')
    'E1418'. ('R_PTE2x')
    'E1420'. ('R_PTE2x', 'R_r0308', 'R_RE1834X', 'R_HMR_0189', 'R_HMR_0193', 'R_HMR_0197',
              'R_HMR_0201', 'R_HMR_0206', 'R_HMR_0210', 'R_HMR_0214', 'R_HMR_0230', 'R_HMR_0234',
              'R_HMR_0238', 'R_HMR_0242', 'R_HMR_0246', 'R_HMR_0256', 'R_HMR_0260', 'R_HMR_0268',
              'R_HMR_0272', 'R_HMR_0276', 'R_HMR_0280', 'R_HMR_0290', 'R_HMR_0298', 'R_HMR_0302',
              'R_HMR_0306', 'R_HMR_0310', 'R_HMR_0324', 'R_HMR_0328', 'R_HMR_0342', 'R_HMR_0346',
              'R_HMR_0350', 'R_HMR_0354', 'R_HMR_0358', 'R_HMR_0362', 'R_HMR_0366', 'R_HMR_0370',
              'R_HMR_0374', 'R_HMR_0378', 'R_HMR_0382', 'R_HMR_0386', 'R_HMR_0390', 'R_HMR_0394',
              'R_HMR_0398', 'R_HMR_0402', 'R_HMR_0406', 'R_HMR_0410', 'R_HMR_0414', 'R_HMR_0418',
              'R_HMR_0422', 'R_HMR_0426', 'R_HMR_0430', 'R_HMR_0434', 'R_HMR_0438', 'R_HMR_2957')
    'E1425'. ('R_PYNP2r')
    'E1426'. ('R_PYNP2r', 'R_DURIPP')
    'E1430'. ('R_RBK_D', 'R_RBK', 'R_DRBK')
    'E1431'. ('R_RDH1', 'R_RDH2', 'R_RDH3', 'R_RDH4', 'R_HMR_6633')
    'E1432'. ('R_RDH1')
    'E1433'. ('R_RDH1a', 'R_HMR_6632')
    'E1434'. ('R_RDH1a', 'R_RDH2a')
    'E1435'. ('R_RDH1a', 'R_RDH2a', 'R_HMR_6632')
    'E1437'. ('R_RDH1a', 'R_RDH2a', 'R_HMR_6633')
    'E1439'. ('R_RDH1a', 'R_RDH2a', 'R_RE2766C', 'R_HMR_6632')
    'E1440'. ('R_HMR_0003', 'R_HMR_0672')
    'E1442'. ('R_RNMK')
    'E1443'. ('R_S23T2g', 'R_S23T4g', 'R_HMR_0812', 'R_HMR_0817', 'R_HMR_0837', 'R_HMR_0844')
    'E1445'. ('R_S23T2g', 'R_S23T4g', 'R_SIAT4Bg', 'R_ST3GAL21g', 'R_ST3GAL22g', 'R_HMR_0812',
              'R_HMR_0817', 'R_HMR_0837', 'R_HMR_0844')
    'E1446'. ('R_S23T2g', 'R_S23T4g')
    'E1447'. ('R_S2T1g', 'R_S2T2g')
    'E1448'. ('R_S2T4g')
    'E1449'. ('R_S2TASE1ly', 'R_S2TASE2ly', 'R_S2TASE3ly')
    'E1451'. ('R_S3T1g')
    'E1452'. ('R_S3T1g', 'R_S3T2g', 'R_S3T3g')
    'E1453'. ('R_S3T1g', 'R_S3T2g')
    'E1454'. ('R_S3T2g')
    'E1455'. ('R_S3T3g')
    'E1458'. ('R_S4T1g', 'R_S4T2g')
    'E1462'. ('R_S4TASE1ly', 'R_S4TASE2ly', 'R_S4TASE3ly', 'R_S4TASE4ly', 'R_S4TASE5ly')
    'E1464'. ('R_S6T16g', 'R_S6T17g', 'R_S6T1g', 'R_S6T2g')
    'E1469'. ('R_S6T18g', 'R_S6T3g')
    'E1470'. ('R_S6T18g', 'R_S6T19g', 'R_S6T20g', 'R_S6T21g', 'R_S6T24g', 'R_S6T3g')
    'E1471'. ('R_S6T19g', 'R_S6T20g', 'R_S6T21g', 'R_S6T24g')
    'E1472'. ('R_S6T25g')
    'E1476'. ('R_S6TASE1ly', 'R_S6TASE2ly', 'R_S6TASE3ly')
    'E1477'. ('R_SACCD4m', 'R_r0525')
    'E1478'. ('R_SALMCOM', 'R_SALMCOM2')
    'E1479'. ('R_SAMHISTA', 'R_SAMHISTAe', 'R_HMR_3915')
    'E1481'. ('R_r0787', 'R_HMR_6545')
    'E1483'. ('R_SCP21x', 'R_SCP22x', 'R_SCP2x', 'R_SCPx', 'R_RE1836X', 'R_HMR_1653',
              'R_HMR_3505')
    'E1486'. ('R_SFGTH')
    'E1488'. ('R_HMR_0824')
    'E1489'. ('R_SLCBK1', 'R_SPHK21c', 'R_SPHK21n', 'R_SPHK22n')
    'E1490'. ('R_SLCBK1', 'R_SPHK21c')
    'E1492'. ('R_SMPD3g', 'R_SMPD3l', 'R_HMR_0795')
    'E1493'. ('R_SMPD3g', 'R_SMPD3l')
    'E1494'. ('R_SMPD3g', 'R_HMR_0795')
    'E1496'. ('R_SMPD3l', 'R_HMR_0795')
    'E1497'. ('R_SMPD4', 'R_HMR_0795')
    'E1498'. ('R_SMS', 'R_SMS1', 'R_SMS10', 'R_SMS11', 'R_SMS12', 'R_SMS16',
              'R_SMS13', 'R_SMS14', 'R_SMS15', 'R_SMS2', 'R_SMS3', 'R_SMS4',
              'R_SMS5', 'R_SMS6', 'R_SMS7', 'R_SMS8', 'R_SMS9', 'R_SMS1S2')
    'E1499'. ('R_SO4HCOtex', 'R_HMR_6534')
    'E1500'. ('R_SO4HCOtex')
    'E1507'. ('R_SOAT12', 'R_r1164', 'R_r1165', 'R_r1166', 'R_r1167', 'R_r1171',
              'R_CHOLESACATc', 'R_HMR_3625', 'R_HMR_3626', 'R_HMR_3627', 'R_HMR_3628', 'R_HMR_3629',
              'R_HMR_3630', 'R_HMR_3631', 'R_HMR_3633', 'R_HMR_3635', 'R_HMR_3636', 'R_HMR_3637',
              'R_HMR_3639', 'R_HMR_3640', 'R_HMR_3642', 'R_HMR_3644', 'R_HMR_3645', 'R_HMR_3646',
              'R_HMR_3647', 'R_HMR_3648', 'R_HMR_3649', 'R_HMR_3650', 'R_HMR_3651', 'R_HMR_3652',
              'R_HMR_3653', 'R_HMR_3654', 'R_HMR_3655', 'R_HMR_3656', 'R_HMR_3657', 'R_HMR_3658',
              'R_HMR_3659', 'R_HMR_3660', 'R_HMR_3662', 'R_HMR_3663', 'R_HMR_3664', 'R_HMR_3665',
              'R_HMR_3666', 'R_HMR_3667', 'R_HMR_3668', 'R_HMR_3669', 'R_HMR_3670', 'R_HMR_3677',
              'R_HMR_3678', 'R_HMR_3679', 'R_HMR_3680', 'R_HMR_3681', 'R_HMR_3682')
    'E1512'. ('R_SPRMS')
    'E1513'. ('R_SPRMS', 'R_SPMS')
    'E1514'. ('R_SQLEr', 'R_HMR_1470')
    'E1515'. ('R_SQLSr')
    'E1531'. ('R_ST3GAL62g', 'R_HMR_0876', 'R_HMR_0910')
    'E1533'. ('R_ST6GALNAC31', 'R_HMR_0823')
    'E1536'. ('R_ST8SIA11', 'R_HMR_0814', 'R_HMR_0841', 'R_HMR_0852', 'R_HMR_0853', 'R_HMR_0854',
              'R_HMR_0855', 'R_HMR_0877')
    'E1537'. ('R_HMR_0855')
    'E1538'. ('R_STS1', 'R_STS1r', 'R_STS2', 'R_STS2r')
    'E1539'. ('R_SUCD1m', 'R_r0509')
    'E1540'. ('R_SULFOX')
    'E1542'. ('R_THBPT4ACAMDASE')
    'E1544'. ('R_THD1m')
    'E1546'. ('R_THMTP')
    'E1547'. ('R_THYOXt2', 'R_TRIODTHYt2')
    'E1549'. ('R_TMLYSOX')
    'E1550'. ('R_TRDR', 'R_TRDR2', 'R_TRDR3')
    'E1551'. ('R_TRDR', 'R_TRDR2', 'R_TRDR3', 'R_r0027')
    'E1554'. ('R_TREH')
    'E1556'. ('R_TRPHYDRO2', 'R_r0403')
    'E1560'. ('R_TSULt4_3', 'R_HMR_7700')
    'E1561'. ('R_TXASr')
    'E1566'. ('R_UAG2EMAi', 'R_r0113', 'R_AMANK')
    'E1568'. ('R_UDPGALtg', 'R_UGALNACtg', 'R_HMR_6385')
    'E1569'. ('R_UDPGD')
    'E1570'. ('R_UDPGLCAter')
    'E1571'. ('R_UDPGLDCg', 'R_HMR_4124')
    'E1573'. ('R_UDPXYLtg')
    'E1576'. ('R_UGLCNACtg')
    'E1577'. ('R_UGT1A2r', 'R_UGT1A5r2', 'R_ATVACYLGLUChc', 'R_ATVLACGLCURhc', 'R_LSTNM7hr')
    'E1578'. ('R_UGT1A2r', 'R_UGT1A5r2', 'R_LSTNM7hr')
    'E1579'. ('R_UGT1A2r', 'R_UGT1A5r2', 'R_GLC3MEACPhr', 'R_PTVSTGLUChc')
    'E1580'. ('R_UGT1A2r', 'R_UGT1A5r2')
    'E1581'. ('R_UGT1A2r', 'R_UGT1A5r2', 'R_1HIBUP_SGLUhep', 'R_2HIBUP_SGLUhep', 'R_3HIBUP_SGLUhep', 'R_ATVETHGLUChc',
              'R_CARIBUP_SGLUhep', 'R_GLC3MEACPhr', 'R_IBUPGT_HEP', 'R_LSTNM7hr')
    'E1582'. ('R_UGT1A2r', 'R_UGT1A5r2', 'R_ATVACYLGLUChc', 'R_ATVLACGLCURhc', 'R_GLC3MEACPhr', 'R_LSTNM7hr',
              'R_PTVSTGLUChc')
    'E1583'. ('R_UGT1A2r', 'R_UGT1A5r2', 'R_CDCA24GSc', 'R_CDCA24GSr', 'R_HDCA24GSc', 'R_HDCA24GSr',
              'R_LCA24GSc', 'R_LCA24GSr', 'R_1HIBUP_SGLUhep', 'R_2HATVLACGLUChr', 'R_2HIBUP_SGLUhep', 'R_3HIBUP_SGLUhep',
              'R_ATVACYLGLUChc', 'R_ATVETHGLUChc', 'R_ATVLACGLCURhc', 'R_CARIBUP_SGLUhep', 'R_IBUPGT_HEP', 'R_LSTNM7hr',
              'R_PTVSTGLUChc')
    'E1585'. ('R_UGT1A2r', 'R_UGT1A5r2', 'R_1HMDGLUChr', 'R_2HATVLACGLUChr', 'R_4HMDZGLUChr', 'R_ATVACYLGLUChc',
              'R_ATVETHGLUChc', 'R_ATVLACGLCURhc', 'R_LSTNM7hr', 'R_PTVSTGLUChc')
    'E1586'. ('R_CDCA3GSc', 'R_CDCA3GSr', 'R_HCA24GSc', 'R_HCA24GSr', 'R_HDCA6GSc', 'R_HDCA6GSr',
              'R_LCA24GSc', 'R_LCA24GSr', 'R_LCA3GSc', 'R_LCA3GSr', 'R_1HIBUP_SGLUhep', 'R_1HMDGLUChr',
              'R_2HIBUP_SGLUhep', 'R_3HIBUP_SGLUhep', 'R_4HMDZGLUChr', 'R_ATVACYLGLUChc', 'R_ATVLACGLCURhc', 'R_CARIBUP_SGLUhep',
              'R_IBUPGT_HEP', 'R_LSTNM7hr', 'R_PTVSTGLUChc')
    'E1587'. ('R_UGT1A5r2')
    'E1588'. ('R_UGT1A5r2', 'R_LSTNM7hr')
    'E1590'. ('R_UGT1A5r2', 'R_HDCA6GSc', 'R_HDCA6GSr', 'R_1HMDGLUChr', 'R_4HMDZGLUChr')
    'E1593'. ('R_URIK1', 'R_r1156', 'R_HMR_5301')
    'E1594'. ('R_r0394', 'R_r0395')
    'E1596'. ('R_XYLTer')
    'E1602'. ('R_r0016')
    'E1608'. ('R_r0027')
    'E1609'. ('R_r0033', 'R_r0590', 'R_DPCOAK', 'R_PTPAT')
    'E1610'. ('R_r0047', 'R_NTD4', 'R_NTD5', 'R_NTD6', 'R_NTD7', 'R_NTD8',
              'R_NTD9', 'R_NTD10', 'R_NTD11', 'R_NT5C')
    'E1611'. ('R_r0047', 'R_NTD4', 'R_NTD5', 'R_NTD6', 'R_NTD7', 'R_NTD8',
              'R_NTD9', 'R_NTD10', 'R_NTD11', 'R_NT5C', 'R_NTD3')
    'E1614'. ('R_r0047')
    'E1615'. ('R_r0051')
    'E1616'. ('R_r0083', 'R_r0425')
    'E1617'. ('R_r0085')
    'E1618'. ('R_PYK')
    'E1619'. ('R_r0129', 'R_r0130', 'R_r0641', 'R_r0648', 'R_r0649')
    'E1625'. ('R_r0191', 'R_r0408', 'R_r0409', 'R_r0610', 'R_r0611', 'R_PFK')
    'E1628'. ('R_r0208', 'R_MAN1PT2')
    'E1632'. ('R_r0242', 'R_r0587', 'R_r0707')
    'E1634'. ('R_r0276')
    'E1636'. ('R_r0283')
    'E1640'. ('R_r0308', 'R_RE1834M', 'R_RE2649M', 'R_EIC21114TRc', 'R_5EIPENCm', 'R_HMR_0189',
              'R_HMR_0193', 'R_HMR_0197', 'R_HMR_0201', 'R_HMR_0206', 'R_HMR_0210', 'R_HMR_0214',
              'R_HMR_0230', 'R_HMR_0234', 'R_HMR_0238', 'R_HMR_0242', 'R_HMR_0246', 'R_HMR_0256',
              'R_HMR_0260', 'R_HMR_0268', 'R_HMR_0272', 'R_HMR_0276', 'R_HMR_0280', 'R_HMR_0290',
              'R_HMR_0298', 'R_HMR_0302', 'R_HMR_0306', 'R_HMR_0310', 'R_HMR_0324', 'R_HMR_0328',
              'R_HMR_0342', 'R_HMR_0346', 'R_HMR_0350', 'R_HMR_0354', 'R_HMR_0358', 'R_HMR_0362',
              'R_HMR_0366', 'R_HMR_0370', 'R_HMR_0374', 'R_HMR_0378', 'R_HMR_0382', 'R_HMR_0386',
              'R_HMR_0390', 'R_HMR_0394', 'R_HMR_0398', 'R_HMR_0402', 'R_HMR_0406', 'R_HMR_0410',
              'R_HMR_0414', 'R_HMR_0418', 'R_HMR_0422', 'R_HMR_0426', 'R_HMR_0430', 'R_HMR_0434',
              'R_HMR_0438')
    'E1641'. ('R_r0308')
    'E1642'. ('R_r0308', 'R_RE0344C', 'R_RE0577C', 'R_RE0578C', 'R_RE0579C', 'R_RE1834C',
              'R_RE1835C', 'R_RE2649C', 'R_TTDCEAc', 'R_EIC21114TRc', 'R_HMR_0189', 'R_HMR_0193',
              'R_HMR_0197', 'R_HMR_0201', 'R_HMR_0206', 'R_HMR_0210', 'R_HMR_0214', 'R_HMR_0230',
              'R_HMR_0234', 'R_HMR_0238', 'R_HMR_0242', 'R_HMR_0246', 'R_HMR_0256', 'R_HMR_0260',
              'R_HMR_0268', 'R_HMR_0272', 'R_HMR_0276', 'R_HMR_0280', 'R_HMR_0290', 'R_HMR_0298',
              'R_HMR_0302', 'R_HMR_0306', 'R_HMR_0310', 'R_HMR_0324', 'R_HMR_0328', 'R_HMR_0342',
              'R_HMR_0346', 'R_HMR_0350', 'R_HMR_0354', 'R_HMR_0358', 'R_HMR_0362', 'R_HMR_0366',
              'R_HMR_0370', 'R_HMR_0374', 'R_HMR_0378', 'R_HMR_0382', 'R_HMR_0386', 'R_HMR_0390',
              'R_HMR_0394', 'R_HMR_0398', 'R_HMR_0402', 'R_HMR_0406', 'R_HMR_0410', 'R_HMR_0414',
              'R_HMR_0418', 'R_HMR_0422', 'R_HMR_0426', 'R_HMR_0430', 'R_HMR_0434', 'R_HMR_0438')
    'E1644'. ('R_r0309', 'R_r0633', 'R_r0638', 'R_r0652', 'R_r0735', 'R_r0791')
    'E1646'. ('R_r0310', 'R_FAOXC163C164Gm', 'R_FAOXC225C226m', 'R_FAOXC226C227m', 'R_HMR_3107', 'R_HMR_3111',
              'R_HMR_3115', 'R_HMR_3121', 'R_HMR_3128', 'R_HMR_3135', 'R_HMR_3170', 'R_HMR_3174',
              'R_HMR_3178', 'R_HMR_3182', 'R_HMR_3186', 'R_HMR_3218', 'R_HMR_3222', 'R_HMR_3230',
              'R_HMR_3234', 'R_HMR_3240', 'R_HMR_3244', 'R_HMR_3398', 'R_HMR_3406', 'R_HMR_3407',
              'R_HMR_3408', 'R_HMR_3409', 'R_HMR_3411', 'R_HMR_3413', 'R_HMR_3414', 'R_HMR_3416',
              'R_HMR_3421', 'R_HMR_3422', 'R_HMR_3423', 'R_HMR_3424', 'R_HMR_3425', 'R_HMR_3426',
              'R_HMR_3427', 'R_HMR_3428', 'R_HMR_3429', 'R_HMR_3431', 'R_HMR_3432', 'R_HMR_3433',
              'R_HMR_3448', 'R_HMR_3452', 'R_HMR_3456', 'R_HMR_9719', 'R_3HPVSTETCOAhcm')
    'E1647'. ('R_r0310', 'R_r1443', 'R_r1444', 'R_r1445', 'R_r1446', 'R_r1447',
              'R_r1448', 'R_r1449', 'R_r1450', 'R_r1451', 'R_RE1516X', 'R_RE1517X',
              'R_RE1518X', 'R_RE1519X', 'R_RE2985X', 'R_RE2994X', 'R_RE2997X', 'R_RE3086X',
              'R_RE3157X', 'R_HMR_1637', 'R_HMR_3057', 'R_HMR_3062', 'R_HMR_3066', 'R_HMR_3070',
              'R_HMR_3074', 'R_HMR_3094', 'R_HMR_3098', 'R_HMR_3102', 'R_HMR_3321', 'R_HMR_3326',
              'R_HMR_3330', 'R_HMR_3334', 'R_HMR_3338', 'R_HMR_3342', 'R_HMR_3346', 'R_HMR_3350')
    'E1648'. ('R_r0310', 'R_r1472', 'R_RE1516M', 'R_RE1517M', 'R_RE1518M', 'R_RE3185M',
              'R_RE3186M', 'R_HMR_3107', 'R_HMR_3111', 'R_HMR_3115', 'R_HMR_3121', 'R_HMR_3128',
              'R_HMR_3135', 'R_HMR_3170', 'R_HMR_3174', 'R_HMR_3178', 'R_HMR_3182', 'R_HMR_3186',
              'R_HMR_3218', 'R_HMR_3222', 'R_HMR_3230', 'R_HMR_3234', 'R_HMR_3240', 'R_HMR_3244',
              'R_HMR_3398', 'R_HMR_3406', 'R_HMR_3407', 'R_HMR_3408', 'R_HMR_3409', 'R_HMR_3411',
              'R_HMR_3413', 'R_HMR_3414', 'R_HMR_3416', 'R_HMR_3421', 'R_HMR_3422', 'R_HMR_3423',
              'R_HMR_3424', 'R_HMR_3425', 'R_HMR_3426', 'R_HMR_3427', 'R_HMR_3428', 'R_HMR_3429',
              'R_HMR_3431', 'R_HMR_3432', 'R_HMR_3433', 'R_HMR_3448', 'R_HMR_3452', 'R_HMR_3456',
              'R_HMR_3522', 'R_HMR_9719')
    'E1649'. ('R_r0340', 'R_r0339')
    'E1653'. ('R_r0391')
    'E1654'. ('R_r0391', 'R_NNDPR')
    'E1655'. ('R_r0440', 'R_r0444')
    'E1656'. ('R_r0451')
    'E1661'. ('R_FTHFCL')
    'E1664'. ('R_r0557')
    'E1666'. ('R_r0578', 'R_r0579')
    'E1676'. ('R_r0615', 'R_r0616', 'R_r0617', 'R_r0618', 'R_P5CR')
    'E1677'. ('R_r0660', 'R_r0720', 'R_r0721', 'R_r0728', 'R_r1474')
    'E1678'. ('R_r0719')
    'E1679'. ('R_r0739')
    'E1680'. ('R_UPPDC1')
    'E1681'. ('R_r0781', 'R_HMR_1536', 'R_HMR_1538', 'R_HMR_1539')
    'E1684'. ('R_r0845')
    'E1685'. ('R_r0924', 'R_CHSTEROLt')
    'E1687'. ('R_r1090', 'R_CITt4_4')
    'E1689'. ('R_r1164', 'R_r1165', 'R_r1166', 'R_r1167', 'R_r1171', 'R_CHOLESACATc',
              'R_HMR_3625', 'R_HMR_3626', 'R_HMR_3627', 'R_HMR_3628', 'R_HMR_3629', 'R_HMR_3630',
              'R_HMR_3631', 'R_HMR_3633', 'R_HMR_3635', 'R_HMR_3636', 'R_HMR_3637', 'R_HMR_3639',
              'R_HMR_3640', 'R_HMR_3642', 'R_HMR_3644', 'R_HMR_3645', 'R_HMR_3646', 'R_HMR_3647',
              'R_HMR_3648', 'R_HMR_3649', 'R_HMR_3650', 'R_HMR_3651', 'R_HMR_3652', 'R_HMR_3653',
              'R_HMR_3654', 'R_HMR_3655', 'R_HMR_3656', 'R_HMR_3657', 'R_HMR_3658', 'R_HMR_3659',
              'R_HMR_3660', 'R_HMR_3662', 'R_HMR_3663', 'R_HMR_3664', 'R_HMR_3665', 'R_HMR_3666',
              'R_HMR_3667', 'R_HMR_3668', 'R_HMR_3669', 'R_HMR_3670', 'R_HMR_3677', 'R_HMR_3678',
              'R_HMR_3679', 'R_HMR_3680', 'R_HMR_3681', 'R_HMR_3682')
    'E1690'. ('R_r1174', 'R_r1175', 'R_r1177', 'R_r1183', 'R_HMR_3684', 'R_HMR_3685',
              'R_HMR_3686', 'R_HMR_3687', 'R_HMR_3688', 'R_HMR_3689', 'R_HMR_3690', 'R_HMR_3692',
              'R_HMR_3694', 'R_HMR_3695', 'R_HMR_3696', 'R_HMR_3698', 'R_HMR_3699', 'R_HMR_3701',
              'R_HMR_3703', 'R_HMR_3704', 'R_HMR_3705', 'R_HMR_3706', 'R_HMR_3707', 'R_HMR_3708',
              'R_HMR_3709', 'R_HMR_3710', 'R_HMR_3711', 'R_HMR_3712', 'R_HMR_3713', 'R_HMR_3714',
              'R_HMR_3715', 'R_HMR_3716', 'R_HMR_3717', 'R_HMR_3718', 'R_HMR_3719', 'R_HMR_3721',
              'R_HMR_3722', 'R_HMR_3723', 'R_HMR_3724', 'R_HMR_3725', 'R_HMR_3726', 'R_HMR_3727',
              'R_HMR_3728', 'R_HMR_3729', 'R_HMR_3736', 'R_HMR_3737', 'R_HMR_3738', 'R_HMR_3739',
              'R_HMR_3740', 'R_HMR_3741')
    'E1691'. ('R_r1418', 'R_H2CO3D')
    'E1699'. ('R_r1418')
    'E1701'. ('R_r1477')
    'E1703'. ('R_FOLABCCte', 'R_CAMPt', 'R_CGMPt', 'R_MLTHFte1')
    'E1705'. ('R_r1664', 'R_r1665', 'R_r1666', 'R_r1668', 'R_r1669', 'R_r1670',
              'R_r1671', 'R_r1672', 'R_r1673', 'R_r1674', 'R_r1675', 'R_r1676',
              'R_r1677', 'R_r1678', 'R_r1679', 'R_r1680', 'R_r1681', 'R_r1682',
              'R_r1683', 'R_r1684', 'R_r1685', 'R_r1686', 'R_r1687', 'R_r1690',
              'R_r1691', 'R_r1692', 'R_r1693', 'R_r1695', 'R_r1696', 'R_r1698',
              'R_r1700', 'R_r1701', 'R_r1702', 'R_r1705', 'R_r1706', 'R_r1707',
              'R_r1708', 'R_r1710', 'R_r1711', 'R_r1713', 'R_r1715', 'R_r1716',
              'R_r1717', 'R_r1720', 'R_r1721', 'R_r1722', 'R_r1723', 'R_r1725',
              'R_r1726', 'R_r1728', 'R_r1730', 'R_r1731', 'R_r1732', 'R_r1733',
              'R_r1734', 'R_r1735', 'R_r1736', 'R_r1737', 'R_r1738', 'R_r1739',
              'R_r1740', 'R_r1741', 'R_r1742', 'R_r1743', 'R_r1744', 'R_r1745',
              'R_r1746', 'R_r1747', 'R_r1748', 'R_r1749', 'R_r1750', 'R_r1751',
              'R_r1752', 'R_r1753', 'R_r1754', 'R_r1755', 'R_r1756', 'R_r1757',
              'R_r1758', 'R_r1759', 'R_r1760', 'R_r1761', 'R_r1762', 'R_r1763',
              'R_r1764', 'R_r1765', 'R_r1766', 'R_r1767', 'R_r1768', 'R_r1769',
              'R_r1770', 'R_r1771', 'R_r1772', 'R_r1773', 'R_r1774', 'R_r1775',
              'R_r1776', 'R_r1777', 'R_r1778', 'R_r1779', 'R_r1780', 'R_r1781',
              'R_r1782', 'R_r1783', 'R_r1784', 'R_r1785', 'R_r1786', 'R_r1787',
              'R_r1788', 'R_r1789', 'R_r1790', 'R_r1791', 'R_r1792', 'R_r1796',
              'R_r1797', 'R_r1798', 'R_r1799', 'R_r1800', 'R_r1801', 'R_r1803',
              'R_r1805', 'R_r1806', 'R_r1807', 'R_r1808', 'R_r1809', 'R_r1810',
              'R_r1811', 'R_r1812', 'R_r1813', 'R_r1814', 'R_r1815', 'R_r1816',
              'R_r1817', 'R_r1818', 'R_r1819', 'R_r1820', 'R_r1821', 'R_r1822',
              'R_r1823', 'R_r1824', 'R_r1825', 'R_r1826', 'R_r1827', 'R_r1828',
              'R_r1829', 'R_r1830', 'R_r1831', 'R_r1832', 'R_r1833', 'R_r1834',
              'R_r1835', 'R_r1836', 'R_r1837', 'R_r1841', 'R_r1842', 'R_r1843',
              'R_r1844', 'R_r1846', 'R_r1847', 'R_r1848', 'R_r1850', 'R_r1851',
              'R_r1852', 'R_r1853', 'R_r1854', 'R_r1855', 'R_r1856', 'R_r1857',
              'R_r1858', 'R_r1859', 'R_r1860', 'R_r1861', 'R_r1862', 'R_r1863',
              'R_r1864', 'R_r1865', 'R_r1866', 'R_r1867', 'R_r1871', 'R_r1872',
              'R_r1873', 'R_r1874', 'R_r1876', 'R_r1877', 'R_r1879', 'R_r1880',
              'R_r1881', 'R_r1882', 'R_r1883', 'R_r1884', 'R_r1885', 'R_r1886',
              'R_r1887', 'R_r1888', 'R_r1889', 'R_r1890', 'R_r1891', 'R_r1892',
              'R_r1893', 'R_r1894', 'R_r1895', 'R_r1896', 'R_r1897', 'R_r1898',
              'R_r1899', 'R_r1900', 'R_r1901', 'R_r1902', 'R_r1903', 'R_r1904',
              'R_r1905', 'R_r1906', 'R_r1907', 'R_r1908', 'R_r1909', 'R_r1910',
              'R_r1911', 'R_r1912', 'R_r1913', 'R_r1914', 'R_r1915', 'R_r1916',
              'R_r1917', 'R_r1918', 'R_r1919', 'R_r1920', 'R_r1921', 'R_r1922',
              'R_r1923', 'R_r1924', 'R_r1925', 'R_r1926', 'R_r1928', 'R_r1929',
              'R_r1930', 'R_r1931', 'R_r1932', 'R_r1933', 'R_r1934', 'R_r1935',
              'R_r1936', 'R_r1937', 'R_r1938', 'R_r1939', 'R_r1940', 'R_r1941',
              'R_r1942', 'R_r1943', 'R_r1944', 'R_r1945', 'R_r1946', 'R_r1947',
              'R_r1948', 'R_r1949', 'R_r1950', 'R_r1951', 'R_r1952', 'R_r1953',
              'R_r1954', 'R_r1955', 'R_r1956', 'R_r1957', 'R_r1958', 'R_r1959',
              'R_r1960', 'R_r1961', 'R_r1962', 'R_r1963', 'R_r1964', 'R_r1965',
              'R_r1966', 'R_r1967', 'R_r1968', 'R_r1969', 'R_r1970', 'R_r1971',
              'R_r1972', 'R_r1973', 'R_r1974', 'R_r1975', 'R_r1976', 'R_r1977',
              'R_r1978', 'R_r1979', 'R_r1980', 'R_r1981', 'R_r1982', 'R_r1983',
              'R_r1984', 'R_r1985', 'R_r1986', 'R_r1987', 'R_r1988', 'R_r1989',
              'R_r1990', 'R_r1991', 'R_r1667', 'R_HMR_5996')
    'E1707'. ('R_PIt7')
    'E1709'. ('R_r2472')
    'E1710'. ('R_r2497', 'R_r2502', 'R_STRDNCCOAtxc', 'R_HMR_3018', 'R_HMR_3021', 'R_HMR_3023')
    'E1712'. ('R_RE0344C', 'R_RE0577C', 'R_RE0578C', 'R_RE0579C', 'R_RE1834C', 'R_RE1835C',
              'R_RE2649C', 'R_HMR_0189', 'R_HMR_0193', 'R_HMR_0197', 'R_HMR_0201', 'R_HMR_0206',
              'R_HMR_0210', 'R_HMR_0214', 'R_HMR_0230', 'R_HMR_0234', 'R_HMR_0238', 'R_HMR_0242',
              'R_HMR_0246', 'R_HMR_0256', 'R_HMR_0260', 'R_HMR_0268', 'R_HMR_0272', 'R_HMR_0276',
              'R_HMR_0280', 'R_HMR_0290', 'R_HMR_0298', 'R_HMR_0302', 'R_HMR_0306', 'R_HMR_0310',
              'R_HMR_0324', 'R_HMR_0328', 'R_HMR_0342', 'R_HMR_0346', 'R_HMR_0350', 'R_HMR_0354',
              'R_HMR_0358', 'R_HMR_0362', 'R_HMR_0366', 'R_HMR_0370', 'R_HMR_0374', 'R_HMR_0378',
              'R_HMR_0382', 'R_HMR_0386', 'R_HMR_0390', 'R_HMR_0394', 'R_HMR_0398', 'R_HMR_0402',
              'R_HMR_0406', 'R_HMR_0410', 'R_HMR_0414', 'R_HMR_0418', 'R_HMR_0422', 'R_HMR_0426',
              'R_HMR_0430', 'R_HMR_0434', 'R_HMR_0438')
    'E1713'. ('R_RE0453N')
    'E1715'. ('R_RNDR1')
    'E1716'. ('R_RE0512M', 'R_RE1520M', 'R_RE1521M', 'R_RE1522M', 'R_RE1523M', 'R_RE1531M',
              'R_RE1532M', 'R_RE1533M', 'R_RE1534M', 'R_RE3004M', 'R_RE3006M', 'R_RE3177M',
              'R_RE3178M', 'R_RE3179M', 'R_RE3189M', 'R_RE3190M', 'R_RE3191M', 'R_RE3192M',
              'R_RE3193M', 'R_RE3194M', 'R_HMR_1651', 'R_HMR_3108', 'R_HMR_3109', 'R_HMR_3110',
              'R_HMR_3112', 'R_HMR_3113', 'R_HMR_3114', 'R_HMR_3116', 'R_HMR_3117', 'R_HMR_3118',
              'R_HMR_3171', 'R_HMR_3172', 'R_HMR_3173', 'R_HMR_3175', 'R_HMR_3176', 'R_HMR_3177',
              'R_HMR_3179', 'R_HMR_3180', 'R_HMR_3181', 'R_HMR_3183', 'R_HMR_3184', 'R_HMR_3185',
              'R_HMR_3187', 'R_HMR_3188', 'R_HMR_3189', 'R_HMR_3191', 'R_HMR_3192', 'R_HMR_3193',
              'R_HMR_3195', 'R_HMR_3196', 'R_HMR_3197', 'R_HMR_3199', 'R_HMR_3200', 'R_HMR_3201',
              'R_HMR_3203', 'R_HMR_3204', 'R_HMR_3205', 'R_HMR_3219', 'R_HMR_3220', 'R_HMR_3221',
              'R_HMR_3223', 'R_HMR_3224', 'R_HMR_3225', 'R_HMR_3229', 'R_HMR_3231', 'R_HMR_3232',
              'R_HMR_3233', 'R_HMR_3235', 'R_HMR_3236', 'R_HMR_3237', 'R_HMR_3241', 'R_HMR_3242',
              'R_HMR_3243', 'R_HMR_3245', 'R_HMR_3246', 'R_HMR_3247', 'R_HMR_3398', 'R_HMR_3406',
              'R_HMR_3407', 'R_HMR_3408', 'R_HMR_3409', 'R_HMR_3411', 'R_HMR_3413', 'R_HMR_3414',
              'R_HMR_3416', 'R_HMR_3421', 'R_HMR_3422', 'R_HMR_3423', 'R_HMR_3424', 'R_HMR_3425',
              'R_HMR_3426', 'R_HMR_3427', 'R_HMR_3428', 'R_HMR_3429', 'R_HMR_3431', 'R_HMR_3432',
              'R_HMR_3433', 'R_HMR_3449', 'R_HMR_3450', 'R_HMR_3451', 'R_HMR_3453', 'R_HMR_3454',
              'R_HMR_3455', 'R_HMR_9719', 'R_3HPVSTETCOAhcm')
    'E1720'. ('R_RE0912C')
    'E1721'. ('R_RE0915E', 'R_RE0926E', 'R_RE0935E', 'R_RE0944E', 'R_RE0958E', 'R_HMR_8570',
              'R_HMR_8571', 'R_HMR_8572', 'R_HMR_8573', 'R_HMR_8574', 'R_HMR_8575', 'R_HMR_8576',
              'R_HMR_8577', 'R_HMR_8578', 'R_HMR_8579', 'R_HMR_8580', 'R_HMR_8582')
    'E1722'. ('R_RE1050E', 'R_RE2514E', 'R_HMR_2088', 'R_HMR_2089')
    'E1724'. ('R_HMR_6550', 'R_HMR_6558')
    'E1726'. ('R_RE2429M', 'R_GLYNATm', 'R_PPIOGLYc', 'R_TIGGLYc', 'R_HEXGLYc', 'R_SUBGLYc')
    'E1734'. ('R_RE2235R', 'R_HMR_0942', 'R_HMR_0946', 'R_HMR_0950', 'R_HMR_0954', 'R_HMR_0981',
              'R_HMR_1126', 'R_HMR_1127', 'R_HMR_2029', 'R_HMR_2457')
    'E1735'. ('R_RE2269E')
    'E1736'. ('R_RE2270E', 'R_RE2273E')
    'E1743'. ('R_RE2445E')
    'E1745'. ('R_HMR_0765')
    'E1748'. ('R_RE2993X', 'R_RE2996X', 'R_FAOXC102C101x', 'R_FAOXC103C102x', 'R_FAOXC164C163x', 'R_FAOXC165C164x',
              'R_FAOXC226C225x', 'R_HMR_3296', 'R_HMR_3322', 'R_HMR_3446', 'R_HMR_3457')
    'E1749'. ('R_RE3001M', 'R_FAOXC103C102m', 'R_FAOXC164GC163m', 'R_FAOXC226C225m', 'R_FAOXC227C226m', 'R_HMR_3296',
              'R_HMR_3322', 'R_HMR_3446', 'R_HMR_3457')
    'E1751'. ('R_RE3010M', 'R_RE3010X', 'R_RE3432M', 'R_RE3432X', 'R_RE3470M', 'R_RE3476M',
              'R_RE3597M', 'R_RE3597X', 'R_HMR_1102', 'R_HMR_0980')
    'E1752'. ('R_RE3014R', 'R_RE3015R', 'R_HMR_0981', 'R_HMR_1126', 'R_HMR_1127')
    'E1753'. ('R_RE3038C', 'R_RE3040C', 'R_RE3258C', 'R_RE3259C')
    'E1754'. ('R_RE3269C')
    'E1757'. ('R_RE3269C', 'R_MI1PP', 'R_HMR_6545')
    'E1758'. ('R_HMR_0960', 'R_HMR_0963')
    'E1761'. ('R_GLCt4')
    'E1765'. ('R_PROt4_2_r', 'R_HMR_9617')
    'E1767'. ('R_2MB2COAc', 'R_3HBCOARc', 'R_HDCACBP', 'R_HDDACBP', 'R_HEXDICOAACBP', 'R_HOCTDACBP',
              'R_HTDCACBP', 'R_OCTDEC2ACBP', 'R_HMR_7758')
    'E1768'. ('R_DOCOSCOAtxc')
    'E1769'. ('R_DOCO13EFATP', 'R_OCT11EFATP', 'R_CE2510ABCt', 'R_CE2537ABCt', 'R_NRVNCABCt', 'R_HMR_0155',
              'R_HMR_0164', 'R_HMR_0167', 'R_HMR_0170', 'R_HMR_0176', 'R_HMR_0183', 'R_HMR_0191',
              'R_HMR_0203', 'R_HMR_0208', 'R_HMR_0232', 'R_HMR_0240', 'R_HMR_0244', 'R_HMR_0254',
              'R_HMR_0270', 'R_HMR_0278', 'R_HMR_0288', 'R_HMR_0292', 'R_HMR_0296', 'R_HMR_0300',
              'R_HMR_0304', 'R_HMR_0308', 'R_HMR_0322', 'R_HMR_0326', 'R_HMR_0344', 'R_HMR_0380',
              'R_HMR_0384', 'R_HMR_0388', 'R_HMR_0392', 'R_HMR_0428', 'R_HMR_0432', 'R_HMR_0436')
    'E1770'. ('R_HMR_0188', 'R_HMR_0192', 'R_HMR_0200', 'R_HMR_0204', 'R_HMR_0209', 'R_HMR_0233',
              'R_HMR_0241', 'R_HMR_0245', 'R_HMR_0255', 'R_HMR_0259', 'R_HMR_0267', 'R_HMR_0271',
              'R_HMR_0279', 'R_HMR_0289', 'R_HMR_0293', 'R_HMR_0297', 'R_HMR_0301', 'R_HMR_0305',
              'R_HMR_0309', 'R_HMR_0319', 'R_HMR_0323', 'R_HMR_0327', 'R_HMR_0345', 'R_HMR_0381',
              'R_HMR_0385', 'R_HMR_0389', 'R_HMR_0393', 'R_HMR_0429', 'R_HMR_0433', 'R_HMR_0437',
              'R_HMR_2942', 'R_HMR_2943', 'R_HMR_2944', 'R_HMR_2945', 'R_HMR_2946', 'R_HMR_2947',
              'R_HMR_2948', 'R_HMR_2951', 'R_HMR_2954', 'R_HMR_2955', 'R_HMR_2956', 'R_HMR_2961',
              'R_HMR_2962', 'R_HMR_2963', 'R_HMR_2964', 'R_HMR_2965', 'R_HMR_2966', 'R_HMR_2967',
              'R_HMR_2968', 'R_HMR_2969', 'R_HMR_2970', 'R_HMR_2971', 'R_HMR_2972', 'R_HMR_2973',
              'R_HMR_2974', 'R_HMR_2975', 'R_HMR_2976', 'R_HMR_2977', 'R_HMR_2978', 'R_HMR_2979',
              'R_HMR_2980', 'R_HMR_2982', 'R_HMR_2983', 'R_HMR_2985', 'R_HMR_2986', 'R_HMR_2988',
              'R_HMR_2989', 'R_HMR_2990', 'R_HMR_2994', 'R_HMR_2998', 'R_HMR_2999', 'R_HMR_3001',
              'R_HMR_3002', 'R_HMR_3003', 'R_HMR_2957')
    'E1771'. ('R_FAOXC102C81m', 'R_FAOXC122C101m', 'R_FAOXC123C102m')
    'E1772'. ('R_FAOXC101C8x', 'R_FAOXC102C81x', 'R_FAOXC121C10x', 'R_FAOXC123C102x', 'R_FAOXC163C142x', 'R_FAOXC164C143x',
              'R_FAOXC184C163x', 'R_FAOXC205C184x', 'R_FAOXC225C204x', 'R_FOAXC122C101x')
    'E1774'. ('R_FAOXC12C10m', 'R_FAOXC81C61m', 'R_FAOXC8C6m')
    'E1775'. ('R_FAOXC10C8x', 'R_FAOXC12C10x', 'R_FAOXC142C122x', 'R_FAOXC143C123x', 'R_FAOXC14C12x', 'R_FAOXC16C14x',
              'R_FAOXC184C164x', 'R_FAOXC22C20x', 'R_FAOXC24C22x', 'R_FAOXC6C4x', 'R_FAOXC81C61x')
    'E1776'. ('R_FAOXC11BRC9BRx')
    'E1780'. ('R_FAOXC13BRC11BRx')
    'E1784'. ('R_FAOXC142C122m', 'R_FAOXC143C123m', 'R_FAOXC14C12m', 'R_FAOXC163C143m', 'R_FAOXC16C14m', 'R_FAOXC183C163m',
              'R_FAOXC204C184m', 'R_FAOXC226C205m')
    'E1785'. ('R_FAOXC181C181OHm', 'R_FAOXC182C182OHm')
    'E1787'. ('R_FAOXC15NADPx', 'R_FAOXC15NADx')
    'E1790'. ('R_FAOXOHC16C16DCc')
    'E1791'. ('R_4OHPROIMINOtc', 'R_PROIMINOtc')
    'E1793'. ('R_ALAyLATthc', 'R_GLNyLATthc', 'R_HISyLATtc', 'R_HISyLATthc', 'R_LEUyLAThtc', 'R_METyLATthc',
              'R_PHEyLATthc')
    'E1795'. ('R_CYSTALArBATtc', 'R_CYSTLEUrBATtc')
    'E1796'. ('R_FOLTle', 'R_PHEMEe', 'R_MLTHFte')
    'E1798'. ('R_HMR_0155', 'R_HMR_0164', 'R_HMR_0167', 'R_HMR_0170', 'R_HMR_0176', 'R_HMR_0183',
              'R_HMR_0191', 'R_HMR_0203', 'R_HMR_0208', 'R_HMR_0232', 'R_HMR_0240', 'R_HMR_0244',
              'R_HMR_0254', 'R_HMR_0270', 'R_HMR_0278', 'R_HMR_0288', 'R_HMR_0292', 'R_HMR_0296',
              'R_HMR_0300', 'R_HMR_0304', 'R_HMR_0308', 'R_HMR_0322', 'R_HMR_0326', 'R_HMR_0344',
              'R_HMR_0380', 'R_HMR_0384', 'R_HMR_0388', 'R_HMR_0392', 'R_HMR_0428', 'R_HMR_0432',
              'R_HMR_0436')
    'E1800'. ('R_NACHORCTL3le')
    'E1805'. ('R_FMNALKPle')
    'E1806'. ('R_MTHFR3', 'R_MTHFD', 'R_r0792')
    'E1807'. ('R_P5CR')
    'E1809'. ('R_PHEMEe')
    'E1810'. ('R_RPEc')
    'E1812'. ('R_OROTGLUt', 'R_FOLOAT2tc', 'R_HMR_9623', 'R_HMR_9624', 'R_OXYPthc')
    'E1813'. ('R_LKYNRtr2')
    'E1814'. ('R_CE1918te', 'R_34DHOXMANDte', 'R_CE6205te')
    'E1815'. ('R_FOLOAT2tc', 'R_CE1918te', 'R_34DHOXMANDte', 'R_CE6205te')
    'E1817'. ('R_ALAPAT4te', 'R_PROPAT4te', 'R_TRPt')
    'E1819'. ('R_FOLABCCte', 'R_CAMPt', 'R_CGMPt', 'R_GCHOLAt3', 'R_TCHOLAt3', 'R_C03990ATP',
              'R_C04483t1', 'R_C05463t1', 'R_CE1273t1', 'R_HC02195te', 'R_HC02196te', 'R_DHCHOLESTANATEATP',
              'R_THCHOLSTOICATP', 'R_XOL7AH3ATP', 'R_XOL7AONEATP', 'R_XOLDIOLONEATP', 'R_7KILTCHOLATP', 'R_MLTHFte1')
    'E1820'. ('R_TRYPTAte')
    'E1822'. ('R_FOLABCCte', 'R_HC02220te', 'R_MLTHFte1', 'R_CDCA24Gte', 'R_CDCA3Gte', 'R_HCA24Gte',
              'R_HDCA24Gte', 'R_HDCA6Gte', 'R_LCA24Gte', 'R_LCA3Gte', 'R_3HPVSTETteb', 'R_3HPVSteb',
              'R_3ISPVSteb', 'R_56DHPVSteb', 'R_56EPPVSteb', 'R_6EPSteb', 'R_7HPVSteb', 'R_DSPVSteb',
              'R_PVSGLUCteb', 'R_TRIPVSteb')
    'E1823'. ('R_FOLOAT2tc', 'R_T4HCINNMte', 'R_HMR_9623', 'R_HMR_9624')
    'E1824'. ('R_H2OGLYAQPt')
    'E1827'. ('R_PGLYCABCte')
    'E1829'. ('R_CAMPt', 'R_CGMPt')
    'E1830'. ('R_FRUt4', 'R_GALt4', 'R_GLCt4', 'R_MANt4')
    'E1832'. ('R_GALt4', 'R_GLCt4')
    'E1834'. ('R_RIBFLVte')
    'E1836'. ('R_r1492')
    'E1840'. ('R_RETt')
    'E1843'. ('R_r0963', 'R_MLTHFte3')
    'E1844'. ('R_15KPROSTGF2c')
    'E1845'. ('R_SMS1', 'R_SMS10', 'R_SMS11', 'R_SMS12', 'R_SMS16', 'R_SMS13',
              'R_SMS14', 'R_SMS15', 'R_SMS2', 'R_SMS3', 'R_SMS4', 'R_SMS5',
              'R_SMS6', 'R_SMS7', 'R_SMS8', 'R_SMS9', 'R_SMS1S2')
    'E1847'. ('R_ACONT')
    'E1848'. ('R_ADK1', 'R_r0345')
    'E1850'. ('R_ADPT')
    'E1851'. ('R_ADSS')
    'E1854'. ('R_ALAR')
    'E1855'. ('R_ARGN')
    'E1856'. ('R_CPPPGO')
    'E1857'. ('R_CTPS1', 'R_CTPS2')
    'E1860'. ('R_GK1')
    'E1862'. ('R_DMATT', 'R_GRTT', 'R_HMR_1532')
    'E1863'. ('R_ENO')
    'E1867'. ('R_FERO')
    'E1868'. ('R_FMNAT')
    'E1870'. ('R_GALU')
    'E1872'. ('R_GAPD')
    'E1874'. ('R_GF6PTA')
    'E1878'. ('R_HMR_1085')
    'E1879'. ('R_GMAND')
    'E1882'. ('R_H2CO3D')
    'E1890'. ('R_HMBS')
    'E1891'. ('R_ILETA', 'R_LEUTA', 'R_VALTA')
    'E1892'. ('R_IMPD')
    'E1895'. ('R_L_LACt2r')
    'E1896'. ('R_MAN1PT2')
    'E1898'. ('R_MAN6PI')
    'E1899'. ('R_MTHFC', 'R_MTHFD2')
    'E1902'. ('R_NAt3_1')
    'E1905'. ('R_PGK')
    'E1908'. ('R_PGMT', 'R_PPM')
    'E1909'. ('R_PGMT', 'R_PMANM', 'R_PPM', 'R_r0570')
    'E1910'. ('R_PMANM')
    'E1917'. ('R_PPBNGS')
    'E1921'. ('R_PRO1x', 'R_PROD2')
    'E1922'. ('R_PROt2r', 'R_GLYt2r', 'R_ALAt2r')
    'E1923'. ('R_PRPPS')
    'E1929'. ('R_PSP_L')
    'E1931'. ('R_RBFK')
    'E1934'. ('R_THRS')
    'E1935'. ('R_TKT1', 'R_TKT2')
    'E1938'. ('R_TMDPK')
    'E1941'. ('R_UAG4E', 'R_UDPG4E')
    'E1943'. ('R_UAGDP')
    'E1945'. ('R_UPP3S')
    'E1946'. ('R_UREAt')
    'E1949'. ('R_r0345')
    'E1950'. ('R_ACCOAC')
    'E1960'. ('R_NTD6', 'R_NTD7', 'R_NTD8', 'R_NTD10', 'R_NTD11', 'R_NT5C',
              'R_NTD3')
    'E1961'. ('R_NADS2', 'R_HMR_4261', 'R_HMR_4278')
    'E1962'. ('R_ADNK1')
    'E1964'. ('R_ACYP')
    'E1971'. ('R_CITL')
    'E1973'. ('R_G6PDA')
    'E1975'. ('R_GALK')
    'E1978'. ('R_GALT', 'R_UGLT')
    'E1981'. ('R_GLUPRT')
    'E1984'. ('R_HISD')
    'E1987'. ('R_MI1PP', 'R_MI3PP')
    'E1989'. ('R_MI1PP', 'R_HMR_6545')
    'E1990'. ('R_NTD3')
    'E1991'. ('R_HMR_4422')
    'E1992'. ('R_PFK')
    'E2003'. ('R_PRFGS')
    'E2007'. ('R_THRD_L')
    'E2011'. ('R_DCMPDA')
    'E2013'. ('R_THMt3')
    'E2014'. ('R_AHC')
    'E2018'. ('R_3HADICOAx', 'R_3OHSEBCOAx', 'R_3OHSUBCOAx')
    'E2022'. ('R_PE12_HSABCt', 'R_Pe13_HSABCt', 'R_PE14_HSABCt', 'R_PE15_HSABCt', 'R_PE161_HSABCt', 'R_PE17_HSABCt',
              'R_PE203_HSABCt', 'R_PE226_HSABCt', 'R_PE2LINL_HSABCt', 'R_PEAR_HSABCt', 'R_PEDH203_HSABCt', 'R_PELINL_HSABCt',
              'R_PELPALM_HSABCt', 'R_PEOLE_HSABCt', 'R_PESTE_HSABCt')
    'E2024'. ('R_ANDRSTANDRte', 'R_2HATVLACGLUCteb', 'R_6MELVACtbc', 'R_ISOLVSTtbc')
    'E2025'. ('R_EIC21114TRc', 'R_5EIPENCm')
    'E2026'. ('R_5EIPENCtm', 'R_Htmi')
    'E2027'. ('R_EIC21114TRc')
    'E2028'. ('R_C05770te', 'R_HMR_4756')
    'E2029'. ('R_MMAte')
    'E2030'. ('R_PTRCARGte')
    'E2031'. ('R_1A25DHVITD3te', 'R_HMR_0019')
    'E2032'. ('R_1A25DHVITD3te', 'R_HMR_0155', 'R_HMR_0164', 'R_HMR_0167', 'R_HMR_0170', 'R_HMR_0176',
              'R_HMR_0183', 'R_HMR_0191', 'R_HMR_0203', 'R_HMR_0208', 'R_HMR_0232', 'R_HMR_0240',
              'R_HMR_0244', 'R_HMR_0254', 'R_HMR_0270', 'R_HMR_0278', 'R_HMR_0288', 'R_HMR_0292',
              'R_HMR_0296', 'R_HMR_0300', 'R_HMR_0304', 'R_HMR_0308', 'R_HMR_0322', 'R_HMR_0326',
              'R_HMR_0344', 'R_HMR_0380', 'R_HMR_0384', 'R_HMR_0388', 'R_HMR_0392', 'R_HMR_0428',
              'R_HMR_0432', 'R_HMR_0436')
    'E2033'. ('R_1A25DHVITD3te')
    'E2034'. ('R_CE5026t')
    'E2035'. ('R_NADPQNOXR', 'R_NADQNOXR')
    'E2037'. ('R_HMR_0753')
    'E2038'. ('R_ACER21g', 'R_ACER22g', 'R_HMR_0753')
    'E2044'. ('R_GBA2e')
    'E2049'. ('R_NEU21', 'R_NEU22', 'R_NEU23', 'R_NEU24', 'R_NEU25', 'R_HMR_0825',
              'R_HMR_0847')
    'E2050'. ('R_NEU38n', 'R_HMR_0825', 'R_HMR_0847')
    'E2077'. ('R_HMR_0189', 'R_HMR_0193', 'R_HMR_0197', 'R_HMR_0201', 'R_HMR_0206', 'R_HMR_0210',
              'R_HMR_0214', 'R_HMR_0230', 'R_HMR_0234', 'R_HMR_0238', 'R_HMR_0242', 'R_HMR_0246',
              'R_HMR_0256', 'R_HMR_0260', 'R_HMR_0268', 'R_HMR_0272', 'R_HMR_0276', 'R_HMR_0280',
              'R_HMR_0290', 'R_HMR_0298', 'R_HMR_0302', 'R_HMR_0306', 'R_HMR_0310', 'R_HMR_0324',
              'R_HMR_0328', 'R_HMR_0342', 'R_HMR_0346', 'R_HMR_0350', 'R_HMR_0354', 'R_HMR_0358',
              'R_HMR_0362', 'R_HMR_0366', 'R_HMR_0370', 'R_HMR_0374', 'R_HMR_0378', 'R_HMR_0382',
              'R_HMR_0386', 'R_HMR_0390', 'R_HMR_0394', 'R_HMR_0398', 'R_HMR_0402', 'R_HMR_0406',
              'R_HMR_0410', 'R_HMR_0414', 'R_HMR_0418', 'R_HMR_0422', 'R_HMR_0426', 'R_HMR_0430',
              'R_HMR_0434', 'R_HMR_0438')
    'E2081'. ('R_HMR_0597', 'R_HMR_0598', 'R_HMR_0601', 'R_HMR_0767', 'R_HMR_0775')
    'E2082'. ('R_HMR_0597', 'R_HMR_0598', 'R_HMR_0601', 'R_HMR_0767')
    'E2089'. ('R_HMR_0614')
    'E2090'. ('R_HMR_0629', 'R_HMR_0642')
    'E2092'. ('R_HMR_0629')
    'E2094'. ('R_HMR_0678')
    'E2095'. ('R_HMR_0750', 'R_HMR_0758')
    'E2107'. ('R_HMR_0765', 'R_HMR_0875', 'R_HMR_0890')
    'E2114'. ('R_HMR_0765', 'R_HMR_0860')
    'E2126'. ('R_HMR_0765', 'R_HMR_0911')
    'E2134'. ('R_HMR_0807', 'R_HMR_0808', 'R_HMR_0821', 'R_HMR_0828')
    'E2135'. ('R_HMR_0819', 'R_HMR_0830')
    'E2136'. ('R_HMR_0823')
    'E2137'. ('R_HMR_0825', 'R_HMR_0847')
    'E2139'. ('R_HMR_0864')
    'E2140'. ('R_HMR_0870', 'R_HMR_0873', 'R_HMR_0911', 'R_HMR_8271')
    'E2142'. ('R_HMR_0942', 'R_HMR_0946', 'R_HMR_0950', 'R_HMR_0954', 'R_HMR_2029', 'R_HMR_2457')
    'E2146'. ('R_HMR_1312')
    'E2149'. ('R_HMR_2016', 'R_HMR_2018')
    'E2150'. ('R_HMR_1490', 'R_HMR_1493', 'R_HMR_1494', 'R_HMR_1502', 'R_HMR_1503', 'R_HMR_1504',
              'R_HMR_1543', 'R_HMR_1544', 'R_HMR_1545', 'R_HMR_1548', 'R_HMR_1549', 'R_HMR_1550')
    'E2151'. ('R_HMR_1495')
    'E2152'. ('R_HMR_1540', 'R_HMR_1484')
    'E2153'. ('R_HMR_1653', 'R_HMR_3065', 'R_HMR_3069', 'R_HMR_3073', 'R_HMR_3097', 'R_HMR_3101',
              'R_HMR_3329', 'R_HMR_3333', 'R_HMR_3337', 'R_HMR_3341', 'R_HMR_3345', 'R_HMR_3349',
              'R_HMR_3353')
    'E2154'. ('R_HMR_1916')
    'E2159'. ('R_HMR_2041', 'R_HMR_6633')
    'E2161'. ('R_HMR_2041', 'R_HMR_2217', 'R_HMR_2260', 'R_HMR_2264', 'R_HMR_2268', 'R_HMR_2334',
              'R_HMR_2343', 'R_HMR_2348', 'R_HMR_2354', 'R_HMR_2362', 'R_HMR_2434', 'R_HMR_2533',
              'R_HMR_2541')
    'E2163'. ('R_HMR_2190', 'R_HMR_2211', 'R_HMR_2215', 'R_HMR_2259', 'R_HMR_2263', 'R_HMR_2267',
              'R_HMR_2332', 'R_HMR_2342', 'R_HMR_2347', 'R_HMR_2353', 'R_HMR_2361', 'R_HMR_2395',
              'R_HMR_2433', 'R_HMR_2530', 'R_HMR_2540')
    'E2166'. ('R_HMR_2193', 'R_HMR_2218', 'R_HMR_2261', 'R_HMR_2265', 'R_HMR_2269', 'R_HMR_2336',
              'R_HMR_2344', 'R_HMR_2349', 'R_HMR_2355', 'R_HMR_2363', 'R_HMR_2435', 'R_HMR_2535',
              'R_HMR_2542')
    'E2171'. ('R_HMR_2210', 'R_HMR_2219', 'R_HMR_2262', 'R_HMR_2266', 'R_HMR_2270', 'R_HMR_2338',
              'R_HMR_2345', 'R_HMR_2350', 'R_HMR_2356', 'R_HMR_2364', 'R_HMR_2436', 'R_HMR_2537',
              'R_HMR_2543')
    'E2172'. ('R_HMR_2210', 'R_HMR_2219', 'R_HMR_2262', 'R_HMR_2266', 'R_HMR_2338', 'R_HMR_2345',
              'R_HMR_2350', 'R_HMR_2356', 'R_HMR_2364', 'R_HMR_2436', 'R_HMR_2537', 'R_HMR_2543')
    'E2174'. ('R_HMR_2359', 'R_HMR_2365', 'R_HMR_2368', 'R_HMR_2380', 'R_HMR_2472', 'R_HMR_2484')
    'E2175'. ('R_HMR_2581')
    'E2176'. ('R_HMR_2603', 'R_HMR_2609', 'R_HMR_2612', 'R_HMR_2621', 'R_HMR_2624', 'R_HMR_2634',
              'R_HMR_2644', 'R_HMR_2649', 'R_HMR_2652', 'R_HMR_2655', 'R_HMR_2661', 'R_HMR_2667',
              'R_HMR_2670', 'R_HMR_2673', 'R_HMR_2676', 'R_HMR_2679', 'R_HMR_2682', 'R_HMR_2685',
              'R_HMR_2688', 'R_HMR_2691', 'R_HMR_2695', 'R_HMR_2700', 'R_HMR_2703', 'R_HMR_2706',
              'R_HMR_2709', 'R_HMR_2712', 'R_HMR_2715', 'R_HMR_2718', 'R_HMR_2722', 'R_HMR_2727',
              'R_HMR_2731', 'R_HMR_2734', 'R_HMR_2737', 'R_HMR_2740', 'R_HMR_2744', 'R_HMR_2748',
              'R_HMR_2753', 'R_HMR_2757', 'R_HMR_2760', 'R_HMR_2764', 'R_HMR_2769', 'R_HMR_2772',
              'R_HMR_2775')
    'E2178'. ('R_HMR_3855', 'R_HMR_4592')
    'E2185'. ('R_HMR_4270')
    'E2190'. ('R_HMR_4776', 'R_HMR_4777')
    'E2193'. ('R_HMR_4790')
    'E2200'. ('R_HMR_6545')
    'E2219'. ('R_HMR_6564')
    'E2221'. ('R_HMR_6595')
    'E2222'. ('R_HMR_6632')
    'E2224'. ('R_HMR_6755')
    'E2225'. ('R_HMR_6826')
    'E2226'. ('R_HMR_6826', 'R_HMR_6834', 'R_HMR_6854')
    'E2228'. ('R_HMR_6838', 'R_HMR_6844', 'R_HMR_6850')
    'E2230'. ('R_HMR_6908')
    'E2231'. ('R_HMR_6975', 'R_HMR_6976', 'R_HMR_6977', 'R_Abeta_N6_methyl_L_lysine', 'R_Abeta_N6_dimethyl_L_lysine', 'R_Abeta_N6_N6_trimethyl_L_lysine',
              'R_Tau_N6_methyl_L_lysine', 'R_Tau_N6_dimethyl_L_lysine', 'R_Tau_N6_N6_trimethyl_L_lysine', 'R_TNFA_N6_methyl_L_lysine', 'R_TNFA_N6_dimethyl_L_lysine', 'R_TNFA_N6_N6_trimethyl_L_lysine',
              'R_IL6_N6_methyl_L_lysine', 'R_IL6_N6_dimethyl_L_lysine', 'R_IL6_N6_N6_trimethyl_L_lysine')
    'E2232'. ('R_HMR_6975', 'R_HMR_6976', 'R_HMR_6977')
    'E2256'. ('R_HMR_6978')
    'E2262'. ('R_HMR_7328')
    'E2263'. ('R_HMR_7329')
    'E2266'. ('R_HMR_7652')
    'E2270'. ('R_HMR_8395')
    'E2273'. ('R_HMR_8643')
    'E2276'. ('R_HMR_9191')
    'E2282'. ('R_HMR_9801')
    'E2297'. ('R_HMR_9807')
    'E2300'. ('R_12DHCHOLt', 'R_3DHCDCHOLt', 'R_3DHCHOLt', 'R_3DHDCAt', 'R_3DHLCAt', 'R_7DHCDCHOLt',
              'R_7DHCHOLt', 'R_COPROSTt', 'R_HYOCHOLt', 'R_ICDCHOLt', 'R_ISOCHOLt', 'R_THYOCHOLt',
              'R_UCHOLt', 'R_UDCHOLt')
    'E2302'. ('R_CDCA24GSc', 'R_CDCA24GSr', 'R_CDCA3GSc', 'R_CDCA3GSr', 'R_HCA24GSc', 'R_HCA24GSr',
              'R_HDCA24GSc', 'R_HDCA24GSr', 'R_HDCA6GSc', 'R_HDCA6GSr', 'R_LCA24GSc', 'R_LCA24GSr',
              'R_LCA3GSc', 'R_LCA3GSr')
    'E2304'. ('R_HDCA24Gtr')
    'E2305'. ('R_2HATVACIDhc', 'R_3HLVSTAChep', 'R_3HSMVACIDhep', 'R_4HATVACIDhc', 'R_6CSMVACIDhep', 'R_6HLVSTAChep',
              'R_6HMSMVACIDhep', 'R_6HSMVACIDhep', 'R_6MELACAChep', 'R_ATVACIDhc', 'R_LVSTACIDhep', 'R_PTVSThc',
              'R_RSVSPONhc', 'R_SMVHYDROhep')
    'E2307'. ('R_Htmi')
    'E2315'. ('R_CYOOm3i')
    'E2316'. ('R_CYOOm2i')
    'E2318'. ('R_Ub_Abeta', 'R_Ub_Tau', 'R_Ub_TNFA', 'R_Ub_IL6')
    'E2492'. ('R_Abeta_N6_methyl_L_lysine', 'R_Abeta_N6_dimethyl_L_lysine', 'R_Abeta_N6_N6_trimethyl_L_lysine', 'R_Tau_N6_methyl_L_lysine', 'R_Tau_N6_dimethyl_L_lysine', 'R_Tau_N6_N6_trimethyl_L_lysine',
              'R_TNFA_N6_methyl_L_lysine', 'R_TNFA_N6_dimethyl_L_lysine', 'R_TNFA_N6_N6_trimethyl_L_lysine', 'R_IL6_N6_methyl_L_lysine', 'R_IL6_N6_dimethyl_L_lysine', 'R_IL6_N6_N6_trimethyl_L_lysine')
    'E2494'. ('R_Abeta_N6_N6_N6_trimethyl_L_lysine', 'R_Tau_N6_N6_N6_trimethyl_L_lysine', 'R_TNFA_N6_N6_N6_trimethyl_L_lysine', 'R_IL6_N6_N6_N6_trimethyl_L_lysine')

********** Non-GPR association ----------
    'ER_10FTHF5GLUtl'.('R_10FTHF5GLUtl')
    'ER_10FTHF5GLUtm'.('R_10FTHF5GLUtm')
    'ER_10FTHF6GLUtl'.('R_10FTHF6GLUtl')
    'ER_10FTHF6GLUtm'.('R_10FTHF6GLUtm')
    'ER_10FTHF7GLUtl'.('R_10FTHF7GLUtl')
    'ER_10FTHF7GLUtm'.('R_10FTHF7GLUtm')
    'ER_10FTHFtl'.('R_10FTHFtl')
    'ER_10FTHFtm'.('R_10FTHFtm')
    'ER_24NPHte'.('R_24NPHte')
    'ER_25HVITD2tin_m'.('R_25HVITD2tin_m')
    'ER_25HVITD3tin_m'.('R_25HVITD3tin_m')
    'ER_2DR1PP'.('R_2DR1PP')
    'ER_2MCITt'.('R_2MCITt')
    'ER_34DHOXPEGt'.('R_34DHOXPEGt')
    'ER_35CGMPtn'.('R_35CGMPtn')
    'ER_3DPHBH1'.('R_3DPHBH1')
    'ER_3DPHBH2'.('R_3DPHBH2')
    'ER_3HBCOAHLm'.('R_3HBCOAHLm')
    'ER_3MLDAt'.('R_3MLDAt')
    'ER_3MOBt2im'.('R_3MOBt2im')
    'ER_3MOPt2im'.('R_3MOPt2im')
    'ER_4ABUTtm'.('R_4ABUTtm')
    'ER_4HBZCOAFm'.('R_4HBZCOAFm')
    'ER_4HBZFm'.('R_4HBZFm')
    'ER_4MOPt2im'.('R_4MOPt2im')
    'ER_4NPHSFte'.('R_4NPHSFte')
    'ER_4NPHte'.('R_4NPHte')
    'ER_5ADTSTSTERONESte'.('R_5ADTSTSTERONESte')
    'ER_5ADTSTSTERONEte'.('R_5ADTSTSTERONEte')
    'ER_5AOPtm'.('R_5AOPtm')
    'ER_5DHFtl'.('R_5DHFtl')
    'ER_5THFtl'.('R_5THFtl')
    'ER_5THFtm'.('R_5THFtm')
    'ER_6DHFtl'.('R_6DHFtl')
    'ER_6DHFtm'.('R_6DHFtm')
    'ER_6HTSTSTERONEte'.('R_6HTSTSTERONEte')
    'ER_6HTSTSTERONEtr'.('R_6HTSTSTERONEtr')
    'ER_6THFtl'.('R_6THFtl')
    'ER_6THFtm'.('R_6THFtm')
    'ER_7DHCHSTEROLtr'.('R_7DHCHSTEROLtr')
    'ER_7DHFtl'.('R_7DHFtl')
    'ER_7DHFtm'.('R_7DHFtm')
    'ER_7THFtl'.('R_7THFtl')
    'ER_7THFtm'.('R_7THFtm')
    'ER_AASAD3m'.('R_AASAD3m')
    'ER_ABTD'.('R_ABTD')
    'ER_ACACtx'.('R_ACACtx')
    'ER_ACALDtm'.('R_ACALDtm')
    'ER_ACCOAtn'.('R_ACCOAtn')
    'ER_ACGAGBSIDEtg'.('R_ACGAGBSIDEtg')
    'ER_ACGAGBSIDEtl'.('R_ACGAGBSIDEtl')
    'ER_ACGALK'.('R_ACGALK')
    'ER_ACGALK2'.('R_ACGALK2')
    'ER_ACGALtlg'.('R_ACGALtlg')
    'ER_ACGALtly'.('R_ACGALtly')
    'ER_ACGAMtly'.('R_ACGAMtly')
    'ER_ACGBGBSIDEtg'.('R_ACGBGBSIDEtg')
    'ER_ACGBGBSIDEtl'.('R_ACGBGBSIDEtl')
    'ER_ACHtn'.('R_ACHtn')
    'ER_ACNACNGAL14ACGLCGALGLUSIDEte'.('R_ACNACNGAL14ACGLCGALGLUSIDEte')
    'ER_ACNACNGALGBSIDEte'.('R_ACNACNGALGBSIDEte')
    'ER_ACNACNGALGBSIDEtg'.('R_ACNACNGALGBSIDEtg')
    'ER_ACNAMtn'.('R_ACNAMtn')
    'ER_ACNGALACGLCGAL14ACGLCGALGLUSIDEte'.('R_ACNGALACGLCGAL14ACGLCGALGLUSIDEte')
    'ER_ACNGALACGLCGAL14ACGLCGALGLUSIDEtg'.('R_ACNGALACGLCGAL14ACGLCGALGLUSIDEtg')
    'ER_ACNMLr'.('R_ACNMLr')
    'ER_ACt2m'.('R_ACt2m')
    'ER_ACt2r'.('R_ACt2r')
    'ER_ACtg'.('R_ACtg')
    'ER_ADCim'.('R_ADCim')
    'ER_ADNK1m'.('R_ADNK1m')
    'ER_ADRNCOAtx'.('R_ADRNCOAtx')
    'ER_ADRNt'.('R_ADRNt')
    'ER_AFLATOXINte'.('R_AFLATOXINte')
    'ER_AHCYStr'.('R_AHCYStr')
    'ER_AKGtp'.('R_AKGtp')
    'ER_AMETr'.('R_AMETr')
    'ER_AMPtp'.('R_AMPtp')
    'ER_ANDRSTRNte'.('R_ANDRSTRNte')
    'ER_ANDRSTRNtr'.('R_ANDRSTRNtr')
    'ER_AQCOBALt'.('R_AQCOBALt')
    'ER_ARAB_Lt'.('R_ARAB_Lt')
    'ER_ARACHCOAtx'.('R_ARACHCOAtx')
    'ER_ARACHDCOAtx'.('R_ARACHDCOAtx')
    'ER_ARACHDtr'.('R_ARACHDtr')
    'ER_ARACHt'.('R_ARACHt')
    'ER_R_group_phosphotase_1'.('R_R_group_phosphotase_1')
    'ER_R_group_phosphotase_3'.('R_R_group_phosphotase_3')
    'ER_ARTFR208'.('R_ARTFR208')
    'ER_ARTPLM3'.('R_ARTPLM3')
    'ER_ASCBOX'.('R_ASCBOX')
    'ER_ASCBt'.('R_ASCBt')
    'ER_ASPDxt'.('R_ASPDxt')
    'ER_ATP1ter'.('R_ATP1ter')
    'ER_ATP2ter'.('R_ATP2ter')
    'ER_ATPtn'.('R_ATPtn')
    'ER_ATPtx'.('R_ATPtx')
    'ER_B3GALTg'.('R_B3GALTg')
    'ER_BALAtmr'.('R_BALAtmr')
    'ER_BHBt'.('R_BHBt')
    'ER_BHBtm'.('R_BHBtm')
    'ER_BILDGLCURtr'.('R_BILDGLCURtr')
    'ER_BILIRUBtr'.('R_BILIRUBtr')
    'ER_BZt'.('R_BZt')
    'ER_BZtr'.('R_BZtr')
    'ER_C226COAtx'.('R_C226COAtx')
    'ER_C226CRNt'.('R_C226CRNt')
    'ER_CAROtr'.('R_CAROtr')
    'ER_CBL2OR'.('R_CBL2OR')
    'ER_CBPter'.('R_CBPter')
    'ER_CDPDAGtm'.('R_CDPDAGtm')
    'ER_CHOLPtg'.('R_CHOLPtg')
    'ER_CHOLPtl'.('R_CHOLPtl')
    'ER_CHOLtn'.('R_CHOLtn')
    'ER_CITMCOAHm'.('R_CITMCOAHm')
    'ER_CITMCOALm'.('R_CITMCOALm')
    'ER_CLPNDCOAtx'.('R_CLPNDCOAtx')
    'ER_CLPNDt'.('R_CLPNDt')
    'ER_CMPACNAtn'.('R_CMPACNAtn')
    'ER_CO2ter'.('R_CO2ter')
    'ER_CO2tg'.('R_CO2tg')
    'ER_CO2tm'.('R_CO2tm')
    'ER_CO2tp'.('R_CO2tp')
    'ER_COAtg'.('R_COAtg')
    'ER_COAtl'.('R_COAtl')
    'ER_COAtn'.('R_COAtn')
    'ER_COAtp'.('R_COAtp')
    'ER_COAtr'.('R_COAtr')
    'ER_COQ5m'.('R_COQ5m')
    'ER_CORE5GTg'.('R_CORE5GTg')
    'ER_CORE7GTg'.('R_CORE7GTg')
    'ER_COUCOAFm'.('R_COUCOAFm')
    'ER_COUMARINte'.('R_COUMARINte')
    'ER_CRMPte'.('R_CRMPte')
    'ER_CRNCAR3tp'.('R_CRNCAR3tp')
    'ER_CRNtx'.('R_CRNtx')
    'ER_CRTSTRNt'.('R_CRTSTRNt')
    'ER_CRVNCtr'.('R_CRVNCtr')
    'ER_CSAPASEly'.('R_CSAPASEly')
    'ER_CSBPASEly'.('R_CSBPASEly')
    'ER_CSCPASEly'.('R_CSCPASEly')
    'ER_CSDPASEly'.('R_CSDPASEly')
    'ER_CSEPASEly'.('R_CSEPASEly')
    'ER_CSPG_At'.('R_CSPG_At')
    'ER_CSPG_Atly'.('R_CSPG_Atly')
    'ER_CSPG_Btly'.('R_CSPG_Btly')
    'ER_CSPG_Ct'.('R_CSPG_Ct')
    'ER_CSPG_Ctly'.('R_CSPG_Ctly')
    'ER_CSPG_Dt'.('R_CSPG_Dt')
    'ER_CSPG_Dtly'.('R_CSPG_Dtly')
    'ER_CSPG_Et'.('R_CSPG_Et')
    'ER_CSPG_Etly'.('R_CSPG_Etly')
    'ER_CTPtn'.('R_CTPtn')
    'ER_CYSGLTH'.('R_CYSGLTH')
    'ER_CYTDK2m'.('R_CYTDK2m')
    'ER_D_3AIBt'.('R_D_3AIBt')
    'ER_DADNK'.('R_DADNK')
    'ER_DAG_HSter'.('R_DAG_HSter')
    'ER_DAGt'.('R_DAGt')
    'ER_DALAxt'.('R_DALAxt')
    'ER_DATPtn'.('R_DATPtn')
    'ER_DCK1m'.('R_DCK1m')
    'ER_DCSPTN1COAtx'.('R_DCSPTN1COAtx')
    'ER_DCSPTN1t'.('R_DCSPTN1t')
    'ER_DCTPtn'.('R_DCTPtn')
    'ER_DECDPtm'.('R_DECDPtm')
    'ER_DEDOLP1_L'.('R_DEDOLP1_L')
    'ER_DEDOLP2_L'.('R_DEDOLP2_L')
    'ER_DEDOLR_L'.('R_DEDOLR_L')
    'ER_DESAT22_1p'.('R_DESAT22_1p')
    'ER_DESAT22_2p'.('R_DESAT22_2p')
    'ER_DGCHOLte'.('R_DGCHOLte')
    'ER_DGCHOLtx'.('R_DGCHOLtx')
    'ER_DGK2m'.('R_DGK2m')
    'ER_DGSNtm'.('R_DGSNtm')
    'ER_DGTPtn'.('R_DGTPtn')
    'ER_DGULND'.('R_DGULND')
    'ER_DHEAStr'.('R_DHEAStr')
    'ER_DHEAtr'.('R_DHEAtr')
    'ER_DHFtl'.('R_DHFtl')
    'ER_DHFtm'.('R_DHFtm')
    'ER_DHPR2'.('R_DHPR2')
    'ER_DIGALSIDEtl'.('R_DIGALSIDEtl')
    'ER_DKMPPD'.('R_DKMPPD')
    'ER_DM_Asn_X_Ser_Thr_ly_'.('R_DM_Asn_X_Ser_Thr_ly_')
    'ER_DM_core5_g_'.('R_DM_core5_g_')
    'ER_DM_core7_g_'.('R_DM_core7_g_')
    'ER_DM_datp_m_'.('R_DM_datp_m_')
    'ER_DM_datp_n_'.('R_DM_datp_n_')
    'ER_DM_dctp_m_'.('R_DM_dctp_m_')
    'ER_DM_dctp_n_'.('R_DM_dctp_n_')
    'ER_DM_dem2emgacpail_prot_hs_r_'.('R_DM_dem2emgacpail_prot_hs_r_')
    'ER_DM_dgpi_prot_hs_r_'.('R_DM_dgpi_prot_hs_r_')
    'ER_DM_dgtp_m_'.('R_DM_dgtp_m_')
    'ER_DM_dgtp_n_'.('R_DM_dgtp_n_')
    'ER_DM_dttp_m_'.('R_DM_dttp_m_')
    'ER_DM_dttp_n_'.('R_DM_dttp_n_')
    'ER_DM_ethamp_r_'.('R_DM_ethamp_r_')
    'ER_DM_gncore2_g_'.('R_DM_gncore2_g_')
    'ER_DM_gpi_sig_er_'.('R_DM_gpi_sig_er_')
    'ER_DM_kdn_c_'.('R_DM_kdn_c_')
    'ER_DM_mem2emgacpail_prot_hs_r_'.('R_DM_mem2emgacpail_prot_hs_r_')
    'ER_DM_Ser_Thr_ly_'.('R_DM_Ser_Thr_ly_')
    'ER_DM_Ser_Gly_Ala_X_Gly_ly_'.('R_DM_Ser_Gly_Ala_X_Gly_ly_')
    'ER_DM_sprm_c_'.('R_DM_sprm_c_')
    'ER_DM_T_antigen_g_'.('R_DM_T_antigen_g_')
    'ER_DMHPTCRNt'.('R_DMHPTCRNt')
    'ER_DMHPTCRNte'.('R_DMHPTCRNte')
    'ER_DMNONCOACRNCPT1'.('R_DMNONCOACRNCPT1')
    'ER_DMNONCRNt'.('R_DMNONCRNt')
    'ER_DNADtn'.('R_DNADtn')
    'ER_DOLMANP_Uter'.('R_DOLMANP_Uter')
    'ER_DOLPMT4_Uer'.('R_DOLPMT4_Uer')
    'ER_DOPASFt'.('R_DOPASFt')
    'ER_DPCOAtl'.('R_DPCOAtl')
    'ER_DPHMBDCm'.('R_DPHMBDCm')
    'ER_DPPS'.('R_DPPS')
    'ER_DRIBt'.('R_DRIBt')
    'ER_DSAT'.('R_DSAT')
    'ER_DTDPtn'.('R_DTDPtn')
    'ER_DTTPtn'.('R_DTTPtn')
    'ER_EAFLATOXINte'.('R_EAFLATOXINte')
    'ER_EBASTINEOHte'.('R_EBASTINEOHte')
    'ER_EBASTINEOHtr'.('R_EBASTINEOHtr')
    'ER_EBASTINEte'.('R_EBASTINEte')
    'ER_EBASTINEtr'.('R_EBASTINEtr')
    'ER_EICOSTETt'.('R_EICOSTETt')
    'ER_ENGASE2ly'.('R_ENGASE2ly')
    'ER_ENGASE3ly'.('R_ENGASE3ly')
    'ER_ESTRADIOLt'.('R_ESTRADIOLt')
    'ER_ESTRADIOLtr'.('R_ESTRADIOLtr')
    'ER_ESTRIOLtr'.('R_ESTRIOLtr')
    'ER_ESTRONEtr'.('R_ESTRONEtr')
    'ER_EX_10fthf[e]'.('R_EX_10fthf[e]')
    'ER_EX_10fthf5glu[e]'.('R_EX_10fthf5glu[e]')
    'ER_EX_10fthf6glu[e]'.('R_EX_10fthf6glu[e]')
    'ER_EX_10fthf7glu[e]'.('R_EX_10fthf7glu[e]')
    'ER_EX_13_cis_retnglc[e]'.('R_EX_13_cis_retnglc[e]')
    'ER_EX_24nph[e]'.('R_EX_24nph[e]')
    'ER_EX_2hb[e]'.('R_EX_2hb[e]')
    'ER_EX_2mcit[e]'.('R_EX_2mcit[e]')
    'ER_EX_34dhoxpeg[e]'.('R_EX_34dhoxpeg[e]')
    'ER_EX_35cgmp[e]'.('R_EX_35cgmp[e]')
    'ER_EX_3aib[e]'.('R_EX_3aib[e]')
    'ER_EX_3aib_D[e]'.('R_EX_3aib_D[e]')
    'ER_EX_3mlda[e]'.('R_EX_3mlda[e]')
    'ER_EX_4nph[e]'.('R_EX_4nph[e]')
    'ER_EX_4nphsf[e]'.('R_EX_4nphsf[e]')
    'ER_EX_5adtststerone[e]'.('R_EX_5adtststerone[e]')
    'ER_EX_5adtststerones[e]'.('R_EX_5adtststerones[e]')
    'ER_EX_5dhf[e]'.('R_EX_5dhf[e]')
    'ER_EX_5fthf[e]'.('R_EX_5fthf[e]')
    'ER_EX_5htrp[e]'.('R_EX_5htrp[e]')
    'ER_EX_5mthf[e]'.('R_EX_5mthf[e]')
    'ER_EX_5thf[e]'.('R_EX_5thf[e]')
    'ER_EX_6dhf[e]'.('R_EX_6dhf[e]')
    'ER_EX_6htststerone[e]'.('R_EX_6htststerone[e]')
    'ER_EX_6thf[e]'.('R_EX_6thf[e]')
    'ER_EX_7dhf[e]'.('R_EX_7dhf[e]')
    'ER_EX_7thf[e]'.('R_EX_7thf[e]')
    'ER_EX_acetone[e]'.('R_EX_acetone[e]')
    'ER_EX_ach[e]'.('R_EX_ach[e]')
    'ER_EX_acnacngal14acglcgalgluside_hs[e]'.('R_EX_acnacngal14acglcgalgluside_hs[e]')
    'ER_EX_acnacngalgbside_hs[e]'.('R_EX_acnacngalgbside_hs[e]')
    'ER_EX_acngalacglcgal14acglcgalgluside_hs[e]'.('R_EX_acngalacglcgal14acglcgalgluside_hs[e]')
    'ER_EX_adp[e]'.('R_EX_adp[e]')
    'ER_EX_adprbp[e]'.('R_EX_adprbp[e]')
    'ER_EX_adrn[e]'.('R_EX_adrn[e]')
    'ER_EX_adrnl[e]'.('R_EX_adrnl[e]')
    'ER_EX_aflatoxin[e]'.('R_EX_aflatoxin[e]')
    'ER_EX_ala_B[e]'.('R_EX_ala_B[e]')
    'ER_EX_ala_D[e]'.('R_EX_ala_D[e]')
    'ER_EX_amp[e]'.('R_EX_amp[e]')
    'ER_EX_andrstrn[e]'.('R_EX_andrstrn[e]')
    'ER_EX_aprgstrn[e]'.('R_EX_aprgstrn[e]')
    'ER_EX_aqcobal[e]'.('R_EX_aqcobal[e]')
    'ER_EX_arach[e]'.('R_EX_arach[e]')
    'ER_EX_arachd[e]'.('R_EX_arachd[e]')
    'ER_EX_ascb_L[e]'.('R_EX_ascb_L[e]')
    'ER_EX_asp_D[e]'.('R_EX_asp_D[e]')
    'ER_EX_atp[e]'.('R_EX_atp[e]')
    'ER_EX_avite1[e]'.('R_EX_avite1[e]')
    'ER_EX_bhb[e]'.('R_EX_bhb[e]')
    'ER_EX_bildglcur[e]'.('R_EX_bildglcur[e]')
    'ER_EX_bilglcur[e]'.('R_EX_bilglcur[e]')
    'ER_EX_bilirub[e]'.('R_EX_bilirub[e]')
    'ER_EX_camp[e]'.('R_EX_camp[e]')
    'ER_EX_caro[e]'.('R_EX_caro[e]')
    'ER_EX_chol[e]'.('R_EX_chol[e]')
    'ER_EX_cholate[e]'.('R_EX_cholate[e]')
    'ER_EX_chsterol[e]'.('R_EX_chsterol[e]')
    'ER_EX_chtn[e]'.('R_EX_chtn[e]')
    'ER_EX_clpnd[e]'.('R_EX_clpnd[e]')
    'ER_EX_cmp[e]'.('R_EX_cmp[e]')
    'ER_EX_coumarin[e]'.('R_EX_coumarin[e]')
    'ER_EX_creat[e]'.('R_EX_creat[e]')
    'ER_EX_crmp_hs[e]'.('R_EX_crmp_hs[e]')
    'ER_EX_crn[e]'.('R_EX_crn[e]')
    'ER_EX_crtstrn[e]'.('R_EX_crtstrn[e]')
    'ER_EX_crvnc[e]'.('R_EX_crvnc[e]')
    'ER_EX_cspg_a[e]'.('R_EX_cspg_a[e]')
    'ER_EX_cspg_b[e]'.('R_EX_cspg_b[e]')
    'ER_EX_cspg_c[e]'.('R_EX_cspg_c[e]')
    'ER_EX_cspg_d[e]'.('R_EX_cspg_d[e]')
    'ER_EX_cspg_e[e]'.('R_EX_cspg_e[e]')
    'ER_EX_dag_hs[e]'.('R_EX_dag_hs[e]')
    'ER_EX_dcsptn1[e]'.('R_EX_dcsptn1[e]')
    'ER_EX_dgchol[e]'.('R_EX_dgchol[e]')
    'ER_EX_dhdascb[e]'.('R_EX_dhdascb[e]')
    'ER_EX_dheas[e]'.('R_EX_dheas[e]')
    'ER_EX_dhf[e]'.('R_EX_dhf[e]')
    'ER_EX_dlnlcg[e]'.('R_EX_dlnlcg[e]')
    'ER_EX_dmhptcrn[e]'.('R_EX_dmhptcrn[e]')
    'ER_EX_dopa[e]'.('R_EX_dopa[e]')
    'ER_EX_dopasf[e]'.('R_EX_dopasf[e]')
    'ER_EX_eaflatoxin[e]'.('R_EX_eaflatoxin[e]')
    'ER_EX_ebastine[e]'.('R_EX_ebastine[e]')
    'ER_EX_ebastineoh[e]'.('R_EX_ebastineoh[e]')
    'ER_EX_eicostet[e]'.('R_EX_eicostet[e]')
    'ER_EX_elaid[e]'.('R_EX_elaid[e]')
    'ER_EX_estradiol[e]'.('R_EX_estradiol[e]')
    'ER_EX_estrones[e]'.('R_EX_estrones[e]')
    'ER_EX_fuc13galacglcgal14acglcgalgluside_hs[e]'.('R_EX_fuc13galacglcgal14acglcgalgluside_hs[e]')
    'ER_EX_fuc14galacglcgalgluside_hs[e]'.('R_EX_fuc14galacglcgalgluside_hs[e]')
    'ER_EX_fucacgalfucgalacglcgalgluside_hs[e]'.('R_EX_fucacgalfucgalacglcgalgluside_hs[e]')
    'ER_EX_fucfuc12gal14acglcgalgluside_hs[e]'.('R_EX_fucfuc12gal14acglcgalgluside_hs[e]')
    'ER_EX_fucfucfucgalacglc13galacglcgal14acglcgalgluside_hs[e]'.('R_EX_fucfucfucgalacglc13galacglcgal14acglcgalgluside_hs[e]')
    'ER_EX_fucfucgalacglcgalgluside_hs[e]'.('R_EX_fucfucgalacglcgalgluside_hs[e]')
    'ER_EX_fucgal14acglcgalgluside_hs[e]'.('R_EX_fucgal14acglcgalgluside_hs[e]')
    'ER_EX_fucgalfucgalacglcgalgluside_hs[e]'.('R_EX_fucgalfucgalacglcgalgluside_hs[e]')
    'ER_EX_fuc_L[e]'.('R_EX_fuc_L[e]')
    'ER_EX_galacglcgalgbside_hs[e]'.('R_EX_galacglcgalgbside_hs[e]')
    'ER_EX_galgalfucfucgalacglcgalacglcgal14acglcgalgluside_hs[e]'.('R_EX_galgalfucfucgalacglcgalacglcgal14acglcgalgluside_hs[e]')
    'ER_EX_galgalgalthcrm_hs[e]'.('R_EX_galgalgalthcrm_hs[e]')
    'ER_EX_gbside_hs[e]'.('R_EX_gbside_hs[e]')
    'ER_EX_gchola[e]'.('R_EX_gchola[e]')
    'ER_EX_gdp[e]'.('R_EX_gdp[e]')
    'ER_EX_gluala[e]'.('R_EX_gluala[e]')
    'ER_EX_glyc_S[e]'.('R_EX_glyc_S[e]')
    'ER_EX_glygn2[e]'.('R_EX_glygn2[e]')
    'ER_EX_glygn4[e]'.('R_EX_glygn4[e]')
    'ER_EX_glygn5[e]'.('R_EX_glygn5[e]')
    'ER_EX_gmp[e]'.('R_EX_gmp[e]')
    'ER_EX_gq1b_hs[e]'.('R_EX_gq1b_hs[e]')
    'ER_EX_gsn[e]'.('R_EX_gsn[e]')
    'ER_EX_gt1a_hs[e]'.('R_EX_gt1a_hs[e]')
    'ER_EX_gthox[e]'.('R_EX_gthox[e]')
    'ER_EX_gthrd[e]'.('R_EX_gthrd[e]')
    'ER_EX_gtp[e]'.('R_EX_gtp[e]')
    'ER_EX_h2o2[e]'.('R_EX_h2o2[e]')
    'ER_EX_ha[e]'.('R_EX_ha[e]')
    'ER_EX_ha_pre1[e]'.('R_EX_ha_pre1[e]')
    'ER_EX_hco3[e]'.('R_EX_hco3[e]')
    'ER_EX_hcoumarin[e]'.('R_EX_hcoumarin[e]')
    'ER_EX_hdca[e]'.('R_EX_hdca[e]')
    'ER_EX_hdcea[e]'.('R_EX_hdcea[e]')
    'ER_EX_hestratriol[e]'.('R_EX_hestratriol[e]')
    'ER_EX_hexc[e]'.('R_EX_hexc[e]')
    'ER_EX_hista[e]'.('R_EX_hista[e]')
    'ER_EX_hom_L[e]'.('R_EX_hom_L[e]')
    'ER_EX_hpdca[e]'.('R_EX_hpdca[e]')
    'ER_EX_hspg[e]'.('R_EX_hspg[e]')
    'ER_EX_htaxol[e]'.('R_EX_htaxol[e]')
    'ER_EX_i[e]'.('R_EX_i[e]')
    'ER_EX_idp[e]'.('R_EX_idp[e]')
    'ER_EX_imp[e]'.('R_EX_imp[e]')
    'ER_EX_ksi[e]'.('R_EX_ksi[e]')
    'ER_EX_ksi_deg1[e]'.('R_EX_ksi_deg1[e]')
    'ER_EX_ksii_core2[e]'.('R_EX_ksii_core2[e]')
    'ER_EX_ksii_core4[e]'.('R_EX_ksii_core4[e]')
    'ER_EX_lac_D[e]'.('R_EX_lac_D[e]')
    'ER_EX_Lcystin[e]'.('R_EX_Lcystin[e]')
    'ER_EX_leuktrA4[e]'.('R_EX_leuktrA4[e]')
    'ER_EX_leuktrB4[e]'.('R_EX_leuktrB4[e]')
    'ER_EX_leuktrC4[e]'.('R_EX_leuktrC4[e]')
    'ER_EX_leuktrD4[e]'.('R_EX_leuktrD4[e]')
    'ER_EX_leuktrE4[e]'.('R_EX_leuktrE4[e]')
    'ER_EX_leuktrF4[e]'.('R_EX_leuktrF4[e]')
    'ER_EX_lgnc[e]'.('R_EX_lgnc[e]')
    'ER_EX_lneldc[e]'.('R_EX_lneldc[e]')
    'ER_EX_lnlc[e]'.('R_EX_lnlc[e]')
    'ER_EX_lnlnca[e]'.('R_EX_lnlnca[e]')
    'ER_EX_lnlncg[e]'.('R_EX_lnlncg[e]')
    'ER_EX_lpchol_hs[e]'.('R_EX_lpchol_hs[e]')
    'ER_EX_mag_hs[e]'.('R_EX_mag_hs[e]')
    'ER_EX_meoh[e]'.('R_EX_meoh[e]')
    'ER_EX_mthgxl[e]'.('R_EX_mthgxl[e]')
    'ER_EX_n2m2nmasn[e]'.('R_EX_n2m2nmasn[e]')
    'ER_EX_nad[e]'.('R_EX_nad[e]')
    'ER_EX_nadp[e]'.('R_EX_nadp[e]')
    'ER_EX_ncam[e]'.('R_EX_ncam[e]')
    'ER_EX_no[e]'.('R_EX_no[e]')
    'ER_EX_nrpphr[e]'.('R_EX_nrpphr[e]')
    'ER_EX_nrpphrsf[e]'.('R_EX_nrpphrsf[e]')
    'ER_EX_nrvnc[e]'.('R_EX_nrvnc[e]')
    'ER_EX_o2s[e]'.('R_EX_o2s[e]')
    'ER_EX_oagd3_hs[e]'.('R_EX_oagd3_hs[e]')
    'ER_EX_oagt3_hs[e]'.('R_EX_oagt3_hs[e]')
    'ER_EX_ocdca[e]'.('R_EX_ocdca[e]')
    'ER_EX_ocdcea[e]'.('R_EX_ocdcea[e]')
    'ER_EX_octa[e]'.('R_EX_octa[e]')
    'ER_EX_oxa[e]'.('R_EX_oxa[e]')
    'ER_EX_pchol_hs[e]'.('R_EX_pchol_hs[e]')
    'ER_EX_pe_hs[e]'.('R_EX_pe_hs[e]')
    'ER_EX_peplys[e]'.('R_EX_peplys[e]')
    'ER_EX_pglyc_hs[e]'.('R_EX_pglyc_hs[e]')
    'ER_EX_phyt[e]'.('R_EX_phyt[e]')
    'ER_EX_prgstrn[e]'.('R_EX_prgstrn[e]')
    'ER_EX_prostgd2[e]'.('R_EX_prostgd2[e]')
    'ER_EX_prostge1[e]'.('R_EX_prostge1[e]')
    'ER_EX_prostge2[e]'.('R_EX_prostge2[e]')
    'ER_EX_ps_hs[e]'.('R_EX_ps_hs[e]')
    'ER_EX_ptdca[e]'.('R_EX_ptdca[e]')
    'ER_EX_retfa[e]'.('R_EX_retfa[e]')
    'ER_EX_retinol[e]'.('R_EX_retinol[e]')
    'ER_EX_retn[e]'.('R_EX_retn[e]')
    'ER_EX_Rtotal[e]'.('R_EX_Rtotal[e]')
    'ER_EX_Rtotal2[e]'.('R_EX_Rtotal2[e]')
    'ER_EX_Rtotal3[e]'.('R_EX_Rtotal3[e]')
    'ER_EX_s2l2fn2m2masn[e]'.('R_EX_s2l2fn2m2masn[e]')
    'ER_EX_s2l2n2m2masn[e]'.('R_EX_s2l2n2m2masn[e]')
    'ER_EX_spc_hs[e]'.('R_EX_spc_hs[e]')
    'ER_EX_sph1p[e]'.('R_EX_sph1p[e]')
    'ER_EX_sphs1p[e]'.('R_EX_sphs1p[e]')
    'ER_EX_srtn[e]'.('R_EX_srtn[e]')
    'ER_EX_strch1[e]'.('R_EX_strch1[e]')
    'ER_EX_strch2[e]'.('R_EX_strch2[e]')
    'ER_EX_strdnc[e]'.('R_EX_strdnc[e]')
    'ER_EX_tagat_D[e]'.('R_EX_tagat_D[e]')
    'ER_EX_taxol[e]'.('R_EX_taxol[e]')
    'ER_EX_tchola[e]'.('R_EX_tchola[e]')
    'ER_EX_tdchola[e]'.('R_EX_tdchola[e]')
    'ER_EX_tethex3[e]'.('R_EX_tethex3[e]')
    'ER_EX_tetpent3[e]'.('R_EX_tetpent3[e]')
    'ER_EX_tetpent6[e]'.('R_EX_tetpent6[e]')
    'ER_EX_tettet6[e]'.('R_EX_tettet6[e]')
    'ER_EX_thf[e]'.('R_EX_thf[e]')
    'ER_EX_thmtp[e]'.('R_EX_thmtp[e]')
    'ER_EX_thym[e]'.('R_EX_thym[e]')
    'ER_EX_thyox_L[e]'.('R_EX_thyox_L[e]')
    'ER_EX_tmndnc[e]'.('R_EX_tmndnc[e]')
    'ER_EX_triodthy[e]'.('R_EX_triodthy[e]')
    'ER_EX_triodthysuf[e]'.('R_EX_triodthysuf[e]')
    'ER_EX_tststerone[e]'.('R_EX_tststerone[e]')
    'ER_EX_tststerones[e]'.('R_EX_tststerones[e]')
    'ER_EX_ttdca[e]'.('R_EX_ttdca[e]')
    'ER_EX_txa2[e]'.('R_EX_txa2[e]')
    'ER_EX_Tyr_ggn[e]'.('R_EX_Tyr_ggn[e]')
    'ER_EX_udp[e]'.('R_EX_udp[e]')
    'ER_EX_ump[e]'.('R_EX_ump[e]')
    'ER_EX_urate[e]'.('R_EX_urate[e]')
    'ER_EX_utp[e]'.('R_EX_utp[e]')
    'ER_EX_vacc[e]'.('R_EX_vacc[e]')
    'ER_EX_vitd3[e]'.('R_EX_vitd3[e]')
    'ER_EX_whhdca[e]'.('R_EX_whhdca[e]')
    'ER_EX_whtststerone[e]'.('R_EX_whtststerone[e]')
    'ER_EX_xolest_hs[e]'.('R_EX_xolest_hs[e]')
    'ER_EX_xolest2_hs[e]'.('R_EX_xolest2_hs[e]')
    'ER_EX_xoltri24[e]'.('R_EX_xoltri24[e]')
    'ER_EX_xoltri27[e]'.('R_EX_xoltri27[e]')
    'ER_EX_xylt[e]'.('R_EX_xylt[e]')
    'ER_F1Atg'.('R_F1Atg')
    'ER_FADH2tru'.('R_FADH2tru')
    'ER_FADH2tx'.('R_FADH2tx')
    'ER_FADtru'.('R_FADtru')
    'ER_FADtx'.('R_FADtx')
    'ER_FALDtly'.('R_FALDtly')
    'ER_FCOAH'.('R_FCOAH')
    'ER_FE2t'.('R_FE2t')
    'ER_FE2tm'.('R_FE2tm')
    'ER_FORMCOAtx'.('R_FORMCOAtx')
    'ER_FORt2m'.('R_FORt2m')
    'ER_FORtr'.('R_FORtr')
    'ER_FRDPtr'.('R_FRDPtr')
    'ER_FUC13GALACGLCGAL14ACGLCGALGLUSIDEte'.('R_FUC13GALACGLCGAL14ACGLCGALGLUSIDEte')
    'ER_FUC13GALACGLCGAL14ACGLCGALGLUSIDEtg'.('R_FUC13GALACGLCGAL14ACGLCGALGLUSIDEtg')
    'ER_FUC14GALACGLCGALGLUSIDEte'.('R_FUC14GALACGLCGALGLUSIDEte')
    'ER_FUC14GALACGLCGALGLUSIDEtg'.('R_FUC14GALACGLCGALGLUSIDEtg')
    'ER_FUCACGALFUCGALACGLCGALGLUSIDEte'.('R_FUCACGALFUCGALACGLCGALGLUSIDEte')
    'ER_FUCFUC12GAL14ACGLCGALGLUSIDEte'.('R_FUCFUC12GAL14ACGLCGALGLUSIDEte')
    'ER_FUCFUC12GAL14ACGLCGALGLUSIDEtg'.('R_FUCFUC12GAL14ACGLCGALGLUSIDEtg')
    'ER_FUCFUCFUCGALACGLC13GALACGLCGAL14ACGLCGALGLUSIDEte'.('R_FUCFUCFUCGALACGLC13GALACGLCGAL14ACGLCGALGLUSIDEte')
    'ER_FUCFUCFUCGALACGLC13GALACGLCGAL14ACGLCGALGLUSIDEtg'.('R_FUCFUCFUCGALACGLC13GALACGLCGAL14ACGLCGALGLUSIDEtg')
    'ER_FUCFUCGALACGLCGALGLUSIDEte'.('R_FUCFUCGALACGLCGALGLUSIDEte')
    'ER_FUCFUCGALACGLCGALGLUSIDEtg'.('R_FUCFUCGALACGLCGALGLUSIDEtg')
    'ER_FUCGAL14ACGLCGALGLUSIDEte'.('R_FUCGAL14ACGLCGALGLUSIDEte')
    'ER_FUCGAL14ACGLCGALGLUSIDEtg'.('R_FUCGAL14ACGLCGALGLUSIDEtg')
    'ER_FUCGALFUCGALACGLCGALGLUSIDEte'.('R_FUCGALFUCGALACGLCGALGLUSIDEte')
    'ER_FUCtly'.('R_FUCtly')
    'ER_G5SADrm'.('R_G5SADrm')
    'ER_GACPAILter'.('R_GACPAILter')
    'ER_GALACGLCGALGBSIDEte'.('R_GALACGLCGALGBSIDEte')
    'ER_GALACGLCGALGBSIDEtg'.('R_GALACGLCGALGBSIDEtg')
    'ER_GALGALFUCFUCGALACGLCGALACGLCGAL14ACGLCGALGLUSIDEte'.('R_GALGALFUCFUCGALACGLCGALACGLCGAL14ACGLCGALGLUSIDEte')
    'ER_GALGALFUCFUCGALACGLCGALACGLCGAL14ACGLCGALGLUSIDEtg'.('R_GALGALFUCFUCGALACGLCGALACGLCGAL14ACGLCGALGLUSIDEtg')
    'ER_GALGALGALTHCRMte'.('R_GALGALGALTHCRMte')
    'ER_GALGALGALTHCRMtg'.('R_GALGALGALTHCRMtg')
    'ER_GALGLUSIDEtg'.('R_GALGLUSIDEtg')
    'ER_GALSIDEtl'.('R_GALSIDEtl')
    'ER_GALtly'.('R_GALtly')
    'ER_GBSIDEte'.('R_GBSIDEte')
    'ER_GBSIDEtl'.('R_GBSIDEtl')
    'ER_GCHOLAte'.('R_GCHOLAte')
    'ER_GDPtg'.('R_GDPtg')
    'ER_GGT_L'.('R_GGT_L')
    'ER_GGT6'.('R_GGT6')
    'ER_GLACter'.('R_GLACter')
    'ER_GLCMter'.('R_GLCMter')
    'ER_GLCter'.('R_GLCter')
    'ER_GLCtly'.('R_GLCtly')
    'ER_GLCURter'.('R_GLCURter')
    'ER_GLNtm'.('R_GLNtm')
    'ER_GLUt7l'.('R_GLUt7l')
    'ER_GLXtm'.('R_GLXtm')
    'ER_GLXtp'.('R_GLXtp')
    'ER_GLYC3Ptm'.('R_GLYC3Ptm')
    'ER_GLYCK2'.('R_GLYCK2')
    'ER_GLYCLTDym'.('R_GLYCLTDym')
    'ER_GLYCLTtp'.('R_GLYCLTtp')
    'ER_GLYC_St'.('R_GLYC_St')
    'ER_GLYCtm'.('R_GLYCtm')
    'ER_GLYtm'.('R_GLYtm')
    'ER_GLYtp'.('R_GLYtp')
    'ER_GMPtg'.('R_GMPtg')
    'ER_GMPtn'.('R_GMPtn')
    'ER_GQ1Bte'.('R_GQ1Bte')
    'ER_GT1Ate'.('R_GT1Ate')
    'ER_GTHDH'.('R_GTHDH')
    'ER_GTHRDtr'.('R_GTHRDtr')
    'ER_GULN3D'.('R_GULN3D')
    'ER_GULNDer'.('R_GULNDer')
    'ER_GULNter'.('R_GULNter')
    'ER_H2O2t'.('R_H2O2t')
    'ER_H2O2tly'.('R_H2O2tly')
    'ER_H2O2tm'.('R_H2O2tm')
    'ER_H2O2tp'.('R_H2O2tp')
    'ER_H2Oter'.('R_H2Oter')
    'ER_H2Otg'.('R_H2Otg')
    'ER_H2Otly'.('R_H2Otly')
    'ER_H2Otn'.('R_H2Otn')
    'ER_H2Otp'.('R_H2Otp')
    'ER_HAtly'.('R_HAtly')
    'ER_HCOUMARINte'.('R_HCOUMARINte')
    'ER_HDCAter'.('R_HDCAter')
    'ER_HDD2COAtx'.('R_HDD2COAtx')
    'ER_HESTRATRIOLte'.('R_HESTRATRIOLte')
    'ER_HESTRATRIOLtr'.('R_HESTRATRIOLtr')
    'ER_HEXCCOAtx'.('R_HEXCCOAtx')
    'ER_HEXCt'.('R_HEXCt')
    'ER_HMGCOAtm'.('R_HMGCOAtm')
    'ER_HMGCOAtx'.('R_HMGCOAtx')
    'ER_HPDCAt'.('R_HPDCAt')
    'ER_HPYRDC'.('R_HPYRDC')
    'ER_HPYRDCm'.('R_HPYRDCm')
    'ER_HPYRtp'.('R_HPYRtp')
    'ER_HSAT1ly'.('R_HSAT1ly')
    'ER_HSAT2ly'.('R_HSAT2ly')
    'ER_HSAT3ly'.('R_HSAT3ly')
    'ER_HSAT4ly'.('R_HSAT4ly')
    'ER_HSPASEly'.('R_HSPASEly')
    'ER_HSPGt'.('R_HSPGt')
    'ER_HSPGtly'.('R_HSPGtly')
    'ER_HTAXOLte'.('R_HTAXOLte')
    'ER_Htg'.('R_Htg')
    'ER_Htr'.('R_Htr')
    'ER_Htx'.('R_Htx')
    'ER_ILEt5m'.('R_ILEt5m')
    'ER_IPDPtx'.('R_IPDPtx')
    'ER_KDNH'.('R_KDNH')
    'ER_KSII_CORE2t'.('R_KSII_CORE2t')
    'ER_KSII_CORE2tly'.('R_KSII_CORE2tly')
    'ER_KSII_CORE4t'.('R_KSII_CORE4t')
    'ER_KSII_CORE4tly'.('R_KSII_CORE4tly')
    'ER_KSItly'.('R_KSItly')
    'ER_KYNATESYN'.('R_KYNATESYN')
    'ER_LEUKTRB4tr'.('R_LEUKTRB4tr')
    'ER_LEUKTRD4t'.('R_LEUKTRD4t')
    'ER_LEUt5m'.('R_LEUt5m')
    'ER_LGNCCOAtx'.('R_LGNCCOAtx')
    'ER_LINKDEG1ly'.('R_LINKDEG1ly')
    'ER_LINKDEG2ly'.('R_LINKDEG2ly')
    'ER_LINKDEG3ly'.('R_LINKDEG3ly')
    'ER_LINKDEG4ly'.('R_LINKDEG4ly')
    'ER_LNELDCt'.('R_LNELDCt')
    'ER_LPCHOLt'.('R_LPCHOLt')
    'ER_LTC4CP'.('R_LTC4CP')
    'ER_LTD4DP'.('R_LTD4DP')
    'ER_MAGt'.('R_MAGt')
    'ER_MANtly'.('R_MANtly')
    'ER_MCITS'.('R_MCITS')
    'ER_MDRPD'.('R_MDRPD')
    'ER_MEOHt2'.('R_MEOHt2')
    'ER_MEOHtly'.('R_MEOHtly')
    'ER_MGSA'.('R_MGSA')
    'ER_MGSA2'.('R_MGSA2')
    'ER_MI134P4P'.('R_MI134P4P')
    'ER_MI13PP'.('R_MI13PP')
    'ER_MI14P4P'.('R_MI14P4P')
    'ER_MINOHPtn'.('R_MINOHPtn')
    'ER_MTHGXLt'.('R_MTHGXLt')
    'ER_N2M2NMASNtly'.('R_N2M2NMASNtly')
    'ER_N4Tg'.('R_N4Tg')
    'ER_NADHtpu'.('R_NADHtpu')
    'ER_NADHtru'.('R_NADHtru')
    'ER_NADPHtru'.('R_NADPHtru')
    'ER_NADPHtxu'.('R_NADPHtxu')
    'ER_NADPtru'.('R_NADPtru')
    'ER_NADPtxu'.('R_NADPtxu')
    'ER_NADtn'.('R_NADtn')
    'ER_NADtru'.('R_NADtru')
    'ER_NAGAlby'.('R_NAGAlby')
    'ER_NAGLCAly'.('R_NAGLCAly')
    'ER_NCAMUP'.('R_NCAMUP')
    'ER_NH4tn'.('R_NH4tn')
    'ER_NH4tp'.('R_NH4tp')
    'ER_NICRNS'.('R_NICRNS')
    'ER_NICRNTtn'.('R_NICRNTtn')
    'ER_NMNtn'.('R_NMNtn')
    'ER_NOt'.('R_NOt')
    'ER_NRPPHRSFt'.('R_NRPPHRSFt')
    'ER_NRVNCCOAtx'.('R_NRVNCCOAtx')
    'ER_O2St'.('R_O2St')
    'ER_O2Stm'.('R_O2Stm')
    'ER_O2ter'.('R_O2ter')
    'ER_O2tm'.('R_O2tm')
    'ER_O2tn'.('R_O2tn')
    'ER_O2tp'.('R_O2tp')
    'ER_OAGD3te'.('R_OAGD3te')
    'ER_OAGD3tg'.('R_OAGD3tg')
    'ER_OAGT3te'.('R_OAGT3te')
    'ER_OCCOAtm'.('R_OCCOAtm')
    'ER_OCCOAtx'.('R_OCCOAtx')
    'ER_OCTAt'.('R_OCTAt')
    'ER_ODECOAtx'.('R_ODECOAtx')
    'ER_OXAtp'.('R_OXAtp')
    'ER_P450LTB4r'.('R_P450LTB4r')
    'ER_PAFS'.('R_PAFS')
    'ER_PAIL_HStn'.('R_PAIL_HStn')
    'ER_PAIL45P_HStn'.('R_PAIL45P_HStn')
    'ER_PAIL4P_HStn'.('R_PAIL4P_HStn')
    'ER_PAN4PP'.('R_PAN4PP')
    'ER_PAPtg'.('R_PAPtg')
    'ER_PCHOL_HSter'.('R_PCHOL_HSter')
    'ER_PCHOL_HStg'.('R_PCHOL_HStg')
    'ER_PE_HSter'.('R_PE_HSter')
    'ER_PEt'.('R_PEt')
    'ER_PGLYCt'.('R_PGLYCt')
    'ER_PHEMEtm'.('R_PHEMEtm')
    'ER_PHYTt'.('R_PHYTt')
    'ER_PI45P4P'.('R_PI45P4P')
    'ER_PI4P5Kn'.('R_PI4P5Kn')
    'ER_PI4PP'.('R_PI4PP')
    'ER_PI5P4Kn'.('R_PI5P4Kn')
    'ER_PIK3n'.('R_PIK3n')
    'ER_PIK4n'.('R_PIK4n')
    'ER_PIK5n'.('R_PIK5n')
    'ER_PItg'.('R_PItg')
    'ER_PItn'.('R_PItn')
    'ER_PMTCOAtx'.('R_PMTCOAtx')
    'ER_PPAn'.('R_PPAn')
    'ER_PPAt'.('R_PPAt')
    'ER_PPAtm'.('R_PPAtm')
    'ER_PPItr'.('R_PPItr')
    'ER_PPItx'.('R_PPItx')
    'ER_PPMI12346Ptn'.('R_PPMI12346Ptn')
    'ER_PPPG9tm'.('R_PPPG9tm')
    'ER_PRGSTRNt'.('R_PRGSTRNt')
    'ER_PRISTANALtx'.('R_PRISTANALtx')
    'ER_PRISTCOAtx'.('R_PRISTCOAtx')
    'ER_PRISTtx'.('R_PRISTtx')
    'ER_PROSTGH2t'.('R_PROSTGH2t')
    'ER_PROSTGI2t'.('R_PROSTGI2t')
    'ER_PROtm'.('R_PROtm')
    'ER_PSt3'.('R_PSt3')
    'ER_PTDCAt'.('R_PTDCAt')
    'ER_QUILSYN'.('R_QUILSYN')
    'ER_RADH'.('R_RADH')
    'ER_RADH2'.('R_RADH2')
    'ER_RAI1'.('R_RAI1')
    'ER_RAI2'.('R_RAI2')
    'ER_RAtn'.('R_RAtn')
    'ER_RETHe'.('R_RETHe')
    'ER_RETI1'.('R_RETI1')
    'ER_RETI2'.('R_RETI2')
    'ER_RETI3'.('R_RETI3')
    'ER_RETNGLCt2'.('R_RETNGLCt2')
    'ER_RETNGLCt2r'.('R_RETNGLCt2r')
    'ER_RETNt'.('R_RETNt')
    'ER_RETNtr2'.('R_RETNtr2')
    'ER_RIBt'.('R_RIBt')
    'ER_RIBt2'.('R_RIBt2')
    'ER_RTOTAL2t'.('R_RTOTAL2t')
    'ER_RTOTALt'.('R_RTOTALt')
    'ER_Rtotaltl'.('R_Rtotaltl')
    'ER_S2L2FN2M2MASNtly'.('R_S2L2FN2M2MASNtly')
    'ER_S2L2N2M2MASNtly'.('R_S2L2N2M2MASNtly')
    'ER_S2TASE4ly'.('R_S2TASE4ly')
    'ER_S2TASE5ly'.('R_S2TASE5ly')
    'ER_S3TASE1ly'.('R_S3TASE1ly')
    'ER_S3TASE2ly'.('R_S3TASE2ly')
    'ER_S3TASE3ly'.('R_S3TASE3ly')
    'ER_S4T4g'.('R_S4T4g')
    'ER_S4T5g'.('R_S4T5g')
    'ER_Ser_Thrtg'.('R_Ser_Thrtg')
    'ER_SERtp'.('R_SERtp')
    'ER_sink_citr[c]'.('R_sink_citr[c]')
    'ER_sink_pre_prot[r]'.('R_sink_pre_prot[r]')
    'ER_SO4tl'.('R_SO4tl')
    'ER_SPC_HSt'.('R_SPC_HSt')
    'ER_SPH1Pte'.('R_SPH1Pte')
    'ER_SPHINGStl'.('R_SPHINGStl')
    'ER_SPHMYLNtg'.('R_SPHMYLNtg')
    'ER_SPHMYLNtl'.('R_SPHMYLNtl')
    'ER_SPHS1Pte'.('R_SPHS1Pte')
    'ER_SPMDOX'.('R_SPMDOX')
    'ER_STCOAtx'.('R_STCOAtx')
    'ER_STRDNCt'.('R_STRDNCt')
    'ER_SUCCtp'.('R_SUCCtp')
    'ER_T4HCINNMFM'.('R_T4HCINNMFM')
    'ER_TAGAT_Dt'.('R_TAGAT_Dt')
    'ER_TAXOLte'.('R_TAXOLte')
    'ER_TCHOLAte'.('R_TCHOLAte')
    'ER_TDCHOLAte'.('R_TDCHOLAte')
    'ER_TETHEX3COAtx'.('R_TETHEX3COAtx')
    'ER_TETHEX3t'.('R_TETHEX3t')
    'ER_TETPENT3COAtx'.('R_TETPENT3COAtx')
    'ER_TETPENT3t'.('R_TETPENT3t')
    'ER_TETPENT6COAtx'.('R_TETPENT6COAtx')
    'ER_TETPENT6t'.('R_TETPENT6t')
    'ER_TETTET6COAtx'.('R_TETTET6COAtx')
    'ER_TETTET6t'.('R_TETTET6t')
    'ER_THCHOLSTOICtm'.('R_THCHOLSTOICtm')
    'ER_THFtl'.('R_THFtl')
    'ER_THFtm'.('R_THFtm')
    'ER_TMNDNCCOAtx'.('R_TMNDNCCOAtx')
    'ER_TMNDNCt'.('R_TMNDNCt')
    'ER_TRIODTHYSUFt'.('R_TRIODTHYSUFt')
    'ER_TRIOK'.('R_TRIOK')
    'ER_TSTSTERONESte'.('R_TSTSTERONESte')
    'ER_TSTSTERONEt'.('R_TSTSTERONEt')
    'ER_TSTSTERONEtr'.('R_TSTSTERONEtr')
    'ER_TXA2te'.('R_TXA2te')
    'ER_TXA2tr'.('R_TXA2tr')
    'ER_UAGALDP'.('R_UAGALDP')
    'ER_UDPACGALtl'.('R_UDPACGALtl')
    'ER_UDPGLCAtg'.('R_UDPGLCAtg')
    'ER_UDPtl'.('R_UDPtl')
    'ER_UDPXYLter'.('R_UDPXYLter')
    'ER_UMPtr'.('R_UMPtr')
    'ER_URATEt'.('R_URATEt')
    'ER_UROLACer'.('R_UROLACer')
    'ER_UTPtn'.('R_UTPtn')
    'ER_VACCt'.('R_VACCt')
    'ER_VALt5m'.('R_VALt5m')
    'ER_VITD3t'.('R_VITD3t')
    'ER_WHHDCAte'.('R_WHHDCAte')
    'ER_WHTSTSTERONEte'.('R_WHTSTSTERONEte')
    'ER_XOL27OHtm'.('R_XOL27OHtm')
    'ER_XOL7AONEtr'.('R_XOL7AONEtr')
    'ER_XOLEST2te'.('R_XOLEST2te')
    'ER_XOLESTte'.('R_XOLESTte')
    'ER_XOLTRI24te'.('R_XOLTRI24te')
    'ER_XOLTRI27tc'.('R_XOLTRI27tc')
    'ER_XOLTRI27te'.('R_XOLTRI27te')
    'ER_XSERtg'.('R_XSERtg')
    'ER_XYLTD_Dr'.('R_XYLTD_Dr')
    'ER_XYLtly'.('R_XYLtly')
    'ER_XYLTt'.('R_XYLTt')
    'ER_EX_4abutn[e]'.('R_EX_4abutn[e]')
    'ER_EX_acmana[e]'.('R_EX_acmana[e]')
    'ER_EX_ahdt[e]'.('R_EX_ahdt[e]')
    'ER_EX_ctp[e]'.('R_EX_ctp[e]')
    'ER_EX_dgmp[e]'.('R_EX_dgmp[e]')
    'ER_EX_dgtp[e]'.('R_EX_dgtp[e]')
    'ER_EX_dha[e]'.('R_EX_dha[e]')
    'ER_EX_dhap[e]'.('R_EX_dhap[e]')
    'ER_EX_dtmp[e]'.('R_EX_dtmp[e]')
    'ER_EX_dttp[e]'.('R_EX_dttp[e]')
    'ER_EX_fald[e]'.('R_EX_fald[e]')
    'ER_EX_HC01104[e]'.('R_EX_HC01104[e]')
    'ER_EX_HC01361[e]'.('R_EX_HC01361[e]')
    'ER_EX_HC01440[e]'.('R_EX_HC01440[e]')
    'ER_EX_HC01441[e]'.('R_EX_HC01441[e]')
    'ER_EX_HC01444[e]'.('R_EX_HC01444[e]')
    'ER_EX_HC01446[e]'.('R_EX_HC01446[e]')
    'ER_EX_HC01577[e]'.('R_EX_HC01577[e]')
    'ER_EX_HC01700[e]'.('R_EX_HC01700[e]')
    'ER_EX_HC02160[e]'.('R_EX_HC02160[e]')
    'ER_EX_HC02161[e]'.('R_EX_HC02161[e]')
    'ER_EX_itp[e]'.('R_EX_itp[e]')
    'ER_EX_orot[e]'.('R_EX_orot[e]')
    'ER_EX_prpp[e]'.('R_EX_prpp[e]')
    'ER_r0002'.('R_r0002')
    'ER_r0156'.('R_r0156')
    'ER_r0179'.('R_r0179')
    'ER_r0236'.('R_r0236')
    'ER_r0330'.('R_r0330')
    'ER_r0365'.('R_r0365')
    'ER_r0480'.('R_r0480')
    'ER_r0527'.('R_r0527')
    'ER_r0647'.('R_r0647')
    'ER_r0784'.('R_r0784')
    'ER_r0788'.('R_r0788')
    'ER_r0789'.('R_r0789')
    'ER_r0809'.('R_r0809')
    'ER_r0818'.('R_r0818')
    'ER_r0838'.('R_r0838')
    'ER_r0839'.('R_r0839')
    'ER_r0841'.('R_r0841')
    'ER_r0853'.('R_r0853')
    'ER_r0859'.('R_r0859')
    'ER_r0886'.('R_r0886')
    'ER_r0892'.('R_r0892')
    'ER_r0899'.('R_r0899')
    'ER_r0926'.('R_r0926')
    'ER_r0927'.('R_r0927')
    'ER_r0936'.('R_r0936')
    'ER_r0937'.('R_r0937')
    'ER_r0944'.('R_r0944')
    'ER_r0950'.('R_r0950')
    'ER_r0962'.('R_r0962')
    'ER_r0968'.('R_r0968')
    'ER_r0970'.('R_r0970')
    'ER_r0973'.('R_r0973')
    'ER_r0974'.('R_r0974')
    'ER_r0986'.('R_r0986')
    'ER_r0987'.('R_r0987')
    'ER_r0989'.('R_r0989')
    'ER_r0990'.('R_r0990')
    'ER_r0994'.('R_r0994')
    'ER_r1000'.('R_r1000')
    'ER_r1003'.('R_r1003')
    'ER_r1011'.('R_r1011')
    'ER_r1012'.('R_r1012')
    'ER_r1013'.('R_r1013')
    'ER_r1014'.('R_r1014')
    'ER_r1018'.('R_r1018')
    'ER_r1019'.('R_r1019')
    'ER_r1030'.('R_r1030')
    'ER_r1050'.('R_r1050')
    'ER_r1088'.('R_r1088')
    'ER_r1106'.('R_r1106')
    'ER_r1109'.('R_r1109')
    'ER_r1116'.('R_r1116')
    'ER_r1117'.('R_r1117')
    'ER_r1134'.('R_r1134')
    'ER_r1146'.('R_r1146')
    'ER_r1148'.('R_r1148')
    'ER_r1150'.('R_r1150')
    'ER_r1159'.('R_r1159')
    'ER_r1291'.('R_r1291')
    'ER_r1292'.('R_r1292')
    'ER_r1298'.('R_r1298')
    'ER_r1299'.('R_r1299')
    'ER_r1301'.('R_r1301')
    'ER_r1302'.('R_r1302')
    'ER_r1303'.('R_r1303')
    'ER_r1304'.('R_r1304')
    'ER_r1318'.('R_r1318')
    'ER_r1364'.('R_r1364')
    'ER_r1365'.('R_r1365')
    'ER_r1367'.('R_r1367')
    'ER_r1368'.('R_r1368')
    'ER_r1377'.('R_r1377')
    'ER_r1384'.('R_r1384')
    'ER_r1400'.('R_r1400')
    'ER_r1421'.('R_r1421')
    'ER_r1423'.('R_r1423')
    'ER_r1435'.('R_r1435')
    'ER_r1436'.('R_r1436')
    'ER_r1437'.('R_r1437')
    'ER_r1459'.('R_r1459')
    'ER_r1467'.('R_r1467')
    'ER_r1468'.('R_r1468')
    'ER_r1493'.('R_r1493')
    'ER_r1512'.('R_r1512')
    'ER_r2508'.('R_r2508')
    'ER_r2509'.('R_r2509')
    'ER_r2510'.('R_r2510')
    'ER_r2511'.('R_r2511')
    'ER_r2514'.('R_r2514')
    'ER_r2519'.('R_r2519')
    'ER_r2521'.('R_r2521')
    'ER_r2537'.('R_r2537')
    'ER_r2538'.('R_r2538')
    'ER_r2539'.('R_r2539')
    'ER_EX_so3[e]'.('R_EX_so3[e]')
    'ER_EX_sprm[e]'.('R_EX_sprm[e]')
    'ER_RE0124C'.('R_RE0124C')
    'ER_RE0452M'.('R_RE0452M')
    'ER_RE0453C'.('R_RE0453C')
    'ER_RE0570C'.('R_RE0570C')
    'ER_RE0571C'.('R_RE0571C')
    'ER_RE0574C'.('R_RE0574C')
    'ER_RE0575C'.('R_RE0575C')
    'ER_RE0576C'.('R_RE0576C')
    'ER_RE0581C'.('R_RE0581C')
    'ER_RE0583C'.('R_RE0583C')
    'ER_RE0691C'.('R_RE0691C')
    'ER_RE0830C'.('R_RE0830C')
    'ER_RE0908C'.('R_RE0908C')
    'ER_RE0915C'.('R_RE0915C')
    'ER_RE0916C'.('R_RE0916C')
    'ER_RE0918C'.('R_RE0918C')
    'ER_RE0958C'.('R_RE0958C')
    'ER_RE1234C'.('R_RE1234C')
    'ER_RE1303C'.('R_RE1303C')
    'ER_RE1342C'.('R_RE1342C')
    'ER_RE1447N'.('R_RE1447N')
    'ER_RE1448N'.('R_RE1448N')
    'ER_RE1530C'.('R_RE1530C')
    'ER_RE1711C'.('R_RE1711C')
    'ER_RE1804C'.('R_RE1804C')
    'ER_RE1807C'.('R_RE1807C')
    'ER_RE1826C'.('R_RE1826C')
    'ER_RE1836C'.('R_RE1836C')
    'ER_RE1897C'.('R_RE1897C')
    'ER_RE1898C'.('R_RE1898C')
    'ER_RE1915C'.('R_RE1915C')
    'ER_RE1916C'.('R_RE1916C')
    'ER_RE1919C'.('R_RE1919C')
    'ER_RE1921C'.('R_RE1921C')
    'ER_RE1978C'.('R_RE1978C')
    'ER_RE2069C'.('R_RE2069C')
    'ER_RE2080C'.('R_RE2080C')
    'ER_RE2112C'.('R_RE2112C')
    'ER_RE2235C'.('R_RE2235C')
    'ER_RE2327C'.('R_RE2327C')
    'ER_RE2407C'.('R_RE2407C')
    'ER_RE2410C'.('R_RE2410C')
    'ER_RE2426C'.('R_RE2426C')
    'ER_RE2526C'.('R_RE2526C')
    'ER_RE2562C'.('R_RE2562C')
    'ER_RE2563C'.('R_RE2563C')
    'ER_RE2625C'.('R_RE2625C')
    'ER_RE2626C'.('R_RE2626C')
    'ER_RE2655R'.('R_RE2655R')
    'ER_RE2659R'.('R_RE2659R')
    'ER_RE2666C'.('R_RE2666C')
    'ER_RE2677C'.('R_RE2677C')
    'ER_RE2677N'.('R_RE2677N')
    'ER_RE2799C'.('R_RE2799C')
    'ER_RE2814R'.('R_RE2814R')
    'ER_RE2974N'.('R_RE2974N')
    'ER_RE3011R'.('R_RE3011R')
    'ER_RE3016R'.('R_RE3016R')
    'ER_RE3017R'.('R_RE3017R')
    'ER_RE3033C'.('R_RE3033C')
    'ER_RE3044C'.('R_RE3044C')
    'ER_RE3050R'.('R_RE3050R')
    'ER_RE3052C'.('R_RE3052C')
    'ER_RE3073X'.('R_RE3073X')
    'ER_RE3104C'.('R_RE3104C')
    'ER_RE3106C'.('R_RE3106C')
    'ER_RE3112C'.('R_RE3112C')
    'ER_RE3113C'.('R_RE3113C')
    'ER_RE3119C'.('R_RE3119C')
    'ER_RE3121C'.('R_RE3121C')
    'ER_RE3122C'.('R_RE3122C')
    'ER_RE3152C'.('R_RE3152C')
    'ER_RE3153C'.('R_RE3153C')
    'ER_RE3154C'.('R_RE3154C')
    'ER_RE3162C'.('R_RE3162C')
    'ER_RE3163C'.('R_RE3163C')
    'ER_RE3164C'.('R_RE3164C')
    'ER_RE3166C'.('R_RE3166C')
    'ER_RE3167C'.('R_RE3167C')
    'ER_RE3168C'.('R_RE3168C')
    'ER_RE3169C'.('R_RE3169C')
    'ER_RE3171C'.('R_RE3171C')
    'ER_RE3172C'.('R_RE3172C')
    'ER_RE3173C'.('R_RE3173C')
    'ER_RE3175C'.('R_RE3175C')
    'ER_RE3176C'.('R_RE3176C')
    'ER_RE3180C'.('R_RE3180C')
    'ER_RE3181C'.('R_RE3181C')
    'ER_RE3227C'.('R_RE3227C')
    'ER_RE3228C'.('R_RE3228C')
    'ER_RE3229C'.('R_RE3229C')
    'ER_RE3230C'.('R_RE3230C')
    'ER_RE3231C'.('R_RE3231C')
    'ER_RE3232C'.('R_RE3232C')
    'ER_RE3234C'.('R_RE3234C')
    'ER_RE3235C'.('R_RE3235C')
    'ER_RE3236C'.('R_RE3236C')
    'ER_RE3237C'.('R_RE3237C')
    'ER_RE3238C'.('R_RE3238C')
    'ER_RE3239C'.('R_RE3239C')
    'ER_RE3242C'.('R_RE3242C')
    'ER_RE3243C'.('R_RE3243C')
    'ER_RE3244C'.('R_RE3244C')
    'ER_RE3245C'.('R_RE3245C')
    'ER_RE3267E'.('R_RE3267E')
    'ER_RE3270C'.('R_RE3270C')
    'ER_RE3272N'.('R_RE3272N')
    'ER_RE3286C'.('R_RE3286C')
    'ER_RE3288C'.('R_RE3288C')
    'ER_RE3347C'.('R_RE3347C')
    'ER_RE3352C'.('R_RE3352C')
    'ER_RE3422C'.('R_RE3422C')
    'ER_RE3430M'.('R_RE3430M')
    'ER_RE3430X'.('R_RE3430X')
    'ER_RE3434C'.('R_RE3434C')
    'ER_RE3435C'.('R_RE3435C')
    'ER_RE3436C'.('R_RE3436C')
    'ER_RE3437C'.('R_RE3437C')
    'ER_RE3475C'.('R_RE3475C')
    'ER_RE3485C'.('R_RE3485C')
    'ER_RE3493C'.('R_RE3493C')
    'ER_RE3496C'.('R_RE3496C')
    'ER_RE3513C'.('R_RE3513C')
    'ER_RE3513R'.('R_RE3513R')
    'ER_RE3525M'.('R_RE3525M')
    'ER_RE3526M'.('R_RE3526M')
    'ER_RE3556C'.('R_RE3556C')
    'ER_RE3565C'.('R_RE3565C')
    'ER_RE3566C'.('R_RE3566C')
    'ER_RE3567C'.('R_RE3567C')
    'ER_RE3568C'.('R_RE3568C')
    'ER_RE3570C'.('R_RE3570C')
    'ER_RE3587C'.('R_RE3587C')
    'ER_RE3637C'.('R_RE3637C')
    'ER_EX_prostgh2[e]'.('R_EX_prostgh2[e]')
    'ER_EX_prostgi2[e]'.('R_EX_prostgi2[e]')
    'ER_EX_cdp[e]'.('R_EX_cdp[e]')
    'ER_EX_dtdp[e]'.('R_EX_dtdp[e]')
    'ER_EX_HC00955[e]'.('R_EX_HC00955[e]')
    'ER_EX_citr_L[e]'.('R_EX_citr_L[e]')
    'ER_EX_C02470[e]'.('R_EX_C02470[e]')
    'ER_EX_C02528[e]'.('R_EX_C02528[e]')
    'ER_EX_HC02195[e]'.('R_EX_HC02195[e]')
    'ER_EX_HC02196[e]'.('R_EX_HC02196[e]')
    'ER_EX_HC02220[e]'.('R_EX_HC02220[e]')
    'ER_EX_HC02191[e]'.('R_EX_HC02191[e]')
    'ER_EX_HC02194[e]'.('R_EX_HC02194[e]')
    'ER_EX_HC02197[e]'.('R_EX_HC02197[e]')
    'ER_EX_HC02198[e]'.('R_EX_HC02198[e]')
    'ER_EX_HC02187[e]'.('R_EX_HC02187[e]')
    'ER_EX_HC02180[e]'.('R_EX_HC02180[e]')
    'ER_EX_HC02202[e]'.('R_EX_HC02202[e]')
    'ER_EX_HC02203[e]'.('R_EX_HC02203[e]')
    'ER_EX_HC02204[e]'.('R_EX_HC02204[e]')
    'ER_EX_HC02205[e]'.('R_EX_HC02205[e]')
    'ER_EX_HC02206[e]'.('R_EX_HC02206[e]')
    'ER_EX_HC02207[e]'.('R_EX_HC02207[e]')
    'ER_EX_HC02213[e]'.('R_EX_HC02213[e]')
    'ER_EX_HC02217[e]'.('R_EX_HC02217[e]')
    'ER_EX_maltpt[e]'.('R_EX_maltpt[e]')
    'ER_EX_CE2915[e]'.('R_EX_CE2915[e]')
    'ER_EX_CE4722[e]'.('R_EX_CE4722[e]')
    'ER_EX_CE2916[e]'.('R_EX_CE2916[e]')
    'ER_EX_CE4723[e]'.('R_EX_CE4723[e]')
    'ER_EX_CE2917[e]'.('R_EX_CE2917[e]')
    'ER_EX_CE4724[e]'.('R_EX_CE4724[e]')
    'ER_EX_malthp[e]'.('R_EX_malthp[e]')
    'ER_EX_CE2839[e]'.('R_EX_CE2839[e]')
    'ER_EX_CE2838[e]'.('R_EX_CE2838[e]')
    'ER_EX_CE1950[e]'.('R_EX_CE1950[e]')
    'ER_EX_cynt[e]'.('R_EX_cynt[e]')
    'ER_EX_CE5786[e]'.('R_EX_CE5786[e]')
    'ER_EX_CE5788[e]'.('R_EX_CE5788[e]')
    'ER_EX_CE5789[e]'.('R_EX_CE5789[e]')
    'ER_EX_CE5797[e]'.('R_EX_CE5797[e]')
    'ER_EX_CE5798[e]'.('R_EX_CE5798[e]')
    'ER_EX_CE5867[e]'.('R_EX_CE5867[e]')
    'ER_EX_CE5868[e]'.('R_EX_CE5868[e]')
    'ER_EX_CE5869[e]'.('R_EX_CE5869[e]')
    'ER_EX_CE4633[e]'.('R_EX_CE4633[e]')
    'ER_EX_CE4881[e]'.('R_EX_CE4881[e]')
    'ER_EX_crm_hs[e]'.('R_EX_crm_hs[e]')
    'ER_EX_CE0074[e]'.('R_EX_CE0074[e]')
    'ER_EX_cdpea[e]'.('R_EX_cdpea[e]')
    'ER_EX_12dgr120[e]'.('R_EX_12dgr120[e]')
    'ER_biomass_reaction'.('R_biomass_reaction')
    'ER_ADPACDAc'.('R_ADPACDAc')
    'ER_ADPACtx'.('R_ADPACtx')
    'ER_BCRNe'.('R_BCRNe')
    'ER_sink_c101coa[c]'.('R_sink_c101coa[c]')
    'ER_C101CRNe'.('R_C101CRNe')
    'ER_C10CRNe'.('R_C10CRNe')
    'ER_C12DCACT'.('R_C12DCACT')
    'ER_C12DCe'.('R_C12DCe')
    'ER_C16DCe'.('R_C16DCe')
    'ER_C3DCe'.('R_C3DCe')
    'ER_C4CRNe'.('R_C4CRNe')
    'ER_C4DCe'.('R_C4DCe')
    'ER_C6CRNe'.('R_C6CRNe')
    'ER_sink_c81coa[c]'.('R_sink_c81coa[c]')
    'ER_C81CRNe'.('R_C81CRNe')
    'ER_C8CRNe'.('R_C8CRNe')
    'ER_C8DCe'.('R_C8DCe')
    'ER_sink_dd2coa[c]'.('R_sink_dd2coa[c]')
    'ER_DDCRNe'.('R_DDCRNe')
    'ER_DDECCRNe'.('R_DDECCRNe')
    'ER_DDECE1CRNe'.('R_DDECE1CRNe')
    'ER_DECCRNe'.('R_DECCRNe')
    'ER_sink_decdicoa[c]'.('R_sink_decdicoa[c]')
    'ER_DECDICRNe'.('R_DECDICRNe')
    'ER_DOCOSACTDe'.('R_DOCOSACTDe')
    'ER_DOCOSACTDr'.('R_DOCOSACTDr')
    'ER_EX_3bcrn[e]'.('R_EX_3bcrn[e]')
    'ER_EX_3ddcrn[e]'.('R_EX_3ddcrn[e]')
    'ER_EX_3deccrn[e]'.('R_EX_3deccrn[e]')
    'ER_EX_3octdec2crn[e]'.('R_EX_3octdec2crn[e]')
    'ER_EX_3octdece1crn[e]'.('R_EX_3octdece1crn[e]')
    'ER_EX_3tdcrn[e]'.('R_EX_3tdcrn[e]')
    'ER_EX_c101crn[e]'.('R_EX_c101crn[e]')
    'ER_EX_c10crn[e]'.('R_EX_c10crn[e]')
    'ER_EX_c12dc[e]'.('R_EX_c12dc[e]')
    'ER_EX_c16dc[e]'.('R_EX_c16dc[e]')
    'ER_EX_c3dc[e]'.('R_EX_c3dc[e]')
    'ER_EX_c4crn[e]'.('R_EX_c4crn[e]')
    'ER_EX_c4dc[e]'.('R_EX_c4dc[e]')
    'ER_EX_c51crn[e]'.('R_EX_c51crn[e]')
    'ER_EX_c6crn[e]'.('R_EX_c6crn[e]')
    'ER_EX_c81crn[e]'.('R_EX_c81crn[e]')
    'ER_EX_c8crn[e]'.('R_EX_c8crn[e]')
    'ER_EX_c8dc[e]'.('R_EX_c8dc[e]')
    'ER_EX_ddece1crn[e]'.('R_EX_ddece1crn[e]')
    'ER_EX_ddecrn[e]'.('R_EX_ddecrn[e]')
    'ER_EX_decdicrn[e]'.('R_EX_decdicrn[e]')
    'ER_EX_doco13ac[e]'.('R_EX_doco13ac[e]')
    'ER_EX_docosac[e]'.('R_EX_docosac[e]')
    'ER_EX_tetdec2crn[e]'.('R_EX_tetdec2crn[e]')
    'ER_EX_tetdece1crn[e]'.('R_EX_tetdece1crn[e]')
    'ER_EX_dca[e]'.('R_EX_dca[e]')
    'ER_FAOXC5C5OHm'.('R_FAOXC5C5OHm')
    'ER_HEXDIACtr'.('R_HEXDIACtr')
    'ER_HOCTDEC2CRNe'.('R_HOCTDEC2CRNe')
    'ER_HTDCRNe'.('R_HTDCRNe')
    'ER_OCTDECE1CRNe'.('R_OCTDECE1CRNe')
    'ER_sink_octdececoa[c]'.('R_sink_octdececoa[c]')
    'ER_SEBACACT'.('R_SEBACACT')
    'ER_SEBACIDtx'.('R_SEBACIDtx')
    'ER_SUBEACtx'.('R_SUBEACtx')
    'ER_SUBERICACT'.('R_SUBERICACT')
    'ER_SUCCACT'.('R_SUCCACT')
    'ER_TDCRNe'.('R_TDCRNe')
    'ER_sink_tetdec2coa[c]'.('R_sink_tetdec2coa[c]')
    'ER_TETDEC2CRNe'.('R_TETDEC2CRNe')
    'ER_sink_tetdece1coa[c]'.('R_sink_tetdece1coa[c]')
    'ER_TETDECE1CRNe'.('R_TETDECE1CRNe')
    'ER_TIGCRNe'.('R_TIGCRNe')
    'ER_BTNTe'.('R_BTNTe')
    'ER_SBTle'.('R_SBTle')
    'ER_1a25DHVITD3TRn'.('R_1a25DHVITD3TRn')
    'ER_3AIB_Dtm'.('R_3AIB_Dtm')
    'ER_5MTHFt2le'.('R_5MTHFt2le')
    'ER_ADNK4'.('R_ADNK4')
    'ER_AHCYStd'.('R_AHCYStd')
    'ER_ALA-DTDe'.('R_ALA-DTDe')
    'ER_AMETtd'.('R_AMETtd')
    'ER_ARACHFATPc'.('R_ARACHFATPc')
    'ER_ASPDTDe'.('R_ASPDTDe')
    'ER_ASPte'.('R_ASPte')
    'ER_CHSTEROLtrc'.('R_CHSTEROLtrc')
    'ER_CRNrtx'.('R_CRNrtx')
    'ER_Coqe'.('R_Coqe')
    'ER_DATPtm'.('R_DATPtm')
    'ER_DCTPtm'.('R_DCTPtm')
    'ER_DGTPtm'.('R_DGTPtm')
    'ER_DHAPtc'.('R_DHAPtc')
    'ER_DM_1a25dhvitd3[n]'.('R_DM_1a25dhvitd3[n]')
    'ER_DM_taur[c]'.('R_DM_taur[c]')
    'ER_DM_pmtcoa[r]'.('R_DM_pmtcoa[r]')
    'ER_DTTPtm'.('R_DTTPtm')
    'ER_EX_4hpro[e]'.('R_EX_4hpro[e]')
    'ER_EX_carn[e]'.('R_EX_carn[e]')
    'ER_EX_dchac[e]'.('R_EX_dchac[e]')
    'ER_EX_sfcys[e]'.('R_EX_sfcys[e]')
    'ER_EX_cysam[e]'.('R_EX_cysam[e]')
    'ER_EX_fmn[e]'.('R_EX_fmn[e]')
    'ER_EX_oh1[e]'.('R_EX_oh1[e]')
    'ER_EX_ptth[e]'.('R_EX_ptth[e]')
    'ER_EX_q10[e]'.('R_EX_q10[e]')
    'ER_EX_q10h2[e]'.('R_EX_q10h2[e]')
    'ER_FOLt2le'.('R_FOLt2le')
    'ER_FRDPtcr'.('R_FRDPtcr')
    'ER_GLU5SAtmc'.('R_GLU5SAtmc')
    'ER_GLYC3PFADm'.('R_GLYC3PFADm')
    'ER_GLYCTDle'.('R_GLYCTDle')
    'ER_INSK'.('R_INSK')
    'ER_KHte'.('R_KHte')
    'ER_LACLt'.('R_LACLt')
    'ER_MAL_Ltx'.('R_MAL_Ltx')
    'ER_MDHx'.('R_MDHx')
    'ER_NADtm'.('R_NADtm')
    'ER_NADtx'.('R_NADtx')
    'ER_PNTEHe'.('R_PNTEHe')
    'ER_PPItm'.('R_PPItm')
    'ER_PRO_Dtde'.('R_PRO_Dtde')
    'ER_PTCRTD'.('R_PTCRTD')
    'ER_Q10H2e'.('R_Q10H2e')
    'ER_SFCYSc'.('R_SFCYSc')
    'ER_SFCYSe'.('R_SFCYSe')
    'ER_sink_5hpet[c]'.('R_sink_5hpet[c]')
    'ER_TAURCHAe'.('R_TAURCHAe')
    'ER_TTDCAFATPc'.('R_TTDCAFATPc')
    'ER_q10h2tc'.('R_q10h2tc')
    'ER_q10tm'.('R_q10tm')
    'ER_34HPPte'.('R_34HPPte')
    'ER_3MOBte'.('R_3MOBte')
    'ER_3MOPte'.('R_3MOPte')
    'ER_4MOPte'.('R_4MOPte')
    'ER_5MTAte'.('R_5MTAte')
    'ER_AHCYSte'.('R_AHCYSte')
    'ER_AICARte'.('R_AICARte')
    'ER_CBASPte'.('R_CBASPte')
    'ER_DM_4hrpo'.('R_DM_4hrpo')
    'ER_DM_Lcystin'.('R_DM_Lcystin')
    'ER_DM_fol'.('R_DM_fol')
    'ER_DM_pnto_R'.('R_DM_pnto_R')
    'ER_EX_34hpp[e]'.('R_EX_34hpp[e]')
    'ER_EX_3mob[e]'.('R_EX_3mob[e]')
    'ER_EX_3mop[e]'.('R_EX_3mop[e]')
    'ER_EX_4mop[e]'.('R_EX_4mop[e]')
    'ER_EX_5mta[e]'.('R_EX_5mta[e]')
    'ER_EX_ahcys[e]'.('R_EX_ahcys[e]')
    'ER_EX_aicar[e]'.('R_EX_aicar[e]')
    'ER_EX_cbasp[e]'.('R_EX_cbasp[e]')
    'ER_MAL_Lte'.('R_MAL_Lte')
    'ER_IDOURte'.('R_IDOURte')
    'ER_EX_idour[e]'.('R_EX_idour[e]')
    'ER_GLYALDtr'.('R_GLYALDtr')
    'ER_PEPtr'.('R_PEPtr')
    'ER_GUDACtr'.('R_GUDACtr')
    'ER_GUDACtr2'.('R_GUDACtr2')
    'ER_KYNATEtr2'.('R_KYNATEtr2')
    'ER_3ANTHRNtr'.('R_3ANTHRNtr')
    'ER_2PGtr'.('R_2PGtr')
    'ER_CARNtr'.('R_CARNtr')
    'ER_CHOLPtr'.('R_CHOLPtr')
    'ER_DCMPtr'.('R_DCMPtr')
    'ER_DHAPtr'.('R_DHAPtr')
    'ER_ETHAMPtr'.('R_ETHAMPtr')
    'ER_FUMtr'.('R_FUMtr')
    'ER_GLCURtr'.('R_GLCURtr')
    'ER_ICITtr'.('R_ICITtr')
    'ER_L2AADPtr'.('R_L2AADPtr')
    'ER_XANtr'.('R_XANtr')
    'ER_XMPtr'.('R_XMPtr')
    'ER_XTSNtr'.('R_XTSNtr')
    'ER_3PGtr'.('R_3PGtr')
    'ER_UDPGLCURtr'.('R_UDPGLCURtr')
    'ER_IMPtr'.('R_IMPtr')
    'ER_GLYC3tr'.('R_GLYC3tr')
    'ER_NICRNtr'.('R_NICRNtr')
    'ER_OROT5Ptr'.('R_OROT5Ptr')
    'ER_EX_2pg[e]'.('R_EX_2pg[e]')
    'ER_EX_5hoxindoa[e]'.('R_EX_5hoxindoa[e]')
    'ER_EX_cholp[e]'.('R_EX_cholp[e]')
    'ER_EX_dcmp[e]'.('R_EX_dcmp[e]')
    'ER_EX_ethamp[e]'.('R_EX_ethamp[e]')
    'ER_EX_glyald[e]'.('R_EX_glyald[e]')
    'ER_EX_gudac[e]'.('R_EX_gudac[e]')
    'ER_EX_hcys_L[e]'.('R_EX_hcys_L[e]')
    'ER_EX_icit[e]'.('R_EX_icit[e]')
    'ER_EX_kynate[e]'.('R_EX_kynate[e]')
    'ER_EX_L2aadp[e]'.('R_EX_L2aadp[e]')
    'ER_EX_Lkynr[e]'.('R_EX_Lkynr[e]')
    'ER_EX_pep[e]'.('R_EX_pep[e]')
    'ER_EX_xmp[e]'.('R_EX_xmp[e]')
    'ER_EX_xtsn[e]'.('R_EX_xtsn[e]')
    'ER_EX_3pg[e]'.('R_EX_3pg[e]')
    'ER_EX_3hanthrn[e]'.('R_EX_3hanthrn[e]')
    'ER_EX_udpglcur[e]'.('R_EX_udpglcur[e]')
    'ER_EX_nicrnt[e]'.('R_EX_nicrnt[e]')
    'ER_EX_orot5p[e]'.('R_EX_orot5p[e]')
    'ER_EX_glyc3p[e]'.('R_EX_glyc3p[e]')
    'ER_ARGSUCte'.('R_ARGSUCte')
    'ER_EX_argsuc[e]'.('R_EX_argsuc[e]')
    'ER_EX_acrn[e]'.('R_EX_acrn[e]')
    'ER_EX_pcrn[e]'.('R_EX_pcrn[e]')
    'ER_EX_lneldccrn[e]'.('R_EX_lneldccrn[e]')
    'ER_EX_odecrn[e]'.('R_EX_odecrn[e]')
    'ER_EX_stcrn[e]'.('R_EX_stcrn[e]')
    'ER_EX_pmtcrn[e]'.('R_EX_pmtcrn[e]')
    'ER_EX_hdcecrn[e]'.('R_EX_hdcecrn[e]')
    'ER_DM_ascb_L[c]'.('R_DM_ascb_L[c]')
    'ER_biomass_maintenance_noTrTr'.('R_biomass_maintenance_noTrTr')
    'ER_ADPOHc'.('R_ADPOHc')
    'ER_PHLAC'.('R_PHLAC')
    'ER_3MHISc'.('R_3MHISc')
    'ER_HMCRNc'.('R_HMCRNc')
    'ER_CE4843HYDc'.('R_CE4843HYDc')
    'ER_HXCOAc'.('R_HXCOAc')
    'ER_HDCAc'.('R_HDCAc')
    'ER_ELAIDCRNte'.('R_ELAIDCRNte')
    'ER_LNLCCRNNAt'.('R_LNLCCRNNAt')
    'ER_PHLACHt'.('R_PHLACHt')
    'ER_TTDCRNNAt'.('R_TTDCRNNAt')
    'ER_15HPETATP'.('R_15HPETATP')
    'ER_15KPROSTGF2t'.('R_15KPROSTGF2t')
    'ER_2OXOADPt'.('R_2OXOADPt')
    'ER_34HPLte'.('R_34HPLte')
    'ER_3HMPtd'.('R_3HMPtd')
    'ER_3HPPt'.('R_3HPPt')
    'ER_3MHISt1'.('R_3MHISt1')
    'ER_3MHISt2'.('R_3MHISt2')
    'ER_3MHISt3'.('R_3MHISt3')
    'ER_3MOXTYRt'.('R_3MOXTYRt')
    'ER_3UIBtd'.('R_3UIBtd')
    'ER_4TMEABUTNt1'.('R_4TMEABUTNt1')
    'ER_4TMEABUTNt2'.('R_4TMEABUTNt2')
    'ER_56DTHMt'.('R_56DTHMt')
    'ER_56DTHMtd'.('R_56DTHMtd')
    'ER_56DURAt'.('R_56DURAt')
    'ER_56DURAtd'.('R_56DURAtd')
    'ER_5AOPt'.('R_5AOPt')
    'ER_7DHCHSTEROLtd'.('R_7DHCHSTEROLtd')
    'ER_ACGLUtd'.('R_ACGLUtd')
    'ER_ACLYSt'.('R_ACLYSt')
    'ER_ACLYStm'.('R_ACLYStm')
    'ER_ADPACtd'.('R_ADPACtd')
    'ER_ADPOHt'.('R_ADPOHt')
    'ER_ALLTNt'.('R_ALLTNt')
    'ER_C02712tm'.('R_C02712tm')
    'ER_C03990tr'.('R_C03990tr')
    'ER_C04483t2'.('R_C04483t2')
    'ER_C04717td'.('R_C04717td')
    'ER_C04805td'.('R_C04805td')
    'ER_C05463t2'.('R_C05463t2')
    'ER_C05953t'.('R_C05953t')
    'ER_C05957t'.('R_C05957t')
    'ER_C05957td'.('R_C05957td')
    'ER_C06314t'.('R_C06314t')
    'ER_C06315t'.('R_C06315t')
    'ER_C06439t'.('R_C06439t')
    'ER_C11695td'.('R_C11695td')
    'ER_C14768td'.('R_C14768td')
    'ER_C14769td1'.('R_C14769td1')
    'ER_EX_C14769[e]'.('R_EX_C14769[e]')
    'ER_C14770ATP'.('R_C14770ATP')
    'ER_C14771ATP'.('R_C14771ATP')
    'ER_C14825td'.('R_C14825td')
    'ER_C14826td'.('R_C14826td')
    'ER_CE1273t2'.('R_CE1273t2')
    'ER_CE2510t'.('R_CE2510t')
    'ER_CE2513td'.('R_CE2513td')
    'ER_CE2537ATP'.('R_CE2537ATP')
    'ER_CE4843td'.('R_CE4843td')
    'ER_CE5304t'.('R_CE5304t')
    'ER_CE6247t'.('R_CE6247t')
    'ER_DODECANACtd'.('R_DODECANACtd')
    'ER_ELAIDCRNtd'.('R_ELAIDCRNtd')
    'ER_EX_12HPET[e]'.('R_EX_12HPET[e]')
    'ER_EX_15HPET[e]'.('R_EX_15HPET[e]')
    'ER_EX_15kprostgf2[e]'.('R_EX_15kprostgf2[e]')
    'ER_EX_2oxoadp[e]'.('R_EX_2oxoadp[e]')
    'ER_EX_34hpl[e]'.('R_EX_34hpl[e]')
    'ER_EX_3hmp[e]'.('R_EX_3hmp[e]')
    'ER_EX_3hpp[e]'.('R_EX_3hpp[e]')
    'ER_EX_3mhis[e]'.('R_EX_3mhis[e]')
    'ER_EX_3uib[e]'.('R_EX_3uib[e]')
    'ER_EX_4tmeabutn[e]'.('R_EX_4tmeabutn[e]')
    'ER_EX_56dthm[e]'.('R_EX_56dthm[e]')
    'ER_EX_56dura[e]'.('R_EX_56dura[e]')
    'ER_EX_7dhchsterol[e]'.('R_EX_7dhchsterol[e]')
    'ER_EX_aclys[e]'.('R_EX_aclys[e]')
    'ER_EX_adpac[e]'.('R_EX_adpac[e]')
    'ER_EX_adpoh[e]'.('R_EX_adpoh[e]')
    'ER_EX_amet[e]'.('R_EX_amet[e]')
    'ER_EX_aracheth[e]'.('R_EX_aracheth[e]')
    'ER_EX_C04717[e]'.('R_EX_C04717[e]')
    'ER_EX_C04805[e]'.('R_EX_C04805[e]')
    'ER_EX_C05957[e]'.('R_EX_C05957[e]')
    'ER_EX_C06314[e]'.('R_EX_C06314[e]')
    'ER_EX_C06315[e]'.('R_EX_C06315[e]')
    'ER_EX_C11695[e]'.('R_EX_C11695[e]')
    'ER_EX_C14768[e]'.('R_EX_C14768[e]')
    'ER_EX_C14770[e]'.('R_EX_C14770[e]')
    'ER_EX_C14771[e]'.('R_EX_C14771[e]')
    'ER_EX_C14825[e]'.('R_EX_C14825[e]')
    'ER_EX_C14826[e]'.('R_EX_C14826[e]')
    'ER_EX_CE2537[e]'.('R_EX_CE2537[e]')
    'ER_EX_CE4843[e]'.('R_EX_CE4843[e]')
    'ER_EX_CE5304[e]'.('R_EX_CE5304[e]')
    'ER_EX_CE6247[e]'.('R_EX_CE6247[e]')
    'ER_EX_CE7172[e]'.('R_EX_CE7172[e]')
    'ER_EX_didecaeth[e]'.('R_EX_didecaeth[e]')
    'ER_EX_diholineth[e]'.('R_EX_diholineth[e]')
    'ER_EX_docohxeth[e]'.('R_EX_docohxeth[e]')
    'ER_EX_docteteth[e]'.('R_EX_docteteth[e]')
    'ER_EX_dodecanac[e]'.('R_EX_dodecanac[e]')
    'ER_EX_elaidcrn[e]'.('R_EX_elaidcrn[e]')
    'ER_EX_forglu[e]'.('R_EX_forglu[e]')
    'ER_EX_HC00900[e]'.('R_EX_HC00900[e]')
    'ER_EX_hepdeceth[e]'.('R_EX_hepdeceth[e]')
    'ER_EX_hexdeceeth[e]'.('R_EX_hexdeceeth[e]')
    'ER_EX_hexdiac[e]'.('R_EX_hexdiac[e]')
    'ER_EX_hgentis[e]'.('R_EX_hgentis[e]')
    'ER_EX_hmcr[e]'.('R_EX_hmcr[e]')
    'ER_EX_hxcoa[e]'.('R_EX_hxcoa[e]')
    'ER_EX_leuktrB4wcooh[e]'.('R_EX_leuktrB4wcooh[e]')
    'ER_EX_leuktrB4woh[e]'.('R_EX_leuktrB4woh[e]')
    'ER_EX_lineth[e]'.('R_EX_lineth[e]')
    'ER_EX_lnlccrn[e]'.('R_EX_lnlccrn[e]')
    'ER_EX_lthstrl[e]'.('R_EX_lthstrl[e]')
    'ER_EX_mev_R[e]'.('R_EX_mev_R[e]')
    'ER_EX_mi1p_D[e]'.('R_EX_mi1p_D[e]')
    'ER_EX_nwharg[e]'.('R_EX_nwharg[e]')
    'ER_EX_oleth[e]'.('R_EX_oleth[e]')
    'ER_EX_pailar_hs[e]'.('R_EX_pailar_hs[e]')
    'ER_EX_pailpalm_hs[e]'.('R_EX_pailpalm_hs[e]')
    'ER_EX_pchol2linl_hs[e]'.('R_EX_pchol2linl_hs[e]')
    'ER_EX_pchol2ole_hs[e]'.('R_EX_pchol2ole_hs[e]')
    'ER_EX_pchol2palm_hs[e]'.('R_EX_pchol2palm_hs[e]')
    'ER_EX_pchol2ste_hs[e]'.('R_EX_pchol2ste_hs[e]')
    'ER_EX_pcholar_hs[e]'.('R_EX_pcholar_hs[e]')
    'ER_EX_pcholdoc_hs[e]'.('R_EX_pcholdoc_hs[e]')
    'ER_EX_pcholeic_hs[e]'.('R_EX_pcholeic_hs[e]')
    'ER_EX_pcholet_hs[e]'.('R_EX_pcholet_hs[e]')
    'ER_EX_pcholhep_hs[e]'.('R_EX_pcholhep_hs[e]')
    'ER_EX_pchollinl_hs[e]'.('R_EX_pchollinl_hs[e]')
    'ER_EX_pcholmyr_hs[e]'.('R_EX_pcholmyr_hs[e]')
    'ER_EX_pcholn15_hs[e]'.('R_EX_pcholn15_hs[e]')
    'ER_EX_pcholn183_hs[e]'.('R_EX_pcholn183_hs[e]')
    'ER_EX_pcholn1836_hs[e]'.('R_EX_pcholn1836_hs[e]')
    'ER_EX_pcholn19_hs[e]'.('R_EX_pcholn19_hs[e]')
    'ER_EX_pcholn201_hs[e]'.('R_EX_pcholn201_hs[e]')
    'ER_EX_pcholn203_hs[e]'.('R_EX_pcholn203_hs[e]')
    'ER_EX_pcholn204_hs[e]'.('R_EX_pcholn204_hs[e]')
    'ER_EX_pcholn205_hs[e]'.('R_EX_pcholn205_hs[e]')
    'ER_EX_pcholn224_hs[e]'.('R_EX_pcholn224_hs[e]')
    'ER_EX_pcholn225_hs[e]'.('R_EX_pcholn225_hs[e]')
    'ER_EX_pcholn2254_hs[e]'.('R_EX_pcholn2254_hs[e]')
    'ER_EX_pcholn226_hs[e]'.('R_EX_pcholn226_hs[e]')
    'ER_EX_pcholn24_hs[e]'.('R_EX_pcholn24_hs[e]')
    'ER_EX_pcholn261_hs[e]'.('R_EX_pcholn261_hs[e]')
    'ER_EX_pcholn28_hs[e]'.('R_EX_pcholn28_hs[e]')
    'ER_EX_pcholn281_hs[e]'.('R_EX_pcholn281_hs[e]')
    'ER_EX_pcholole_hs[e]'.('R_EX_pcholole_hs[e]')
    'ER_EX_pcholpalm_hs[e]'.('R_EX_pcholpalm_hs[e]')
    'ER_EX_pcholpalme_hs[e]'.('R_EX_pcholpalme_hs[e]')
    'ER_EX_pcholste_hs[e]'.('R_EX_pcholste_hs[e]')
    'ER_EX_pcollg5hlys[e]'.('R_EX_pcollg5hlys[e]')
    'ER_EX_pe12_hs[e]'.('R_EX_pe12_hs[e]')
    'ER_EX_pe13_hs[e]'.('R_EX_pe13_hs[e]')
    'ER_EX_pe14_hs[e]'.('R_EX_pe14_hs[e]')
    'ER_EX_pe15_hs[e]'.('R_EX_pe15_hs[e]')
    'ER_EX_pe161_hs[e]'.('R_EX_pe161_hs[e]')
    'ER_EX_pe17_hs[e]'.('R_EX_pe17_hs[e]')
    'ER_EX_pe203_hs[e]'.('R_EX_pe203_hs[e]')
    'ER_EX_pe224_hs[e]'.('R_EX_pe224_hs[e]')
    'ER_EX_pe226_hs[e]'.('R_EX_pe226_hs[e]')
    'ER_EX_pe2linl_hs[e]'.('R_EX_pe2linl_hs[e]')
    'ER_EX_pear_hs[e]'.('R_EX_pear_hs[e]')
    'ER_EX_pedh203_hs[e]'.('R_EX_pedh203_hs[e]')
    'ER_EX_pelinl_hs[e]'.('R_EX_pelinl_hs[e]')
    'ER_EX_pendecaeth[e]'.('R_EX_pendecaeth[e]')
    'ER_EX_peole_hs[e]'.('R_EX_peole_hs[e]')
    'ER_EX_pepalm_hs[e]'.('R_EX_pepalm_hs[e]')
    'ER_EX_peste_hs[e]'.('R_EX_peste_hs[e]')
    'ER_EX_pmeth[e]'.('R_EX_pmeth[e]')
    'ER_EX_saccrp_L[e]'.('R_EX_saccrp_L[e]')
    'ER_EX_sebacid[e]'.('R_EX_sebacid[e]')
    'ER_EX_sphmyln180241_hs[e]'.('R_EX_sphmyln180241_hs[e]')
    'ER_EX_sphmyln18114_hs[e]'.('R_EX_sphmyln18114_hs[e]')
    'ER_EX_sphmyln18115_hs[e]'.('R_EX_sphmyln18115_hs[e]')
    'ER_EX_sphmyln18116_hs[e]'.('R_EX_sphmyln18116_hs[e]')
    'ER_EX_sphmyln181161_hs[e]'.('R_EX_sphmyln181161_hs[e]')
    'ER_EX_sphmyln18117_hs[e]'.('R_EX_sphmyln18117_hs[e]')
    'ER_EX_sphmyln18118_hs[e]'.('R_EX_sphmyln18118_hs[e]')
    'ER_EX_sphmyln181181_hs[e]'.('R_EX_sphmyln181181_hs[e]')
    'ER_EX_sphmyln18120_hs[e]'.('R_EX_sphmyln18120_hs[e]')
    'ER_EX_sphmyln181201_hs[e]'.('R_EX_sphmyln181201_hs[e]')
    'ER_EX_sphmyln18121_hs[e]'.('R_EX_sphmyln18121_hs[e]')
    'ER_EX_sphmyln18122_hs[e]'.('R_EX_sphmyln18122_hs[e]')
    'ER_EX_sphmyln181221_hs[e]'.('R_EX_sphmyln181221_hs[e]')
    'ER_EX_sphmyln18123_hs[e]'.('R_EX_sphmyln18123_hs[e]')
    'ER_EX_sphmyln1824_hs[e]'.('R_EX_sphmyln1824_hs[e]')
    'ER_EX_sphmyln1825_hs[e]'.('R_EX_sphmyln1825_hs[e]')
    'ER_EX_steeth[e]'.('R_EX_steeth[e]')
    'ER_EX_subeac[e]'.('R_EX_subeac[e]')
    'ER_EX_tetdecaeth[e]'.('R_EX_tetdecaeth[e]')
    'ER_EX_tmlys[e]'.('R_EX_tmlys[e]')
    'ER_EX_trideceth[e]'.('R_EX_trideceth[e]')
    'ER_EX_ttdcrn[e]'.('R_EX_ttdcrn[e]')
    'ER_EX_urcan[e]'.('R_EX_urcan[e]')
    'ER_EX_wharachd[e]'.('R_EX_wharachd[e]')
    'ER_FORGLUt'.('R_FORGLUt')
    'ER_GALTt'.('R_GALTt')
    'ER_LYSACm'.('R_LYSACm')
    'ER_GLYC_Rt'.('R_GLYC_Rt')
    'ER_GLYCLTtd'.('R_GLYCLTtd')
    'ER_HC00900t1'.('R_HC00900t1')
    'ER_HC00900t2'.('R_HC00900t2')
    'ER_HC00900t3'.('R_HC00900t3')
    'ER_HC00900t4'.('R_HC00900t4')
    'ER_HC02149td'.('R_HC02149td')
    'ER_HEXDIACtd'.('R_HEXDIACtd')
    'ER_HGENTISt'.('R_HGENTISt')
    'ER_HMCRNt'.('R_HMCRNt')
    'ER_HXCOAm'.('R_HXCOAm')
    'ER_HXCOAte'.('R_HXCOAte')
    'ER_HXCOAtx'.('R_HXCOAtx')
    'ER_HXCOAx'.('R_HXCOAx')
    'ER_IND3ACt'.('R_IND3ACt')
    'ER_LCYSTt'.('R_LCYSTt')
    'ER_LEUKTRB4WCOOHt'.('R_LEUKTRB4WCOOHt')
    'ER_LEUKTRB4WOHt'.('R_LEUKTRB4WOHt')
    'ER_LEUKTRB4WOHtr'.('R_LEUKTRB4WOHtr')
    'ER_LNLCCRNtd'.('R_LNLCCRNtd')
    'ER_LTHSTRLt'.('R_LTHSTRLt')
    'ER_MEV_Rt'.('R_MEV_Rt')
    'ER_MI1Pt'.('R_MI1Pt')
    'ER_NWHARGtd'.('R_NWHARGtd')
    'ER_OAAt'.('R_OAAt')
    'ER_pac'.('R_pac')
    'ER_PCOLLG5HLYStd'.('R_PCOLLG5HLYStd')
    'ER_PROSTGI2c'.('R_PROSTGI2c')
    'ER_PSERtr'.('R_PSERtr')
    'ER_SACCRP_Lte'.('R_SACCRP_Lte')
    'ER_SACCRP_Ltm'.('R_SACCRP_Ltm')
    'ER_SEBACIDtd'.('R_SEBACIDtd')
    'ER_SUBEACtd'.('R_SUBEACtd')
    'ER_TMLYStd'.('R_TMLYStd')
    'ER_TXB2c'.('R_TXB2c')
    'ER_URCANt'.('R_URCANt')
    'ER_WHARACHDtr'.('R_WHARACHDtr')
    'ER_EX_estriol[e]'.('R_EX_estriol[e]')
    'ER_DDCAFATP'.('R_DDCAFATP')
    'ER_EX_3moxtyr[e]'.('R_EX_3moxtyr[e]')
    'ER_EX_5aop[e]'.('R_EX_5aop[e]')
    'ER_EX_acglu[e]'.('R_EX_acglu[e]')
    'ER_EX_alltn[e]'.('R_EX_alltn[e]')
    'ER_EX_CE2510[e]'.('R_EX_CE2510[e]')
    'ER_EX_ddca[e]'.('R_EX_ddca[e]')
    'ER_EX_glyc_R[e]'.('R_EX_glyc_R[e]')
    'ER_EX_glyclt[e]'.('R_EX_glyclt[e]')
    'ER_EX_Lcyst[e]'.('R_EX_Lcyst[e]')
    'ER_EX_oaa[e]'.('R_EX_oaa[e]')
    'ER_EX_pac[e]'.('R_EX_pac[e]')
    'ER_EX_phlac[e]'.('R_EX_phlac[e]')
    'ER_EX_pser_L[e]'.('R_EX_pser_L[e]')
    'ER_EX_ttdcea[e]'.('R_EX_ttdcea[e]')
    'ER_TTDCEAt'.('R_TTDCEAt')
    'ER_DCHOLESTANCOAc'.('R_DCHOLESTANCOAc')
    'ER_XOL27OHtmc'.('R_XOL27OHtmc')
    'ER_r0202m'.('R_r0202m')
    'ER_PHEACGLYsec'.('R_PHEACGLYsec')
    'ER_EX_pheacgly[e]'.('R_EX_pheacgly[e]')
    'ER_EX_bz[e]'.('R_EX_bz[e]')
    'ER_NORMETEt'.('R_NORMETEt')
    'ER_MEPIt'.('R_MEPIt')
    'ER_TREt'.('R_TREt')
    'ER_C05300t'.('R_C05300t')
    'ER_RETINALt'.('R_RETINALt')
    'ER_MALTTTRt'.('R_MALTTTRt')
    'ER_1MNCAMt'.('R_1MNCAMt')
    'ER_DHBPTt'.('R_DHBPTt')
    'ER_THBPTt'.('R_THBPTt')
    'ER_EX_normete_L[e]'.('R_EX_normete_L[e]')
    'ER_EX_mepi[e]'.('R_EX_mepi[e]')
    'ER_EX_C05300[e]'.('R_EX_C05300[e]')
    'ER_EX_retinal[e]'.('R_EX_retinal[e]')
    'ER_EX_maltttr[e]'.('R_EX_maltttr[e]')
    'ER_EX_1mncam[e]'.('R_EX_1mncam[e]')
    'ER_EX_dhbpt[e]'.('R_EX_dhbpt[e]')
    'ER_EX_thbpt[e]'.('R_EX_thbpt[e]')
    'ER_EX_adprib[e]'.('R_EX_adprib[e]')
    'ER_EX_homoval[e]'.('R_EX_homoval[e]')
    'ER_GLYCLTtm'.('R_GLYCLTtm')
    'ER_TYMc'.('R_TYMc')
    'ER_PCHOL2PALM_HSte'.('R_PCHOL2PALM_HSte')
    'ER_PE224_HSte'.('R_PE224_HSte')
    'ER_PCHOLN261_HSte'.('R_PCHOLN261_HSte')
    'ER_PCHOLN281_HSte'.('R_PCHOLN281_HSte')
    'ER_PCHOLN28_HSte'.('R_PCHOLN28_HSte')
    'ER_ACRNtr'.('R_ACRNtr')
    'ER_HDCECRNtr'.('R_HDCECRNtr')
    'ER_LNELDCCRNtr'.('R_LNELDCCRNtr')
    'ER_ODECRNtr'.('R_ODECRNtr')
    'ER_PMTCRNtr'.('R_PMTCRNtr')
    'ER_STCRNtr'.('R_STCRNtr')
    'ER_EX_sphmyln_hs[e]'.('R_EX_sphmyln_hs[e]')
    'ER_PHEACGLYtm'.('R_PHEACGLYtm')
    'ER_HXAt1'.('R_HXAt1')
    'ER_HXAt2'.('R_HXAt2')
    'ER_HXAt3'.('R_HXAt3')
    'ER_EX_hxa[e]'.('R_EX_hxa[e]')
    'ER_PACCOALm'.('R_PACCOALm')
    'ER_PACALDtm'.('R_PACALDtm')
    'ER_LHCYSTIN'.('R_LHCYSTIN')
    'ER_LHCYSTINt'.('R_LHCYSTINt')
    'ER_EX_Lhcystin[e]'.('R_EX_Lhcystin[e]')
    'ER_PA_HStm'.('R_PA_HStm')
    'ER_FldAct'.('R_FldAct')
    'ER_MALOAtm'.('R_MALOAtm')
    'ER_MLTHFtm'.('R_MLTHFtm')
    'ER_2MOPtm'.('R_2MOPtm')
    'ER_MMALtm'.('R_MMALtm')
    'ER_PGPP_hsc'.('R_PGPP_hsc')
    'ER_CE2512te'.('R_CE2512te')
    'ER_r2514e'.('R_r2514e')
    'ER_r2514m'.('R_r2514m')
    'ER_FAS180'.('R_FAS180')
    'ER_5AOPt2'.('R_5AOPt2')
    'ER_ACNAMt2'.('R_ACNAMt2')
    'ER_ADRNLtu'.('R_ADRNLtu')
    'ER_DM_pe_hs[c]'.('R_DM_pe_hs[c]')
    'ER_DM_akg[c]'.('R_DM_akg[c]')
    'ER_DM_for[c]'.('R_DM_for[c]')
    'ER_DM_mi1345p[c]'.('R_DM_mi1345p[c]')
    'ER_DM_mi134p[c]'.('R_DM_mi134p[c]')
    'ER_DM_mi145p[c]'.('R_DM_mi145p[c]')
    'ER_DM_mi14p[c]'.('R_DM_mi14p[c]')
    'ER_DM_pchol_hs[c]'.('R_DM_pchol_hs[c]')
    'ER_ETHAt'.('R_ETHAt')
    'ER_HCYSte'.('R_HCYSte')
    'ER_OROte'.('R_OROte')
    'ER_PPPGOc'.('R_PPPGOc')
    'ER_SPRMt2r'.('R_SPRMt2r')
    'ER_THMtrbc'.('R_THMtrbc')
    'ER_UGT1A10c'.('R_UGT1A10c')
    'ER_UNK3r'.('R_UNK3r')
    'ER_ACGALtr'.('R_ACGALtr')
    'ER_ACNAMtr'.('R_ACNAMtr')
    'ER_CORE4t'.('R_CORE4t')
    'ER_S2L2N2M2Mt'.('R_S2L2N2M2Mt')
    'ER_EX_core4[e]'.('R_EX_core4[e]')
    'ER_EX_f1a[e]'.('R_EX_f1a[e]')
    'ER_EX_s2l2n2m2m[e]'.('R_EX_s2l2n2m2m[e]')
    'ER_EX_acgal[e]'.('R_EX_acgal[e]')
    'ER_EX_acnam[e]'.('R_EX_acnam[e]')
    'ER_EX_pa_hs[e]'.('R_EX_pa_hs[e]')
    'ER_DM_C02712[c]'.('R_DM_C02712[c]')
    'ER_F1Ate'.('R_F1Ate')
    'ER_34HPLtm'.('R_34HPLtm')
    'ER_3HMPtm'.('R_3HMPtm')
    'ER_3HPPtm'.('R_3HPPtm')
    'ER_ACGLUtm'.('R_ACGLUtm')
    'ER_PGP_hs_tm'.('R_PGP_hs_tm')
    'ER_PROSTGE2t2r'.('R_PROSTGE2t2r')
    'ER_ESTR2r'.('R_ESTR2r')
    'ER_LTHSTRLtr'.('R_LTHSTRLtr')
    'ER_PGLYCtm'.('R_PGLYCtm')
    'ER_sink_25hvitd2[c]'.('R_sink_25hvitd2[c]')
    'ER_sink_C02528[c]'.('R_sink_C02528[c]')
    'ER_sink_HC02191[c]'.('R_sink_HC02191[c]')
    'ER_sink_HC02194[c]'.('R_sink_HC02194[c]')
    'ER_sink_HC02195[c]'.('R_sink_HC02195[c]')
    'ER_sink_HC02196[c]'.('R_sink_HC02196[c]')
    'ER_sink_HC02197[c]'.('R_sink_HC02197[c]')
    'ER_sink_HC02198[c]'.('R_sink_HC02198[c]')
    'ER_sink_HC02220[c]'.('R_sink_HC02220[c]')
    'ER_sink_Tyr_ggn[c]'.('R_sink_Tyr_ggn[c]')
    'ER_sink_avite1[c]'.('R_sink_avite1[c]')
    'ER_sink_btn[c]'.('R_sink_btn[c]')
    'ER_sink_c226coa[c]'.('R_sink_c226coa[c]')
    'ER_sink_chol[c]'.('R_sink_chol[c]')
    'ER_sink_cholate[c]'.('R_sink_cholate[c]')
    'ER_sink_coa[c]'.('R_sink_coa[c]')
    'ER_sink_crvnc[c]'.('R_sink_crvnc[c]')
    'ER_sink_dgchol[c]'.('R_sink_dgchol[c]')
    'ER_sink_doco13ecoa[c]'.('R_sink_doco13ecoa[c]')
    'ER_sink_fad[c]'.('R_sink_fad[c]')
    'ER_sink_fe3[c]'.('R_sink_fe3[c]')
    'ER_sink_gchola[c]'.('R_sink_gchola[c]')
    'ER_sink_glygn2[c]'.('R_sink_glygn2[c]')
    'ER_sink_hdca[c]'.('R_sink_hdca[c]')
    'ER_sink_lnlc[c]'.('R_sink_lnlc[c]')
    'ER_sink_lnlccoa[c]'.('R_sink_lnlccoa[c]')
    'ER_sink_lnlncacoa[c]'.('R_sink_lnlncacoa[c]')
    'ER_sink_lnlncgcoa[c]'.('R_sink_lnlncgcoa[c]')
    'ER_sink_nad[c]'.('R_sink_nad[c]')
    'ER_sink_nadp[c]'.('R_sink_nadp[c]')
    'ER_sink_odecoa[c]'.('R_sink_odecoa[c]')
    'ER_sink_pmtcoa[c]'.('R_sink_pmtcoa[c]')
    'ER_sink_pydam[c]'.('R_sink_pydam[c]')
    'ER_sink_pydx[c]'.('R_sink_pydx[c]')
    'ER_sink_pydxn[c]'.('R_sink_pydxn[c]')
    'ER_sink_retfa[c]'.('R_sink_retfa[c]')
    'ER_sink_retinol[c]'.('R_sink_retinol[c]')
    'ER_sink_stcoa[c]'.('R_sink_stcoa[c]')
    'ER_sink_tag_hs[c]'.('R_sink_tag_hs[c]')
    'ER_sink_tchola[c]'.('R_sink_tchola[c]')
    'ER_sink_tdchola[c]'.('R_sink_tdchola[c]')
    'ER_sink_thf[c]'.('R_sink_thf[c]')
    'ER_sink_thmpp[c]'.('R_sink_thmpp[c]')
    'ER_sink_thmtp[c]'.('R_sink_thmtp[c]')
    'ER_sink_tmndnc[c]'.('R_sink_tmndnc[c]')
    'ER_sink_tmndnccoa[c]'.('R_sink_tmndnccoa[c]')
    'ER_sink_vitd3[c]'.('R_sink_vitd3[c]')
    'ER_DXTRNt'.('R_DXTRNt')
    'ER_EX_dxtrn[e]'.('R_EX_dxtrn[e]')
    'ER_EX_dhcholestanate[e]'.('R_EX_dhcholestanate[e]')
    'ER_sink_dhcholestanate[c]'.('R_sink_dhcholestanate[c]')
    'ER_EX_thcholstoic[e]'.('R_EX_thcholstoic[e]')
    'ER_sink_thcholstoic[c]'.('R_sink_thcholstoic[c]')
    'ER_EX_xol7ah3[e]'.('R_EX_xol7ah3[e]')
    'ER_sink_xol7ah3[c]'.('R_sink_xol7ah3[c]')
    'ER_EX_xol7aone[e]'.('R_EX_xol7aone[e]')
    'ER_sink_xol7aone[c]'.('R_sink_xol7aone[c]')
    'ER_EX_xoldiolone[e]'.('R_EX_xoldiolone[e]')
    'ER_sink_xoldiolone[c]'.('R_sink_xoldiolone[c]')
    'ER_EX_7klitchol[e]'.('R_EX_7klitchol[e]')
    'ER_sink_7klitchol[c]'.('R_sink_7klitchol[c]')
    'ER_sink_dchac[c]'.('R_sink_dchac[c]')
    'ER_EX_2obut[e]'.('R_EX_2obut[e]')
    'ER_EX_glcn[e]'.('R_EX_glcn[e]')
    'ER_CO2t'.('R_CO2t')
    'ER_DM_atp_c_'.('R_DM_atp_c_')
    'ER_EX_acac[e]'.('R_EX_acac[e]')
    'ER_EX_adn[e]'.('R_EX_adn[e]')
    'ER_EX_akg[e]'.('R_EX_akg[e]')
    'ER_EX_asn_L[e]'.('R_EX_asn_L[e]')
    'ER_EX_asp_L[e]'.('R_EX_asp_L[e]')
    'ER_EX_but[e]'.('R_EX_but[e]')
    'ER_EX_cgly[e]'.('R_EX_cgly[e]')
    'ER_EX_co2[e]'.('R_EX_co2[e]')
    'ER_EX_cytd[e]'.('R_EX_cytd[e]')
    'ER_EX_dad_2[e]'.('R_EX_dad_2[e]')
    'ER_EX_dcyt[e]'.('R_EX_dcyt[e]')
    'ER_EX_dgsn[e]'.('R_EX_dgsn[e]')
    'ER_EX_din[e]'.('R_EX_din[e]')
    'ER_EX_duri[e]'.('R_EX_duri[e]')
    'ER_EX_fe2[e]'.('R_EX_fe2[e]')
    'ER_EX_fe3[e]'.('R_EX_fe3[e]')
    'ER_EX_fum[e]'.('R_EX_fum[e]')
    'ER_EX_gal[e]'.('R_EX_gal[e]')
    'ER_EX_glu_L[e]'.('R_EX_glu_L[e]')
    'ER_EX_h[e]'.('R_EX_h[e]')
    'ER_EX_h2o[e]'.('R_EX_h2o[e]')
    'ER_EX_ile_L[e]'.('R_EX_ile_L[e]')
    'ER_EX_ins[e]'.('R_EX_ins[e]')
    'ER_EX_k[e]'.('R_EX_k[e]')
    'ER_EX_lac_L[e]'.('R_EX_lac_L[e]')
    'ER_EX_leu_L[e]'.('R_EX_leu_L[e]')
    'ER_EX_lys_L[e]'.('R_EX_lys_L[e]')
    'ER_EX_mal_L[e]'.('R_EX_mal_L[e]')
    'ER_EX_met_L[e]'.('R_EX_met_L[e]')
    'ER_EX_na1[e]'.('R_EX_na1[e]')
    'ER_EX_no2[e]'.('R_EX_no2[e]')
    'ER_EX_o2[e]'.('R_EX_o2[e]')
    'ER_EX_orn[e]'.('R_EX_orn[e]')
    'ER_EX_pi[e]'.('R_EX_pi[e]')
    'ER_EX_ppi[e]'.('R_EX_ppi[e]')
    'ER_EX_pro_L[e]'.('R_EX_pro_L[e]')
    'ER_EX_ribflv[e]'.('R_EX_ribflv[e]')
    'ER_EX_ser_L[e]'.('R_EX_ser_L[e]')
    'ER_EX_so4[e]'.('R_EX_so4[e]')
    'ER_EX_succ[e]'.('R_EX_succ[e]')
    'ER_EX_thymd[e]'.('R_EX_thymd[e]')
    'ER_EX_urea[e]'.('R_EX_urea[e]')
    'ER_EX_uri[e]'.('R_EX_uri[e]')
    'ER_EX_val_L[e]'.('R_EX_val_L[e]')
    'ER_FCLTc'.('R_FCLTc')
    'ER_FT'.('R_FT')
    'ER_G5SADs'.('R_G5SADs')
    'ER_O2t'.('R_O2t')
    'ER_PIt6b'.('R_PIt6b')
    'ER_URIDK3'.('R_URIDK3')
    'ER_EX_pnto_R[e]'.('R_EX_pnto_R[e]')
    'ER_EX_gly[e]'.('R_EX_gly[e]')
    'ER_EX_cys_L[e]'.('R_EX_cys_L[e]')
    'ER_EX_ala_L[e]'.('R_EX_ala_L[e]')
    'ER_EX_his_L[e]'.('R_EX_his_L[e]')
    'ER_EX_thr_L[e]'.('R_EX_thr_L[e]')
    'ER_EX_gln_L[e]'.('R_EX_gln_L[e]')
    'ER_EX_phe_L[e]'.('R_EX_phe_L[e]')
    'ER_EX_tyr_L[e]'.('R_EX_tyr_L[e]')
    'ER_EX_arg_L[e]'.('R_EX_arg_L[e]')
    'ER_EX_for[e]'.('R_EX_for[e]')
    'ER_EX_nac[e]'.('R_EX_nac[e]')
    'ER_EX_ind3ac[e]'.('R_EX_ind3ac[e]')
    'ER_EX_nh4[e]'.('R_EX_nh4[e]')
    'ER_EX_ac[e]'.('R_EX_ac[e]')
    'ER_CSND'.('R_CSND')
    'ER_EX_acgam[e]'.('R_EX_acgam[e]')
    'ER_EX_cit[e]'.('R_EX_cit[e]')
    'ER_EX_csn[e]'.('R_EX_csn[e]')
    'ER_EX_drib[e]'.('R_EX_drib[e]')
    'ER_EX_etha[e]'.('R_EX_etha[e]')
    'ER_EX_fol[e]'.('R_EX_fol[e]')
    'ER_EX_fru[e]'.('R_EX_fru[e]')
    'ER_EX_galt[e]'.('R_EX_galt[e]')
    'ER_EX_glcr[e]'.('R_EX_glcr[e]')
    'ER_EX_glcur[e]'.('R_EX_glcur[e]')
    'ER_EX_glyc[e]'.('R_EX_glyc[e]')
    'ER_EX_hxan[e]'.('R_EX_hxan[e]')
    'ER_EX_malt[e]'.('R_EX_malt[e]')
    'ER_EX_malthx[e]'.('R_EX_malthx[e]')
    'ER_EX_malttr[e]'.('R_EX_malttr[e]')
    'ER_EX_man[e]'.('R_EX_man[e]')
    'ER_EX_ptrc[e]'.('R_EX_ptrc[e]')
    'ER_EX_rib_D[e]'.('R_EX_rib_D[e]')
    'ER_EX_spmd[e]'.('R_EX_spmd[e]')
    'ER_EX_thm[e]'.('R_EX_thm[e]')
    'ER_EX_trp_L[e]'.('R_EX_trp_L[e]')
    'ER_EX_ura[e]'.('R_EX_ura[e]')
    'ER_EX_xan[e]'.('R_EX_xan[e]')
    'ER_EX_xyl_D[e]'.('R_EX_xyl_D[e]')
    'ER_NTD5_a'.('R_NTD5_a')
    'ER_OAADC'.('R_OAADC')
    'ER_EX_pydxn[e]'.('R_EX_pydxn[e]')
    'ER_PYDXNtr'.('R_PYDXNtr')
    'ER_EX_pydx[e]'.('R_EX_pydx[e]')
    'ER_PYDXtr'.('R_PYDXtr')
    'ER_EX_pydam[e]'.('R_EX_pydam[e]')
    'ER_PYDAMtr'.('R_PYDAMtr')
    'ER_EX_4hbz[e]'.('R_EX_4hbz[e]')
    'ER_EX_ppa[e]'.('R_EX_ppa[e]')
    'ER_EX_arab_L[e]'.('R_EX_arab_L[e]')
    'ER_EX_gam[e]'.('R_EX_gam[e]')
    'ER_EX_pyr[e]'.('R_EX_pyr[e]')
    'ER_EX_tre[e]'.('R_EX_tre[e]')
    'ER_EX_btn[e]'.('R_EX_btn[e]')
    'ER_EX_lcts[e]'.('R_EX_lcts[e]')
    'ER_EX_ade[e]'.('R_EX_ade[e]')
    'ER_EX_etoh[e]'.('R_EX_etoh[e]')
    'ER_ETOHt'.('R_ETOHt')
    'ER_EX_acald[e]'.('R_EX_acald[e]')
    'ER_ACALDt'.('R_ACALDt')
    'ER_EX_sucr[e]'.('R_EX_sucr[e]')
    'ER_EX_pheme[e]'.('R_EX_pheme[e]')
    'ER_MTRI'.('R_MTRI')
    'ER_EX_gua[e]'.('R_EX_gua[e]')
    'ER_EX_4abut[e]'.('R_EX_4abut[e]')
    'ER_OBDHc'.('R_OBDHc')
    'ER_EX_phpyr[e]'.('R_EX_phpyr[e]')
    'ER_EX_lanost[e]'.('R_EX_lanost[e]')
    'ER_3MOX4HOXMte'.('R_3MOX4HOXMte')
    'ER_EX_3mox4hoxm[e]'.('R_EX_3mox4hoxm[e]')
    'ER_2H3MVte'.('R_2H3MVte')
    'ER_EX_2h3mv[e]'.('R_EX_2h3mv[e]')
    'ER_2HIVte'.('R_2HIVte')
    'ER_EX_2hiv[e]'.('R_EX_2hiv[e]')
    'ER_2M3HBUc'.('R_2M3HBUc')
    'ER_2M3HBUtm'.('R_2M3HBUtm')
    'ER_2M3HBUte'.('R_2M3HBUte')
    'ER_EX_2m3hbu[e]'.('R_EX_2m3hbu[e]')
    'ER_3H3MGLTc'.('R_3H3MGLTc')
    'ER_3H3MGLTte'.('R_3H3MGLTte')
    'ER_EX_3h3mglt[e]'.('R_EX_3h3mglt[e]')
    'ER_3MGLUTACc'.('R_3MGLUTACc')
    'ER_3MGLUTACtm'.('R_3MGLUTACtm')
    'ER_3MGLUTACte'.('R_3MGLUTACte')
    'ER_EX_3mglutac[e]'.('R_EX_3mglutac[e]')
    'ER_PPIOGLYtm'.('R_PPIOGLYtm')
    'ER_PPIOGLYte'.('R_PPIOGLYte')
    'ER_EX_ppiogly[e]'.('R_EX_ppiogly[e]')
    'ER_TIGGLYtm'.('R_TIGGLYtm')
    'ER_TIGGLYte'.('R_TIGGLYte')
    'ER_EX_tiggly[e]'.('R_EX_tiggly[e]')
    'ER_GLUTACOAm'.('R_GLUTACOAm')
    'ER_GLUTCONm'.('R_GLUTCONm')
    'ER_GLUTCONtm'.('R_GLUTCONtm')
    'ER_GLUTCONte'.('R_GLUTCONte')
    'ER_EX_glutcon[e]'.('R_EX_glutcon[e]')
    'ER_3HIVAcm'.('R_3HIVAcm')
    'ER_3HIVActm'.('R_3HIVActm')
    'ER_3HIVActe'.('R_3HIVActe')
    'ER_EX_3hivac[e]'.('R_EX_3hivac[e]')
    'ER_3HADPACx'.('R_3HADPACx')
    'ER_3HADPACtxc'.('R_3HADPACtxc')
    'ER_3HADPACte'.('R_3HADPACte')
    'ER_EX_3hadpac[e]'.('R_EX_3hadpac[e]')
    'ER_3OHSEBACx'.('R_3OHSEBACx')
    'ER_3OHSEBACtxc'.('R_3OHSEBACtxc')
    'ER_3OHSEBACte'.('R_3OHSEBACte')
    'ER_EX_3ohsebac[e]'.('R_EX_3ohsebac[e]')
    'ER_3OHSUBACx'.('R_3OHSUBACx')
    'ER_3OHSUBACtxc'.('R_3OHSUBACtxc')
    'ER_3OHSUBACte'.('R_3OHSUBACte')
    'ER_EX_3ohsubac[e]'.('R_EX_3ohsubac[e]')
    'ER_CAPROICc'.('R_CAPROICc')
    'ER_5OHHEXAc'.('R_5OHHEXAc')
    'ER_5OHHEXAte'.('R_5OHHEXAte')
    'ER_EX_5ohhexa[e]'.('R_EX_5ohhexa[e]')
    'ER_ETHMALCOAc'.('R_ETHMALCOAc')
    'ER_ETHMALACc'.('R_ETHMALACc')
    'ER_ETHMALACte'.('R_ETHMALACte')
    'ER_EX_ethmalac[e]'.('R_EX_ethmalac[e]')
    'ER_HEXGLYte'.('R_HEXGLYte')
    'ER_EX_hexgly[e]'.('R_EX_hexgly[e]')
    'ER_SUBGLYte'.('R_SUBGLYte')
    'ER_EX_subgly[e]'.('R_EX_subgly[e]')
    'ER_4OHBUTm'.('R_4OHBUTm')
    'ER_4OHBUTtmc'.('R_4OHBUTtmc')
    'ER_4OHBUTtce'.('R_4OHBUTtce')
    'ER_EX_4ohbut[e]'.('R_EX_4ohbut[e]')
    'ER_12HPETUPKt'.('R_12HPETUPKt')
    'ER_15HPETUPKt'.('R_15HPETUPKt')
    'ER_3AIBSYMPt'.('R_3AIBSYMPt')
    'ER_CE7172UPKt'.('R_CE7172UPKt')
    'ER_PAIL_hs_SECt'.('R_PAIL_hs_SECt')
    'ER_PAILPALM_HSSECt'.('R_PAILPALM_HSSECt')
    'ER_PAILR_HSSECt'.('R_PAILR_HSSECt')
    'ER_SPHMYLN_HsSECt'.('R_SPHMYLN_HsSECt')
    'ER_SPHMYLN180241_hs_SECt'.('R_SPHMYLN180241_hs_SECt')
    'ER_SPHMYLN18114_hs_SECt'.('R_SPHMYLN18114_hs_SECt')
    'ER_SPHMYLN18115_hs_SECt'.('R_SPHMYLN18115_hs_SECt')
    'ER_SPHMYLN18116_hs_SECt'.('R_SPHMYLN18116_hs_SECt')
    'ER_SPHMYLN181161_hs_SECt'.('R_SPHMYLN181161_hs_SECt')
    'ER_SPHMYLN18117_hs_SECt'.('R_SPHMYLN18117_hs_SECt')
    'ER_SPHMYLN18118_hs_SECt'.('R_SPHMYLN18118_hs_SECt')
    'ER_SPHMYLN181181_hs_SECt'.('R_SPHMYLN181181_hs_SECt')
    'ER_SPHMYLN18120_hs_SECt'.('R_SPHMYLN18120_hs_SECt')
    'ER_SPHMYLN181201_hs_SECt'.('R_SPHMYLN181201_hs_SECt')
    'ER_SPHMYLN18121_hs_SECt'.('R_SPHMYLN18121_hs_SECt')
    'ER_SPHMYLN18122_hs_SECt'.('R_SPHMYLN18122_hs_SECt')
    'ER_SPHMYLN181221_hs_SECt'.('R_SPHMYLN181221_hs_SECt')
    'ER_SPHMYLN18123_hs_SECt'.('R_SPHMYLN18123_hs_SECt')
    'ER_SPHMYLN1824_hs_SECt'.('R_SPHMYLN1824_hs_SECt')
    'ER_SPHMYLN1825_hs_SECt'.('R_SPHMYLN1825_hs_SECt')
    'ER_3AIBt1'.('R_3AIBt1')
    'ER_AK2LGCHOLt1'.('R_AK2LGCHOLt1')
    'ER_PAFt1'.('R_PAFt1')
    'ER_PCHOL2LINL_HSt1e'.('R_PCHOL2LINL_HSt1e')
    'ER_PCHOL2OLE_HSt1e'.('R_PCHOL2OLE_HSt1e')
    'ER_PCHOL2STE_HSt1e'.('R_PCHOL2STE_HSt1e')
    'ER_PCHOLAR_HSt1e'.('R_PCHOLAR_HSt1e')
    'ER_PCHOLDOC_HSt1e'.('R_PCHOLDOC_HSt1e')
    'ER_PCHOLEIC_HSt1e'.('R_PCHOLEIC_HSt1e')
    'ER_PCHOLET_HSt1e'.('R_PCHOLET_HSt1e')
    'ER_PCHOLHEP_HSt1e'.('R_PCHOLHEP_HSt1e')
    'ER_PCHOLLINL_HSt1e'.('R_PCHOLLINL_HSt1e')
    'ER_PCHOLMYR_Hst1e'.('R_PCHOLMYR_Hst1e')
    'ER_PCHOLN15_HSt1e'.('R_PCHOLN15_HSt1e')
    'ER_PCHOLN183_HSt1e'.('R_PCHOLN183_HSt1e')
    'ER_PCHOLN1836_HSt1e'.('R_PCHOLN1836_HSt1e')
    'ER_PCHOLN19_HSt1e'.('R_PCHOLN19_HSt1e')
    'ER_PCHOLN201_HSt1e'.('R_PCHOLN201_HSt1e')
    'ER_PCHOLN203_HSt1e'.('R_PCHOLN203_HSt1e')
    'ER_PCHOLN204_HSt1e'.('R_PCHOLN204_HSt1e')
    'ER_PCHOLN205_HSt1e'.('R_PCHOLN205_HSt1e')
    'ER_PCHOLN224_HSt1e'.('R_PCHOLN224_HSt1e')
    'ER_PCHOLN225_HSt1e'.('R_PCHOLN225_HSt1e')
    'ER_PCHOLN2254_HSt1e'.('R_PCHOLN2254_HSt1e')
    'ER_PCHLN225_HSt1e'.('R_PCHLN225_HSt1e')
    'ER_PCHOLN264_HSt1e'.('R_PCHOLN264_HSt1e')
    'ER_PCHOLOLE_HSt1e'.('R_PCHOLOLE_HSt1e')
    'ER_PEPALM_HSt1e'.('R_PEPALM_HSt1e')
    'ER_PCHOLPALME-HSt1e'.('R_PCHOLPALME-HSt1e')
    'ER_PCHOLSTE_HSt1e'.('R_PCHOLSTE_HSt1e')
    'ER_PE12_HSt1e'.('R_PE12_HSt1e')
    'ER_Pe13_HSt1e'.('R_Pe13_HSt1e')
    'ER_PE14_HSt1e'.('R_PE14_HSt1e')
    'ER_PE15_HSt1e'.('R_PE15_HSt1e')
    'ER_PE161_HSt1e'.('R_PE161_HSt1e')
    'ER_PE17_HSt1e'.('R_PE17_HSt1e')
    'ER_PE203_HSt1e'.('R_PE203_HSt1e')
    'ER_PE226_HSt1e'.('R_PE226_HSt1e')
    'ER_PE2LINL_HSt1e'.('R_PE2LINL_HSt1e')
    'ER_PEAR_HSt1e'.('R_PEAR_HSt1e')
    'ER_PEDH203_HSt1e'.('R_PEDH203_HSt1e')
    'ER_PELINL_HSt1e'.('R_PELINL_HSt1e')
    'ER_PEOLE_HSt1e'.('R_PEOLE_HSt1e')
    'ER_PELPALM_HSt1e'.('R_PELPALM_HSt1e')
    'ER_PESTE_HSt1e'.('R_PESTE_HSt1e')
    'ER_EIC21114TRte'.('R_EIC21114TRte')
    'ER_EX_eic21114tr[e]'.('R_EX_eic21114tr[e]')
    'ER_5EIPENCte'.('R_5EIPENCte')
    'ER_EX_5eipenc[e]'.('R_EX_5eipenc[e]')
    'ER_ISOBUTtm'.('R_ISOBUTtm')
    'ER_ISOBUTte'.('R_ISOBUTte')
    'ER_EX_CE4969[e]'.('R_EX_CE4969[e]')
    'ER_NACCYStm'.('R_NACCYStm')
    'ER_NACCYSte'.('R_NACCYSte')
    'ER_EX_CE1310[e]'.('R_EX_CE1310[e]')
    'ER_AGRMtm'.('R_AGRMtm')
    'ER_EX_agm[e]'.('R_EX_agm[e]')
    'ER_T4HCINNMtm'.('R_T4HCINNMtm')
    'ER_EX_T4hcinnm[e]'.('R_EX_T4hcinnm[e]')
    'ER_4HBZte'.('R_4HBZte')
    'ER_SUCSALtm'.('R_SUCSALtm')
    'ER_SUCSALte'.('R_SUCSALte')
    'ER_EX_sucsal[e]'.('R_EX_sucsal[e]')
    'ER_CE7081tr'.('R_CE7081tr')
    'ER_CE7081tm'.('R_CE7081tm')
    'ER_EX_CE7081[e]'.('R_EX_CE7081[e]')
    'ER_EGMEtr'.('R_EGMEtr')
    'ER_EGMEte'.('R_EGMEte')
    'ER_EX_egme[e]'.('R_EX_egme[e]')
    'ER_SQLtr'.('R_SQLtr')
    'ER_SQLte'.('R_SQLte')
    'ER_EX_sql[e]'.('R_EX_sql[e]')
    'ER_ORN_Dte'.('R_ORN_Dte')
    'ER_EX_orn_D[e]'.('R_EX_orn_D[e]')
    'ER_5G2OXPTtx'.('R_5G2OXPTtx')
    'ER_5G2OXPTte'.('R_5G2OXPTte')
    'ER_EX_5g2oxpt[e]'.('R_EX_5g2oxpt[e]')
    'ER_DHEAte'.('R_DHEAte')
    'ER_EX_dhea[e]'.('R_EX_dhea[e]')
    'ER_ANDRSTANDRtr'.('R_ANDRSTANDRtr')
    'ER_EX_andrstandn[e]'.('R_EX_andrstandn[e]')
    'ER_ESTRONEte'.('R_ESTRONEte')
    'ER_EX_estrone[e]'.('R_EX_estrone[e]')
    'ER_HC02020tr'.('R_HC02020tr')
    'ER_HC02020te'.('R_HC02020te')
    'ER_EX_HC02020[e]'.('R_EX_HC02020[e]')
    'ER_XOL27OHte'.('R_XOL27OHte')
    'ER_EX_xol27oh[e]'.('R_EX_xol27oh[e]')
    'ER_XOL25OHtr'.('R_XOL25OHtr')
    'ER_XOL25OHte'.('R_XOL25OHte')
    'ER_EX_xol25oh[e]'.('R_EX_xol25oh[e]')
    'ER_DSMSTEROLtr'.('R_DSMSTEROLtr')
    'ER_DSMSTEROLte'.('R_DSMSTEROLte')
    'ER_EX_dsmsterol[e]'.('R_EX_dsmsterol[e]')
    'ER_CHSTEROLSte'.('R_CHSTEROLSte')
    'ER_EX_chsterols[e]'.('R_EX_chsterols[e]')
    'ER_3ITYR_Lte'.('R_3ITYR_Lte')
    'ER_EX_3ityr_L[e]'.('R_EX_3ityr_L[e]')
    'ER_35DIODTYRte'.('R_35DIODTYRte')
    'ER_EX_35diotyr[e]'.('R_EX_35diotyr[e]')
    'ER_13_CIS_RETNte'.('R_13_CIS_RETNte')
    'ER_EX_13_cis_retn[e]'.('R_EX_13_cis_retn[e]')
    'ER_LDL_HSDEG'.('R_LDL_HSDEG')
    'ER_EX_34dhoxmand[e]'.('R_EX_34dhoxmand[e]')
    'ER_EX_CE7090[e]'.('R_EX_CE7090[e]')
    'ER_EX_CE7085[e]'.('R_EX_CE7085[e]')
    'ER_EX_CE7096[e]'.('R_EX_CE7096[e]')
    'ER_EX_CE4877[e]'.('R_EX_CE4877[e]')
    'ER_EX_CE1447[e]'.('R_EX_CE1447[e]')
    'ER_EX_CE6205[e]'.('R_EX_CE6205[e]')
    'ER_EX_trypta[e]'.('R_EX_trypta[e]')
    'ER_C05767te'.('R_C05767te')
    'ER_EX_C05767[e]'.('R_EX_C05767[e]')
    'ER_C05770te3'.('R_C05770te3')
    'ER_EX_C05770[e]'.('R_EX_C05770[e]')
    'ER_EX_mhista[e]'.('R_EX_mhista[e]')
    'ER_PPBNGte'.('R_PPBNGte')
    'ER_EX_ppbng[e]'.('R_EX_ppbng[e]')
    'ER_EX_mma[e]'.('R_EX_mma[e]')
    'ER_12PPDRte'.('R_12PPDRte')
    'ER_EX_12ppd_R[e]'.('R_EX_12ppd_R[e]')
    'ER_AMETAMte'.('R_AMETAMte')
    'ER_EX_ametam[e]'.('R_EX_ametam[e]')
    'ER_XYLULte'.('R_XYLULte')
    'ER_EX_xylu_L[e]'.('R_EX_xylu_L[e]')
    'ER_XYLUDte'.('R_XYLUDte')
    'ER_EX_xylu_D[e]'.('R_EX_xylu_D[e]')
    'ER_GLCNte'.('R_GLCNte')
    'ER_SPHGNSte'.('R_SPHGNSte')
    'ER_EX_sphings[e]'.('R_EX_sphings[e]')
    'ER_HDD2CRNte'.('R_HDD2CRNte')
    'ER_EX_hdd2crn[e]'.('R_EX_hdd2crn[e]')
    'ER_IM4ACte'.('R_IM4ACte')
    'ER_EX_im4ac[e]'.('R_EX_im4ac[e]')
    'ER_EX_CE1918[e]'.('R_EX_CE1918[e]')
    'ER_EX_mlthf[e]'.('R_EX_mlthf[e]')
    'ER_EX_CE2705[e]'.('R_EX_CE2705[e]')
    'ER_SPHGNte'.('R_SPHGNte')
    'ER_EX_sphgn[e]'.('R_EX_sphgn[e]')
    'ER_EX_N1aspmd[e]'.('R_EX_N1aspmd[e]')
    'ER_C13856te'.('R_C13856te')
    'ER_EX_1a25dhvitd3[e]'.('R_EX_1a25dhvitd3[e]')
    'ER_PRISTte'.('R_PRISTte')
    'ER_EX_prist[e]'.('R_EX_prist[e]')
    'ER_CE2049te'.('R_CE2049te')
    'ER_EX_CE2049[e]'.('R_EX_CE2049[e]')
    'ER_CE2047te'.('R_CE2047te')
    'ER_EX_CE2047[e]'.('R_EX_CE2047[e]')
    'ER_LANOSTte'.('R_LANOSTte')
    'ER_FDPte'.('R_FDPte')
    'ER_EX_fdp[e]'.('R_EX_fdp[e]')
    'ER_EX_coke[e]'.('R_EX_coke[e]')
    'ER_COKEte'.('R_COKEte')
    'ER_COKEtr'.('R_COKEtr')
    'ER_EX_5a2opntn[e]'.('R_EX_5a2opntn[e]')
    'ER_5A2OPNTNte'.('R_5A2OPNTNte')
    'ER_5A2OPNTNtx'.('R_5A2OPNTNtx')
    'ER_ARG_Dtx'.('R_ARG_Dtx')
    'ER_ARG_Dte'.('R_ARG_Dte')
    'ER_EX_arg_D[e]'.('R_EX_arg_D[e]')
    'ER_LANOSTtr'.('R_LANOSTtr')
    'ER_EX_ldl_hs[e]'.('R_EX_ldl_hs[e]')
    'ER_EX_HC00005[e]'.('R_EX_HC00005[e]')
    'ER_CE1261t'.('R_CE1261t')
    'ER_DOPAOQNOX'.('R_DOPAOQNOX')
    'ER_DOPAOQCYS'.('R_DOPAOQCYS')
    'ER_DACT'.('R_DACT')
    'ER_CE5629t'.('R_CE5629t')
    'ER_EX_CE5629[e]'.('R_EX_CE5629[e]')
    'ER_CRMte'.('R_CRMte')
    'ER_EX_gd3_hs[e]'.('R_EX_gd3_hs[e]')
    'ER_EX_gluside_hs[e]'.('R_EX_gluside_hs[e]')
    'ER_GALGLUSIDEtg2'.('R_GALGLUSIDEtg2')
    'ER_GD3tg'.('R_GD3tg')
    'ER_GD3tl'.('R_GD3tl')
    'ER_GLUSIDEte'.('R_GLUSIDEte')
    'ER_GLUSIDEtg'.('R_GLUSIDEtg')
    'ER_GLUSIDEtl'.('R_GLUSIDEtl')
    'ER_GM1tg'.('R_GM1tg')
    'ER_GM1tl'.('R_GM1tl')
    'ER_SPHMYLNtl2'.('R_SPHMYLNtl2')
    'ER_RE3477C1'.('R_RE3477C1')
    'ER_NH4tr'.('R_NH4tr')
    'ER_UDPGALt2n'.('R_UDPGALt2n')
    'ER_THCRMtl'.('R_THCRMtl')
    'ER_DAG_HStg'.('R_DAG_HStg')
    'ER_SPHGNtn'.('R_SPHGNtn')
    'ER_SPHGNtg'.('R_SPHGNtg')
    'ER_SPHINGStn'.('R_SPHINGStn')
    'ER_SPHINGStg'.('R_SPHINGStg')
    'ER_DHCRMtg'.('R_DHCRMtg')
    'ER_GDA1tn'.('R_GDA1tn')
    'ER_sink_34dhpac[c]'.('R_sink_34dhpac[c]')
    'ER_34DHPEt'.('R_34DHPEt')
    'ER_EX_34dhpe[e]'.('R_EX_34dhpe[e]')
    'ER_DM_sph1p[n]'.('R_DM_sph1p[n]')
    'ER_DM_sphs1p[n]'.('R_DM_sphs1p[n]')
    'ER_DM_gm1_hs[n]'.('R_DM_gm1_hs[n]')
    'ER_DM_gda1_hs[n]'.('R_DM_gda1_hs[n]')
    'ER_DM_6hddopaqn[c]'.('R_DM_6hddopaqn[c]')
    'ER_GALSIDEtn'.('R_GALSIDEtn')
    'ER_CERT1tn'.('R_CERT1tn')
    'ER_Rtotaltg'.('R_Rtotaltg')
    'ER_GD1Atg'.('R_GD1Atg')
    'ER_GD1Atn'.('R_GD1Atn')
    'ER_ATPtg'.('R_ATPtg')
    'ER_GD3tlc'.('R_GD3tlc')
    'ER_GD3tm'.('R_GD3tm')
    'ER_DM_pail35p_hs[n]'.('R_DM_pail35p_hs[n]')
    'ER_DM_gd3_hs[m]'.('R_DM_gd3_hs[m]')
    'ER_CATr'.('R_CATr')
    'ER_S2L2N2M2Mtl'.('R_S2L2N2M2Mtl')
    'ER_DM_k[g]'.('R_DM_k[g]')
    'ER_DM_na1[g]'.('R_DM_na1[g]')
    'ER_DM_retn[n]'.('R_DM_retn[n]')
    'ER_DM_15HPET[n]'.('R_DM_15HPET[n]')
    'ER_DM_15HPET[x]'.('R_DM_15HPET[x]')
    'ER_DM_15HPET[r]'.('R_DM_15HPET[r]')
    'ER_sink_Ser_Gly_Ala_X_Gly[r]'.('R_sink_Ser_Gly_Ala_X_Gly[r]')
    'ER_EX_pail_hs[e]'.('R_EX_pail_hs[e]')
    'ER_EX_CE5026[e]'.('R_EX_CE5026[e]')
    'ER_EX_CE1261[e]'.('R_EX_CE1261[e]')
    'ER_EX_galgluside_hs[e]'.('R_EX_galgluside_hs[e]')
    'ER_EX_gm1_hs[e]'.('R_EX_gm1_hs[e]')
    'ER_HMR_0015'.('R_HMR_0015')
    'ER_HMR_0020'.('R_HMR_0020')
    'ER_HMR_0157'.('R_HMR_0157')
    'ER_HMR_0166'.('R_HMR_0166')
    'ER_HMR_0172'.('R_HMR_0172')
    'ER_HMR_0178'.('R_HMR_0178')
    'ER_HMR_0182'.('R_HMR_0182')
    'ER_HMR_0185'.('R_HMR_0185')
    'ER_HMR_0763'.('R_HMR_0763')
    'ER_HMR_0769'.('R_HMR_0769')
    'ER_HMR_0771'.('R_HMR_0771')
    'ER_HMR_0809'.('R_HMR_0809')
    'ER_HMR_0831'.('R_HMR_0831')
    'ER_HMR_0912'.('R_HMR_0912')
    'ER_HMR_0913'.('R_HMR_0913')
    'ER_HMR_0962'.('R_HMR_0962')
    'ER_HMR_0984'.('R_HMR_0984')
    'ER_HMR_1095'.('R_HMR_1095')
    'ER_HMR_1104'.('R_HMR_1104')
    'ER_HMR_1135'.('R_HMR_1135')
    'ER_HMR_1242'.('R_HMR_1242')
    'ER_HMR_1243'.('R_HMR_1243')
    'ER_HMR_1283'.('R_HMR_1283')
    'ER_HMR_1284'.('R_HMR_1284')
    'ER_HMR_1306'.('R_HMR_1306')
    'ER_HMR_1311'.('R_HMR_1311')
    'ER_HMR_1315'.('R_HMR_1315')
    'ER_HMR_1316'.('R_HMR_1316')
    'ER_HMR_1317'.('R_HMR_1317')
    'ER_HMR_1332'.('R_HMR_1332')
    'ER_HMR_1623'.('R_HMR_1623')
    'ER_HMR_1701'.('R_HMR_1701')
    'ER_HMR_1744'.('R_HMR_1744')
    'ER_HMR_1745'.('R_HMR_1745')
    'ER_HMR_1752'.('R_HMR_1752')
    'ER_HMR_1753'.('R_HMR_1753')
    'ER_HMR_1758'.('R_HMR_1758')
    'ER_HMR_1759'.('R_HMR_1759')
    'ER_HMR_1834'.('R_HMR_1834')
    'ER_HMR_2087'.('R_HMR_2087')
    'ER_HMR_2090'.('R_HMR_2090')
    'ER_HMR_2127'.('R_HMR_2127')
    'ER_HMR_2374'.('R_HMR_2374')
    'ER_HMR_2376'.('R_HMR_2376')
    'ER_HMR_2391'.('R_HMR_2391')
    'ER_HMR_2393'.('R_HMR_2393')
    'ER_HMR_2495'.('R_HMR_2495')
    'ER_HMR_2569'.('R_HMR_2569')
    'ER_HMR_2571'.('R_HMR_2571')
    'ER_HMR_3053'.('R_HMR_3053')
    'ER_HMR_3056'.('R_HMR_3056')
    'ER_HMR_3106'.('R_HMR_3106')
    'ER_HMR_3396'.('R_HMR_3396')
    'ER_HMR_3397'.('R_HMR_3397')
    'ER_HMR_3478'.('R_HMR_3478')
    'ER_HMR_3520'.('R_HMR_3520')
    'ER_HMR_3597'.('R_HMR_3597')
    'ER_HMR_3951'.('R_HMR_3951')
    'ER_HMR_3953'.('R_HMR_3953')
    'ER_HMR_3996'.('R_HMR_3996')
    'ER_HMR_4078'.('R_HMR_4078')
    'ER_HMR_4266'.('R_HMR_4266')
    'ER_HMR_4664'.('R_HMR_4664')
    'ER_HMR_4672'.('R_HMR_4672')
    'ER_HMR_4782'.('R_HMR_4782')
    'ER_HMR_4783'.('R_HMR_4783')
    'ER_HMR_4831'.('R_HMR_4831')
    'ER_HMR_4957'.('R_HMR_4957')
    'ER_HMR_5101'.('R_HMR_5101')
    'ER_HMR_5409'.('R_HMR_5409')
    'ER_HMR_6500'.('R_HMR_6500')
    'ER_HMR_6611'.('R_HMR_6611')
    'ER_HMR_6629'.('R_HMR_6629')
    'ER_HMR_6784'.('R_HMR_6784')
    'ER_HMR_6785'.('R_HMR_6785')
    'ER_HMR_6786'.('R_HMR_6786')
    'ER_HMR_7198'.('R_HMR_7198')
    'ER_HMR_7330'.('R_HMR_7330')
    'ER_HMR_7712'.('R_HMR_7712')
    'ER_HMR_7715'.('R_HMR_7715')
    'ER_HMR_7898'.('R_HMR_7898')
    'ER_HMR_7900'.('R_HMR_7900')
    'ER_HMR_7944'.('R_HMR_7944')
    'ER_HMR_7977'.('R_HMR_7977')
    'ER_HMR_8023'.('R_HMR_8023')
    'ER_HMR_8084'.('R_HMR_8084')
    'ER_HMR_8086'.('R_HMR_8086')
    'ER_HMR_8090'.('R_HMR_8090')
    'ER_HMR_8374'.('R_HMR_8374')
    'ER_HMR_8418'.('R_HMR_8418')
    'ER_HMR_8505'.('R_HMR_8505')
    'ER_HMR_8562'.('R_HMR_8562')
    'ER_HMR_8567'.('R_HMR_8567')
    'ER_HMR_8776'.('R_HMR_8776')
    'ER_HMR_9019'.('R_HMR_9019')
    'ER_HMR_9174'.('R_HMR_9174')
    'ER_HMR_9175'.('R_HMR_9175')
    'ER_HMR_9176'.('R_HMR_9176')
    'ER_HMR_9179'.('R_HMR_9179')
    'ER_HMR_9180'.('R_HMR_9180')
    'ER_HMR_9184'.('R_HMR_9184')
    'ER_HMR_9185'.('R_HMR_9185')
    'ER_HMR_9188'.('R_HMR_9188')
    'ER_HMR_9189'.('R_HMR_9189')
    'ER_HMR_9612'.('R_HMR_9612')
    'ER_HMR_9625'.('R_HMR_9625')
    'ER_HMR_9626'.('R_HMR_9626')
    'ER_HMR_9627'.('R_HMR_9627')
    'ER_HMR_9628'.('R_HMR_9628')
    'ER_HMR_9634'.('R_HMR_9634')
    'ER_HMR_9638'.('R_HMR_9638')
    'ER_HMR_9639'.('R_HMR_9639')
    'ER_HMR_9640'.('R_HMR_9640')
    'ER_HMR_9647'.('R_HMR_9647')
    'ER_HMR_9648'.('R_HMR_9648')
    'ER_HMR_9652'.('R_HMR_9652')
    'ER_HMR_9665'.('R_HMR_9665')
    'ER_HMR_9667'.('R_HMR_9667')
    'ER_HMR_9676'.('R_HMR_9676')
    'ER_HMR_9678'.('R_HMR_9678')
    'ER_HMR_9679'.('R_HMR_9679')
    'ER_HMR_9680'.('R_HMR_9680')
    'ER_HMR_9718'.('R_HMR_9718')
    'ER_HMR_9720'.('R_HMR_9720')
    'ER_HMR_9797'.('R_HMR_9797')
    'ER_HMR_6672'.('R_HMR_6672')
    'ER_EX_nadh[e]'.('R_EX_nadh[e]')
    'ER_EX_glc_D[e]'.('R_EX_glc_D[e]')
    'ER_EX_sbt_D[e]'.('R_EX_sbt_D[e]')
    'ER_CDCA24Gtr'.('R_CDCA24Gtr')
    'ER_CDCA3Gtr'.('R_CDCA3Gtr')
    'ER_DM_12dhchol[c]'.('R_DM_12dhchol[c]')
    'ER_DM_3dhcdchol[c]'.('R_DM_3dhcdchol[c]')
    'ER_DM_3dhchol[c]'.('R_DM_3dhchol[c]')
    'ER_DM_3dhdchol[c]'.('R_DM_3dhdchol[c]')
    'ER_DM_3dhlchol[c]'.('R_DM_3dhlchol[c]')
    'ER_DM_7dhcdchol[c]'.('R_DM_7dhcdchol[c]')
    'ER_DM_7dhchol[c]'.('R_DM_7dhchol[c]')
    'ER_DM_cdca24g[c]'.('R_DM_cdca24g[c]')
    'ER_DM_cdca3g[c]'.('R_DM_cdca3g[c]')
    'ER_DM_coprost[c]'.('R_DM_coprost[c]')
    'ER_DM_hca24g[c]'.('R_DM_hca24g[c]')
    'ER_DM_hdca24g[c]'.('R_DM_hdca24g[c]')
    'ER_DM_hdca6g[c]'.('R_DM_hdca6g[c]')
    'ER_DM_hyochol[c]'.('R_DM_hyochol[c]')
    'ER_DM_icdchol[c]'.('R_DM_icdchol[c]')
    'ER_DM_isochol[c]'.('R_DM_isochol[c]')
    'ER_DM_lca24g[c]'.('R_DM_lca24g[c]')
    'ER_DM_lca3g[c]'.('R_DM_lca3g[c]')
    'ER_DM_thyochol[c]'.('R_DM_thyochol[c]')
    'ER_DM_uchol[c]'.('R_DM_uchol[c]')
    'ER_EX_12dhchol[e]'.('R_EX_12dhchol[e]')
    'ER_EX_3dhcdchol[e]'.('R_EX_3dhcdchol[e]')
    'ER_EX_3dhchol[e]'.('R_EX_3dhchol[e]')
    'ER_EX_3dhdchol[e]'.('R_EX_3dhdchol[e]')
    'ER_EX_3dhlchol[e]'.('R_EX_3dhlchol[e]')
    'ER_EX_7dhcdchol[e]'.('R_EX_7dhcdchol[e]')
    'ER_EX_7dhchol[e]'.('R_EX_7dhchol[e]')
    'ER_EX_cdca24g[e]'.('R_EX_cdca24g[e]')
    'ER_EX_cdca3g[e]'.('R_EX_cdca3g[e]')
    'ER_EX_coprost[e]'.('R_EX_coprost[e]')
    'ER_EX_hca24g[e]'.('R_EX_hca24g[e]')
    'ER_EX_hdca24g[e]'.('R_EX_hdca24g[e]')
    'ER_EX_hdca6g[e]'.('R_EX_hdca6g[e]')
    'ER_EX_hyochol[e]'.('R_EX_hyochol[e]')
    'ER_EX_icdchol[e]'.('R_EX_icdchol[e]')
    'ER_EX_isochol[e]'.('R_EX_isochol[e]')
    'ER_EX_lca24g[e]'.('R_EX_lca24g[e]')
    'ER_EX_lca3g[e]'.('R_EX_lca3g[e]')
    'ER_EX_thyochol[e]'.('R_EX_thyochol[e]')
    'ER_EX_uchol[e]'.('R_EX_uchol[e]')
    'ER_HCA24Gtr'.('R_HCA24Gtr')
    'ER_HDCA6Gtr'.('R_HDCA6Gtr')
    'ER_HYOCHOLtr'.('R_HYOCHOLtr')
    'ER_LCA24Gtr'.('R_LCA24Gtr')
    'ER_LCA3Gtr'.('R_LCA3Gtr')
    'ER_M02155tr'.('R_M02155tr')
    'ER_12HTACRtep'.('R_12HTACRtep')
    'ER_14MDZtev'.('R_14MDZtev')
    'ER_1HIBUPGLUC_Sthv'.('R_1HIBUPGLUC_Sthv')
    'ER_1HIBUP_Sthv'.('R_1HIBUP_Sthv')
    'ER_1HMDZGLUChc'.('R_1HMDZGLUChc')
    'ER_1OHMDZtep'.('R_1OHMDZtep')
    'ER_2HATVACIDtep'.('R_2HATVACIDtep')
    'ER_2HATVLACtep'.('R_2HATVLACtep')
    'ER_2HIBUPGLUC_Sthv'.('R_2HIBUPGLUC_Sthv')
    'ER_2HIBUP_Rthv'.('R_2HIBUP_Rthv')
    'ER_2HIBUP_Sthv'.('R_2HIBUP_Sthv')
    'ER_35DSMVteb'.('R_35DSMVteb')
    'ER_3HIBUPGLUC_Sthv'.('R_3HIBUPGLUC_Sthv')
    'ER_3HIBUP_Rthv'.('R_3HIBUP_Rthv')
    'ER_3HIBUP_Sthv'.('R_3HIBUP_Sthv')
    'ER_3HLVSTACtbc'.('R_3HLVSTACtbc')
    'ER_3HPVSTETtev'.('R_3HPVSTETtev')
    'ER_3HPVStep'.('R_3HPVStep')
    'ER_3HSMVACIDteb'.('R_3HSMVACIDteb')
    'ER_3ISPVStep'.('R_3ISPVStep')
    'ER_3MEACMPhc'.('R_3MEACMPhc')
    'ER_3OHACMPtev'.('R_3OHACMPtev')
    'ER_4HATVACIDtep'.('R_4HATVACIDtep')
    'ER_4HATVLACtep'.('R_4HATVLACtep')
    'ER_4HMDGLUCtev'.('R_4HMDGLUCtev')
    'ER_4OHMDZtev'.('R_4OHMDZtev')
    'ER_56DHPVStev'.('R_56DHPVStev')
    'ER_56EPPVStev'.('R_56EPPVStev')
    'ER_5OHFVSGLUhc'.('R_5OHFVSGLUhc')
    'ER_5OHFVSGLUtev'.('R_5OHFVSGLUtev')
    'ER_5OHFVSteb'.('R_5OHFVSteb')
    'ER_6BHGLZtev'.('R_6BHGLZtev')
    'ER_6CSMVACIDteb'.('R_6CSMVACIDteb')
    'ER_6EPVStep'.('R_6EPVStep')
    'ER_6HLVSTthep'.('R_6HLVSTthep')
    'ER_6HMSMVACIDteb'.('R_6HMSMVACIDteb')
    'ER_6HSMVACIDteb'.('R_6HSMVACIDteb')
    'ER_6MELVSTthep'.('R_6MELVSTthep')
    'ER_6OHFVSGLUhc'.('R_6OHFVSGLUhc')
    'ER_6OHFVSGLUtev'.('R_6OHFVSGLUtev')
    'ER_7BHGLZtev'.('R_7BHGLZtev')
    'ER_7HPVStev'.('R_7HPVStev')
    'ER_ACMPdt'.('R_ACMPdt')
    'ER_AM1CSAtep'.('R_AM1CSAtep')
    'ER_AM9CSAtep'.('R_AM9CSAtep')
    'ER_ATVACIDhr'.('R_ATVACIDhr')
    'ER_ATVACIDtdu'.('R_ATVACIDtdu')
    'ER_ATVLACh2r'.('R_ATVLACh2r')
    'ER_ATVLAChr'.('R_ATVLAChr')
    'ER_ATVLACtdhc'.('R_ATVLACtdhc')
    'ER_Am19CStev'.('R_Am19CStev')
    'ER_CARBIBUP_SGLUthv'.('R_CARBIBUP_SGLUthv')
    'ER_CARIBUP_Sthv'.('R_CARIBUP_Sthv')
    'ER_CRVSM24tev'.('R_CRVSM24tev')
    'ER_CRVStu'.('R_CRVStu')
    'ER_CSAtd'.('R_CSAtd')
    'ER_DEOXFVStev'.('R_DEOXFVStev')
    'ER_DSPVStev'.('R_DSPVStev')
    'ER_EPOXTAChr'.('R_EPOXTAChr')
    'ER_EPOXTACtev'.('R_EPOXTACtev')
    'ER_EX_12htacr[e]'.('R_EX_12htacr[e]')
    'ER_EX_14hmdz[e]'.('R_EX_14hmdz[e]')
    'ER_EX_1hibup_S[e]'.('R_EX_1hibup_S[e]')
    'ER_EX_1hibupglu_S[e]'.('R_EX_1hibupglu_S[e]')
    'ER_EX_1hmdgluc[e]'.('R_EX_1hmdgluc[e]')
    'ER_EX_1ohmdz[e]'.('R_EX_1ohmdz[e]')
    'ER_EX_2hatvacid[e]'.('R_EX_2hatvacid[e]')
    'ER_EX_2hatvlac[e]'.('R_EX_2hatvlac[e]')
    'ER_EX_2hatvlacgluc[e]'.('R_EX_2hatvlacgluc[e]')
    'ER_EX_2hibup_R[e]'.('R_EX_2hibup_R[e]')
    'ER_EX_2hibup_S[e]'.('R_EX_2hibup_S[e]')
    'ER_EX_2hibupglu_S[e]'.('R_EX_2hibupglu_S[e]')
    'ER_EX_35dsmv[e]'.('R_EX_35dsmv[e]')
    'ER_EX_3hibup_R[e]'.('R_EX_3hibup_R[e]')
    'ER_EX_3hibup_S[e]'.('R_EX_3hibup_S[e]')
    'ER_EX_3hibupglu_S[e]'.('R_EX_3hibupglu_S[e]')
    'ER_EX_3hlvstacid[e]'.('R_EX_3hlvstacid[e]')
    'ER_EX_3hpvs[e]'.('R_EX_3hpvs[e]')
    'ER_EX_3hpvstet[e]'.('R_EX_3hpvstet[e]')
    'ER_EX_3hsmvacid[e]'.('R_EX_3hsmvacid[e]')
    'ER_EX_3ohacmp[e]'.('R_EX_3ohacmp[e]')
    'ER_EX_4hatvacid[e]'.('R_EX_4hatvacid[e]')
    'ER_EX_4hatvlac[e]'.('R_EX_4hatvlac[e]')
    'ER_EX_4hmdgluc[e]'.('R_EX_4hmdgluc[e]')
    'ER_EX_4ohmdz[e]'.('R_EX_4ohmdz[e]')
    'ER_EX_5ohfvs[e]'.('R_EX_5ohfvs[e]')
    'ER_EX_5ohfvsglu[e]'.('R_EX_5ohfvsglu[e]')
    'ER_EX_6bhglz[e]'.('R_EX_6bhglz[e]')
    'ER_EX_6csmvacid[e]'.('R_EX_6csmvacid[e]')
    'ER_EX_6hlvst[e]'.('R_EX_6hlvst[e]')
    'ER_EX_6hmsmvacid[e]'.('R_EX_6hmsmvacid[e]')
    'ER_EX_6hsmvacid[e]'.('R_EX_6hsmvacid[e]')
    'ER_EX_6melvacid[e]'.('R_EX_6melvacid[e]')
    'ER_EX_6melvst[e]'.('R_EX_6melvst[e]')
    'ER_EX_6ohfvsglu[e]'.('R_EX_6ohfvsglu[e]')
    'ER_EX_7bhglz[e]'.('R_EX_7bhglz[e]')
    'ER_EX_acmp[e]'.('R_EX_acmp[e]')
    'ER_EX_am19cs[e]'.('R_EX_am19cs[e]')
    'ER_EX_am1csa[e]'.('R_EX_am1csa[e]')
    'ER_EX_am9csa[e]'.('R_EX_am9csa[e]')
    'ER_EX_atvacid[e]'.('R_EX_atvacid[e]')
    'ER_EX_atvlac[e]'.('R_EX_atvlac[e]')
    'ER_EX_caribup_s[e]'.('R_EX_caribup_s[e]')
    'ER_EX_caribupglu_S[e]'.('R_EX_caribupglu_S[e]')
    'ER_EX_crvs[e]'.('R_EX_crvs[e]')
    'ER_EX_crvsm24[e]'.('R_EX_crvsm24[e]')
    'ER_EX_csa[e]'.('R_EX_csa[e]')
    'ER_EX_deoxfvs[e]'.('R_EX_deoxfvs[e]')
    'ER_EX_epoxtac[e]'.('R_EX_epoxtac[e]')
    'ER_EX_fvs[e]'.('R_EX_fvs[e]')
    'ER_EX_glc3meacp[e]'.('R_EX_glc3meacp[e]')
    'ER_EX_glz[e]'.('R_EX_glz[e]')
    'ER_EX_ibup_R[e]'.('R_EX_ibup_R[e]')
    'ER_EX_ibup_S[e]'.('R_EX_ibup_S[e]')
    'ER_EX_ibupgluc[e]'.('R_EX_ibupgluc[e]')
    'ER_EX_isolvstacid[e]'.('R_EX_isolvstacid[e]')
    'ER_EX_lstn[e]'.('R_EX_lstn[e]')
    'ER_EX_lstnm7[e]'.('R_EX_lstnm7[e]')
    'ER_EX_lvst[e]'.('R_EX_lvst[e]')
    'ER_EX_mdz[e]'.('R_EX_mdz[e]')
    'ER_EX_nfdac[e]'.('R_EX_nfdac[e]')
    'ER_EX_nfdoh[e]'.('R_EX_nfdoh[e]')
    'ER_EX_profvs[e]'.('R_EX_profvs[e]')
    'ER_EX_ptvst[e]'.('R_EX_ptvst[e]')
    'ER_EX_ptvstlac[e]'.('R_EX_ptvstlac[e]')
    'ER_EX_pvs[e]'.('R_EX_pvs[e]')
    'ER_EX_smv[e]'.('R_EX_smv[e]')
    'ER_EX_smvacid[e]'.('R_EX_smvacid[e]')
    'ER_EX_tacr[e]'.('R_EX_tacr[e]')
    'ER_EX_tlacfvs[e]'.('R_EX_tlacfvs[e]')
    'ER_FVShc'.('R_FVShc')
    'ER_FVStep'.('R_FVStep')
    'ER_GLC3MEACPtev'.('R_GLC3MEACPtev')
    'ER_GLZtd'.('R_GLZtd')
    'ER_IBUPGLUCtchep'.('R_IBUPGLUCtchep')
    'ER_IBUPGLUCtpvb'.('R_IBUPGLUCtpvb')
    'ER_IBUP_Rtdhep'.('R_IBUP_Rtdhep')
    'ER_IBUP_Rtdu'.('R_IBUP_Rtdu')
    'ER_IBUP_Stdhep'.('R_IBUP_Stdhep')
    'ER_IBUP_Stdu'.('R_IBUP_Stdu')
    'ER_ISOLVSTAChep'.('R_ISOLVSTAChep')
    'ER_LSTNM7TDhc'.('R_LSTNM7TDhc')
    'ER_LSTNM7thc'.('R_LSTNM7thc')
    'ER_LSTNRATt'.('R_LSTNRATt')
    'ER_LSTNtd'.('R_LSTNtd')
    'ER_LVACLAChep'.('R_LVACLAChep')
    'ER_LVSTtu'.('R_LVSTtu')
    'ER_MDZtd'.('R_MDZtd')
    'ER_NFDACtep'.('R_NFDACtep')
    'ER_NFDOHtep'.('R_NFDOHtep')
    'ER_OXYPtepv'.('R_OXYPtepv')
    'ER_PROFVShc'.('R_PROFVShc')
    'ER_PROFVStev'.('R_PROFVStev')
    'ER_PTVSTLAChc'.('R_PTVSTLAChc')
    'ER_PTVSTLACtev'.('R_PTVSTLACtev')
    'ER_PTVSTtep'.('R_PTVSTtep')
    'ER_PVSGLUCtev'.('R_PVSGLUCtev')
    'ER_PVSHtu'.('R_PVSHtu')
    'ER_PVStep'.('R_PVStep')
    'ER_RSVGLUChc'.('R_RSVGLUChc')
    'ER_RSVLAChv'.('R_RSVLAChv')
    'ER_SMVACIDtev'.('R_SMVACIDtev')
    'ER_SMVtv'.('R_SMVtv')
    'ER_TACRDtsc'.('R_TACRDtsc')
    'ER_TLACFVStev'.('R_TLACFVStev')
    'ER_TRIPVStev'.('R_TRIPVStev')
    'ER_12HTACRitr'.('R_12HTACRitr')
    'ER_14HMDZitr'.('R_14HMDZitr')
    'ER_1HIBUP_Sitr'.('R_1HIBUP_Sitr')
    'ER_1HIBUPGLUitr'.('R_1HIBUPGLUitr')
    'ER_1HMDGLUCitr'.('R_1HMDGLUCitr')
    'ER_2HATVLACGLUCitr'.('R_2HATVLACGLUCitr')
    'ER_2HIBUP_Ritr'.('R_2HIBUP_Ritr')
    'ER_2HIBUP_Sitr'.('R_2HIBUP_Sitr')
    'ER_2HIBUPGLUC_Sitr'.('R_2HIBUPGLUC_Sitr')
    'ER_35DSMVitr'.('R_35DSMVitr')
    'ER_3HIBUP_Ritr'.('R_3HIBUP_Ritr')
    'ER_3HIBUPGLUC_Sitr'.('R_3HIBUPGLUC_Sitr')
    'ER_3HLVSTitr'.('R_3HLVSTitr')
    'ER_3HPVSitr'.('R_3HPVSitr')
    'ER_3HPVSCOAitm'.('R_3HPVSCOAitm')
    'ER_3HPVSCOAitx'.('R_3HPVSCOAitx')
    'ER_3HPVSTETCOAitm'.('R_3HPVSTETCOAitm')
    'ER_3HPVSTETCOAitx'.('R_3HPVSTETCOAitx')
    'ER_3HSMVitr'.('R_3HSMVitr')
    'ER_3MEACMPitr'.('R_3MEACMPitr')
    'ER_3OHACMPitr'.('R_3OHACMPitr')
    'ER_4HATVACIDitr'.('R_4HATVACIDitr')
    'ER_4HATVLACitr'.('R_4HATVLACitr')
    'ER_4HMDGLUCitr'.('R_4HMDGLUCitr')
    'ER_4OHMDZitr'.('R_4OHMDZitr')
    'ER_5OHFVSitr'.('R_5OHFVSitr')
    'ER_5OHFVSGLUitr'.('R_5OHFVSGLUitr')
    'ER_6CSMVitr'.('R_6CSMVitr')
    'ER_6HLVSTitr'.('R_6HLVSTitr')
    'ER_6HLVSTACIDitr'.('R_6HLVSTACIDitr')
    'ER_6HMSMVitr'.('R_6HMSMVitr')
    'ER_6HSMVitr'.('R_6HSMVitr')
    'ER_6MELVACIDitr'.('R_6MELVACIDitr')
    'ER_6MELVSTitr'.('R_6MELVSTitr')
    'ER_6OHFVSGLUitr'.('R_6OHFVSGLUitr')
    'ER_ACMPitr'.('R_ACMPitr')
    'ER_AM19CSitr'.('R_AM19CSitr')
    'ER_CARIBUP_Sitr'.('R_CARIBUP_Sitr')
    'ER_CARIBUPGLU_Sitr'.('R_CARIBUPGLU_Sitr')
    'ER_CRVSitr'.('R_CRVSitr')
    'ER_CRVSM24itr'.('R_CRVSM24itr')
    'ER_CSAitr'.('R_CSAitr')
    'ER_DEOXFVSitx'.('R_DEOXFVSitx')
    'ER_EPOXTACitr'.('R_EPOXTACitr')
    'ER_FVSitx'.('R_FVSitx')
    'ER_FVSCOAitx'.('R_FVSCOAitx')
    'ER_GLC3MEACPitr'.('R_GLC3MEACPitr')
    'ER_GLZitr'.('R_GLZitr')
    'ER_IBUP_Ritr'.('R_IBUP_Ritr')
    'ER_IBUP_Sitr'.('R_IBUP_Sitr')
    'ER_IBUPGLUCitr'.('R_IBUPGLUCitr')
    'ER_LSTNitr'.('R_LSTNitr')
    'ER_LSTNM7itr'.('R_LSTNM7itr')
    'ER_LVSTitr'.('R_LVSTitr')
    'ER_LVSTACIDitr'.('R_LVSTACIDitr')
    'ER_MDZitr'.('R_MDZitr')
    'ER_NFDOHitr'.('R_NFDOHitr')
    'ER_PROFVSCOAitx'.('R_PROFVSCOAitx')
    'ER_PTVSTLACitr'.('R_PTVSTLACitr')
    'ER_PTVSTM13itr'.('R_PTVSTM13itr')
    'ER_PTVSTM13te'.('R_PTVSTM13te')
    'ER_EX_ptvstm13[e]'.('R_EX_ptvstm13[e]')
    'ER_PVSitr'.('R_PVSitr')
    'ER_RSVLACitr'.('R_RSVLACitr')
    'ER_TACRitr'.('R_TACRitr')
    'ER_TLACFVSitr'.('R_TLACFVSitr')
    'ER_3HPVSCOAhc'.('R_3HPVSCOAhc')
    'ER_3HPVSTEThc'.('R_3HPVSTEThc')
    'ER_FVSCOAhc'.('R_FVSCOAhc')
    'ER_1OHMDZitr'.('R_1OHMDZitr')
    'ER_NFDACitr'.('R_NFDACitr')
    'ER_H2O2itr'.('R_H2O2itr')
    'ER_ATVACIDitr'.('R_ATVACIDitr')
    'ER_ATVLACitr'.('R_ATVLACitr')
    'ER_SMVitr'.('R_SMVitr')
    'ER_6BHGLZitr'.('R_6BHGLZitr')
    'ER_7BHGLZitr'.('R_7BHGLZitr')
    'ER_RSVitr'.('R_RSVitr')
    'ER_PTVSTitr'.('R_PTVSTitr')
    'ER_3HIBUP_Sitr'.('R_3HIBUP_Sitr')
    'ER_FVSitr'.('R_FVSitr')
    'ER_AM1CSAitr'.('R_AM1CSAitr')
    'ER_AM9CSAitr'.('R_AM9CSAitr')
    'ER_2HATVACIDitr'.('R_2HATVACIDitr')
    'ER_EX_caproic[e]'.('R_EX_caproic[e]')
    'ER_1A25HVITD2t'.('R_1A25HVITD2t')
    'ER_1A25HVITD2tm'.('R_1A25HVITD2tm')
    'ER_EX_1a25dhvitd2[e]'.('R_EX_1a25dhvitd2[e]')
    'ER_EX_C13856[e]'.('R_EX_C13856[e]')
    'ER_EX_M00234[e]'.('R_EX_M00234[e]')
    'ER_EX_M01807[e]'.('R_EX_M01807[e]')
    'ER_EX_M00503[e]'.('R_EX_M00503[e]')
    'ER_EX_M00003[e]'.('R_EX_M00003[e]')
    'ER_EX_M00008[e]'.('R_EX_M00008[e]')
    'ER_EX_M00010[e]'.('R_EX_M00010[e]')
    'ER_EX_M00017[e]'.('R_EX_M00017[e]')
    'ER_EX_M00019[e]'.('R_EX_M00019[e]')
    'ER_EX_M00021[e]'.('R_EX_M00021[e]')
    'ER_EX_M00115[e]'.('R_EX_M00115[e]')
    'ER_EX_M00117[e]'.('R_EX_M00117[e]')
    'ER_EX_M00260[e]'.('R_EX_M00260[e]')
    'ER_EX_M00265[e]'.('R_EX_M00265[e]')
    'ER_EX_M00315[e]'.('R_EX_M00315[e]')
    'ER_EX_M00341[e]'.('R_EX_M00341[e]')
    'ER_EX_M01197[e]'.('R_EX_M01197[e]')
    'ER_EX_M01207[e]'.('R_EX_M01207[e]')
    'ER_EX_M01235[e]'.('R_EX_M01235[e]')
    'ER_EX_M01238[e]'.('R_EX_M01238[e]')
    'ER_EX_M01582[e]'.('R_EX_M01582[e]')
    'ER_EX_M02053[e]'.('R_EX_M02053[e]')
    'ER_EX_M02457[e]'.('R_EX_M02457[e]')
    'ER_EX_M02613[e]'.('R_EX_M02613[e]')
    'ER_EX_M02745[e]'.('R_EX_M02745[e]')
    'ER_EX_M03045[e]'.('R_EX_M03045[e]')
    'ER_EX_M03051[e]'.('R_EX_M03051[e]')
    'ER_EX_M03153[e]'.('R_EX_M03153[e]')
    'ER_EX_M02560[e]'.('R_EX_M02560[e]')
    'ER_EX_C01601[e]'.('R_EX_C01601[e]')
    'ER_EX_M02108[e]'.('R_EX_M02108[e]')
    'ER_EX_M03117[e]'.('R_EX_M03117[e]')
    'ER_EX_M03134[e]'.('R_EX_M03134[e]')
    'ER_EX_M01111[e]'.('R_EX_M01111[e]')
    'ER_EX_h2co3[e]'.('R_EX_h2co3[e]')
    'ER_EX_M01870[e]'.('R_EX_M01870[e]')
    'ER_EX_ditp[e]'.('R_EX_ditp[e]')
    'ER_EX_M02446[e]'.('R_EX_M02446[e]')
    'ER_EX_M02447[e]'.('R_EX_M02447[e]')
    'ER_EX_M02449[e]'.('R_EX_M02449[e]')
    'ER_EX_M02451[e]'.('R_EX_M02451[e]')
    'ER_EX_itacon[e]'.('R_EX_itacon[e]')
    'ER_EX_adpman[e]'.('R_EX_adpman[e]')
    'ER_EX_rbl_D[e]'.('R_EX_rbl_D[e]')
    'ER_EX_M02155[e]'.('R_EX_M02155[e]')
    'ER_EX_M01989[e]'.('R_EX_M01989[e]')
    'ER_EX_M03131[e]'.('R_EX_M03131[e]')
    'ER_EX_n5m2masn[e]'.('R_EX_n5m2masn[e]')
    'ER_EX_dolichol_L[e]'.('R_EX_dolichol_L[e]')
    'ER_sink_his_L[c]'.('R_sink_his_L[c]')
    'ER_sink_ile_L[c]'.('R_sink_ile_L[c]')
    'ER_sink_leu_L[c]'.('R_sink_leu_L[c]')
    'ER_sink_lys_L[c]'.('R_sink_lys_L[c]')
    'ER_sink_met_L[c]'.('R_sink_met_L[c]')
    'ER_sink_phe_L[c]'.('R_sink_phe_L[c]')
    'ER_sink_thr_L[c]'.('R_sink_thr_L[c]')
    'ER_sink_trp_L[c]'.('R_sink_trp_L[c]')
    'ER_sink_val_L[c]'.('R_sink_val_L[c]')
    'ER_sink_ala_L[c]'.('R_sink_ala_L[c]')
    'ER_sink_arg_L[c]'.('R_sink_arg_L[c]')
    'ER_sink_asn_L[c]'.('R_sink_asn_L[c]')
    'ER_sink_asp_L[c]'.('R_sink_asp_L[c]')
    'ER_sink_cys_L[c]'.('R_sink_cys_L[c]')
    'ER_sink_gln_L[c]'.('R_sink_gln_L[c]')
    'ER_sink_glu_L[c]'.('R_sink_glu_L[c]')
    'ER_sink_pro_L[c]'.('R_sink_pro_L[c]')
    'ER_sink_ser_L[c]'.('R_sink_ser_L[c]')
    'ER_sink_tyr_L[c]'.('R_sink_tyr_L[c]')
    'ER_sink_gly[c]'.('R_sink_gly[c]')
    'ER_sink_4abut[l]'.('R_sink_4abut[l]')
    'ER_DM_5cysdopa[c]'.('R_DM_5cysdopa[c]')
    'ER_DM_4abut[c]'.('R_DM_4abut[c]')
    'ER_DM_srtn[c]'.('R_DM_srtn[c]')
    'ER_DM_ach[c]'.('R_DM_ach[c]')
    'ER_DM_hista[c]'.('R_DM_hista[c]')
    'ER_DM_kynate[c]'.('R_DM_kynate[c]')
    'ER_DM_tym[c]'.('R_DM_tym[c]')
    'ER_DM_Lkynr[c]'.('R_DM_Lkynr[c]')
    'ER_DM_cbl2[m]'.('R_DM_cbl2[m]')
    'ER_DCMPtm'.('R_DCMPtm')
    'ER_ATPS4mi'.('R_ATPS4mi')
    'ER_KER_02243'.('R_KER_02243')
    'ER_KER_02407'.('R_KER_02407')
    'ER_KER_10600'.('R_KER_10600')
    'ER_ITPtm'.('R_ITPtm')
    'ER_IDPtm'.('R_IDPtm')
    'ER_CE_Peptide'.('R_CE_Peptide')
    'ER_EX_Peptide'.('R_EX_Peptide')
    'ER_Ubiquitin_syn'.('R_Ubiquitin_syn')
    'ER_DM_Ubiquitin'.('R_DM_Ubiquitin')
    'ER_Abeta_syn'.('R_Abeta_syn')
    'ER_DM_Abeta'.('R_DM_Abeta')
    'ER_Abeta_L_lysine'.('R_Abeta_L_lysine')
    'ER_CE_Abeta_L_lysine'.('R_CE_Abeta_L_lysine')
    'ER_CN_Abeta_L_lysine'.('R_CN_Abeta_L_lysine')
    'ER_EX_Abeta_L_lysine'.('R_EX_Abeta_L_lysine')
    'ER_EN_Abeta_L_lysine'.('R_EN_Abeta_L_lysine')
    'ER_Abeta_Deg'.('R_Abeta_Deg')
    'ER_Tau_syn'.('R_Tau_syn')
    'ER_DM_Tau'.('R_DM_Tau')
    'ER_Tau_L_lysine'.('R_Tau_L_lysine')
    'ER_CE_Tau_L_lysine'.('R_CE_Tau_L_lysine')
    'ER_CN_Tau_L_lysine'.('R_CN_Tau_L_lysine')
    'ER_EX_Tau_L_lysine'.('R_EX_Tau_L_lysine')
    'ER_EN_Tau_L_lysine'.('R_EN_Tau_L_lysine')
    'ER_Tau_Deg'.('R_Tau_Deg')
    'ER_TNFA_syn'.('R_TNFA_syn')
    'ER_DM_TNFA'.('R_DM_TNFA')
    'ER_TNFA_L_lysine'.('R_TNFA_L_lysine')
    'ER_CE_TNFA_L_lysine'.('R_CE_TNFA_L_lysine')
    'ER_CN_TNFA_L_lysine'.('R_CN_TNFA_L_lysine')
    'ER_EX_TNFA_L_lysine'.('R_EX_TNFA_L_lysine')
    'ER_EN_TNFA_L_lysine'.('R_EN_TNFA_L_lysine')
    'ER_TNFA_Deg'.('R_TNFA_Deg')
    'ER_IL6_syn'.('R_IL6_syn')
    'ER_DM_IL6'.('R_DM_IL6')
    'ER_IL6_L_lysine'.('R_IL6_L_lysine')
    'ER_CE_IL6_L_lysine'.('R_CE_IL6_L_lysine')
    'ER_CN_IL6_L_lysine'.('R_CN_IL6_L_lysine')
    'ER_EX_IL6_L_lysine'.('R_EX_IL6_L_lysine')
    'ER_EN_IL6_L_lysine'.('R_EN_IL6_L_lysine')
    'ER_IL6_Deg'.('R_IL6_Deg')
   /

  identical_enz(enzymes, enzymes) "feasible enzyme and its relative identical_enz in BL model"
   /
    'E0010'.('E0011', 'E0013', 'E0015')
    'E0014'.('E0016')
    'E0026'.('E0027')
    'E0028'.('E0029', 'E0031')
    'E0030'.('E0032', 'E0035')
    'E0040'.('E0042')
    'E0055'.('E0056', 'E0904', 'E0905')
    'E0058'.('E0059', 'E0060')
    'E0063'.('E0064')
    'E0065'.('E0067')
    'E0066'.('E0069', 'E0070', 'E0071', 'E0073')
    'E0068'.('E0072')
    'E0076'.('E0077')
    'E0079'.('E0080')
    'E0081'.('E0082', 'E0084', 'E0086', 'E0087')
    'E0083'.('E0085')
    'E0093'.('E0094', 'E0095')
    'E0105'.('E0106')
    'E0112'.('E2093')
    'E0115'.('E0116')
    'E0120'.('E0121')
    'E0124'.('E0126')
    'E0138'.('E0139')
    'E0149'.('E0152', 'E0153', 'E0154')
    'E0159'.('E0160', 'E0161', 'E0162', 'E0163', 'E0164', 'E0165',
             'E0166', 'E0167', 'E0168', 'E0169')
    'E0178'.('E0181')
    'E0179'.('E0183')
    'E0185'.('E0186')
    'E0187'.('E0188')
    'E0192'.('E0193', 'E0194')
    'E0199'.('E0201', 'E0203', 'E0204', 'E0205', 'E0206', 'E2078',
             'E2079', 'E2080')
    'E0224'.('E0225', 'E0226', 'E0227')
    'E0231'.('E0234')
    'E0232'.('E0235')
    'E0241'.('E0244')
    'E0242'.('E0243', 'E0245')
    'E0249'.('E0254')
    'E0258'.('E0259')
    'E0265'.('E0266', 'E0267')
    'E0268'.('E0269', 'E0270', 'E0271', 'E0272')
    'E0275'.('E0276', 'E0277', 'E0278', 'E0281')
    'E0286'.('E0287')
    'E0293'.('E0296')
    'E0302'.('E0303', 'E0304', 'E0305', 'E0306')
    'E0495'.('E0496', 'E0499')
    'E0497'.('E0498')
    'E0506'.('E0508', 'E0509')
    'E0511'.('E0513', 'E0514', 'E0515')
    'E0522'.('E0523', 'E0524')
    'E0548'.('E0549', 'E0550', 'E0551', 'E0552', 'E0553', 'E0554',
             'E0555')
    'E0557'.('E0558', 'E0559')
    'E0562'.('E1750')
    'E0563'.('E0564')
    'E0565'.('E0566')
    'E0569'.('E0570')
    'E0574'.('E0575', 'E0576', 'E0577')
    'E0579'.('E0580')
    'E0584'.('E0586')
    'E0589'.('E0590', 'E0591')
    'E0599'.('E0600', 'E0601')
    'E0612'.('E0613')
    'E0631'.('E0632')
    'E0643'.('E0644')
    'E0647'.('E0648', 'E0649', 'E0650', 'E0651', 'E0652', 'E0653',
             'E0654', 'E0655', 'E0656', 'E0657', 'E0658', 'E0659',
             'E0660')
    'E0662'.('E0663', 'E0664')
    'E0665'.('E0666')
    'E0671'.('E1659')
    'E0676'.('E0677', 'E0678', 'E0679', 'E0680')
    'E0687'.('E0688', 'E0689')
    'E0708'.('E0709', 'E0710', 'E0711', 'E0712')
    'E0732'.('E0733')
    'E0734'.('E0735')
    'E0744'.('E2072', 'E2073', 'E2074', 'E2075', 'E2076')
    'E0745'.('E0746')
    'E0747'.('E0748', 'E0749', 'E0750')
    'E0753'.('E0754')
    'E0755'.('E0756')
    'E0761'.('E0763')
    'E0764'.('E0765')
    'E0766'.('E0771')
    'E0767'.('E0768', 'E0769', 'E0770')
    'E0772'.('E0773')
    'E0782'.('E0784')
    'E0795'.('E0797', 'E0798')
    'E0805'.('E0806')
    'E0812'.('E0813')
    'E0814'.('E0815')
    'E0816'.('E0817', 'E0818', 'E0819', 'E0820', 'E0821', 'E0822',
             'E0823', 'E0824', 'E0825', 'E0826', 'E0827', 'E0829',
             'E0830', 'E0831')
    'E0839'.('E0840', 'E0841', 'E0842', 'E0843')
    'E0846'.('E0847')
    'E0858'.('E1622', 'E1623')
    'E0869'.('E0870', 'E0871', 'E0872')
    'E0874'.('E0875', 'E0876', 'E0877')
    'E0881'.('E0882', 'E0883', 'E0884', 'E0885')
    'E0887'.('E0888', 'E0889', 'E0890', 'E0891', 'E0892')
    'E0893'.('E0894', 'E0895')
    'E0901'.('E0902')
    'E0911'.('E0913')
    'E0916'.('E0917', 'E0918', 'E0919')
    'E0920'.('E1982', 'E1983')
    'E0930'.('E0931', 'E0933', 'E0934', 'E0936', 'E0937', 'E0939')
    'E0940'.('E0941', 'E0942')
    'E0943'.('E0944')
    'E0948'.('E0949')
    'E0950'.('E0951', 'E0952', 'E0953', 'E0954', 'E0955', 'E0956',
             'E0957', 'E0958', 'E0959')
    'E0961'.('E0962')
    'E0966'.('E0967', 'E0968')
    'E0974'.('E0975')
    'E0976'.('E0977', 'E0978', 'E0979')
    'E0981'.('E0982', 'E0984', 'E0985')
    'E0986'.('E0987', 'E0988', 'E0989', 'E0990', 'E0991', 'E0992',
             'E0993', 'E0994', 'E0995', 'E0996')
    'E1016'.('E1017')
    'E1018'.('E2160', 'E2162')
    'E1027'.('E1029', 'E1030', 'E1031')
    'E1038'.('E1039')
    'E1043'.('E1044', 'E1045')
    'E1049'.('E1050')
    'E1061'.('E1071', 'E1375', 'E1377', 'E1381', 'E1382')
    'E1066'.('E1068')
    'E1069'.('E1070')
    'E1087'.('E1491')
    'E1093'.('E1095')
    'E1101'.('E1104', 'E1106', 'E1109')
    'E1102'.('E1105', 'E1107', 'E1108')
    'E1111'.('E1112', 'E1113')
    'E1116'.('E1117')
    'E1143'.('E1144', 'E1145')
    'E1146'.('E1147')
    'E1149'.('E1150', 'E1151', 'E1152', 'E1153', 'E1154')
    'E1159'.('E1162', 'E1163')
    'E1171'.('E1172')
    'E1176'.('E1178', 'E1180')
    'E1177'.('E1179', 'E1181')
    'E1192'.('E1193')
    'E1199'.('E1200', 'E1201', 'E1202')
    'E1204'.('E1205')
    'E1207'.('E1214', 'E1219', 'E1221', 'E1727', 'E1728', 'E1729',
             'E1730', 'E1731', 'E1732', 'E1733')
    'E1228'.('E1229')
    'E1234'.('E1235', 'E1236')
    'E1239'.('E2020', 'E2021')
    'E1243'.('E1244')
    'E1246'.('E1247')
    'E1248'.('E1251', 'E1255', 'E1257', 'E1258', 'E1262', 'E1264',
             'E1265', 'E1269')
    'E1249'.('E1250', 'E1252', 'E1253', 'E1254', 'E1256', 'E1259',
             'E1261', 'E1263', 'E1266', 'E1267', 'E1268', 'E1270')
    'E1271'.('E1272', 'E1273', 'E1274', 'E1275', 'E1276', 'E1277',
             'E1278', 'E1279', 'E1280', 'E1281', 'E1282', 'E1283',
             'E1284', 'E1285', 'E1286', 'E1287', 'E1288', 'E1289',
             'E1290', 'E1291', 'E1292', 'E1293')
    'E1303'.('E1305')
    'E1309'.('E1310', 'E1313', 'E1314')
    'E1311'.('E1312')
    'E1318'.('E1319')
    'E1326'.('E1327', 'E1328')
    'E1329'.('E1330', 'E1331')
    'E1332'.('E1333', 'E1334', 'E1335', 'E1336', 'E1337', 'E1338',
             'E1339', 'E1340', 'E1341', 'E1342')
    'E1343'.('E1344')
    'E1345'.('E1346', 'E1347', 'E1348', 'E1349', 'E1350', 'E1351',
             'E1352', 'E1353', 'E1354', 'E1355', 'E1356', 'E1357',
             'E1358', 'E1359', 'E1360', 'E1361', 'E1362')
    'E1363'.('E1364', 'E1365')
    'E1366'.('E1367', 'E1368', 'E1369', 'E1370', 'E1371', 'E1372')
    'E1376'.('E1378', 'E1379', 'E1380')
    'E1383'.('E1384', 'E1385', 'E1386')
    'E1388'.('E1390')
    'E1391'.('E1392', 'E1393', 'E1394', 'E1396')
    'E1398'.('E1399', 'E1400', 'E1401')
    'E1402'.('E1404')
    'E1418'.('E1419')
    'E1425'.('E1427')
    'E1434'.('E1438')
    'E1435'.('E1436')
    'E1440'.('E2053', 'E2054', 'E2055', 'E2056', 'E2057', 'E2058',
             'E2059', 'E2060', 'E2061', 'E2062', 'E2063')
    'E1443'.('E1444')
    'E1449'.('E1450')
    'E1455'.('E1456', 'E1457')
    'E1458'.('E1459', 'E1460', 'E1461')
    'E1462'.('E1463')
    'E1464'.('E1465', 'E1466', 'E1467', 'E1468')
    'E1472'.('E1473', 'E1474', 'E1475')
    'E1481'.('E1682')
    'E1494'.('E1495')
    'E1499'.('E1504', 'E1505')
    'E1500'.('E1501', 'E1502', 'E1503')
    'E1533'.('E1534', 'E1535')
    'E1542'.('E1543')
    'E1544'.('E1545')
    'E1550'.('E1552', 'E1553')
    'E1554'.('E1555')
    'E1556'.('E1557')
    'E1578'.('E1584')
    'E1587'.('E1589', 'E1591', 'E1592')
    'E1596'.('E1597')
    'E1602'.('E1603', 'E1604')
    'E1611'.('E1612', 'E1613')
    'E1618'.('E1747', 'E2004', 'E2005', 'E2006')
    'E1619'.('E1620', 'E1621', 'E1624')
    'E1628'.('E1629')
    'E1634'.('E1635')
    'E1641'.('E1643')
    'E1644'.('E1645')
    'E1666'.('E1667', 'E1668', 'E1669')
    'E1691'.('E1692', 'E1693', 'E1694', 'E1695', 'E1696', 'E1697',
             'E1698', 'E1700')
    'E1701'.('E1702')
    'E1707'.('E1998', 'E1999', 'E2000', 'E2001', 'E2002')
    'E1713'.('E1714')
    'E1715'.('E1932')
    'E1736'.('E1737', 'E1738', 'E1739')
    'E1745'.('E2102', 'E2103', 'E2104', 'E2105', 'E2106', 'E2108',
             'E2109', 'E2110', 'E2111', 'E2112', 'E2113', 'E2115',
             'E2116', 'E2117', 'E2118', 'E2119', 'E2121', 'E2122',
             'E2123', 'E2124', 'E2125', 'E2127', 'E2128', 'E2129',
             'E2130', 'E2131', 'E2132')
    'E1754'.('E1755', 'E1756')
    'E1758'.('E2143')
    'E1761'.('E1833')
    'E1776'.('E1777', 'E1778', 'E1779')
    'E1780'.('E1781', 'E1782', 'E1783')
    'E1793'.('E1794')
    'E1798'.('E2064', 'E2065', 'E2066', 'E2067', 'E2068', 'E2069',
             'E2070', 'E2071')
    'E1810'.('E1811')
    'E1824'.('E1825', 'E1826')
    'E1830'.('E1831')
    'E1834'.('E1835')
    'E1836'.('E1837', 'E1838', 'E1839')
    'E1840'.('E1841')
    'E1848'.('E1849')
    'E1851'.('E1852', 'E1853')
    'E1857'.('E1858')
    'E1863'.('E1864', 'E1865', 'E1866')
    'E1868'.('E1869')
    'E1870'.('E1871')
    'E1872'.('E1873')
    'E1874'.('E1875')
    'E1878'.('E2144', 'E2145')
    'E1882'.('E1883', 'E1884')
    'E1892'.('E1893', 'E1894')
    'E1896'.('E1897')
    'E1899'.('E1900')
    'E1902'.('E1903')
    'E1905'.('E1906', 'E1907')
    'E1910'.('E1911')
    'E1917'.('E1918')
    'E1923'.('E1924', 'E1925', 'E1926')
    'E1929'.('E1930')
    'E1935'.('E1936', 'E1937')
    'E1941'.('E1942')
    'E1943'.('E1944')
    'E1946'.('E1947')
    'E1950'.('E1951', 'E1952', 'E1953', 'E1954', 'E1955', 'E1956',
             'E1957', 'E1958', 'E1959')
    'E1962'.('E1963')
    'E1964'.('E1965', 'E1966', 'E1967')
    'E1971'.('E1972')
    'E1973'.('E1974')
    'E1975'.('E1976', 'E1977')
    'E1978'.('E1979', 'E1980')
    'E1987'.('E1988')
    'E1992'.('E1993', 'E1994', 'E1995', 'E1996', 'E1997')
    'E2014'.('E2015', 'E2016')
    'E2018'.('E2019')
    'E2022'.('E2023')
    'E2037'.('E2101')
    'E2038'.('E2039')
    'E2050'.('E2051')
    'E2081'.('E2085', 'E2086')
    'E2082'.('E2083', 'E2084', 'E2087', 'E2088')
    'E2090'.('E2091')
    'E2095'.('E2096', 'E2097', 'E2098', 'E2099', 'E2100')
    'E2114'.('E2120')
    'E2140'.('E2141')
    'E2149'.('E2158')
    'E2154'.('E2155')
    'E2163'.('E2164', 'E2165')
    'E2166'.('E2167', 'E2168', 'E2169', 'E2170')
    'E2176'.('E2177')
    'E2185'.('E2186', 'E2187')
    'E2190'.('E2191', 'E2192')
    'E2200'.('E2201', 'E2202', 'E2203', 'E2204', 'E2205', 'E2206',
             'E2207', 'E2208', 'E2209', 'E2210', 'E2211', 'E2212',
             'E2213', 'E2214', 'E2215', 'E2216', 'E2217', 'E2218')
    'E2222'.('E2223')
    'E2226'.('E2227')
    'E2228'.('E2229')
    'E2231'.('E2233', 'E2234', 'E2235', 'E2237', 'E2238', 'E2239',
             'E2240', 'E2241', 'E2242', 'E2243', 'E2244', 'E2245',
             'E2246', 'E2247', 'E2248', 'E2250', 'E2251', 'E2252',
             'E2253', 'E2254', 'E2255')
    'E2232'.('E2236', 'E2249')
    'E2256'.('E2257', 'E2258', 'E2259', 'E2260')
    'E2266'.('E2267')
    'E2270'.('E2271')
    'E2273'.('E2274', 'E2275')
    'E2300'.('E2301')
    'E2302'.('E2303')
    'E2307'.('E2308', 'E2309', 'E2310', 'E2311', 'E2312')
    'E2316'.('E2317')
    'E2318'.('E2319', 'E2320', 'E2321', 'E2322', 'E2323', 'E2324',
             'E2325', 'E2326', 'E2327', 'E2328', 'E2329', 'E2330',
             'E2331', 'E2332', 'E2333', 'E2334', 'E2335', 'E2336',
             'E2337', 'E2338', 'E2339', 'E2340', 'E2341', 'E2342',
             'E2343', 'E2344', 'E2345', 'E2346', 'E2347', 'E2348',
             'E2349', 'E2350', 'E2351', 'E2352', 'E2353', 'E2354',
             'E2355', 'E2356', 'E2357', 'E2358', 'E2359', 'E2360',
             'E2361', 'E2362', 'E2363', 'E2364', 'E2365', 'E2366',
             'E2367', 'E2368', 'E2369', 'E2370', 'E2371', 'E2372',
             'E2373', 'E2374', 'E2375', 'E2376', 'E2377', 'E2378',
             'E2379', 'E2380', 'E2381', 'E2382', 'E2383', 'E2384',
             'E2385', 'E2386', 'E2387', 'E2388', 'E2389', 'E2390',
             'E2391', 'E2392', 'E2393', 'E2394', 'E2395', 'E2396',
             'E2397', 'E2398', 'E2399', 'E2400', 'E2401', 'E2402',
             'E2403', 'E2404', 'E2405', 'E2406', 'E2407', 'E2408',
             'E2409', 'E2410', 'E2411', 'E2412', 'E2413', 'E2414',
             'E2415', 'E2416', 'E2417', 'E2418', 'E2419', 'E2420',
             'E2421', 'E2422', 'E2423', 'E2424', 'E2425', 'E2426',
             'E2427', 'E2428', 'E2429', 'E2430', 'E2431', 'E2432',
             'E2433', 'E2434', 'E2435', 'E2436', 'E2437', 'E2438',
             'E2439', 'E2440', 'E2441', 'E2442', 'E2443', 'E2444',
             'E2445', 'E2446', 'E2447', 'E2448', 'E2449', 'E2450',
             'E2451', 'E2452', 'E2453', 'E2454', 'E2455', 'E2456',
             'E2457', 'E2458', 'E2459', 'E2460', 'E2461', 'E2462',
             'E2463', 'E2464', 'E2465', 'E2466', 'E2467', 'E2468',
             'E2469', 'E2470', 'E2471', 'E2472', 'E2473', 'E2474',
             'E2475', 'E2476', 'E2477', 'E2478', 'E2479', 'E2480',
             'E2481', 'E2482', 'E2483', 'E2484', 'E2485', 'E2486',
             'E2487', 'E2488', 'E2489', 'E2490', 'E2491')
    'E2492'.('E2493')
   /

  isozymes(enzymes, enzymes) "feasible/candidate enzyme and its relative isozymes in BL model, not included identical_enz"
   /
    'E0001'.('E0002', 'E0003', 'E0004', 'E0053', 'E0054')
    'E0007'.('E2007')
    'E0008'.('E0066', 'E0068', 'E0075', 'E0596', 'E0691', 'E1720',
             'E2228')
    'E0009'.('E0699')
    'E0010'.('E0012', 'E0014', 'E0017', 'E1010', 'E1011')
    'E0018'.('E0019', 'E0020', 'E0696', 'E1895')
    'E0028'.('E0030', 'E0033', 'E0034', 'E0241', 'E0242', 'E1431',
             'E1437', 'E1679', 'E2159')
    'E0036'.('E0037', 'E1478', 'E2224')
    'E0038'.('E1817')
    'E0039'.('E0040', 'E0041', 'E0248', 'E0249', 'E0250', 'E0251',
             'E0252', 'E0253', 'E0255')
    'E0044'.('E0045')
    'E0049'.('E0050', 'E0051')
    'E0052'.('E0999')
    'E0057'.('E0058')
    'E0063'.('E0256', 'E0801', 'E0845', 'E0846')
    'E0074'.('E0528', 'E0598', 'E0728', 'E1245', 'E1703', 'E1819',
             'E1822', 'E2034')
    'E0081'.('E0083')
    'E0090'.('E0189', 'E0190', 'E0192', 'E0197', 'E0512', 'E0516',
             'E0533', 'E0626', 'E0794', 'E0795', 'E0799', 'E0828',
             'E0834', 'E0844', 'E0965', 'E0972', 'E1745', 'E2107',
             'E2114', 'E2126')
    'E0092'.('E1922')
    'E0093'.('E0096')
    'E0098'.('E0099', 'E0102', 'E0123', 'E0128', 'E0541', 'E0721',
             'E0724', 'E0974', 'E1646', 'E1648', 'E1716')
    'E0100'.('E0722')
    'E0105'.('E0142')
    'E0108'.('E1566')
    'E0119'.('E0120')
    'E0122'.('E0124', 'E0125', 'E0127')
    'E0131'.('E0132', 'E0136', 'E1217', 'E1647')
    'E0134'.('E0135')
    'E0137'.('E0138', 'E0140', 'E1805', 'E2185')
    'E0141'.('E0630', 'E1183', 'E2176')
    'E0143'.('E0144')
    'E0146'.('E1059', 'E1092', 'E1093', 'E1094', 'E1207', 'E1209',
             'E1212', 'E1213', 'E1215', 'E1218', 'E1224', 'E1225',
             'E1227', 'E1734', 'E2142')
    'E0148'.('E0170')
    'E0149'.('E0150', 'E0151')
    'E0155'.('E0156', 'E1848', 'E1949')
    'E0171'.('E0172', 'E0173', 'E0174')
    'E0178'.('E0179', 'E0180', 'E0182')
    'E0184'.('E0629')
    'E0191'.('E0195', 'E0196')
    'E0210'.('E0211', 'E0212', 'E2134')
    'E0216'.('E1705')
    'E0218'.('E0219', 'E2149')
    'E0221'.('E0222', 'E0594')
    'E0223'.('E0636', 'E0637')
    'E0228'.('E0229', 'E0230', 'E0231', 'E0232', 'E0233', 'E0236',
             'E1320')
    'E0246'.('E0247', 'E0261', 'E0262')
    'E0263'.('E0264')
    'E0274'.('E0275', 'E0279', 'E0280', 'E2276')
    'E0282'.('E0725', 'E0758', 'E0759', 'E0760', 'E1769')
    'E0285'.('E1855')
    'E0288'.('E0289')
    'E0291'.('E0292', 'E2037', 'E2038')
    'E0293'.('E0294', 'E0295')
    'E0495'.('E0497', 'E0500', 'E0501')
    'E0506'.('E0507')
    'E0517'.('E1416', 'E1417', 'E1420', 'E1640', 'E1642', 'E1712',
             'E2077')
    'E0527'.('E0530', 'E0581', 'E0690', 'E0726', 'E0727', 'E0729',
             'E2300')
    'E0529'.('E0584', 'E0585')
    'E0537'.('E2013')
    'E0539'.('E2152')
    'E0540'.('E0542', 'E2151')
    'E0562'.('E1751')
    'E0567'.('E0568', 'E2089')
    'E0582'.('E0583')
    'E0588'.('E0589')
    'E0593'.('E0595', 'E0707')
    'E0604'.('E1687')
    'E0611'.('E0612')
    'E0618'.('E2273')
    'E0620'.('E0621')
    'E0623'.('E0624', 'E0625')
    'E0627'.('E0628')
    'E0633'.('E0634')
    'E0643'.('E1593')
    'E0667'.('E0668', 'E0723')
    'E0672'.('E0673', 'E2174')
    'E0681'.('E0682', 'E0683', 'E0780', 'E0781', 'E0782', 'E0832',
             'E0881')
    'E0684'.('E0685')
    'E0697'.('E1862')
    'E0716'.('E0717')
    'E0718'.('E0719')
    'E0736'.('E0737', 'E0738', 'E0739', 'E0740', 'E0741', 'E0742',
             'E0743', 'E1770')
    'E0747'.('E2163')
    'E0761'.('E0762', 'E0764')
    'E0766'.('E0767')
    'E0786'.('E0787', 'E1124')
    'E0792'.('E2139')
    'E0793'.('E2140')
    'E0808'.('E0809')
    'E0812'.('E0814')
    'E0835'.('E1190')
    'E0836'.('E0837')
    'E0858'.('E0946', 'E0947', 'E1619')
    'E0859'.('E0860')
    'E0864'.('E0865')
    'E0868'.('E0878', 'E0880')
    'E0886'.('E1037', 'E1131', 'E1946')
    'E0899'.('E0900')
    'E0901'.('E0903')
    'E0906'.('E0907')
    'E0911'.('E0912')
    'E0921'.('E0922')
    'E0930'.('E0932', 'E0935', 'E0938')
    'E0940'.('E1408', 'E1758')
    'E0963'.('E0964')
    'E0981'.('E0983')
    'E1002'.('E1003')
    'E1005'.('E1006')
    'E1016'.('E1018', 'E1019', 'E2161')
    'E1025'.('E1026', 'E1616')
    'E1027'.('E1028')
    'E1043'.('E1046')
    'E1047'.('E1048')
    'E1052'.('E1053', 'E2135')
    'E1058'.('E1824')
    'E1061'.('E1376')
    'E1065'.('E1066', 'E1067')
    'E1088'.('E1090')
    'E1101'.('E1102', 'E1103', 'E1325')
    'E1143'.('E1902')
    'E1155'.('E1157')
    'E1159'.('E1160', 'E1161')
    'E1165'.('E1166', 'E2029')
    'E1169'.('E1170', 'E1171')
    'E1176'.('E1177')
    'E1182'.('E1426')
    'E1185'.('E1186', 'E1187', 'E1188', 'E1481', 'E1610', 'E1611',
             'E1614', 'E1757', 'E1960', 'E1989', 'E1990', 'E2200')
    'E1198'.('E1199', 'E1499', 'E1500')
    'E1228'.('E1752')
    'E1232'.('E1233', 'E1676', 'E1807')
    'E1240'.('E1241', 'E2090', 'E2092')
    'E1248'.('E1249', 'E1260', 'E1271')
    'E1303'.('E1304')
    'E1309'.('E1311')
    'E1318'.('E2175')
    'E1324'.('E1724')
    'E1326'.('E1329', 'E1366', 'E2221')
    'E1332'.('E1363', 'E1373')
    'E1388'.('E1389', 'E1391', 'E1395', 'E2266')
    'E1402'.('E1403', 'E1405', 'E2081', 'E2082')
    'E1407'.('E1409', 'E1722')
    'E1433'.('E1434', 'E1435', 'E1439', 'E2222')
    'E1443'.('E1445', 'E1446')
    'E1451'.('E1452', 'E1453')
    'E1469'.('E1470')
    'E1483'.('E2153')
    'E1489'.('E1490')
    'E1492'.('E1493', 'E1494', 'E1496', 'E1497')
    'E1498'.('E1845')
    'E1507'.('E1689')
    'E1512'.('E1513')
    'E1533'.('E2136')
    'E1536'.('E1537')
    'E1550'.('E1551')
    'E1577'.('E1578', 'E1579', 'E1580', 'E1581', 'E1582', 'E1583',
             'E1585', 'E1586', 'E1587', 'E1588', 'E1590')
    'E1625'.('E1992')
    'E1628'.('E1896')
    'E1653'.('E1654')
    'E1691'.('E1699', 'E1882')
    'E1748'.('E1749')
    'E1761'.('E1830', 'E1832')
    'E1796'.('E1809')
    'E1798'.('E2032')
    'E1812'.('E1815', 'E1823')
    'E1908'.('E1909')
    'E2025'.('E2027')
    'E2026'.('E2307')
    'E2031'.('E2033')
    'E2049'.('E2050', 'E2137')
    'E2171'.('E2172')
    'E2225'.('E2226')
    'E2231'.('E2232', 'E2492')
   /

  isozyme_rxn(reactions) "reactions regulated by isozymes in BL model"
   /
    'R_13DAMPPOX',    'R_2HBO',    'R_2HBt2',    'R_34DHOXPEGOX',    'R_34DHPHAMT',    'R_34DHPLACOX',
    'R_34DHPLACOX_NADP_',    'R_3AIBTm',    'R_3AIBtmi',    'R_3HKYNAKGAT',    'R_3MOX4HOXPGALDOX',    'R_3MOX4HOXPGALDOX_NADP_',
    'R_41R1H2MAE12BOOX',    'R_42A12BOOX',    'R_4HOXPACDOX_NADP_',    'R_4NPHSULT',    'R_5ADTSTSTERONESULT',    'R_5HOXINOXDA',
    'R_5MTHFt',    'R_AATAi',    'R_ABTArm',    'R_ABUTt4_2_r',    'R_ACETONEt2',    'R_ACNAMPH',
    'R_ACOAD10m',    'R_ACOAD1fm',    'R_ACOAD9m',    'R_ACOAO7p',    'R_ACONTm',    'R_ACP1_FMN_',
    'R_ACS2',    'R_ADK1m',    'R_ADK3',    'R_ADKd',    'R_ADNt',    'R_ADNt4',
    'R_ADRNCPT1',    'R_AG13T16g',    'R_AG13T17g',    'R_AG13T18g',    'R_AG13T1g',    'R_AG13T2g',
    'R_AG13T3g',    'R_AHEXASE2ly',    'R_ALACYSNaEx',    'R_ALASERNaEx',    'R_ALAt4',    'R_ALATHRNaEx',
    'R_ALCD21_D',    'R_ALCD21_L',    'R_ALCD22_D',    'R_ALCD22_L',    'R_ALCD2if',    'R_ALCD2yf',
    'R_ALDD20x',    'R_ALDD20xm',    'R_ALDD2xm',    'R_ALDD2y',    'R_ALR2',    'R_ALR3',
    'R_AMACR2p',    'R_AMY1e',    'R_AMY2e',    'R_APAT2rm',    'R_ARABR',    'R_ARACHCPT1',
    'R_ARGtm',    'R_ASAH1',    'R_ASCBt4',    'R_ATPH1e',    'R_ATPH2e',    'R_B3GALT3g',
    'R_B3GALT5g',    'R_B3GNT12g',    'R_BAMPPALDOX',    'R_C160CPT1',    'R_C160CPT2',    'R_C161CPT1',
    'R_C161CPT12',    'R_C180CPT1',    'R_C181CPT1',    'R_C204CPT1',    'R_C226CPT1',    'R_C4STMO2r',
    'R_CHOLATEt2',    'R_CHOLATEt3',    'R_CHOLK',    'R_CHOLtu',    'R_CHSTEROLSULT',    'R_CITRtm',
    'R_CLHCO3tex2',    'R_CLOHtex2',    'R_CLOXAtex2',    'R_CLPNDCPT1',    'R_COQ6m',    'R_CORE2GTg',
    'R_CREATt4_2_r',    'R_CSNAT2x',    'R_CYSALANaEx',    'R_CYSGLUexR',    'R_CYSGLYexR',    'R_CYSSERNaEx',
    'R_CYSTHRNaEx',    'R_CYTDt',    'R_CYTDt4',    'R_CYTK3',    'R_CYTK4',    'R_DCIm',
    'R_DCSPTN1CPT1',    'R_DESAT18_9',    'R_DHAAt1r',    'R_DHCR242r',    'R_DHEASULT',    'R_D_LACt2',
    'R_DLNLCGCPT1',    'R_DOPAMT',    'R_DOPASULT',    'R_DOPAtu',    'R_DURIK1',    'R_DUTPDPm',
    'R_ECOAH12m',    'R_ECOAH1m',    'R_ECOAH1x',    'R_ECOAH9m',    'R_EICOSTETCPT1',    'R_ELAIDCPT1',
    'R_ESTRONESt',    'R_ESTSULT',    'R_ETHAK',    'R_FACOAL150',    'R_FACOAL160i',    'R_FACOAL170',
    'R_FACOAL180i',    'R_FACOAL181i',    'R_FACOAL1821',    'R_FACOAL1831',    'R_FACOAL204',    'R_FACOAL80i',
    'R_FAOXC140',    'R_FAOXC160',    'R_FAOXC226',    'R_FAOXC226205m',    'R_FAOXC80',    'R_FATP1t',
    'R_FATP2t',    'R_FATP3t',    'R_FATP6t',    'R_FATP7t',    'R_FATP8t',    'R_FATP9t',
    'R_FBA4',    'R_FBP26',    'R_FRUt1r',    'R_FTHFLm',    'R_G14T18g',    'R_G14T19g',
    'R_G14T20g',    'R_G14T21g',    'R_G14T2g',    'R_G14T3g',    'R_G14T4g',    'R_G14T5g',
    'R_GALASE10ly',    'R_GALASE11ly',    'R_GALASE12ly',    'R_GALASE13ly',    'R_GALASE14ly',    'R_GALASE15ly',
    'R_GALASE16ly',    'R_GALASE17ly',    'R_GALASE18ly',    'R_GALASE19ly',    'R_GALASE20ly',    'R_GALASE3ly',
    'R_GALASE4ly',    'R_GALASE5ly',    'R_GALASE6ly',    'R_GALASE7ly',    'R_GALASE8ly',    'R_GALASE9ly',
    'R_GALNACT2g',    'R_GALNACT3g',    'R_GALNACT4g',    'R_GALNACT5g',    'R_GALNTg',    'R_GALOR',
    'R_GALt1r',    'R_GAMt1r',    'R_GARFT',    'R_GCALDDm',    'R_GCHOLAt2',    'R_GHMT2rm',
    'R_GHMT3',    'R_GLACO',    'R_GLCAASE8ly',    'R_GLCAT2g',    'R_GLCAT3g',    'R_GLCAT4g',
    'R_GLCAT5g',    'R_GLCNACT1g',    'R_GLCNACT2g',    'R_GLCNACT3g',    'R_GLCNACT4g',    'R_GLCNACT5g',
    'R_GLCt1r',    'R_GluForTx',    'R_GLUNm',    'R_GLUTCOADHm',    'R_GLXO2p',    'R_GLYCTO1p',
    'R_GLYt7_211_r',    'R_GSNt',    'R_GTHP',    'R_GTHPe',    'R_GTHPm',    'R_GTMLTe',
    'R_H2ETer',    'R_H3ETer',    'R_H4ETer',    'R_H6_ETer',    'R_H7_ETer',    'R_HACD1m',
    'R_HACD1x',    'R_HCO3_CLt',    'R_HISDC',    'R_HISTASE',    'R_HISTAtu',    'R_HMGCOASi',
    'R_HMGLm',    'R_HOMt4',    'R_HPDCACRNCPT1',    'R_HPYRR2x',    'R_IDHPOXOX2b',    'R_IDHPOXOX3',
    'R_IDHPOXOX4',    'R_IDHPOXOXb',    'R_INSt',    'R_KCCt',    'R_KHK',    'R_KHK2',
    'R_KHK3',    'R_KYNAKGAT',    'R_LACZe',    'R_LAPCOAl',    'R_LCADi_D',    'R_LCADim',
    'R_LCYSTCBOXL',    'R_LDH_Lm',    'R_LEUt4',    'R_LNELDCCPT1',    'R_LNLCCPT1',    'R_LNLNCACPT1',
    'R_LNLNCGCPT1',    'R_LPS',    'R_LYStiDF',    'R_LYStm',    'R_MACOXO',    'R_MAOLNOR',
    'R_MAOX',    'R_ME2m',    'R_MELATNOX',    'R_MHISOR',    'R_MI1345PP',    'R_MI145PP',
    'R_MTHFCm',    'R_MTHFDm',    'R_NACHEX1ly',    'R_NACHEX21ly',    'R_NACHEX22ly',    'R_NACHEX25ly',
    'R_NACHEX27ly',    'R_NACHEX2ly',    'R_NACHEX3ly',    'R_NACHEX8ly',    'R_NACHEX9ly',    'R_NACHEXA10ly',
    'R_NACHEXA11ly',    'R_NACHEXA12ly',    'R_NACHEXA13ly',    'R_NACHEXA14ly',    'R_NACHEXA15ly',    'R_NACHEXA16ly',
    'R_NACHEXA17ly',    'R_NACHEXA18ly',    'R_NACHEXA19ly',    'R_NACHEXA1ly',    'R_NACHEXA20ly',    'R_NACHEXA21ly',
    'R_NACHEXA22ly',    'R_NACHEXA2ly',    'R_NACHEXA3ly',    'R_NACHEXA4ly',    'R_NACHEXA5ly',    'R_NACHEXA6ly',
    'R_NACHEXA7ly',    'R_NACHEXA8ly',    'R_NACHEXA9ly',    'R_NAt',    'R_NDP10ex',    'R_NDP3ex',
    'R_NDP7er',    'R_NDP7ex',    'R_NDP8ex',    'R_NDPK1m',    'R_NDPK3m',    'R_NDPK5m',
    'R_NDPK6m',    'R_NDPK8m',    'R_NH4t3r',    'R_NMNATr',    'R_NOS1',    'R_NOS2',
    'R_NRPPHRSULT',    'R_NRPPHRtu',    'R_NTD12',    'R_NTD2l',    'R_NTP3e',    'R_NTPP10',
    'R_NTPP9',    'R_ORNt3m',    'R_ORNt4m',    'R_ORNtiDF',    'R_OXAHCOtex',    'R_P4501B1r',
    'R_P4502A6',    'R_P4502C8',    'R_P4504F122r',    'R_P5CRm',    'R_P5CRxm',    'R_PCHOLP_hs',
    'R_PCt',    'R_PDE1',    'R_PDE4',    'R_PEAMNO',    'R_PETOHMr_hs',    'R_PGESr',
    'R_PHEt4',    'R_PI345P5P',    'R_PI3P4K',    'R_PI45P5P',    'R_PI4P3K',    'R_PI4P5K',
    'R_PI5P3K',    'R_PIK3',    'R_PLA2_2',    'R_PLA2_2e',    'R_PMI12346PH',    'R_PMI12346PHn',
    'R_PPAP',    'R_PPDOy',    'R_PRAGSr',    'R_PROSTGE2t',    'R_PROSTGE2t2',    'R_PROSTGF2t',
    'R_PTDCACRNCPT1',    'R_PTE2x',    'R_PTRCOX1',    'R_PYNP2r',    'R_PYRt2p',    'R_RDH1',
    'R_RDH1a',    'R_RDH2a',    'R_S23T2g',    'R_S23T4g',    'R_S3T1g',    'R_S3T2g',
    'R_S3T3g',    'R_S6T18g',    'R_S6T19g',    'R_S6T20g',    'R_S6T21g',    'R_S6T24g',
    'R_S6T3g',    'R_SALMCOM',    'R_SBTR',    'R_SERALANaEx',    'R_SERCYSNaEx',    'R_SERTHRNaEx',
    'R_SLCBK1',    'R_SMPD3g',    'R_SMPD3l',    'R_SO4CLtex2',    'R_SO4HCOtex',    'R_SO4OXAtex2',
    'R_SPHK21c',    'R_SPRMS',    'R_SRTNtu',    'R_STRDNCCPT1',    'R_SUCRe',    'R_TCHOLAt',
    'R_TCHOLAt2',    'R_THRALANaEx',    'R_THRCYSNaEx',    'R_THRSERNaEx',    'R_THYMDt1',    'R_THYOXt',
    'R_THYPX',    'R_TMNDNCCPT1',    'R_TRDR',    'R_TRDR2',    'R_TRDR3',    'R_TRIODTHYSULT',
    'R_TRIODTHYt',    'R_TRYPTAOX',    'R_TSTSTERONESULT',    'R_UGT1A2r',    'R_UGT1A5r2',    'R_URIK1',
    'R_URIt',    'R_URIt4',    'R_VLCS2r',    'R_r0027',    'R_r0028',    'R_r0047',
    'R_r0083',    'R_r0084',    'R_r0129',    'R_r0130',    'R_r0139',    'R_r0149',
    'R_r0173',    'R_r0181',    'R_r0221',    'R_r0245',    'R_r0246',    'R_r0308',
    'R_r0310',    'R_r0311',    'R_r0317',    'R_r0319',    'R_r0391',    'R_r0393',
    'R_r0407',    'R_r0423',    'R_r0424',    'R_r0425',    'R_r0426',    'R_r0494',
    'R_r0497',    'R_r0545',    'R_r0546',    'R_r0547',    'R_r0548',    'R_r0615',
    'R_r0616',    'R_r0617',    'R_r0618',    'R_r0641',    'R_r0642',    'R_r0643',
    'R_r0648',    'R_r0649',    'R_r0650',    'R_r0655',    'R_r0688',    'R_r0739',
    'R_r0752',    'R_r0753',    'R_r0754',    'R_r0755',    'R_r0756',    'R_r0757',
    'R_r0758',    'R_r0787',    'R_r0879',    'R_r1043',    'R_r1044',    'R_r1045',
    'R_r1090',    'R_r1155',    'R_r1156',    'R_r1164',    'R_r1165',    'R_r1166',
    'R_r1167',    'R_r1171',    'R_r1174',    'R_r1175',    'R_r1177',    'R_r1183',
    'R_r1251',    'R_r1252',    'R_r1253',    'R_r1254',    'R_r1255',    'R_r1257',
    'R_r1259',    'R_r1260',    'R_r1262',    'R_r1418',    'R_r1443',    'R_r1444',
    'R_r1445',    'R_r1446',    'R_r1447',    'R_r1448',    'R_r1449',    'R_r1450',
    'R_r1451',    'R_r1454',    'R_r1487',    'R_RE0344C',    'R_RE0512M',    'R_RE0512X',
    'R_RE0577C',    'R_RE0578C',    'R_RE0579C',    'R_RE0912C',    'R_RE0915E',    'R_RE0926E',
    'R_RE0935E',    'R_RE0944E',    'R_RE0958E',    'R_RE1516M',    'R_RE1516X',    'R_RE1517M',
    'R_RE1517X',    'R_RE1518M',    'R_RE1518X',    'R_RE1519X',    'R_RE1520M',    'R_RE1521M',
    'R_RE1522M',    'R_RE1523M',    'R_RE1525M',    'R_RE1525X',    'R_RE1526M',    'R_RE1526X',
    'R_RE1527M',    'R_RE1527X',    'R_RE1531M',    'R_RE1532M',    'R_RE1533M',    'R_RE1534M',
    'R_RE1573M',    'R_RE1573X',    'R_RE1834C',    'R_RE1834M',    'R_RE1834X',    'R_RE1835C',
    'R_RE2235R',    'R_RE2445E',    'R_RE2649C',    'R_RE2649M',    'R_RE2888C',    'R_RE2912M',
    'R_RE2985X',    'R_RE2987X',    'R_RE2991X',    'R_RE2992M',    'R_RE2992X',    'R_RE2994X',
    'R_RE2997X',    'R_RE2999M',    'R_RE3002X',    'R_RE3003M',    'R_RE3004M',    'R_RE3005M',
    'R_RE3006M',    'R_RE3012M',    'R_RE3012R',    'R_RE3014R',    'R_RE3015R',    'R_RE3074X',
    'R_RE3082X',    'R_RE3086X',    'R_RE3095C',    'R_RE3114R',    'R_RE3132R',    'R_RE3146R',
    'R_RE3156X',    'R_RE3157X',    'R_RE3160R',    'R_RE3177M',    'R_RE3178M',    'R_RE3179M',
    'R_RE3185M',    'R_RE3186M',    'R_RE3189M',    'R_RE3190M',    'R_RE3191M',    'R_RE3192M',
    'R_RE3193M',    'R_RE3194M',    'R_RE3269C',    'R_RE3628M',    'R_C100CPT1',    'R_C101CPT1',
    'R_C102CPT1',    'R_C10DCc',    'R_C10OHc',    'R_C120CPT1',    'R_C121CPT1',    'R_C12OHc',
    'R_C140CPT1',    'R_C141CPT1',    'R_C142CPT1',    'R_C14OHc',    'R_C16DCc',    'R_C181OHc',
    'R_C182OHc',    'R_C30CPT1',    'R_C40CPT1',    'R_C4OHc',    'R_C51CPT1',    'R_C60CPT1',
    'R_C6DCc',    'R_C80CPT1',    'R_C81CPT1',    'R_C8DCc',    'R_DOCO13EFATP',    'R_FAOXC101C102m',
    'R_FAOXC101x',    'R_FAOXC102x',    'R_FAOXC121x',    'R_FAOXC122x',    'R_FAOXC123x',    'R_FAOXC12DCc',
    'R_FAOXC163x',    'R_FAOXC164x',    'R_FAOXC184x',    'R_FAOXC225x',    'R_FAOXC3DC',    'R_FAOXC4C4DCc',
    'R_FAOXC61x',    'R_OCT11EFATP',    'R_OCTDECCPT1',    'R_ASCBSVCTtc',    'R_CHOLESACATc',    'R_FMNALKPle',
    'R_P5CR',    'R_PHEMEe',    'R_ARACHDFATPtc',    'R_FOLABCCte',    'R_FOLOAT2tc',    'R_H2OGLYAQPt',
    'R_LGNCFATPtc',    'R_CAMPt',    'R_CGMPt',    'R_GALt4',    'R_GCHOLAt3',    'R_GLCt4',
    'R_TCHOLAt3',    'R_TRPt',    'R_CHSTEROLt',    'R_r0963',    'R_SMS1',    'R_SMS10',
    'R_SMS11',    'R_SMS12',    'R_SMS16',    'R_SMS13',    'R_SMS14',    'R_SMS15',
    'R_SMS2',    'R_SMS3',    'R_SMS4',    'R_SMS5',    'R_SMS6',    'R_SMS7',
    'R_SMS8',    'R_SMS9',    'R_PCHOLMYR_HSPLA2',    'R_PCHOLOLE_HSPLA2',    'R_PEOLE_HSPLA2',    'R_PCHOLPALME_HSPLA2',
    'R_PCHOLPALM_HSPLA2',    'R_PEPALM_HSPLA2',    'R_PAILPALM_HSPLA2',    'R_PCHOLSTE_HSPLA2',    'R_PCHOL2LINL_HSPLA2',    'R_PE2LINL_HSPLA2',
    'R_PCHOL2OLE_HSPLA2',    'R_PCHOL2PALM_HSPLA2',    'R_PCHOL2STE_HSPLA2',    'R_PCHOLN15_HSPLA2',    'R_PCHOLAR_HSPLA2',    'R_PCHOLN183_HSPLA2',
    'R_PCHOLN1836_HSPLA2',    'R_PCHOLN19_HSPLA2',    'R_PCHOLN201_HSPLA2',    'R_PCHOLN204_HSPLA2',    'R_PCHOLN205_HSPLA2',    'R_PCHOLN224_HSPLA2',
    'R_PCHOLN225_HSPLA2',    'R_PCHOLN2254_HSPLA2',    'R_PCHOLN226_HSPLA2',    'R_PEAR_HSPLA2',    'R_PE203_HSPLA2',    'R_PE226_HSPLA2',
    'R_PE224_HSPLA2',    'R_PEDH203_HSPLA2',    'R_PEDH12_HSPLA2',    'R_PEDH14_HSPLA2',    'R_PEDH161_HSPLA2',    'R_PEDH13_HSPLA2',
    'R_PEDH15_HSPLA2',    'R_PEDH17_HSPLA2',    'R_PCHOLN203_HSPLA2',    'R_PAILAR_HSPLA2',    'R_PCHOLN24_HSPLA2',    'R_PCHOLN261_HSPLA2',
    'R_PCHOLN281_HSPLA2',    'R_PCHOLN28_HSPLA2',    'R_PCHOLDOC_HSPLA2',    'R_PCHOLDEIC_HSPLA2',    'R_PCHOLDET_HSPLA2',    'R_PCHOLHEP_HSPLA2',
    'R_PCHOLLINL_HSPLA2',    'R_PELINL_HSPLA2',    'R_ARACHETH',    'R_C03990ATP',    'R_C04483t1',    'R_C05463t1',
    'R_CE1273t1',    'R_DIDECAETH',    'R_DIHOLINETH',    'R_DOCOHEXETHc',    'R_DOCTETETH',    'R_HEPDECETH',
    'R_HEXDECEETH',    'R_OLEETH',    'R_PELINETH',    'R_PENDECAETH',    'R_PEPALM',    'R_STEETH',
    'R_TETDECAETH',    'R_TRIDECETH',    'R_HC02195te',    'R_HC02196te',    'R_HC02194te',    'R_HC02220te',
    'R_ARGtD',    'R_DHCHOLESTANATEATP',    'R_THCHOLSTOICATP',    'R_XOL7AH3ATP',    'R_XOL7AONEATP',    'R_XOLDIOLONEATP',
    'R_7KILTCHOLATP',    'R_ACACt2',    'R_ACCOAL',    'R_ACONT',    'R_ACS',    'R_ADK1',
    'R_ARGN',    'R_DURIPP',    'R_FBA',    'R_FBA2',    'R_GHMT2r',    'R_H2CO3D',
    'R_L_LACt2r',    'R_MAN1PT2',    'R_MTHFC',    'R_MTHFD',    'R_NAt3_1',    'R_NDPK1',
    'R_NDPK2',    'R_NDPK3',    'R_NDPK4',    'R_NDPK5',    'R_NDPK6',    'R_NDPK7',
    'R_NDPK8',    'R_NDPK9',    'R_NNATr',    'R_PGMT',    'R_PMANM',    'R_PPM',
    'R_PROt2r',    'R_TMDK1',    'R_UREAt',    'R_r0220',    'R_r0318',    'R_r0345',
    'R_r0422',    'R_GLYt2r',    'R_ALAt2r',    'R_NTD4',    'R_NTD5',    'R_NTD6',
    'R_NTD7',    'R_NTD8',    'R_NTD9',    'R_NTD10',    'R_NTD11',    'R_ALCD1',
    'R_GCALDD',    'R_ALDD2x',    'R_AMANK',    'R_GLXO1',    'R_IMACTD',    'R_LCADi',
    'R_LDH_D',    'R_LDH_L',    'R_MI1PP',    'R_NT5C',    'R_NTD3',    'R_PFK',
    'R_THRD_L',    'R_r0392',    'R_PYRt2r',    'R_THMt3',    'R_FORTHFC',    'R_MTHFD2',
    'R_PHPYRte',    'R_2H3MVc',    'R_2HIVc',    'R_AK2LGCHOLABCt',    'R_CE2510ABCt',    'R_CE2537ABCt',
    'R_NRVNCABCt',    'R_PAFABCt',    'R_PCHLN225_HSABCt',    'R_PCHOL2LINL_HSABCt',    'R_PCHOL2OLE_HSABCt',    'R_PCHOL2STE_HSABCt',
    'R_PCHOLAR_HSABCt',    'R_PCHOLDOC_HSABCt',    'R_PCHOLEIC_HSABCt',    'R_PCHOLET_HSABCt',    'R_PCHOLHEP_HSABCt',    'R_PCHOLLINL_HSABCt',
    'R_PCHOLMYR_HsABCt',    'R_PCHOLN15_HSABCt',    'R_PCHOLN183_HSABCt',    'R_PCHOLN1836_HSABCt',    'R_PCHOLN19_HSABCt',    'R_PCHOLN201_HSABCt',
    'R_PCHOLN203_HSABCt',    'R_PCHOLN204_HSABCt',    'R_PCHOLN205_HSABCt',    'R_PCHOLN224_HSABCt',    'R_PCHOLN225_HSABCt',    'R_PCHOLN2254_HSABCt',
    'R_PCHOLN264_HSABCt',    'R_PCHOLOLE_HSABCt',    'R_PCHOLPALME-HSABCt',    'R_PCHOLSTE_HSABCt',    'R_PEPALM_HSASBCt',    'R_EIC21114TRc',
    'R_5EIPENCm',    'R_CE7090te',    'R_CE7085te',    'R_CE7096te',    'R_CE4877te',    'R_CE1447te',
    'R_C05770te',    'R_MLTHFte3',    'R_CE2705t',    'R_SPHS1Pt2e',    'R_MMAte',    'R_HDD2CRNte2',
    'R_MLTHFte1',    'R_CE1918te',    'R_34DHOXMANDte',    'R_CE6205te',    'R_1A25DHVITD3te',    'R_CE5026t',
    'R_SMS1S2',    'R_HMR_0003',    'R_HMR_0155',    'R_HMR_0164',    'R_HMR_0167',    'R_HMR_0170',
    'R_HMR_0176',    'R_HMR_0183',    'R_HMR_0188',    'R_HMR_0189',    'R_HMR_0191',    'R_HMR_0192',
    'R_HMR_0193',    'R_HMR_0197',    'R_HMR_0200',    'R_HMR_0201',    'R_HMR_0203',    'R_HMR_0204',
    'R_HMR_0206',    'R_HMR_0208',    'R_HMR_0209',    'R_HMR_0210',    'R_HMR_0214',    'R_HMR_0230',
    'R_HMR_0232',    'R_HMR_0233',    'R_HMR_0234',    'R_HMR_0238',    'R_HMR_0240',    'R_HMR_0241',
    'R_HMR_0242',    'R_HMR_0244',    'R_HMR_0245',    'R_HMR_0246',    'R_HMR_0254',    'R_HMR_0255',
    'R_HMR_0256',    'R_HMR_0259',    'R_HMR_0260',    'R_HMR_0267',    'R_HMR_0268',    'R_HMR_0270',
    'R_HMR_0271',    'R_HMR_0272',    'R_HMR_0276',    'R_HMR_0278',    'R_HMR_0279',    'R_HMR_0280',
    'R_HMR_0288',    'R_HMR_0289',    'R_HMR_0290',    'R_HMR_0292',    'R_HMR_0293',    'R_HMR_0296',
    'R_HMR_0297',    'R_HMR_0298',    'R_HMR_0300',    'R_HMR_0301',    'R_HMR_0302',    'R_HMR_0304',
    'R_HMR_0305',    'R_HMR_0306',    'R_HMR_0308',    'R_HMR_0309',    'R_HMR_0310',    'R_HMR_0319',
    'R_HMR_0322',    'R_HMR_0323',    'R_HMR_0324',    'R_HMR_0326',    'R_HMR_0327',    'R_HMR_0328',
    'R_HMR_0342',    'R_HMR_0344',    'R_HMR_0345',    'R_HMR_0346',    'R_HMR_0350',    'R_HMR_0354',
    'R_HMR_0358',    'R_HMR_0362',    'R_HMR_0366',    'R_HMR_0370',    'R_HMR_0374',    'R_HMR_0378',
    'R_HMR_0380',    'R_HMR_0381',    'R_HMR_0382',    'R_HMR_0384',    'R_HMR_0385',    'R_HMR_0386',
    'R_HMR_0388',    'R_HMR_0389',    'R_HMR_0390',    'R_HMR_0392',    'R_HMR_0393',    'R_HMR_0394',
    'R_HMR_0398',    'R_HMR_0402',    'R_HMR_0406',    'R_HMR_0410',    'R_HMR_0414',    'R_HMR_0418',
    'R_HMR_0422',    'R_HMR_0426',    'R_HMR_0428',    'R_HMR_0429',    'R_HMR_0430',    'R_HMR_0432',
    'R_HMR_0433',    'R_HMR_0434',    'R_HMR_0436',    'R_HMR_0437',    'R_HMR_0438',    'R_HMR_0597',
    'R_HMR_0598',    'R_HMR_0601',    'R_HMR_0614',    'R_HMR_0625',    'R_HMR_0629',    'R_HMR_0642',
    'R_HMR_0672',    'R_HMR_0753',    'R_HMR_0765',    'R_HMR_0767',    'R_HMR_0775',    'R_HMR_0795',
    'R_HMR_0807',    'R_HMR_0808',    'R_HMR_0812',    'R_HMR_0817',    'R_HMR_0819',    'R_HMR_0821',
    'R_HMR_0823',    'R_HMR_0825',    'R_HMR_0828',    'R_HMR_0830',    'R_HMR_0837',    'R_HMR_0844',
    'R_HMR_0847',    'R_HMR_0855',    'R_HMR_0860',    'R_HMR_0864',    'R_HMR_0870',    'R_HMR_0873',
    'R_HMR_0875',    'R_HMR_0889',    'R_HMR_0890',    'R_HMR_0911',    'R_HMR_0942',    'R_HMR_0946',
    'R_HMR_0950',    'R_HMR_0954',    'R_HMR_0960',    'R_HMR_0963',    'R_HMR_0981',    'R_HMR_1084',
    'R_HMR_1102',    'R_HMR_1126',    'R_HMR_1127',    'R_HMR_1312',    'R_HMR_1490',    'R_HMR_1493',
    'R_HMR_1494',    'R_HMR_1495',    'R_HMR_1502',    'R_HMR_1503',    'R_HMR_1504',    'R_HMR_1532',
    'R_HMR_1540',    'R_HMR_1543',    'R_HMR_1544',    'R_HMR_1545',    'R_HMR_1548',    'R_HMR_1549',
    'R_HMR_1550',    'R_HMR_1620',    'R_HMR_1627',    'R_HMR_1637',    'R_HMR_1651',    'R_HMR_1653',
    'R_HMR_1665',    'R_HMR_1666',    'R_HMR_1754',    'R_HMR_1756',    'R_HMR_2016',    'R_HMR_2018',
    'R_HMR_2029',    'R_HMR_2041',    'R_HMR_2088',    'R_HMR_2089',    'R_HMR_2190',    'R_HMR_2210',
    'R_HMR_2211',    'R_HMR_2215',    'R_HMR_2219',    'R_HMR_2259',    'R_HMR_2262',    'R_HMR_2263',
    'R_HMR_2266',    'R_HMR_2267',    'R_HMR_2332',    'R_HMR_2338',    'R_HMR_2342',    'R_HMR_2345',
    'R_HMR_2347',    'R_HMR_2350',    'R_HMR_2353',    'R_HMR_2356',    'R_HMR_2359',    'R_HMR_2361',
    'R_HMR_2364',    'R_HMR_2365',    'R_HMR_2368',    'R_HMR_2380',    'R_HMR_2395',    'R_HMR_2433',
    'R_HMR_2436',    'R_HMR_2457',    'R_HMR_2472',    'R_HMR_2484',    'R_HMR_2530',    'R_HMR_2537',
    'R_HMR_2540',    'R_HMR_2543',    'R_HMR_2581',    'R_HMR_2602',    'R_HMR_2603',    'R_HMR_2604',
    'R_HMR_2608',    'R_HMR_2609',    'R_HMR_2610',    'R_HMR_2611',    'R_HMR_2612',    'R_HMR_2613',
    'R_HMR_2620',    'R_HMR_2621',    'R_HMR_2622',    'R_HMR_2624',    'R_HMR_2633',    'R_HMR_2634',
    'R_HMR_2635',    'R_HMR_2644',    'R_HMR_2648',    'R_HMR_2649',    'R_HMR_2650',    'R_HMR_2651',
    'R_HMR_2652',    'R_HMR_2653',    'R_HMR_2655',    'R_HMR_2657',    'R_HMR_2659',    'R_HMR_2660',
    'R_HMR_2661',    'R_HMR_2662',    'R_HMR_2666',    'R_HMR_2667',    'R_HMR_2668',    'R_HMR_2669',
    'R_HMR_2670',    'R_HMR_2671',    'R_HMR_2673',    'R_HMR_2675',    'R_HMR_2676',    'R_HMR_2677',
    'R_HMR_2679',    'R_HMR_2681',    'R_HMR_2682',    'R_HMR_2683',    'R_HMR_2684',    'R_HMR_2685',
    'R_HMR_2686',    'R_HMR_2687',    'R_HMR_2688',    'R_HMR_2689',    'R_HMR_2690',    'R_HMR_2691',
    'R_HMR_2692',    'R_HMR_2693',    'R_HMR_2695',    'R_HMR_2697',    'R_HMR_2699',    'R_HMR_2700',
    'R_HMR_2701',    'R_HMR_2702',    'R_HMR_2703',    'R_HMR_2704',    'R_HMR_2705',    'R_HMR_2706',
    'R_HMR_2707',    'R_HMR_2708',    'R_HMR_2709',    'R_HMR_2710',    'R_HMR_2711',    'R_HMR_2712',
    'R_HMR_2713',    'R_HMR_2715',    'R_HMR_2718',    'R_HMR_2722',    'R_HMR_2727',    'R_HMR_2731',
    'R_HMR_2733',    'R_HMR_2734',    'R_HMR_2735',    'R_HMR_2736',    'R_HMR_2737',    'R_HMR_2738',
    'R_HMR_2739',    'R_HMR_2740',    'R_HMR_2741',    'R_HMR_2744',    'R_HMR_2748',    'R_HMR_2753',
    'R_HMR_2757',    'R_HMR_2760',    'R_HMR_2764',    'R_HMR_2768',    'R_HMR_2769',    'R_HMR_2770',
    'R_HMR_2771',    'R_HMR_2772',    'R_HMR_2773',    'R_HMR_2774',    'R_HMR_2775',    'R_HMR_2776',
    'R_HMR_2942',    'R_HMR_2943',    'R_HMR_2944',    'R_HMR_2945',    'R_HMR_2946',    'R_HMR_2947',
    'R_HMR_2948',    'R_HMR_2951',    'R_HMR_2954',    'R_HMR_2955',    'R_HMR_2956',    'R_HMR_2961',
    'R_HMR_2962',    'R_HMR_2963',    'R_HMR_2964',    'R_HMR_2965',    'R_HMR_2966',    'R_HMR_2967',
    'R_HMR_2968',    'R_HMR_2969',    'R_HMR_2970',    'R_HMR_2971',    'R_HMR_2972',    'R_HMR_2973',
    'R_HMR_2974',    'R_HMR_2975',    'R_HMR_2976',    'R_HMR_2977',    'R_HMR_2978',    'R_HMR_2979',
    'R_HMR_2980',    'R_HMR_2982',    'R_HMR_2983',    'R_HMR_2985',    'R_HMR_2986',    'R_HMR_2988',
    'R_HMR_2989',    'R_HMR_2990',    'R_HMR_2994',    'R_HMR_2998',    'R_HMR_2999',    'R_HMR_3001',
    'R_HMR_3002',    'R_HMR_3003',    'R_HMR_3057',    'R_HMR_3059',    'R_HMR_3062',    'R_HMR_3064',
    'R_HMR_3065',    'R_HMR_3066',    'R_HMR_3068',    'R_HMR_3069',    'R_HMR_3070',    'R_HMR_3072',
    'R_HMR_3073',    'R_HMR_3074',    'R_HMR_3076',    'R_HMR_3094',    'R_HMR_3096',    'R_HMR_3097',
    'R_HMR_3098',    'R_HMR_3100',    'R_HMR_3101',    'R_HMR_3102',    'R_HMR_3107',    'R_HMR_3108',
    'R_HMR_3109',    'R_HMR_3110',    'R_HMR_3111',    'R_HMR_3112',    'R_HMR_3113',    'R_HMR_3114',
    'R_HMR_3115',    'R_HMR_3116',    'R_HMR_3117',    'R_HMR_3118',    'R_HMR_3121',    'R_HMR_3128',
    'R_HMR_3135',    'R_HMR_3142',    'R_HMR_3149',    'R_HMR_3170',    'R_HMR_3171',    'R_HMR_3172',
    'R_HMR_3173',    'R_HMR_3174',    'R_HMR_3175',    'R_HMR_3176',    'R_HMR_3177',    'R_HMR_3178',
    'R_HMR_3179',    'R_HMR_3180',    'R_HMR_3181',    'R_HMR_3182',    'R_HMR_3183',    'R_HMR_3184',
    'R_HMR_3185',    'R_HMR_3186',    'R_HMR_3187',    'R_HMR_3188',    'R_HMR_3189',    'R_HMR_3190',
    'R_HMR_3191',    'R_HMR_3192',    'R_HMR_3193',    'R_HMR_3194',    'R_HMR_3195',    'R_HMR_3196',
    'R_HMR_3197',    'R_HMR_3198',    'R_HMR_3199',    'R_HMR_3200',    'R_HMR_3201',    'R_HMR_3203',
    'R_HMR_3204',    'R_HMR_3205',    'R_HMR_3218',    'R_HMR_3219',    'R_HMR_3220',    'R_HMR_3221',
    'R_HMR_3222',    'R_HMR_3223',    'R_HMR_3224',    'R_HMR_3225',    'R_HMR_3229',    'R_HMR_3230',
    'R_HMR_3231',    'R_HMR_3232',    'R_HMR_3233',    'R_HMR_3234',    'R_HMR_3235',    'R_HMR_3236',
    'R_HMR_3237',    'R_HMR_3240',    'R_HMR_3241',    'R_HMR_3242',    'R_HMR_3243',    'R_HMR_3244',
    'R_HMR_3245',    'R_HMR_3246',    'R_HMR_3247',    'R_HMR_3296',    'R_HMR_3321',    'R_HMR_3322',
    'R_HMR_3326',    'R_HMR_3328',    'R_HMR_3329',    'R_HMR_3330',    'R_HMR_3332',    'R_HMR_3333',
    'R_HMR_3334',    'R_HMR_3336',    'R_HMR_3337',    'R_HMR_3338',    'R_HMR_3340',    'R_HMR_3341',
    'R_HMR_3342',    'R_HMR_3344',    'R_HMR_3345',    'R_HMR_3346',    'R_HMR_3348',    'R_HMR_3349',
    'R_HMR_3350',    'R_HMR_3352',    'R_HMR_3353',    'R_HMR_3398',    'R_HMR_3406',    'R_HMR_3407',
    'R_HMR_3408',    'R_HMR_3409',    'R_HMR_3411',    'R_HMR_3413',    'R_HMR_3414',    'R_HMR_3416',
    'R_HMR_3421',    'R_HMR_3422',    'R_HMR_3423',    'R_HMR_3424',    'R_HMR_3425',    'R_HMR_3426',
    'R_HMR_3427',    'R_HMR_3428',    'R_HMR_3429',    'R_HMR_3431',    'R_HMR_3432',    'R_HMR_3433',
    'R_HMR_3446',    'R_HMR_3447',    'R_HMR_3448',    'R_HMR_3449',    'R_HMR_3450',    'R_HMR_3451',
    'R_HMR_3452',    'R_HMR_3453',    'R_HMR_3454',    'R_HMR_3455',    'R_HMR_3456',    'R_HMR_3457',
    'R_HMR_3505',    'R_HMR_3522',    'R_HMR_3625',    'R_HMR_3626',    'R_HMR_3627',    'R_HMR_3628',
    'R_HMR_3629',    'R_HMR_3630',    'R_HMR_3631',    'R_HMR_3633',    'R_HMR_3635',    'R_HMR_3636',
    'R_HMR_3637',    'R_HMR_3639',    'R_HMR_3640',    'R_HMR_3642',    'R_HMR_3644',    'R_HMR_3645',
    'R_HMR_3646',    'R_HMR_3647',    'R_HMR_3648',    'R_HMR_3649',    'R_HMR_3650',    'R_HMR_3651',
    'R_HMR_3652',    'R_HMR_3653',    'R_HMR_3654',    'R_HMR_3655',    'R_HMR_3656',    'R_HMR_3657',
    'R_HMR_3658',    'R_HMR_3659',    'R_HMR_3660',    'R_HMR_3662',    'R_HMR_3663',    'R_HMR_3664',
    'R_HMR_3665',    'R_HMR_3666',    'R_HMR_3667',    'R_HMR_3668',    'R_HMR_3669',    'R_HMR_3670',
    'R_HMR_3677',    'R_HMR_3678',    'R_HMR_3679',    'R_HMR_3680',    'R_HMR_3681',    'R_HMR_3682',
    'R_HMR_3684',    'R_HMR_3685',    'R_HMR_3686',    'R_HMR_3687',    'R_HMR_3688',    'R_HMR_3689',
    'R_HMR_3690',    'R_HMR_3692',    'R_HMR_3694',    'R_HMR_3695',    'R_HMR_3696',    'R_HMR_3698',
    'R_HMR_3699',    'R_HMR_3701',    'R_HMR_3703',    'R_HMR_3704',    'R_HMR_3705',    'R_HMR_3706',
    'R_HMR_3707',    'R_HMR_3708',    'R_HMR_3709',    'R_HMR_3710',    'R_HMR_3711',    'R_HMR_3712',
    'R_HMR_3713',    'R_HMR_3714',    'R_HMR_3715',    'R_HMR_3716',    'R_HMR_3717',    'R_HMR_3718',
    'R_HMR_3719',    'R_HMR_3721',    'R_HMR_3722',    'R_HMR_3723',    'R_HMR_3724',    'R_HMR_3725',
    'R_HMR_3726',    'R_HMR_3727',    'R_HMR_3728',    'R_HMR_3729',    'R_HMR_3736',    'R_HMR_3737',
    'R_HMR_3738',    'R_HMR_3739',    'R_HMR_3740',    'R_HMR_3741',    'R_HMR_3855',    'R_HMR_3859',
    'R_HMR_4079',    'R_HMR_4270',    'R_HMR_4592',    'R_HMR_5301',    'R_HMR_5996',    'R_HMR_6534',
    'R_HMR_6545',    'R_HMR_6550',    'R_HMR_6558',    'R_HMR_6595',    'R_HMR_6632',    'R_HMR_6633',
    'R_HMR_6647',    'R_HMR_6747',    'R_HMR_6755',    'R_HMR_6790',    'R_HMR_6826',    'R_HMR_6838',
    'R_HMR_6844',    'R_HMR_6850',    'R_HMR_6975',    'R_HMR_6976',    'R_HMR_6977',    'R_HMR_7652',
    'R_HMR_8271',    'R_HMR_8475',    'R_HMR_8476',    'R_HMR_8570',    'R_HMR_8571',    'R_HMR_8572',
    'R_HMR_8573',    'R_HMR_8574',    'R_HMR_8575',    'R_HMR_8576',    'R_HMR_8577',    'R_HMR_8578',
    'R_HMR_8579',    'R_HMR_8580',    'R_HMR_8582',    'R_HMR_8643',    'R_HMR_8762',    'R_HMR_9191',
    'R_HMR_9593',    'R_HMR_9623',    'R_HMR_9624',    'R_HMR_9719',    'R_HMR_2957',    'R_HMR_1484',
    'R_HMR_0980',    'R_12DHCHOLabc',    'R_12DHCHOLt',    'R_12DHCHOLt2',    'R_3DHCDCHOLabc',    'R_3DHCDCHOLt',
    'R_3DHCDCHOLt2',    'R_3DHCHOLabc',    'R_3DHCHOLt',    'R_3DHCHOLt2',    'R_3DHDCAabc',    'R_3DHDCAt',
    'R_3DHDCAt2',    'R_3DHLCAabc',    'R_3DHLCAt',    'R_3DHLCAt2',    'R_7DHCDCHOLabc',    'R_7DHCDCHOLt',
    'R_7DHCDCHOLt2',    'R_7DHCHOLabc',    'R_7DHCHOLt',    'R_7DHCHOLt2',    'R_CDCA24GSc',    'R_CDCA24GSr',
    'R_CDCA24Gte',    'R_CDCA3GSc',    'R_CDCA3GSr',    'R_CDCA3Gte',    'R_COPROSTabc',    'R_COPROSTt',
    'R_COPROSTt2',    'R_HCA24GSc',    'R_HCA24GSr',    'R_HCA24Gte',    'R_HDCA24GSc',    'R_HDCA24GSr',
    'R_HDCA24Gte',    'R_HDCA6GSc',    'R_HDCA6GSr',    'R_HDCA6Gte',    'R_HYOCHOLabc',    'R_HYOCHOLt',
    'R_HYOCHOLt2',    'R_ICDCHOLabc',    'R_ICDCHOLt',    'R_ICDCHOLt2',    'R_ISOCHOLabc',    'R_ISOCHOLt',
    'R_ISOCHOLt2',    'R_LCA24GSc',    'R_LCA24GSr',    'R_LCA24Gte',    'R_LCA3GSc',    'R_LCA3GSr',
    'R_LCA3Gte',    'R_THYOCHOLabc',    'R_THYOCHOLt',    'R_THYOCHOLt2',    'R_UCHOLabc',    'R_UCHOLt',
    'R_UCHOLt2',    'R_UDCHOLt',    'R_UDCHOLt2',    'R_12HTACRhr',    'R_14HMDZALThr',    'R_14HMDZhr',
    'R_1HIBUP_SGLUhep',    'R_1HMDGLUChr',    'R_1OHMDZhr',    'R_2HATVACIDOXDhc',    'R_2HATVLACGLUChr',    'R_2HATVLACGLUCteb',
    'R_2HATVLACOXDhc',    'R_2HIBUP_SGLUhep',    'R_35DSMVhep',    'R_3HIBUP_SGLUhep',    'R_3HPVSTETCOAhcm',    'R_3HPVSTETCOAhcx',
    'R_3HPVSTETteb',    'R_3HPVShc',    'R_3HPVSteb',    'R_3HSMVhep',    'R_3ISPVSteb',    'R_3OHACMPhr',
    'R_4HATVACIDOXDhc',    'R_4HATVLACOXDhc',    'R_4HMDZGLUChr',    'R_4OHMDZhr',    'R_56DHPVSteb',    'R_56EPPVSteb',
    'R_5OHFVShc',    'R_6BHGLZhr',    'R_6CSMVhep',    'R_6EPSteb',    'R_6HMSMVhep',    'R_6HSMVhep',
    'R_6MSMVhep',    'R_7BHGLZhr',    'R_7HPVSteb',    'R_AM19CSALThr',    'R_AM1CSAhr',    'R_AM9CSAhr',
    'R_ATVACYLGLUChc',    'R_ATVETHGLUChc',    'R_ATVLACGLCURhc',    'R_CARIBUP_SGLUhep',    'R_CRVS1M24hc',    'R_CRVS23M24hc',
    'R_CRVSM1hc',    'R_DEOXFVShc',    'R_DSPVSteb',    'R_GLC3MEACPhr',    'R_IBUPGT_HEP',    'R_IBUP_RCYP2hep',
    'R_IBUP_RCYP3hep',    'R_IBUP_SCYP2hep',    'R_IBUP_SCYP3hep',    'R_LSTNM7hr',    'R_LVSTACOXD6Hhep',    'R_LVSTACOXD6MEhep',
    'R_LVSTOXD3Hhep',    'R_LVSTOXD6Hhep',    'R_LVSTOXD6METhep',    'R_NFDACOXDhc',    'R_PROFVSCOAhc',    'R_PTVSTGLUChc',
    'R_PTVSTM13hr',    'R_PVSGLUCteb',    'R_TRIPVSteb',    'R_Htmi',    'R_Abeta_N6_methyl_L_lysine',    'R_Abeta_N6_dimethyl_L_lysine',
    'R_Abeta_N6_N6_trimethyl_L_lysine',    'R_Tau_N6_methyl_L_lysine',    'R_Tau_N6_dimethyl_L_lysine',    'R_Tau_N6_N6_trimethyl_L_lysine',    'R_TNFA_N6_methyl_L_lysine',    'R_TNFA_N6_dimethyl_L_lysine',
    'R_TNFA_N6_N6_trimethyl_L_lysine',    'R_IL6_N6_methyl_L_lysine',    'R_IL6_N6_dimethyl_L_lysine',    'R_IL6_N6_N6_trimethyl_L_lysine'
   /

  isozyme_rxn_enz(reactions, enzymes) "regulated reaction and its relative isozymes in BL model"
   /
    'R_13DAMPPOX'.('E0001', 'E0002', 'E0003', 'E0004')
    'R_2HBO'.('E0010', 'E0012', 'E0014', 'E0017')
    'R_2HBt2'.('E0018', 'E0019', 'E0020')
    'R_34DHOXPEGOX'.('E0028', 'E0030', 'E0033', 'E0034')
    'R_34DHPHAMT'.('E0036', 'E0037')
    'R_34DHPLACOX'.('E0039', 'E0040', 'E0041')
    'R_34DHPLACOX_NADP_'.('E0039', 'E0040')
    'R_3AIBTm'.('E0044', 'E0045')
    'R_3AIBtmi'.('E0044', 'E0045')
    'R_3HKYNAKGAT'.('E0049', 'E0050', 'E0051')
    'R_3MOX4HOXPGALDOX'.('E0039', 'E0040', 'E0041')
    'R_3MOX4HOXPGALDOX_NADP_'.('E0039', 'E0040', 'E0041')
    'R_41R1H2MAE12BOOX'.('E0053', 'E0054')
    'R_42A12BOOX'.('E0001', 'E0002', 'E0003', 'E0004', 'E0053', 'E0054')
    'R_4HOXPACDOX_NADP_'.('E0039', 'E0040', 'E0041')
    'R_4NPHSULT'.('E0065', 'E0066', 'E0068')
    'R_5ADTSTSTERONESULT'.('E0008', 'E0075')
    'R_5HOXINOXDA'.('E0053', 'E0054')
    'R_5MTHFt'.('E0081', 'E0083')
    'R_AATAi'.('E0049', 'E0051')
    'R_ABTArm'.('E0044', 'E0045')
    'R_ABUTt4_2_r'.('E0093', 'E0096')
    'R_ACETONEt2'.('E0018', 'E0019', 'E0020')
    'R_ACNAMPH'.('E0119', 'E0120')
    'R_ACOAD10m'.('E0122', 'E0123')
    'R_ACOAD1fm'.('E0122', 'E0123', 'E0124', 'E0125', 'E0127', 'E0128')
    'R_ACOAD9m'.('E0123', 'E0127')
    'R_ACOAO7p'.('E0131', 'E0132')
    'R_ACONTm'.('E0134', 'E0135')
    'R_ACP1_FMN_'.('E0120', 'E0137', 'E0138', 'E0140')
    'R_ACS2'.('E0142', 'E0143', 'E0144')
    'R_ADK1m'.('E0149', 'E0150', 'E0151')
    'R_ADK3'.('E0155', 'E0156')
    'R_ADKd'.('E0155', 'E0156')
    'R_ADNt'.('E0148', 'E0170')
    'R_ADNt4'.('E0171', 'E0172', 'E0173', 'E0174')
    'R_ADRNCPT1'.('E0178', 'E0179', 'E0180', 'E0182')
    'R_AG13T16g'.('E0189', 'E0190', 'E0191', 'E0192', 'E0195', 'E0196',
                'E0197')
    'R_AG13T17g'.('E0189', 'E0190', 'E0191', 'E0192', 'E0195', 'E0196',
                'E0197')
    'R_AG13T18g'.('E0189', 'E0190', 'E0191', 'E0192', 'E0195', 'E0196',
                'E0197')
    'R_AG13T1g'.('E0189', 'E0190', 'E0191', 'E0192', 'E0195', 'E0196',
                'E0197')
    'R_AG13T2g'.('E0189', 'E0190', 'E0191', 'E0192', 'E0195', 'E0196',
                'E0197')
    'R_AG13T3g'.('E0189', 'E0190', 'E0191', 'E0192', 'E0195', 'E0196',
                'E0197')
    'R_AHEXASE2ly'.('E0210', 'E0211', 'E0212')
    'R_ALACYSNaEx'.('E0221', 'E0222')
    'R_ALASERNaEx'.('E0221', 'E0222')
    'R_ALAt4'.('E0228', 'E0229', 'E0230', 'E0231', 'E0232', 'E0233',
                'E0236')
    'R_ALATHRNaEx'.('E0221', 'E0222')
    'R_ALCD21_D'.('E0028', 'E0030', 'E0033', 'E0034', 'E0241', 'E0242')
    'R_ALCD21_L'.('E0028', 'E0030', 'E0033', 'E0034', 'E0241', 'E0242')
    'R_ALCD22_D'.('E0028', 'E0030', 'E0033', 'E0034', 'E0241', 'E0242')
    'R_ALCD22_L'.('E0028', 'E0030', 'E0033', 'E0034', 'E0241', 'E0242')
    'R_ALCD2if'.('E0028', 'E0030', 'E0033', 'E0034', 'E0241', 'E0242')
    'R_ALCD2yf'.('E0246', 'E0247')
    'R_ALDD20x'.('E0248', 'E0249', 'E0250', 'E0251', 'E0252', 'E0253')
    'R_ALDD20xm'.('E0063', 'E0255', 'E0256')
    'R_ALDD2xm'.('E0255', 'E0256')
    'R_ALDD2y'.('E0039', 'E0040', 'E0249', 'E0251', 'E0252', 'E0253',
                'E0255')
    'R_ALR2'.('E0246', 'E0247', 'E0261', 'E0262')
    'R_ALR3'.('E0246', 'E0247', 'E0261', 'E0262')
    'R_AMACR2p'.('E0263', 'E0264')
    'R_AMY1e'.('E0274', 'E0275', 'E0279', 'E0280')
    'R_AMY2e'.('E0274', 'E0275', 'E0279', 'E0280')
    'R_APAT2rm'.('E0044', 'E0045')
    'R_ARABR'.('E0246', 'E0247', 'E0261', 'E0262')
    'R_ARACHCPT1'.('E0178', 'E0179', 'E0180', 'E0182')
    'R_ARGtm'.('E0288', 'E0289')
    'R_ASAH1'.('E0291', 'E0292')
    'R_ASCBt4'.('E0293', 'E0294', 'E0295')
    'R_ATPH1e'.('E0495', 'E0497', 'E0500')
    'R_ATPH2e'.('E0495', 'E0497', 'E0500', 'E0501')
    'R_B3GALT3g'.('E0506', 'E0507')
    'R_B3GALT5g'.('E0511', 'E0512')
    'R_B3GNT12g'.('E0190', 'E0196')
    'R_BAMPPALDOX'.('E0248', 'E0249', 'E0250', 'E0251', 'E0252', 'E0253')
    'R_C160CPT1'.('E0178', 'E0179', 'E0182')
    'R_C160CPT2'.('E0182', 'E0184')
    'R_C161CPT1'.('E0178', 'E0179', 'E0180', 'E0182')
    'R_C161CPT12'.('E0178', 'E0179', 'E0180', 'E0182')
    'R_C180CPT1'.('E0178', 'E0179', 'E0180', 'E0182')
    'R_C181CPT1'.('E0178', 'E0179', 'E0180', 'E0182')
    'R_C204CPT1'.('E0178', 'E0179', 'E0180', 'E0182')
    'R_C226CPT1'.('E0178', 'E0179', 'E0180', 'E0182')
    'R_C4STMO2r'.('E0540', 'E0542')
    'R_CHOLATEt2'.('E0582', 'E0583')
    'R_CHOLATEt3'.('E0529', 'E0584', 'E0585')
    'R_CHOLK'.('E0588', 'E0589')
    'R_CHOLtu'.('E0593', 'E0594', 'E0595')
    'R_CHSTEROLSULT'.('E0008', 'E0596')
    'R_CITRtm'.('E0288', 'E0289')
    'R_CLHCO3tex2'.('E0611', 'E0612')
    'R_CLOHtex2'.('E0611', 'E0612')
    'R_CLOXAtex2'.('E0611', 'E0612')
    'R_CLPNDCPT1'.('E0178', 'E0179', 'E0180', 'E0182')
    'R_COQ6m'.('E0620', 'E0621')
    'R_CORE2GTg'.('E0623', 'E0624', 'E0625')
    'R_CREATt4_2_r'.('E0627', 'E0628')
    'R_CSNAT2x'.('E0633', 'E0634')
    'R_CYSALANaEx'.('E0221', 'E0222')
    'R_CYSGLUexR'.('E0223', 'E0636')
    'R_CYSGLYexR'.('E0223', 'E0637')
    'R_CYSSERNaEx'.('E0221', 'E0222')
    'R_CYSTHRNaEx'.('E0221', 'E0222')
    'R_CYTDt'.('E0148', 'E0170')
    'R_CYTDt4'.('E0171', 'E0172', 'E0173')
    'R_CYTK3'.('E0155', 'E0156')
    'R_CYTK4'.('E0155', 'E0156')
    'R_DCIm'.('E0667', 'E0668')
    'R_DCSPTN1CPT1'.('E0178', 'E0179', 'E0180', 'E0182')
    'R_DESAT18_9'.('E0672', 'E0673')
    'R_DHAAt1r'.('E0681', 'E0682', 'E0683')
    'R_DHCR242r'.('E0684', 'E0685')
    'R_DHEASULT'.('E0008', 'E0075', 'E0691')
    'R_D_LACt2'.('E0018', 'E0019', 'E0020', 'E0696')
    'R_DLNLCGCPT1'.('E0178', 'E0179', 'E0180', 'E0182')
    'R_DOPAMT'.('E0036', 'E0037')
    'R_DOPASULT'.('E0065', 'E0066', 'E0068')
    'R_DOPAtu'.('E0593', 'E0594', 'E0595', 'E0707')
    'R_DURIK1'.('E0716', 'E0717')
    'R_DUTPDPm'.('E0718', 'E0719')
    'R_ECOAH12m'.('E0100', 'E0721')
    'R_ECOAH1m'.('E0100', 'E0721', 'E0722')
    'R_ECOAH1x'.('E0723', 'E0724')
    'R_ECOAH9m'.('E0100', 'E0721')
    'R_EICOSTETCPT1'.('E0178', 'E0179', 'E0180', 'E0182')
    'R_ELAIDCPT1'.('E0178', 'E0179', 'E0180', 'E0182')
    'R_ESTRONESt'.('E0527', 'E0530', 'E0581', 'E0690', 'E0726', 'E0727',
                'E0729')
    'R_ESTSULT'.('E0008', 'E0066', 'E0691')
    'R_ETHAK'.('E0589', 'E0732')
    'R_FACOAL150'.('E0736', 'E0737', 'E0738', 'E0739')
    'R_FACOAL160i'.('E0736', 'E0737', 'E0738', 'E0739', 'E0740', 'E0741')
    'R_FACOAL170'.('E0736', 'E0737', 'E0738', 'E0739')
    'R_FACOAL180i'.('E0736', 'E0738', 'E0739', 'E0740')
    'R_FACOAL181i'.('E0736', 'E0737', 'E0738', 'E0739', 'E0741')
    'R_FACOAL1821'.('E0736', 'E0737', 'E0738', 'E0741')
    'R_FACOAL1831'.('E0736', 'E0737', 'E0738', 'E0740', 'E0741', 'E0742')
    'R_FACOAL204'.('E0736', 'E0737', 'E0738', 'E0739', 'E0741', 'E0743')
    'R_FACOAL80i'.('E0736', 'E0739')
    'R_FAOXC140'.('E0123', 'E0125')
    'R_FAOXC160'.('E0123', 'E0125')
    'R_FAOXC226'.('E0123', 'E0125')
    'R_FAOXC226205m'.('E0123', 'E0125')
    'R_FAOXC80'.('E0123', 'E0125')
    'R_FATP1t'.('E0757', 'E0758', 'E0759', 'E0760')
    'R_FATP2t'.('E0757', 'E0759')
    'R_FATP3t'.('E0757', 'E0759')
    'R_FATP6t'.('E0282', 'E0725')
    'R_FATP7t'.('E0282', 'E0725')
    'R_FATP8t'.('E0282', 'E0725')
    'R_FATP9t'.('E0282', 'E0725')
    'R_FBA4'.('E0761', 'E0762', 'E0764')
    'R_FBP26'.('E0766', 'E0767')
    'R_FRUt1r'.('E0780', 'E0781', 'E0782', 'E0783')
    'R_FTHFLm'.('E0786', 'E0787')
    'R_G14T18g'.('E0795', 'E0796', 'E0799')
    'R_G14T19g'.('E0795', 'E0796', 'E0799')
    'R_G14T20g'.('E0795', 'E0796', 'E0799')
    'R_G14T21g'.('E0795', 'E0796', 'E0799')
    'R_G14T2g'.('E0795', 'E0796', 'E0799')
    'R_G14T3g'.('E0795', 'E0796', 'E0799')
    'R_G14T4g'.('E0795', 'E0796', 'E0799')
    'R_G14T5g'.('E0795', 'E0796', 'E0799')
    'R_GALASE10ly'.('E0808', 'E0809')
    'R_GALASE11ly'.('E0808', 'E0809')
    'R_GALASE12ly'.('E0808', 'E0809')
    'R_GALASE13ly'.('E0808', 'E0809')
    'R_GALASE14ly'.('E0808', 'E0809')
    'R_GALASE15ly'.('E0808', 'E0809')
    'R_GALASE16ly'.('E0808', 'E0809')
    'R_GALASE17ly'.('E0808', 'E0809')
    'R_GALASE18ly'.('E0808', 'E0809')
    'R_GALASE19ly'.('E0808', 'E0809')
    'R_GALASE20ly'.('E0808', 'E0809')
    'R_GALASE3ly'.('E0808', 'E0809')
    'R_GALASE4ly'.('E0808', 'E0809')
    'R_GALASE5ly'.('E0808', 'E0809')
    'R_GALASE6ly'.('E0808', 'E0809')
    'R_GALASE7ly'.('E0808', 'E0809')
    'R_GALASE8ly'.('E0808', 'E0809')
    'R_GALASE9ly'.('E0808', 'E0809')
    'R_GALNACT2g'.('E0812', 'E0814')
    'R_GALNACT3g'.('E0812', 'E0814')
    'R_GALNACT4g'.('E0812', 'E0814')
    'R_GALNACT5g'.('E0812', 'E0814')
    'R_GALNTg'.('E0816', 'E0828')
    'R_GALOR'.('E0246', 'E0247', 'E0262')
    'R_GALt1r'.('E0681', 'E0682', 'E0780', 'E0781', 'E0832')
    'R_GAMt1r'.('E0682', 'E0683', 'E0781')
    'R_GARFT'.('E0836', 'E0837')
    'R_GCALDDm'.('E0063', 'E0255', 'E0256', 'E0801', 'E0845', 'E0846')
    'R_GCHOLAt2'.('E0582', 'E0583')
    'R_GHMT2rm'.('E0859', 'E0860')
    'R_GHMT3'.('E0860', 'E0861')
    'R_GLACO'.('E0039', 'E0040', 'E0041', 'E0248', 'E0249', 'E0251',
                'E0252', 'E0253')
    'R_GLCAASE8ly'.('E0864', 'E0865')
    'R_GLCAT2g'.('E0814', 'E0867')
    'R_GLCAT3g'.('E0814', 'E0867')
    'R_GLCAT4g'.('E0814', 'E0867')
    'R_GLCAT5g'.('E0814', 'E0867')
    'R_GLCNACT1g'.('E0878', 'E0879')
    'R_GLCNACT2g'.('E0868', 'E0878', 'E0880')
    'R_GLCNACT3g'.('E0868', 'E0878', 'E0880')
    'R_GLCNACT4g'.('E0868', 'E0878', 'E0880')
    'R_GLCNACT5g'.('E0868', 'E0878', 'E0880')
    'R_GLCt1r'.('E0681', 'E0682', 'E0683', 'E0780', 'E0781', 'E0782',
                'E0832', 'E0881')
    'R_GluForTx'.('E0899', 'E0900')
    'R_GLUNm'.('E0901', 'E0903')
    'R_GLUTCOADHm'.('E0906', 'E0907')
    'R_GLXO2p'.('E0911', 'E0912')
    'R_GLYCTO1p'.('E0911', 'E0912')
    'R_GLYt7_211_r'.('E0921', 'E0922')
    'R_GSNt'.('E0148', 'E0170')
    'R_GTHP'.('E0930', 'E0932', 'E0935', 'E0938')
    'R_GTHPe'.('E0932', 'E0935', 'E0940')
    'R_GTHPm'.('E0935', 'E0938', 'E0943')
    'R_GTMLTe'.('E0946', 'E0947', 'E0948')
    'R_H2ETer'.('E0963', 'E0964')
    'R_H3ETer'.('E0963', 'E0964')
    'R_H4ETer'.('E0963', 'E0964')
    'R_H6_ETer'.('E0963', 'E0964')
    'R_H7_ETer'.('E0963', 'E0964')
    'R_HACD1m'.('E0100', 'E0974')
    'R_HACD1x'.('E0541', 'E0724')
    'R_HCO3_CLt'.('E0981', 'E0983')
    'R_HISDC'.('E0052', 'E0999')
    'R_HISTASE'.('E0003', 'E0004')
    'R_HISTAtu'.('E0593', 'E0594', 'E0595', 'E0707')
    'R_HMGCOASi'.('E1002', 'E1003')
    'R_HMGLm'.('E1005', 'E1006')
    'R_HOMt4'.('E0229', 'E0231')
    'R_HPDCACRNCPT1'.('E0178', 'E0179', 'E0182')
    'R_HPYRR2x'.('E0010', 'E0014', 'E0017', 'E1010', 'E1011')
    'R_IDHPOXOX2b'.('E1027', 'E1028')
    'R_IDHPOXOX3'.('E1027', 'E1028')
    'R_IDHPOXOX4'.('E1027', 'E1028')
    'R_IDHPOXOXb'.('E1027', 'E1028')
    'R_INSt'.('E0148', 'E0170')
    'R_KCCt'.('E1043', 'E1046')
    'R_KHK'.('E1047', 'E1048')
    'R_KHK2'.('E1047', 'E1048')
    'R_KHK3'.('E1047', 'E1048')
    'R_KYNAKGAT'.('E0049', 'E0050', 'E0051')
    'R_LACZe'.('E1052', 'E1053')
    'R_LAPCOAl'.('E0120', 'E0140', 'E1054')
    'R_LCADi_D'.('E0039', 'E0040', 'E0041', 'E0248', 'E0249', 'E0250',
                'E0251', 'E0252', 'E0253')
    'R_LCADim'.('E0063', 'E0255', 'E0256', 'E0801', 'E0845', 'E0846')
    'R_LCYSTCBOXL'.('E0057', 'E0058')
    'R_LDH_Lm'.('E0014', 'E1010')
    'R_LEUt4'.('E0229', 'E0230', 'E0231', 'E0232', 'E0233', 'E0236',
                'E0274')
    'R_LNELDCCPT1'.('E0178', 'E0179', 'E0180', 'E0182')
    'R_LNLCCPT1'.('E0178', 'E0179', 'E0180', 'E0182')
    'R_LNLNCACPT1'.('E0178', 'E0179', 'E0180', 'E0182')
    'R_LNLNCGCPT1'.('E0178', 'E0179', 'E0180', 'E0182')
    'R_LPS'.('E1065', 'E1066', 'E1067')
    'R_LYStiDF'.('E0229', 'E0231', 'E0233')
    'R_LYStm'.('E0288', 'E0289')
    'R_MACOXO'.('E0039', 'E0040', 'E0041', 'E0054')
    'R_MAOLNOR'.('E0053', 'E0054')
    'R_MAOX'.('E0001', 'E0002', 'E0003', 'E0004')
    'R_ME2m'.('E1088', 'E1090')
    'R_MELATNOX'.('E1092', 'E1093', 'E1094')
    'R_MHISOR'.('E0001', 'E0003')
    'R_MI1345PP'.('E1101', 'E1102', 'E1103')
    'R_MI145PP'.('E1101', 'E1102', 'E1103')
    'R_MTHFCm'.('E0786', 'E1124')
    'R_MTHFDm'.('E0786', 'E0787', 'E1124')
    'R_NACHEX1ly'.('E0210', 'E0211', 'E0212')
    'R_NACHEX21ly'.('E0210', 'E0211', 'E0212')
    'R_NACHEX22ly'.('E0210', 'E0211', 'E0212')
    'R_NACHEX25ly'.('E0210', 'E0211', 'E0212')
    'R_NACHEX27ly'.('E0210', 'E0211', 'E0212')
    'R_NACHEX2ly'.('E0210', 'E0211', 'E0212')
    'R_NACHEX3ly'.('E0210', 'E0212')
    'R_NACHEX8ly'.('E0210', 'E0211', 'E0212')
    'R_NACHEX9ly'.('E0210', 'E0211', 'E0212')
    'R_NACHEXA10ly'.('E0210', 'E0212')
    'R_NACHEXA11ly'.('E0210', 'E0212')
    'R_NACHEXA12ly'.('E0210', 'E0212')
    'R_NACHEXA13ly'.('E0210', 'E0212')
    'R_NACHEXA14ly'.('E0210', 'E0212')
    'R_NACHEXA15ly'.('E0210', 'E0212')
    'R_NACHEXA16ly'.('E0210', 'E0212')
    'R_NACHEXA17ly'.('E0210', 'E0212')
    'R_NACHEXA18ly'.('E0210', 'E0212')
    'R_NACHEXA19ly'.('E0210', 'E0212')
    'R_NACHEXA1ly'.('E0210', 'E0212')
    'R_NACHEXA20ly'.('E0210', 'E0212')
    'R_NACHEXA21ly'.('E0210', 'E0212')
    'R_NACHEXA22ly'.('E0210', 'E0212')
    'R_NACHEXA2ly'.('E0210', 'E0212')
    'R_NACHEXA3ly'.('E0210', 'E0212')
    'R_NACHEXA4ly'.('E0210', 'E0212')
    'R_NACHEXA5ly'.('E0210', 'E0212')
    'R_NACHEXA6ly'.('E0210', 'E0212')
    'R_NACHEXA7ly'.('E0210', 'E0212')
    'R_NACHEXA8ly'.('E0210', 'E0212')
    'R_NACHEXA9ly'.('E0210', 'E0212')
    'R_NAt'.('E0886', 'E1037', 'E1131')
    'R_NDP10ex'.('E0497', 'E0501', 'E1155')
    'R_NDP3ex'.('E0497', 'E0501', 'E1155')
    'R_NDP7er'.('E0500', 'E1155', 'E1157')
    'R_NDP7ex'.('E0497', 'E0501', 'E1155')
    'R_NDP8ex'.('E0497', 'E0501', 'E1155')
    'R_NDPK1m'.('E1161', 'E1164')
    'R_NDPK3m'.('E1161', 'E1164')
    'R_NDPK5m'.('E1161', 'E1164')
    'R_NDPK6m'.('E1161', 'E1164')
    'R_NDPK8m'.('E1161', 'E1164')
    'R_NH4t3r'.('E1165', 'E1166')
    'R_NMNATr'.('E1169', 'E1171')
    'R_NOS1'.('E1176', 'E1177')
    'R_NOS2'.('E1176', 'E1177')
    'R_NRPPHRSULT'.('E0008', 'E0068')
    'R_NRPPHRtu'.('E0593', 'E0595', 'E0707', 'E1183')
    'R_NTD12'.('E1185', 'E1186')
    'R_NTD2l'.('E0120', 'E0140', 'E1054')
    'R_NTP3e'.('E0497', 'E0501', 'E1155')
    'R_NTPP10'.('E0719', 'E1189')
    'R_NTPP9'.('E0719', 'E1189')
    'R_ORNt3m'.('E0288', 'E0289')
    'R_ORNt4m'.('E0288', 'E0289')
    'R_ORNtiDF'.('E0229', 'E0231')
    'R_OXAHCOtex'.('E1198', 'E1199')
    'R_P4501B1r'.('E1094', 'E1209')
    'R_P4502A6'.('E1212', 'E1213')
    'R_P4502C8'.('E1215', 'E1216')
    'R_P4504F122r'.('E1227', 'E1228')
    'R_P5CRm'.('E1232', 'E1233')
    'R_P5CRxm'.('E1232', 'E1233')
    'R_PCHOLP_hs'.('E1240', 'E1241')
    'R_PCt'.('E0598', 'E1245', 'E1246')
    'R_PDE1'.('E1248', 'E1249', 'E1260')
    'R_PDE4'.('E1248', 'E1260', 'E1271')
    'R_PEAMNO'.('E0002', 'E0003', 'E0053', 'E0054')
    'R_PETOHMr_hs'.('E1303', 'E1304')
    'R_PGESr'.('E1309', 'E1311')
    'R_PHEt4'.('E0228', 'E0229', 'E0230', 'E0231', 'E0232', 'E0233',
                'E1320')
    'R_PI345P5P'.('E1101', 'E1102', 'E1103', 'E1325')
    'R_PI3P4K'.('E1326', 'E1329')
    'R_PI45P5P'.('E1102', 'E1325', 'E1343')
    'R_PI4P3K'.('E1332', 'E1363')
    'R_PI4P5K'.('E1326', 'E1366')
    'R_PI5P3K'.('E1332', 'E1363', 'E1373')
    'R_PIK3'.('E1332', 'E1363', 'E1373')
    'R_PLA2_2'.('E1061', 'E1376')
    'R_PLA2_2e'.('E1376', 'E1383')
    'R_PMI12346PH'.('E1388', 'E1389')
    'R_PMI12346PHn'.('E1388', 'E1389', 'E1391', 'E1395')
    'R_PPAP'.('E1402', 'E1403', 'E1405')
    'R_PPDOy'.('E0246', 'E0247', 'E0261', 'E0262')
    'R_PRAGSr'.('E0836', 'E0837')
    'R_PROSTGE2t'.('E0581', 'E0726', 'E0729', 'E1412')
    'R_PROSTGE2t2'.('E0593', 'E0595', 'E1183')
    'R_PROSTGF2t'.('E0593', 'E0595', 'E1183')
    'R_PTDCACRNCPT1'.('E0178', 'E0179', 'E0180', 'E0182')
    'R_PTE2x'.('E1416', 'E1417', 'E1418', 'E1420')
    'R_PTRCOX1'.('E0001', 'E0003')
    'R_PYNP2r'.('E1425', 'E1426')
    'R_PYRt2p'.('E0019', 'E0020')
    'R_RDH1'.('E1431', 'E1432')
    'R_RDH1a'.('E1433', 'E1434', 'E1435', 'E1437', 'E1439')
    'R_RDH2a'.('E1434', 'E1435', 'E1437', 'E1439')
    'R_S23T2g'.('E1443', 'E1445', 'E1446')
    'R_S23T4g'.('E1443', 'E1445', 'E1446')
    'R_S3T1g'.('E1451', 'E1452', 'E1453')
    'R_S3T2g'.('E1452', 'E1453', 'E1454')
    'R_S3T3g'.('E1452', 'E1455')
    'R_S6T18g'.('E1469', 'E1470')
    'R_S6T19g'.('E1470', 'E1471')
    'R_S6T20g'.('E1470', 'E1471')
    'R_S6T21g'.('E1470', 'E1471')
    'R_S6T24g'.('E1470', 'E1471')
    'R_S6T3g'.('E1469', 'E1470')
    'R_SALMCOM'.('E0036', 'E0037', 'E1478')
    'R_SBTR'.('E0246', 'E0247', 'E0261', 'E0262')
    'R_SERALANaEx'.('E0221', 'E0222')
    'R_SERCYSNaEx'.('E0221', 'E0222')
    'R_SERTHRNaEx'.('E0221', 'E0222')
    'R_SLCBK1'.('E1489', 'E1490')
    'R_SMPD3g'.('E1492', 'E1493', 'E1494')
    'R_SMPD3l'.('E1492', 'E1493', 'E1496')
    'R_SO4CLtex2'.('E0611', 'E0612')
    'R_SO4HCOtex'.('E1198', 'E1199', 'E1499', 'E1500')
    'R_SO4OXAtex2'.('E0611', 'E0612')
    'R_SPHK21c'.('E1489', 'E1490')
    'R_SPRMS'.('E1512', 'E1513')
    'R_SRTNtu'.('E0593', 'E0595', 'E1183')
    'R_STRDNCCPT1'.('E0178', 'E0179', 'E0180', 'E0182')
    'R_SUCRe'.('E0835', 'E1190')
    'R_TCHOLAt'.('E0527', 'E0530', 'E0581', 'E0726')
    'R_TCHOLAt2'.('E0582', 'E0583')
    'R_THRALANaEx'.('E0221', 'E0222')
    'R_THRCYSNaEx'.('E0221', 'E0222')
    'R_THRSERNaEx'.('E0221', 'E0222')
    'R_THYMDt1'.('E0148', 'E0170')
    'R_THYOXt'.('E0527', 'E0581', 'E0726', 'E0727')
    'R_THYPX'.('E1027', 'E1028')
    'R_TMNDNCCPT1'.('E0178', 'E0179', 'E0180', 'E0182')
    'R_TRDR'.('E1550', 'E1551')
    'R_TRDR2'.('E1550', 'E1551')
    'R_TRDR3'.('E1550', 'E1551')
    'R_TRIODTHYSULT'.('E0008', 'E0066')
    'R_TRIODTHYt'.('E0527', 'E0530', 'E0581', 'E0726', 'E0727')
    'R_TRYPTAOX'.('E0002', 'E0003', 'E0004', 'E0053', 'E0054')
    'R_TSTSTERONESULT'.('E0008', 'E0075')
    'R_UGT1A2r'.('E1577', 'E1578', 'E1579', 'E1580', 'E1581', 'E1582',
                'E1583', 'E1585')
    'R_UGT1A5r2'.('E1577', 'E1578', 'E1579', 'E1580', 'E1581', 'E1582',
                'E1583', 'E1585', 'E1587', 'E1588', 'E1590')
    'R_URIK1'.('E0643', 'E1593')
    'R_URIt'.('E0148', 'E0170')
    'R_URIt4'.('E0171', 'E0172', 'E0173', 'E0174')
    'R_VLCS2r'.('E0282', 'E0725')
    'R_r0027'.('E1551', 'E1608')
    'R_r0028'.('E0497', 'E0501')
    'R_r0047'.('E1185', 'E1187', 'E1188', 'E1610', 'E1611', 'E1614')
    'R_r0083'.('E1025', 'E1026', 'E1616')
    'R_r0084'.('E1025', 'E1026')
    'R_r0129'.('E0858', 'E0947', 'E1619')
    'R_r0130'.('E0858', 'E0947', 'E1619')
    'R_r0139'.('E0497', 'E0501')
    'R_r0149'.('E0497', 'E0501')
    'R_r0173'.('E0014', 'E0017')
    'R_r0181'.('E0497', 'E0501')
    'R_r0221'.('E0105', 'E0142')
    'R_r0245'.('E0246', 'E0262')
    'R_r0246'.('E0246', 'E0262')
    'R_r0308'.('E1416', 'E1420', 'E1640', 'E1641', 'E1642')
    'R_r0310'.('E0123', 'E0131', 'E1646', 'E1647', 'E1648')
    'R_r0311'.('E0725', 'E0736', 'E0737', 'E0738', 'E0740', 'E0741',
                'E0742')
    'R_r0317'.('E0134', 'E0135')
    'R_r0319'.('E0105', 'E0142')
    'R_r0391'.('E1653', 'E1654')
    'R_r0393'.('E0250', 'E0252', 'E0253', 'E0255', 'E0256')
    'R_r0407'.('E0762', 'E0764')
    'R_r0423'.('E1025', 'E1026')
    'R_r0424'.('E1025', 'E1026')
    'R_r0425'.('E1025', 'E1026', 'E1616')
    'R_r0426'.('E0134', 'E0135')
    'R_r0494'.('E0497', 'E0501')
    'R_r0497'.('E0497', 'E0501')
    'R_r0545'.('E0039', 'E0040', 'E0041')
    'R_r0546'.('E0039', 'E0040', 'E0041')
    'R_r0547'.('E0039', 'E0040', 'E0041')
    'R_r0548'.('E0039', 'E0040', 'E0041')
    'R_r0615'.('E1232', 'E1676')
    'R_r0616'.('E1232', 'E1676')
    'R_r0617'.('E1232', 'E1676')
    'R_r0618'.('E1232', 'E1676')
    'R_r0641'.('E0858', 'E0947', 'E1619')
    'R_r0642'.('E0250', 'E0252', 'E0253', 'E0255', 'E0256')
    'R_r0643'.('E0250', 'E0252', 'E0253', 'E0255', 'E0256')
    'R_r0648'.('E0858', 'E0947', 'E1619')
    'R_r0649'.('E0858', 'E0947', 'E1619')
    'R_r0650'.('E0282', 'E0725')
    'R_r0655'.('E0123', 'E0129')
    'R_r0688'.('E0250', 'E0252', 'E0253', 'E0255', 'E0256')
    'R_r0739'.('E0028', 'E0033', 'E1679')
    'R_r0752'.('E0039', 'E0040', 'E0041')
    'R_r0753'.('E0039', 'E0040', 'E0041')
    'R_r0754'.('E0039', 'E0040', 'E0041')
    'R_r0755'.('E0039', 'E0040', 'E0041')
    'R_r0756'.('E0039', 'E0040', 'E0041')
    'R_r0757'.('E0039', 'E0040', 'E0041')
    'R_r0758'.('E0250', 'E0252', 'E0253', 'E0255', 'E0256')
    'R_r0787'.('E1402', 'E1403', 'E1481')
    'R_r0879'.('E0009', 'E0699')
    'R_r1043'.('E0172', 'E0173')
    'R_r1044'.('E0172', 'E0173')
    'R_r1045'.('E0173', 'E0174')
    'R_r1090'.('E0604', 'E1687')
    'R_r1155'.('E0019', 'E0020')
    'R_r1156'.('E0643', 'E1593')
    'R_r1164'.('E1507', 'E1689')
    'R_r1165'.('E1507', 'E1689')
    'R_r1166'.('E1507', 'E1689')
    'R_r1167'.('E1507', 'E1689')
    'R_r1171'.('E1507', 'E1689')
    'R_r1174'.('E1067', 'E1690')
    'R_r1175'.('E1067', 'E1690')
    'R_r1177'.('E1067', 'E1690')
    'R_r1183'.('E1067', 'E1690')
    'R_r1251'.('E0725', 'E0736', 'E0737', 'E0738', 'E0740', 'E0741',
                'E0742')
    'R_r1252'.('E0725', 'E0736', 'E0737', 'E0738', 'E0740', 'E0741',
                'E0742')
    'R_r1253'.('E0725', 'E0736', 'E0737', 'E0738', 'E0740', 'E0741',
                'E0742')
    'R_r1254'.('E0725', 'E0736', 'E0737', 'E0738', 'E0740', 'E0741',
                'E0742')
    'R_r1255'.('E0725', 'E0736', 'E0737', 'E0738', 'E0740', 'E0741',
                'E0742')
    'R_r1257'.('E0725', 'E0736', 'E0737', 'E0738', 'E0740', 'E0741',
                'E0742')
    'R_r1259'.('E0725', 'E0736', 'E0737', 'E0738', 'E0740', 'E0741',
                'E0742')
    'R_r1260'.('E0725', 'E0736', 'E0737', 'E0738', 'E0740', 'E0741',
                'E0742')
    'R_r1262'.('E0725', 'E0736', 'E0737', 'E0738', 'E0740', 'E0741',
                'E0742')
    'R_r1418'.('E1691', 'E1699')
    'R_r1443'.('E0131', 'E1647')
    'R_r1444'.('E0131', 'E1647')
    'R_r1445'.('E0131', 'E1647')
    'R_r1446'.('E0131', 'E1647')
    'R_r1447'.('E0131', 'E1647')
    'R_r1448'.('E0131', 'E1647')
    'R_r1449'.('E0131', 'E1647')
    'R_r1450'.('E0131', 'E1647')
    'R_r1451'.('E0131', 'E1647')
    'R_r1454'.('E0019', 'E0020')
    'R_r1487'.('E0725', 'E0736', 'E0737', 'E0738', 'E0740', 'E0741',
                'E0742')
    'R_RE0344C'.('E0517', 'E1642', 'E1712')
    'R_RE0512M'.('E0098', 'E0541', 'E0724', 'E0974', 'E1716')
    'R_RE0512X'.('E0541', 'E0724')
    'R_RE0577C'.('E0517', 'E1642', 'E1712')
    'R_RE0578C'.('E0517', 'E1642', 'E1712')
    'R_RE0579C'.('E0517', 'E1642', 'E1712')
    'R_RE0912C'.('E0008', 'E1720')
    'R_RE0915E'.('E0275', 'E1721')
    'R_RE0926E'.('E0275', 'E1721')
    'R_RE0935E'.('E0275', 'E1721')
    'R_RE0944E'.('E0275', 'E1721')
    'R_RE0958E'.('E0275', 'E1721')
    'R_RE1516M'.('E0131', 'E1648')
    'R_RE1516X'.('E0131', 'E1647')
    'R_RE1517M'.('E0131', 'E1648')
    'R_RE1517X'.('E0131', 'E1647')
    'R_RE1518M'.('E0131', 'E1648')
    'R_RE1518X'.('E0131', 'E1647')
    'R_RE1519X'.('E0131', 'E1647')
    'R_RE1520M'.('E0098', 'E0721', 'E0724', 'E1716')
    'R_RE1521M'.('E0098', 'E0721', 'E0724', 'E1716')
    'R_RE1522M'.('E0098', 'E0721', 'E0724', 'E1716')
    'R_RE1523M'.('E0098', 'E0721', 'E0724', 'E1716')
    'R_RE1525M'.('E0541', 'E0724', 'E0974')
    'R_RE1525X'.('E0541', 'E0724')
    'R_RE1526M'.('E0541', 'E0724', 'E0974')
    'R_RE1526X'.('E0541', 'E0724')
    'R_RE1527M'.('E0541', 'E0724', 'E0974')
    'R_RE1527X'.('E0541', 'E0724')
    'R_RE1531M'.('E0098', 'E0099', 'E1716')
    'R_RE1532M'.('E0098', 'E0099', 'E1716')
    'R_RE1533M'.('E0098', 'E0099', 'E1716')
    'R_RE1534M'.('E0098', 'E0099', 'E1716')
    'R_RE1573M'.('E0667', 'E0668', 'E0724')
    'R_RE1573X'.('E0668', 'E0724')
    'R_RE1834C'.('E0517', 'E1417', 'E1642', 'E1712')
    'R_RE1834M'.('E1416', 'E1640')
    'R_RE1834X'.('E0517', 'E1417', 'E1420')
    'R_RE1835C'.('E0517', 'E1642', 'E1712')
    'R_RE2235R'.('E0146', 'E1059', 'E1093', 'E1094', 'E1207', 'E1209',
                'E1212', 'E1213', 'E1215', 'E1217', 'E1218', 'E1224',
                'E1225', 'E1227', 'E1734')
    'R_RE2445E'.('E1320', 'E1743')
    'R_RE2649C'.('E0517', 'E1642', 'E1712')
    'R_RE2649M'.('E1416', 'E1640')
    'R_RE2888C'.('E1028', 'E1408')
    'R_RE2912M'.('E0736', 'E0737', 'E0738', 'E0740', 'E0742')
    'R_RE2985X'.('E0131', 'E0136', 'E1647')
    'R_RE2987X'.('E0541', 'E0724')
    'R_RE2991X'.('E0541', 'E0724')
    'R_RE2992M'.('E0667', 'E0668', 'E0724')
    'R_RE2992X'.('E0668', 'E0724')
    'R_RE2994X'.('E0131', 'E0136', 'E1647')
    'R_RE2997X'.('E0131', 'E0136', 'E1647')
    'R_RE2999M'.('E0667', 'E0668', 'E0724')
    'R_RE3002X'.('E0668', 'E0724')
    'R_RE3003M'.('E0667', 'E0668', 'E0724')
    'R_RE3004M'.('E0098', 'E0721', 'E0724', 'E1716')
    'R_RE3005M'.('E0541', 'E0724', 'E0974')
    'R_RE3006M'.('E0098', 'E0099', 'E1716')
    'R_RE3012M'.('E0250', 'E0255', 'E0256')
    'R_RE3012R'.('E0039', 'E0253')
    'R_RE3014R'.('E1228', 'E1752')
    'R_RE3015R'.('E1228', 'E1752')
    'R_RE3074X'.('E0725', 'E0736', 'E0737', 'E0738', 'E0740', 'E0742')
    'R_RE3082X'.('E0541', 'E0724')
    'R_RE3086X'.('E0131', 'E0136', 'E1647')
    'R_RE3095C'.('E1028', 'E1408')
    'R_RE3114R'.('E0725', 'E0736', 'E0737', 'E0738', 'E0740', 'E0742')
    'R_RE3132R'.('E0725', 'E0736', 'E0737', 'E0738', 'E0740', 'E0742')
    'R_RE3146R'.('E0725', 'E0736', 'E0737', 'E0738', 'E0740', 'E0742')
    'R_RE3156X'.('E0541', 'E0724')
    'R_RE3157X'.('E0131', 'E0136', 'E1647')
    'R_RE3160R'.('E0725', 'E0736', 'E0737', 'E0738', 'E0740', 'E0742')
    'R_RE3177M'.('E0098', 'E0541', 'E0724', 'E0974', 'E1716')
    'R_RE3178M'.('E0098', 'E0541', 'E0724', 'E0974', 'E1716')
    'R_RE3179M'.('E0098', 'E0541', 'E0724', 'E0974', 'E1716')
    'R_RE3185M'.('E0122', 'E0123', 'E1648')
    'R_RE3186M'.('E0122', 'E0123', 'E1648')
    'R_RE3189M'.('E0098', 'E0099', 'E1716')
    'R_RE3190M'.('E0098', 'E0099', 'E1716')
    'R_RE3191M'.('E0098', 'E0099', 'E1716')
    'R_RE3192M'.('E0098', 'E0721', 'E0724', 'E1716')
    'R_RE3193M'.('E0098', 'E0721', 'E0724', 'E1716')
    'R_RE3194M'.('E0098', 'E0721', 'E0724', 'E1716')
    'R_RE3269C'.('E1754', 'E1757')
    'R_RE3628M'.('E0667', 'E0668', 'E0724')
    'R_C100CPT1'.('E0178', 'E0182')
    'R_C101CPT1'.('E0178', 'E0182')
    'R_C102CPT1'.('E0178', 'E0182')
    'R_C10DCc'.('E0178', 'E0182')
    'R_C10OHc'.('E0178', 'E0182')
    'R_C120CPT1'.('E0178', 'E0182')
    'R_C121CPT1'.('E0178', 'E0182')
    'R_C12OHc'.('E0178', 'E0182')
    'R_C140CPT1'.('E0178', 'E0182')
    'R_C141CPT1'.('E0178', 'E0182')
    'R_C142CPT1'.('E0178', 'E0182')
    'R_C14OHc'.('E0178', 'E0182')
    'R_C16DCc'.('E0178', 'E0182')
    'R_C181OHc'.('E0178', 'E0182')
    'R_C182OHc'.('E0178', 'E0182')
    'R_C30CPT1'.('E0178', 'E0182')
    'R_C40CPT1'.('E0178', 'E0182')
    'R_C4OHc'.('E0178', 'E0182')
    'R_C51CPT1'.('E0178', 'E0182')
    'R_C60CPT1'.('E0178', 'E0182')
    'R_C6DCc'.('E0178', 'E0182')
    'R_C80CPT1'.('E0178', 'E0182')
    'R_C81CPT1'.('E0178', 'E0182')
    'R_C8DCc'.('E0178', 'E0182')
    'R_DOCO13EFATP'.('E0282', 'E0725', 'E0758', 'E0759', 'E0760', 'E1769')
    'R_FAOXC101C102m'.('E0123', 'E0131')
    'R_FAOXC101x'.('E0668', 'E0724')
    'R_FAOXC102x'.('E0668', 'E0724')
    'R_FAOXC121x'.('E0668', 'E0724')
    'R_FAOXC122x'.('E0668', 'E0724')
    'R_FAOXC123x'.('E0668', 'E0724')
    'R_FAOXC12DCc'.('E0178', 'E0182')
    'R_FAOXC163x'.('E0668', 'E0724')
    'R_FAOXC164x'.('E0668', 'E0724')
    'R_FAOXC184x'.('E0668', 'E0724')
    'R_FAOXC225x'.('E0668', 'E0724')
    'R_FAOXC3DC'.('E0178', 'E0182')
    'R_FAOXC4C4DCc'.('E0178', 'E0182')
    'R_FAOXC61x'.('E0668', 'E0724')
    'R_OCT11EFATP'.('E0282', 'E0725', 'E0758', 'E0759', 'E0760', 'E1769')
    'R_OCTDECCPT1'.('E0178', 'E0182')
    'R_ASCBSVCTtc'.('E0294', 'E0295')
    'R_CHOLESACATc'.('E1507', 'E1689')
    'R_FMNALKPle'.('E0137', 'E0138', 'E1805')
    'R_P5CR'.('E1232', 'E1676', 'E1807')
    'R_PHEMEe'.('E1796', 'E1809')
    'R_ARACHDFATPtc'.('E0758', 'E0759')
    'R_FOLABCCte'.('E0074', 'E0528', 'E0728', 'E1245', 'E1703', 'E1819',
                'E1822')
    'R_FOLOAT2tc'.('E1812', 'E1815', 'E1823')
    'R_H2OGLYAQPt'.('E1058', 'E1824')
    'R_LGNCFATPtc'.('E0725', 'E0759')
    'R_CAMPt'.('E0728', 'E1703', 'E1819', 'E1829')
    'R_CGMPt'.('E0728', 'E1703', 'E1819', 'E1829')
    'R_GALt4'.('E1830', 'E1832')
    'R_GCHOLAt3'.('E0529', 'E0584', 'E0585', 'E1819')
    'R_GLCt4'.('E1037', 'E1761', 'E1830', 'E1832')
    'R_TCHOLAt3'.('E0529', 'E0584', 'E0585', 'E1819')
    'R_TRPt'.('E0038', 'E1817')
    'R_CHSTEROLt'.('E0598', 'E1685')
    'R_r0963'.('E0083', 'E1843')
    'R_SMS1'.('E1498', 'E1845')
    'R_SMS10'.('E1498', 'E1845')
    'R_SMS11'.('E1498', 'E1845')
    'R_SMS12'.('E1498', 'E1845')
    'R_SMS16'.('E1498', 'E1845')
    'R_SMS13'.('E1498', 'E1845')
    'R_SMS14'.('E1498', 'E1845')
    'R_SMS15'.('E1498', 'E1845')
    'R_SMS2'.('E1498', 'E1845')
    'R_SMS3'.('E1498', 'E1845')
    'R_SMS4'.('E1498', 'E1845')
    'R_SMS5'.('E1498', 'E1845')
    'R_SMS6'.('E1498', 'E1845')
    'R_SMS7'.('E1498', 'E1845')
    'R_SMS8'.('E1498', 'E1845')
    'R_SMS9'.('E1498', 'E1845')
    'R_PCHOLMYR_HSPLA2'.('E1061', 'E1376')
    'R_PCHOLOLE_HSPLA2'.('E1061', 'E1376')
    'R_PEOLE_HSPLA2'.('E1061', 'E1376')
    'R_PCHOLPALME_HSPLA2'.('E1061', 'E1376')
    'R_PCHOLPALM_HSPLA2'.('E1061', 'E1376')
    'R_PEPALM_HSPLA2'.('E1061', 'E1376')
    'R_PAILPALM_HSPLA2'.('E1061', 'E1376')
    'R_PCHOLSTE_HSPLA2'.('E1061', 'E1376')
    'R_PCHOL2LINL_HSPLA2'.('E1061', 'E1376')
    'R_PE2LINL_HSPLA2'.('E1061', 'E1376')
    'R_PCHOL2OLE_HSPLA2'.('E1061', 'E1376')
    'R_PCHOL2PALM_HSPLA2'.('E1061', 'E1376')
    'R_PCHOL2STE_HSPLA2'.('E1061', 'E1376')
    'R_PCHOLN15_HSPLA2'.('E1061', 'E1376')
    'R_PCHOLAR_HSPLA2'.('E1061', 'E1376')
    'R_PCHOLN183_HSPLA2'.('E1061', 'E1376')
    'R_PCHOLN1836_HSPLA2'.('E1061', 'E1376')
    'R_PCHOLN19_HSPLA2'.('E1061', 'E1376')
    'R_PCHOLN201_HSPLA2'.('E1061', 'E1376')
    'R_PCHOLN204_HSPLA2'.('E1061', 'E1376')
    'R_PCHOLN205_HSPLA2'.('E1061', 'E1376')
    'R_PCHOLN224_HSPLA2'.('E1061', 'E1376')
    'R_PCHOLN225_HSPLA2'.('E1061', 'E1376')
    'R_PCHOLN2254_HSPLA2'.('E1061', 'E1376')
    'R_PCHOLN226_HSPLA2'.('E1061', 'E1376')
    'R_PEAR_HSPLA2'.('E1061', 'E1376')
    'R_PE203_HSPLA2'.('E1061', 'E1376')
    'R_PE226_HSPLA2'.('E1061', 'E1376')
    'R_PE224_HSPLA2'.('E1061', 'E1376')
    'R_PEDH203_HSPLA2'.('E1061', 'E1376')
    'R_PEDH12_HSPLA2'.('E1061', 'E1376')
    'R_PEDH14_HSPLA2'.('E1061', 'E1376')
    'R_PEDH161_HSPLA2'.('E1061', 'E1376')
    'R_PEDH13_HSPLA2'.('E1061', 'E1376')
    'R_PEDH15_HSPLA2'.('E1061', 'E1376')
    'R_PEDH17_HSPLA2'.('E1061', 'E1376')
    'R_PCHOLN203_HSPLA2'.('E1061', 'E1376')
    'R_PAILAR_HSPLA2'.('E1061', 'E1376')
    'R_PCHOLN24_HSPLA2'.('E1061', 'E1376')
    'R_PCHOLN261_HSPLA2'.('E1061', 'E1376')
    'R_PCHOLN281_HSPLA2'.('E1061', 'E1376')
    'R_PCHOLN28_HSPLA2'.('E1061', 'E1376')
    'R_PCHOLDOC_HSPLA2'.('E1061', 'E1376')
    'R_PCHOLDEIC_HSPLA2'.('E1061', 'E1376')
    'R_PCHOLDET_HSPLA2'.('E1061', 'E1376')
    'R_PCHOLHEP_HSPLA2'.('E1061', 'E1376')
    'R_PCHOLLINL_HSPLA2'.('E1061', 'E1376')
    'R_PELINL_HSPLA2'.('E1061', 'E1376')
    'R_ARACHETH'.('E1240', 'E1241')
    'R_C03990ATP'.('E0529', 'E0585', 'E1819')
    'R_C04483t1'.('E0529', 'E0585', 'E1819')
    'R_C05463t1'.('E0529', 'E0585', 'E1819')
    'R_CE1273t1'.('E0529', 'E0585', 'E1819')
    'R_DIDECAETH'.('E1240', 'E1241')
    'R_DIHOLINETH'.('E1240', 'E1241')
    'R_DOCOHEXETHc'.('E1240', 'E1241')
    'R_DOCTETETH'.('E1240', 'E1241')
    'R_HEPDECETH'.('E1240', 'E1241')
    'R_HEXDECEETH'.('E1240', 'E1241')
    'R_OLEETH'.('E1240', 'E1241')
    'R_PELINETH'.('E1240', 'E1241')
    'R_PENDECAETH'.('E1240', 'E1241')
    'R_PEPALM'.('E1240', 'E1241')
    'R_STEETH'.('E1240', 'E1241')
    'R_TETDECAETH'.('E1240', 'E1241')
    'R_TRIDECETH'.('E1240', 'E1241')
    'R_HC02195te'.('E0529', 'E0585', 'E1819')
    'R_HC02196te'.('E0529', 'E0585', 'E1819')
    'R_HC02194te'.('E0528', 'E0529', 'E0584', 'E0585', 'E0728')
    'R_HC02220te'.('E0528', 'E0529', 'E0584', 'E0728', 'E1822')
    'R_ARGtD'.('E0229', 'E0231')
    'R_DHCHOLESTANATEATP'.('E0529', 'E0585', 'E1819')
    'R_THCHOLSTOICATP'.('E0529', 'E0585', 'E1819')
    'R_XOL7AH3ATP'.('E0529', 'E0585', 'E1819')
    'R_XOL7AONEATP'.('E0529', 'E0585', 'E1819')
    'R_XOLDIOLONEATP'.('E0529', 'E0585', 'E1819')
    'R_7KILTCHOLATP'.('E0529', 'E0585', 'E1819')
    'R_ACACt2'.('E0019', 'E0020')
    'R_ACCOAL'.('E0142', 'E0144')
    'R_ACONT'.('E0135', 'E1847')
    'R_ACS'.('E0142', 'E0143', 'E0144')
    'R_ADK1'.('E0151', 'E0155', 'E0156', 'E1848')
    'R_ARGN'.('E0285', 'E1855')
    'R_DURIPP'.('E1182', 'E1426')
    'R_FBA'.('E0761', 'E0762', 'E0764')
    'R_FBA2'.('E0761', 'E0762', 'E0764')
    'R_GHMT2r'.('E0860', 'E0861')
    'R_H2CO3D'.('E1691', 'E1882')
    'R_L_LACt2r'.('E0018', 'E0019', 'E0020', 'E0696', 'E1895')
    'R_MAN1PT2'.('E1628', 'E1896')
    'R_MTHFC'.('E0787', 'E1899')
    'R_MTHFD'.('E0787', 'E1806')
    'R_NAt3_1'.('E1143', 'E1902')
    'R_NDPK1'.('E1159', 'E1160', 'E1161')
    'R_NDPK2'.('E1159', 'E1160', 'E1161')
    'R_NDPK3'.('E1159', 'E1160', 'E1161')
    'R_NDPK4'.('E1159', 'E1160', 'E1161')
    'R_NDPK5'.('E1159', 'E1160', 'E1161')
    'R_NDPK6'.('E1159', 'E1160', 'E1161')
    'R_NDPK7'.('E1159', 'E1160', 'E1161')
    'R_NDPK8'.('E1159', 'E1160', 'E1161')
    'R_NDPK9'.('E1159', 'E1160', 'E1161')
    'R_NNATr'.('E1169', 'E1170', 'E1171')
    'R_PGMT'.('E1908', 'E1909')
    'R_PMANM'.('E1909', 'E1910')
    'R_PPM'.('E1908', 'E1909')
    'R_PROt2r'.('E0092', 'E1922')
    'R_TMDK1'.('E0716', 'E0717')
    'R_UREAt'.('E0886', 'E1131', 'E1946')
    'R_r0220'.('E0105', 'E0142')
    'R_r0318'.('E0105', 'E0142')
    'R_r0345'.('E0150', 'E0151', 'E0155', 'E1848', 'E1949')
    'R_r0422'.('E1025', 'E1026')
    'R_GLYt2r'.('E0092', 'E1922')
    'R_ALAt2r'.('E0092', 'E1922')
    'R_NTD4'.('E1185', 'E1188', 'E1610', 'E1611')
    'R_NTD5'.('E1185', 'E1188', 'E1610', 'E1611')
    'R_NTD6'.('E1185', 'E1188', 'E1610', 'E1611', 'E1960')
    'R_NTD7'.('E1185', 'E1610', 'E1611', 'E1960')
    'R_NTD8'.('E1185', 'E1188', 'E1610', 'E1611', 'E1960')
    'R_NTD9'.('E1188', 'E1610', 'E1611')
    'R_NTD10'.('E1185', 'E1188', 'E1610', 'E1611', 'E1960')
    'R_NTD11'.('E1188', 'E1610', 'E1611', 'E1960')
    'R_ALCD1'.('E0028', 'E0030', 'E0033', 'E0034', 'E0241', 'E0242')
    'R_GCALDD'.('E0039', 'E0040', 'E0041', 'E0248', 'E0249', 'E0250',
                'E0251', 'E0252', 'E0253')
    'R_ALDD2x'.('E0039', 'E0040', 'E0041', 'E0248', 'E0249', 'E0250',
                'E0251', 'E0252', 'E0253', 'E0255')
    'R_AMANK'.('E0108', 'E1566')
    'R_GLXO1'.('E0010', 'E0012', 'E0014', 'E0017', 'E1010', 'E1011')
    'R_IMACTD'.('E0248', 'E0249', 'E0250', 'E0251', 'E0252', 'E0253')
    'R_LCADi'.('E0039', 'E0040', 'E0041', 'E0248', 'E0249', 'E0250',
                'E0251', 'E0252', 'E0253')
    'R_LDH_D'.('E1010', 'E1011')
    'R_LDH_L'.('E0010', 'E0012', 'E0014', 'E0017')
    'R_MI1PP'.('E1757', 'E1987', 'E1989')
    'R_NT5C'.('E1185', 'E1188', 'E1610', 'E1611', 'E1960')
    'R_NTD3'.('E1185', 'E1188', 'E1611', 'E1960', 'E1990')
    'R_PFK'.('E1625', 'E1992')
    'R_THRD_L'.('E0007', 'E2007')
    'R_r0392'.('E0250', 'E0252', 'E0253', 'E0255', 'E0256')
    'R_PYRt2r'.('E0018', 'E0019', 'E0020')
    'R_THMt3'.('E0537', 'E2013')
    'R_FORTHFC'.('E0899', 'E0900')
    'R_MTHFD2'.('E1124', 'E1899')
    'R_PHPYRte'.('E0018', 'E0019', 'E0020')
    'R_2H3MVc'.('E0010', 'E0012', 'E0014', 'E0017')
    'R_2HIVc'.('E0010', 'E0012', 'E0014', 'E0017')
    'R_AK2LGCHOLABCt'.('E0598', 'E1239', 'E1245')
    'R_CE2510ABCt'.('E0282', 'E0725', 'E0758', 'E0759', 'E0760', 'E1769')
    'R_CE2537ABCt'.('E0282', 'E0725', 'E0758', 'E0759', 'E0760', 'E1769')
    'R_NRVNCABCt'.('E0282', 'E0725', 'E0758', 'E0759', 'E0760', 'E1769')
    'R_PAFABCt'.('E0598', 'E1239', 'E1245')
    'R_PCHLN225_HSABCt'.('E0598', 'E1239', 'E1245')
    'R_PCHOL2LINL_HSABCt'.('E0598', 'E1239', 'E1245')
    'R_PCHOL2OLE_HSABCt'.('E0598', 'E1239', 'E1245')
    'R_PCHOL2STE_HSABCt'.('E0598', 'E1239', 'E1245')
    'R_PCHOLAR_HSABCt'.('E0598', 'E1239', 'E1245')
    'R_PCHOLDOC_HSABCt'.('E0598', 'E1239', 'E1245')
    'R_PCHOLEIC_HSABCt'.('E0598', 'E1239', 'E1245')
    'R_PCHOLET_HSABCt'.('E0598', 'E1239', 'E1245')
    'R_PCHOLHEP_HSABCt'.('E0598', 'E1239', 'E1245')
    'R_PCHOLLINL_HSABCt'.('E0598', 'E1239', 'E1245')
    'R_PCHOLMYR_HsABCt'.('E0598', 'E1239', 'E1245')
    'R_PCHOLN15_HSABCt'.('E0598', 'E1239', 'E1245')
    'R_PCHOLN183_HSABCt'.('E0598', 'E1239', 'E1245')
    'R_PCHOLN1836_HSABCt'.('E0598', 'E1239', 'E1245')
    'R_PCHOLN19_HSABCt'.('E0598', 'E1239', 'E1245')
    'R_PCHOLN201_HSABCt'.('E0598', 'E1239', 'E1245')
    'R_PCHOLN203_HSABCt'.('E0598', 'E1239', 'E1245')
    'R_PCHOLN204_HSABCt'.('E0598', 'E1239', 'E1245')
    'R_PCHOLN205_HSABCt'.('E0598', 'E1239', 'E1245')
    'R_PCHOLN224_HSABCt'.('E0598', 'E1239', 'E1245')
    'R_PCHOLN225_HSABCt'.('E0598', 'E1239', 'E1245')
    'R_PCHOLN2254_HSABCt'.('E0598', 'E1239', 'E1245')
    'R_PCHOLN264_HSABCt'.('E0598', 'E1239', 'E1245')
    'R_PCHOLOLE_HSABCt'.('E0598', 'E1239', 'E1245')
    'R_PCHOLPALME-HSABCt'.('E0598', 'E1239', 'E1245')
    'R_PCHOLSTE_HSABCt'.('E0598', 'E1239', 'E1245')
    'R_PEPALM_HSASBCt'.('E0598', 'E1239', 'E1245')
    'R_EIC21114TRc'.('E1640', 'E1642', 'E2025', 'E2027')
    'R_5EIPENCm'.('E1416', 'E1417', 'E1640', 'E2025')
    'R_CE7090te'.('E0074', 'E0728')
    'R_CE7085te'.('E0074', 'E0728')
    'R_CE7096te'.('E0074', 'E0728')
    'R_CE4877te'.('E0074', 'E0728')
    'R_CE1447te'.('E0074', 'E0728')
    'R_C05770te'.('E0528', 'E2028')
    'R_MLTHFte3'.('E0083', 'E1843')
    'R_CE2705t'.('E0148', 'E0170')
    'R_SPHS1Pt2e'.('E0074', 'E0598')
    'R_MMAte'.('E1165', 'E2029')
    'R_HDD2CRNte2'.('E0221', 'E0594')
    'R_MLTHFte1'.('E0074', 'E0528', 'E0728', 'E1245', 'E1703', 'E1819',
                'E1822')
    'R_CE1918te'.('E1814', 'E1815')
    'R_34DHOXMANDte'.('E1814', 'E1815')
    'R_CE6205te'.('E1814', 'E1815')
    'R_1A25DHVITD3te'.('E2031', 'E2032', 'E2033')
    'R_CE5026t'.('E0074', 'E2034')
    'R_SMS1S2'.('E1498', 'E1845')
    'R_HMR_0003'.('E1066', 'E1067', 'E1440')
    'R_HMR_0155'.('E0758', 'E0759', 'E0760', 'E1769', 'E1798', 'E2032')
    'R_HMR_0164'.('E0758', 'E0759', 'E0760', 'E1769', 'E1798', 'E2032')
    'R_HMR_0167'.('E0758', 'E0759', 'E0760', 'E1769', 'E1798', 'E2032')
    'R_HMR_0170'.('E0758', 'E0759', 'E0760', 'E1769', 'E1798', 'E2032')
    'R_HMR_0176'.('E0758', 'E0759', 'E0760', 'E1769', 'E1798', 'E2032')
    'R_HMR_0183'.('E0758', 'E0759', 'E0760', 'E1769', 'E1798', 'E2032')
    'R_HMR_0188'.('E0725', 'E0736', 'E0737', 'E0738', 'E0740', 'E0741',
                'E0742', 'E1770')
    'R_HMR_0189'.('E0517', 'E1416', 'E1420', 'E1640', 'E1642', 'E1712',
                'E2077')
    'R_HMR_0191'.('E0758', 'E0759', 'E0760', 'E1769', 'E1798', 'E2032')
    'R_HMR_0192'.('E0725', 'E0736', 'E0737', 'E0738', 'E0740', 'E0741',
                'E0742', 'E1770')
    'R_HMR_0193'.('E0517', 'E1416', 'E1420', 'E1640', 'E1642', 'E1712',
                'E2077')
    'R_HMR_0197'.('E0517', 'E1416', 'E1420', 'E1640', 'E1642', 'E1712',
                'E2077')
    'R_HMR_0200'.('E0725', 'E0736', 'E0737', 'E0738', 'E0740', 'E0741',
                'E0742', 'E1770')
    'R_HMR_0201'.('E0517', 'E1416', 'E1420', 'E1640', 'E1642', 'E1712',
                'E2077')
    'R_HMR_0203'.('E0758', 'E0759', 'E0760', 'E1769', 'E1798', 'E2032')
    'R_HMR_0204'.('E0725', 'E0736', 'E0737', 'E0738', 'E0740', 'E0741',
                'E0742', 'E1770')
    'R_HMR_0206'.('E0517', 'E1416', 'E1420', 'E1640', 'E1642', 'E1712',
                'E2077')
    'R_HMR_0208'.('E0758', 'E0759', 'E0760', 'E1769', 'E1798', 'E2032')
    'R_HMR_0209'.('E0725', 'E0736', 'E0737', 'E0738', 'E0740', 'E0741',
                'E0742', 'E1770')
    'R_HMR_0210'.('E0517', 'E1416', 'E1420', 'E1640', 'E1642', 'E1712',
                'E2077')
    'R_HMR_0214'.('E0517', 'E1416', 'E1420', 'E1640', 'E1642', 'E1712',
                'E2077')
    'R_HMR_0230'.('E0517', 'E1416', 'E1420', 'E1640', 'E1642', 'E1712',
                'E2077')
    'R_HMR_0232'.('E0758', 'E0759', 'E0760', 'E1769', 'E1798', 'E2032')
    'R_HMR_0233'.('E0725', 'E0736', 'E0737', 'E0738', 'E0740', 'E0741',
                'E0742', 'E1770')
    'R_HMR_0234'.('E0517', 'E1416', 'E1420', 'E1640', 'E1642', 'E1712',
                'E2077')
    'R_HMR_0238'.('E0517', 'E1416', 'E1420', 'E1640', 'E1642', 'E1712',
                'E2077')
    'R_HMR_0240'.('E0758', 'E0759', 'E0760', 'E1769', 'E1798', 'E2032')
    'R_HMR_0241'.('E0725', 'E0736', 'E0737', 'E0738', 'E0740', 'E0741',
                'E0742', 'E1770')
    'R_HMR_0242'.('E0517', 'E1416', 'E1420', 'E1640', 'E1642', 'E1712',
                'E2077')
    'R_HMR_0244'.('E0758', 'E0759', 'E0760', 'E1769', 'E1798', 'E2032')
    'R_HMR_0245'.('E0725', 'E0736', 'E0737', 'E0738', 'E0740', 'E0741',
                'E0742', 'E1770')
    'R_HMR_0246'.('E0517', 'E1416', 'E1420', 'E1640', 'E1642', 'E1712',
                'E2077')
    'R_HMR_0254'.('E0758', 'E0759', 'E0760', 'E1769', 'E1798', 'E2032')
    'R_HMR_0255'.('E0725', 'E0736', 'E0737', 'E0738', 'E0740', 'E0741',
                'E0742', 'E1770')
    'R_HMR_0256'.('E0517', 'E1416', 'E1420', 'E1640', 'E1642', 'E1712',
                'E2077')
    'R_HMR_0259'.('E0725', 'E0736', 'E0737', 'E0738', 'E0740', 'E0741',
                'E0742', 'E1770')
    'R_HMR_0260'.('E0517', 'E1416', 'E1420', 'E1640', 'E1642', 'E1712',
                'E2077')
    'R_HMR_0267'.('E0725', 'E0736', 'E0737', 'E0738', 'E0740', 'E0741',
                'E0742', 'E1770')
    'R_HMR_0268'.('E0517', 'E1416', 'E1420', 'E1640', 'E1642', 'E1712',
                'E2077')
    'R_HMR_0270'.('E0758', 'E0759', 'E0760', 'E1769', 'E1798', 'E2032')
    'R_HMR_0271'.('E0725', 'E0736', 'E0737', 'E0738', 'E0740', 'E0741',
                'E0742', 'E1770')
    'R_HMR_0272'.('E0517', 'E1416', 'E1420', 'E1640', 'E1642', 'E1712',
                'E2077')
    'R_HMR_0276'.('E0517', 'E1416', 'E1420', 'E1640', 'E1642', 'E1712',
                'E2077')
    'R_HMR_0278'.('E0758', 'E0759', 'E0760', 'E1769', 'E1798', 'E2032')
    'R_HMR_0279'.('E0725', 'E0736', 'E0737', 'E0738', 'E0740', 'E0741',
                'E0742', 'E1770')
    'R_HMR_0280'.('E0517', 'E1416', 'E1420', 'E1640', 'E1642', 'E1712',
                'E2077')
    'R_HMR_0288'.('E0758', 'E0759', 'E0760', 'E1769', 'E1798', 'E2032')
    'R_HMR_0289'.('E0725', 'E0736', 'E0737', 'E0738', 'E0740', 'E0741',
                'E0742', 'E1770')
    'R_HMR_0290'.('E0517', 'E1416', 'E1420', 'E1640', 'E1642', 'E1712',
                'E2077')
    'R_HMR_0292'.('E0758', 'E0759', 'E0760', 'E1769', 'E1798', 'E2032')
    'R_HMR_0293'.('E0725', 'E0736', 'E0737', 'E0738', 'E0740', 'E0741',
                'E0742', 'E1770')
    'R_HMR_0296'.('E0758', 'E0759', 'E0760', 'E1769', 'E1798', 'E2032')
    'R_HMR_0297'.('E0725', 'E0736', 'E0737', 'E0738', 'E0740', 'E0741',
                'E0742', 'E1770')
    'R_HMR_0298'.('E0517', 'E1416', 'E1420', 'E1640', 'E1642', 'E1712',
                'E2077')
    'R_HMR_0300'.('E0758', 'E0759', 'E0760', 'E1769', 'E1798', 'E2032')
    'R_HMR_0301'.('E0725', 'E0736', 'E0737', 'E0738', 'E0740', 'E0741',
                'E0742', 'E1770')
    'R_HMR_0302'.('E0517', 'E1416', 'E1420', 'E1640', 'E1642', 'E1712',
                'E2077')
    'R_HMR_0304'.('E0758', 'E0759', 'E0760', 'E1769', 'E1798', 'E2032')
    'R_HMR_0305'.('E0725', 'E0736', 'E0737', 'E0738', 'E0740', 'E0741',
                'E0742', 'E1770')
    'R_HMR_0306'.('E0517', 'E1416', 'E1420', 'E1640', 'E1642', 'E1712',
                'E2077')
    'R_HMR_0308'.('E0758', 'E0759', 'E0760', 'E1769', 'E1798', 'E2032')
    'R_HMR_0309'.('E0725', 'E0736', 'E0737', 'E0738', 'E0740', 'E0741',
                'E0742', 'E1770')
    'R_HMR_0310'.('E0517', 'E1416', 'E1420', 'E1640', 'E1642', 'E1712',
                'E2077')
    'R_HMR_0319'.('E0725', 'E0736', 'E0737', 'E0738', 'E0740', 'E0741',
                'E0742', 'E1770')
    'R_HMR_0322'.('E0758', 'E0759', 'E0760', 'E1769', 'E1798', 'E2032')
    'R_HMR_0323'.('E0725', 'E0736', 'E0737', 'E0738', 'E0740', 'E0741',
                'E0742', 'E1770')
    'R_HMR_0324'.('E0517', 'E1416', 'E1420', 'E1640', 'E1642', 'E1712',
                'E2077')
    'R_HMR_0326'.('E0758', 'E0759', 'E0760', 'E1769', 'E1798', 'E2032')
    'R_HMR_0327'.('E0725', 'E0736', 'E0737', 'E0738', 'E0740', 'E0741',
                'E0742', 'E1770')
    'R_HMR_0328'.('E0517', 'E1416', 'E1420', 'E1640', 'E1642', 'E1712',
                'E2077')
    'R_HMR_0342'.('E0517', 'E1416', 'E1420', 'E1640', 'E1642', 'E1712',
                'E2077')
    'R_HMR_0344'.('E0758', 'E0759', 'E0760', 'E1769', 'E1798', 'E2032')
    'R_HMR_0345'.('E0725', 'E0736', 'E0737', 'E0738', 'E0740', 'E0741',
                'E0742', 'E1770')
    'R_HMR_0346'.('E0517', 'E1416', 'E1420', 'E1640', 'E1642', 'E1712',
                'E2077')
    'R_HMR_0350'.('E0517', 'E1416', 'E1420', 'E1640', 'E1642', 'E1712',
                'E2077')
    'R_HMR_0354'.('E0517', 'E1416', 'E1420', 'E1640', 'E1642', 'E1712',
                'E2077')
    'R_HMR_0358'.('E0517', 'E1416', 'E1420', 'E1640', 'E1642', 'E1712',
                'E2077')
    'R_HMR_0362'.('E0517', 'E1416', 'E1420', 'E1640', 'E1642', 'E1712',
                'E2077')
    'R_HMR_0366'.('E0517', 'E1416', 'E1420', 'E1640', 'E1642', 'E1712',
                'E2077')
    'R_HMR_0370'.('E0517', 'E1416', 'E1420', 'E1640', 'E1642', 'E1712',
                'E2077')
    'R_HMR_0374'.('E0517', 'E1416', 'E1420', 'E1640', 'E1642', 'E1712',
                'E2077')
    'R_HMR_0378'.('E0517', 'E1416', 'E1420', 'E1640', 'E1642', 'E1712',
                'E2077')
    'R_HMR_0380'.('E0758', 'E0759', 'E0760', 'E1769', 'E1798', 'E2032')
    'R_HMR_0381'.('E0725', 'E0736', 'E0737', 'E0738', 'E0740', 'E0741',
                'E0742', 'E1770')
    'R_HMR_0382'.('E0517', 'E1416', 'E1420', 'E1640', 'E1642', 'E1712',
                'E2077')
    'R_HMR_0384'.('E0758', 'E0759', 'E0760', 'E1769', 'E1798', 'E2032')
    'R_HMR_0385'.('E0725', 'E0736', 'E0737', 'E0738', 'E0740', 'E0741',
                'E0742', 'E1770')
    'R_HMR_0386'.('E0517', 'E1416', 'E1420', 'E1640', 'E1642', 'E1712',
                'E2077')
    'R_HMR_0388'.('E0758', 'E0759', 'E0760', 'E1769', 'E1798', 'E2032')
    'R_HMR_0389'.('E0725', 'E0736', 'E0737', 'E0738', 'E0740', 'E0741',
                'E0742', 'E1770')
    'R_HMR_0390'.('E0517', 'E1416', 'E1420', 'E1640', 'E1642', 'E1712',
                'E2077')
    'R_HMR_0392'.('E0758', 'E0759', 'E0760', 'E1769', 'E1798', 'E2032')
    'R_HMR_0393'.('E0725', 'E0736', 'E0737', 'E0738', 'E0740', 'E0741',
                'E0742', 'E1770')
    'R_HMR_0394'.('E0517', 'E1416', 'E1420', 'E1640', 'E1642', 'E1712',
                'E2077')
    'R_HMR_0398'.('E0517', 'E1416', 'E1420', 'E1640', 'E1642', 'E1712',
                'E2077')
    'R_HMR_0402'.('E0517', 'E1416', 'E1420', 'E1640', 'E1642', 'E1712',
                'E2077')
    'R_HMR_0406'.('E0517', 'E1416', 'E1420', 'E1640', 'E1642', 'E1712',
                'E2077')
    'R_HMR_0410'.('E0517', 'E1416', 'E1420', 'E1640', 'E1642', 'E1712',
                'E2077')
    'R_HMR_0414'.('E0517', 'E1416', 'E1420', 'E1640', 'E1642', 'E1712',
                'E2077')
    'R_HMR_0418'.('E0517', 'E1416', 'E1420', 'E1640', 'E1642', 'E1712',
                'E2077')
    'R_HMR_0422'.('E0517', 'E1416', 'E1420', 'E1640', 'E1642', 'E1712',
                'E2077')
    'R_HMR_0426'.('E0517', 'E1416', 'E1420', 'E1640', 'E1642', 'E1712',
                'E2077')
    'R_HMR_0428'.('E0758', 'E0759', 'E0760', 'E1769', 'E1798', 'E2032')
    'R_HMR_0429'.('E0725', 'E0736', 'E0737', 'E0738', 'E0740', 'E0741',
                'E0742', 'E1770')
    'R_HMR_0430'.('E0517', 'E1416', 'E1420', 'E1640', 'E1642', 'E1712',
                'E2077')
    'R_HMR_0432'.('E0758', 'E0759', 'E0760', 'E1769', 'E1798', 'E2032')
    'R_HMR_0433'.('E0725', 'E0736', 'E0737', 'E0738', 'E0740', 'E0741',
                'E0742', 'E1770')
    'R_HMR_0434'.('E0517', 'E1416', 'E1420', 'E1640', 'E1642', 'E1712',
                'E2077')
    'R_HMR_0436'.('E0758', 'E0759', 'E0760', 'E1769', 'E1798', 'E2032')
    'R_HMR_0437'.('E0725', 'E0736', 'E0737', 'E0738', 'E0740', 'E0741',
                'E0742', 'E1770')
    'R_HMR_0438'.('E0517', 'E1416', 'E1420', 'E1640', 'E1642', 'E1712',
                'E2077')
    'R_HMR_0597'.('E1402', 'E1403', 'E2081', 'E2082')
    'R_HMR_0598'.('E1402', 'E1403', 'E2081', 'E2082')
    'R_HMR_0601'.('E1402', 'E1403', 'E2081', 'E2082')
    'R_HMR_0614'.('E0567', 'E2089')
    'R_HMR_0625'.('E0567', 'E0568')
    'R_HMR_0629'.('E1240', 'E1241', 'E2090', 'E2092')
    'R_HMR_0642'.('E1240', 'E1241', 'E2090')
    'R_HMR_0672'.('E1066', 'E1067', 'E1440')
    'R_HMR_0753'.('E0291', 'E2037', 'E2038')
    'R_HMR_0765'.('E0090', 'E0189', 'E0190', 'E0192', 'E0197', 'E0512',
                'E0516', 'E0533', 'E0626', 'E0794', 'E0795', 'E0799',
                'E0828', 'E0834', 'E0844', 'E0965', 'E0972', 'E1745',
                'E2107', 'E2114', 'E2126')
    'R_HMR_0767'.('E1402', 'E1403', 'E2081', 'E2082')
    'R_HMR_0775'.('E1402', 'E1403', 'E2081')
    'R_HMR_0795'.('E1492', 'E1494', 'E1496', 'E1497')
    'R_HMR_0807'.('E0210', 'E0211', 'E2134')
    'R_HMR_0808'.('E0210', 'E0211', 'E2134')
    'R_HMR_0812'.('E1443', 'E1445')
    'R_HMR_0817'.('E1443', 'E1445')
    'R_HMR_0819'.('E1052', 'E1053', 'E2135')
    'R_HMR_0821'.('E0210', 'E0211', 'E2134')
    'R_HMR_0823'.('E1533', 'E2136')
    'R_HMR_0825'.('E2049', 'E2050', 'E2137')
    'R_HMR_0828'.('E0210', 'E0211', 'E2134')
    'R_HMR_0830'.('E1052', 'E1053', 'E2135')
    'R_HMR_0837'.('E1443', 'E1445')
    'R_HMR_0844'.('E1443', 'E1445')
    'R_HMR_0847'.('E2049', 'E2050', 'E2137')
    'R_HMR_0855'.('E1536', 'E1537')
    'R_HMR_0860'.('E0512', 'E2114')
    'R_HMR_0864'.('E0792', 'E2139')
    'R_HMR_0870'.('E0793', 'E2140')
    'R_HMR_0873'.('E0793', 'E2140')
    'R_HMR_0875'.('E0795', 'E2107')
    'R_HMR_0889'.('E0189', 'E0190', 'E0191', 'E0197')
    'R_HMR_0890'.('E0795', 'E2107')
    'R_HMR_0911'.('E0793', 'E0794', 'E2126', 'E2140')
    'R_HMR_0942'.('E0146', 'E1059', 'E1092', 'E1093', 'E1094', 'E1207',
                'E1209', 'E1212', 'E1213', 'E1215', 'E1217', 'E1218',
                'E1224', 'E1225', 'E1227', 'E1734', 'E2142')
    'R_HMR_0946'.('E0146', 'E1059', 'E1092', 'E1093', 'E1094', 'E1207',
                'E1209', 'E1212', 'E1213', 'E1215', 'E1217', 'E1218',
                'E1224', 'E1225', 'E1227', 'E1734', 'E2142')
    'R_HMR_0950'.('E0146', 'E1059', 'E1092', 'E1093', 'E1094', 'E1207',
                'E1209', 'E1212', 'E1213', 'E1215', 'E1217', 'E1218',
                'E1224', 'E1225', 'E1227', 'E1734', 'E2142')
    'R_HMR_0954'.('E0146', 'E1059', 'E1092', 'E1093', 'E1094', 'E1207',
                'E1209', 'E1212', 'E1213', 'E1215', 'E1217', 'E1218',
                'E1224', 'E1225', 'E1227', 'E1734', 'E2142')
    'R_HMR_0960'.('E0932', 'E0935', 'E0938', 'E0940', 'E1408', 'E1758')
    'R_HMR_0963'.('E0932', 'E0935', 'E0938', 'E0940', 'E1408', 'E1758')
    'R_HMR_0981'.('E1059', 'E1228', 'E1734', 'E1752')
    'R_HMR_1084'.('E0858', 'E0946', 'E0947')
    'R_HMR_1102'.('E0562', 'E1751')
    'R_HMR_1126'.('E1059', 'E1228', 'E1734', 'E1752')
    'R_HMR_1127'.('E1059', 'E1228', 'E1734', 'E1752')
    'R_HMR_1312'.('E1311', 'E2146')
    'R_HMR_1490'.('E0542', 'E2150')
    'R_HMR_1493'.('E0542', 'E2150')
    'R_HMR_1494'.('E0542', 'E2150')
    'R_HMR_1495'.('E0540', 'E2151')
    'R_HMR_1502'.('E0542', 'E2150')
    'R_HMR_1503'.('E0542', 'E2150')
    'R_HMR_1504'.('E0542', 'E2150')
    'R_HMR_1532'.('E0697', 'E1862')
    'R_HMR_1540'.('E0539', 'E2152')
    'R_HMR_1543'.('E0542', 'E2150')
    'R_HMR_1544'.('E0542', 'E2150')
    'R_HMR_1545'.('E0542', 'E2150')
    'R_HMR_1548'.('E0542', 'E2150')
    'R_HMR_1549'.('E0542', 'E2150')
    'R_HMR_1550'.('E0542', 'E2150')
    'R_HMR_1620'.('E0282', 'E0725')
    'R_HMR_1627'.('E0282', 'E0725')
    'R_HMR_1637'.('E0131', 'E1647')
    'R_HMR_1651'.('E0974', 'E1716')
    'R_HMR_1653'.('E0102', 'E1483', 'E2153')
    'R_HMR_1665'.('E0282', 'E0725')
    'R_HMR_1666'.('E0282', 'E0725')
    'R_HMR_1754'.('E0282', 'E0725')
    'R_HMR_1756'.('E0282', 'E0725')
    'R_HMR_2016'.('E0218', 'E0219', 'E2149')
    'R_HMR_2018'.('E0218', 'E0219', 'E2149')
    'R_HMR_2029'.('E0146', 'E1059', 'E1092', 'E1093', 'E1094', 'E1207',
                'E1209', 'E1212', 'E1213', 'E1215', 'E1217', 'E1218',
                'E1224', 'E1225', 'E1227', 'E1734', 'E2142')
    'R_HMR_2041'.('E1016', 'E1018', 'E1019', 'E2159', 'E2161')
    'R_HMR_2088'.('E1028', 'E1407', 'E1408', 'E1409', 'E1722')
    'R_HMR_2089'.('E1028', 'E1407', 'E1408', 'E1409', 'E1722')
    'R_HMR_2190'.('E0747', 'E2163')
    'R_HMR_2210'.('E2171', 'E2172')
    'R_HMR_2211'.('E0747', 'E2163')
    'R_HMR_2215'.('E0747', 'E2163')
    'R_HMR_2219'.('E2171', 'E2172')
    'R_HMR_2259'.('E0747', 'E2163')
    'R_HMR_2262'.('E2171', 'E2172')
    'R_HMR_2263'.('E0747', 'E2163')
    'R_HMR_2266'.('E2171', 'E2172')
    'R_HMR_2267'.('E0747', 'E2163')
    'R_HMR_2332'.('E0747', 'E2163')
    'R_HMR_2338'.('E2171', 'E2172')
    'R_HMR_2342'.('E0747', 'E2163')
    'R_HMR_2345'.('E2171', 'E2172')
    'R_HMR_2347'.('E0747', 'E2163')
    'R_HMR_2350'.('E2171', 'E2172')
    'R_HMR_2353'.('E0747', 'E2163')
    'R_HMR_2356'.('E2171', 'E2172')
    'R_HMR_2359'.('E0672', 'E0673', 'E2174')
    'R_HMR_2361'.('E0747', 'E2163')
    'R_HMR_2364'.('E2171', 'E2172')
    'R_HMR_2365'.('E0672', 'E0673', 'E2174')
    'R_HMR_2368'.('E0672', 'E0673', 'E2174')
    'R_HMR_2380'.('E0672', 'E0673', 'E2174')
    'R_HMR_2395'.('E0747', 'E2163')
    'R_HMR_2433'.('E0747', 'E2163')
    'R_HMR_2436'.('E2171', 'E2172')
    'R_HMR_2457'.('E0146', 'E1059', 'E1092', 'E1093', 'E1094', 'E1207',
                'E1209', 'E1212', 'E1213', 'E1215', 'E1217', 'E1218',
                'E1224', 'E1225', 'E1227', 'E1734', 'E2142')
    'R_HMR_2472'.('E0672', 'E0673', 'E2174')
    'R_HMR_2484'.('E0672', 'E0673', 'E2174')
    'R_HMR_2530'.('E0747', 'E2163')
    'R_HMR_2537'.('E2171', 'E2172')
    'R_HMR_2540'.('E0747', 'E2163')
    'R_HMR_2543'.('E2171', 'E2172')
    'R_HMR_2581'.('E1318', 'E2175')
    'R_HMR_2602'.('E0178', 'E0182')
    'R_HMR_2603'.('E0141', 'E0630', 'E1183', 'E2176')
    'R_HMR_2604'.('E0184', 'E0629')
    'R_HMR_2608'.('E0178', 'E0182')
    'R_HMR_2609'.('E0141', 'E0630', 'E1183', 'E2176')
    'R_HMR_2610'.('E0184', 'E0629')
    'R_HMR_2611'.('E0178', 'E0182')
    'R_HMR_2612'.('E0141', 'E0630', 'E1183', 'E2176')
    'R_HMR_2613'.('E0184', 'E0629')
    'R_HMR_2620'.('E0178', 'E0182')
    'R_HMR_2621'.('E0141', 'E0630', 'E1183', 'E2176')
    'R_HMR_2622'.('E0184', 'E0629')
    'R_HMR_2624'.('E0141', 'E0630', 'E1183', 'E2176')
    'R_HMR_2633'.('E0178', 'E0182')
    'R_HMR_2634'.('E0141', 'E0630', 'E1183', 'E2176')
    'R_HMR_2635'.('E0184', 'E0629')
    'R_HMR_2644'.('E0141', 'E0630', 'E1183', 'E2176')
    'R_HMR_2648'.('E0178', 'E0182')
    'R_HMR_2649'.('E0141', 'E0630', 'E1183', 'E2176')
    'R_HMR_2650'.('E0184', 'E0629')
    'R_HMR_2651'.('E0178', 'E0182')
    'R_HMR_2652'.('E0141', 'E0630', 'E1183', 'E2176')
    'R_HMR_2653'.('E0184', 'E0629')
    'R_HMR_2655'.('E0141', 'E0630', 'E1183', 'E2176')
    'R_HMR_2657'.('E0178', 'E0182')
    'R_HMR_2659'.('E0184', 'E0629')
    'R_HMR_2660'.('E0178', 'E0182')
    'R_HMR_2661'.('E0141', 'E0630', 'E1183', 'E2176')
    'R_HMR_2662'.('E0184', 'E0629')
    'R_HMR_2666'.('E0178', 'E0182')
    'R_HMR_2667'.('E0141', 'E0630', 'E1183', 'E2176')
    'R_HMR_2668'.('E0184', 'E0629')
    'R_HMR_2669'.('E0178', 'E0182')
    'R_HMR_2670'.('E0141', 'E0630', 'E1183', 'E2176')
    'R_HMR_2671'.('E0184', 'E0629')
    'R_HMR_2673'.('E0141', 'E0630', 'E1183', 'E2176')
    'R_HMR_2675'.('E0178', 'E0182')
    'R_HMR_2676'.('E0141', 'E0630', 'E1183', 'E2176')
    'R_HMR_2677'.('E0184', 'E0629')
    'R_HMR_2679'.('E0141', 'E0630', 'E1183', 'E2176')
    'R_HMR_2681'.('E0178', 'E0182')
    'R_HMR_2682'.('E0141', 'E0630', 'E1183', 'E2176')
    'R_HMR_2683'.('E0184', 'E0629')
    'R_HMR_2684'.('E0178', 'E0182')
    'R_HMR_2685'.('E0141', 'E0630', 'E1183', 'E2176')
    'R_HMR_2686'.('E0184', 'E0629')
    'R_HMR_2687'.('E0178', 'E0182')
    'R_HMR_2688'.('E0141', 'E0630', 'E1183', 'E2176')
    'R_HMR_2689'.('E0184', 'E0629')
    'R_HMR_2690'.('E0178', 'E0182')
    'R_HMR_2691'.('E0141', 'E0630', 'E1183', 'E2176')
    'R_HMR_2692'.('E0184', 'E0629')
    'R_HMR_2693'.('E0178', 'E0182')
    'R_HMR_2695'.('E0141', 'E0630', 'E1183', 'E2176')
    'R_HMR_2697'.('E0184', 'E0629')
    'R_HMR_2699'.('E0178', 'E0182')
    'R_HMR_2700'.('E0141', 'E0630', 'E1183', 'E2176')
    'R_HMR_2701'.('E0184', 'E0629')
    'R_HMR_2702'.('E0178', 'E0182')
    'R_HMR_2703'.('E0141', 'E0630', 'E1183', 'E2176')
    'R_HMR_2704'.('E0184', 'E0629')
    'R_HMR_2705'.('E0178', 'E0182')
    'R_HMR_2706'.('E0141', 'E0630', 'E1183', 'E2176')
    'R_HMR_2707'.('E0184', 'E0629')
    'R_HMR_2708'.('E0178', 'E0182')
    'R_HMR_2709'.('E0141', 'E0630', 'E1183', 'E2176')
    'R_HMR_2710'.('E0184', 'E0629')
    'R_HMR_2711'.('E0178', 'E0182')
    'R_HMR_2712'.('E0141', 'E0630', 'E1183', 'E2176')
    'R_HMR_2713'.('E0184', 'E0629')
    'R_HMR_2715'.('E0141', 'E0630', 'E1183', 'E2176')
    'R_HMR_2718'.('E0141', 'E0630', 'E1183', 'E2176')
    'R_HMR_2722'.('E0141', 'E0630', 'E1183', 'E2176')
    'R_HMR_2727'.('E0141', 'E0630', 'E1183', 'E2176')
    'R_HMR_2731'.('E0141', 'E0630', 'E1183', 'E2176')
    'R_HMR_2733'.('E0178', 'E0182')
    'R_HMR_2734'.('E0141', 'E0630', 'E1183', 'E2176')
    'R_HMR_2735'.('E0184', 'E0629')
    'R_HMR_2736'.('E0178', 'E0182')
    'R_HMR_2737'.('E0141', 'E0630', 'E1183', 'E2176')
    'R_HMR_2738'.('E0184', 'E0629')
    'R_HMR_2739'.('E0178', 'E0182')
    'R_HMR_2740'.('E0141', 'E0630', 'E1183', 'E2176')
    'R_HMR_2741'.('E0184', 'E0629')
    'R_HMR_2744'.('E0141', 'E0630', 'E1183', 'E2176')
    'R_HMR_2748'.('E0141', 'E0630', 'E1183', 'E2176')
    'R_HMR_2753'.('E0141', 'E0630', 'E1183', 'E2176')
    'R_HMR_2757'.('E0141', 'E0630', 'E1183', 'E2176')
    'R_HMR_2760'.('E0141', 'E0630', 'E1183', 'E2176')
    'R_HMR_2764'.('E0141', 'E0630', 'E1183', 'E2176')
    'R_HMR_2768'.('E0178', 'E0182')
    'R_HMR_2769'.('E0141', 'E0630', 'E1183', 'E2176')
    'R_HMR_2770'.('E0184', 'E0629')
    'R_HMR_2771'.('E0178', 'E0182')
    'R_HMR_2772'.('E0141', 'E0630', 'E1183', 'E2176')
    'R_HMR_2773'.('E0184', 'E0629')
    'R_HMR_2774'.('E0178', 'E0182')
    'R_HMR_2775'.('E0141', 'E0630', 'E1183', 'E2176')
    'R_HMR_2776'.('E0184', 'E0629')
    'R_HMR_2942'.('E0725', 'E0736', 'E0737', 'E0738', 'E0740', 'E0741',
                'E0742', 'E1770')
    'R_HMR_2943'.('E0725', 'E0736', 'E0737', 'E0738', 'E0740', 'E0741',
                'E0742', 'E1770')
    'R_HMR_2944'.('E0725', 'E0736', 'E0737', 'E0738', 'E0740', 'E0741',
                'E0742', 'E1770')
    'R_HMR_2945'.('E0725', 'E0736', 'E0737', 'E0738', 'E0740', 'E0741',
                'E0742', 'E1770')
    'R_HMR_2946'.('E0725', 'E0736', 'E0737', 'E0738', 'E0740', 'E0741',
                'E0742', 'E1770')
    'R_HMR_2947'.('E0725', 'E0736', 'E0737', 'E0738', 'E0740', 'E0741',
                'E0742', 'E1770')
    'R_HMR_2948'.('E0725', 'E0736', 'E0737', 'E0738', 'E0740', 'E0741',
                'E0742', 'E1770')
    'R_HMR_2951'.('E0725', 'E0736', 'E0737', 'E0738', 'E0740', 'E0741',
                'E0742', 'E1770')
    'R_HMR_2954'.('E0725', 'E0736', 'E0737', 'E0738', 'E0740', 'E0741',
                'E0742', 'E1770')
    'R_HMR_2955'.('E0725', 'E0736', 'E0737', 'E0738', 'E0740', 'E0741',
                'E0742', 'E1770')
    'R_HMR_2956'.('E0725', 'E0736', 'E0737', 'E0738', 'E0740', 'E0741',
                'E0742', 'E1770')
    'R_HMR_2961'.('E0725', 'E0736', 'E0737', 'E0738', 'E0740', 'E0741',
                'E0742', 'E1770')
    'R_HMR_2962'.('E0725', 'E0736', 'E0737', 'E0738', 'E0740', 'E0741',
                'E0742', 'E1770')
    'R_HMR_2963'.('E0725', 'E0736', 'E0737', 'E0738', 'E0740', 'E0741',
                'E0742', 'E1770')
    'R_HMR_2964'.('E0725', 'E0736', 'E0737', 'E0738', 'E0740', 'E0741',
                'E0742', 'E1770')
    'R_HMR_2965'.('E0725', 'E0736', 'E0737', 'E0738', 'E0740', 'E0741',
                'E0742', 'E1770')
    'R_HMR_2966'.('E0725', 'E0736', 'E0737', 'E0738', 'E0740', 'E0741',
                'E0742', 'E1770')
    'R_HMR_2967'.('E0725', 'E0736', 'E0737', 'E0738', 'E0740', 'E0741',
                'E0742', 'E1770')
    'R_HMR_2968'.('E0725', 'E0736', 'E0737', 'E0738', 'E0740', 'E0741',
                'E0742', 'E1770')
    'R_HMR_2969'.('E0725', 'E0736', 'E0737', 'E0738', 'E0740', 'E0741',
                'E0742', 'E1770')
    'R_HMR_2970'.('E0725', 'E0736', 'E0737', 'E0738', 'E0740', 'E0741',
                'E0742', 'E1770')
    'R_HMR_2971'.('E0725', 'E0736', 'E0737', 'E0738', 'E0740', 'E0741',
                'E0742', 'E1770')
    'R_HMR_2972'.('E0725', 'E0736', 'E0737', 'E0738', 'E0740', 'E0741',
                'E0742', 'E1770')
    'R_HMR_2973'.('E0725', 'E0736', 'E0737', 'E0738', 'E0740', 'E0741',
                'E0742', 'E1770')
    'R_HMR_2974'.('E0725', 'E0736', 'E0737', 'E0738', 'E0740', 'E0741',
                'E0742', 'E1770')
    'R_HMR_2975'.('E0725', 'E0736', 'E0737', 'E0738', 'E0740', 'E0741',
                'E0742', 'E1770')
    'R_HMR_2976'.('E0725', 'E0736', 'E0737', 'E0738', 'E0740', 'E0741',
                'E0742', 'E1770')
    'R_HMR_2977'.('E0725', 'E0736', 'E0737', 'E0738', 'E0740', 'E0741',
                'E0742', 'E1770')
    'R_HMR_2978'.('E0725', 'E0736', 'E0737', 'E0738', 'E0740', 'E0741',
                'E0742', 'E1770')
    'R_HMR_2979'.('E0725', 'E0736', 'E0737', 'E0738', 'E0740', 'E0741',
                'E0742', 'E1770')
    'R_HMR_2980'.('E0725', 'E0736', 'E0737', 'E0738', 'E0740', 'E0741',
                'E0742', 'E1770')
    'R_HMR_2982'.('E0725', 'E0736', 'E0737', 'E0738', 'E0740', 'E0741',
                'E0742', 'E1770')
    'R_HMR_2983'.('E0725', 'E0736', 'E0737', 'E0738', 'E0740', 'E0741',
                'E0742', 'E1770')
    'R_HMR_2985'.('E0725', 'E0736', 'E0737', 'E0738', 'E0740', 'E0741',
                'E0742', 'E1770')
    'R_HMR_2986'.('E0725', 'E0736', 'E0737', 'E0738', 'E0740', 'E0741',
                'E0742', 'E1770')
    'R_HMR_2988'.('E0725', 'E0736', 'E0737', 'E0738', 'E0740', 'E0741',
                'E0742', 'E1770')
    'R_HMR_2989'.('E0725', 'E0736', 'E0737', 'E0738', 'E0740', 'E0741',
                'E0742', 'E1770')
    'R_HMR_2990'.('E0725', 'E0736', 'E0737', 'E0738', 'E0740', 'E0741',
                'E0742', 'E1770')
    'R_HMR_2994'.('E0725', 'E0736', 'E0737', 'E0738', 'E0740', 'E0741',
                'E0742', 'E1770')
    'R_HMR_2998'.('E0725', 'E0736', 'E0737', 'E0738', 'E0740', 'E0741',
                'E0742', 'E1770')
    'R_HMR_2999'.('E0725', 'E0736', 'E0737', 'E0738', 'E0740', 'E0741',
                'E0742', 'E1770')
    'R_HMR_3001'.('E0725', 'E0736', 'E0737', 'E0738', 'E0740', 'E0741',
                'E0742', 'E1770')
    'R_HMR_3002'.('E0725', 'E0736', 'E0737', 'E0738', 'E0740', 'E0741',
                'E0742', 'E1770')
    'R_HMR_3003'.('E0725', 'E0736', 'E0737', 'E0738', 'E0740', 'E0741',
                'E0742', 'E1770')
    'R_HMR_3057'.('E0131', 'E1647')
    'R_HMR_3059'.('E0541', 'E0724')
    'R_HMR_3062'.('E0131', 'E1647')
    'R_HMR_3064'.('E0541', 'E0724')
    'R_HMR_3065'.('E0102', 'E2153')
    'R_HMR_3066'.('E0131', 'E1647')
    'R_HMR_3068'.('E0541', 'E0724')
    'R_HMR_3069'.('E0102', 'E2153')
    'R_HMR_3070'.('E0131', 'E1647')
    'R_HMR_3072'.('E0541', 'E0724')
    'R_HMR_3073'.('E0102', 'E2153')
    'R_HMR_3074'.('E0131', 'E1647')
    'R_HMR_3076'.('E0541', 'E0724')
    'R_HMR_3094'.('E0131', 'E1647')
    'R_HMR_3096'.('E0541', 'E0724')
    'R_HMR_3097'.('E0102', 'E2153')
    'R_HMR_3098'.('E0131', 'E1647')
    'R_HMR_3100'.('E0541', 'E0724')
    'R_HMR_3101'.('E0102', 'E2153')
    'R_HMR_3102'.('E0131', 'E1647')
    'R_HMR_3107'.('E0123', 'E0128', 'E1646', 'E1648')
    'R_HMR_3108'.('E0721', 'E1716')
    'R_HMR_3109'.('E0974', 'E1716')
    'R_HMR_3110'.('E0098', 'E0099', 'E1716')
    'R_HMR_3111'.('E0123', 'E0128', 'E1646', 'E1648')
    'R_HMR_3112'.('E0721', 'E1716')
    'R_HMR_3113'.('E0974', 'E1716')
    'R_HMR_3114'.('E0098', 'E0099', 'E1716')
    'R_HMR_3115'.('E0123', 'E0128', 'E1646', 'E1648')
    'R_HMR_3116'.('E0721', 'E1716')
    'R_HMR_3117'.('E0974', 'E1716')
    'R_HMR_3118'.('E0098', 'E0099', 'E1716')
    'R_HMR_3121'.('E0123', 'E0128', 'E1646', 'E1648')
    'R_HMR_3128'.('E0123', 'E0128', 'E1646', 'E1648')
    'R_HMR_3135'.('E0123', 'E0128', 'E1646', 'E1648')
    'R_HMR_3142'.('E0123', 'E0128')
    'R_HMR_3149'.('E0123', 'E0128')
    'R_HMR_3170'.('E0123', 'E0128', 'E1646', 'E1648')
    'R_HMR_3171'.('E0721', 'E1716')
    'R_HMR_3172'.('E0974', 'E1716')
    'R_HMR_3173'.('E0098', 'E0099', 'E1716')
    'R_HMR_3174'.('E0123', 'E0128', 'E1646', 'E1648')
    'R_HMR_3175'.('E0721', 'E1716')
    'R_HMR_3176'.('E0974', 'E1716')
    'R_HMR_3177'.('E0098', 'E0099', 'E1716')
    'R_HMR_3178'.('E0123', 'E0128', 'E1646', 'E1648')
    'R_HMR_3179'.('E0721', 'E1716')
    'R_HMR_3180'.('E0974', 'E1716')
    'R_HMR_3181'.('E0098', 'E0099', 'E1716')
    'R_HMR_3182'.('E0123', 'E0128', 'E1646', 'E1648')
    'R_HMR_3183'.('E0721', 'E1716')
    'R_HMR_3184'.('E0974', 'E1716')
    'R_HMR_3185'.('E0098', 'E0099', 'E1716')
    'R_HMR_3186'.('E0123', 'E0128', 'E1646', 'E1648')
    'R_HMR_3187'.('E0721', 'E1716')
    'R_HMR_3188'.('E0974', 'E1716')
    'R_HMR_3189'.('E0098', 'E0099', 'E1716')
    'R_HMR_3190'.('E0123', 'E0128')
    'R_HMR_3191'.('E0721', 'E1716')
    'R_HMR_3192'.('E0974', 'E1716')
    'R_HMR_3193'.('E0098', 'E0099', 'E1716')
    'R_HMR_3194'.('E0123', 'E0128')
    'R_HMR_3195'.('E0721', 'E1716')
    'R_HMR_3196'.('E0974', 'E1716')
    'R_HMR_3197'.('E0098', 'E0099', 'E1716')
    'R_HMR_3198'.('E0123', 'E0128')
    'R_HMR_3199'.('E0721', 'E1716')
    'R_HMR_3200'.('E0974', 'E1716')
    'R_HMR_3201'.('E0098', 'E0099', 'E1716')
    'R_HMR_3203'.('E0721', 'E1716')
    'R_HMR_3204'.('E0974', 'E1716')
    'R_HMR_3205'.('E0098', 'E0099', 'E1716')
    'R_HMR_3218'.('E0123', 'E0128', 'E1646', 'E1648')
    'R_HMR_3219'.('E0721', 'E1716')
    'R_HMR_3220'.('E0974', 'E1716')
    'R_HMR_3221'.('E0098', 'E0099', 'E1716')
    'R_HMR_3222'.('E0123', 'E0128', 'E1646', 'E1648')
    'R_HMR_3223'.('E0721', 'E1716')
    'R_HMR_3224'.('E0974', 'E1716')
    'R_HMR_3225'.('E0098', 'E0099', 'E1716')
    'R_HMR_3229'.('E0098', 'E0099', 'E1716')
    'R_HMR_3230'.('E0123', 'E0128', 'E1646', 'E1648')
    'R_HMR_3231'.('E0721', 'E1716')
    'R_HMR_3232'.('E0974', 'E1716')
    'R_HMR_3233'.('E0098', 'E0099', 'E1716')
    'R_HMR_3234'.('E0123', 'E0128', 'E1646', 'E1648')
    'R_HMR_3235'.('E0721', 'E1716')
    'R_HMR_3236'.('E0974', 'E1716')
    'R_HMR_3237'.('E0098', 'E0099', 'E1716')
    'R_HMR_3240'.('E0123', 'E0128', 'E1646', 'E1648')
    'R_HMR_3241'.('E0721', 'E1716')
    'R_HMR_3242'.('E0974', 'E1716')
    'R_HMR_3243'.('E0098', 'E0099', 'E1716')
    'R_HMR_3244'.('E0123', 'E0128', 'E1646', 'E1648')
    'R_HMR_3245'.('E0721', 'E1716')
    'R_HMR_3246'.('E0974', 'E1716')
    'R_HMR_3247'.('E0098', 'E0099', 'E1716')
    'R_HMR_3296'.('E1748', 'E1749')
    'R_HMR_3321'.('E0131', 'E1647')
    'R_HMR_3322'.('E1748', 'E1749')
    'R_HMR_3326'.('E0131', 'E1647')
    'R_HMR_3328'.('E0541', 'E0724')
    'R_HMR_3329'.('E0102', 'E2153')
    'R_HMR_3330'.('E0131', 'E1647')
    'R_HMR_3332'.('E0541', 'E0724')
    'R_HMR_3333'.('E0102', 'E2153')
    'R_HMR_3334'.('E0131', 'E1647')
    'R_HMR_3336'.('E0541', 'E0724')
    'R_HMR_3337'.('E0102', 'E2153')
    'R_HMR_3338'.('E0131', 'E1647')
    'R_HMR_3340'.('E0541', 'E0724')
    'R_HMR_3341'.('E0102', 'E2153')
    'R_HMR_3342'.('E0131', 'E1647')
    'R_HMR_3344'.('E0541', 'E0724')
    'R_HMR_3345'.('E0102', 'E2153')
    'R_HMR_3346'.('E0131', 'E1647')
    'R_HMR_3348'.('E0541', 'E0724')
    'R_HMR_3349'.('E0102', 'E2153')
    'R_HMR_3350'.('E0131', 'E1647')
    'R_HMR_3352'.('E0541', 'E0724')
    'R_HMR_3353'.('E0102', 'E2153')
    'R_HMR_3398'.('E0098', 'E0099', 'E0102', 'E0123', 'E0128', 'E0721',
                'E0974', 'E1646', 'E1648', 'E1716')
    'R_HMR_3406'.('E0098', 'E0099', 'E0102', 'E0123', 'E0128', 'E0721',
                'E0974', 'E1646', 'E1648', 'E1716')
    'R_HMR_3407'.('E0098', 'E0099', 'E0102', 'E0123', 'E0128', 'E0721',
                'E0974', 'E1646', 'E1648', 'E1716')
    'R_HMR_3408'.('E0098', 'E0099', 'E0102', 'E0123', 'E0128', 'E0721',
                'E0974', 'E1646', 'E1648', 'E1716')
    'R_HMR_3409'.('E0098', 'E0099', 'E0102', 'E0123', 'E0128', 'E0721',
                'E0974', 'E1646', 'E1648', 'E1716')
    'R_HMR_3411'.('E0098', 'E0099', 'E0102', 'E0123', 'E0128', 'E0721',
                'E0974', 'E1646', 'E1648', 'E1716')
    'R_HMR_3413'.('E0098', 'E0099', 'E0102', 'E0123', 'E0128', 'E0721',
                'E0974', 'E1646', 'E1648', 'E1716')
    'R_HMR_3414'.('E0098', 'E0099', 'E0102', 'E0123', 'E0128', 'E0721',
                'E0974', 'E1646', 'E1648', 'E1716')
    'R_HMR_3416'.('E0098', 'E0099', 'E0102', 'E0123', 'E0128', 'E0721',
                'E0974', 'E1646', 'E1648', 'E1716')
    'R_HMR_3421'.('E0098', 'E0099', 'E0102', 'E0123', 'E0128', 'E0721',
                'E0974', 'E1646', 'E1648', 'E1716')
    'R_HMR_3422'.('E0098', 'E0099', 'E0102', 'E0123', 'E0128', 'E0721',
                'E0974', 'E1646', 'E1648', 'E1716')
    'R_HMR_3423'.('E0098', 'E0099', 'E0102', 'E0123', 'E0128', 'E0721',
                'E0974', 'E1646', 'E1648', 'E1716')
    'R_HMR_3424'.('E0098', 'E0099', 'E0102', 'E0123', 'E0128', 'E0721',
                'E0974', 'E1646', 'E1648', 'E1716')
    'R_HMR_3425'.('E0098', 'E0099', 'E0102', 'E0123', 'E0128', 'E0721',
                'E0974', 'E1646', 'E1648', 'E1716')
    'R_HMR_3426'.('E0098', 'E0099', 'E0102', 'E0123', 'E0128', 'E0721',
                'E0974', 'E1646', 'E1648', 'E1716')
    'R_HMR_3427'.('E0098', 'E0099', 'E0102', 'E0123', 'E0128', 'E0721',
                'E0974', 'E1646', 'E1648', 'E1716')
    'R_HMR_3428'.('E0098', 'E0099', 'E0102', 'E0123', 'E0128', 'E0721',
                'E0974', 'E1646', 'E1648', 'E1716')
    'R_HMR_3429'.('E0098', 'E0099', 'E0102', 'E0123', 'E0128', 'E0721',
                'E0974', 'E1646', 'E1648', 'E1716')
    'R_HMR_3431'.('E0098', 'E0099', 'E0102', 'E0123', 'E0128', 'E0721',
                'E0974', 'E1646', 'E1648', 'E1716')
    'R_HMR_3432'.('E0098', 'E0099', 'E0102', 'E0123', 'E0128', 'E0721',
                'E0974', 'E1646', 'E1648', 'E1716')
    'R_HMR_3433'.('E0098', 'E0099', 'E0102', 'E0123', 'E0128', 'E0721',
                'E0974', 'E1646', 'E1648', 'E1716')
    'R_HMR_3446'.('E1748', 'E1749')
    'R_HMR_3447'.('E0667', 'E0668', 'E0723')
    'R_HMR_3448'.('E0123', 'E0128', 'E1646', 'E1648')
    'R_HMR_3449'.('E0721', 'E1716')
    'R_HMR_3450'.('E0974', 'E1716')
    'R_HMR_3451'.('E0098', 'E0099', 'E1716')
    'R_HMR_3452'.('E0123', 'E0128', 'E1646', 'E1648')
    'R_HMR_3453'.('E0721', 'E1716')
    'R_HMR_3454'.('E0974', 'E1716')
    'R_HMR_3455'.('E0098', 'E0099', 'E1716')
    'R_HMR_3456'.('E0123', 'E0128', 'E1646', 'E1648')
    'R_HMR_3457'.('E1748', 'E1749')
    'R_HMR_3505'.('E0102', 'E1483')
    'R_HMR_3522'.('E0123', 'E1648')
    'R_HMR_3625'.('E1507', 'E1689')
    'R_HMR_3626'.('E1507', 'E1689')
    'R_HMR_3627'.('E1507', 'E1689')
    'R_HMR_3628'.('E1507', 'E1689')
    'R_HMR_3629'.('E1507', 'E1689')
    'R_HMR_3630'.('E1507', 'E1689')
    'R_HMR_3631'.('E1507', 'E1689')
    'R_HMR_3633'.('E1507', 'E1689')
    'R_HMR_3635'.('E1507', 'E1689')
    'R_HMR_3636'.('E1507', 'E1689')
    'R_HMR_3637'.('E1507', 'E1689')
    'R_HMR_3639'.('E1507', 'E1689')
    'R_HMR_3640'.('E1507', 'E1689')
    'R_HMR_3642'.('E1507', 'E1689')
    'R_HMR_3644'.('E1507', 'E1689')
    'R_HMR_3645'.('E1507', 'E1689')
    'R_HMR_3646'.('E1507', 'E1689')
    'R_HMR_3647'.('E1507', 'E1689')
    'R_HMR_3648'.('E1507', 'E1689')
    'R_HMR_3649'.('E1507', 'E1689')
    'R_HMR_3650'.('E1507', 'E1689')
    'R_HMR_3651'.('E1507', 'E1689')
    'R_HMR_3652'.('E1507', 'E1689')
    'R_HMR_3653'.('E1507', 'E1689')
    'R_HMR_3654'.('E1507', 'E1689')
    'R_HMR_3655'.('E1507', 'E1689')
    'R_HMR_3656'.('E1507', 'E1689')
    'R_HMR_3657'.('E1507', 'E1689')
    'R_HMR_3658'.('E1507', 'E1689')
    'R_HMR_3659'.('E1507', 'E1689')
    'R_HMR_3660'.('E1507', 'E1689')
    'R_HMR_3662'.('E1507', 'E1689')
    'R_HMR_3663'.('E1507', 'E1689')
    'R_HMR_3664'.('E1507', 'E1689')
    'R_HMR_3665'.('E1507', 'E1689')
    'R_HMR_3666'.('E1507', 'E1689')
    'R_HMR_3667'.('E1507', 'E1689')
    'R_HMR_3668'.('E1507', 'E1689')
    'R_HMR_3669'.('E1507', 'E1689')
    'R_HMR_3670'.('E1507', 'E1689')
    'R_HMR_3677'.('E1507', 'E1689')
    'R_HMR_3678'.('E1507', 'E1689')
    'R_HMR_3679'.('E1507', 'E1689')
    'R_HMR_3680'.('E1507', 'E1689')
    'R_HMR_3681'.('E1507', 'E1689')
    'R_HMR_3682'.('E1507', 'E1689')
    'R_HMR_3684'.('E1067', 'E1690')
    'R_HMR_3685'.('E1067', 'E1690')
    'R_HMR_3686'.('E1067', 'E1690')
    'R_HMR_3687'.('E1067', 'E1690')
    'R_HMR_3688'.('E1067', 'E1690')
    'R_HMR_3689'.('E1067', 'E1690')
    'R_HMR_3690'.('E1067', 'E1690')
    'R_HMR_3692'.('E1067', 'E1690')
    'R_HMR_3694'.('E1067', 'E1690')
    'R_HMR_3695'.('E1067', 'E1690')
    'R_HMR_3696'.('E1067', 'E1690')
    'R_HMR_3698'.('E1067', 'E1690')
    'R_HMR_3699'.('E1067', 'E1690')
    'R_HMR_3701'.('E1067', 'E1690')
    'R_HMR_3703'.('E1067', 'E1690')
    'R_HMR_3704'.('E1067', 'E1690')
    'R_HMR_3705'.('E1067', 'E1690')
    'R_HMR_3706'.('E1067', 'E1690')
    'R_HMR_3707'.('E1067', 'E1690')
    'R_HMR_3708'.('E1067', 'E1690')
    'R_HMR_3709'.('E1067', 'E1690')
    'R_HMR_3710'.('E1067', 'E1690')
    'R_HMR_3711'.('E1067', 'E1690')
    'R_HMR_3712'.('E1067', 'E1690')
    'R_HMR_3713'.('E1067', 'E1690')
    'R_HMR_3714'.('E1067', 'E1690')
    'R_HMR_3715'.('E1067', 'E1690')
    'R_HMR_3716'.('E1067', 'E1690')
    'R_HMR_3717'.('E1067', 'E1690')
    'R_HMR_3718'.('E1067', 'E1690')
    'R_HMR_3719'.('E1067', 'E1690')
    'R_HMR_3721'.('E1067', 'E1690')
    'R_HMR_3722'.('E1067', 'E1690')
    'R_HMR_3723'.('E1067', 'E1690')
    'R_HMR_3724'.('E1067', 'E1690')
    'R_HMR_3725'.('E1067', 'E1690')
    'R_HMR_3726'.('E1067', 'E1690')
    'R_HMR_3727'.('E1067', 'E1690')
    'R_HMR_3728'.('E1067', 'E1690')
    'R_HMR_3729'.('E1067', 'E1690')
    'R_HMR_3736'.('E1067', 'E1690')
    'R_HMR_3737'.('E1067', 'E1690')
    'R_HMR_3738'.('E1067', 'E1690')
    'R_HMR_3739'.('E1067', 'E1690')
    'R_HMR_3740'.('E1067', 'E1690')
    'R_HMR_3741'.('E1067', 'E1690')
    'R_HMR_3855'.('E0262', 'E2178')
    'R_HMR_3859'.('E1010', 'E1057')
    'R_HMR_4079'.('E0250', 'E0252', 'E0253', 'E0255', 'E0256')
    'R_HMR_4270'.('E0120', 'E0137', 'E0140', 'E2185')
    'R_HMR_4592'.('E0262', 'E2178')
    'R_HMR_5301'.('E0643', 'E1593')
    'R_HMR_5996'.('E0216', 'E1705')
    'R_HMR_6534'.('E1198', 'E1499')
    'R_HMR_6545'.('E1103', 'E1185', 'E1187', 'E1481', 'E1757', 'E1989',
                'E2200')
    'R_HMR_6550'.('E1324', 'E1724')
    'R_HMR_6558'.('E1324', 'E1724')
    'R_HMR_6595'.('E1326', 'E2221')
    'R_HMR_6632'.('E1433', 'E1435', 'E1439', 'E2222')
    'R_HMR_6633'.('E0028', 'E0033', 'E0034', 'E0242', 'E1431', 'E1437',
                'E2159')
    'R_HMR_6647'.('E0248', 'E0251')
    'R_HMR_6747'.('E0053', 'E0054')
    'R_HMR_6755'.('E0036', 'E2224')
    'R_HMR_6790'.('E0039', 'E0040', 'E0041')
    'R_HMR_6826'.('E2225', 'E2226')
    'R_HMR_6838'.('E0008', 'E2228')
    'R_HMR_6844'.('E0008', 'E2228')
    'R_HMR_6850'.('E0008', 'E2228')
    'R_HMR_6975'.('E2231', 'E2232')
    'R_HMR_6976'.('E2231', 'E2232')
    'R_HMR_6977'.('E2231', 'E2232')
    'R_HMR_7652'.('E1388', 'E1395', 'E2266')
    'R_HMR_8271'.('E0793', 'E2140')
    'R_HMR_8475'.('E0148', 'E0170')
    'R_HMR_8476'.('E0148', 'E0170')
    'R_HMR_8570'.('E0275', 'E1721')
    'R_HMR_8571'.('E0275', 'E1721')
    'R_HMR_8572'.('E0275', 'E1721')
    'R_HMR_8573'.('E0275', 'E1721')
    'R_HMR_8574'.('E0275', 'E1721')
    'R_HMR_8575'.('E0275', 'E1721')
    'R_HMR_8576'.('E0275', 'E1721')
    'R_HMR_8577'.('E0275', 'E1721')
    'R_HMR_8578'.('E0275', 'E1721')
    'R_HMR_8579'.('E0275', 'E1721')
    'R_HMR_8580'.('E0275', 'E1721')
    'R_HMR_8582'.('E0275', 'E1721')
    'R_HMR_8643'.('E0618', 'E2273')
    'R_HMR_8762'.('E0762', 'E0764')
    'R_HMR_9191'.('E0274', 'E2276')
    'R_HMR_9593'.('E0230', 'E0921')
    'R_HMR_9623'.('E1812', 'E1823')
    'R_HMR_9624'.('E1812', 'E1823')
    'R_HMR_9719'.('E0098', 'E0099', 'E0102', 'E0123', 'E0128', 'E0721',
                'E0974', 'E1646', 'E1648', 'E1716')
    'R_HMR_2957'.('E0725', 'E0736', 'E0737', 'E0738', 'E0740', 'E0741',
                'E0742', 'E1416', 'E1420', 'E1770')
    'R_HMR_1484'.('E0539', 'E2152')
    'R_HMR_0980'.('E0562', 'E1751')
    'R_12DHCHOLabc'.('E0528', 'E0529', 'E0584', 'E0585', 'E0728')
    'R_12DHCHOLt'.('E0527', 'E0530', 'E2300')
    'R_12DHCHOLt2'.('E0582', 'E0583')
    'R_3DHCDCHOLabc'.('E0528', 'E0529', 'E0584', 'E0585', 'E0728')
    'R_3DHCDCHOLt'.('E0527', 'E0530', 'E2300')
    'R_3DHCDCHOLt2'.('E0582', 'E0583')
    'R_3DHCHOLabc'.('E0528', 'E0529', 'E0584', 'E0585', 'E0728')
    'R_3DHCHOLt'.('E0527', 'E0530', 'E2300')
    'R_3DHCHOLt2'.('E0582', 'E0583')
    'R_3DHDCAabc'.('E0528', 'E0529', 'E0584', 'E0585')
    'R_3DHDCAt'.('E0527', 'E0530', 'E2300')
    'R_3DHDCAt2'.('E0582', 'E0583')
    'R_3DHLCAabc'.('E0528', 'E0529', 'E0584', 'E0585')
    'R_3DHLCAt'.('E0527', 'E0530', 'E2300')
    'R_3DHLCAt2'.('E0582', 'E0583')
    'R_7DHCDCHOLabc'.('E0528', 'E0529', 'E0584', 'E0585', 'E0728')
    'R_7DHCDCHOLt'.('E0527', 'E0530', 'E2300')
    'R_7DHCDCHOLt2'.('E0582', 'E0583')
    'R_7DHCHOLabc'.('E0528', 'E0529', 'E0584', 'E0585', 'E0728')
    'R_7DHCHOLt'.('E0527', 'E0530', 'E2300')
    'R_7DHCHOLt2'.('E0582', 'E0583')
    'R_CDCA24GSc'.('E1583', 'E2302')
    'R_CDCA24GSr'.('E1583', 'E2302')
    'R_CDCA24Gte'.('E0528', 'E0529', 'E0584', 'E0585', 'E1822')
    'R_CDCA3GSc'.('E1586', 'E2302')
    'R_CDCA3GSr'.('E1586', 'E2302')
    'R_CDCA3Gte'.('E0528', 'E0529', 'E0584', 'E0585', 'E1822')
    'R_COPROSTabc'.('E0528', 'E0529', 'E0584', 'E0585', 'E0728')
    'R_COPROSTt'.('E0527', 'E0530', 'E2300')
    'R_COPROSTt2'.('E0582', 'E0583')
    'R_HCA24GSc'.('E1586', 'E2302')
    'R_HCA24GSr'.('E1586', 'E2302')
    'R_HCA24Gte'.('E0528', 'E0529', 'E0584', 'E0585', 'E1822')
    'R_HDCA24GSc'.('E1583', 'E2302')
    'R_HDCA24GSr'.('E1583', 'E2302')
    'R_HDCA24Gte'.('E0528', 'E0529', 'E0584', 'E0585', 'E1822')
    'R_HDCA6GSc'.('E1586', 'E1590', 'E2302')
    'R_HDCA6GSr'.('E1586', 'E1590', 'E2302')
    'R_HDCA6Gte'.('E0528', 'E0529', 'E0584', 'E0585', 'E1822')
    'R_HYOCHOLabc'.('E0528', 'E0529', 'E0584', 'E0585')
    'R_HYOCHOLt'.('E0527', 'E0530', 'E2300')
    'R_HYOCHOLt2'.('E0582', 'E0583')
    'R_ICDCHOLabc'.('E0528', 'E0529', 'E0584', 'E0585', 'E0728')
    'R_ICDCHOLt'.('E0527', 'E0530', 'E2300')
    'R_ICDCHOLt2'.('E0582', 'E0583')
    'R_ISOCHOLabc'.('E0528', 'E0529', 'E0584', 'E0585', 'E0728')
    'R_ISOCHOLt'.('E0527', 'E0530', 'E2300')
    'R_ISOCHOLt2'.('E0582', 'E0583')
    'R_LCA24GSc'.('E1583', 'E1586', 'E2302')
    'R_LCA24GSr'.('E1583', 'E1586', 'E2302')
    'R_LCA24Gte'.('E0528', 'E0529', 'E0584', 'E0585', 'E1822')
    'R_LCA3GSc'.('E1586', 'E2302')
    'R_LCA3GSr'.('E1586', 'E2302')
    'R_LCA3Gte'.('E0528', 'E0529', 'E0584', 'E0585', 'E1822')
    'R_THYOCHOLabc'.('E0528', 'E0529', 'E0584', 'E0585')
    'R_THYOCHOLt'.('E0527', 'E0530', 'E2300')
    'R_THYOCHOLt2'.('E0582', 'E0583')
    'R_UCHOLabc'.('E0528', 'E0529', 'E0584', 'E0585', 'E0728')
    'R_UCHOLt'.('E0527', 'E0530', 'E2300')
    'R_UCHOLt2'.('E0582', 'E0583')
    'R_UDCHOLt'.('E0527', 'E0530', 'E2300')
    'R_UDCHOLt2'.('E0582', 'E0583')
    'R_12HTACRhr'.('E1209', 'E1224')
    'R_14HMDZALThr'.('E1209', 'E1224')
    'R_14HMDZhr'.('E1209', 'E1224')
    'R_1HIBUP_SGLUhep'.('E1581', 'E1583', 'E1586')
    'R_1HMDGLUChr'.('E1585', 'E1586', 'E1590')
    'R_1OHMDZhr'.('E1209', 'E1224')
    'R_2HATVACIDOXDhc'.('E1209', 'E1215', 'E1224')
    'R_2HATVLACGLUChr'.('E1583', 'E1585')
    'R_2HATVLACGLUCteb'.('E0528', 'E2024')
    'R_2HATVLACOXDhc'.('E1209', 'E1224')
    'R_2HIBUP_SGLUhep'.('E1581', 'E1583', 'E1586')
    'R_35DSMVhep'.('E1209', 'E1215', 'E1218', 'E1224')
    'R_3HIBUP_SGLUhep'.('E1581', 'E1583', 'E1586')
    'R_3HPVSTETCOAhcm'.('E0098', 'E1646', 'E1716')
    'R_3HPVSTETCOAhcx'.('E0102', 'E0131', 'E0541', 'E0724')
    'R_3HPVSTETteb'.('E0528', 'E0585', 'E1822')
    'R_3HPVShc'.('E1209', 'E1228')
    'R_3HPVSteb'.('E0528', 'E0585', 'E1822')
    'R_3HSMVhep'.('E1209', 'E1215', 'E1218', 'E1224')
    'R_3ISPVSteb'.('E0528', 'E0585', 'E1822')
    'R_3OHACMPhr'.('E0146', 'E1213')
    'R_4HATVACIDOXDhc'.('E1209', 'E1215', 'E1224')
    'R_4HATVLACOXDhc'.('E1209', 'E1224')
    'R_4HMDZGLUChr'.('E1585', 'E1586', 'E1590')
    'R_4OHMDZhr'.('E1209', 'E1224')
    'R_56DHPVSteb'.('E0528', 'E0585', 'E1822')
    'R_56EPPVSteb'.('E0528', 'E0585', 'E1822')
    'R_5OHFVShc'.('E1209', 'E1215', 'E1217', 'E1218')
    'R_6BHGLZhr'.('E1092', 'E1215', 'E1217', 'E1218')
    'R_6CSMVhep'.('E1209', 'E1215', 'E1218', 'E1224')
    'R_6EPSteb'.('E0528', 'E0585', 'E1822')
    'R_6HMSMVhep'.('E1209', 'E1215', 'E1218', 'E1224')
    'R_6HSMVhep'.('E1209', 'E1215', 'E1218', 'E1224')
    'R_6MSMVhep'.('E1209', 'E1215', 'E1218', 'E1224')
    'R_7BHGLZhr'.('E1092', 'E1215', 'E1217')
    'R_7HPVSteb'.('E0528', 'E0585', 'E1822')
    'R_AM19CSALThr'.('E1209', 'E1224')
    'R_AM1CSAhr'.('E1209', 'E1224')
    'R_AM9CSAhr'.('E1209', 'E1224')
    'R_ATVACYLGLUChc'.('E1577', 'E1582', 'E1583', 'E1585', 'E1586')
    'R_ATVETHGLUChc'.('E1581', 'E1583', 'E1585')
    'R_ATVLACGLCURhc'.('E1577', 'E1582', 'E1583', 'E1585', 'E1586')
    'R_CARIBUP_SGLUhep'.('E1581', 'E1583', 'E1586')
    'R_CRVS1M24hc'.('E1209', 'E1215')
    'R_CRVS23M24hc'.('E1209', 'E1215')
    'R_CRVSM1hc'.('E1209', 'E1215')
    'R_DEOXFVShc'.('E0102', 'E0131', 'E0541', 'E0724')
    'R_DSPVSteb'.('E0528', 'E0585', 'E1822')
    'R_GLC3MEACPhr'.('E1579', 'E1581', 'E1582')
    'R_IBUPGT_HEP'.('E1581', 'E1583', 'E1586')
    'R_IBUP_RCYP2hep'.('E1092', 'E1209', 'E1215', 'E1217')
    'R_IBUP_RCYP3hep'.('E1092', 'E1209', 'E1215', 'E1217')
    'R_IBUP_SCYP2hep'.('E1092', 'E1209', 'E1215', 'E1217')
    'R_IBUP_SCYP3hep'.('E1092', 'E1209', 'E1215', 'E1217')
    'R_LSTNM7hr'.('E1577', 'E1578', 'E1581', 'E1582', 'E1583', 'E1585',
                'E1586', 'E1588')
    'R_LVSTACOXD6Hhep'.('E1209', 'E1215', 'E1224')
    'R_LVSTACOXD6MEhep'.('E1209', 'E1215', 'E1224')
    'R_LVSTOXD3Hhep'.('E1209', 'E1215', 'E1224')
    'R_LVSTOXD6Hhep'.('E1209', 'E1215', 'E1224')
    'R_LVSTOXD6METhep'.('E1209', 'E1215', 'E1224')
    'R_NFDACOXDhc'.('E1209', 'E1224')
    'R_PROFVSCOAhc'.('E0102', 'E0131', 'E0541', 'E0724', 'E1217')
    'R_PTVSTGLUChc'.('E1579', 'E1582', 'E1583', 'E1585', 'E1586')
    'R_PTVSTM13hr'.('E1215', 'E1217')
    'R_PVSGLUCteb'.('E0528', 'E0585', 'E1822')
    'R_TRIPVSteb'.('E0528', 'E0585', 'E1822')
    'R_Htmi'.('E2026', 'E2307')
    'R_Abeta_N6_methyl_L_lysine'.('E2231', 'E2492')
    'R_Abeta_N6_dimethyl_L_lysine'.('E2231', 'E2492')
    'R_Abeta_N6_N6_trimethyl_L_lysine'.('E2231', 'E2492')
    'R_Tau_N6_methyl_L_lysine'.('E2231', 'E2492')
    'R_Tau_N6_dimethyl_L_lysine'.('E2231', 'E2492')
    'R_Tau_N6_N6_trimethyl_L_lysine'.('E2231', 'E2492')
    'R_TNFA_N6_methyl_L_lysine'.('E2231', 'E2492')
    'R_TNFA_N6_dimethyl_L_lysine'.('E2231', 'E2492')
    'R_TNFA_N6_N6_trimethyl_L_lysine'.('E2231', 'E2492')
    'R_IL6_N6_methyl_L_lysine'.('E2231', 'E2492')
    'R_IL6_N6_dimethyl_L_lysine'.('E2231', 'E2492')
    'R_IL6_N6_N6_trimethyl_L_lysine'.('E2231', 'E2492')
   /

  enzyme_gene(enzymes, genes) "the enzyme and gene association, AND operon: >= 2 genes"
   /
    'E0001'. ('8639.1')
    'E0002'. ('26.1')
    'E0003'. ('314.2')
    'E0004'. ('314.1')
    'E0006'. ('1594.1')
    'E0007'. ('10993.1')
    'E0008'. ('6818.1')
    'E0009'. ('89874.1')
    'E0010'. ('92483.1')
    'E0011'. ('3948.2')
    'E0012'. ('55293.1')
    'E0013'. ('3945.1', '3939.1')
    'E0014'. ('3939.1')
    'E0015'. ('160287.1')
    'E0016'. ('3945.1')
    'E0017'. ('3948.1')
    'E0018'. ('9123.1')
    'E0019'. ('9194.1')
    'E0020'. ('6566.1')
    'E0026'. ('4967.2', '1738.1', '8050.1', '1743.1')
    'E0027'. ('1738.1', '8050.1', '1743.1', '4967.1')
    'E0028'. ('130.1')
    'E0029'. ('127.1')
    'E0030'. ('125.1', '124.1')
    'E0031'. ('131.1')
    'E0032'. ('124.1', '126.1')
    'E0033'. ('128.1')
    'E0034'. ('137872.1')
    'E0035'. ('125.1', '126.1')
    'E0036'. ('1312.1')
    'E0037'. ('1312.2')
    'E0038'. ('117247.1')
    'E0039'. ('218.1')
    'E0040'. ('222.1')
    'E0041'. ('220.1')
    'E0042'. ('221.1')
    'E0043'. ('3242.1')
    'E0044'. ('18.1')
    'E0045'. ('18.2')
    'E0047'. ('23498.1')
    'E0048'. ('55268.1')
    'E0049'. ('51166.1')
    'E0050'. ('883.1')
    'E0051'. ('51166.2')
    'E0052'. ('1644.1')
    'E0053'. ('4128.1')
    'E0054'. ('4129.1')
    'E0055'. ('10165.1')
    'E0056'. ('8604.1')
    'E0057'. ('51380.1')
    'E0058'. ('2571.1')
    'E0059'. ('2572.1')
    'E0060'. ('2571.2')
    'E0063'. ('8659.1')
    'E0064'. ('8659.2')
    'E0065'. ('6799.1')
    'E0066'. ('6817.3')
    'E0067'. ('6799.2')
    'E0068'. ('6818.2')
    'E0069'. ('6817.2')
    'E0070'. ('6817.4')
    'E0071'. ('6817.1')
    'E0072'. ('6818.3')
    'E0073'. ('6817.5')
    'E0074'. ('4363.1')
    'E0075'. ('6822.1')
    'E0076'. ('6573.1')
    'E0077'. ('6573.2')
    'E0079'. ('6570.1')
    'E0080'. ('6571.1')
    'E0081'. ('2348.5')
    'E0082'. ('2348.3')
    'E0083'. ('2348.1')
    'E0084'. ('2348.6')
    'E0085'. ('2352.1')
    'E0086'. ('2348.4')
    'E0087'. ('2348.2')
    'E0088'. ('4125.1')
    'E0089'. ('53947.1')
    'E0090'. ('51146.1')
    'E0091'. ('28.1')
    'E0092'. ('206358.1')
    'E0093'. ('6529.1')
    'E0094'. ('6538.1')
    'E0095'. ('6540.1')
    'E0096'. ('6539.1')
    'E0097'. ('38.1')
    'E0098'. ('3032.1')
    'E0099'. ('10449.1')
    'E0100'. ('3032.1', '3030.1')
    'E0101'. ('39.1')
    'E0102'. ('30.1')
    'E0103'. ('32.1')
    'E0104'. ('9197.1')
    'E0105'. ('84532.1')
    'E0106'. ('79611.1')
    'E0107'. ('64841.1')
    'E0108'. ('55577.1')
    'E0109'. ('5238.1')
    'E0110'. ('9487.1')
    'E0111'. ('162417.1')
    'E0112'. ('43.1')
    'E0114'. ('6572.1')
    'E0115'. ('47.1')
    'E0116'. ('47.2')
    'E0117'. ('54187.1')
    'E0118'. ('26503.1')
    'E0119'. ('140838.1')
    'E0120'. ('54.1')
    'E0121'. ('51205.1')
    'E0122'. ('36.1')
    'E0123'. ('34.1')
    'E0124'. ('80724.1')
    'E0125'. ('35.1')
    'E0126'. ('84129.1')
    'E0127'. ('27034.1')
    'E0128'. ('28976.1')
    'E0129'. ('3712.1')
    'E0131'. ('51.1')
    'E0132'. ('51.2')
    'E0134'. ('50.1')
    'E0135'. ('48.1')
    'E0136'. ('8309.1')
    'E0137'. ('52.1')
    'E0138'. ('52.3')
    'E0139'. ('52.2')
    'E0140'. ('55.1')
    'E0141'. ('788.1')
    'E0142'. ('55902.1')
    'E0143'. ('65985.1')
    'E0144'. ('55902.2')
    'E0146'. ('1571.1')
    'E0148'. ('3177.1')
    'E0149'. ('205.3')
    'E0150'. ('205.1')
    'E0151'. ('204.1')
    'E0152'. ('204.3')
    'E0153'. ('204.2')
    'E0154'. ('205.2')
    'E0155'. ('26289.1')
    'E0156'. ('26289.2')
    'E0159'. ('112.1')
    'E0160'. ('55811.1')
    'E0161'. ('109.1')
    'E0162'. ('112.2')
    'E0163'. ('114.1')
    'E0164'. ('108.1')
    'E0165'. ('113.1')
    'E0166'. ('107.1')
    'E0167'. ('196883.1')
    'E0168'. ('115.1')
    'E0169'. ('111.1')
    'E0170'. ('2030.1')
    'E0171'. ('9154.2')
    'E0172'. ('9154.1')
    'E0173'. ('64078.1')
    'E0174'. ('9153.1')
    'E0175'. ('55315.1')
    'E0176'. ('11164.1')
    'E0177'. ('952.1')
    'E0178'. ('1375.1')
    'E0179'. ('1375.3')
    'E0180'. ('1375.4')
    'E0181'. ('126129.1')
    'E0182'. ('1374.1')
    'E0183'. ('1375.2')
    'E0184'. ('1376.1')
    'E0185'. ('9060.1')
    'E0186'. ('9061.1')
    'E0187'. ('158.1')
    'E0188'. ('158.2')
    'E0189'. ('79369.1')
    'E0190'. ('10678.1')
    'E0191'. ('11041.1')
    'E0192'. ('146712.1')
    'E0193'. ('374907.1')
    'E0194'. ('93010.1')
    'E0195'. ('374907.2')
    'E0196'. ('10678.2')
    'E0197'. ('10331.1')
    'E0199'. ('10555.1')
    'E0201'. ('56895.1')
    'E0203'. ('56894.1')
    'E0204'. ('55326.1')
    'E0205'. ('10554.1')
    'E0206'. ('129642.1')
    'E0209'. ('189.1')
    'E0210'. ('3073.1')
    'E0211'. ('3074.1')
    'E0212'. ('3073.1', '3074.1')
    'E0213'. ('10606.1')
    'E0215'. ('1468.1')
    'E0216'. ('64849.1')
    'E0218'. ('1645.1')
    'E0219'. ('1109.1')
    'E0220'. ('6718.1')
    'E0221'. ('6510.1')
    'E0222'. ('6509.1')
    'E0223'. ('56301.1', '6520.1')
    'E0224'. ('212.1')
    'E0225'. ('23464.1')
    'E0226'. ('211.2')
    'E0227'. ('211.1')
    'E0228'. ('54407.1')
    'E0229'. ('6542.1')
    'E0230'. ('11254.1')
    'E0231'. ('6541.1')
    'E0232'. ('81539.1')
    'E0233'. ('55089.1')
    'E0234'. ('84889.1')
    'E0235'. ('340024.1', '57393.1')
    'E0236'. ('340024.1', '59272.1')
    'E0241'. ('284273.2')
    'E0242'. ('125.1')
    'E0243'. ('124.1')
    'E0244'. ('284273.1')
    'E0245'. ('126.1')
    'E0246'. ('10327.1')
    'E0247'. ('10327.2')
    'E0248'. ('216.1')
    'E0249'. ('8854.2')
    'E0250'. ('501.1')
    'E0251'. ('8854.1')
    'E0252'. ('223.1')
    'E0253'. ('224.1')
    'E0254'. ('8854.3')
    'E0255'. ('219.1')
    'E0256'. ('217.1')
    'E0257'. ('239.1')
    'E0258'. ('247.1')
    'E0259'. ('246.1')
    'E0260'. ('240.1')
    'E0261'. ('8574.1')
    'E0262'. ('231.1')
    'E0263'. ('23600.1')
    'E0264'. ('23600.2')
    'E0265'. ('115286.3')
    'E0266'. ('115286.2')
    'E0267'. ('115286.1')
    'E0268'. ('271.2')
    'E0269'. ('270.1')
    'E0270'. ('271.1')
    'E0271'. ('272.1')
    'E0272'. ('271.3')
    'E0273'. ('290.1')
    'E0274'. ('6520.1')
    'E0275'. ('280.1')
    'E0276'. ('278.1')
    'E0277'. ('276.1')
    'E0278'. ('277.1')
    'E0279'. ('6519.1', '11136.1')
    'E0280'. ('276.2')
    'E0281'. ('279.1')
    'E0282'. ('10998.1')
    'E0283'. ('113451.1')
    'E0284'. ('6520.1', '9057.1')
    'E0285'. ('384.1')
    'E0286'. ('445.1')
    'E0287'. ('445.2')
    'E0288'. ('83884.1')
    'E0289'. ('10166.1')
    'E0291'. ('427.1')
    'E0292'. ('427.2')
    'E0293'. ('9962.2')
    'E0294'. ('9963.1')
    'E0295'. ('9962.1')
    'E0296'. ('9963.2')
    'E0301'. ('790.1')
    'E0302'. ('6511.1')
    'E0303'. ('6505.1')
    'E0304'. ('6507.1')
    'E0305'. ('6506.1')
    'E0306'. ('6512.1')
    'E0495'. ('954.1')
    'E0496'. ('954.2')
    'E0497'. ('953.1')
    'E0498'. ('956.1')
    'E0499'. ('955.1')
    'E0500'. ('957.1')
    'E0501'. ('377841.1')
    'E0505'. ('4126.1')
    'E0506'. ('8706.4')
    'E0507'. ('8706.1')
    'E0508'. ('8706.3')
    'E0509'. ('8706.2')
    'E0510'. ('8705.1')
    'E0511'. ('10317.4')
    'E0512'. ('10317.1')
    'E0513'. ('10317.3')
    'E0514'. ('10317.2')
    'E0515'. ('10317.5')
    'E0516'. ('84002.1')
    'E0517'. ('570.1')
    'E0519'. ('140679.1')
    'E0521'. ('53630.1')
    'E0522'. ('622.2')
    'E0523'. ('622.3')
    'E0524'. ('622.1')
    'E0527'. ('10599.1')
    'E0528'. ('1244.1')
    'E0529'. ('8714.1')
    'E0530'. ('28234.1')
    'E0533'. ('9488.1')
    'E0534'. ('10380.1')
    'E0536'. ('8884.1')
    'E0537'. ('80704.1')
    'E0538'. ('51733.1')
    'E0539'. ('7108.1')
    'E0540'. ('50814.1')
    'E0541'. ('3295.1')
    'E0542'. ('6307.1')
    'E0547'. ('847.1')
    'E0548'. ('6547.6')
    'E0549'. ('6547.4')
    'E0550'. ('6547.2')
    'E0551'. ('6546.1')
    'E0552'. ('6547.1')
    'E0553'. ('6547.5')
    'E0554'. ('6543.1')
    'E0555'. ('6547.3')
    'E0556'. ('166785.1')
    'E0557'. ('2538.1')
    'E0558'. ('57818.1')
    'E0559'. ('92579.1')
    'E0562'. ('873.1')
    'E0563'. ('10423.1')
    'E0564'. ('10423.2')
    'E0565'. ('1040.1')
    'E0566'. ('8760.1')
    'E0567'. ('10390.1')
    'E0568'. ('56994.1')
    'E0569'. ('64781.1')
    'E0570'. ('64781.2')
    'E0571'. ('10087.1')
    'E0572'. ('6565.1')
    'E0573'. ('9023.1')
    'E0574'. ('1103.4')
    'E0575'. ('1103.2')
    'E0576'. ('1103.3')
    'E0577'. ('1103.1')
    'E0579'. ('5130.1')
    'E0580'. ('9468.1')
    'E0581'. ('6579.1')
    'E0582'. ('6554.1')
    'E0583'. ('6555.1')
    'E0584'. ('8714.3')
    'E0585'. ('8647.1')
    'E0586'. ('8714.2')
    'E0588'. ('1120.2')
    'E0589'. ('1119.1')
    'E0590'. ('1120.1')
    'E0591'. ('1119.2')
    'E0593'. ('6582.1')
    'E0594'. ('6584.1')
    'E0595'. ('6582.2')
    'E0596'. ('6820.1')
    'E0598'. ('19.1')
    'E0599'. ('27159.1')
    'E0600'. ('54682.1')
    'E0601'. ('1118.1')
    'E0602'. ('27159.2')
    'E0603'. ('9058.1')
    'E0604'. ('6576.1')
    'E0610'. ('5172.1')
    'E0611'. ('65010.1')
    'E0612'. ('65010.3')
    'E0613'. ('65010.2')
    'E0614'. ('54675.1')
    'E0615'. ('10559.1')
    'E0616'. ('55907.1')
    'E0617'. ('8034.1')
    'E0618'. ('8824.1')
    'E0619'. ('51805.1')
    'E0620'. ('51004.1')
    'E0621'. ('51004.2')
    'E0622'. ('10229.1')
    'E0623'. ('9245.1')
    'E0624'. ('2650.1')
    'E0625'. ('51301.1')
    'E0626'. ('192134.1')
    'E0627'. ('6535.1')
    'E0628'. ('386757.1')
    'E0629'. ('1384.1')
    'E0630'. ('6583.1')
    'E0631'. ('1431.1')
    'E0632'. ('1431.2')
    'E0633'. ('54677.1')
    'E0634'. ('1384.2')
    'E0636'. ('6520.1', '8140.1')
    'E0637'. ('6520.1', '23428.1')
    'E0640'. ('6520.1', '23657.1')
    'E0643'. ('7371.1')
    'E0644'. ('83549.1')
    'E0645'. ('51727.1')
    'E0646'. ('129607.1')
    'E0647'. ('9162.1')
    'E0648'. ('1607.1')
    'E0649'. ('8525.2')
    'E0650'. ('160851.1')
    'E0651'. ('1608.1')
    'E0652'. ('1607.2')
    'E0653'. ('8525.1')
    'E0654'. ('8527.1')
    'E0655'. ('1606.1')
    'E0656'. ('160851.2')
    'E0657'. ('8526.1')
    'E0658'. ('8525.3')
    'E0659'. ('8527.2')
    'E0660'. ('1609.1')
    'E0661'. ('1610.1')
    'E0662'. ('2745.1')
    'E0663'. ('51022.2')
    'E0664'. ('51022.1')
    'E0665'. ('8528.2')
    'E0666'. ('8528.1')
    'E0667'. ('1632.1')
    'E0668'. ('10455.1')
    'E0669'. ('1633.1')
    'E0671'. ('6319.1')
    'E0672'. ('9415.1')
    'E0673'. ('3992.1')
    'E0676'. ('1716.5')
    'E0677'. ('1716.1')
    'E0678'. ('1716.4')
    'E0679'. ('1716.2')
    'E0680'. ('1716.3')
    'E0681'. ('6515.1')
    'E0682'. ('6513.1')
    'E0683'. ('6517.1')
    'E0684'. ('1718.1')
    'E0685'. ('1581.1')
    'E0686'. ('1717.1')
    'E0687'. ('8560.1')
    'E0688'. ('8560.2')
    'E0689'. ('123099.1')
    'E0690'. ('11309.1')
    'E0691'. ('6783.1')
    'E0696'. ('23539.1')
    'E0697'. ('2224.1')
    'E0699'. ('60386.1')
    'E0701'. ('79087.1')
    'E0707'. ('6581.1')
    'E0708'. ('669.2')
    'E0709'. ('5223.1')
    'E0710'. ('5224.2')
    'E0711'. ('5224.1')
    'E0712'. ('669.1')
    'E0713'. ('4597.1')
    'E0714'. ('51071.1')
    'E0715'. ('1806.1')
    'E0716'. ('7083.1')
    'E0717'. ('7084.1')
    'E0718'. ('1854.1')
    'E0719'. ('3704.1')
    'E0720'. ('10682.1')
    'E0721'. ('1892.1')
    'E0722'. ('549.1')
    'E0723'. ('1891.1')
    'E0724'. ('1962.1')
    'E0725'. ('11001.1')
    'E0726'. ('28231.1')
    'E0727'. ('53919.1')
    'E0728'. ('10257.1')
    'E0729'. ('28232.1')
    'E0732'. ('55500.1')
    'E0733'. ('55224.1')
    'E0734'. ('8790.1')
    'E0735'. ('51086.1')
    'E0736'. ('2181.1')
    'E0737'. ('2182.1')
    'E0738'. ('2180.1')
    'E0739'. ('2181.2')
    'E0740'. ('51703.1')
    'E0741'. ('81616.1')
    'E0742'. ('23305.1')
    'E0743'. ('2182.2')
    'E0744'. ('116285.1')
    'E0745'. ('5167.1')
    'E0746'. ('5169.1')
    'E0747'. ('6785.1')
    'E0748'. ('79071.1')
    'E0749'. ('60481.1')
    'E0750'. ('54898.1')
    'E0752'. ('38.1', '36.1', '1892.1', '3028.1')
    'E0753'. ('30.1', '51.1', '3295.1')
    'E0754'. ('30.1', '51.1', '1962.1')
    'E0755'. ('2194.1')
    'E0756'. ('79071.1', '60481.1', '54898.1', '2194.1')
    'E0757'. ('376497.2')
    'E0758'. ('10999.1')
    'E0759'. ('376497.1')
    'E0760'. ('11000.1')
    'E0761'. ('226.2')
    'E0762'. ('229.1')
    'E0763'. ('226.3')
    'E0764'. ('230.1')
    'E0765'. ('226.1')
    'E0766'. ('2203.1')
    'E0767'. ('5210.1')
    'E0768'. ('5207.1')
    'E0769'. ('5209.1')
    'E0770'. ('5208.1')
    'E0771'. ('8789.1')
    'E0772'. ('2235.1')
    'E0773'. ('2235.2')
    'E0775'. ('79901.1')
    'E0776'. ('197258.1')
    'E0778'. ('1719.1')
    'E0779'. ('2356.1')
    'E0780'. ('29988.1')
    'E0781'. ('6514.1')
    'E0782'. ('155184.1')
    'E0783'. ('6518.1')
    'E0784'. ('66035.1')
    'E0786'. ('25902.1')
    'E0787'. ('4522.1')
    'E0788'. ('2519.1')
    'E0789'. ('2517.1')
    'E0791'. ('2271.1')
    'E0792'. ('2523.1')
    'E0793'. ('2525.1')
    'E0794'. ('10690.1')
    'E0795'. ('8703.1')
    'E0796'. ('8704.2')
    'E0797'. ('8704.1')
    'E0798'. ('2683.1')
    'E0799'. ('9334.1')
    'E0800'. ('2820.1')
    'E0801'. ('5832.1')
    'E0803'. ('2539.1')
    'E0804'. ('2542.1')
    'E0805'. ('2593.1')
    'E0806'. ('2593.2')
    'E0808'. ('5476.1', '2720.1', '2588.1', '4758.1')
    'E0809'. ('5476.1', '2720.1')
    'E0810'. ('2581.1')
    'E0811'. ('2583.1')
    'E0812'. ('55790.1')
    'E0813'. ('55454.1')
    'E0814'. ('79586.1', '22856.1')
    'E0815'. ('337876.1')
    'E0816'. ('26290.1')
    'E0817'. ('79695.1')
    'E0818'. ('2589.1')
    'E0819'. ('50614.1')
    'E0820'. ('8693.1')
    'E0821'. ('55568.2')
    'E0822'. ('114805.1')
    'E0823'. ('11226.1')
    'E0824'. ('117248.1')
    'E0825'. ('11227.1')
    'E0826'. ('55568.1')
    'E0827'. ('2590.1')
    'E0828'. ('51809.1')
    'E0829'. ('79623.1')
    'E0830'. ('63917.1')
    'E0831'. ('2591.1')
    'E0832'. ('81031.1')
    'E0833'. ('126792.1')
    'E0834'. ('11285.1')
    'E0835'. ('8972.1')
    'E0836'. ('2618.1')
    'E0837'. ('2618.2')
    'E0838'. ('175.1')
    'E0839'. ('2629.2')
    'E0840'. ('2629.3')
    'E0841'. ('2629.4')
    'E0842'. ('2629.5')
    'E0843'. ('2629.1')
    'E0844'. ('26301.1')
    'E0845'. ('4329.1')
    'E0846'. ('7915.1')
    'E0847'. ('7915.2')
    'E0848'. ('1738.1', '275.1', '2731.1', '2653.1')
    'E0849'. ('2651.1')
    'E0850'. ('55343.1')
    'E0851'. ('7264.1')
    'E0852'. ('8836.1')
    'E0858'. ('2687.1')
    'E0859'. ('6472.1')
    'E0860'. ('6470.1')
    'E0861'. ('6470.2')
    'E0862'. ('2717.1')
    'E0864'. ('2990.1')
    'E0865'. ('8372.1')
    'E0866'. ('26035.1')
    'E0867'. ('54480.1')
    'E0868'. ('2131.1', '2132.1')
    'E0869'. ('27087.2')
    'E0870'. ('135152.1')
    'E0871'. ('27087.1')
    'E0872'. ('26229.1')
    'E0873'. ('4669.1')
    'E0874'. ('64579.1')
    'E0875'. ('3340.1')
    'E0876'. ('9348.1')
    'E0877'. ('8509.1')
    'E0878'. ('2137.1')
    'E0879'. ('2135.1')
    'E0880'. ('2134.1')
    'E0881'. ('56606.1')
    'E0882'. ('154091.1')
    'E0883'. ('11182.1')
    'E0884'. ('56606.2')
    'E0885'. ('144195.1')
    'E0886'. ('6523.1')
    'E0887'. ('178.4')
    'E0888'. ('178.5')
    'E0889'. ('178.1')
    'E0890'. ('178.3')
    'E0891'. ('178.2')
    'E0892'. ('178.6')
    'E0893'. ('5834.1')
    'E0894'. ('5837.1')
    'E0895'. ('5836.1')
    'E0896'. ('2729.1', '2730.1')
    'E0899'. ('10841.1')
    'E0900'. ('10841.2')
    'E0901'. ('2744.1')
    'E0902'. ('27165.2')
    'E0903'. ('27165.1')
    'E0904'. ('83733.1')
    'E0905'. ('79751.1')
    'E0906'. ('2639.1')
    'E0907'. ('2639.2')
    'E0911'. ('54363.1')
    'E0912'. ('51179.2')
    'E0913'. ('51179.1')
    'E0916'. ('2710.2')
    'E0917'. ('2712.1')
    'E0918'. ('2710.1')
    'E0919'. ('2713.1')
    'E0920'. ('3029.1')
    'E0921'. ('6536.1')
    'E0922'. ('6536.2')
    'E0923'. ('5226.1')
    'E0926'. ('284098.1')
    'E0927'. ('80055.1')
    'E0928'. ('93183.1', '54965.1')
    'E0929'. ('2936.1')
    'E0930'. ('7001.3')
    'E0931'. ('5052.3')
    'E0932'. ('2877.1')
    'E0933'. ('2876.2')
    'E0934'. ('5052.2')
    'E0935'. ('2876.1')
    'E0936'. ('5052.1')
    'E0937'. ('7001.1')
    'E0938'. ('2879.1')
    'E0939'. ('7001.2')
    'E0940'. ('2878.1')
    'E0941'. ('257202.1')
    'E0942'. ('2882.1')
    'E0943'. ('10935.1')
    'E0944'. ('10935.2')
    'E0945'. ('2937.1')
    'E0946'. ('2679.1')
    'E0947'. ('2678.1')
    'E0948'. ('2678.3')
    'E0949'. ('2678.2')
    'E0950'. ('2977.1', '2983.1')
    'E0951'. ('4882.2')
    'E0952'. ('2982.1', '2974.1')
    'E0953'. ('2986.1')
    'E0954'. ('4882.1')
    'E0955'. ('2984.1')
    'E0956'. ('4881.1')
    'E0957'. ('2977.1', '2974.1')
    'E0958'. ('3000.1')
    'E0959'. ('2983.1', '2982.1')
    'E0960'. ('9615.1')
    'E0961'. ('763.1')
    'E0962'. ('11238.1')
    'E0963'. ('23556.1')
    'E0964'. ('23556.2')
    'E0965'. ('55650.1')
    'E0966'. ('53905.1')
    'E0967'. ('50506.1')
    'E0968'. ('53905.2')
    'E0970'. ('5281.1', '84720.1')
    'E0971'. ('5281.1', '54872.1')
    'E0972'. ('80235.1')
    'E0973'. ('10026.1', '8733.1', '128869.1', '94005.1', '51604.1')
    'E0974'. ('3028.1')
    'E0975'. ('3033.1')
    'E0976'. ('3038.2')
    'E0977'. ('3036.1')
    'E0978'. ('3038.1')
    'E0979'. ('3037.1')
    'E0980'. ('27235.1')
    'E0981'. ('6522.1')
    'E0982'. ('83697.1')
    'E0983'. ('6521.1')
    'E0984'. ('6508.2')
    'E0985'. ('6508.1')
    'E0986'. ('2645.1')
    'E0987'. ('3099.1')
    'E0988'. ('3098.3')
    'E0989'. ('2645.2')
    'E0990'. ('80201.1')
    'E0991'. ('3098.2')
    'E0992'. ('2645.3')
    'E0993'. ('3098.1')
    'E0994'. ('3098.4')
    'E0995'. ('3101.1')
    'E0996'. ('3098.5')
    'E0999'. ('3067.1')
    'E1002'. ('3157.1')
    'E1003'. ('3157.2')
    'E1004'. ('3158.1')
    'E1005'. ('3155.1')
    'E1006'. ('54511.1')
    'E1009'. ('26061.1')
    'E1010'. ('197257.1')
    'E1011'. ('197257.2')
    'E1012'. ('6448.1')
    'E1016'. ('3292.1')
    'E1017'. ('7923.1')
    'E1018'. ('3294.1')
    'E1019'. ('51478.1')
    'E1021'. ('3284.1')
    'E1022'. ('80270.1')
    'E1024'. ('3420.1', '3421.1', '3419.1')
    'E1025'. ('3417.1')
    'E1026'. ('3418.1')
    'E1027'. ('7173.4')
    'E1028'. ('7173.1')
    'E1029'. ('7173.3')
    'E1030'. ('7173.2')
    'E1031'. ('7173.5')
    'E1032'. ('3425.1')
    'E1033'. ('587.1')
    'E1037'. ('6526.1')
    'E1038'. ('3422.1')
    'E1039'. ('91734.1')
    'E1040'. ('160728.1')
    'E1041'. ('8802.1', '8801.1')
    'E1042'. ('8802.1', '8803.1')
    'E1043'. ('6560.1')
    'E1044'. ('10723.1')
    'E1045'. ('9990.1')
    'E1046'. ('57468.1')
    'E1047'. ('3795.1')
    'E1048'. ('3795.2')
    'E1049'. ('84679.1')
    'E1050'. ('23315.1')
    'E1051'. ('8564.1')
    'E1052'. ('3938.1')
    'E1053'. ('2720.1')
    'E1054'. ('53.1')
    'E1056'. ('387775.1')
    'E1057'. ('124637.1')
    'E1058'. ('366.1')
    'E1059'. ('11283.1')
    'E1060'. ('4047.1')
    'E1061'. ('5321.1')
    'E1065'. ('4023.1')
    'E1066'. ('3990.1')
    'E1067'. ('1056.1')
    'E1068'. ('80339.1')
    'E1069'. ('11343.1')
    'E1070'. ('11343.2')
    'E1071'. ('50487.1')
    'E1072'. ('9227.1')
    'E1073'. ('6309.1')
    'E1087'. ('4190.1')
    'E1088'. ('4200.1')
    'E1090'. ('10873.1')
    'E1092'. ('1557.1')
    'E1093'. ('1543.1')
    'E1094'. ('1545.1')
    'E1095'. ('1544.1')
    'E1098'. ('6520.1', '8140.1')
    'E1100'. ('4598.1')
    'E1101'. ('3635.1')
    'E1102'. ('8867.2')
    'E1103'. ('3636.1')
    'E1104'. ('27124.2')
    'E1105'. ('8867.1')
    'E1106'. ('27124.1')
    'E1107'. ('3633.1')
    'E1108'. ('56623.1')
    'E1109'. ('3632.1')
    'E1111'. ('3706.1')
    'E1112'. ('80271.1')
    'E1113'. ('3707.1')
    'E1114'. ('51477.1')
    'E1116'. ('3631.1')
    'E1117'. ('8821.1')
    'E1123'. ('4507.1')
    'E1124'. ('10797.1')
    'E1128'. ('4668.1')
    'E1131'. ('6528.1')
    'E1143'. ('6548.1')
    'E1144'. ('6550.1')
    'E1145'. ('6549.1')
    'E1146'. ('84735.1')
    'E1147'. ('55748.1')
    'E1148'. ('6559.1')
    'E1149'. ('123041.2')
    'E1150'. ('57419.1')
    'E1151'. ('9187.1')
    'E1152'. ('123041.3')
    'E1153'. ('25769.1')
    'E1154'. ('123041.1')
    'E1155'. ('124583.1')
    'E1157'. ('9583.1')
    'E1159'. ('4832.1')
    'E1160'. ('4831.1', '4830.1')
    'E1161'. ('10201.1')
    'E1162'. ('29922.2')
    'E1163'. ('29922.1')
    'E1164'. ('4833.1')
    'E1165'. ('57127.1')
    'E1166'. ('6005.1')
    'E1169'. ('349565.1')
    'E1170'. ('64802.1')
    'E1171'. ('23057.1')
    'E1172'. ('23057.2')
    'E1174'. ('4837.1')
    'E1176'. ('4846.1')
    'E1177'. ('201288.1')
    'E1178'. ('4842.1')
    'E1179'. ('4843.2')
    'E1180'. ('4843.1')
    'E1181'. ('645740.1')
    'E1182'. ('4860.1')
    'E1183'. ('6580.1')
    'E1185'. ('30833.1')
    'E1186'. ('5251.1')
    'E1187'. ('56953.1')
    'E1188'. ('4907.1')
    'E1189'. ('3704.2')
    'E1190'. ('6476.1')
    'E1192'. ('5019.1')
    'E1193'. ('64064.1')
    'E1194'. ('1738.1', '1629.1', '594.1', '593.1')
    'E1197'. ('7372.1')
    'E1198'. ('1836.1')
    'E1199'. ('10861.1')
    'E1200'. ('10861.3')
    'E1201'. ('10861.2')
    'E1202'. ('1811.1')
    'E1204'. ('1584.1')
    'E1205'. ('1585.1')
    'E1207'. ('1588.1')
    'E1209'. ('1576.1')
    'E1210'. ('1589.1')
    'E1211'. ('1593.1')
    'E1212'. ('1553.1')
    'E1213'. ('1548.1')
    'E1214'. ('1562.1')
    'E1215'. ('1558.1')
    'E1216'. ('1558.2')
    'E1217'. ('1559.1')
    'E1218'. ('1565.1')
    'E1219'. ('1572.1')
    'E1221'. ('64816.1')
    'E1224'. ('1577.1')
    'E1225'. ('1551.1')
    'E1227'. ('66002.1')
    'E1228'. ('4051.1')
    'E1229'. ('8529.1')
    'E1230'. ('9420.1')
    'E1231'. ('1582.1')
    'E1232'. ('5831.1')
    'E1233'. ('5831.2')
    'E1234'. ('5051.1')
    'E1235'. ('5049.1', '5050.1')
    'E1236'. ('5049.1', '5050.1', '5048.1')
    'E1238'. ('347734.1')
    'E1239'. ('57194.1')
    'E1240'. ('5338.1')
    'E1241'. ('5337.1')
    'E1243'. ('5091.1')
    'E1244'. ('5091.2')
    'E1245'. ('5244.1')
    'E1246'. ('5244.3')
    'E1247'. ('5244.2')
    'E1248'. ('5139.1')
    'E1249'. ('5142.1')
    'E1250'. ('5151.3')
    'E1251'. ('5153.1')
    'E1252'. ('5150.2')
    'E1253'. ('5143.1')
    'E1254'. ('5150.1')
    'E1255'. ('5137.1')
    'E1256'. ('5144.1')
    'E1257'. ('5136.2')
    'E1258'. ('5140.2')
    'E1259'. ('5151.2')
    'E1260'. ('10846.1')
    'E1261'. ('5151.5')
    'E1262'. ('5140.1')
    'E1263'. ('5141.1')
    'E1264'. ('5138.1')
    'E1265'. ('5136.1')
    'E1266'. ('5151.4')
    'E1267'. ('5151.1')
    'E1268'. ('27115.1')
    'E1269'. ('50940.1')
    'E1270'. ('8622.1')
    'E1271'. ('5146.1')
    'E1272'. ('5152.17')
    'E1273'. ('5152.6')
    'E1274'. ('5152.11')
    'E1275'. ('5152.2')
    'E1276'. ('8654.2')
    'E1277'. ('5152.10')
    'E1278'. ('5145.1', '5158.1', '5149.1')
    'E1279'. ('5152.12')
    'E1280'. ('5152.15')
    'E1281'. ('5152.5')
    'E1282'. ('5152.20')
    'E1283'. ('5152.19')
    'E1284'. ('5152.16')
    'E1285'. ('8654.3')
    'E1286'. ('5152.14')
    'E1287'. ('5152.13')
    'E1288'. ('5152.7')
    'E1289'. ('5152.3')
    'E1290'. ('8654.1')
    'E1291'. ('5152.18')
    'E1292'. ('5146.1', '5145.1', '5158.1', '5147.1', '5148.1')
    'E1293'. ('5152.4')
    'E1294'. ('5152.1')
    'E1297'. ('55163.1')
    'E1299'. ('5105.1')
    'E1301'. ('30.1', '3295.1', '1962.1', '8310.1')
    'E1302'. ('5833.1')
    'E1303'. ('10400.2')
    'E1304'. ('10400.1')
    'E1305'. ('10400.3')
    'E1309'. ('80142.4')
    'E1310'. ('80142.2')
    'E1311'. ('9536.1')
    'E1312'. ('80142.1')
    'E1313'. ('9536.2')
    'E1314'. ('80142.3')
    'E1317'. ('9489.1')
    'E1318'. ('5743.1')
    'E1319'. ('5742.1')
    'E1320'. ('59272.1')
    'E1322'. ('5053.1')
    'E1323'. ('5264.1')
    'E1324'. ('5728.1')
    'E1325'. ('8871.1')
    'E1326'. ('8394.1')
    'E1327'. ('23396.1')
    'E1328'. ('8395.1')
    'E1329'. ('55361.1')
    'E1330'. ('5297.1')
    'E1331'. ('5298.1')
    'E1332'. ('5293.1', '8503.1')
    'E1333'. ('5296.1', '5290.1')
    'E1334'. ('5293.1', '5295.1')
    'E1335'. ('5295.1', '5291.1')
    'E1336'. ('5296.1', '5291.1')
    'E1337'. ('10870.1', '5294.1')
    'E1338'. ('5294.1', '23533.1')
    'E1339'. ('5290.1', '5295.1')
    'E1340'. ('8503.1', '5290.1')
    'E1341'. ('8503.1', '5291.1')
    'E1342'. ('5293.1', '5296.1')
    'E1343'. ('4952.1')
    'E1344'. ('4952.2')
    'E1345'. ('23236.2')
    'E1346'. ('5336.1')
    'E1347'. ('9651.1')
    'E1348'. ('113026.1')
    'E1349'. ('89869.1')
    'E1350'. ('84812.1')
    'E1351'. ('5330.1')
    'E1352'. ('5335.1')
    'E1353'. ('51196.1')
    'E1354'. ('5333.1')
    'E1355'. ('5332.2')
    'E1356'. ('5331.1')
    'E1357'. ('5335.2')
    'E1358'. ('5334.1')
    'E1359'. ('5332.1')
    'E1360'. ('257068.1')
    'E1361'. ('23236.1')
    'E1362'. ('23007.1')
    'E1363'. ('5287.1')
    'E1364'. ('5286.1')
    'E1365'. ('5288.1')
    'E1366'. ('200576.2')
    'E1367'. ('8396.1')
    'E1368'. ('200576.3')
    'E1369'. ('79837.1')
    'E1370'. ('8396.2')
    'E1371'. ('5305.1')
    'E1372'. ('200576.1')
    'E1373'. ('5289.1')
    'E1374'. ('5279.1', '51227.1', '5277.1', '5283.1', '9091.1', '8818.1')
    'E1375'. ('8398.1')
    'E1376'. ('5320.1')
    'E1377'. ('8398.2')
    'E1378'. ('81579.1')
    'E1379'. ('5322.1')
    'E1380'. ('64600.1')
    'E1381'. ('100137049.1')
    'E1382'. ('123745.1')
    'E1383'. ('5319.1')
    'E1384'. ('26279.1')
    'E1385'. ('8399.1')
    'E1386'. ('30814.1')
    'E1387'. ('10654.1')
    'E1388'. ('117283.1')
    'E1389'. ('9807.2')
    'E1390'. ('9807.1')
    'E1391'. ('51447.3')
    'E1392'. ('51447.4')
    'E1393'. ('51447.6')
    'E1394'. ('51447.5')
    'E1395'. ('51447.1')
    'E1396'. ('51447.2')
    'E1398'. ('27068.4')
    'E1399'. ('27068.1')
    'E1400'. ('27068.3')
    'E1401'. ('27068.2')
    'E1402'. ('8612.1')
    'E1403'. ('8611.1')
    'E1404'. ('8613.1')
    'E1405'. ('8611.2')
    'E1406'. ('5498.1')
    'E1407'. ('8288.1')
    'E1408'. ('9588.1')
    'E1409'. ('4353.1')
    'E1412'. ('6578.1')
    'E1416'. ('10965.1')
    'E1417'. ('10005.1')
    'E1418'. ('10005.3')
    'E1419'. ('10005.2')
    'E1420'. ('122970.1')
    'E1425'. ('7378.2')
    'E1426'. ('151531.1')
    'E1427'. ('7378.1')
    'E1430'. ('64080.1')
    'E1431'. ('5959.1')
    'E1432'. ('8608.1')
    'E1433'. ('157506.1')
    'E1434'. ('112724.1')
    'E1435'. ('145226.1')
    'E1436'. ('51109.1')
    'E1437'. ('195814.1')
    'E1438'. ('57665.1')
    'E1439'. ('50700.1')
    'E1440'. ('8228.1')
    'E1442'. ('54981.1')
    'E1443'. ('6484.1')
    'E1444'. ('6482.1')
    'E1445'. ('6483.1')
    'E1446'. ('6482.2')
    'E1447'. ('10090.1')
    'E1448'. ('9653.1')
    'E1449'. ('3423.1')
    'E1450'. ('3423.2')
    'E1451'. ('9957.1')
    'E1452'. ('9951.1')
    'E1453'. ('222537.1')
    'E1454'. ('9956.1')
    'E1455'. ('9955.1')
    'E1456'. ('9953.1')
    'E1457'. ('64711.1')
    'E1458'. ('113189.1')
    'E1459'. ('50515.1')
    'E1460'. ('166012.1')
    'E1461'. ('55501.1')
    'E1462'. ('411.2')
    'E1463'. ('411.1')
    'E1464'. ('23563.2')
    'E1465'. ('9435.1')
    'E1466'. ('23563.1')
    'E1467'. ('10164.1')
    'E1468'. ('4166.1')
    'E1469'. ('8534.1')
    'E1470'. ('9469.1')
    'E1471'. ('56548.1')
    'E1472'. ('266722.1')
    'E1473'. ('9394.1')
    'E1474'. ('90161.2')
    'E1475'. ('90161.1')
    'E1476'. ('2799.1')
    'E1477'. ('10157.1')
    'E1478'. ('118881.1')
    'E1479'. ('3176.1')
    'E1481'. ('81537.1')
    'E1483'. ('6342.1')
    'E1486'. ('2098.1')
    'E1488'. ('8869.1')
    'E1489'. ('56848.1')
    'E1490'. ('8877.1')
    'E1491'. ('130752.1')
    'E1492'. ('55512.1')
    'E1493'. ('55512.2')
    'E1494'. ('339221.1')
    'E1495'. ('55627.1')
    'E1496'. ('6609.1')
    'E1497'. ('6610.1')
    'E1498'. ('259230.1')
    'E1499'. ('115111.1')
    'E1500'. ('115019.2')
    'E1501'. ('115111.2')
    'E1502'. ('116369.2')
    'E1503'. ('284129.1')
    'E1504'. ('116369.1')
    'E1505'. ('115019.1')
    'E1507'. ('6646.1')
    'E1512'. ('6611.1')
    'E1513'. ('6723.1')
    'E1514'. ('6713.1')
    'E1515'. ('2222.1')
    'E1531'. ('10402.1')
    'E1533'. ('256435.1')
    'E1534'. ('30815.1')
    'E1535'. ('81849.1')
    'E1536'. ('6489.1')
    'E1537'. ('29906.1')
    'E1538'. ('412.1')
    'E1539'. ('6389.1', '6392.1', '6391.1', '6390.1')
    'E1540'. ('6821.1')
    'E1542'. ('5092.1')
    'E1543'. ('5092.2')
    'E1544'. ('23530.2')
    'E1545'. ('23530.1')
    'E1546'. ('79178.1')
    'E1547'. ('6567.1')
    'E1549'. ('55217.1')
    'E1550'. ('7296.3')
    'E1551'. ('7296.1')
    'E1552'. ('7296.4')
    'E1553'. ('7296.2')
    'E1554'. ('80162.1')
    'E1555'. ('11181.1')
    'E1556'. ('7166.1')
    'E1557'. ('121278.1')
    'E1560'. ('6561.1')
    'E1561'. ('6916.1')
    'E1566'. ('10020.1')
    'E1568'. ('7355.1')
    'E1569'. ('7358.1')
    'E1570'. ('23169.1')
    'E1571'. ('80146.1')
    'E1573'. ('84912.1')
    'E1576'. ('11046.1')
    'E1577'. ('54576.1')
    'E1578'. ('54575.1')
    'E1579'. ('54578.1')
    'E1580'. ('54579.1')
    'E1581'. ('54600.1')
    'E1582'. ('54658.1')
    'E1583'. ('54659.1')
    'E1584'. ('54577.1')
    'E1585'. ('54657.1')
    'E1586'. ('7364.1')
    'E1587'. ('54490.1')
    'E1588'. ('7367.1')
    'E1589'. ('10720.1')
    'E1590'. ('7363.1')
    'E1591'. ('7365.1')
    'E1592'. ('7366.1')
    'E1593'. ('54963.1')
    'E1594'. ('7498.1')
    'E1596'. ('64131.1')
    'E1597'. ('64132.1')
    'E1602'. ('1356.1')
    'E1603'. ('1356.1', '2512.1', '2495.1')
    'E1604'. ('94033.1')
    'E1608'. ('10587.1')
    'E1609'. ('80347.1')
    'E1610'. ('22978.1')
    'E1611'. ('84618.1')
    'E1612'. ('51251.1')
    'E1613'. ('93034.1')
    'E1614'. ('100526794.1')
    'E1615'. ('3251.1', '353.1')
    'E1616'. ('3420.1', '3421.1', '3419.1')
    'E1617'. ('56954.1')
    'E1618'. ('5313.1')
    'E1619'. ('92086.1')
    'E1620'. ('728441.1')
    'E1621'. ('102724197.1')
    'E1622'. ('2686.1')
    'E1623'. ('124975.1')
    'E1624'. ('124975.1', '91227.1')
    'E1625'. ('5211.1')
    'E1628'. ('29926.1')
    'E1629'. ('29925.1')
    'E1632'. ('249.1')
    'E1634'. ('51292.1')
    'E1635'. ('2766.1')
    'E1636'. ('57571.1')
    'E1640'. ('11332.1')
    'E1641'. ('5538.1')
    'E1642'. ('641371.1')
    'E1643'. ('9374.1')
    'E1644'. ('55825.1')
    'E1645'. ('51102.1')
    'E1646'. ('37.1')
    'E1647'. ('8310.1')
    'E1648'. ('33.1')
    'E1649'. ('132158.1')
    'E1653'. ('93100.1')
    'E1654'. ('23475.1')
    'E1655'. ('1374.1', '1376.1')
    'E1656'. ('4967.1')
    'E1659'. ('79966.1')
    'E1660'. ('275.1')
    'E1661'. ('10588.1')
    'E1664'. ('1743.1')
    'E1665'. ('1629.1')
    'E1666'. ('79646.1')
    'E1667'. ('80025.1')
    'E1668'. ('53354.1')
    'E1669'. ('55229.1')
    'E1676'. ('29920.1')
    'E1677'. ('3030.1', '1892.1', '1962.1')
    'E1678'. ('3030.1', '1962.1', '3033.1')
    'E1679'. ('125.1', '124.1', '126.1')
    'E1680'. ('7389.1')
    'E1681'. ('1595.1')
    'E1682'. ('130367.1')
    'E1684'. ('23443.1')
    'E1685'. ('64240.1', '64241.1')
    'E1686'. ('11136.1')
    'E1687'. ('284111.1')
    'E1688'. ('1738.1', '1629.1', '594.1', '593.1')
    'E1689'. ('8435.1')
    'E1690'. ('3988.1')
    'E1691'. ('771.1')
    'E1692'. ('760.1')
    'E1693'. ('768.1')
    'E1694'. ('23632.1')
    'E1695'. ('765.1')
    'E1696'. ('759.1')
    'E1697'. ('762.1')
    'E1698'. ('766.1')
    'E1699'. ('767.1')
    'E1700'. ('377677.1')
    'E1701'. ('3295.1', '1962.1', '3028.1')
    'E1702'. ('3295.1', '1962.1', '3033.1')
    'E1703'. ('10057.1')
    'E1704'. ('8140.1')
    'E1705'. ('9057.1')
    'E1707'. ('6568.1')
    'E1709'. ('54020.1')
    'E1710'. ('215.1')
    'E1712'. ('641372.1')
    'E1713'. ('4830.1')
    'E1714'. ('4831.1')
    'E1715'. ('50484.1')
    'E1716'. ('3030.1')
    'E1720'. ('25830.1')
    'E1721'. ('84569.1')
    'E1722'. ('4025.1')
    'E1724'. ('93492.1')
    'E1726'. ('10249.1')
    'E1727'. ('1580.1')
    'E1728'. ('1555.1')
    'E1729'. ('1549.1')
    'E1730'. ('1573.1')
    'E1731'. ('199974.1')
    'E1732'. ('260293.1')
    'E1733'. ('29785.1')
    'E1734'. ('57834.1')
    'E1735'. ('1215.1')
    'E1736'. ('1357.1')
    'E1737'. ('1358.1')
    'E1738'. ('57094.1')
    'E1739'. ('93979.1')
    'E1743'. ('1636.1')
    'E1745'. ('9331.1')
    'E1747'. ('5315.1')
    'E1748'. ('26063.1')
    'E1749'. ('1666.1')
    'E1750'. ('874.1')
    'E1751'. ('10901.1')
    'E1752'. ('126410.1')
    'E1753'. ('2053.1')
    'E1754'. ('8897.1')
    'E1755'. ('8897.3')
    'E1756'. ('8897.2')
    'E1757'. ('8898.1')
    'E1758'. ('2880.1')
    'E1761'. ('115584.1')
    'E1765'. ('6534.1')
    'E1767'. ('1622.1')
    'E1768'. ('215.1', '225.1')
    'E1769'. ('28965.1')
    'E1770'. ('23205.1')
    'E1771'. ('10449.1', '1892.1', '3033.1')
    'E1772'. ('30.1', '3295.1', '1962.1')
    'E1773'. ('34.1', '1892.1')
    'E1774'. ('10449.1', '34.1', '1892.1', '3033.1')
    'E1775'. ('30.1', '51.1', '3295.1', '1962.1')
    'E1776'. ('30.1', '8309.1', '23600.1', '1962.1')
    'E1777'. ('8309.1', '23600.1', '1962.1', '6342.1')
    'E1778'. ('30.1', '8309.1', '23600.1', '3295.1')
    'E1779'. ('8309.1', '23600.1', '3295.1', '6342.1')
    'E1780'. ('30.1', '8309.1', '1962.1')
    'E1781'. ('8309.1', '1962.1', '6342.1')
    'E1782'. ('30.1', '8309.1', '3295.1')
    'E1783'. ('8309.1', '3295.1', '6342.1')
    'E1784'. ('3032.1', '3030.1', '37.1')
    'E1785'. ('3030.1', '37.1')
    'E1786'. ('30.1', '3295.1', '1962.1', '8310.1')
    'E1787'. ('224.1', '26061.1')
    'E1790'. ('128.1', '224.1')
    'E1791'. ('57393.1', '54716.1')
    'E1793'. ('6520.1', '9057.1')
    'E1794'. ('6520.1', '9056.1')
    'E1795'. ('6519.1', '11136.1')
    'E1796'. ('113235.1')
    'E1798'. ('2168.1')
    'E1800'. ('9390.1')
    'E1805'. ('248.1')
    'E1806'. ('4524.1')
    'E1807'. ('65263.1')
    'E1809'. ('28982.1')
    'E1810'. ('6120.1')
    'E1811'. ('6120.2')
    'E1812'. ('10864.1')
    'E1813'. ('23428.1')
    'E1814'. ('9356.1')
    'E1815'. ('9376.1')
    'E1817'. ('120103.1')
    'E1819'. ('85320.1')
    'E1820'. ('222962.1')
    'E1822'. ('9429.1')
    'E1823'. ('55867.1')
    'E1824'. ('360.1')
    'E1825'. ('364.1')
    'E1826'. ('89872.1')
    'E1827'. ('21.1')
    'E1829'. ('10057.2')
    'E1830'. ('125206.1')
    'E1831'. ('200010.1')
    'E1832'. ('6524.1')
    'E1833'. ('159963.1')
    'E1834'. ('79581.1')
    'E1835'. ('55065.1')
    'E1836'. ('3764.1', '6833.1')
    'E1837'. ('3764.1', '10060.1')
    'E1838'. ('6833.1', '3767.1')
    'E1839'. ('10060.1', '3767.1')
    'E1840'. ('5950.1', '64220.1', '5947.1')
    'E1841'. ('5950.1', '64220.1', '5948.1')
    'E1843'. ('2350.1')
    'E1844'. ('3248.1')
    'E1845'. ('166929.1')
    'E1847'. ('3658.1')
    'E1848'. ('122481.1')
    'E1849'. ('203.1')
    'E1850'. ('353.1')
    'E1851'. ('159.1')
    'E1852'. ('122622.1')
    'E1853'. ('122622.2')
    'E1854'. ('11212.1')
    'E1855'. ('383.1')
    'E1856'. ('1371.1')
    'E1857'. ('1503.1')
    'E1858'. ('56474.1')
    'E1860'. ('2987.1')
    'E1862'. ('9453.1')
    'E1863'. ('2023.1')
    'E1864'. ('2027.1')
    'E1865'. ('2027.2')
    'E1866'. ('2026.1')
    'E1867'. ('9843.1')
    'E1868'. ('80308.1')
    'E1869'. ('80308.2')
    'E1870'. ('7360.1')
    'E1871'. ('7360.2')
    'E1872'. ('2597.1')
    'E1873'. ('26330.1')
    'E1874'. ('2673.1')
    'E1875'. ('9945.1')
    'E1878'. ('1800.1')
    'E1879'. ('2762.1')
    'E1881'. ('3251.1')
    'E1882'. ('761.1')
    'E1883'. ('766.2')
    'E1884'. ('771.2')
    'E1890'. ('3145.1')
    'E1891'. ('586.1')
    'E1892'. ('3614.1')
    'E1893'. ('3615.1')
    'E1894'. ('3614.2')
    'E1895'. ('682.1')
    'E1896'. ('29926.2')
    'E1897'. ('29925.2')
    'E1898'. ('4351.1')
    'E1899'. ('100287639.1')
    'E1900'. ('441024.1')
    'E1902'. ('389015.1')
    'E1903'. ('6553.1')
    'E1905'. ('5230.1')
    'E1906'. ('375056.1')
    'E1907'. ('5232.1')
    'E1908'. ('5236.1')
    'E1909'. ('55276.1')
    'E1910'. ('5372.1')
    'E1911'. ('5373.1')
    'E1917'. ('210.1')
    'E1918'. ('210.2')
    'E1921'. ('58510.1')
    'E1922'. ('153201.1')
    'E1923'. ('221823.2')
    'E1924'. ('5631.1')
    'E1925'. ('221823.1')
    'E1926'. ('5634.1')
    'E1929'. ('8781.1')
    'E1930'. ('5723.1')
    'E1931'. ('55312.1')
    'E1932'. ('6240.1', '6241.1')
    'E1934'. ('79896.1')
    'E1935'. ('7086.1')
    'E1936'. ('84076.1')
    'E1937'. ('8277.1')
    'E1938'. ('27010.1')
    'E1941'. ('2582.1')
    'E1942'. ('2582.2')
    'E1943'. ('6675.1')
    'E1944'. ('91373.1')
    'E1945'. ('7390.1')
    'E1946'. ('6563.1')
    'E1947'. ('8170.1')
    'E1949'. ('100507855.1')
    'E1950'. ('31.5')
    'E1951'. ('31.4')
    'E1952'. ('32.1', '31.2')
    'E1953'. ('32.1', '31.4')
    'E1954'. ('31.2')
    'E1955'. ('32.1', '31.3')
    'E1956'. ('32.1', '31.1')
    'E1957'. ('31.1')
    'E1958'. ('32.1', '31.5')
    'E1959'. ('31.3')
    'E1960'. ('93034.2')
    'E1961'. ('55191.1')
    'E1962'. ('132.1')
    'E1963'. ('132.2')
    'E1964'. ('112611.1')
    'E1965'. ('98.1')
    'E1966'. ('97.2')
    'E1967'. ('97.1')
    'E1971'. ('171425.1')
    'E1972'. ('171425.2')
    'E1973'. ('132789.1')
    'E1974'. ('10007.1')
    'E1975'. ('2584.1')
    'E1976'. ('2585.2')
    'E1977'. ('2585.1')
    'E1978'. ('2592.1')
    'E1979'. ('2592.3')
    'E1980'. ('2592.2')
    'E1981'. ('5471.1')
    'E1982'. ('84264.2')
    'E1983'. ('84264.1')
    'E1984'. ('3034.1')
    'E1987'. ('3612.1')
    'E1988'. ('3613.1')
    'E1989'. ('8776.1')
    'E1990'. ('2978.1')
    'E1991'. ('4953.1')
    'E1992'. ('5214.1')
    'E1993'. ('5211.2')
    'E1994'. ('5211.1', '5214.1')
    'E1995'. ('5214.1', '5213.1')
    'E1996'. ('5213.1')
    'E1997'. ('5211.1', '5213.1')
    'E1998'. ('10050.1')
    'E1999'. ('10786.1')
    'E2000'. ('10246.1')
    'E2001'. ('6569.1')
    'E2002'. ('10568.1')
    'E2003'. ('5198.1')
    'E2004'. ('5315.2')
    'E2005'. ('5313.2')
    'E2006'. ('5315.3')
    'E2007'. ('113675.1')
    'E2011'. ('1635.1')
    'E2013'. ('10560.1')
    'E2014'. ('191.1')
    'E2015'. ('10768.2')
    'E2016'. ('10768.1')
    'E2018'. ('51.1', '1891.1')
    'E2019'. ('51.1', '1962.1')
    'E2020'. ('5205.1')
    'E2021'. ('57198.1')
    'E2022'. ('23250.1')
    'E2023'. ('286410.1')
    'E2024'. ('5243.1')
    'E2025'. ('55856.1')
    'E2026'. ('7350.1')
    'E2027'. ('26027.1')
    'E2028'. ('10058.1')
    'E2029'. ('51458.1')
    'E2030'. ('6520.1', '9056.1')
    'E2031'. ('949.1')
    'E2032'. ('948.1')
    'E2033'. ('29881.1')
    'E2034'. ('10928.1')
    'E2035'. ('1728.1')
    'E2037'. ('125981.1')
    'E2038'. ('55331.1')
    'E2039'. ('340485.1')
    'E2044'. ('57704.1')
    'E2048'. ('5476.1', '2720.1', '2588.1', '4758.1')
    'E2049'. ('4759.1')
    'E2050'. ('10825.1')
    'E2051'. ('4758.1')
    'E2053'. ('3991.1')
    'E2054'. ('9388.1')
    'E2055'. ('13.1')
    'E2056'. ('747.1')
    'E2057'. ('221955.1')
    'E2058'. ('5408.1')
    'E2059'. ('5406.1')
    'E2060'. ('57104.1')
    'E2061'. ('8513.1')
    'E2062'. ('5407.1')
    'E2063'. ('119548.1')
    'E2064'. ('2170.1')
    'E2065'. ('2169.1')
    'E2066'. ('2173.1')
    'E2067'. ('2171.1')
    'E2068'. ('2172.1')
    'E2069'. ('2167.1')
    'E2070'. ('646486.1')
    'E2071'. ('646480.1')
    'E2072'. ('6296.1')
    'E2073'. ('348158.1')
    'E2074'. ('54988.1')
    'E2075'. ('123876.1')
    'E2076'. ('341392.1')
    'E2077'. ('344967.1')
    'E2078'. ('51099.1')
    'E2079'. ('154141.1')
    'E2080'. ('253558.1')
    'E2081'. ('9663.1')
    'E2082'. ('64748.1')
    'E2083'. ('9890.1')
    'E2084'. ('79948.1')
    'E2085'. ('64900.1')
    'E2086'. ('23175.1')
    'E2087'. ('84513.1')
    'E2088'. ('196051.1')
    'E2089'. ('85465.1')
    'E2090'. ('23646.1')
    'E2091'. ('122618.1')
    'E2092'. ('201164.1')
    'E2093'. ('590.1')
    'E2094'. ('55750.1')
    'E2095'. ('79603.1')
    'E2096'. ('91012.1')
    'E2097'. ('29956.1')
    'E2098'. ('204219.1')
    'E2099'. ('253782.1')
    'E2100'. ('10715.1')
    'E2101'. ('56624.1')
    'E2102'. ('55830.1')
    'E2103'. ('55624.1')
    'E2104'. ('55757.1')
    'E2105'. ('168391.1')
    'E2106'. ('83468.1')
    'E2107'. ('8702.1')
    'E2108'. ('140687.1')
    'E2109'. ('3703.1')
    'E2110'. ('56886.1')
    'E2111'. ('283358.1')
    'E2112'. ('93183.1')
    'E2113'. ('8473.1')
    'E2114'. ('8707.1')
    'E2115'. ('148789.1')
    'E2116'. ('56983.1')
    'E2117'. ('201595.1')
    'E2118'. ('124872.1')
    'E2119'. ('146664.1')
    'E2120'. ('8708.1')
    'E2121'. ('84750.1')
    'E2122'. ('2529.1')
    'E2123'. ('338707.1')
    'E2124'. ('145173.1')
    'E2125'. ('200810.1')
    'E2126'. ('2526.1')
    'E2127'. ('170384.1')
    'E2128'. ('360203.1')
    'E2129'. ('152586.1')
    'E2130'. ('644378.1')
    'E2131'. ('84752.1')
    'E2132'. ('644974.1')
    'E2134'. ('284004.1')
    'E2135'. ('79411.1')
    'E2136'. ('27090.1')
    'E2137'. ('129807.1')
    'E2139'. ('2524.1')
    'E2140'. ('2527.1')
    'E2141'. ('2528.1')
    'E2142'. ('113612.1')
    'E2143'. ('493869.1')
    'E2144'. ('64180.1')
    'E2145'. ('64174.1')
    'E2146'. ('10728.1')
    'E2149'. ('8644.1')
    'E2150'. ('10826.1')
    'E2151'. ('266740.1')
    'E2152'. ('3930.1')
    'E2153'. ('4645.1')
    'E2154'. ('3069.1')
    'E2155'. ('4864.1')
    'E2158'. ('1646.1')
    'E2159'. ('8630.1')
    'E2160'. ('158160.1')
    'E2161'. ('51144.1')
    'E2162'. ('51170.1')
    'E2163'. ('64834.1')
    'E2164'. ('83401.1')
    'E2165'. ('79993.1')
    'E2166'. ('51495.1')
    'E2167'. ('192286.1')
    'E2168'. ('9200.1')
    'E2169'. ('401494.1')
    'E2170'. ('201562.1')
    'E2171'. ('9524.1')
    'E2172'. ('253017.1')
    'E2174'. ('3995.1')
    'E2175'. ('1155.1')
    'E2176'. ('114571.1')
    'E2177'. ('123096.1')
    'E2178'. ('57016.1')
    'E2185'. ('93650.1')
    'E2186'. ('92370.1')
    'E2187'. ('390928.1')
    'E2190'. ('8974.1')
    'E2191'. ('5033.1')
    'E2192'. ('283208.1')
    'E2193'. ('8041.1')
    'E2199'. ('1738.1')
    'E2200'. ('9108.1')
    'E2201'. ('29085.1')
    'E2202'. ('55613.1')
    'E2203'. ('23371.1')
    'E2204'. ('51559.1')
    'E2205'. ('9896.1')
    'E2206'. ('163404.1')
    'E2207'. ('51496.1')
    'E2208'. ('374462.1')
    'E2209'. ('9107.1')
    'E2210'. ('8446.1')
    'E2211'. ('138639.1')
    'E2212'. ('84814.1')
    'E2213'. ('64419.1')
    'E2214'. ('23203.1')
    'E2215'. ('22876.1')
    'E2216'. ('403313.1')
    'E2217'. ('22908.1')
    'E2218'. ('145553.1')
    'E2219'. ('9562.1')
    'E2221'. ('138429.1')
    'E2222'. ('10170.1')
    'E2223'. ('9249.1')
    'E2224'. ('220074.1')
    'E2225'. ('1735.1')
    'E2226'. ('1734.1')
    'E2227'. ('1733.1')
    'E2228'. ('27284.1')
    'E2229'. ('6819.1')
    'E2230'. ('84274.1')
    'E2231'. ('55904.1')
    'E2232'. ('58508.1')
    'E2233'. ('9739.1')
    'E2234'. ('6839.1')
    'E2235'. ('84444.1')
    'E2236'. ('9757.1')
    'E2237'. ('7468.1')
    'E2238'. ('51111.1')
    'E2239'. ('55870.1')
    'E2240'. ('4297.1')
    'E2241'. ('84787.1')
    'E2242'. ('83852.1')
    'E2243'. ('23067.1')
    'E2244'. ('9869.1')
    'E2245'. ('80854.1')
    'E2246'. ('54904.1')
    'E2247'. ('79723.1')
    'E2248'. ('64324.1')
    'E2249'. ('8085.1')
    'E2250'. ('6419.1')
    'E2251'. ('79813.1')
    'E2252'. ('29072.1')
    'E2253'. ('387893.1')
    'E2254'. ('64754.1')
    'E2255'. ('10919.1')
    'E2256'. ('28972.1')
    'E2257'. ('9789.1')
    'E2258'. ('60559.1')
    'E2259'. ('23478.1')
    'E2260'. ('90701.1')
    'E2262'. ('4249.1')
    'E2263'. ('25834.1')
    'E2266'. ('23262.1')
    'E2267'. ('9677.1')
    'E2270'. ('5281.1')
    'E2271'. ('54872.1')
    'E2273'. ('221223.1')
    'E2274'. ('23491.1')
    'E2275'. ('1066.1')
    'E2276'. ('56301.1')
    'E2282'. ('123688.1')
    'E2297'. ('85007.1')
    'E2300'. ('123264.1')
    'E2301'. ('200931.1')
    'E2302'. ('10941.1')
    'E2303'. ('79799.1')
    'E2304'. ('0')
    'E2305'. ('5446.1')
    'E2306'. ('7384.1', '7388.1', '4519.1', '29796.1', '10975.1', '7385.1',
              '1537.1', '7386.1', '27089.1', '7381.1')
    'E2307'. ('9016.1')
    'E2308'. ('7352.2')
    'E2309'. ('7352.1')
    'E2310'. ('7351.1')
    'E2311'. ('9016.2')
    'E2312'. ('9481.1')
    'E2315'. ('1351.1', '1347.1', '1329.1', '1327.1', '341947.1', '9167.1',
              '1350.1', '4512.1', '1349.1', '1339.1', '1345.1', '4513.1',
              '9377.1', '125965.1', '4514.1', '170712.1', '1346.1', '1340.1',
              '84701.1', '1337.1')
    'E2316'. ('7384.1', '7388.1', '4519.1', '10975.1', '7385.1', '1537.1',
              '7386.1', '27089.1', '7381.1', '1351.1', '1347.1', '1329.1',
              '1327.1', '341947.1', '1350.1', '1349.1', '1339.1', '1345.1',
              '9377.1', '170712.1', '1340.1', '1337.1', '29796.2')
    'E2317'. ('7384.1', '7388.1', '4519.1', '29796.1', '10975.1', '7385.1',
              '1537.1', '7386.1', '27089.1', '7381.1', '1351.1', '1347.1',
              '1329.1', '1327.1', '341947.1', '1350.1', '1349.1', '1339.1',
              '1345.1', '9377.1', '170712.1', '1340.1', '1337.1')
    'E2318'. ('9810.1', '56254.1')
    'E2319'. ('10054.1', '10055.1')
    'E2320'. ('6045.1', '6015.1')
    'E2321'. ('23072.1')
    'E2322'. ('23077.1')
    'E2323'. ('29116.1')
    'E2324'. ('9690.1')
    'E2325'. ('54476.1')
    'E2326'. ('55148.1')
    'E2327'. ('9604.1')
    'E2328'. ('23304.1')
    'E2329'. ('55236.1')
    'E2330'. ('25897.1')
    'E2331'. ('23327.1')
    'E2332'. ('4734.1')
    'E2333'. ('55658.1')
    'E2334'. ('56852.1')
    'E2335'. ('6596.1')
    'E2336'. ('7321.1')
    'E2337'. ('55743.1')
    'E2338'. ('23609.1')
    'E2339'. ('29089.1')
    'E2340'. ('7319.1')
    'E2341'. ('3093.1')
    'E2342'. ('83737.1')
    'E2343'. ('51619.1')
    'E2344'. ('4850.1')
    'E2345'. ('11342.1')
    'E2346'. ('57531.1')
    'E2347'. ('10075.1')
    'E2348'. ('8315.1')
    'E2349'. ('79594.1')
    'E2350'. ('55072.1')
    'E2351'. ('25831.1')
    'E2352'. ('51257.1')
    'E2353'. ('997.1')
    'E2354'. ('57820.1')
    'E2355'. ('54941.1')
    'E2356'. ('57534.1')
    'E2357'. ('4281.1')
    'E2358'. ('23295.1')
    'E2359'. ('10273.1')
    'E2360'. ('7329.1')
    'E2361'. ('8925.1')
    'E2362'. ('55284.1')
    'E2363'. ('51366.1')
    'E2364'. ('79872.1')
    'E2365'. ('4899.1')
    'E2366'. ('54926.1')
    'E2367'. ('9148.1')
    'E2368'. ('27338.1')
    'E2369'. ('26001.1')
    'E2370'. ('64750.1')
    'E2371'. ('7323.1')
    'E2372'. ('9354.1')
    'E2373'. ('867.1')
    'E2374'. ('9025.1')
    'E2375'. ('55819.1')
    'E2376'. ('7337.1')
    'E2377'. ('868.1')
    'E2378'. ('55120.1')
    'E2379'. ('57448.1')
    'E2380'. ('127544.1')
    'E2381'. ('81847.1')
    'E2382'. ('7320.1')
    'E2383'. ('22954.1')
    'E2384'. ('5930.1')
    'E2385'. ('11059.1')
    'E2386'. ('79654.1')
    'E2387'. ('23352.1')
    'E2388'. ('8924.1')
    'E2389'. ('9040.1')
    'E2390'. ('10277.1')
    'E2391'. ('7317.1')
    'E2392'. ('7322.1')
    'E2393'. ('84231.1')
    'E2394'. ('85363.1')
    'E2395'. ('7326.1')
    'E2396'. ('79589.1')
    'E2397'. ('23608.1')
    'E2398'. ('51444.1')
    'E2399'. ('4193.1')
    'E2400'. ('64844.1')
    'E2401'. ('255488.1')
    'E2402'. ('580.1')
    'E2403'. ('57520.1')
    'E2404'. ('8916.1')
    'E2405'. ('91445.1')
    'E2406'. ('92979.1')
    'E2407'. ('92912.1')
    'E2408'. ('23624.1')
    'E2409'. ('64326.1')
    'E2410'. ('130507.1')
    'E2411'. ('57574.1')
    'E2412'. ('9039.1')
    'E2413'. ('55016.1')
    'E2414'. ('10299.1')
    'E2415'. ('154214.1')
    'E2416'. ('257218.1')
    'E2417'. ('115426.1')
    'E2418'. ('90678.1')
    'E2419'. ('26091.1')
    'E2420'. ('89910.1')
    'E2421'. ('9781.1')
    'E2422'. ('9320.1')
    'E2423'. ('81559.1')
    'E2424'. ('57630.1')
    'E2425'. ('153769.1')
    'E2426'. ('9246.1')
    'E2427'. ('84676.1')
    'E2428'. ('65264.1')
    'E2429'. ('197131.1')
    'E2430'. ('267.1')
    'E2431'. ('118424.1')
    'E2432'. ('55585.1')
    'E2433'. ('84447.1')
    'E2434'. ('151112.1')
    'E2435'. ('284996.1')
    'E2436'. ('64320.1')
    'E2437'. ('25898.1')
    'E2438'. ('63891.1')
    'E2439'. ('285671.1')
    'E2440'. ('143279.1')
    'E2441'. ('220972.1')
    'E2442'. ('5896.1')
    'E2443'. ('149603.1')
    'E2444'. ('55159.1')
    'E2445'. ('10477.1')
    'E2446'. ('7324.1')
    'E2447'. ('11236.1')
    'E2448'. ('344558.1')
    'E2449'. ('162333.1')
    'E2450'. ('115123.1')
    'E2451'. ('11065.1')
    'E2452'. ('158506.1')
    'E2453'. ('63893.1')
    'E2454'. ('220441.1')
    'E2455'. ('148581.1')
    'E2456'. ('7334.1')
    'E2457'. ('7681.1')
    'E2458'. ('223082.1')
    'E2459'. ('221687.1')
    'E2460'. ('64219.1')
    'E2461'. ('6478.1')
    'E2462'. ('10193.1')
    'E2463'. ('7318.1')
    'E2464'. ('7325.1')
    'E2465'. ('7267.1')
    'E2466'. ('441061.1')
    'E2467'. ('140739.1')
    'E2468'. ('7327.1')
    'E2469'. ('5071.1')
    'E2470'. ('7332.1')
    'E2471'. ('84937.1')
    'E2472'. ('7328.1')
    'E2473'. ('378884.1')
    'E2474'. ('168433.1')
    'E2475'. ('6477.1')
    'E2476'. ('51592.1')
    'E2477'. ('142678.1')
    'E2478'. ('10210.1')
    'E2479'. ('54708.1')
    'E2480'. ('11060.1')
    'E2481'. ('57154.1')
    'E2482'. ('51465.1')
    'E2483'. ('9666.1')
    'E2484'. ('9867.1')
    'E2485'. ('6048.1')
    'E2486'. ('54492.1')
    'E2487'. ('134111.1')
    'E2488'. ('7844.1')
    'E2489'. ('27246.1')
    'E2490'. ('29128.1')
    'E2491'. ('389898.1')
    'E2492'. ('58508.1', '9757.1')
    'E2493'. ('58508.1', '8085.1')
    'E2494'. ('28972.1', '9789.1', '60559.1', '23478.1', '90701.1')

********* Non-GPR association ----------
    'ER_10FTHF5GLUtl'.('GR_10FTHF5GLUtl')
    'ER_10FTHF5GLUtm'.('GR_10FTHF5GLUtm')
    'ER_10FTHF6GLUtl'.('GR_10FTHF6GLUtl')
    'ER_10FTHF6GLUtm'.('GR_10FTHF6GLUtm')
    'ER_10FTHF7GLUtl'.('GR_10FTHF7GLUtl')
    'ER_10FTHF7GLUtm'.('GR_10FTHF7GLUtm')
    'ER_10FTHFtl'.('GR_10FTHFtl')
    'ER_10FTHFtm'.('GR_10FTHFtm')
    'ER_24NPHte'.('GR_24NPHte')
    'ER_25HVITD2tin_m'.('GR_25HVITD2tin_m')
    'ER_25HVITD3tin_m'.('GR_25HVITD3tin_m')
    'ER_2DR1PP'.('GR_2DR1PP')
    'ER_2MCITt'.('GR_2MCITt')
    'ER_34DHOXPEGt'.('GR_34DHOXPEGt')
    'ER_35CGMPtn'.('GR_35CGMPtn')
    'ER_3DPHBH1'.('GR_3DPHBH1')
    'ER_3DPHBH2'.('GR_3DPHBH2')
    'ER_3HBCOAHLm'.('GR_3HBCOAHLm')
    'ER_3MLDAt'.('GR_3MLDAt')
    'ER_3MOBt2im'.('GR_3MOBt2im')
    'ER_3MOPt2im'.('GR_3MOPt2im')
    'ER_4ABUTtm'.('GR_4ABUTtm')
    'ER_4HBZCOAFm'.('GR_4HBZCOAFm')
    'ER_4HBZFm'.('GR_4HBZFm')
    'ER_4MOPt2im'.('GR_4MOPt2im')
    'ER_4NPHSFte'.('GR_4NPHSFte')
    'ER_4NPHte'.('GR_4NPHte')
    'ER_5ADTSTSTERONESte'.('GR_5ADTSTSTERONESte')
    'ER_5ADTSTSTERONEte'.('GR_5ADTSTSTERONEte')
    'ER_5AOPtm'.('GR_5AOPtm')
    'ER_5DHFtl'.('GR_5DHFtl')
    'ER_5THFtl'.('GR_5THFtl')
    'ER_5THFtm'.('GR_5THFtm')
    'ER_6DHFtl'.('GR_6DHFtl')
    'ER_6DHFtm'.('GR_6DHFtm')
    'ER_6HTSTSTERONEte'.('GR_6HTSTSTERONEte')
    'ER_6HTSTSTERONEtr'.('GR_6HTSTSTERONEtr')
    'ER_6THFtl'.('GR_6THFtl')
    'ER_6THFtm'.('GR_6THFtm')
    'ER_7DHCHSTEROLtr'.('GR_7DHCHSTEROLtr')
    'ER_7DHFtl'.('GR_7DHFtl')
    'ER_7DHFtm'.('GR_7DHFtm')
    'ER_7THFtl'.('GR_7THFtl')
    'ER_7THFtm'.('GR_7THFtm')
    'ER_AASAD3m'.('GR_AASAD3m')
    'ER_ABTD'.('GR_ABTD')
    'ER_ACACtx'.('GR_ACACtx')
    'ER_ACALDtm'.('GR_ACALDtm')
    'ER_ACCOAtn'.('GR_ACCOAtn')
    'ER_ACGAGBSIDEtg'.('GR_ACGAGBSIDEtg')
    'ER_ACGAGBSIDEtl'.('GR_ACGAGBSIDEtl')
    'ER_ACGALK'.('GR_ACGALK')
    'ER_ACGALK2'.('GR_ACGALK2')
    'ER_ACGALtlg'.('GR_ACGALtlg')
    'ER_ACGALtly'.('GR_ACGALtly')
    'ER_ACGAMtly'.('GR_ACGAMtly')
    'ER_ACGBGBSIDEtg'.('GR_ACGBGBSIDEtg')
    'ER_ACGBGBSIDEtl'.('GR_ACGBGBSIDEtl')
    'ER_ACHtn'.('GR_ACHtn')
    'ER_ACNACNGAL14ACGLCGALGLUSIDEte'.('GR_ACNACNGAL14ACGLCGALGLUSIDEte')
    'ER_ACNACNGALGBSIDEte'.('GR_ACNACNGALGBSIDEte')
    'ER_ACNACNGALGBSIDEtg'.('GR_ACNACNGALGBSIDEtg')
    'ER_ACNAMtn'.('GR_ACNAMtn')
    'ER_ACNGALACGLCGAL14ACGLCGALGLUSIDEte'.('GR_ACNGALACGLCGAL14ACGLCGALGLUSIDEte')
    'ER_ACNGALACGLCGAL14ACGLCGALGLUSIDEtg'.('GR_ACNGALACGLCGAL14ACGLCGALGLUSIDEtg')
    'ER_ACNMLr'.('GR_ACNMLr')
    'ER_ACt2m'.('GR_ACt2m')
    'ER_ACt2r'.('GR_ACt2r')
    'ER_ACtg'.('GR_ACtg')
    'ER_ADCim'.('GR_ADCim')
    'ER_ADNK1m'.('GR_ADNK1m')
    'ER_ADRNCOAtx'.('GR_ADRNCOAtx')
    'ER_ADRNt'.('GR_ADRNt')
    'ER_AFLATOXINte'.('GR_AFLATOXINte')
    'ER_AHCYStr'.('GR_AHCYStr')
    'ER_AKGtp'.('GR_AKGtp')
    'ER_AMETr'.('GR_AMETr')
    'ER_AMPtp'.('GR_AMPtp')
    'ER_ANDRSTRNte'.('GR_ANDRSTRNte')
    'ER_ANDRSTRNtr'.('GR_ANDRSTRNtr')
    'ER_AQCOBALt'.('GR_AQCOBALt')
    'ER_ARAB_Lt'.('GR_ARAB_Lt')
    'ER_ARACHCOAtx'.('GR_ARACHCOAtx')
    'ER_ARACHDCOAtx'.('GR_ARACHDCOAtx')
    'ER_ARACHDtr'.('GR_ARACHDtr')
    'ER_ARACHt'.('GR_ARACHt')
    'ER_R_group_phosphotase_1'.('GR_R_group_phosphotase_1')
    'ER_R_group_phosphotase_3'.('GR_R_group_phosphotase_3')
    'ER_ARTFR208'.('GR_ARTFR208')
    'ER_ARTPLM3'.('GR_ARTPLM3')
    'ER_ASCBOX'.('GR_ASCBOX')
    'ER_ASCBt'.('GR_ASCBt')
    'ER_ASPDxt'.('GR_ASPDxt')
    'ER_ATP1ter'.('GR_ATP1ter')
    'ER_ATP2ter'.('GR_ATP2ter')
    'ER_ATPtn'.('GR_ATPtn')
    'ER_ATPtx'.('GR_ATPtx')
    'ER_B3GALTg'.('GR_B3GALTg')
    'ER_BALAtmr'.('GR_BALAtmr')
    'ER_BHBt'.('GR_BHBt')
    'ER_BHBtm'.('GR_BHBtm')
    'ER_BILDGLCURtr'.('GR_BILDGLCURtr')
    'ER_BILIRUBtr'.('GR_BILIRUBtr')
    'ER_BZt'.('GR_BZt')
    'ER_BZtr'.('GR_BZtr')
    'ER_C226COAtx'.('GR_C226COAtx')
    'ER_C226CRNt'.('GR_C226CRNt')
    'ER_CAROtr'.('GR_CAROtr')
    'ER_CBL2OR'.('GR_CBL2OR')
    'ER_CBPter'.('GR_CBPter')
    'ER_CDPDAGtm'.('GR_CDPDAGtm')
    'ER_CHOLPtg'.('GR_CHOLPtg')
    'ER_CHOLPtl'.('GR_CHOLPtl')
    'ER_CHOLtn'.('GR_CHOLtn')
    'ER_CITMCOAHm'.('GR_CITMCOAHm')
    'ER_CITMCOALm'.('GR_CITMCOALm')
    'ER_CLPNDCOAtx'.('GR_CLPNDCOAtx')
    'ER_CLPNDt'.('GR_CLPNDt')
    'ER_CMPACNAtn'.('GR_CMPACNAtn')
    'ER_CO2ter'.('GR_CO2ter')
    'ER_CO2tg'.('GR_CO2tg')
    'ER_CO2tm'.('GR_CO2tm')
    'ER_CO2tp'.('GR_CO2tp')
    'ER_COAtg'.('GR_COAtg')
    'ER_COAtl'.('GR_COAtl')
    'ER_COAtn'.('GR_COAtn')
    'ER_COAtp'.('GR_COAtp')
    'ER_COAtr'.('GR_COAtr')
    'ER_COQ5m'.('GR_COQ5m')
    'ER_CORE5GTg'.('GR_CORE5GTg')
    'ER_CORE7GTg'.('GR_CORE7GTg')
    'ER_COUCOAFm'.('GR_COUCOAFm')
    'ER_COUMARINte'.('GR_COUMARINte')
    'ER_CRMPte'.('GR_CRMPte')
    'ER_CRNCAR3tp'.('GR_CRNCAR3tp')
    'ER_CRNtx'.('GR_CRNtx')
    'ER_CRTSTRNt'.('GR_CRTSTRNt')
    'ER_CRVNCtr'.('GR_CRVNCtr')
    'ER_CSAPASEly'.('GR_CSAPASEly')
    'ER_CSBPASEly'.('GR_CSBPASEly')
    'ER_CSCPASEly'.('GR_CSCPASEly')
    'ER_CSDPASEly'.('GR_CSDPASEly')
    'ER_CSEPASEly'.('GR_CSEPASEly')
    'ER_CSPG_At'.('GR_CSPG_At')
    'ER_CSPG_Atly'.('GR_CSPG_Atly')
    'ER_CSPG_Btly'.('GR_CSPG_Btly')
    'ER_CSPG_Ct'.('GR_CSPG_Ct')
    'ER_CSPG_Ctly'.('GR_CSPG_Ctly')
    'ER_CSPG_Dt'.('GR_CSPG_Dt')
    'ER_CSPG_Dtly'.('GR_CSPG_Dtly')
    'ER_CSPG_Et'.('GR_CSPG_Et')
    'ER_CSPG_Etly'.('GR_CSPG_Etly')
    'ER_CTPtn'.('GR_CTPtn')
    'ER_CYSGLTH'.('GR_CYSGLTH')
    'ER_CYTDK2m'.('GR_CYTDK2m')
    'ER_D_3AIBt'.('GR_D_3AIBt')
    'ER_DADNK'.('GR_DADNK')
    'ER_DAG_HSter'.('GR_DAG_HSter')
    'ER_DAGt'.('GR_DAGt')
    'ER_DALAxt'.('GR_DALAxt')
    'ER_DATPtn'.('GR_DATPtn')
    'ER_DCK1m'.('GR_DCK1m')
    'ER_DCSPTN1COAtx'.('GR_DCSPTN1COAtx')
    'ER_DCSPTN1t'.('GR_DCSPTN1t')
    'ER_DCTPtn'.('GR_DCTPtn')
    'ER_DECDPtm'.('GR_DECDPtm')
    'ER_DEDOLP1_L'.('GR_DEDOLP1_L')
    'ER_DEDOLP2_L'.('GR_DEDOLP2_L')
    'ER_DEDOLR_L'.('GR_DEDOLR_L')
    'ER_DESAT22_1p'.('GR_DESAT22_1p')
    'ER_DESAT22_2p'.('GR_DESAT22_2p')
    'ER_DGCHOLte'.('GR_DGCHOLte')
    'ER_DGCHOLtx'.('GR_DGCHOLtx')
    'ER_DGK2m'.('GR_DGK2m')
    'ER_DGSNtm'.('GR_DGSNtm')
    'ER_DGTPtn'.('GR_DGTPtn')
    'ER_DGULND'.('GR_DGULND')
    'ER_DHEAStr'.('GR_DHEAStr')
    'ER_DHEAtr'.('GR_DHEAtr')
    'ER_DHFtl'.('GR_DHFtl')
    'ER_DHFtm'.('GR_DHFtm')
    'ER_DHPR2'.('GR_DHPR2')
    'ER_DIGALSIDEtl'.('GR_DIGALSIDEtl')
    'ER_DKMPPD'.('GR_DKMPPD')
    'ER_DM_Asn_X_Ser_Thr_ly_'.('GR_DM_Asn_X_Ser_Thr_ly_')
    'ER_DM_core5_g_'.('GR_DM_core5_g_')
    'ER_DM_core7_g_'.('GR_DM_core7_g_')
    'ER_DM_datp_m_'.('GR_DM_datp_m_')
    'ER_DM_datp_n_'.('GR_DM_datp_n_')
    'ER_DM_dctp_m_'.('GR_DM_dctp_m_')
    'ER_DM_dctp_n_'.('GR_DM_dctp_n_')
    'ER_DM_dem2emgacpail_prot_hs_r_'.('GR_DM_dem2emgacpail_prot_hs_r_')
    'ER_DM_dgpi_prot_hs_r_'.('GR_DM_dgpi_prot_hs_r_')
    'ER_DM_dgtp_m_'.('GR_DM_dgtp_m_')
    'ER_DM_dgtp_n_'.('GR_DM_dgtp_n_')
    'ER_DM_dttp_m_'.('GR_DM_dttp_m_')
    'ER_DM_dttp_n_'.('GR_DM_dttp_n_')
    'ER_DM_ethamp_r_'.('GR_DM_ethamp_r_')
    'ER_DM_gncore2_g_'.('GR_DM_gncore2_g_')
    'ER_DM_gpi_sig_er_'.('GR_DM_gpi_sig_er_')
    'ER_DM_kdn_c_'.('GR_DM_kdn_c_')
    'ER_DM_mem2emgacpail_prot_hs_r_'.('GR_DM_mem2emgacpail_prot_hs_r_')
    'ER_DM_Ser_Thr_ly_'.('GR_DM_Ser_Thr_ly_')
    'ER_DM_Ser_Gly_Ala_X_Gly_ly_'.('GR_DM_Ser_Gly_Ala_X_Gly_ly_')
    'ER_DM_sprm_c_'.('GR_DM_sprm_c_')
    'ER_DM_T_antigen_g_'.('GR_DM_T_antigen_g_')
    'ER_DMHPTCRNt'.('GR_DMHPTCRNt')
    'ER_DMHPTCRNte'.('GR_DMHPTCRNte')
    'ER_DMNONCOACRNCPT1'.('GR_DMNONCOACRNCPT1')
    'ER_DMNONCRNt'.('GR_DMNONCRNt')
    'ER_DNADtn'.('GR_DNADtn')
    'ER_DOLMANP_Uter'.('GR_DOLMANP_Uter')
    'ER_DOLPMT4_Uer'.('GR_DOLPMT4_Uer')
    'ER_DOPASFt'.('GR_DOPASFt')
    'ER_DPCOAtl'.('GR_DPCOAtl')
    'ER_DPHMBDCm'.('GR_DPHMBDCm')
    'ER_DPPS'.('GR_DPPS')
    'ER_DRIBt'.('GR_DRIBt')
    'ER_DSAT'.('GR_DSAT')
    'ER_DTDPtn'.('GR_DTDPtn')
    'ER_DTTPtn'.('GR_DTTPtn')
    'ER_EAFLATOXINte'.('GR_EAFLATOXINte')
    'ER_EBASTINEOHte'.('GR_EBASTINEOHte')
    'ER_EBASTINEOHtr'.('GR_EBASTINEOHtr')
    'ER_EBASTINEte'.('GR_EBASTINEte')
    'ER_EBASTINEtr'.('GR_EBASTINEtr')
    'ER_EICOSTETt'.('GR_EICOSTETt')
    'ER_ENGASE2ly'.('GR_ENGASE2ly')
    'ER_ENGASE3ly'.('GR_ENGASE3ly')
    'ER_ESTRADIOLt'.('GR_ESTRADIOLt')
    'ER_ESTRADIOLtr'.('GR_ESTRADIOLtr')
    'ER_ESTRIOLtr'.('GR_ESTRIOLtr')
    'ER_ESTRONEtr'.('GR_ESTRONEtr')
    'ER_EX_10fthf[e]'.('GR_EX_10fthf[e]')
    'ER_EX_10fthf5glu[e]'.('GR_EX_10fthf5glu[e]')
    'ER_EX_10fthf6glu[e]'.('GR_EX_10fthf6glu[e]')
    'ER_EX_10fthf7glu[e]'.('GR_EX_10fthf7glu[e]')
    'ER_EX_13_cis_retnglc[e]'.('GR_EX_13_cis_retnglc[e]')
    'ER_EX_24nph[e]'.('GR_EX_24nph[e]')
    'ER_EX_2hb[e]'.('GR_EX_2hb[e]')
    'ER_EX_2mcit[e]'.('GR_EX_2mcit[e]')
    'ER_EX_34dhoxpeg[e]'.('GR_EX_34dhoxpeg[e]')
    'ER_EX_35cgmp[e]'.('GR_EX_35cgmp[e]')
    'ER_EX_3aib[e]'.('GR_EX_3aib[e]')
    'ER_EX_3aib_D[e]'.('GR_EX_3aib_D[e]')
    'ER_EX_3mlda[e]'.('GR_EX_3mlda[e]')
    'ER_EX_4nph[e]'.('GR_EX_4nph[e]')
    'ER_EX_4nphsf[e]'.('GR_EX_4nphsf[e]')
    'ER_EX_5adtststerone[e]'.('GR_EX_5adtststerone[e]')
    'ER_EX_5adtststerones[e]'.('GR_EX_5adtststerones[e]')
    'ER_EX_5dhf[e]'.('GR_EX_5dhf[e]')
    'ER_EX_5fthf[e]'.('GR_EX_5fthf[e]')
    'ER_EX_5htrp[e]'.('GR_EX_5htrp[e]')
    'ER_EX_5mthf[e]'.('GR_EX_5mthf[e]')
    'ER_EX_5thf[e]'.('GR_EX_5thf[e]')
    'ER_EX_6dhf[e]'.('GR_EX_6dhf[e]')
    'ER_EX_6htststerone[e]'.('GR_EX_6htststerone[e]')
    'ER_EX_6thf[e]'.('GR_EX_6thf[e]')
    'ER_EX_7dhf[e]'.('GR_EX_7dhf[e]')
    'ER_EX_7thf[e]'.('GR_EX_7thf[e]')
    'ER_EX_acetone[e]'.('GR_EX_acetone[e]')
    'ER_EX_ach[e]'.('GR_EX_ach[e]')
    'ER_EX_acnacngal14acglcgalgluside_hs[e]'.('GR_EX_acnacngal14acglcgalgluside_hs[e]')
    'ER_EX_acnacngalgbside_hs[e]'.('GR_EX_acnacngalgbside_hs[e]')
    'ER_EX_acngalacglcgal14acglcgalgluside_hs[e]'.('GR_EX_acngalacglcgal14acglcgalgluside_hs[e]')
    'ER_EX_adp[e]'.('GR_EX_adp[e]')
    'ER_EX_adprbp[e]'.('GR_EX_adprbp[e]')
    'ER_EX_adrn[e]'.('GR_EX_adrn[e]')
    'ER_EX_adrnl[e]'.('GR_EX_adrnl[e]')
    'ER_EX_aflatoxin[e]'.('GR_EX_aflatoxin[e]')
    'ER_EX_ala_B[e]'.('GR_EX_ala_B[e]')
    'ER_EX_ala_D[e]'.('GR_EX_ala_D[e]')
    'ER_EX_amp[e]'.('GR_EX_amp[e]')
    'ER_EX_andrstrn[e]'.('GR_EX_andrstrn[e]')
    'ER_EX_aprgstrn[e]'.('GR_EX_aprgstrn[e]')
    'ER_EX_aqcobal[e]'.('GR_EX_aqcobal[e]')
    'ER_EX_arach[e]'.('GR_EX_arach[e]')
    'ER_EX_arachd[e]'.('GR_EX_arachd[e]')
    'ER_EX_ascb_L[e]'.('GR_EX_ascb_L[e]')
    'ER_EX_asp_D[e]'.('GR_EX_asp_D[e]')
    'ER_EX_atp[e]'.('GR_EX_atp[e]')
    'ER_EX_avite1[e]'.('GR_EX_avite1[e]')
    'ER_EX_bhb[e]'.('GR_EX_bhb[e]')
    'ER_EX_bildglcur[e]'.('GR_EX_bildglcur[e]')
    'ER_EX_bilglcur[e]'.('GR_EX_bilglcur[e]')
    'ER_EX_bilirub[e]'.('GR_EX_bilirub[e]')
    'ER_EX_camp[e]'.('GR_EX_camp[e]')
    'ER_EX_caro[e]'.('GR_EX_caro[e]')
    'ER_EX_chol[e]'.('GR_EX_chol[e]')
    'ER_EX_cholate[e]'.('GR_EX_cholate[e]')
    'ER_EX_chsterol[e]'.('GR_EX_chsterol[e]')
    'ER_EX_chtn[e]'.('GR_EX_chtn[e]')
    'ER_EX_clpnd[e]'.('GR_EX_clpnd[e]')
    'ER_EX_cmp[e]'.('GR_EX_cmp[e]')
    'ER_EX_coumarin[e]'.('GR_EX_coumarin[e]')
    'ER_EX_creat[e]'.('GR_EX_creat[e]')
    'ER_EX_crmp_hs[e]'.('GR_EX_crmp_hs[e]')
    'ER_EX_crn[e]'.('GR_EX_crn[e]')
    'ER_EX_crtstrn[e]'.('GR_EX_crtstrn[e]')
    'ER_EX_crvnc[e]'.('GR_EX_crvnc[e]')
    'ER_EX_cspg_a[e]'.('GR_EX_cspg_a[e]')
    'ER_EX_cspg_b[e]'.('GR_EX_cspg_b[e]')
    'ER_EX_cspg_c[e]'.('GR_EX_cspg_c[e]')
    'ER_EX_cspg_d[e]'.('GR_EX_cspg_d[e]')
    'ER_EX_cspg_e[e]'.('GR_EX_cspg_e[e]')
    'ER_EX_dag_hs[e]'.('GR_EX_dag_hs[e]')
    'ER_EX_dcsptn1[e]'.('GR_EX_dcsptn1[e]')
    'ER_EX_dgchol[e]'.('GR_EX_dgchol[e]')
    'ER_EX_dhdascb[e]'.('GR_EX_dhdascb[e]')
    'ER_EX_dheas[e]'.('GR_EX_dheas[e]')
    'ER_EX_dhf[e]'.('GR_EX_dhf[e]')
    'ER_EX_dlnlcg[e]'.('GR_EX_dlnlcg[e]')
    'ER_EX_dmhptcrn[e]'.('GR_EX_dmhptcrn[e]')
    'ER_EX_dopa[e]'.('GR_EX_dopa[e]')
    'ER_EX_dopasf[e]'.('GR_EX_dopasf[e]')
    'ER_EX_eaflatoxin[e]'.('GR_EX_eaflatoxin[e]')
    'ER_EX_ebastine[e]'.('GR_EX_ebastine[e]')
    'ER_EX_ebastineoh[e]'.('GR_EX_ebastineoh[e]')
    'ER_EX_eicostet[e]'.('GR_EX_eicostet[e]')
    'ER_EX_elaid[e]'.('GR_EX_elaid[e]')
    'ER_EX_estradiol[e]'.('GR_EX_estradiol[e]')
    'ER_EX_estrones[e]'.('GR_EX_estrones[e]')
    'ER_EX_fuc13galacglcgal14acglcgalgluside_hs[e]'.('GR_EX_fuc13galacglcgal14acglcgalgluside_hs[e]')
    'ER_EX_fuc14galacglcgalgluside_hs[e]'.('GR_EX_fuc14galacglcgalgluside_hs[e]')
    'ER_EX_fucacgalfucgalacglcgalgluside_hs[e]'.('GR_EX_fucacgalfucgalacglcgalgluside_hs[e]')
    'ER_EX_fucfuc12gal14acglcgalgluside_hs[e]'.('GR_EX_fucfuc12gal14acglcgalgluside_hs[e]')
    'ER_EX_fucfucfucgalacglc13galacglcgal14acglcgalgluside_hs[e]'.('GR_EX_fucfucfucgalacglc13galacglcgal14acglcgalgluside_hs[e]')
    'ER_EX_fucfucgalacglcgalgluside_hs[e]'.('GR_EX_fucfucgalacglcgalgluside_hs[e]')
    'ER_EX_fucgal14acglcgalgluside_hs[e]'.('GR_EX_fucgal14acglcgalgluside_hs[e]')
    'ER_EX_fucgalfucgalacglcgalgluside_hs[e]'.('GR_EX_fucgalfucgalacglcgalgluside_hs[e]')
    'ER_EX_fuc_L[e]'.('GR_EX_fuc_L[e]')
    'ER_EX_galacglcgalgbside_hs[e]'.('GR_EX_galacglcgalgbside_hs[e]')
    'ER_EX_galgalfucfucgalacglcgalacglcgal14acglcgalgluside_hs[e]'.('GR_EX_galgalfucfucgalacglcgalacglcgal14acglcgalgluside_hs[e]')
    'ER_EX_galgalgalthcrm_hs[e]'.('GR_EX_galgalgalthcrm_hs[e]')
    'ER_EX_gbside_hs[e]'.('GR_EX_gbside_hs[e]')
    'ER_EX_gchola[e]'.('GR_EX_gchola[e]')
    'ER_EX_gdp[e]'.('GR_EX_gdp[e]')
    'ER_EX_gluala[e]'.('GR_EX_gluala[e]')
    'ER_EX_glyc_S[e]'.('GR_EX_glyc_S[e]')
    'ER_EX_glygn2[e]'.('GR_EX_glygn2[e]')
    'ER_EX_glygn4[e]'.('GR_EX_glygn4[e]')
    'ER_EX_glygn5[e]'.('GR_EX_glygn5[e]')
    'ER_EX_gmp[e]'.('GR_EX_gmp[e]')
    'ER_EX_gq1b_hs[e]'.('GR_EX_gq1b_hs[e]')
    'ER_EX_gsn[e]'.('GR_EX_gsn[e]')
    'ER_EX_gt1a_hs[e]'.('GR_EX_gt1a_hs[e]')
    'ER_EX_gthox[e]'.('GR_EX_gthox[e]')
    'ER_EX_gthrd[e]'.('GR_EX_gthrd[e]')
    'ER_EX_gtp[e]'.('GR_EX_gtp[e]')
    'ER_EX_h2o2[e]'.('GR_EX_h2o2[e]')
    'ER_EX_ha[e]'.('GR_EX_ha[e]')
    'ER_EX_ha_pre1[e]'.('GR_EX_ha_pre1[e]')
    'ER_EX_hco3[e]'.('GR_EX_hco3[e]')
    'ER_EX_hcoumarin[e]'.('GR_EX_hcoumarin[e]')
    'ER_EX_hdca[e]'.('GR_EX_hdca[e]')
    'ER_EX_hdcea[e]'.('GR_EX_hdcea[e]')
    'ER_EX_hestratriol[e]'.('GR_EX_hestratriol[e]')
    'ER_EX_hexc[e]'.('GR_EX_hexc[e]')
    'ER_EX_hista[e]'.('GR_EX_hista[e]')
    'ER_EX_hom_L[e]'.('GR_EX_hom_L[e]')
    'ER_EX_hpdca[e]'.('GR_EX_hpdca[e]')
    'ER_EX_hspg[e]'.('GR_EX_hspg[e]')
    'ER_EX_htaxol[e]'.('GR_EX_htaxol[e]')
    'ER_EX_i[e]'.('GR_EX_i[e]')
    'ER_EX_idp[e]'.('GR_EX_idp[e]')
    'ER_EX_imp[e]'.('GR_EX_imp[e]')
    'ER_EX_ksi[e]'.('GR_EX_ksi[e]')
    'ER_EX_ksi_deg1[e]'.('GR_EX_ksi_deg1[e]')
    'ER_EX_ksii_core2[e]'.('GR_EX_ksii_core2[e]')
    'ER_EX_ksii_core4[e]'.('GR_EX_ksii_core4[e]')
    'ER_EX_lac_D[e]'.('GR_EX_lac_D[e]')
    'ER_EX_Lcystin[e]'.('GR_EX_Lcystin[e]')
    'ER_EX_leuktrA4[e]'.('GR_EX_leuktrA4[e]')
    'ER_EX_leuktrB4[e]'.('GR_EX_leuktrB4[e]')
    'ER_EX_leuktrC4[e]'.('GR_EX_leuktrC4[e]')
    'ER_EX_leuktrD4[e]'.('GR_EX_leuktrD4[e]')
    'ER_EX_leuktrE4[e]'.('GR_EX_leuktrE4[e]')
    'ER_EX_leuktrF4[e]'.('GR_EX_leuktrF4[e]')
    'ER_EX_lgnc[e]'.('GR_EX_lgnc[e]')
    'ER_EX_lneldc[e]'.('GR_EX_lneldc[e]')
    'ER_EX_lnlc[e]'.('GR_EX_lnlc[e]')
    'ER_EX_lnlnca[e]'.('GR_EX_lnlnca[e]')
    'ER_EX_lnlncg[e]'.('GR_EX_lnlncg[e]')
    'ER_EX_lpchol_hs[e]'.('GR_EX_lpchol_hs[e]')
    'ER_EX_mag_hs[e]'.('GR_EX_mag_hs[e]')
    'ER_EX_meoh[e]'.('GR_EX_meoh[e]')
    'ER_EX_mthgxl[e]'.('GR_EX_mthgxl[e]')
    'ER_EX_n2m2nmasn[e]'.('GR_EX_n2m2nmasn[e]')
    'ER_EX_nad[e]'.('GR_EX_nad[e]')
    'ER_EX_nadp[e]'.('GR_EX_nadp[e]')
    'ER_EX_ncam[e]'.('GR_EX_ncam[e]')
    'ER_EX_no[e]'.('GR_EX_no[e]')
    'ER_EX_nrpphr[e]'.('GR_EX_nrpphr[e]')
    'ER_EX_nrpphrsf[e]'.('GR_EX_nrpphrsf[e]')
    'ER_EX_nrvnc[e]'.('GR_EX_nrvnc[e]')
    'ER_EX_o2s[e]'.('GR_EX_o2s[e]')
    'ER_EX_oagd3_hs[e]'.('GR_EX_oagd3_hs[e]')
    'ER_EX_oagt3_hs[e]'.('GR_EX_oagt3_hs[e]')
    'ER_EX_ocdca[e]'.('GR_EX_ocdca[e]')
    'ER_EX_ocdcea[e]'.('GR_EX_ocdcea[e]')
    'ER_EX_octa[e]'.('GR_EX_octa[e]')
    'ER_EX_oxa[e]'.('GR_EX_oxa[e]')
    'ER_EX_pchol_hs[e]'.('GR_EX_pchol_hs[e]')
    'ER_EX_pe_hs[e]'.('GR_EX_pe_hs[e]')
    'ER_EX_peplys[e]'.('GR_EX_peplys[e]')
    'ER_EX_pglyc_hs[e]'.('GR_EX_pglyc_hs[e]')
    'ER_EX_phyt[e]'.('GR_EX_phyt[e]')
    'ER_EX_prgstrn[e]'.('GR_EX_prgstrn[e]')
    'ER_EX_prostgd2[e]'.('GR_EX_prostgd2[e]')
    'ER_EX_prostge1[e]'.('GR_EX_prostge1[e]')
    'ER_EX_prostge2[e]'.('GR_EX_prostge2[e]')
    'ER_EX_ps_hs[e]'.('GR_EX_ps_hs[e]')
    'ER_EX_ptdca[e]'.('GR_EX_ptdca[e]')
    'ER_EX_retfa[e]'.('GR_EX_retfa[e]')
    'ER_EX_retinol[e]'.('GR_EX_retinol[e]')
    'ER_EX_retn[e]'.('GR_EX_retn[e]')
    'ER_EX_Rtotal[e]'.('GR_EX_Rtotal[e]')
    'ER_EX_Rtotal2[e]'.('GR_EX_Rtotal2[e]')
    'ER_EX_Rtotal3[e]'.('GR_EX_Rtotal3[e]')
    'ER_EX_s2l2fn2m2masn[e]'.('GR_EX_s2l2fn2m2masn[e]')
    'ER_EX_s2l2n2m2masn[e]'.('GR_EX_s2l2n2m2masn[e]')
    'ER_EX_spc_hs[e]'.('GR_EX_spc_hs[e]')
    'ER_EX_sph1p[e]'.('GR_EX_sph1p[e]')
    'ER_EX_sphs1p[e]'.('GR_EX_sphs1p[e]')
    'ER_EX_srtn[e]'.('GR_EX_srtn[e]')
    'ER_EX_strch1[e]'.('GR_EX_strch1[e]')
    'ER_EX_strch2[e]'.('GR_EX_strch2[e]')
    'ER_EX_strdnc[e]'.('GR_EX_strdnc[e]')
    'ER_EX_tagat_D[e]'.('GR_EX_tagat_D[e]')
    'ER_EX_taxol[e]'.('GR_EX_taxol[e]')
    'ER_EX_tchola[e]'.('GR_EX_tchola[e]')
    'ER_EX_tdchola[e]'.('GR_EX_tdchola[e]')
    'ER_EX_tethex3[e]'.('GR_EX_tethex3[e]')
    'ER_EX_tetpent3[e]'.('GR_EX_tetpent3[e]')
    'ER_EX_tetpent6[e]'.('GR_EX_tetpent6[e]')
    'ER_EX_tettet6[e]'.('GR_EX_tettet6[e]')
    'ER_EX_thf[e]'.('GR_EX_thf[e]')
    'ER_EX_thmtp[e]'.('GR_EX_thmtp[e]')
    'ER_EX_thym[e]'.('GR_EX_thym[e]')
    'ER_EX_thyox_L[e]'.('GR_EX_thyox_L[e]')
    'ER_EX_tmndnc[e]'.('GR_EX_tmndnc[e]')
    'ER_EX_triodthy[e]'.('GR_EX_triodthy[e]')
    'ER_EX_triodthysuf[e]'.('GR_EX_triodthysuf[e]')
    'ER_EX_tststerone[e]'.('GR_EX_tststerone[e]')
    'ER_EX_tststerones[e]'.('GR_EX_tststerones[e]')
    'ER_EX_ttdca[e]'.('GR_EX_ttdca[e]')
    'ER_EX_txa2[e]'.('GR_EX_txa2[e]')
    'ER_EX_Tyr_ggn[e]'.('GR_EX_Tyr_ggn[e]')
    'ER_EX_udp[e]'.('GR_EX_udp[e]')
    'ER_EX_ump[e]'.('GR_EX_ump[e]')
    'ER_EX_urate[e]'.('GR_EX_urate[e]')
    'ER_EX_utp[e]'.('GR_EX_utp[e]')
    'ER_EX_vacc[e]'.('GR_EX_vacc[e]')
    'ER_EX_vitd3[e]'.('GR_EX_vitd3[e]')
    'ER_EX_whhdca[e]'.('GR_EX_whhdca[e]')
    'ER_EX_whtststerone[e]'.('GR_EX_whtststerone[e]')
    'ER_EX_xolest_hs[e]'.('GR_EX_xolest_hs[e]')
    'ER_EX_xolest2_hs[e]'.('GR_EX_xolest2_hs[e]')
    'ER_EX_xoltri24[e]'.('GR_EX_xoltri24[e]')
    'ER_EX_xoltri27[e]'.('GR_EX_xoltri27[e]')
    'ER_EX_xylt[e]'.('GR_EX_xylt[e]')
    'ER_F1Atg'.('GR_F1Atg')
    'ER_FADH2tru'.('GR_FADH2tru')
    'ER_FADH2tx'.('GR_FADH2tx')
    'ER_FADtru'.('GR_FADtru')
    'ER_FADtx'.('GR_FADtx')
    'ER_FALDtly'.('GR_FALDtly')
    'ER_FCOAH'.('GR_FCOAH')
    'ER_FE2t'.('GR_FE2t')
    'ER_FE2tm'.('GR_FE2tm')
    'ER_FORMCOAtx'.('GR_FORMCOAtx')
    'ER_FORt2m'.('GR_FORt2m')
    'ER_FORtr'.('GR_FORtr')
    'ER_FRDPtr'.('GR_FRDPtr')
    'ER_FUC13GALACGLCGAL14ACGLCGALGLUSIDEte'.('GR_FUC13GALACGLCGAL14ACGLCGALGLUSIDEte')
    'ER_FUC13GALACGLCGAL14ACGLCGALGLUSIDEtg'.('GR_FUC13GALACGLCGAL14ACGLCGALGLUSIDEtg')
    'ER_FUC14GALACGLCGALGLUSIDEte'.('GR_FUC14GALACGLCGALGLUSIDEte')
    'ER_FUC14GALACGLCGALGLUSIDEtg'.('GR_FUC14GALACGLCGALGLUSIDEtg')
    'ER_FUCACGALFUCGALACGLCGALGLUSIDEte'.('GR_FUCACGALFUCGALACGLCGALGLUSIDEte')
    'ER_FUCFUC12GAL14ACGLCGALGLUSIDEte'.('GR_FUCFUC12GAL14ACGLCGALGLUSIDEte')
    'ER_FUCFUC12GAL14ACGLCGALGLUSIDEtg'.('GR_FUCFUC12GAL14ACGLCGALGLUSIDEtg')
    'ER_FUCFUCFUCGALACGLC13GALACGLCGAL14ACGLCGALGLUSIDEte'.('GR_FUCFUCFUCGALACGLC13GALACGLCGAL14ACGLCGALGLUSIDEte')
    'ER_FUCFUCFUCGALACGLC13GALACGLCGAL14ACGLCGALGLUSIDEtg'.('GR_FUCFUCFUCGALACGLC13GALACGLCGAL14ACGLCGALGLUSIDEtg')
    'ER_FUCFUCGALACGLCGALGLUSIDEte'.('GR_FUCFUCGALACGLCGALGLUSIDEte')
    'ER_FUCFUCGALACGLCGALGLUSIDEtg'.('GR_FUCFUCGALACGLCGALGLUSIDEtg')
    'ER_FUCGAL14ACGLCGALGLUSIDEte'.('GR_FUCGAL14ACGLCGALGLUSIDEte')
    'ER_FUCGAL14ACGLCGALGLUSIDEtg'.('GR_FUCGAL14ACGLCGALGLUSIDEtg')
    'ER_FUCGALFUCGALACGLCGALGLUSIDEte'.('GR_FUCGALFUCGALACGLCGALGLUSIDEte')
    'ER_FUCtly'.('GR_FUCtly')
    'ER_G5SADrm'.('GR_G5SADrm')
    'ER_GACPAILter'.('GR_GACPAILter')
    'ER_GALACGLCGALGBSIDEte'.('GR_GALACGLCGALGBSIDEte')
    'ER_GALACGLCGALGBSIDEtg'.('GR_GALACGLCGALGBSIDEtg')
    'ER_GALGALFUCFUCGALACGLCGALACGLCGAL14ACGLCGALGLUSIDEte'.('GR_GALGALFUCFUCGALACGLCGALACGLCGAL14ACGLCGALGLUSIDEte')
    'ER_GALGALFUCFUCGALACGLCGALACGLCGAL14ACGLCGALGLUSIDEtg'.('GR_GALGALFUCFUCGALACGLCGALACGLCGAL14ACGLCGALGLUSIDEtg')
    'ER_GALGALGALTHCRMte'.('GR_GALGALGALTHCRMte')
    'ER_GALGALGALTHCRMtg'.('GR_GALGALGALTHCRMtg')
    'ER_GALGLUSIDEtg'.('GR_GALGLUSIDEtg')
    'ER_GALSIDEtl'.('GR_GALSIDEtl')
    'ER_GALtly'.('GR_GALtly')
    'ER_GBSIDEte'.('GR_GBSIDEte')
    'ER_GBSIDEtl'.('GR_GBSIDEtl')
    'ER_GCHOLAte'.('GR_GCHOLAte')
    'ER_GDPtg'.('GR_GDPtg')
    'ER_GGT_L'.('GR_GGT_L')
    'ER_GGT6'.('GR_GGT6')
    'ER_GLACter'.('GR_GLACter')
    'ER_GLCMter'.('GR_GLCMter')
    'ER_GLCter'.('GR_GLCter')
    'ER_GLCtly'.('GR_GLCtly')
    'ER_GLCURter'.('GR_GLCURter')
    'ER_GLNtm'.('GR_GLNtm')
    'ER_GLUt7l'.('GR_GLUt7l')
    'ER_GLXtm'.('GR_GLXtm')
    'ER_GLXtp'.('GR_GLXtp')
    'ER_GLYC3Ptm'.('GR_GLYC3Ptm')
    'ER_GLYCK2'.('GR_GLYCK2')
    'ER_GLYCLTDym'.('GR_GLYCLTDym')
    'ER_GLYCLTtp'.('GR_GLYCLTtp')
    'ER_GLYC_St'.('GR_GLYC_St')
    'ER_GLYCtm'.('GR_GLYCtm')
    'ER_GLYtm'.('GR_GLYtm')
    'ER_GLYtp'.('GR_GLYtp')
    'ER_GMPtg'.('GR_GMPtg')
    'ER_GMPtn'.('GR_GMPtn')
    'ER_GQ1Bte'.('GR_GQ1Bte')
    'ER_GT1Ate'.('GR_GT1Ate')
    'ER_GTHDH'.('GR_GTHDH')
    'ER_GTHRDtr'.('GR_GTHRDtr')
    'ER_GULN3D'.('GR_GULN3D')
    'ER_GULNDer'.('GR_GULNDer')
    'ER_GULNter'.('GR_GULNter')
    'ER_H2O2t'.('GR_H2O2t')
    'ER_H2O2tly'.('GR_H2O2tly')
    'ER_H2O2tm'.('GR_H2O2tm')
    'ER_H2O2tp'.('GR_H2O2tp')
    'ER_H2Oter'.('GR_H2Oter')
    'ER_H2Otg'.('GR_H2Otg')
    'ER_H2Otly'.('GR_H2Otly')
    'ER_H2Otn'.('GR_H2Otn')
    'ER_H2Otp'.('GR_H2Otp')
    'ER_HAtly'.('GR_HAtly')
    'ER_HCOUMARINte'.('GR_HCOUMARINte')
    'ER_HDCAter'.('GR_HDCAter')
    'ER_HDD2COAtx'.('GR_HDD2COAtx')
    'ER_HESTRATRIOLte'.('GR_HESTRATRIOLte')
    'ER_HESTRATRIOLtr'.('GR_HESTRATRIOLtr')
    'ER_HEXCCOAtx'.('GR_HEXCCOAtx')
    'ER_HEXCt'.('GR_HEXCt')
    'ER_HMGCOAtm'.('GR_HMGCOAtm')
    'ER_HMGCOAtx'.('GR_HMGCOAtx')
    'ER_HPDCAt'.('GR_HPDCAt')
    'ER_HPYRDC'.('GR_HPYRDC')
    'ER_HPYRDCm'.('GR_HPYRDCm')
    'ER_HPYRtp'.('GR_HPYRtp')
    'ER_HSAT1ly'.('GR_HSAT1ly')
    'ER_HSAT2ly'.('GR_HSAT2ly')
    'ER_HSAT3ly'.('GR_HSAT3ly')
    'ER_HSAT4ly'.('GR_HSAT4ly')
    'ER_HSPASEly'.('GR_HSPASEly')
    'ER_HSPGt'.('GR_HSPGt')
    'ER_HSPGtly'.('GR_HSPGtly')
    'ER_HTAXOLte'.('GR_HTAXOLte')
    'ER_Htg'.('GR_Htg')
    'ER_Htr'.('GR_Htr')
    'ER_Htx'.('GR_Htx')
    'ER_ILEt5m'.('GR_ILEt5m')
    'ER_IPDPtx'.('GR_IPDPtx')
    'ER_KDNH'.('GR_KDNH')
    'ER_KSII_CORE2t'.('GR_KSII_CORE2t')
    'ER_KSII_CORE2tly'.('GR_KSII_CORE2tly')
    'ER_KSII_CORE4t'.('GR_KSII_CORE4t')
    'ER_KSII_CORE4tly'.('GR_KSII_CORE4tly')
    'ER_KSItly'.('GR_KSItly')
    'ER_KYNATESYN'.('GR_KYNATESYN')
    'ER_LEUKTRB4tr'.('GR_LEUKTRB4tr')
    'ER_LEUKTRD4t'.('GR_LEUKTRD4t')
    'ER_LEUt5m'.('GR_LEUt5m')
    'ER_LGNCCOAtx'.('GR_LGNCCOAtx')
    'ER_LINKDEG1ly'.('GR_LINKDEG1ly')
    'ER_LINKDEG2ly'.('GR_LINKDEG2ly')
    'ER_LINKDEG3ly'.('GR_LINKDEG3ly')
    'ER_LINKDEG4ly'.('GR_LINKDEG4ly')
    'ER_LNELDCt'.('GR_LNELDCt')
    'ER_LPCHOLt'.('GR_LPCHOLt')
    'ER_LTC4CP'.('GR_LTC4CP')
    'ER_LTD4DP'.('GR_LTD4DP')
    'ER_MAGt'.('GR_MAGt')
    'ER_MANtly'.('GR_MANtly')
    'ER_MCITS'.('GR_MCITS')
    'ER_MDRPD'.('GR_MDRPD')
    'ER_MEOHt2'.('GR_MEOHt2')
    'ER_MEOHtly'.('GR_MEOHtly')
    'ER_MGSA'.('GR_MGSA')
    'ER_MGSA2'.('GR_MGSA2')
    'ER_MI134P4P'.('GR_MI134P4P')
    'ER_MI13PP'.('GR_MI13PP')
    'ER_MI14P4P'.('GR_MI14P4P')
    'ER_MINOHPtn'.('GR_MINOHPtn')
    'ER_MTHGXLt'.('GR_MTHGXLt')
    'ER_N2M2NMASNtly'.('GR_N2M2NMASNtly')
    'ER_N4Tg'.('GR_N4Tg')
    'ER_NADHtpu'.('GR_NADHtpu')
    'ER_NADHtru'.('GR_NADHtru')
    'ER_NADPHtru'.('GR_NADPHtru')
    'ER_NADPHtxu'.('GR_NADPHtxu')
    'ER_NADPtru'.('GR_NADPtru')
    'ER_NADPtxu'.('GR_NADPtxu')
    'ER_NADtn'.('GR_NADtn')
    'ER_NADtru'.('GR_NADtru')
    'ER_NAGAlby'.('GR_NAGAlby')
    'ER_NAGLCAly'.('GR_NAGLCAly')
    'ER_NCAMUP'.('GR_NCAMUP')
    'ER_NH4tn'.('GR_NH4tn')
    'ER_NH4tp'.('GR_NH4tp')
    'ER_NICRNS'.('GR_NICRNS')
    'ER_NICRNTtn'.('GR_NICRNTtn')
    'ER_NMNtn'.('GR_NMNtn')
    'ER_NOt'.('GR_NOt')
    'ER_NRPPHRSFt'.('GR_NRPPHRSFt')
    'ER_NRVNCCOAtx'.('GR_NRVNCCOAtx')
    'ER_O2St'.('GR_O2St')
    'ER_O2Stm'.('GR_O2Stm')
    'ER_O2ter'.('GR_O2ter')
    'ER_O2tm'.('GR_O2tm')
    'ER_O2tn'.('GR_O2tn')
    'ER_O2tp'.('GR_O2tp')
    'ER_OAGD3te'.('GR_OAGD3te')
    'ER_OAGD3tg'.('GR_OAGD3tg')
    'ER_OAGT3te'.('GR_OAGT3te')
    'ER_OCCOAtm'.('GR_OCCOAtm')
    'ER_OCCOAtx'.('GR_OCCOAtx')
    'ER_OCTAt'.('GR_OCTAt')
    'ER_ODECOAtx'.('GR_ODECOAtx')
    'ER_OXAtp'.('GR_OXAtp')
    'ER_P450LTB4r'.('GR_P450LTB4r')
    'ER_PAFS'.('GR_PAFS')
    'ER_PAIL_HStn'.('GR_PAIL_HStn')
    'ER_PAIL45P_HStn'.('GR_PAIL45P_HStn')
    'ER_PAIL4P_HStn'.('GR_PAIL4P_HStn')
    'ER_PAN4PP'.('GR_PAN4PP')
    'ER_PAPtg'.('GR_PAPtg')
    'ER_PCHOL_HSter'.('GR_PCHOL_HSter')
    'ER_PCHOL_HStg'.('GR_PCHOL_HStg')
    'ER_PE_HSter'.('GR_PE_HSter')
    'ER_PEt'.('GR_PEt')
    'ER_PGLYCt'.('GR_PGLYCt')
    'ER_PHEMEtm'.('GR_PHEMEtm')
    'ER_PHYTt'.('GR_PHYTt')
    'ER_PI45P4P'.('GR_PI45P4P')
    'ER_PI4P5Kn'.('GR_PI4P5Kn')
    'ER_PI4PP'.('GR_PI4PP')
    'ER_PI5P4Kn'.('GR_PI5P4Kn')
    'ER_PIK3n'.('GR_PIK3n')
    'ER_PIK4n'.('GR_PIK4n')
    'ER_PIK5n'.('GR_PIK5n')
    'ER_PItg'.('GR_PItg')
    'ER_PItn'.('GR_PItn')
    'ER_PMTCOAtx'.('GR_PMTCOAtx')
    'ER_PPAn'.('GR_PPAn')
    'ER_PPAt'.('GR_PPAt')
    'ER_PPAtm'.('GR_PPAtm')
    'ER_PPItr'.('GR_PPItr')
    'ER_PPItx'.('GR_PPItx')
    'ER_PPMI12346Ptn'.('GR_PPMI12346Ptn')
    'ER_PPPG9tm'.('GR_PPPG9tm')
    'ER_PRGSTRNt'.('GR_PRGSTRNt')
    'ER_PRISTANALtx'.('GR_PRISTANALtx')
    'ER_PRISTCOAtx'.('GR_PRISTCOAtx')
    'ER_PRISTtx'.('GR_PRISTtx')
    'ER_PROSTGH2t'.('GR_PROSTGH2t')
    'ER_PROSTGI2t'.('GR_PROSTGI2t')
    'ER_PROtm'.('GR_PROtm')
    'ER_PSt3'.('GR_PSt3')
    'ER_PTDCAt'.('GR_PTDCAt')
    'ER_QUILSYN'.('GR_QUILSYN')
    'ER_RADH'.('GR_RADH')
    'ER_RADH2'.('GR_RADH2')
    'ER_RAI1'.('GR_RAI1')
    'ER_RAI2'.('GR_RAI2')
    'ER_RAtn'.('GR_RAtn')
    'ER_RETHe'.('GR_RETHe')
    'ER_RETI1'.('GR_RETI1')
    'ER_RETI2'.('GR_RETI2')
    'ER_RETI3'.('GR_RETI3')
    'ER_RETNGLCt2'.('GR_RETNGLCt2')
    'ER_RETNGLCt2r'.('GR_RETNGLCt2r')
    'ER_RETNt'.('GR_RETNt')
    'ER_RETNtr2'.('GR_RETNtr2')
    'ER_RIBt'.('GR_RIBt')
    'ER_RIBt2'.('GR_RIBt2')
    'ER_RTOTAL2t'.('GR_RTOTAL2t')
    'ER_RTOTALt'.('GR_RTOTALt')
    'ER_Rtotaltl'.('GR_Rtotaltl')
    'ER_S2L2FN2M2MASNtly'.('GR_S2L2FN2M2MASNtly')
    'ER_S2L2N2M2MASNtly'.('GR_S2L2N2M2MASNtly')
    'ER_S2TASE4ly'.('GR_S2TASE4ly')
    'ER_S2TASE5ly'.('GR_S2TASE5ly')
    'ER_S3TASE1ly'.('GR_S3TASE1ly')
    'ER_S3TASE2ly'.('GR_S3TASE2ly')
    'ER_S3TASE3ly'.('GR_S3TASE3ly')
    'ER_S4T4g'.('GR_S4T4g')
    'ER_S4T5g'.('GR_S4T5g')
    'ER_Ser_Thrtg'.('GR_Ser_Thrtg')
    'ER_SERtp'.('GR_SERtp')
    'ER_sink_citr[c]'.('GR_sink_citr[c]')
    'ER_sink_pre_prot[r]'.('GR_sink_pre_prot[r]')
    'ER_SO4tl'.('GR_SO4tl')
    'ER_SPC_HSt'.('GR_SPC_HSt')
    'ER_SPH1Pte'.('GR_SPH1Pte')
    'ER_SPHINGStl'.('GR_SPHINGStl')
    'ER_SPHMYLNtg'.('GR_SPHMYLNtg')
    'ER_SPHMYLNtl'.('GR_SPHMYLNtl')
    'ER_SPHS1Pte'.('GR_SPHS1Pte')
    'ER_SPMDOX'.('GR_SPMDOX')
    'ER_STCOAtx'.('GR_STCOAtx')
    'ER_STRDNCt'.('GR_STRDNCt')
    'ER_SUCCtp'.('GR_SUCCtp')
    'ER_T4HCINNMFM'.('GR_T4HCINNMFM')
    'ER_TAGAT_Dt'.('GR_TAGAT_Dt')
    'ER_TAXOLte'.('GR_TAXOLte')
    'ER_TCHOLAte'.('GR_TCHOLAte')
    'ER_TDCHOLAte'.('GR_TDCHOLAte')
    'ER_TETHEX3COAtx'.('GR_TETHEX3COAtx')
    'ER_TETHEX3t'.('GR_TETHEX3t')
    'ER_TETPENT3COAtx'.('GR_TETPENT3COAtx')
    'ER_TETPENT3t'.('GR_TETPENT3t')
    'ER_TETPENT6COAtx'.('GR_TETPENT6COAtx')
    'ER_TETPENT6t'.('GR_TETPENT6t')
    'ER_TETTET6COAtx'.('GR_TETTET6COAtx')
    'ER_TETTET6t'.('GR_TETTET6t')
    'ER_THCHOLSTOICtm'.('GR_THCHOLSTOICtm')
    'ER_THFtl'.('GR_THFtl')
    'ER_THFtm'.('GR_THFtm')
    'ER_TMNDNCCOAtx'.('GR_TMNDNCCOAtx')
    'ER_TMNDNCt'.('GR_TMNDNCt')
    'ER_TRIODTHYSUFt'.('GR_TRIODTHYSUFt')
    'ER_TRIOK'.('GR_TRIOK')
    'ER_TSTSTERONESte'.('GR_TSTSTERONESte')
    'ER_TSTSTERONEt'.('GR_TSTSTERONEt')
    'ER_TSTSTERONEtr'.('GR_TSTSTERONEtr')
    'ER_TXA2te'.('GR_TXA2te')
    'ER_TXA2tr'.('GR_TXA2tr')
    'ER_UAGALDP'.('GR_UAGALDP')
    'ER_UDPACGALtl'.('GR_UDPACGALtl')
    'ER_UDPGLCAtg'.('GR_UDPGLCAtg')
    'ER_UDPtl'.('GR_UDPtl')
    'ER_UDPXYLter'.('GR_UDPXYLter')
    'ER_UMPtr'.('GR_UMPtr')
    'ER_URATEt'.('GR_URATEt')
    'ER_UROLACer'.('GR_UROLACer')
    'ER_UTPtn'.('GR_UTPtn')
    'ER_VACCt'.('GR_VACCt')
    'ER_VALt5m'.('GR_VALt5m')
    'ER_VITD3t'.('GR_VITD3t')
    'ER_WHHDCAte'.('GR_WHHDCAte')
    'ER_WHTSTSTERONEte'.('GR_WHTSTSTERONEte')
    'ER_XOL27OHtm'.('GR_XOL27OHtm')
    'ER_XOL7AONEtr'.('GR_XOL7AONEtr')
    'ER_XOLEST2te'.('GR_XOLEST2te')
    'ER_XOLESTte'.('GR_XOLESTte')
    'ER_XOLTRI24te'.('GR_XOLTRI24te')
    'ER_XOLTRI27tc'.('GR_XOLTRI27tc')
    'ER_XOLTRI27te'.('GR_XOLTRI27te')
    'ER_XSERtg'.('GR_XSERtg')
    'ER_XYLTD_Dr'.('GR_XYLTD_Dr')
    'ER_XYLtly'.('GR_XYLtly')
    'ER_XYLTt'.('GR_XYLTt')
    'ER_EX_4abutn[e]'.('GR_EX_4abutn[e]')
    'ER_EX_acmana[e]'.('GR_EX_acmana[e]')
    'ER_EX_ahdt[e]'.('GR_EX_ahdt[e]')
    'ER_EX_ctp[e]'.('GR_EX_ctp[e]')
    'ER_EX_dgmp[e]'.('GR_EX_dgmp[e]')
    'ER_EX_dgtp[e]'.('GR_EX_dgtp[e]')
    'ER_EX_dha[e]'.('GR_EX_dha[e]')
    'ER_EX_dhap[e]'.('GR_EX_dhap[e]')
    'ER_EX_dtmp[e]'.('GR_EX_dtmp[e]')
    'ER_EX_dttp[e]'.('GR_EX_dttp[e]')
    'ER_EX_fald[e]'.('GR_EX_fald[e]')
    'ER_EX_HC01104[e]'.('GR_EX_HC01104[e]')
    'ER_EX_HC01361[e]'.('GR_EX_HC01361[e]')
    'ER_EX_HC01440[e]'.('GR_EX_HC01440[e]')
    'ER_EX_HC01441[e]'.('GR_EX_HC01441[e]')
    'ER_EX_HC01444[e]'.('GR_EX_HC01444[e]')
    'ER_EX_HC01446[e]'.('GR_EX_HC01446[e]')
    'ER_EX_HC01577[e]'.('GR_EX_HC01577[e]')
    'ER_EX_HC01700[e]'.('GR_EX_HC01700[e]')
    'ER_EX_HC02160[e]'.('GR_EX_HC02160[e]')
    'ER_EX_HC02161[e]'.('GR_EX_HC02161[e]')
    'ER_EX_itp[e]'.('GR_EX_itp[e]')
    'ER_EX_orot[e]'.('GR_EX_orot[e]')
    'ER_EX_prpp[e]'.('GR_EX_prpp[e]')
    'ER_r0002'.('GR_r0002')
    'ER_r0156'.('GR_r0156')
    'ER_r0179'.('GR_r0179')
    'ER_r0236'.('GR_r0236')
    'ER_r0330'.('GR_r0330')
    'ER_r0365'.('GR_r0365')
    'ER_r0480'.('GR_r0480')
    'ER_r0527'.('GR_r0527')
    'ER_r0647'.('GR_r0647')
    'ER_r0784'.('GR_r0784')
    'ER_r0788'.('GR_r0788')
    'ER_r0789'.('GR_r0789')
    'ER_r0809'.('GR_r0809')
    'ER_r0818'.('GR_r0818')
    'ER_r0838'.('GR_r0838')
    'ER_r0839'.('GR_r0839')
    'ER_r0841'.('GR_r0841')
    'ER_r0853'.('GR_r0853')
    'ER_r0859'.('GR_r0859')
    'ER_r0886'.('GR_r0886')
    'ER_r0892'.('GR_r0892')
    'ER_r0899'.('GR_r0899')
    'ER_r0926'.('GR_r0926')
    'ER_r0927'.('GR_r0927')
    'ER_r0936'.('GR_r0936')
    'ER_r0937'.('GR_r0937')
    'ER_r0944'.('GR_r0944')
    'ER_r0950'.('GR_r0950')
    'ER_r0962'.('GR_r0962')
    'ER_r0968'.('GR_r0968')
    'ER_r0970'.('GR_r0970')
    'ER_r0973'.('GR_r0973')
    'ER_r0974'.('GR_r0974')
    'ER_r0986'.('GR_r0986')
    'ER_r0987'.('GR_r0987')
    'ER_r0989'.('GR_r0989')
    'ER_r0990'.('GR_r0990')
    'ER_r0994'.('GR_r0994')
    'ER_r1000'.('GR_r1000')
    'ER_r1003'.('GR_r1003')
    'ER_r1011'.('GR_r1011')
    'ER_r1012'.('GR_r1012')
    'ER_r1013'.('GR_r1013')
    'ER_r1014'.('GR_r1014')
    'ER_r1018'.('GR_r1018')
    'ER_r1019'.('GR_r1019')
    'ER_r1030'.('GR_r1030')
    'ER_r1050'.('GR_r1050')
    'ER_r1088'.('GR_r1088')
    'ER_r1106'.('GR_r1106')
    'ER_r1109'.('GR_r1109')
    'ER_r1116'.('GR_r1116')
    'ER_r1117'.('GR_r1117')
    'ER_r1134'.('GR_r1134')
    'ER_r1146'.('GR_r1146')
    'ER_r1148'.('GR_r1148')
    'ER_r1150'.('GR_r1150')
    'ER_r1159'.('GR_r1159')
    'ER_r1291'.('GR_r1291')
    'ER_r1292'.('GR_r1292')
    'ER_r1298'.('GR_r1298')
    'ER_r1299'.('GR_r1299')
    'ER_r1301'.('GR_r1301')
    'ER_r1302'.('GR_r1302')
    'ER_r1303'.('GR_r1303')
    'ER_r1304'.('GR_r1304')
    'ER_r1318'.('GR_r1318')
    'ER_r1364'.('GR_r1364')
    'ER_r1365'.('GR_r1365')
    'ER_r1367'.('GR_r1367')
    'ER_r1368'.('GR_r1368')
    'ER_r1377'.('GR_r1377')
    'ER_r1384'.('GR_r1384')
    'ER_r1400'.('GR_r1400')
    'ER_r1421'.('GR_r1421')
    'ER_r1423'.('GR_r1423')
    'ER_r1435'.('GR_r1435')
    'ER_r1436'.('GR_r1436')
    'ER_r1437'.('GR_r1437')
    'ER_r1459'.('GR_r1459')
    'ER_r1467'.('GR_r1467')
    'ER_r1468'.('GR_r1468')
    'ER_r1493'.('GR_r1493')
    'ER_r1512'.('GR_r1512')
    'ER_r2508'.('GR_r2508')
    'ER_r2509'.('GR_r2509')
    'ER_r2510'.('GR_r2510')
    'ER_r2511'.('GR_r2511')
    'ER_r2514'.('GR_r2514')
    'ER_r2519'.('GR_r2519')
    'ER_r2521'.('GR_r2521')
    'ER_r2537'.('GR_r2537')
    'ER_r2538'.('GR_r2538')
    'ER_r2539'.('GR_r2539')
    'ER_EX_so3[e]'.('GR_EX_so3[e]')
    'ER_EX_sprm[e]'.('GR_EX_sprm[e]')
    'ER_RE0124C'.('GR_RE0124C')
    'ER_RE0452M'.('GR_RE0452M')
    'ER_RE0453C'.('GR_RE0453C')
    'ER_RE0570C'.('GR_RE0570C')
    'ER_RE0571C'.('GR_RE0571C')
    'ER_RE0574C'.('GR_RE0574C')
    'ER_RE0575C'.('GR_RE0575C')
    'ER_RE0576C'.('GR_RE0576C')
    'ER_RE0581C'.('GR_RE0581C')
    'ER_RE0583C'.('GR_RE0583C')
    'ER_RE0691C'.('GR_RE0691C')
    'ER_RE0830C'.('GR_RE0830C')
    'ER_RE0908C'.('GR_RE0908C')
    'ER_RE0915C'.('GR_RE0915C')
    'ER_RE0916C'.('GR_RE0916C')
    'ER_RE0918C'.('GR_RE0918C')
    'ER_RE0958C'.('GR_RE0958C')
    'ER_RE1234C'.('GR_RE1234C')
    'ER_RE1303C'.('GR_RE1303C')
    'ER_RE1342C'.('GR_RE1342C')
    'ER_RE1447N'.('GR_RE1447N')
    'ER_RE1448N'.('GR_RE1448N')
    'ER_RE1530C'.('GR_RE1530C')
    'ER_RE1711C'.('GR_RE1711C')
    'ER_RE1804C'.('GR_RE1804C')
    'ER_RE1807C'.('GR_RE1807C')
    'ER_RE1826C'.('GR_RE1826C')
    'ER_RE1836C'.('GR_RE1836C')
    'ER_RE1897C'.('GR_RE1897C')
    'ER_RE1898C'.('GR_RE1898C')
    'ER_RE1915C'.('GR_RE1915C')
    'ER_RE1916C'.('GR_RE1916C')
    'ER_RE1919C'.('GR_RE1919C')
    'ER_RE1921C'.('GR_RE1921C')
    'ER_RE1978C'.('GR_RE1978C')
    'ER_RE2069C'.('GR_RE2069C')
    'ER_RE2080C'.('GR_RE2080C')
    'ER_RE2112C'.('GR_RE2112C')
    'ER_RE2235C'.('GR_RE2235C')
    'ER_RE2327C'.('GR_RE2327C')
    'ER_RE2407C'.('GR_RE2407C')
    'ER_RE2410C'.('GR_RE2410C')
    'ER_RE2426C'.('GR_RE2426C')
    'ER_RE2526C'.('GR_RE2526C')
    'ER_RE2562C'.('GR_RE2562C')
    'ER_RE2563C'.('GR_RE2563C')
    'ER_RE2625C'.('GR_RE2625C')
    'ER_RE2626C'.('GR_RE2626C')
    'ER_RE2655R'.('GR_RE2655R')
    'ER_RE2659R'.('GR_RE2659R')
    'ER_RE2666C'.('GR_RE2666C')
    'ER_RE2677C'.('GR_RE2677C')
    'ER_RE2677N'.('GR_RE2677N')
    'ER_RE2799C'.('GR_RE2799C')
    'ER_RE2814R'.('GR_RE2814R')
    'ER_RE2974N'.('GR_RE2974N')
    'ER_RE3011R'.('GR_RE3011R')
    'ER_RE3016R'.('GR_RE3016R')
    'ER_RE3017R'.('GR_RE3017R')
    'ER_RE3033C'.('GR_RE3033C')
    'ER_RE3044C'.('GR_RE3044C')
    'ER_RE3050R'.('GR_RE3050R')
    'ER_RE3052C'.('GR_RE3052C')
    'ER_RE3073X'.('GR_RE3073X')
    'ER_RE3104C'.('GR_RE3104C')
    'ER_RE3106C'.('GR_RE3106C')
    'ER_RE3112C'.('GR_RE3112C')
    'ER_RE3113C'.('GR_RE3113C')
    'ER_RE3119C'.('GR_RE3119C')
    'ER_RE3121C'.('GR_RE3121C')
    'ER_RE3122C'.('GR_RE3122C')
    'ER_RE3152C'.('GR_RE3152C')
    'ER_RE3153C'.('GR_RE3153C')
    'ER_RE3154C'.('GR_RE3154C')
    'ER_RE3162C'.('GR_RE3162C')
    'ER_RE3163C'.('GR_RE3163C')
    'ER_RE3164C'.('GR_RE3164C')
    'ER_RE3166C'.('GR_RE3166C')
    'ER_RE3167C'.('GR_RE3167C')
    'ER_RE3168C'.('GR_RE3168C')
    'ER_RE3169C'.('GR_RE3169C')
    'ER_RE3171C'.('GR_RE3171C')
    'ER_RE3172C'.('GR_RE3172C')
    'ER_RE3173C'.('GR_RE3173C')
    'ER_RE3175C'.('GR_RE3175C')
    'ER_RE3176C'.('GR_RE3176C')
    'ER_RE3180C'.('GR_RE3180C')
    'ER_RE3181C'.('GR_RE3181C')
    'ER_RE3227C'.('GR_RE3227C')
    'ER_RE3228C'.('GR_RE3228C')
    'ER_RE3229C'.('GR_RE3229C')
    'ER_RE3230C'.('GR_RE3230C')
    'ER_RE3231C'.('GR_RE3231C')
    'ER_RE3232C'.('GR_RE3232C')
    'ER_RE3234C'.('GR_RE3234C')
    'ER_RE3235C'.('GR_RE3235C')
    'ER_RE3236C'.('GR_RE3236C')
    'ER_RE3237C'.('GR_RE3237C')
    'ER_RE3238C'.('GR_RE3238C')
    'ER_RE3239C'.('GR_RE3239C')
    'ER_RE3242C'.('GR_RE3242C')
    'ER_RE3243C'.('GR_RE3243C')
    'ER_RE3244C'.('GR_RE3244C')
    'ER_RE3245C'.('GR_RE3245C')
    'ER_RE3267E'.('GR_RE3267E')
    'ER_RE3270C'.('GR_RE3270C')
    'ER_RE3272N'.('GR_RE3272N')
    'ER_RE3286C'.('GR_RE3286C')
    'ER_RE3288C'.('GR_RE3288C')
    'ER_RE3347C'.('GR_RE3347C')
    'ER_RE3352C'.('GR_RE3352C')
    'ER_RE3422C'.('GR_RE3422C')
    'ER_RE3430M'.('GR_RE3430M')
    'ER_RE3430X'.('GR_RE3430X')
    'ER_RE3434C'.('GR_RE3434C')
    'ER_RE3435C'.('GR_RE3435C')
    'ER_RE3436C'.('GR_RE3436C')
    'ER_RE3437C'.('GR_RE3437C')
    'ER_RE3475C'.('GR_RE3475C')
    'ER_RE3485C'.('GR_RE3485C')
    'ER_RE3493C'.('GR_RE3493C')
    'ER_RE3496C'.('GR_RE3496C')
    'ER_RE3513C'.('GR_RE3513C')
    'ER_RE3513R'.('GR_RE3513R')
    'ER_RE3525M'.('GR_RE3525M')
    'ER_RE3526M'.('GR_RE3526M')
    'ER_RE3556C'.('GR_RE3556C')
    'ER_RE3565C'.('GR_RE3565C')
    'ER_RE3566C'.('GR_RE3566C')
    'ER_RE3567C'.('GR_RE3567C')
    'ER_RE3568C'.('GR_RE3568C')
    'ER_RE3570C'.('GR_RE3570C')
    'ER_RE3587C'.('GR_RE3587C')
    'ER_RE3637C'.('GR_RE3637C')
    'ER_EX_prostgh2[e]'.('GR_EX_prostgh2[e]')
    'ER_EX_prostgi2[e]'.('GR_EX_prostgi2[e]')
    'ER_EX_cdp[e]'.('GR_EX_cdp[e]')
    'ER_EX_dtdp[e]'.('GR_EX_dtdp[e]')
    'ER_EX_HC00955[e]'.('GR_EX_HC00955[e]')
    'ER_EX_citr_L[e]'.('GR_EX_citr_L[e]')
    'ER_EX_C02470[e]'.('GR_EX_C02470[e]')
    'ER_EX_C02528[e]'.('GR_EX_C02528[e]')
    'ER_EX_HC02195[e]'.('GR_EX_HC02195[e]')
    'ER_EX_HC02196[e]'.('GR_EX_HC02196[e]')
    'ER_EX_HC02220[e]'.('GR_EX_HC02220[e]')
    'ER_EX_HC02191[e]'.('GR_EX_HC02191[e]')
    'ER_EX_HC02194[e]'.('GR_EX_HC02194[e]')
    'ER_EX_HC02197[e]'.('GR_EX_HC02197[e]')
    'ER_EX_HC02198[e]'.('GR_EX_HC02198[e]')
    'ER_EX_HC02187[e]'.('GR_EX_HC02187[e]')
    'ER_EX_HC02180[e]'.('GR_EX_HC02180[e]')
    'ER_EX_HC02202[e]'.('GR_EX_HC02202[e]')
    'ER_EX_HC02203[e]'.('GR_EX_HC02203[e]')
    'ER_EX_HC02204[e]'.('GR_EX_HC02204[e]')
    'ER_EX_HC02205[e]'.('GR_EX_HC02205[e]')
    'ER_EX_HC02206[e]'.('GR_EX_HC02206[e]')
    'ER_EX_HC02207[e]'.('GR_EX_HC02207[e]')
    'ER_EX_HC02213[e]'.('GR_EX_HC02213[e]')
    'ER_EX_HC02217[e]'.('GR_EX_HC02217[e]')
    'ER_EX_maltpt[e]'.('GR_EX_maltpt[e]')
    'ER_EX_CE2915[e]'.('GR_EX_CE2915[e]')
    'ER_EX_CE4722[e]'.('GR_EX_CE4722[e]')
    'ER_EX_CE2916[e]'.('GR_EX_CE2916[e]')
    'ER_EX_CE4723[e]'.('GR_EX_CE4723[e]')
    'ER_EX_CE2917[e]'.('GR_EX_CE2917[e]')
    'ER_EX_CE4724[e]'.('GR_EX_CE4724[e]')
    'ER_EX_malthp[e]'.('GR_EX_malthp[e]')
    'ER_EX_CE2839[e]'.('GR_EX_CE2839[e]')
    'ER_EX_CE2838[e]'.('GR_EX_CE2838[e]')
    'ER_EX_CE1950[e]'.('GR_EX_CE1950[e]')
    'ER_EX_cynt[e]'.('GR_EX_cynt[e]')
    'ER_EX_CE5786[e]'.('GR_EX_CE5786[e]')
    'ER_EX_CE5788[e]'.('GR_EX_CE5788[e]')
    'ER_EX_CE5789[e]'.('GR_EX_CE5789[e]')
    'ER_EX_CE5797[e]'.('GR_EX_CE5797[e]')
    'ER_EX_CE5798[e]'.('GR_EX_CE5798[e]')
    'ER_EX_CE5867[e]'.('GR_EX_CE5867[e]')
    'ER_EX_CE5868[e]'.('GR_EX_CE5868[e]')
    'ER_EX_CE5869[e]'.('GR_EX_CE5869[e]')
    'ER_EX_CE4633[e]'.('GR_EX_CE4633[e]')
    'ER_EX_CE4881[e]'.('GR_EX_CE4881[e]')
    'ER_EX_crm_hs[e]'.('GR_EX_crm_hs[e]')
    'ER_EX_CE0074[e]'.('GR_EX_CE0074[e]')
    'ER_EX_cdpea[e]'.('GR_EX_cdpea[e]')
    'ER_EX_12dgr120[e]'.('GR_EX_12dgr120[e]')
    'ER_biomass_reaction'.('GR_biomass_reaction')
    'ER_ADPACDAc'.('GR_ADPACDAc')
    'ER_ADPACtx'.('GR_ADPACtx')
    'ER_BCRNe'.('GR_BCRNe')
    'ER_sink_c101coa[c]'.('GR_sink_c101coa[c]')
    'ER_C101CRNe'.('GR_C101CRNe')
    'ER_C10CRNe'.('GR_C10CRNe')
    'ER_C12DCACT'.('GR_C12DCACT')
    'ER_C12DCe'.('GR_C12DCe')
    'ER_C16DCe'.('GR_C16DCe')
    'ER_C3DCe'.('GR_C3DCe')
    'ER_C4CRNe'.('GR_C4CRNe')
    'ER_C4DCe'.('GR_C4DCe')
    'ER_C6CRNe'.('GR_C6CRNe')
    'ER_sink_c81coa[c]'.('GR_sink_c81coa[c]')
    'ER_C81CRNe'.('GR_C81CRNe')
    'ER_C8CRNe'.('GR_C8CRNe')
    'ER_C8DCe'.('GR_C8DCe')
    'ER_sink_dd2coa[c]'.('GR_sink_dd2coa[c]')
    'ER_DDCRNe'.('GR_DDCRNe')
    'ER_DDECCRNe'.('GR_DDECCRNe')
    'ER_DDECE1CRNe'.('GR_DDECE1CRNe')
    'ER_DECCRNe'.('GR_DECCRNe')
    'ER_sink_decdicoa[c]'.('GR_sink_decdicoa[c]')
    'ER_DECDICRNe'.('GR_DECDICRNe')
    'ER_DOCOSACTDe'.('GR_DOCOSACTDe')
    'ER_DOCOSACTDr'.('GR_DOCOSACTDr')
    'ER_EX_3bcrn[e]'.('GR_EX_3bcrn[e]')
    'ER_EX_3ddcrn[e]'.('GR_EX_3ddcrn[e]')
    'ER_EX_3deccrn[e]'.('GR_EX_3deccrn[e]')
    'ER_EX_3octdec2crn[e]'.('GR_EX_3octdec2crn[e]')
    'ER_EX_3octdece1crn[e]'.('GR_EX_3octdece1crn[e]')
    'ER_EX_3tdcrn[e]'.('GR_EX_3tdcrn[e]')
    'ER_EX_c101crn[e]'.('GR_EX_c101crn[e]')
    'ER_EX_c10crn[e]'.('GR_EX_c10crn[e]')
    'ER_EX_c12dc[e]'.('GR_EX_c12dc[e]')
    'ER_EX_c16dc[e]'.('GR_EX_c16dc[e]')
    'ER_EX_c3dc[e]'.('GR_EX_c3dc[e]')
    'ER_EX_c4crn[e]'.('GR_EX_c4crn[e]')
    'ER_EX_c4dc[e]'.('GR_EX_c4dc[e]')
    'ER_EX_c51crn[e]'.('GR_EX_c51crn[e]')
    'ER_EX_c6crn[e]'.('GR_EX_c6crn[e]')
    'ER_EX_c81crn[e]'.('GR_EX_c81crn[e]')
    'ER_EX_c8crn[e]'.('GR_EX_c8crn[e]')
    'ER_EX_c8dc[e]'.('GR_EX_c8dc[e]')
    'ER_EX_ddece1crn[e]'.('GR_EX_ddece1crn[e]')
    'ER_EX_ddecrn[e]'.('GR_EX_ddecrn[e]')
    'ER_EX_decdicrn[e]'.('GR_EX_decdicrn[e]')
    'ER_EX_doco13ac[e]'.('GR_EX_doco13ac[e]')
    'ER_EX_docosac[e]'.('GR_EX_docosac[e]')
    'ER_EX_tetdec2crn[e]'.('GR_EX_tetdec2crn[e]')
    'ER_EX_tetdece1crn[e]'.('GR_EX_tetdece1crn[e]')
    'ER_EX_dca[e]'.('GR_EX_dca[e]')
    'ER_FAOXC5C5OHm'.('GR_FAOXC5C5OHm')
    'ER_HEXDIACtr'.('GR_HEXDIACtr')
    'ER_HOCTDEC2CRNe'.('GR_HOCTDEC2CRNe')
    'ER_HTDCRNe'.('GR_HTDCRNe')
    'ER_OCTDECE1CRNe'.('GR_OCTDECE1CRNe')
    'ER_sink_octdececoa[c]'.('GR_sink_octdececoa[c]')
    'ER_SEBACACT'.('GR_SEBACACT')
    'ER_SEBACIDtx'.('GR_SEBACIDtx')
    'ER_SUBEACtx'.('GR_SUBEACtx')
    'ER_SUBERICACT'.('GR_SUBERICACT')
    'ER_SUCCACT'.('GR_SUCCACT')
    'ER_TDCRNe'.('GR_TDCRNe')
    'ER_sink_tetdec2coa[c]'.('GR_sink_tetdec2coa[c]')
    'ER_TETDEC2CRNe'.('GR_TETDEC2CRNe')
    'ER_sink_tetdece1coa[c]'.('GR_sink_tetdece1coa[c]')
    'ER_TETDECE1CRNe'.('GR_TETDECE1CRNe')
    'ER_TIGCRNe'.('GR_TIGCRNe')
    'ER_BTNTe'.('GR_BTNTe')
    'ER_SBTle'.('GR_SBTle')
    'ER_1a25DHVITD3TRn'.('GR_1a25DHVITD3TRn')
    'ER_3AIB_Dtm'.('GR_3AIB_Dtm')
    'ER_5MTHFt2le'.('GR_5MTHFt2le')
    'ER_ADNK4'.('GR_ADNK4')
    'ER_AHCYStd'.('GR_AHCYStd')
    'ER_ALA-DTDe'.('GR_ALA-DTDe')
    'ER_AMETtd'.('GR_AMETtd')
    'ER_ARACHFATPc'.('GR_ARACHFATPc')
    'ER_ASPDTDe'.('GR_ASPDTDe')
    'ER_ASPte'.('GR_ASPte')
    'ER_CHSTEROLtrc'.('GR_CHSTEROLtrc')
    'ER_CRNrtx'.('GR_CRNrtx')
    'ER_Coqe'.('GR_Coqe')
    'ER_DATPtm'.('GR_DATPtm')
    'ER_DCTPtm'.('GR_DCTPtm')
    'ER_DGTPtm'.('GR_DGTPtm')
    'ER_DHAPtc'.('GR_DHAPtc')
    'ER_DM_1a25dhvitd3[n]'.('GR_DM_1a25dhvitd3[n]')
    'ER_DM_taur[c]'.('GR_DM_taur[c]')
    'ER_DM_pmtcoa[r]'.('GR_DM_pmtcoa[r]')
    'ER_DTTPtm'.('GR_DTTPtm')
    'ER_EX_4hpro[e]'.('GR_EX_4hpro[e]')
    'ER_EX_carn[e]'.('GR_EX_carn[e]')
    'ER_EX_dchac[e]'.('GR_EX_dchac[e]')
    'ER_EX_sfcys[e]'.('GR_EX_sfcys[e]')
    'ER_EX_cysam[e]'.('GR_EX_cysam[e]')
    'ER_EX_fmn[e]'.('GR_EX_fmn[e]')
    'ER_EX_oh1[e]'.('GR_EX_oh1[e]')
    'ER_EX_ptth[e]'.('GR_EX_ptth[e]')
    'ER_EX_q10[e]'.('GR_EX_q10[e]')
    'ER_EX_q10h2[e]'.('GR_EX_q10h2[e]')
    'ER_FOLt2le'.('GR_FOLt2le')
    'ER_FRDPtcr'.('GR_FRDPtcr')
    'ER_GLU5SAtmc'.('GR_GLU5SAtmc')
    'ER_GLYC3PFADm'.('GR_GLYC3PFADm')
    'ER_GLYCTDle'.('GR_GLYCTDle')
    'ER_INSK'.('GR_INSK')
    'ER_KHte'.('GR_KHte')
    'ER_LACLt'.('GR_LACLt')
    'ER_MAL_Ltx'.('GR_MAL_Ltx')
    'ER_MDHx'.('GR_MDHx')
    'ER_NADtm'.('GR_NADtm')
    'ER_NADtx'.('GR_NADtx')
    'ER_PNTEHe'.('GR_PNTEHe')
    'ER_PPItm'.('GR_PPItm')
    'ER_PRO_Dtde'.('GR_PRO_Dtde')
    'ER_PTCRTD'.('GR_PTCRTD')
    'ER_Q10H2e'.('GR_Q10H2e')
    'ER_SFCYSc'.('GR_SFCYSc')
    'ER_SFCYSe'.('GR_SFCYSe')
    'ER_sink_5hpet[c]'.('GR_sink_5hpet[c]')
    'ER_TAURCHAe'.('GR_TAURCHAe')
    'ER_TTDCAFATPc'.('GR_TTDCAFATPc')
    'ER_q10h2tc'.('GR_q10h2tc')
    'ER_q10tm'.('GR_q10tm')
    'ER_34HPPte'.('GR_34HPPte')
    'ER_3MOBte'.('GR_3MOBte')
    'ER_3MOPte'.('GR_3MOPte')
    'ER_4MOPte'.('GR_4MOPte')
    'ER_5MTAte'.('GR_5MTAte')
    'ER_AHCYSte'.('GR_AHCYSte')
    'ER_AICARte'.('GR_AICARte')
    'ER_CBASPte'.('GR_CBASPte')
    'ER_DM_4hrpo'.('GR_DM_4hrpo')
    'ER_DM_Lcystin'.('GR_DM_Lcystin')
    'ER_DM_fol'.('GR_DM_fol')
    'ER_DM_pnto_R'.('GR_DM_pnto_R')
    'ER_EX_34hpp[e]'.('GR_EX_34hpp[e]')
    'ER_EX_3mob[e]'.('GR_EX_3mob[e]')
    'ER_EX_3mop[e]'.('GR_EX_3mop[e]')
    'ER_EX_4mop[e]'.('GR_EX_4mop[e]')
    'ER_EX_5mta[e]'.('GR_EX_5mta[e]')
    'ER_EX_ahcys[e]'.('GR_EX_ahcys[e]')
    'ER_EX_aicar[e]'.('GR_EX_aicar[e]')
    'ER_EX_cbasp[e]'.('GR_EX_cbasp[e]')
    'ER_MAL_Lte'.('GR_MAL_Lte')
    'ER_IDOURte'.('GR_IDOURte')
    'ER_EX_idour[e]'.('GR_EX_idour[e]')
    'ER_GLYALDtr'.('GR_GLYALDtr')
    'ER_PEPtr'.('GR_PEPtr')
    'ER_GUDACtr'.('GR_GUDACtr')
    'ER_GUDACtr2'.('GR_GUDACtr2')
    'ER_KYNATEtr2'.('GR_KYNATEtr2')
    'ER_3ANTHRNtr'.('GR_3ANTHRNtr')
    'ER_2PGtr'.('GR_2PGtr')
    'ER_CARNtr'.('GR_CARNtr')
    'ER_CHOLPtr'.('GR_CHOLPtr')
    'ER_DCMPtr'.('GR_DCMPtr')
    'ER_DHAPtr'.('GR_DHAPtr')
    'ER_ETHAMPtr'.('GR_ETHAMPtr')
    'ER_FUMtr'.('GR_FUMtr')
    'ER_GLCURtr'.('GR_GLCURtr')
    'ER_ICITtr'.('GR_ICITtr')
    'ER_L2AADPtr'.('GR_L2AADPtr')
    'ER_XANtr'.('GR_XANtr')
    'ER_XMPtr'.('GR_XMPtr')
    'ER_XTSNtr'.('GR_XTSNtr')
    'ER_3PGtr'.('GR_3PGtr')
    'ER_UDPGLCURtr'.('GR_UDPGLCURtr')
    'ER_IMPtr'.('GR_IMPtr')
    'ER_GLYC3tr'.('GR_GLYC3tr')
    'ER_NICRNtr'.('GR_NICRNtr')
    'ER_OROT5Ptr'.('GR_OROT5Ptr')
    'ER_EX_2pg[e]'.('GR_EX_2pg[e]')
    'ER_EX_5hoxindoa[e]'.('GR_EX_5hoxindoa[e]')
    'ER_EX_cholp[e]'.('GR_EX_cholp[e]')
    'ER_EX_dcmp[e]'.('GR_EX_dcmp[e]')
    'ER_EX_ethamp[e]'.('GR_EX_ethamp[e]')
    'ER_EX_glyald[e]'.('GR_EX_glyald[e]')
    'ER_EX_gudac[e]'.('GR_EX_gudac[e]')
    'ER_EX_hcys_L[e]'.('GR_EX_hcys_L[e]')
    'ER_EX_icit[e]'.('GR_EX_icit[e]')
    'ER_EX_kynate[e]'.('GR_EX_kynate[e]')
    'ER_EX_L2aadp[e]'.('GR_EX_L2aadp[e]')
    'ER_EX_Lkynr[e]'.('GR_EX_Lkynr[e]')
    'ER_EX_pep[e]'.('GR_EX_pep[e]')
    'ER_EX_xmp[e]'.('GR_EX_xmp[e]')
    'ER_EX_xtsn[e]'.('GR_EX_xtsn[e]')
    'ER_EX_3pg[e]'.('GR_EX_3pg[e]')
    'ER_EX_3hanthrn[e]'.('GR_EX_3hanthrn[e]')
    'ER_EX_udpglcur[e]'.('GR_EX_udpglcur[e]')
    'ER_EX_nicrnt[e]'.('GR_EX_nicrnt[e]')
    'ER_EX_orot5p[e]'.('GR_EX_orot5p[e]')
    'ER_EX_glyc3p[e]'.('GR_EX_glyc3p[e]')
    'ER_ARGSUCte'.('GR_ARGSUCte')
    'ER_EX_argsuc[e]'.('GR_EX_argsuc[e]')
    'ER_EX_acrn[e]'.('GR_EX_acrn[e]')
    'ER_EX_pcrn[e]'.('GR_EX_pcrn[e]')
    'ER_EX_lneldccrn[e]'.('GR_EX_lneldccrn[e]')
    'ER_EX_odecrn[e]'.('GR_EX_odecrn[e]')
    'ER_EX_stcrn[e]'.('GR_EX_stcrn[e]')
    'ER_EX_pmtcrn[e]'.('GR_EX_pmtcrn[e]')
    'ER_EX_hdcecrn[e]'.('GR_EX_hdcecrn[e]')
    'ER_DM_ascb_L[c]'.('GR_DM_ascb_L[c]')
    'ER_biomass_maintenance_noTrTr'.('GR_biomass_maintenance_noTrTr')
    'ER_ADPOHc'.('GR_ADPOHc')
    'ER_PHLAC'.('GR_PHLAC')
    'ER_3MHISc'.('GR_3MHISc')
    'ER_HMCRNc'.('GR_HMCRNc')
    'ER_CE4843HYDc'.('GR_CE4843HYDc')
    'ER_HXCOAc'.('GR_HXCOAc')
    'ER_HDCAc'.('GR_HDCAc')
    'ER_ELAIDCRNte'.('GR_ELAIDCRNte')
    'ER_LNLCCRNNAt'.('GR_LNLCCRNNAt')
    'ER_PHLACHt'.('GR_PHLACHt')
    'ER_TTDCRNNAt'.('GR_TTDCRNNAt')
    'ER_15HPETATP'.('GR_15HPETATP')
    'ER_15KPROSTGF2t'.('GR_15KPROSTGF2t')
    'ER_2OXOADPt'.('GR_2OXOADPt')
    'ER_34HPLte'.('GR_34HPLte')
    'ER_3HMPtd'.('GR_3HMPtd')
    'ER_3HPPt'.('GR_3HPPt')
    'ER_3MHISt1'.('GR_3MHISt1')
    'ER_3MHISt2'.('GR_3MHISt2')
    'ER_3MHISt3'.('GR_3MHISt3')
    'ER_3MOXTYRt'.('GR_3MOXTYRt')
    'ER_3UIBtd'.('GR_3UIBtd')
    'ER_4TMEABUTNt1'.('GR_4TMEABUTNt1')
    'ER_4TMEABUTNt2'.('GR_4TMEABUTNt2')
    'ER_56DTHMt'.('GR_56DTHMt')
    'ER_56DTHMtd'.('GR_56DTHMtd')
    'ER_56DURAt'.('GR_56DURAt')
    'ER_56DURAtd'.('GR_56DURAtd')
    'ER_5AOPt'.('GR_5AOPt')
    'ER_7DHCHSTEROLtd'.('GR_7DHCHSTEROLtd')
    'ER_ACGLUtd'.('GR_ACGLUtd')
    'ER_ACLYSt'.('GR_ACLYSt')
    'ER_ACLYStm'.('GR_ACLYStm')
    'ER_ADPACtd'.('GR_ADPACtd')
    'ER_ADPOHt'.('GR_ADPOHt')
    'ER_ALLTNt'.('GR_ALLTNt')
    'ER_C02712tm'.('GR_C02712tm')
    'ER_C03990tr'.('GR_C03990tr')
    'ER_C04483t2'.('GR_C04483t2')
    'ER_C04717td'.('GR_C04717td')
    'ER_C04805td'.('GR_C04805td')
    'ER_C05463t2'.('GR_C05463t2')
    'ER_C05953t'.('GR_C05953t')
    'ER_C05957t'.('GR_C05957t')
    'ER_C05957td'.('GR_C05957td')
    'ER_C06314t'.('GR_C06314t')
    'ER_C06315t'.('GR_C06315t')
    'ER_C06439t'.('GR_C06439t')
    'ER_C11695td'.('GR_C11695td')
    'ER_C14768td'.('GR_C14768td')
    'ER_C14769td1'.('GR_C14769td1')
    'ER_EX_C14769[e]'.('GR_EX_C14769[e]')
    'ER_C14770ATP'.('GR_C14770ATP')
    'ER_C14771ATP'.('GR_C14771ATP')
    'ER_C14825td'.('GR_C14825td')
    'ER_C14826td'.('GR_C14826td')
    'ER_CE1273t2'.('GR_CE1273t2')
    'ER_CE2510t'.('GR_CE2510t')
    'ER_CE2513td'.('GR_CE2513td')
    'ER_CE2537ATP'.('GR_CE2537ATP')
    'ER_CE4843td'.('GR_CE4843td')
    'ER_CE5304t'.('GR_CE5304t')
    'ER_CE6247t'.('GR_CE6247t')
    'ER_DODECANACtd'.('GR_DODECANACtd')
    'ER_ELAIDCRNtd'.('GR_ELAIDCRNtd')
    'ER_EX_12HPET[e]'.('GR_EX_12HPET[e]')
    'ER_EX_15HPET[e]'.('GR_EX_15HPET[e]')
    'ER_EX_15kprostgf2[e]'.('GR_EX_15kprostgf2[e]')
    'ER_EX_2oxoadp[e]'.('GR_EX_2oxoadp[e]')
    'ER_EX_34hpl[e]'.('GR_EX_34hpl[e]')
    'ER_EX_3hmp[e]'.('GR_EX_3hmp[e]')
    'ER_EX_3hpp[e]'.('GR_EX_3hpp[e]')
    'ER_EX_3mhis[e]'.('GR_EX_3mhis[e]')
    'ER_EX_3uib[e]'.('GR_EX_3uib[e]')
    'ER_EX_4tmeabutn[e]'.('GR_EX_4tmeabutn[e]')
    'ER_EX_56dthm[e]'.('GR_EX_56dthm[e]')
    'ER_EX_56dura[e]'.('GR_EX_56dura[e]')
    'ER_EX_7dhchsterol[e]'.('GR_EX_7dhchsterol[e]')
    'ER_EX_aclys[e]'.('GR_EX_aclys[e]')
    'ER_EX_adpac[e]'.('GR_EX_adpac[e]')
    'ER_EX_adpoh[e]'.('GR_EX_adpoh[e]')
    'ER_EX_amet[e]'.('GR_EX_amet[e]')
    'ER_EX_aracheth[e]'.('GR_EX_aracheth[e]')
    'ER_EX_C04717[e]'.('GR_EX_C04717[e]')
    'ER_EX_C04805[e]'.('GR_EX_C04805[e]')
    'ER_EX_C05957[e]'.('GR_EX_C05957[e]')
    'ER_EX_C06314[e]'.('GR_EX_C06314[e]')
    'ER_EX_C06315[e]'.('GR_EX_C06315[e]')
    'ER_EX_C11695[e]'.('GR_EX_C11695[e]')
    'ER_EX_C14768[e]'.('GR_EX_C14768[e]')
    'ER_EX_C14770[e]'.('GR_EX_C14770[e]')
    'ER_EX_C14771[e]'.('GR_EX_C14771[e]')
    'ER_EX_C14825[e]'.('GR_EX_C14825[e]')
    'ER_EX_C14826[e]'.('GR_EX_C14826[e]')
    'ER_EX_CE2537[e]'.('GR_EX_CE2537[e]')
    'ER_EX_CE4843[e]'.('GR_EX_CE4843[e]')
    'ER_EX_CE5304[e]'.('GR_EX_CE5304[e]')
    'ER_EX_CE6247[e]'.('GR_EX_CE6247[e]')
    'ER_EX_CE7172[e]'.('GR_EX_CE7172[e]')
    'ER_EX_didecaeth[e]'.('GR_EX_didecaeth[e]')
    'ER_EX_diholineth[e]'.('GR_EX_diholineth[e]')
    'ER_EX_docohxeth[e]'.('GR_EX_docohxeth[e]')
    'ER_EX_docteteth[e]'.('GR_EX_docteteth[e]')
    'ER_EX_dodecanac[e]'.('GR_EX_dodecanac[e]')
    'ER_EX_elaidcrn[e]'.('GR_EX_elaidcrn[e]')
    'ER_EX_forglu[e]'.('GR_EX_forglu[e]')
    'ER_EX_HC00900[e]'.('GR_EX_HC00900[e]')
    'ER_EX_hepdeceth[e]'.('GR_EX_hepdeceth[e]')
    'ER_EX_hexdeceeth[e]'.('GR_EX_hexdeceeth[e]')
    'ER_EX_hexdiac[e]'.('GR_EX_hexdiac[e]')
    'ER_EX_hgentis[e]'.('GR_EX_hgentis[e]')
    'ER_EX_hmcr[e]'.('GR_EX_hmcr[e]')
    'ER_EX_hxcoa[e]'.('GR_EX_hxcoa[e]')
    'ER_EX_leuktrB4wcooh[e]'.('GR_EX_leuktrB4wcooh[e]')
    'ER_EX_leuktrB4woh[e]'.('GR_EX_leuktrB4woh[e]')
    'ER_EX_lineth[e]'.('GR_EX_lineth[e]')
    'ER_EX_lnlccrn[e]'.('GR_EX_lnlccrn[e]')
    'ER_EX_lthstrl[e]'.('GR_EX_lthstrl[e]')
    'ER_EX_mev_R[e]'.('GR_EX_mev_R[e]')
    'ER_EX_mi1p_D[e]'.('GR_EX_mi1p_D[e]')
    'ER_EX_nwharg[e]'.('GR_EX_nwharg[e]')
    'ER_EX_oleth[e]'.('GR_EX_oleth[e]')
    'ER_EX_pailar_hs[e]'.('GR_EX_pailar_hs[e]')
    'ER_EX_pailpalm_hs[e]'.('GR_EX_pailpalm_hs[e]')
    'ER_EX_pchol2linl_hs[e]'.('GR_EX_pchol2linl_hs[e]')
    'ER_EX_pchol2ole_hs[e]'.('GR_EX_pchol2ole_hs[e]')
    'ER_EX_pchol2palm_hs[e]'.('GR_EX_pchol2palm_hs[e]')
    'ER_EX_pchol2ste_hs[e]'.('GR_EX_pchol2ste_hs[e]')
    'ER_EX_pcholar_hs[e]'.('GR_EX_pcholar_hs[e]')
    'ER_EX_pcholdoc_hs[e]'.('GR_EX_pcholdoc_hs[e]')
    'ER_EX_pcholeic_hs[e]'.('GR_EX_pcholeic_hs[e]')
    'ER_EX_pcholet_hs[e]'.('GR_EX_pcholet_hs[e]')
    'ER_EX_pcholhep_hs[e]'.('GR_EX_pcholhep_hs[e]')
    'ER_EX_pchollinl_hs[e]'.('GR_EX_pchollinl_hs[e]')
    'ER_EX_pcholmyr_hs[e]'.('GR_EX_pcholmyr_hs[e]')
    'ER_EX_pcholn15_hs[e]'.('GR_EX_pcholn15_hs[e]')
    'ER_EX_pcholn183_hs[e]'.('GR_EX_pcholn183_hs[e]')
    'ER_EX_pcholn1836_hs[e]'.('GR_EX_pcholn1836_hs[e]')
    'ER_EX_pcholn19_hs[e]'.('GR_EX_pcholn19_hs[e]')
    'ER_EX_pcholn201_hs[e]'.('GR_EX_pcholn201_hs[e]')
    'ER_EX_pcholn203_hs[e]'.('GR_EX_pcholn203_hs[e]')
    'ER_EX_pcholn204_hs[e]'.('GR_EX_pcholn204_hs[e]')
    'ER_EX_pcholn205_hs[e]'.('GR_EX_pcholn205_hs[e]')
    'ER_EX_pcholn224_hs[e]'.('GR_EX_pcholn224_hs[e]')
    'ER_EX_pcholn225_hs[e]'.('GR_EX_pcholn225_hs[e]')
    'ER_EX_pcholn2254_hs[e]'.('GR_EX_pcholn2254_hs[e]')
    'ER_EX_pcholn226_hs[e]'.('GR_EX_pcholn226_hs[e]')
    'ER_EX_pcholn24_hs[e]'.('GR_EX_pcholn24_hs[e]')
    'ER_EX_pcholn261_hs[e]'.('GR_EX_pcholn261_hs[e]')
    'ER_EX_pcholn28_hs[e]'.('GR_EX_pcholn28_hs[e]')
    'ER_EX_pcholn281_hs[e]'.('GR_EX_pcholn281_hs[e]')
    'ER_EX_pcholole_hs[e]'.('GR_EX_pcholole_hs[e]')
    'ER_EX_pcholpalm_hs[e]'.('GR_EX_pcholpalm_hs[e]')
    'ER_EX_pcholpalme_hs[e]'.('GR_EX_pcholpalme_hs[e]')
    'ER_EX_pcholste_hs[e]'.('GR_EX_pcholste_hs[e]')
    'ER_EX_pcollg5hlys[e]'.('GR_EX_pcollg5hlys[e]')
    'ER_EX_pe12_hs[e]'.('GR_EX_pe12_hs[e]')
    'ER_EX_pe13_hs[e]'.('GR_EX_pe13_hs[e]')
    'ER_EX_pe14_hs[e]'.('GR_EX_pe14_hs[e]')
    'ER_EX_pe15_hs[e]'.('GR_EX_pe15_hs[e]')
    'ER_EX_pe161_hs[e]'.('GR_EX_pe161_hs[e]')
    'ER_EX_pe17_hs[e]'.('GR_EX_pe17_hs[e]')
    'ER_EX_pe203_hs[e]'.('GR_EX_pe203_hs[e]')
    'ER_EX_pe224_hs[e]'.('GR_EX_pe224_hs[e]')
    'ER_EX_pe226_hs[e]'.('GR_EX_pe226_hs[e]')
    'ER_EX_pe2linl_hs[e]'.('GR_EX_pe2linl_hs[e]')
    'ER_EX_pear_hs[e]'.('GR_EX_pear_hs[e]')
    'ER_EX_pedh203_hs[e]'.('GR_EX_pedh203_hs[e]')
    'ER_EX_pelinl_hs[e]'.('GR_EX_pelinl_hs[e]')
    'ER_EX_pendecaeth[e]'.('GR_EX_pendecaeth[e]')
    'ER_EX_peole_hs[e]'.('GR_EX_peole_hs[e]')
    'ER_EX_pepalm_hs[e]'.('GR_EX_pepalm_hs[e]')
    'ER_EX_peste_hs[e]'.('GR_EX_peste_hs[e]')
    'ER_EX_pmeth[e]'.('GR_EX_pmeth[e]')
    'ER_EX_saccrp_L[e]'.('GR_EX_saccrp_L[e]')
    'ER_EX_sebacid[e]'.('GR_EX_sebacid[e]')
    'ER_EX_sphmyln180241_hs[e]'.('GR_EX_sphmyln180241_hs[e]')
    'ER_EX_sphmyln18114_hs[e]'.('GR_EX_sphmyln18114_hs[e]')
    'ER_EX_sphmyln18115_hs[e]'.('GR_EX_sphmyln18115_hs[e]')
    'ER_EX_sphmyln18116_hs[e]'.('GR_EX_sphmyln18116_hs[e]')
    'ER_EX_sphmyln181161_hs[e]'.('GR_EX_sphmyln181161_hs[e]')
    'ER_EX_sphmyln18117_hs[e]'.('GR_EX_sphmyln18117_hs[e]')
    'ER_EX_sphmyln18118_hs[e]'.('GR_EX_sphmyln18118_hs[e]')
    'ER_EX_sphmyln181181_hs[e]'.('GR_EX_sphmyln181181_hs[e]')
    'ER_EX_sphmyln18120_hs[e]'.('GR_EX_sphmyln18120_hs[e]')
    'ER_EX_sphmyln181201_hs[e]'.('GR_EX_sphmyln181201_hs[e]')
    'ER_EX_sphmyln18121_hs[e]'.('GR_EX_sphmyln18121_hs[e]')
    'ER_EX_sphmyln18122_hs[e]'.('GR_EX_sphmyln18122_hs[e]')
    'ER_EX_sphmyln181221_hs[e]'.('GR_EX_sphmyln181221_hs[e]')
    'ER_EX_sphmyln18123_hs[e]'.('GR_EX_sphmyln18123_hs[e]')
    'ER_EX_sphmyln1824_hs[e]'.('GR_EX_sphmyln1824_hs[e]')
    'ER_EX_sphmyln1825_hs[e]'.('GR_EX_sphmyln1825_hs[e]')
    'ER_EX_steeth[e]'.('GR_EX_steeth[e]')
    'ER_EX_subeac[e]'.('GR_EX_subeac[e]')
    'ER_EX_tetdecaeth[e]'.('GR_EX_tetdecaeth[e]')
    'ER_EX_tmlys[e]'.('GR_EX_tmlys[e]')
    'ER_EX_trideceth[e]'.('GR_EX_trideceth[e]')
    'ER_EX_ttdcrn[e]'.('GR_EX_ttdcrn[e]')
    'ER_EX_urcan[e]'.('GR_EX_urcan[e]')
    'ER_EX_wharachd[e]'.('GR_EX_wharachd[e]')
    'ER_FORGLUt'.('GR_FORGLUt')
    'ER_GALTt'.('GR_GALTt')
    'ER_LYSACm'.('GR_LYSACm')
    'ER_GLYC_Rt'.('GR_GLYC_Rt')
    'ER_GLYCLTtd'.('GR_GLYCLTtd')
    'ER_HC00900t1'.('GR_HC00900t1')
    'ER_HC00900t2'.('GR_HC00900t2')
    'ER_HC00900t3'.('GR_HC00900t3')
    'ER_HC00900t4'.('GR_HC00900t4')
    'ER_HC02149td'.('GR_HC02149td')
    'ER_HEXDIACtd'.('GR_HEXDIACtd')
    'ER_HGENTISt'.('GR_HGENTISt')
    'ER_HMCRNt'.('GR_HMCRNt')
    'ER_HXCOAm'.('GR_HXCOAm')
    'ER_HXCOAte'.('GR_HXCOAte')
    'ER_HXCOAtx'.('GR_HXCOAtx')
    'ER_HXCOAx'.('GR_HXCOAx')
    'ER_IND3ACt'.('GR_IND3ACt')
    'ER_LCYSTt'.('GR_LCYSTt')
    'ER_LEUKTRB4WCOOHt'.('GR_LEUKTRB4WCOOHt')
    'ER_LEUKTRB4WOHt'.('GR_LEUKTRB4WOHt')
    'ER_LEUKTRB4WOHtr'.('GR_LEUKTRB4WOHtr')
    'ER_LNLCCRNtd'.('GR_LNLCCRNtd')
    'ER_LTHSTRLt'.('GR_LTHSTRLt')
    'ER_MEV_Rt'.('GR_MEV_Rt')
    'ER_MI1Pt'.('GR_MI1Pt')
    'ER_NWHARGtd'.('GR_NWHARGtd')
    'ER_OAAt'.('GR_OAAt')
    'ER_pac'.('GR_pac')
    'ER_PCOLLG5HLYStd'.('GR_PCOLLG5HLYStd')
    'ER_PROSTGI2c'.('GR_PROSTGI2c')
    'ER_PSERtr'.('GR_PSERtr')
    'ER_SACCRP_Lte'.('GR_SACCRP_Lte')
    'ER_SACCRP_Ltm'.('GR_SACCRP_Ltm')
    'ER_SEBACIDtd'.('GR_SEBACIDtd')
    'ER_SUBEACtd'.('GR_SUBEACtd')
    'ER_TMLYStd'.('GR_TMLYStd')
    'ER_TXB2c'.('GR_TXB2c')
    'ER_URCANt'.('GR_URCANt')
    'ER_WHARACHDtr'.('GR_WHARACHDtr')
    'ER_EX_estriol[e]'.('GR_EX_estriol[e]')
    'ER_DDCAFATP'.('GR_DDCAFATP')
    'ER_EX_3moxtyr[e]'.('GR_EX_3moxtyr[e]')
    'ER_EX_5aop[e]'.('GR_EX_5aop[e]')
    'ER_EX_acglu[e]'.('GR_EX_acglu[e]')
    'ER_EX_alltn[e]'.('GR_EX_alltn[e]')
    'ER_EX_CE2510[e]'.('GR_EX_CE2510[e]')
    'ER_EX_ddca[e]'.('GR_EX_ddca[e]')
    'ER_EX_glyc_R[e]'.('GR_EX_glyc_R[e]')
    'ER_EX_glyclt[e]'.('GR_EX_glyclt[e]')
    'ER_EX_Lcyst[e]'.('GR_EX_Lcyst[e]')
    'ER_EX_oaa[e]'.('GR_EX_oaa[e]')
    'ER_EX_pac[e]'.('GR_EX_pac[e]')
    'ER_EX_phlac[e]'.('GR_EX_phlac[e]')
    'ER_EX_pser_L[e]'.('GR_EX_pser_L[e]')
    'ER_EX_ttdcea[e]'.('GR_EX_ttdcea[e]')
    'ER_TTDCEAt'.('GR_TTDCEAt')
    'ER_DCHOLESTANCOAc'.('GR_DCHOLESTANCOAc')
    'ER_XOL27OHtmc'.('GR_XOL27OHtmc')
    'ER_r0202m'.('GR_r0202m')
    'ER_PHEACGLYsec'.('GR_PHEACGLYsec')
    'ER_EX_pheacgly[e]'.('GR_EX_pheacgly[e]')
    'ER_EX_bz[e]'.('GR_EX_bz[e]')
    'ER_NORMETEt'.('GR_NORMETEt')
    'ER_MEPIt'.('GR_MEPIt')
    'ER_TREt'.('GR_TREt')
    'ER_C05300t'.('GR_C05300t')
    'ER_RETINALt'.('GR_RETINALt')
    'ER_MALTTTRt'.('GR_MALTTTRt')
    'ER_1MNCAMt'.('GR_1MNCAMt')
    'ER_DHBPTt'.('GR_DHBPTt')
    'ER_THBPTt'.('GR_THBPTt')
    'ER_EX_normete_L[e]'.('GR_EX_normete_L[e]')
    'ER_EX_mepi[e]'.('GR_EX_mepi[e]')
    'ER_EX_C05300[e]'.('GR_EX_C05300[e]')
    'ER_EX_retinal[e]'.('GR_EX_retinal[e]')
    'ER_EX_maltttr[e]'.('GR_EX_maltttr[e]')
    'ER_EX_1mncam[e]'.('GR_EX_1mncam[e]')
    'ER_EX_dhbpt[e]'.('GR_EX_dhbpt[e]')
    'ER_EX_thbpt[e]'.('GR_EX_thbpt[e]')
    'ER_EX_adprib[e]'.('GR_EX_adprib[e]')
    'ER_EX_homoval[e]'.('GR_EX_homoval[e]')
    'ER_GLYCLTtm'.('GR_GLYCLTtm')
    'ER_TYMc'.('GR_TYMc')
    'ER_PCHOL2PALM_HSte'.('GR_PCHOL2PALM_HSte')
    'ER_PE224_HSte'.('GR_PE224_HSte')
    'ER_PCHOLN261_HSte'.('GR_PCHOLN261_HSte')
    'ER_PCHOLN281_HSte'.('GR_PCHOLN281_HSte')
    'ER_PCHOLN28_HSte'.('GR_PCHOLN28_HSte')
    'ER_ACRNtr'.('GR_ACRNtr')
    'ER_HDCECRNtr'.('GR_HDCECRNtr')
    'ER_LNELDCCRNtr'.('GR_LNELDCCRNtr')
    'ER_ODECRNtr'.('GR_ODECRNtr')
    'ER_PMTCRNtr'.('GR_PMTCRNtr')
    'ER_STCRNtr'.('GR_STCRNtr')
    'ER_EX_sphmyln_hs[e]'.('GR_EX_sphmyln_hs[e]')
    'ER_PHEACGLYtm'.('GR_PHEACGLYtm')
    'ER_HXAt1'.('GR_HXAt1')
    'ER_HXAt2'.('GR_HXAt2')
    'ER_HXAt3'.('GR_HXAt3')
    'ER_EX_hxa[e]'.('GR_EX_hxa[e]')
    'ER_PACCOALm'.('GR_PACCOALm')
    'ER_PACALDtm'.('GR_PACALDtm')
    'ER_LHCYSTIN'.('GR_LHCYSTIN')
    'ER_LHCYSTINt'.('GR_LHCYSTINt')
    'ER_EX_Lhcystin[e]'.('GR_EX_Lhcystin[e]')
    'ER_PA_HStm'.('GR_PA_HStm')
    'ER_FldAct'.('GR_FldAct')
    'ER_MALOAtm'.('GR_MALOAtm')
    'ER_MLTHFtm'.('GR_MLTHFtm')
    'ER_2MOPtm'.('GR_2MOPtm')
    'ER_MMALtm'.('GR_MMALtm')
    'ER_PGPP_hsc'.('GR_PGPP_hsc')
    'ER_CE2512te'.('GR_CE2512te')
    'ER_r2514e'.('GR_r2514e')
    'ER_r2514m'.('GR_r2514m')
    'ER_FAS180'.('GR_FAS180')
    'ER_5AOPt2'.('GR_5AOPt2')
    'ER_ACNAMt2'.('GR_ACNAMt2')
    'ER_ADRNLtu'.('GR_ADRNLtu')
    'ER_DM_pe_hs[c]'.('GR_DM_pe_hs[c]')
    'ER_DM_akg[c]'.('GR_DM_akg[c]')
    'ER_DM_for[c]'.('GR_DM_for[c]')
    'ER_DM_mi1345p[c]'.('GR_DM_mi1345p[c]')
    'ER_DM_mi134p[c]'.('GR_DM_mi134p[c]')
    'ER_DM_mi145p[c]'.('GR_DM_mi145p[c]')
    'ER_DM_mi14p[c]'.('GR_DM_mi14p[c]')
    'ER_DM_pchol_hs[c]'.('GR_DM_pchol_hs[c]')
    'ER_ETHAt'.('GR_ETHAt')
    'ER_HCYSte'.('GR_HCYSte')
    'ER_OROte'.('GR_OROte')
    'ER_PPPGOc'.('GR_PPPGOc')
    'ER_SPRMt2r'.('GR_SPRMt2r')
    'ER_THMtrbc'.('GR_THMtrbc')
    'ER_UGT1A10c'.('GR_UGT1A10c')
    'ER_UNK3r'.('GR_UNK3r')
    'ER_ACGALtr'.('GR_ACGALtr')
    'ER_ACNAMtr'.('GR_ACNAMtr')
    'ER_CORE4t'.('GR_CORE4t')
    'ER_S2L2N2M2Mt'.('GR_S2L2N2M2Mt')
    'ER_EX_core4[e]'.('GR_EX_core4[e]')
    'ER_EX_f1a[e]'.('GR_EX_f1a[e]')
    'ER_EX_s2l2n2m2m[e]'.('GR_EX_s2l2n2m2m[e]')
    'ER_EX_acgal[e]'.('GR_EX_acgal[e]')
    'ER_EX_acnam[e]'.('GR_EX_acnam[e]')
    'ER_EX_pa_hs[e]'.('GR_EX_pa_hs[e]')
    'ER_DM_C02712[c]'.('GR_DM_C02712[c]')
    'ER_F1Ate'.('GR_F1Ate')
    'ER_34HPLtm'.('GR_34HPLtm')
    'ER_3HMPtm'.('GR_3HMPtm')
    'ER_3HPPtm'.('GR_3HPPtm')
    'ER_ACGLUtm'.('GR_ACGLUtm')
    'ER_PGP_hs_tm'.('GR_PGP_hs_tm')
    'ER_PROSTGE2t2r'.('GR_PROSTGE2t2r')
    'ER_ESTR2r'.('GR_ESTR2r')
    'ER_LTHSTRLtr'.('GR_LTHSTRLtr')
    'ER_PGLYCtm'.('GR_PGLYCtm')
    'ER_sink_25hvitd2[c]'.('GR_sink_25hvitd2[c]')
    'ER_sink_C02528[c]'.('GR_sink_C02528[c]')
    'ER_sink_HC02191[c]'.('GR_sink_HC02191[c]')
    'ER_sink_HC02194[c]'.('GR_sink_HC02194[c]')
    'ER_sink_HC02195[c]'.('GR_sink_HC02195[c]')
    'ER_sink_HC02196[c]'.('GR_sink_HC02196[c]')
    'ER_sink_HC02197[c]'.('GR_sink_HC02197[c]')
    'ER_sink_HC02198[c]'.('GR_sink_HC02198[c]')
    'ER_sink_HC02220[c]'.('GR_sink_HC02220[c]')
    'ER_sink_Tyr_ggn[c]'.('GR_sink_Tyr_ggn[c]')
    'ER_sink_avite1[c]'.('GR_sink_avite1[c]')
    'ER_sink_btn[c]'.('GR_sink_btn[c]')
    'ER_sink_c226coa[c]'.('GR_sink_c226coa[c]')
    'ER_sink_chol[c]'.('GR_sink_chol[c]')
    'ER_sink_cholate[c]'.('GR_sink_cholate[c]')
    'ER_sink_coa[c]'.('GR_sink_coa[c]')
    'ER_sink_crvnc[c]'.('GR_sink_crvnc[c]')
    'ER_sink_dgchol[c]'.('GR_sink_dgchol[c]')
    'ER_sink_doco13ecoa[c]'.('GR_sink_doco13ecoa[c]')
    'ER_sink_fad[c]'.('GR_sink_fad[c]')
    'ER_sink_fe3[c]'.('GR_sink_fe3[c]')
    'ER_sink_gchola[c]'.('GR_sink_gchola[c]')
    'ER_sink_glygn2[c]'.('GR_sink_glygn2[c]')
    'ER_sink_hdca[c]'.('GR_sink_hdca[c]')
    'ER_sink_lnlc[c]'.('GR_sink_lnlc[c]')
    'ER_sink_lnlccoa[c]'.('GR_sink_lnlccoa[c]')
    'ER_sink_lnlncacoa[c]'.('GR_sink_lnlncacoa[c]')
    'ER_sink_lnlncgcoa[c]'.('GR_sink_lnlncgcoa[c]')
    'ER_sink_nad[c]'.('GR_sink_nad[c]')
    'ER_sink_nadp[c]'.('GR_sink_nadp[c]')
    'ER_sink_odecoa[c]'.('GR_sink_odecoa[c]')
    'ER_sink_pmtcoa[c]'.('GR_sink_pmtcoa[c]')
    'ER_sink_pydam[c]'.('GR_sink_pydam[c]')
    'ER_sink_pydx[c]'.('GR_sink_pydx[c]')
    'ER_sink_pydxn[c]'.('GR_sink_pydxn[c]')
    'ER_sink_retfa[c]'.('GR_sink_retfa[c]')
    'ER_sink_retinol[c]'.('GR_sink_retinol[c]')
    'ER_sink_stcoa[c]'.('GR_sink_stcoa[c]')
    'ER_sink_tag_hs[c]'.('GR_sink_tag_hs[c]')
    'ER_sink_tchola[c]'.('GR_sink_tchola[c]')
    'ER_sink_tdchola[c]'.('GR_sink_tdchola[c]')
    'ER_sink_thf[c]'.('GR_sink_thf[c]')
    'ER_sink_thmpp[c]'.('GR_sink_thmpp[c]')
    'ER_sink_thmtp[c]'.('GR_sink_thmtp[c]')
    'ER_sink_tmndnc[c]'.('GR_sink_tmndnc[c]')
    'ER_sink_tmndnccoa[c]'.('GR_sink_tmndnccoa[c]')
    'ER_sink_vitd3[c]'.('GR_sink_vitd3[c]')
    'ER_DXTRNt'.('GR_DXTRNt')
    'ER_EX_dxtrn[e]'.('GR_EX_dxtrn[e]')
    'ER_EX_dhcholestanate[e]'.('GR_EX_dhcholestanate[e]')
    'ER_sink_dhcholestanate[c]'.('GR_sink_dhcholestanate[c]')
    'ER_EX_thcholstoic[e]'.('GR_EX_thcholstoic[e]')
    'ER_sink_thcholstoic[c]'.('GR_sink_thcholstoic[c]')
    'ER_EX_xol7ah3[e]'.('GR_EX_xol7ah3[e]')
    'ER_sink_xol7ah3[c]'.('GR_sink_xol7ah3[c]')
    'ER_EX_xol7aone[e]'.('GR_EX_xol7aone[e]')
    'ER_sink_xol7aone[c]'.('GR_sink_xol7aone[c]')
    'ER_EX_xoldiolone[e]'.('GR_EX_xoldiolone[e]')
    'ER_sink_xoldiolone[c]'.('GR_sink_xoldiolone[c]')
    'ER_EX_7klitchol[e]'.('GR_EX_7klitchol[e]')
    'ER_sink_7klitchol[c]'.('GR_sink_7klitchol[c]')
    'ER_sink_dchac[c]'.('GR_sink_dchac[c]')
    'ER_EX_2obut[e]'.('GR_EX_2obut[e]')
    'ER_EX_glcn[e]'.('GR_EX_glcn[e]')
    'ER_CO2t'.('GR_CO2t')
    'ER_DM_atp_c_'.('GR_DM_atp_c_')
    'ER_EX_acac[e]'.('GR_EX_acac[e]')
    'ER_EX_adn[e]'.('GR_EX_adn[e]')
    'ER_EX_akg[e]'.('GR_EX_akg[e]')
    'ER_EX_asn_L[e]'.('GR_EX_asn_L[e]')
    'ER_EX_asp_L[e]'.('GR_EX_asp_L[e]')
    'ER_EX_but[e]'.('GR_EX_but[e]')
    'ER_EX_cgly[e]'.('GR_EX_cgly[e]')
    'ER_EX_co2[e]'.('GR_EX_co2[e]')
    'ER_EX_cytd[e]'.('GR_EX_cytd[e]')
    'ER_EX_dad_2[e]'.('GR_EX_dad_2[e]')
    'ER_EX_dcyt[e]'.('GR_EX_dcyt[e]')
    'ER_EX_dgsn[e]'.('GR_EX_dgsn[e]')
    'ER_EX_din[e]'.('GR_EX_din[e]')
    'ER_EX_duri[e]'.('GR_EX_duri[e]')
    'ER_EX_fe2[e]'.('GR_EX_fe2[e]')
    'ER_EX_fe3[e]'.('GR_EX_fe3[e]')
    'ER_EX_fum[e]'.('GR_EX_fum[e]')
    'ER_EX_gal[e]'.('GR_EX_gal[e]')
    'ER_EX_glu_L[e]'.('GR_EX_glu_L[e]')
    'ER_EX_h[e]'.('GR_EX_h[e]')
    'ER_EX_h2o[e]'.('GR_EX_h2o[e]')
    'ER_EX_ile_L[e]'.('GR_EX_ile_L[e]')
    'ER_EX_ins[e]'.('GR_EX_ins[e]')
    'ER_EX_k[e]'.('GR_EX_k[e]')
    'ER_EX_lac_L[e]'.('GR_EX_lac_L[e]')
    'ER_EX_leu_L[e]'.('GR_EX_leu_L[e]')
    'ER_EX_lys_L[e]'.('GR_EX_lys_L[e]')
    'ER_EX_mal_L[e]'.('GR_EX_mal_L[e]')
    'ER_EX_met_L[e]'.('GR_EX_met_L[e]')
    'ER_EX_na1[e]'.('GR_EX_na1[e]')
    'ER_EX_no2[e]'.('GR_EX_no2[e]')
    'ER_EX_o2[e]'.('GR_EX_o2[e]')
    'ER_EX_orn[e]'.('GR_EX_orn[e]')
    'ER_EX_pi[e]'.('GR_EX_pi[e]')
    'ER_EX_ppi[e]'.('GR_EX_ppi[e]')
    'ER_EX_pro_L[e]'.('GR_EX_pro_L[e]')
    'ER_EX_ribflv[e]'.('GR_EX_ribflv[e]')
    'ER_EX_ser_L[e]'.('GR_EX_ser_L[e]')
    'ER_EX_so4[e]'.('GR_EX_so4[e]')
    'ER_EX_succ[e]'.('GR_EX_succ[e]')
    'ER_EX_thymd[e]'.('GR_EX_thymd[e]')
    'ER_EX_urea[e]'.('GR_EX_urea[e]')
    'ER_EX_uri[e]'.('GR_EX_uri[e]')
    'ER_EX_val_L[e]'.('GR_EX_val_L[e]')
    'ER_FCLTc'.('GR_FCLTc')
    'ER_FT'.('GR_FT')
    'ER_G5SADs'.('GR_G5SADs')
    'ER_O2t'.('GR_O2t')
    'ER_PIt6b'.('GR_PIt6b')
    'ER_URIDK3'.('GR_URIDK3')
    'ER_EX_pnto_R[e]'.('GR_EX_pnto_R[e]')
    'ER_EX_gly[e]'.('GR_EX_gly[e]')
    'ER_EX_cys_L[e]'.('GR_EX_cys_L[e]')
    'ER_EX_ala_L[e]'.('GR_EX_ala_L[e]')
    'ER_EX_his_L[e]'.('GR_EX_his_L[e]')
    'ER_EX_thr_L[e]'.('GR_EX_thr_L[e]')
    'ER_EX_gln_L[e]'.('GR_EX_gln_L[e]')
    'ER_EX_phe_L[e]'.('GR_EX_phe_L[e]')
    'ER_EX_tyr_L[e]'.('GR_EX_tyr_L[e]')
    'ER_EX_arg_L[e]'.('GR_EX_arg_L[e]')
    'ER_EX_for[e]'.('GR_EX_for[e]')
    'ER_EX_nac[e]'.('GR_EX_nac[e]')
    'ER_EX_ind3ac[e]'.('GR_EX_ind3ac[e]')
    'ER_EX_nh4[e]'.('GR_EX_nh4[e]')
    'ER_EX_ac[e]'.('GR_EX_ac[e]')
    'ER_CSND'.('GR_CSND')
    'ER_EX_acgam[e]'.('GR_EX_acgam[e]')
    'ER_EX_cit[e]'.('GR_EX_cit[e]')
    'ER_EX_csn[e]'.('GR_EX_csn[e]')
    'ER_EX_drib[e]'.('GR_EX_drib[e]')
    'ER_EX_etha[e]'.('GR_EX_etha[e]')
    'ER_EX_fol[e]'.('GR_EX_fol[e]')
    'ER_EX_fru[e]'.('GR_EX_fru[e]')
    'ER_EX_galt[e]'.('GR_EX_galt[e]')
    'ER_EX_glcr[e]'.('GR_EX_glcr[e]')
    'ER_EX_glcur[e]'.('GR_EX_glcur[e]')
    'ER_EX_glyc[e]'.('GR_EX_glyc[e]')
    'ER_EX_hxan[e]'.('GR_EX_hxan[e]')
    'ER_EX_malt[e]'.('GR_EX_malt[e]')
    'ER_EX_malthx[e]'.('GR_EX_malthx[e]')
    'ER_EX_malttr[e]'.('GR_EX_malttr[e]')
    'ER_EX_man[e]'.('GR_EX_man[e]')
    'ER_EX_ptrc[e]'.('GR_EX_ptrc[e]')
    'ER_EX_rib_D[e]'.('GR_EX_rib_D[e]')
    'ER_EX_spmd[e]'.('GR_EX_spmd[e]')
    'ER_EX_thm[e]'.('GR_EX_thm[e]')
    'ER_EX_trp_L[e]'.('GR_EX_trp_L[e]')
    'ER_EX_ura[e]'.('GR_EX_ura[e]')
    'ER_EX_xan[e]'.('GR_EX_xan[e]')
    'ER_EX_xyl_D[e]'.('GR_EX_xyl_D[e]')
    'ER_NTD5_a'.('GR_NTD5_a')
    'ER_OAADC'.('GR_OAADC')
    'ER_EX_pydxn[e]'.('GR_EX_pydxn[e]')
    'ER_PYDXNtr'.('GR_PYDXNtr')
    'ER_EX_pydx[e]'.('GR_EX_pydx[e]')
    'ER_PYDXtr'.('GR_PYDXtr')
    'ER_EX_pydam[e]'.('GR_EX_pydam[e]')
    'ER_PYDAMtr'.('GR_PYDAMtr')
    'ER_EX_4hbz[e]'.('GR_EX_4hbz[e]')
    'ER_EX_ppa[e]'.('GR_EX_ppa[e]')
    'ER_EX_arab_L[e]'.('GR_EX_arab_L[e]')
    'ER_EX_gam[e]'.('GR_EX_gam[e]')
    'ER_EX_pyr[e]'.('GR_EX_pyr[e]')
    'ER_EX_tre[e]'.('GR_EX_tre[e]')
    'ER_EX_btn[e]'.('GR_EX_btn[e]')
    'ER_EX_lcts[e]'.('GR_EX_lcts[e]')
    'ER_EX_ade[e]'.('GR_EX_ade[e]')
    'ER_EX_etoh[e]'.('GR_EX_etoh[e]')
    'ER_ETOHt'.('GR_ETOHt')
    'ER_EX_acald[e]'.('GR_EX_acald[e]')
    'ER_ACALDt'.('GR_ACALDt')
    'ER_EX_sucr[e]'.('GR_EX_sucr[e]')
    'ER_EX_pheme[e]'.('GR_EX_pheme[e]')
    'ER_MTRI'.('GR_MTRI')
    'ER_EX_gua[e]'.('GR_EX_gua[e]')
    'ER_EX_4abut[e]'.('GR_EX_4abut[e]')
    'ER_OBDHc'.('GR_OBDHc')
    'ER_EX_phpyr[e]'.('GR_EX_phpyr[e]')
    'ER_EX_lanost[e]'.('GR_EX_lanost[e]')
    'ER_3MOX4HOXMte'.('GR_3MOX4HOXMte')
    'ER_EX_3mox4hoxm[e]'.('GR_EX_3mox4hoxm[e]')
    'ER_2H3MVte'.('GR_2H3MVte')
    'ER_EX_2h3mv[e]'.('GR_EX_2h3mv[e]')
    'ER_2HIVte'.('GR_2HIVte')
    'ER_EX_2hiv[e]'.('GR_EX_2hiv[e]')
    'ER_2M3HBUc'.('GR_2M3HBUc')
    'ER_2M3HBUtm'.('GR_2M3HBUtm')
    'ER_2M3HBUte'.('GR_2M3HBUte')
    'ER_EX_2m3hbu[e]'.('GR_EX_2m3hbu[e]')
    'ER_3H3MGLTc'.('GR_3H3MGLTc')
    'ER_3H3MGLTte'.('GR_3H3MGLTte')
    'ER_EX_3h3mglt[e]'.('GR_EX_3h3mglt[e]')
    'ER_3MGLUTACc'.('GR_3MGLUTACc')
    'ER_3MGLUTACtm'.('GR_3MGLUTACtm')
    'ER_3MGLUTACte'.('GR_3MGLUTACte')
    'ER_EX_3mglutac[e]'.('GR_EX_3mglutac[e]')
    'ER_PPIOGLYtm'.('GR_PPIOGLYtm')
    'ER_PPIOGLYte'.('GR_PPIOGLYte')
    'ER_EX_ppiogly[e]'.('GR_EX_ppiogly[e]')
    'ER_TIGGLYtm'.('GR_TIGGLYtm')
    'ER_TIGGLYte'.('GR_TIGGLYte')
    'ER_EX_tiggly[e]'.('GR_EX_tiggly[e]')
    'ER_GLUTACOAm'.('GR_GLUTACOAm')
    'ER_GLUTCONm'.('GR_GLUTCONm')
    'ER_GLUTCONtm'.('GR_GLUTCONtm')
    'ER_GLUTCONte'.('GR_GLUTCONte')
    'ER_EX_glutcon[e]'.('GR_EX_glutcon[e]')
    'ER_3HIVAcm'.('GR_3HIVAcm')
    'ER_3HIVActm'.('GR_3HIVActm')
    'ER_3HIVActe'.('GR_3HIVActe')
    'ER_EX_3hivac[e]'.('GR_EX_3hivac[e]')
    'ER_3HADPACx'.('GR_3HADPACx')
    'ER_3HADPACtxc'.('GR_3HADPACtxc')
    'ER_3HADPACte'.('GR_3HADPACte')
    'ER_EX_3hadpac[e]'.('GR_EX_3hadpac[e]')
    'ER_3OHSEBACx'.('GR_3OHSEBACx')
    'ER_3OHSEBACtxc'.('GR_3OHSEBACtxc')
    'ER_3OHSEBACte'.('GR_3OHSEBACte')
    'ER_EX_3ohsebac[e]'.('GR_EX_3ohsebac[e]')
    'ER_3OHSUBACx'.('GR_3OHSUBACx')
    'ER_3OHSUBACtxc'.('GR_3OHSUBACtxc')
    'ER_3OHSUBACte'.('GR_3OHSUBACte')
    'ER_EX_3ohsubac[e]'.('GR_EX_3ohsubac[e]')
    'ER_CAPROICc'.('GR_CAPROICc')
    'ER_5OHHEXAc'.('GR_5OHHEXAc')
    'ER_5OHHEXAte'.('GR_5OHHEXAte')
    'ER_EX_5ohhexa[e]'.('GR_EX_5ohhexa[e]')
    'ER_ETHMALCOAc'.('GR_ETHMALCOAc')
    'ER_ETHMALACc'.('GR_ETHMALACc')
    'ER_ETHMALACte'.('GR_ETHMALACte')
    'ER_EX_ethmalac[e]'.('GR_EX_ethmalac[e]')
    'ER_HEXGLYte'.('GR_HEXGLYte')
    'ER_EX_hexgly[e]'.('GR_EX_hexgly[e]')
    'ER_SUBGLYte'.('GR_SUBGLYte')
    'ER_EX_subgly[e]'.('GR_EX_subgly[e]')
    'ER_4OHBUTm'.('GR_4OHBUTm')
    'ER_4OHBUTtmc'.('GR_4OHBUTtmc')
    'ER_4OHBUTtce'.('GR_4OHBUTtce')
    'ER_EX_4ohbut[e]'.('GR_EX_4ohbut[e]')
    'ER_12HPETUPKt'.('GR_12HPETUPKt')
    'ER_15HPETUPKt'.('GR_15HPETUPKt')
    'ER_3AIBSYMPt'.('GR_3AIBSYMPt')
    'ER_CE7172UPKt'.('GR_CE7172UPKt')
    'ER_PAIL_hs_SECt'.('GR_PAIL_hs_SECt')
    'ER_PAILPALM_HSSECt'.('GR_PAILPALM_HSSECt')
    'ER_PAILR_HSSECt'.('GR_PAILR_HSSECt')
    'ER_SPHMYLN_HsSECt'.('GR_SPHMYLN_HsSECt')
    'ER_SPHMYLN180241_hs_SECt'.('GR_SPHMYLN180241_hs_SECt')
    'ER_SPHMYLN18114_hs_SECt'.('GR_SPHMYLN18114_hs_SECt')
    'ER_SPHMYLN18115_hs_SECt'.('GR_SPHMYLN18115_hs_SECt')
    'ER_SPHMYLN18116_hs_SECt'.('GR_SPHMYLN18116_hs_SECt')
    'ER_SPHMYLN181161_hs_SECt'.('GR_SPHMYLN181161_hs_SECt')
    'ER_SPHMYLN18117_hs_SECt'.('GR_SPHMYLN18117_hs_SECt')
    'ER_SPHMYLN18118_hs_SECt'.('GR_SPHMYLN18118_hs_SECt')
    'ER_SPHMYLN181181_hs_SECt'.('GR_SPHMYLN181181_hs_SECt')
    'ER_SPHMYLN18120_hs_SECt'.('GR_SPHMYLN18120_hs_SECt')
    'ER_SPHMYLN181201_hs_SECt'.('GR_SPHMYLN181201_hs_SECt')
    'ER_SPHMYLN18121_hs_SECt'.('GR_SPHMYLN18121_hs_SECt')
    'ER_SPHMYLN18122_hs_SECt'.('GR_SPHMYLN18122_hs_SECt')
    'ER_SPHMYLN181221_hs_SECt'.('GR_SPHMYLN181221_hs_SECt')
    'ER_SPHMYLN18123_hs_SECt'.('GR_SPHMYLN18123_hs_SECt')
    'ER_SPHMYLN1824_hs_SECt'.('GR_SPHMYLN1824_hs_SECt')
    'ER_SPHMYLN1825_hs_SECt'.('GR_SPHMYLN1825_hs_SECt')
    'ER_3AIBt1'.('GR_3AIBt1')
    'ER_AK2LGCHOLt1'.('GR_AK2LGCHOLt1')
    'ER_PAFt1'.('GR_PAFt1')
    'ER_PCHOL2LINL_HSt1e'.('GR_PCHOL2LINL_HSt1e')
    'ER_PCHOL2OLE_HSt1e'.('GR_PCHOL2OLE_HSt1e')
    'ER_PCHOL2STE_HSt1e'.('GR_PCHOL2STE_HSt1e')
    'ER_PCHOLAR_HSt1e'.('GR_PCHOLAR_HSt1e')
    'ER_PCHOLDOC_HSt1e'.('GR_PCHOLDOC_HSt1e')
    'ER_PCHOLEIC_HSt1e'.('GR_PCHOLEIC_HSt1e')
    'ER_PCHOLET_HSt1e'.('GR_PCHOLET_HSt1e')
    'ER_PCHOLHEP_HSt1e'.('GR_PCHOLHEP_HSt1e')
    'ER_PCHOLLINL_HSt1e'.('GR_PCHOLLINL_HSt1e')
    'ER_PCHOLMYR_Hst1e'.('GR_PCHOLMYR_Hst1e')
    'ER_PCHOLN15_HSt1e'.('GR_PCHOLN15_HSt1e')
    'ER_PCHOLN183_HSt1e'.('GR_PCHOLN183_HSt1e')
    'ER_PCHOLN1836_HSt1e'.('GR_PCHOLN1836_HSt1e')
    'ER_PCHOLN19_HSt1e'.('GR_PCHOLN19_HSt1e')
    'ER_PCHOLN201_HSt1e'.('GR_PCHOLN201_HSt1e')
    'ER_PCHOLN203_HSt1e'.('GR_PCHOLN203_HSt1e')
    'ER_PCHOLN204_HSt1e'.('GR_PCHOLN204_HSt1e')
    'ER_PCHOLN205_HSt1e'.('GR_PCHOLN205_HSt1e')
    'ER_PCHOLN224_HSt1e'.('GR_PCHOLN224_HSt1e')
    'ER_PCHOLN225_HSt1e'.('GR_PCHOLN225_HSt1e')
    'ER_PCHOLN2254_HSt1e'.('GR_PCHOLN2254_HSt1e')
    'ER_PCHLN225_HSt1e'.('GR_PCHLN225_HSt1e')
    'ER_PCHOLN264_HSt1e'.('GR_PCHOLN264_HSt1e')
    'ER_PCHOLOLE_HSt1e'.('GR_PCHOLOLE_HSt1e')
    'ER_PEPALM_HSt1e'.('GR_PEPALM_HSt1e')
    'ER_PCHOLPALME-HSt1e'.('GR_PCHOLPALME-HSt1e')
    'ER_PCHOLSTE_HSt1e'.('GR_PCHOLSTE_HSt1e')
    'ER_PE12_HSt1e'.('GR_PE12_HSt1e')
    'ER_Pe13_HSt1e'.('GR_Pe13_HSt1e')
    'ER_PE14_HSt1e'.('GR_PE14_HSt1e')
    'ER_PE15_HSt1e'.('GR_PE15_HSt1e')
    'ER_PE161_HSt1e'.('GR_PE161_HSt1e')
    'ER_PE17_HSt1e'.('GR_PE17_HSt1e')
    'ER_PE203_HSt1e'.('GR_PE203_HSt1e')
    'ER_PE226_HSt1e'.('GR_PE226_HSt1e')
    'ER_PE2LINL_HSt1e'.('GR_PE2LINL_HSt1e')
    'ER_PEAR_HSt1e'.('GR_PEAR_HSt1e')
    'ER_PEDH203_HSt1e'.('GR_PEDH203_HSt1e')
    'ER_PELINL_HSt1e'.('GR_PELINL_HSt1e')
    'ER_PEOLE_HSt1e'.('GR_PEOLE_HSt1e')
    'ER_PELPALM_HSt1e'.('GR_PELPALM_HSt1e')
    'ER_PESTE_HSt1e'.('GR_PESTE_HSt1e')
    'ER_EIC21114TRte'.('GR_EIC21114TRte')
    'ER_EX_eic21114tr[e]'.('GR_EX_eic21114tr[e]')
    'ER_5EIPENCte'.('GR_5EIPENCte')
    'ER_EX_5eipenc[e]'.('GR_EX_5eipenc[e]')
    'ER_ISOBUTtm'.('GR_ISOBUTtm')
    'ER_ISOBUTte'.('GR_ISOBUTte')
    'ER_EX_CE4969[e]'.('GR_EX_CE4969[e]')
    'ER_NACCYStm'.('GR_NACCYStm')
    'ER_NACCYSte'.('GR_NACCYSte')
    'ER_EX_CE1310[e]'.('GR_EX_CE1310[e]')
    'ER_AGRMtm'.('GR_AGRMtm')
    'ER_EX_agm[e]'.('GR_EX_agm[e]')
    'ER_T4HCINNMtm'.('GR_T4HCINNMtm')
    'ER_EX_T4hcinnm[e]'.('GR_EX_T4hcinnm[e]')
    'ER_4HBZte'.('GR_4HBZte')
    'ER_SUCSALtm'.('GR_SUCSALtm')
    'ER_SUCSALte'.('GR_SUCSALte')
    'ER_EX_sucsal[e]'.('GR_EX_sucsal[e]')
    'ER_CE7081tr'.('GR_CE7081tr')
    'ER_CE7081tm'.('GR_CE7081tm')
    'ER_EX_CE7081[e]'.('GR_EX_CE7081[e]')
    'ER_EGMEtr'.('GR_EGMEtr')
    'ER_EGMEte'.('GR_EGMEte')
    'ER_EX_egme[e]'.('GR_EX_egme[e]')
    'ER_SQLtr'.('GR_SQLtr')
    'ER_SQLte'.('GR_SQLte')
    'ER_EX_sql[e]'.('GR_EX_sql[e]')
    'ER_ORN_Dte'.('GR_ORN_Dte')
    'ER_EX_orn_D[e]'.('GR_EX_orn_D[e]')
    'ER_5G2OXPTtx'.('GR_5G2OXPTtx')
    'ER_5G2OXPTte'.('GR_5G2OXPTte')
    'ER_EX_5g2oxpt[e]'.('GR_EX_5g2oxpt[e]')
    'ER_DHEAte'.('GR_DHEAte')
    'ER_EX_dhea[e]'.('GR_EX_dhea[e]')
    'ER_ANDRSTANDRtr'.('GR_ANDRSTANDRtr')
    'ER_EX_andrstandn[e]'.('GR_EX_andrstandn[e]')
    'ER_ESTRONEte'.('GR_ESTRONEte')
    'ER_EX_estrone[e]'.('GR_EX_estrone[e]')
    'ER_HC02020tr'.('GR_HC02020tr')
    'ER_HC02020te'.('GR_HC02020te')
    'ER_EX_HC02020[e]'.('GR_EX_HC02020[e]')
    'ER_XOL27OHte'.('GR_XOL27OHte')
    'ER_EX_xol27oh[e]'.('GR_EX_xol27oh[e]')
    'ER_XOL25OHtr'.('GR_XOL25OHtr')
    'ER_XOL25OHte'.('GR_XOL25OHte')
    'ER_EX_xol25oh[e]'.('GR_EX_xol25oh[e]')
    'ER_DSMSTEROLtr'.('GR_DSMSTEROLtr')
    'ER_DSMSTEROLte'.('GR_DSMSTEROLte')
    'ER_EX_dsmsterol[e]'.('GR_EX_dsmsterol[e]')
    'ER_CHSTEROLSte'.('GR_CHSTEROLSte')
    'ER_EX_chsterols[e]'.('GR_EX_chsterols[e]')
    'ER_3ITYR_Lte'.('GR_3ITYR_Lte')
    'ER_EX_3ityr_L[e]'.('GR_EX_3ityr_L[e]')
    'ER_35DIODTYRte'.('GR_35DIODTYRte')
    'ER_EX_35diotyr[e]'.('GR_EX_35diotyr[e]')
    'ER_13_CIS_RETNte'.('GR_13_CIS_RETNte')
    'ER_EX_13_cis_retn[e]'.('GR_EX_13_cis_retn[e]')
    'ER_LDL_HSDEG'.('GR_LDL_HSDEG')
    'ER_EX_34dhoxmand[e]'.('GR_EX_34dhoxmand[e]')
    'ER_EX_CE7090[e]'.('GR_EX_CE7090[e]')
    'ER_EX_CE7085[e]'.('GR_EX_CE7085[e]')
    'ER_EX_CE7096[e]'.('GR_EX_CE7096[e]')
    'ER_EX_CE4877[e]'.('GR_EX_CE4877[e]')
    'ER_EX_CE1447[e]'.('GR_EX_CE1447[e]')
    'ER_EX_CE6205[e]'.('GR_EX_CE6205[e]')
    'ER_EX_trypta[e]'.('GR_EX_trypta[e]')
    'ER_C05767te'.('GR_C05767te')
    'ER_EX_C05767[e]'.('GR_EX_C05767[e]')
    'ER_C05770te3'.('GR_C05770te3')
    'ER_EX_C05770[e]'.('GR_EX_C05770[e]')
    'ER_EX_mhista[e]'.('GR_EX_mhista[e]')
    'ER_PPBNGte'.('GR_PPBNGte')
    'ER_EX_ppbng[e]'.('GR_EX_ppbng[e]')
    'ER_EX_mma[e]'.('GR_EX_mma[e]')
    'ER_12PPDRte'.('GR_12PPDRte')
    'ER_EX_12ppd_R[e]'.('GR_EX_12ppd_R[e]')
    'ER_AMETAMte'.('GR_AMETAMte')
    'ER_EX_ametam[e]'.('GR_EX_ametam[e]')
    'ER_XYLULte'.('GR_XYLULte')
    'ER_EX_xylu_L[e]'.('GR_EX_xylu_L[e]')
    'ER_XYLUDte'.('GR_XYLUDte')
    'ER_EX_xylu_D[e]'.('GR_EX_xylu_D[e]')
    'ER_GLCNte'.('GR_GLCNte')
    'ER_SPHGNSte'.('GR_SPHGNSte')
    'ER_EX_sphings[e]'.('GR_EX_sphings[e]')
    'ER_HDD2CRNte'.('GR_HDD2CRNte')
    'ER_EX_hdd2crn[e]'.('GR_EX_hdd2crn[e]')
    'ER_IM4ACte'.('GR_IM4ACte')
    'ER_EX_im4ac[e]'.('GR_EX_im4ac[e]')
    'ER_EX_CE1918[e]'.('GR_EX_CE1918[e]')
    'ER_EX_mlthf[e]'.('GR_EX_mlthf[e]')
    'ER_EX_CE2705[e]'.('GR_EX_CE2705[e]')
    'ER_SPHGNte'.('GR_SPHGNte')
    'ER_EX_sphgn[e]'.('GR_EX_sphgn[e]')
    'ER_EX_N1aspmd[e]'.('GR_EX_N1aspmd[e]')
    'ER_C13856te'.('GR_C13856te')
    'ER_EX_1a25dhvitd3[e]'.('GR_EX_1a25dhvitd3[e]')
    'ER_PRISTte'.('GR_PRISTte')
    'ER_EX_prist[e]'.('GR_EX_prist[e]')
    'ER_CE2049te'.('GR_CE2049te')
    'ER_EX_CE2049[e]'.('GR_EX_CE2049[e]')
    'ER_CE2047te'.('GR_CE2047te')
    'ER_EX_CE2047[e]'.('GR_EX_CE2047[e]')
    'ER_LANOSTte'.('GR_LANOSTte')
    'ER_FDPte'.('GR_FDPte')
    'ER_EX_fdp[e]'.('GR_EX_fdp[e]')
    'ER_EX_coke[e]'.('GR_EX_coke[e]')
    'ER_COKEte'.('GR_COKEte')
    'ER_COKEtr'.('GR_COKEtr')
    'ER_EX_5a2opntn[e]'.('GR_EX_5a2opntn[e]')
    'ER_5A2OPNTNte'.('GR_5A2OPNTNte')
    'ER_5A2OPNTNtx'.('GR_5A2OPNTNtx')
    'ER_ARG_Dtx'.('GR_ARG_Dtx')
    'ER_ARG_Dte'.('GR_ARG_Dte')
    'ER_EX_arg_D[e]'.('GR_EX_arg_D[e]')
    'ER_LANOSTtr'.('GR_LANOSTtr')
    'ER_EX_ldl_hs[e]'.('GR_EX_ldl_hs[e]')
    'ER_EX_HC00005[e]'.('GR_EX_HC00005[e]')
    'ER_CE1261t'.('GR_CE1261t')
    'ER_DOPAOQNOX'.('GR_DOPAOQNOX')
    'ER_DOPAOQCYS'.('GR_DOPAOQCYS')
    'ER_DACT'.('GR_DACT')
    'ER_CE5629t'.('GR_CE5629t')
    'ER_EX_CE5629[e]'.('GR_EX_CE5629[e]')
    'ER_CRMte'.('GR_CRMte')
    'ER_EX_gd3_hs[e]'.('GR_EX_gd3_hs[e]')
    'ER_EX_gluside_hs[e]'.('GR_EX_gluside_hs[e]')
    'ER_GALGLUSIDEtg2'.('GR_GALGLUSIDEtg2')
    'ER_GD3tg'.('GR_GD3tg')
    'ER_GD3tl'.('GR_GD3tl')
    'ER_GLUSIDEte'.('GR_GLUSIDEte')
    'ER_GLUSIDEtg'.('GR_GLUSIDEtg')
    'ER_GLUSIDEtl'.('GR_GLUSIDEtl')
    'ER_GM1tg'.('GR_GM1tg')
    'ER_GM1tl'.('GR_GM1tl')
    'ER_SPHMYLNtl2'.('GR_SPHMYLNtl2')
    'ER_RE3477C1'.('GR_RE3477C1')
    'ER_NH4tr'.('GR_NH4tr')
    'ER_UDPGALt2n'.('GR_UDPGALt2n')
    'ER_THCRMtl'.('GR_THCRMtl')
    'ER_DAG_HStg'.('GR_DAG_HStg')
    'ER_SPHGNtn'.('GR_SPHGNtn')
    'ER_SPHGNtg'.('GR_SPHGNtg')
    'ER_SPHINGStn'.('GR_SPHINGStn')
    'ER_SPHINGStg'.('GR_SPHINGStg')
    'ER_DHCRMtg'.('GR_DHCRMtg')
    'ER_GDA1tn'.('GR_GDA1tn')
    'ER_sink_34dhpac[c]'.('GR_sink_34dhpac[c]')
    'ER_34DHPEt'.('GR_34DHPEt')
    'ER_EX_34dhpe[e]'.('GR_EX_34dhpe[e]')
    'ER_DM_sph1p[n]'.('GR_DM_sph1p[n]')
    'ER_DM_sphs1p[n]'.('GR_DM_sphs1p[n]')
    'ER_DM_gm1_hs[n]'.('GR_DM_gm1_hs[n]')
    'ER_DM_gda1_hs[n]'.('GR_DM_gda1_hs[n]')
    'ER_DM_6hddopaqn[c]'.('GR_DM_6hddopaqn[c]')
    'ER_GALSIDEtn'.('GR_GALSIDEtn')
    'ER_CERT1tn'.('GR_CERT1tn')
    'ER_Rtotaltg'.('GR_Rtotaltg')
    'ER_GD1Atg'.('GR_GD1Atg')
    'ER_GD1Atn'.('GR_GD1Atn')
    'ER_ATPtg'.('GR_ATPtg')
    'ER_GD3tlc'.('GR_GD3tlc')
    'ER_GD3tm'.('GR_GD3tm')
    'ER_DM_pail35p_hs[n]'.('GR_DM_pail35p_hs[n]')
    'ER_DM_gd3_hs[m]'.('GR_DM_gd3_hs[m]')
    'ER_CATr'.('GR_CATr')
    'ER_S2L2N2M2Mtl'.('GR_S2L2N2M2Mtl')
    'ER_DM_k[g]'.('GR_DM_k[g]')
    'ER_DM_na1[g]'.('GR_DM_na1[g]')
    'ER_DM_retn[n]'.('GR_DM_retn[n]')
    'ER_DM_15HPET[n]'.('GR_DM_15HPET[n]')
    'ER_DM_15HPET[x]'.('GR_DM_15HPET[x]')
    'ER_DM_15HPET[r]'.('GR_DM_15HPET[r]')
    'ER_sink_Ser_Gly_Ala_X_Gly[r]'.('GR_sink_Ser_Gly_Ala_X_Gly[r]')
    'ER_EX_pail_hs[e]'.('GR_EX_pail_hs[e]')
    'ER_EX_CE5026[e]'.('GR_EX_CE5026[e]')
    'ER_EX_CE1261[e]'.('GR_EX_CE1261[e]')
    'ER_EX_galgluside_hs[e]'.('GR_EX_galgluside_hs[e]')
    'ER_EX_gm1_hs[e]'.('GR_EX_gm1_hs[e]')
    'ER_HMR_0015'.('GR_HMR_0015')
    'ER_HMR_0020'.('GR_HMR_0020')
    'ER_HMR_0157'.('GR_HMR_0157')
    'ER_HMR_0166'.('GR_HMR_0166')
    'ER_HMR_0172'.('GR_HMR_0172')
    'ER_HMR_0178'.('GR_HMR_0178')
    'ER_HMR_0182'.('GR_HMR_0182')
    'ER_HMR_0185'.('GR_HMR_0185')
    'ER_HMR_0763'.('GR_HMR_0763')
    'ER_HMR_0769'.('GR_HMR_0769')
    'ER_HMR_0771'.('GR_HMR_0771')
    'ER_HMR_0809'.('GR_HMR_0809')
    'ER_HMR_0831'.('GR_HMR_0831')
    'ER_HMR_0912'.('GR_HMR_0912')
    'ER_HMR_0913'.('GR_HMR_0913')
    'ER_HMR_0962'.('GR_HMR_0962')
    'ER_HMR_0984'.('GR_HMR_0984')
    'ER_HMR_1095'.('GR_HMR_1095')
    'ER_HMR_1104'.('GR_HMR_1104')
    'ER_HMR_1135'.('GR_HMR_1135')
    'ER_HMR_1242'.('GR_HMR_1242')
    'ER_HMR_1243'.('GR_HMR_1243')
    'ER_HMR_1283'.('GR_HMR_1283')
    'ER_HMR_1284'.('GR_HMR_1284')
    'ER_HMR_1306'.('GR_HMR_1306')
    'ER_HMR_1311'.('GR_HMR_1311')
    'ER_HMR_1315'.('GR_HMR_1315')
    'ER_HMR_1316'.('GR_HMR_1316')
    'ER_HMR_1317'.('GR_HMR_1317')
    'ER_HMR_1332'.('GR_HMR_1332')
    'ER_HMR_1623'.('GR_HMR_1623')
    'ER_HMR_1701'.('GR_HMR_1701')
    'ER_HMR_1744'.('GR_HMR_1744')
    'ER_HMR_1745'.('GR_HMR_1745')
    'ER_HMR_1752'.('GR_HMR_1752')
    'ER_HMR_1753'.('GR_HMR_1753')
    'ER_HMR_1758'.('GR_HMR_1758')
    'ER_HMR_1759'.('GR_HMR_1759')
    'ER_HMR_1834'.('GR_HMR_1834')
    'ER_HMR_2087'.('GR_HMR_2087')
    'ER_HMR_2090'.('GR_HMR_2090')
    'ER_HMR_2127'.('GR_HMR_2127')
    'ER_HMR_2374'.('GR_HMR_2374')
    'ER_HMR_2376'.('GR_HMR_2376')
    'ER_HMR_2391'.('GR_HMR_2391')
    'ER_HMR_2393'.('GR_HMR_2393')
    'ER_HMR_2495'.('GR_HMR_2495')
    'ER_HMR_2569'.('GR_HMR_2569')
    'ER_HMR_2571'.('GR_HMR_2571')
    'ER_HMR_3053'.('GR_HMR_3053')
    'ER_HMR_3056'.('GR_HMR_3056')
    'ER_HMR_3106'.('GR_HMR_3106')
    'ER_HMR_3396'.('GR_HMR_3396')
    'ER_HMR_3397'.('GR_HMR_3397')
    'ER_HMR_3478'.('GR_HMR_3478')
    'ER_HMR_3520'.('GR_HMR_3520')
    'ER_HMR_3597'.('GR_HMR_3597')
    'ER_HMR_3951'.('GR_HMR_3951')
    'ER_HMR_3953'.('GR_HMR_3953')
    'ER_HMR_3996'.('GR_HMR_3996')
    'ER_HMR_4078'.('GR_HMR_4078')
    'ER_HMR_4266'.('GR_HMR_4266')
    'ER_HMR_4664'.('GR_HMR_4664')
    'ER_HMR_4672'.('GR_HMR_4672')
    'ER_HMR_4782'.('GR_HMR_4782')
    'ER_HMR_4783'.('GR_HMR_4783')
    'ER_HMR_4831'.('GR_HMR_4831')
    'ER_HMR_4957'.('GR_HMR_4957')
    'ER_HMR_5101'.('GR_HMR_5101')
    'ER_HMR_5409'.('GR_HMR_5409')
    'ER_HMR_6500'.('GR_HMR_6500')
    'ER_HMR_6611'.('GR_HMR_6611')
    'ER_HMR_6629'.('GR_HMR_6629')
    'ER_HMR_6784'.('GR_HMR_6784')
    'ER_HMR_6785'.('GR_HMR_6785')
    'ER_HMR_6786'.('GR_HMR_6786')
    'ER_HMR_7198'.('GR_HMR_7198')
    'ER_HMR_7330'.('GR_HMR_7330')
    'ER_HMR_7712'.('GR_HMR_7712')
    'ER_HMR_7715'.('GR_HMR_7715')
    'ER_HMR_7898'.('GR_HMR_7898')
    'ER_HMR_7900'.('GR_HMR_7900')
    'ER_HMR_7944'.('GR_HMR_7944')
    'ER_HMR_7977'.('GR_HMR_7977')
    'ER_HMR_8023'.('GR_HMR_8023')
    'ER_HMR_8084'.('GR_HMR_8084')
    'ER_HMR_8086'.('GR_HMR_8086')
    'ER_HMR_8090'.('GR_HMR_8090')
    'ER_HMR_8374'.('GR_HMR_8374')
    'ER_HMR_8418'.('GR_HMR_8418')
    'ER_HMR_8505'.('GR_HMR_8505')
    'ER_HMR_8562'.('GR_HMR_8562')
    'ER_HMR_8567'.('GR_HMR_8567')
    'ER_HMR_8776'.('GR_HMR_8776')
    'ER_HMR_9019'.('GR_HMR_9019')
    'ER_HMR_9174'.('GR_HMR_9174')
    'ER_HMR_9175'.('GR_HMR_9175')
    'ER_HMR_9176'.('GR_HMR_9176')
    'ER_HMR_9179'.('GR_HMR_9179')
    'ER_HMR_9180'.('GR_HMR_9180')
    'ER_HMR_9184'.('GR_HMR_9184')
    'ER_HMR_9185'.('GR_HMR_9185')
    'ER_HMR_9188'.('GR_HMR_9188')
    'ER_HMR_9189'.('GR_HMR_9189')
    'ER_HMR_9612'.('GR_HMR_9612')
    'ER_HMR_9625'.('GR_HMR_9625')
    'ER_HMR_9626'.('GR_HMR_9626')
    'ER_HMR_9627'.('GR_HMR_9627')
    'ER_HMR_9628'.('GR_HMR_9628')
    'ER_HMR_9634'.('GR_HMR_9634')
    'ER_HMR_9638'.('GR_HMR_9638')
    'ER_HMR_9639'.('GR_HMR_9639')
    'ER_HMR_9640'.('GR_HMR_9640')
    'ER_HMR_9647'.('GR_HMR_9647')
    'ER_HMR_9648'.('GR_HMR_9648')
    'ER_HMR_9652'.('GR_HMR_9652')
    'ER_HMR_9665'.('GR_HMR_9665')
    'ER_HMR_9667'.('GR_HMR_9667')
    'ER_HMR_9676'.('GR_HMR_9676')
    'ER_HMR_9678'.('GR_HMR_9678')
    'ER_HMR_9679'.('GR_HMR_9679')
    'ER_HMR_9680'.('GR_HMR_9680')
    'ER_HMR_9718'.('GR_HMR_9718')
    'ER_HMR_9720'.('GR_HMR_9720')
    'ER_HMR_9797'.('GR_HMR_9797')
    'ER_HMR_6672'.('GR_HMR_6672')
    'ER_EX_nadh[e]'.('GR_EX_nadh[e]')
    'ER_EX_glc_D[e]'.('GR_EX_glc_D[e]')
    'ER_EX_sbt_D[e]'.('GR_EX_sbt_D[e]')
    'ER_CDCA24Gtr'.('GR_CDCA24Gtr')
    'ER_CDCA3Gtr'.('GR_CDCA3Gtr')
    'ER_DM_12dhchol[c]'.('GR_DM_12dhchol[c]')
    'ER_DM_3dhcdchol[c]'.('GR_DM_3dhcdchol[c]')
    'ER_DM_3dhchol[c]'.('GR_DM_3dhchol[c]')
    'ER_DM_3dhdchol[c]'.('GR_DM_3dhdchol[c]')
    'ER_DM_3dhlchol[c]'.('GR_DM_3dhlchol[c]')
    'ER_DM_7dhcdchol[c]'.('GR_DM_7dhcdchol[c]')
    'ER_DM_7dhchol[c]'.('GR_DM_7dhchol[c]')
    'ER_DM_cdca24g[c]'.('GR_DM_cdca24g[c]')
    'ER_DM_cdca3g[c]'.('GR_DM_cdca3g[c]')
    'ER_DM_coprost[c]'.('GR_DM_coprost[c]')
    'ER_DM_hca24g[c]'.('GR_DM_hca24g[c]')
    'ER_DM_hdca24g[c]'.('GR_DM_hdca24g[c]')
    'ER_DM_hdca6g[c]'.('GR_DM_hdca6g[c]')
    'ER_DM_hyochol[c]'.('GR_DM_hyochol[c]')
    'ER_DM_icdchol[c]'.('GR_DM_icdchol[c]')
    'ER_DM_isochol[c]'.('GR_DM_isochol[c]')
    'ER_DM_lca24g[c]'.('GR_DM_lca24g[c]')
    'ER_DM_lca3g[c]'.('GR_DM_lca3g[c]')
    'ER_DM_thyochol[c]'.('GR_DM_thyochol[c]')
    'ER_DM_uchol[c]'.('GR_DM_uchol[c]')
    'ER_EX_12dhchol[e]'.('GR_EX_12dhchol[e]')
    'ER_EX_3dhcdchol[e]'.('GR_EX_3dhcdchol[e]')
    'ER_EX_3dhchol[e]'.('GR_EX_3dhchol[e]')
    'ER_EX_3dhdchol[e]'.('GR_EX_3dhdchol[e]')
    'ER_EX_3dhlchol[e]'.('GR_EX_3dhlchol[e]')
    'ER_EX_7dhcdchol[e]'.('GR_EX_7dhcdchol[e]')
    'ER_EX_7dhchol[e]'.('GR_EX_7dhchol[e]')
    'ER_EX_cdca24g[e]'.('GR_EX_cdca24g[e]')
    'ER_EX_cdca3g[e]'.('GR_EX_cdca3g[e]')
    'ER_EX_coprost[e]'.('GR_EX_coprost[e]')
    'ER_EX_hca24g[e]'.('GR_EX_hca24g[e]')
    'ER_EX_hdca24g[e]'.('GR_EX_hdca24g[e]')
    'ER_EX_hdca6g[e]'.('GR_EX_hdca6g[e]')
    'ER_EX_hyochol[e]'.('GR_EX_hyochol[e]')
    'ER_EX_icdchol[e]'.('GR_EX_icdchol[e]')
    'ER_EX_isochol[e]'.('GR_EX_isochol[e]')
    'ER_EX_lca24g[e]'.('GR_EX_lca24g[e]')
    'ER_EX_lca3g[e]'.('GR_EX_lca3g[e]')
    'ER_EX_thyochol[e]'.('GR_EX_thyochol[e]')
    'ER_EX_uchol[e]'.('GR_EX_uchol[e]')
    'ER_HCA24Gtr'.('GR_HCA24Gtr')
    'ER_HDCA6Gtr'.('GR_HDCA6Gtr')
    'ER_HYOCHOLtr'.('GR_HYOCHOLtr')
    'ER_LCA24Gtr'.('GR_LCA24Gtr')
    'ER_LCA3Gtr'.('GR_LCA3Gtr')
    'ER_M02155tr'.('GR_M02155tr')
    'ER_12HTACRtep'.('GR_12HTACRtep')
    'ER_14MDZtev'.('GR_14MDZtev')
    'ER_1HIBUPGLUC_Sthv'.('GR_1HIBUPGLUC_Sthv')
    'ER_1HIBUP_Sthv'.('GR_1HIBUP_Sthv')
    'ER_1HMDZGLUChc'.('GR_1HMDZGLUChc')
    'ER_1OHMDZtep'.('GR_1OHMDZtep')
    'ER_2HATVACIDtep'.('GR_2HATVACIDtep')
    'ER_2HATVLACtep'.('GR_2HATVLACtep')
    'ER_2HIBUPGLUC_Sthv'.('GR_2HIBUPGLUC_Sthv')
    'ER_2HIBUP_Rthv'.('GR_2HIBUP_Rthv')
    'ER_2HIBUP_Sthv'.('GR_2HIBUP_Sthv')
    'ER_35DSMVteb'.('GR_35DSMVteb')
    'ER_3HIBUPGLUC_Sthv'.('GR_3HIBUPGLUC_Sthv')
    'ER_3HIBUP_Rthv'.('GR_3HIBUP_Rthv')
    'ER_3HIBUP_Sthv'.('GR_3HIBUP_Sthv')
    'ER_3HLVSTACtbc'.('GR_3HLVSTACtbc')
    'ER_3HPVSTETtev'.('GR_3HPVSTETtev')
    'ER_3HPVStep'.('GR_3HPVStep')
    'ER_3HSMVACIDteb'.('GR_3HSMVACIDteb')
    'ER_3ISPVStep'.('GR_3ISPVStep')
    'ER_3MEACMPhc'.('GR_3MEACMPhc')
    'ER_3OHACMPtev'.('GR_3OHACMPtev')
    'ER_4HATVACIDtep'.('GR_4HATVACIDtep')
    'ER_4HATVLACtep'.('GR_4HATVLACtep')
    'ER_4HMDGLUCtev'.('GR_4HMDGLUCtev')
    'ER_4OHMDZtev'.('GR_4OHMDZtev')
    'ER_56DHPVStev'.('GR_56DHPVStev')
    'ER_56EPPVStev'.('GR_56EPPVStev')
    'ER_5OHFVSGLUhc'.('GR_5OHFVSGLUhc')
    'ER_5OHFVSGLUtev'.('GR_5OHFVSGLUtev')
    'ER_5OHFVSteb'.('GR_5OHFVSteb')
    'ER_6BHGLZtev'.('GR_6BHGLZtev')
    'ER_6CSMVACIDteb'.('GR_6CSMVACIDteb')
    'ER_6EPVStep'.('GR_6EPVStep')
    'ER_6HLVSTthep'.('GR_6HLVSTthep')
    'ER_6HMSMVACIDteb'.('GR_6HMSMVACIDteb')
    'ER_6HSMVACIDteb'.('GR_6HSMVACIDteb')
    'ER_6MELVSTthep'.('GR_6MELVSTthep')
    'ER_6OHFVSGLUhc'.('GR_6OHFVSGLUhc')
    'ER_6OHFVSGLUtev'.('GR_6OHFVSGLUtev')
    'ER_7BHGLZtev'.('GR_7BHGLZtev')
    'ER_7HPVStev'.('GR_7HPVStev')
    'ER_ACMPdt'.('GR_ACMPdt')
    'ER_AM1CSAtep'.('GR_AM1CSAtep')
    'ER_AM9CSAtep'.('GR_AM9CSAtep')
    'ER_ATVACIDhr'.('GR_ATVACIDhr')
    'ER_ATVACIDtdu'.('GR_ATVACIDtdu')
    'ER_ATVLACh2r'.('GR_ATVLACh2r')
    'ER_ATVLAChr'.('GR_ATVLAChr')
    'ER_ATVLACtdhc'.('GR_ATVLACtdhc')
    'ER_Am19CStev'.('GR_Am19CStev')
    'ER_CARBIBUP_SGLUthv'.('GR_CARBIBUP_SGLUthv')
    'ER_CARIBUP_Sthv'.('GR_CARIBUP_Sthv')
    'ER_CRVSM24tev'.('GR_CRVSM24tev')
    'ER_CRVStu'.('GR_CRVStu')
    'ER_CSAtd'.('GR_CSAtd')
    'ER_DEOXFVStev'.('GR_DEOXFVStev')
    'ER_DSPVStev'.('GR_DSPVStev')
    'ER_EPOXTAChr'.('GR_EPOXTAChr')
    'ER_EPOXTACtev'.('GR_EPOXTACtev')
    'ER_EX_12htacr[e]'.('GR_EX_12htacr[e]')
    'ER_EX_14hmdz[e]'.('GR_EX_14hmdz[e]')
    'ER_EX_1hibup_S[e]'.('GR_EX_1hibup_S[e]')
    'ER_EX_1hibupglu_S[e]'.('GR_EX_1hibupglu_S[e]')
    'ER_EX_1hmdgluc[e]'.('GR_EX_1hmdgluc[e]')
    'ER_EX_1ohmdz[e]'.('GR_EX_1ohmdz[e]')
    'ER_EX_2hatvacid[e]'.('GR_EX_2hatvacid[e]')
    'ER_EX_2hatvlac[e]'.('GR_EX_2hatvlac[e]')
    'ER_EX_2hatvlacgluc[e]'.('GR_EX_2hatvlacgluc[e]')
    'ER_EX_2hibup_R[e]'.('GR_EX_2hibup_R[e]')
    'ER_EX_2hibup_S[e]'.('GR_EX_2hibup_S[e]')
    'ER_EX_2hibupglu_S[e]'.('GR_EX_2hibupglu_S[e]')
    'ER_EX_35dsmv[e]'.('GR_EX_35dsmv[e]')
    'ER_EX_3hibup_R[e]'.('GR_EX_3hibup_R[e]')
    'ER_EX_3hibup_S[e]'.('GR_EX_3hibup_S[e]')
    'ER_EX_3hibupglu_S[e]'.('GR_EX_3hibupglu_S[e]')
    'ER_EX_3hlvstacid[e]'.('GR_EX_3hlvstacid[e]')
    'ER_EX_3hpvs[e]'.('GR_EX_3hpvs[e]')
    'ER_EX_3hpvstet[e]'.('GR_EX_3hpvstet[e]')
    'ER_EX_3hsmvacid[e]'.('GR_EX_3hsmvacid[e]')
    'ER_EX_3ohacmp[e]'.('GR_EX_3ohacmp[e]')
    'ER_EX_4hatvacid[e]'.('GR_EX_4hatvacid[e]')
    'ER_EX_4hatvlac[e]'.('GR_EX_4hatvlac[e]')
    'ER_EX_4hmdgluc[e]'.('GR_EX_4hmdgluc[e]')
    'ER_EX_4ohmdz[e]'.('GR_EX_4ohmdz[e]')
    'ER_EX_5ohfvs[e]'.('GR_EX_5ohfvs[e]')
    'ER_EX_5ohfvsglu[e]'.('GR_EX_5ohfvsglu[e]')
    'ER_EX_6bhglz[e]'.('GR_EX_6bhglz[e]')
    'ER_EX_6csmvacid[e]'.('GR_EX_6csmvacid[e]')
    'ER_EX_6hlvst[e]'.('GR_EX_6hlvst[e]')
    'ER_EX_6hmsmvacid[e]'.('GR_EX_6hmsmvacid[e]')
    'ER_EX_6hsmvacid[e]'.('GR_EX_6hsmvacid[e]')
    'ER_EX_6melvacid[e]'.('GR_EX_6melvacid[e]')
    'ER_EX_6melvst[e]'.('GR_EX_6melvst[e]')
    'ER_EX_6ohfvsglu[e]'.('GR_EX_6ohfvsglu[e]')
    'ER_EX_7bhglz[e]'.('GR_EX_7bhglz[e]')
    'ER_EX_acmp[e]'.('GR_EX_acmp[e]')
    'ER_EX_am19cs[e]'.('GR_EX_am19cs[e]')
    'ER_EX_am1csa[e]'.('GR_EX_am1csa[e]')
    'ER_EX_am9csa[e]'.('GR_EX_am9csa[e]')
    'ER_EX_atvacid[e]'.('GR_EX_atvacid[e]')
    'ER_EX_atvlac[e]'.('GR_EX_atvlac[e]')
    'ER_EX_caribup_s[e]'.('GR_EX_caribup_s[e]')
    'ER_EX_caribupglu_S[e]'.('GR_EX_caribupglu_S[e]')
    'ER_EX_crvs[e]'.('GR_EX_crvs[e]')
    'ER_EX_crvsm24[e]'.('GR_EX_crvsm24[e]')
    'ER_EX_csa[e]'.('GR_EX_csa[e]')
    'ER_EX_deoxfvs[e]'.('GR_EX_deoxfvs[e]')
    'ER_EX_epoxtac[e]'.('GR_EX_epoxtac[e]')
    'ER_EX_fvs[e]'.('GR_EX_fvs[e]')
    'ER_EX_glc3meacp[e]'.('GR_EX_glc3meacp[e]')
    'ER_EX_glz[e]'.('GR_EX_glz[e]')
    'ER_EX_ibup_R[e]'.('GR_EX_ibup_R[e]')
    'ER_EX_ibup_S[e]'.('GR_EX_ibup_S[e]')
    'ER_EX_ibupgluc[e]'.('GR_EX_ibupgluc[e]')
    'ER_EX_isolvstacid[e]'.('GR_EX_isolvstacid[e]')
    'ER_EX_lstn[e]'.('GR_EX_lstn[e]')
    'ER_EX_lstnm7[e]'.('GR_EX_lstnm7[e]')
    'ER_EX_lvst[e]'.('GR_EX_lvst[e]')
    'ER_EX_mdz[e]'.('GR_EX_mdz[e]')
    'ER_EX_nfdac[e]'.('GR_EX_nfdac[e]')
    'ER_EX_nfdoh[e]'.('GR_EX_nfdoh[e]')
    'ER_EX_profvs[e]'.('GR_EX_profvs[e]')
    'ER_EX_ptvst[e]'.('GR_EX_ptvst[e]')
    'ER_EX_ptvstlac[e]'.('GR_EX_ptvstlac[e]')
    'ER_EX_pvs[e]'.('GR_EX_pvs[e]')
    'ER_EX_smv[e]'.('GR_EX_smv[e]')
    'ER_EX_smvacid[e]'.('GR_EX_smvacid[e]')
    'ER_EX_tacr[e]'.('GR_EX_tacr[e]')
    'ER_EX_tlacfvs[e]'.('GR_EX_tlacfvs[e]')
    'ER_FVShc'.('GR_FVShc')
    'ER_FVStep'.('GR_FVStep')
    'ER_GLC3MEACPtev'.('GR_GLC3MEACPtev')
    'ER_GLZtd'.('GR_GLZtd')
    'ER_IBUPGLUCtchep'.('GR_IBUPGLUCtchep')
    'ER_IBUPGLUCtpvb'.('GR_IBUPGLUCtpvb')
    'ER_IBUP_Rtdhep'.('GR_IBUP_Rtdhep')
    'ER_IBUP_Rtdu'.('GR_IBUP_Rtdu')
    'ER_IBUP_Stdhep'.('GR_IBUP_Stdhep')
    'ER_IBUP_Stdu'.('GR_IBUP_Stdu')
    'ER_ISOLVSTAChep'.('GR_ISOLVSTAChep')
    'ER_LSTNM7TDhc'.('GR_LSTNM7TDhc')
    'ER_LSTNM7thc'.('GR_LSTNM7thc')
    'ER_LSTNRATt'.('GR_LSTNRATt')
    'ER_LSTNtd'.('GR_LSTNtd')
    'ER_LVACLAChep'.('GR_LVACLAChep')
    'ER_LVSTtu'.('GR_LVSTtu')
    'ER_MDZtd'.('GR_MDZtd')
    'ER_NFDACtep'.('GR_NFDACtep')
    'ER_NFDOHtep'.('GR_NFDOHtep')
    'ER_OXYPtepv'.('GR_OXYPtepv')
    'ER_PROFVShc'.('GR_PROFVShc')
    'ER_PROFVStev'.('GR_PROFVStev')
    'ER_PTVSTLAChc'.('GR_PTVSTLAChc')
    'ER_PTVSTLACtev'.('GR_PTVSTLACtev')
    'ER_PTVSTtep'.('GR_PTVSTtep')
    'ER_PVSGLUCtev'.('GR_PVSGLUCtev')
    'ER_PVSHtu'.('GR_PVSHtu')
    'ER_PVStep'.('GR_PVStep')
    'ER_RSVGLUChc'.('GR_RSVGLUChc')
    'ER_RSVLAChv'.('GR_RSVLAChv')
    'ER_SMVACIDtev'.('GR_SMVACIDtev')
    'ER_SMVtv'.('GR_SMVtv')
    'ER_TACRDtsc'.('GR_TACRDtsc')
    'ER_TLACFVStev'.('GR_TLACFVStev')
    'ER_TRIPVStev'.('GR_TRIPVStev')
    'ER_12HTACRitr'.('GR_12HTACRitr')
    'ER_14HMDZitr'.('GR_14HMDZitr')
    'ER_1HIBUP_Sitr'.('GR_1HIBUP_Sitr')
    'ER_1HIBUPGLUitr'.('GR_1HIBUPGLUitr')
    'ER_1HMDGLUCitr'.('GR_1HMDGLUCitr')
    'ER_2HATVLACGLUCitr'.('GR_2HATVLACGLUCitr')
    'ER_2HIBUP_Ritr'.('GR_2HIBUP_Ritr')
    'ER_2HIBUP_Sitr'.('GR_2HIBUP_Sitr')
    'ER_2HIBUPGLUC_Sitr'.('GR_2HIBUPGLUC_Sitr')
    'ER_35DSMVitr'.('GR_35DSMVitr')
    'ER_3HIBUP_Ritr'.('GR_3HIBUP_Ritr')
    'ER_3HIBUPGLUC_Sitr'.('GR_3HIBUPGLUC_Sitr')
    'ER_3HLVSTitr'.('GR_3HLVSTitr')
    'ER_3HPVSitr'.('GR_3HPVSitr')
    'ER_3HPVSCOAitm'.('GR_3HPVSCOAitm')
    'ER_3HPVSCOAitx'.('GR_3HPVSCOAitx')
    'ER_3HPVSTETCOAitm'.('GR_3HPVSTETCOAitm')
    'ER_3HPVSTETCOAitx'.('GR_3HPVSTETCOAitx')
    'ER_3HSMVitr'.('GR_3HSMVitr')
    'ER_3MEACMPitr'.('GR_3MEACMPitr')
    'ER_3OHACMPitr'.('GR_3OHACMPitr')
    'ER_4HATVACIDitr'.('GR_4HATVACIDitr')
    'ER_4HATVLACitr'.('GR_4HATVLACitr')
    'ER_4HMDGLUCitr'.('GR_4HMDGLUCitr')
    'ER_4OHMDZitr'.('GR_4OHMDZitr')
    'ER_5OHFVSitr'.('GR_5OHFVSitr')
    'ER_5OHFVSGLUitr'.('GR_5OHFVSGLUitr')
    'ER_6CSMVitr'.('GR_6CSMVitr')
    'ER_6HLVSTitr'.('GR_6HLVSTitr')
    'ER_6HLVSTACIDitr'.('GR_6HLVSTACIDitr')
    'ER_6HMSMVitr'.('GR_6HMSMVitr')
    'ER_6HSMVitr'.('GR_6HSMVitr')
    'ER_6MELVACIDitr'.('GR_6MELVACIDitr')
    'ER_6MELVSTitr'.('GR_6MELVSTitr')
    'ER_6OHFVSGLUitr'.('GR_6OHFVSGLUitr')
    'ER_ACMPitr'.('GR_ACMPitr')
    'ER_AM19CSitr'.('GR_AM19CSitr')
    'ER_CARIBUP_Sitr'.('GR_CARIBUP_Sitr')
    'ER_CARIBUPGLU_Sitr'.('GR_CARIBUPGLU_Sitr')
    'ER_CRVSitr'.('GR_CRVSitr')
    'ER_CRVSM24itr'.('GR_CRVSM24itr')
    'ER_CSAitr'.('GR_CSAitr')
    'ER_DEOXFVSitx'.('GR_DEOXFVSitx')
    'ER_EPOXTACitr'.('GR_EPOXTACitr')
    'ER_FVSitx'.('GR_FVSitx')
    'ER_FVSCOAitx'.('GR_FVSCOAitx')
    'ER_GLC3MEACPitr'.('GR_GLC3MEACPitr')
    'ER_GLZitr'.('GR_GLZitr')
    'ER_IBUP_Ritr'.('GR_IBUP_Ritr')
    'ER_IBUP_Sitr'.('GR_IBUP_Sitr')
    'ER_IBUPGLUCitr'.('GR_IBUPGLUCitr')
    'ER_LSTNitr'.('GR_LSTNitr')
    'ER_LSTNM7itr'.('GR_LSTNM7itr')
    'ER_LVSTitr'.('GR_LVSTitr')
    'ER_LVSTACIDitr'.('GR_LVSTACIDitr')
    'ER_MDZitr'.('GR_MDZitr')
    'ER_NFDOHitr'.('GR_NFDOHitr')
    'ER_PROFVSCOAitx'.('GR_PROFVSCOAitx')
    'ER_PTVSTLACitr'.('GR_PTVSTLACitr')
    'ER_PTVSTM13itr'.('GR_PTVSTM13itr')
    'ER_PTVSTM13te'.('GR_PTVSTM13te')
    'ER_EX_ptvstm13[e]'.('GR_EX_ptvstm13[e]')
    'ER_PVSitr'.('GR_PVSitr')
    'ER_RSVLACitr'.('GR_RSVLACitr')
    'ER_TACRitr'.('GR_TACRitr')
    'ER_TLACFVSitr'.('GR_TLACFVSitr')
    'ER_3HPVSCOAhc'.('GR_3HPVSCOAhc')
    'ER_3HPVSTEThc'.('GR_3HPVSTEThc')
    'ER_FVSCOAhc'.('GR_FVSCOAhc')
    'ER_1OHMDZitr'.('GR_1OHMDZitr')
    'ER_NFDACitr'.('GR_NFDACitr')
    'ER_H2O2itr'.('GR_H2O2itr')
    'ER_ATVACIDitr'.('GR_ATVACIDitr')
    'ER_ATVLACitr'.('GR_ATVLACitr')
    'ER_SMVitr'.('GR_SMVitr')
    'ER_6BHGLZitr'.('GR_6BHGLZitr')
    'ER_7BHGLZitr'.('GR_7BHGLZitr')
    'ER_RSVitr'.('GR_RSVitr')
    'ER_PTVSTitr'.('GR_PTVSTitr')
    'ER_3HIBUP_Sitr'.('GR_3HIBUP_Sitr')
    'ER_FVSitr'.('GR_FVSitr')
    'ER_AM1CSAitr'.('GR_AM1CSAitr')
    'ER_AM9CSAitr'.('GR_AM9CSAitr')
    'ER_2HATVACIDitr'.('GR_2HATVACIDitr')
    'ER_EX_caproic[e]'.('GR_EX_caproic[e]')
    'ER_1A25HVITD2t'.('GR_1A25HVITD2t')
    'ER_1A25HVITD2tm'.('GR_1A25HVITD2tm')
    'ER_EX_1a25dhvitd2[e]'.('GR_EX_1a25dhvitd2[e]')
    'ER_EX_C13856[e]'.('GR_EX_C13856[e]')
    'ER_EX_M00234[e]'.('GR_EX_M00234[e]')
    'ER_EX_M01807[e]'.('GR_EX_M01807[e]')
    'ER_EX_M00503[e]'.('GR_EX_M00503[e]')
    'ER_EX_M00003[e]'.('GR_EX_M00003[e]')
    'ER_EX_M00008[e]'.('GR_EX_M00008[e]')
    'ER_EX_M00010[e]'.('GR_EX_M00010[e]')
    'ER_EX_M00017[e]'.('GR_EX_M00017[e]')
    'ER_EX_M00019[e]'.('GR_EX_M00019[e]')
    'ER_EX_M00021[e]'.('GR_EX_M00021[e]')
    'ER_EX_M00115[e]'.('GR_EX_M00115[e]')
    'ER_EX_M00117[e]'.('GR_EX_M00117[e]')
    'ER_EX_M00260[e]'.('GR_EX_M00260[e]')
    'ER_EX_M00265[e]'.('GR_EX_M00265[e]')
    'ER_EX_M00315[e]'.('GR_EX_M00315[e]')
    'ER_EX_M00341[e]'.('GR_EX_M00341[e]')
    'ER_EX_M01197[e]'.('GR_EX_M01197[e]')
    'ER_EX_M01207[e]'.('GR_EX_M01207[e]')
    'ER_EX_M01235[e]'.('GR_EX_M01235[e]')
    'ER_EX_M01238[e]'.('GR_EX_M01238[e]')
    'ER_EX_M01582[e]'.('GR_EX_M01582[e]')
    'ER_EX_M02053[e]'.('GR_EX_M02053[e]')
    'ER_EX_M02457[e]'.('GR_EX_M02457[e]')
    'ER_EX_M02613[e]'.('GR_EX_M02613[e]')
    'ER_EX_M02745[e]'.('GR_EX_M02745[e]')
    'ER_EX_M03045[e]'.('GR_EX_M03045[e]')
    'ER_EX_M03051[e]'.('GR_EX_M03051[e]')
    'ER_EX_M03153[e]'.('GR_EX_M03153[e]')
    'ER_EX_M02560[e]'.('GR_EX_M02560[e]')
    'ER_EX_C01601[e]'.('GR_EX_C01601[e]')
    'ER_EX_M02108[e]'.('GR_EX_M02108[e]')
    'ER_EX_M03117[e]'.('GR_EX_M03117[e]')
    'ER_EX_M03134[e]'.('GR_EX_M03134[e]')
    'ER_EX_M01111[e]'.('GR_EX_M01111[e]')
    'ER_EX_h2co3[e]'.('GR_EX_h2co3[e]')
    'ER_EX_M01870[e]'.('GR_EX_M01870[e]')
    'ER_EX_ditp[e]'.('GR_EX_ditp[e]')
    'ER_EX_M02446[e]'.('GR_EX_M02446[e]')
    'ER_EX_M02447[e]'.('GR_EX_M02447[e]')
    'ER_EX_M02449[e]'.('GR_EX_M02449[e]')
    'ER_EX_M02451[e]'.('GR_EX_M02451[e]')
    'ER_EX_itacon[e]'.('GR_EX_itacon[e]')
    'ER_EX_adpman[e]'.('GR_EX_adpman[e]')
    'ER_EX_rbl_D[e]'.('GR_EX_rbl_D[e]')
    'ER_EX_M02155[e]'.('GR_EX_M02155[e]')
    'ER_EX_M01989[e]'.('GR_EX_M01989[e]')
    'ER_EX_M03131[e]'.('GR_EX_M03131[e]')
    'ER_EX_n5m2masn[e]'.('GR_EX_n5m2masn[e]')
    'ER_EX_dolichol_L[e]'.('GR_EX_dolichol_L[e]')
    'ER_sink_his_L[c]'.('GR_sink_his_L[c]')
    'ER_sink_ile_L[c]'.('GR_sink_ile_L[c]')
    'ER_sink_leu_L[c]'.('GR_sink_leu_L[c]')
    'ER_sink_lys_L[c]'.('GR_sink_lys_L[c]')
    'ER_sink_met_L[c]'.('GR_sink_met_L[c]')
    'ER_sink_phe_L[c]'.('GR_sink_phe_L[c]')
    'ER_sink_thr_L[c]'.('GR_sink_thr_L[c]')
    'ER_sink_trp_L[c]'.('GR_sink_trp_L[c]')
    'ER_sink_val_L[c]'.('GR_sink_val_L[c]')
    'ER_sink_ala_L[c]'.('GR_sink_ala_L[c]')
    'ER_sink_arg_L[c]'.('GR_sink_arg_L[c]')
    'ER_sink_asn_L[c]'.('GR_sink_asn_L[c]')
    'ER_sink_asp_L[c]'.('GR_sink_asp_L[c]')
    'ER_sink_cys_L[c]'.('GR_sink_cys_L[c]')
    'ER_sink_gln_L[c]'.('GR_sink_gln_L[c]')
    'ER_sink_glu_L[c]'.('GR_sink_glu_L[c]')
    'ER_sink_pro_L[c]'.('GR_sink_pro_L[c]')
    'ER_sink_ser_L[c]'.('GR_sink_ser_L[c]')
    'ER_sink_tyr_L[c]'.('GR_sink_tyr_L[c]')
    'ER_sink_gly[c]'.('GR_sink_gly[c]')
    'ER_sink_4abut[l]'.('GR_sink_4abut[l]')
    'ER_DM_5cysdopa[c]'.('GR_DM_5cysdopa[c]')
    'ER_DM_4abut[c]'.('GR_DM_4abut[c]')
    'ER_DM_srtn[c]'.('GR_DM_srtn[c]')
    'ER_DM_ach[c]'.('GR_DM_ach[c]')
    'ER_DM_hista[c]'.('GR_DM_hista[c]')
    'ER_DM_kynate[c]'.('GR_DM_kynate[c]')
    'ER_DM_tym[c]'.('GR_DM_tym[c]')
    'ER_DM_Lkynr[c]'.('GR_DM_Lkynr[c]')
    'ER_DM_cbl2[m]'.('GR_DM_cbl2[m]')
    'ER_DCMPtm'.('GR_DCMPtm')
    'ER_ATPS4mi'.('GR_ATPS4mi')
    'ER_KER_02243'.('GR_KER_02243')
    'ER_KER_02407'.('GR_KER_02407')
    'ER_KER_10600'.('GR_KER_10600')
    'ER_ITPtm'.('GR_ITPtm')
    'ER_IDPtm'.('GR_IDPtm')
    'ER_CE_Peptide'.('GR_CE_Peptide')
    'ER_EX_Peptide'.('GR_EX_Peptide')
    'ER_Ubiquitin_syn'.('GR_Ubiquitin_syn')
    'ER_DM_Ubiquitin'.('GR_DM_Ubiquitin')
    'ER_Abeta_syn'.('GR_Abeta_syn')
    'ER_DM_Abeta'.('GR_DM_Abeta')
    'ER_Abeta_L_lysine'.('GR_Abeta_L_lysine')
    'ER_CE_Abeta_L_lysine'.('GR_CE_Abeta_L_lysine')
    'ER_CN_Abeta_L_lysine'.('GR_CN_Abeta_L_lysine')
    'ER_EX_Abeta_L_lysine'.('GR_EX_Abeta_L_lysine')
    'ER_EN_Abeta_L_lysine'.('GR_EN_Abeta_L_lysine')
    'ER_Abeta_Deg'.('GR_Abeta_Deg')
    'ER_Tau_syn'.('GR_Tau_syn')
    'ER_DM_Tau'.('GR_DM_Tau')
    'ER_Tau_L_lysine'.('GR_Tau_L_lysine')
    'ER_CE_Tau_L_lysine'.('GR_CE_Tau_L_lysine')
    'ER_CN_Tau_L_lysine'.('GR_CN_Tau_L_lysine')
    'ER_EX_Tau_L_lysine'.('GR_EX_Tau_L_lysine')
    'ER_EN_Tau_L_lysine'.('GR_EN_Tau_L_lysine')
    'ER_Tau_Deg'.('GR_Tau_Deg')
    'ER_TNFA_syn'.('GR_TNFA_syn')
    'ER_DM_TNFA'.('GR_DM_TNFA')
    'ER_TNFA_L_lysine'.('GR_TNFA_L_lysine')
    'ER_CE_TNFA_L_lysine'.('GR_CE_TNFA_L_lysine')
    'ER_CN_TNFA_L_lysine'.('GR_CN_TNFA_L_lysine')
    'ER_EX_TNFA_L_lysine'.('GR_EX_TNFA_L_lysine')
    'ER_EN_TNFA_L_lysine'.('GR_EN_TNFA_L_lysine')
    'ER_TNFA_Deg'.('GR_TNFA_Deg')
    'ER_IL6_syn'.('GR_IL6_syn')
    'ER_DM_IL6'.('GR_DM_IL6')
    'ER_IL6_L_lysine'.('GR_IL6_L_lysine')
    'ER_CE_IL6_L_lysine'.('GR_CE_IL6_L_lysine')
    'ER_CN_IL6_L_lysine'.('GR_CN_IL6_L_lysine')
    'ER_EX_IL6_L_lysine'.('GR_EX_IL6_L_lysine')
    'ER_EN_IL6_L_lysine'.('GR_EN_IL6_L_lysine')
    'ER_IL6_Deg'.('GR_IL6_Deg')
   /;
$offempty
