$onempty
sets
    uptake_rxn_DMEM(reactions) "uptake reactions for DMEM"
/

**** DMEM-from www.thermofisher.com/tw/zt/home/technical-resources/media-formulation.8.html
**** Tobias Ackermann and Saverio Tardito,  Cell culture medium formulation and its implications in cancer metabolism,
**** Trends Cancer. 2019 June 4; 5(6): 329–332. doi:10.1016/j.trecan.2019.05.004

"R_EX_gly[e]"
"R_EX_arg_L[e]"
"R_EX_Lcystin[e]"
"R_EX_gln_L[e]"
"R_EX_his_L[e]"
"R_EX_ile_L[e]"
"R_EX_leu_L[e]"
"R_EX_lys_L[e]"
"R_EX_met_L[e]"
"R_EX_phe_L[e]"
"R_EX_ser_L[e]"
"R_EX_thr_L[e]"
"R_EX_trp_L[e]"
"R_EX_tyr_L[e]"
"R_EX_val_L[e]"
"R_EX_chol[e]"
"R_EX_fol[e]"
"R_EX_ncam[e]"
"R_EX_pydxn[e]"
"R_EX_ribflv[e]"
"R_EX_thm[e]"
*"R_EX_inost[e]"
"R_EX_k[e]"
"R_EX_hco3[e]"
"R_EX_glc_D[e]"
"R_EX_na1[e]"
"R_EX_pnto_R[e]"
"R_EX_fe3[e]"
"R_EX_so4[e]"
"R_EX_pi[e]"


*** 張皓翔 medium 增加成分
*** essential nutrients
"R_EX_asn_L[e]"
"R_EX_thymd[e]"

*** nonessential
"R_EX_4hpro[e]"
"R_EX_ala_L[e]"
"R_EX_asp_L[e]"
"R_EX_btn[e]"
"R_EX_glu_L[e]"
"R_EX_gthrd[e]"
"R_EX_hxan[e]"
"R_EX_lnlc[e]"
"R_EX_nh4[e]"
"R_EX_pro_L[e]"
"R_EX_ptrc[e]"
"R_EX_pydx[e]"
"R_EX_pyr[e]"
"R_EX_succ[e]"

/

    uptake_rxn_HAM(reactions) "uptake reactions for HAM"
/
*** 張皓翔 medium
*** ref.: F. Gatto, H. Miess, A. Schulza and J. Nielsen, Flux balance analysis predicts essential genes in clear cell renal cell carcinoma metabolism,
***       https://doi.org/10.1038/srep10738 

*'R_EX_3ivcrn[e]'
'R_EX_ala_L[e]'
'R_EX_aqcobal[e]'
'R_EX_arg_L[e]'
'R_EX_asn_L[e]'
'R_EX_asp_L[e]'
'R_EX_btn[e]'
'R_EX_c4crn[e]'
'R_EX_c4dc[e]'
'R_EX_c6crn[e]'
'R_EX_chol[e]'
'R_EX_citr_L[e]'
'R_EX_crn[e]'
'R_EX_cys_L[e]'
'R_EX_fe2[e]'
'R_EX_fol[e]'
'R_EX_gln_L[e]'
'R_EX_glu_L[e]'
'R_EX_gly[e]'
'R_EX_hco3[e]'
'R_EX_his_L[e]'
'R_EX_hxan[e]'
'R_EX_ile_L[e]'
*'R_EX_inost[e]'
*'R_EX_ivcrn[e]'
'R_EX_k[e]'
'R_EX_leu_L[e]'
'R_EX_lys_L[e]'
'R_EX_met_L[e]'
'R_EX_na1[e]'
'R_EX_ncam[e]'
'R_EX_octa[e]'
'R_EX_phe_L[e]'
'R_EX_phyt[e]'
'R_EX_pmtcrn[e]'
'R_EX_pnto_R[e]'
'R_EX_pro_L[e]'
'R_EX_pydxn[e]'
'R_EX_pyr[e]'
'R_EX_ribflv[e]'
*'R_EX_sarcs[e]'
'R_EX_ser_L[e]'
'R_EX_so4[e]'
*'R_EX_taur[e]'
'R_EX_thmtp[e]'
'R_EX_thr_L[e]'
'R_EX_thymd[e]'
'R_EX_trp_L[e]'
'R_EX_tyr_L[e]'
'R_EX_val_L[e]'
'R_EX_chsterol[e]'
'R_EX_but[e]'
'R_EX_dca[e]'
'R_EX_etha[e]'
'R_EX_gthrd[e]'
'R_EX_lnlc[e]'
*'R_EX_lipoate[e]'
'R_EX_ptrc[e]'
'R_EX_fe3[e]'
'R_EX_thm[e]'

/

    uptake_rxn_HPLM(reactions) "uptake reactions for HPLM"
/
***HPLM-Medium(62)
'R_EX_his_L[e]'
'R_EX_ile_L[e]'
'R_EX_leu_L[e]'
'R_EX_lys_L[e]'
'R_EX_met_L[e]'
'R_EX_phe_L[e]'
'R_EX_thr_L[e]'
'R_EX_trp_L[e]'
'R_EX_val_L[e]'
'R_EX_ala_L[e]'
'R_EX_arg_L[e]'
'R_EX_asp_L[e]'
'R_EX_glu_L[e]'
'R_EX_gly[e]'
'R_EX_ser_L[e]'
'R_EX_tyr_L[e]'
'R_EX_asn_L[e]'
'R_EX_cys_L[e]'
'R_EX_gln_L[e]'
'R_EX_pro_L[e]'
'R_EX_btn[e]'
'R_EX_fol[e]'
'R_EX_k[e]'
'R_EX_na1[e]'
'R_EX_ncam[e]'
'R_EX_pnto_R[e]'
'R_EX_ribflv[e]'
'R_EX_2hb[e]'
'R_EX_4hpro[e]'
'R_EX_ac[e]'
'R_EX_acetone[e]'
'R_EX_bhb[e]'
'R_EX_chol[e]'
'R_EX_cit[e]'
'R_EX_citr_L[e]'
'R_EX_creat[e]'
'R_EX_crn[e]'
'R_EX_for[e]'
'R_EX_fru[e]'
'R_EX_gal[e]'
'R_EX_glc_D[e]'
*'R_EX_glyb[e]'
'R_EX_glyc[e]'
'R_EX_gthrd[e]'
'R_EX_hco3[e]'
'R_EX_hxan[e]'
*'R_EX_inost[e]'
'R_EX_lac_L[e]'
'R_EX_Lcystin[e]'
'R_EX_nh4[e]'
'R_EX_pydxn[e]'
'R_EX_pyr[e]'
'R_EX_so4[e]'
'R_EX_succ[e]'
*'R_EX_taur[e]'
'R_EX_thm[e]'
'R_EX_urate[e]'
'R_EX_urea[e]'

/

    uptake_rxn_RPMI(reactions) "uptake reactions for RPMI"
/
'R_EX_his_L[e]'
'R_EX_ile_L[e]'
'R_EX_leu_L[e]'
'R_EX_lys_L[e]'
'R_EX_met_L[e]'
'R_EX_phe_L[e]'
'R_EX_thr_L[e]'
'R_EX_trp_L[e]'
'R_EX_val_L[e]'
'R_EX_ala_L[e]'
'R_EX_arg_L[e]'
'R_EX_asp_L[e]'
'R_EX_glu_L[e]'
'R_EX_gly[e]'
'R_EX_ser_L[e]'
'R_EX_tyr_L[e]'
'R_EX_asn_L[e]'
'R_EX_cys_L[e]'
'R_EX_gln_L[e]'
'R_EX_pro_L[e]'
'R_EX_btn[e]'
'R_EX_fol[e]'
'R_EX_k[e]'
'R_EX_na1[e]'
'R_EX_ncam[e]'
'R_EX_pnto_R[e]'
'R_EX_ribflv[e]'
'R_EX_chol[e]'
'R_EX_fe2[e]'
'R_EX_glc_D[e]'
'R_EX_gthrd[e]'
*'R_EX_inost[e]'
'R_EX_Lcystin[e]'
'R_EX_o2[e]'
'R_EX_pydx[e]'

/

    uptake_rxn_VMH(reactions) "uptake reactions for VMH from VMH database and Comp-Stru-Biotech2022"
/
*********VMH-Medium
"R_EX_10fthf[e]"
"R_EX_12dgr120[e]"
"R_EX_2obut[e]"
"R_EX_3mop[e]"
"R_EX_4hbz[e]"
"R_EX_5mthf[e]"
"R_EX_7thf[e]"
"R_EX_ac[e]"
"R_EX_acgam[e]"
"R_EX_acmana[e]"
"R_EX_ade[e]"
"R_EX_adn[e]"
"R_EX_adrn[e]"
"R_EX_ala_D[e]"
"R_EX_ala_L[e]"
"R_EX_amet[e]"
"R_EX_amp[e]"
"R_EX_arab_L[e]"
"R_EX_arach[e]"
"R_EX_arachd[e]"
"R_EX_arg_L[e]"
"R_EX_ascb_L[e]"
"R_EX_asn_L[e]"
"R_EX_asp_L[e]"
"R_EX_avite1[e]"
"R_EX_btn[e]"
"R_EX_but[e]"
"R_EX_carn[e]"
"R_EX_caro[e]"
"R_EX_CE2510[e]"
"R_EX_CE4843[e]"
"R_EX_cgly[e]"
"R_EX_chol[e]"
"R_EX_chsterol[e]"
"R_EX_cit[e]"
"R_EX_clpnd[e]"
"R_EX_creat[e]"
"R_EX_crn[e]"
"R_EX_crvnc[e]"
"R_EX_csn[e]"
"R_EX_cys_L[e]"
"R_EX_cytd[e]"
"R_EX_dad_2[e]"
"R_EX_dca[e]"
"R_EX_dcyt[e]"
"R_EX_ddca[e]"
"R_EX_dgchol[e]"
"R_EX_dgsn[e]"
"R_EX_dlnlcg[e]"
"R_EX_doco13ac[e]"
"R_EX_docosac[e]"
"R_EX_elaid[e]"
"R_EX_etoh[e]"
"R_EX_fald[e]"
"R_EX_fe2[e]"
"R_EX_fe3[e]"
"R_EX_fol[e]"
"R_EX_for[e]"
"R_EX_fru[e]"
"R_EX_gal[e]"
"R_EX_gam[e]"
"R_EX_gchola[e]"
"R_EX_glc_D[e]"
"R_EX_gln_L[e]"
"R_EX_glu_L[e]"
"R_EX_gly[e]"
"R_EX_glyc[e]"
"R_EX_glyc3p[e]"
"R_EX_gsn[e]"
"R_EX_gthox[e]"
"R_EX_gthrd[e]"
"R_EX_gua[e]"
"R_EX_h[e]"
"R_EX_h2o[e]"
"R_EX_hco3[e]"
"R_EX_hdca[e]"
"R_EX_hdcea[e]"
"R_EX_his_L[e]"
"R_EX_hista[e]"
"R_EX_hpdca[e]"
"R_EX_hxan[e]"
"R_EX_i[e]"
"R_EX_ile_L[e]"
"R_EX_k[e]"
"R_EX_lanost[e]"
"R_EX_lcts[e]"
"R_EX_Lcystin[e]"
"R_EX_leu_L[e]"
"R_EX_lgnc[e]"
"R_EX_lnlc[e]"
"R_EX_lnlnca[e]"
"R_EX_lys_L[e]"
"R_EX_M01989[e]"
"R_EX_malt[e]"
"R_EX_man[e]"
"R_EX_met_L[e]"
"R_EX_na1[e]"
"R_EX_nac[e]"
"R_EX_ncam[e]"
"R_EX_no2[e]"
"R_EX_ocdca[e]"
"R_EX_ocdcea[e]"
"R_EX_octa[e]"
"R_EX_orn[e]"
"R_EX_phe_L[e]"
"R_EX_pheme[e]"
*"R_EX_phyQ[e]"
"R_EX_pi[e]"
"R_EX_pnto_R[e]"
"R_EX_pro_L[e]"
"R_EX_ptdca[e]"
"R_EX_ptrc[e]"
"R_EX_pydam[e]"
"R_EX_pydx[e]"
"R_EX_pydxn[e]"
"R_EX_q10[e]"
"R_EX_retinol[e]"
"R_EX_rib_D[e]"
"R_EX_ribflv[e]"
"R_EX_sbt_D[e]"
"R_EX_ser_L[e]"
"R_EX_so4[e]"
"R_EX_spmd[e]"
"R_EX_sprm[e]"
"R_EX_strch1[e]"
"R_EX_strdnc[e]"
"R_EX_sucr[e]"
"R_EX_tchola[e]"
"R_EX_tdchola[e]"
"R_EX_thf[e]"
"R_EX_thm[e]"
"R_EX_thr_L[e]"
"R_EX_thymd[e]"
"R_EX_trp_L[e]"
"R_EX_ttdca[e]"
"R_EX_ttdcea[e]"
"R_EX_tyr_L[e]"
"R_EX_ura[e]"
"R_EX_urate[e]"
"R_EX_val_L[e]"
"R_EX_vitd3[e]"
"R_EX_xan[e]"
"R_EX_xyl_D[e]"
"R_EX_xylt[e]"

/

    uptake_rxn_ALLEx(reactions) "uptake reactions for overall exchange reactions in GSMM"
    
    uptake_rxn_DMEM_chsterol(reactions) "uptake reactions for DMEM"
    /"R_EX_chsterol[e]"/
    
    uptake_rxn_HAM_chsterol(reactions) "uptake reactions for HAM"
    /"R_EX_chsterol[e]"/    

    uptake_rxn_HPLM_chsterol(reactions) "uptake reactions for HPLM"
    /"R_EX_chsterol[e]"/    

    uptake_rxn_RPMI_chsterol(reactions) "uptake reactions for RPMI"
    /"R_EX_chsterol[e]"/    

    uptake_rxn_VMH_chsterol(reactions) "uptake reactions for VMH"
    /"R_EX_chsterol[e]"/
    
   uptake_rxn_ALLEx_chsterol(reactions) "uptake reactions for overall exchange reactions in GSMM"
       /"R_EX_chsterol[e]"/

    uptake_demand(reactions) "demanded uptake reactions, vf = 0"
        /'R_EX_glc_D[e]'
         'R_EX_o2[e]'
        /

    uptake_fixed(reactions) "fixed demand uptake reactions, vb.fx = v_LB"
        /  /

    exchange_demand(reactions) "demanded exchange reactions"
        /
*         'R_EX_co[e]                  '
         'R_EX_co2[e]                 '
         'R_EX_h[e]                   '
         'R_EX_h2o[e]                 '
         'R_EX_h2o2[e]                '
         'R_EX_hco3[e]                '
         'R_EX_o2s[e]                 '
         'R_EX_pi[e]                  '
        /

    targetSet(reactions) "target reactions in the metabolic network"
        /
        'R_DM_atp_c_                '                
        'R_ATPS4mi                  '
        'R_Tau_syn                  '
        'R_DM_Tau                   '                   
        'R_Abeta_syn                '
        'R_DM_Abeta                 '                 
        'R_IL6_syn                  '
        'R_DM_IL6                   '                   
        'R_TNFA_syn                 '
        'R_DM_TNFA                  '
        'R_Ubiquitin_syn'
         /

    secretion_demand(reactions) "demanded secretion reactions, vb = 0"
        /  /

   exchange_rxn_domain(reactions) "exchange reactions included in optimization problem"
          / /
        
*****************************************************************************************************************************************************
*** A user is to assgin specific rxn_vf (vf > 0 and vb = 0), rev_vb (vf = 0 and vb > 0) and rxn_vfvb (vf > 0 and vb > 0) in CA and HT model *********

   CA_Specific_rxn_vf(reactions) "Define irreversible rxn_vf (vf > 0 and vb = 0) in CA model"
        /  / 

   CA_Specific_rxn_vb(reactions) "Define irreversible rxn_vb (vf = 0 and vb > 0) in CA model"
        /   /

   CA_Specific_rxn_vfvb(reactions) "Define reversible rxn_vfvb (vf > 0 and vb > 0) in CA model"
       / /

   HT_Specific_rxn_vf(reactions) "Define irreversible rxn_vf (vf > 0 and vb = 0) in HT model"
        /  /

   HT_Specific_rxn_vb(reactions) "Define irreversible rxn_vb (vf = 0 and vb > 0) in HT model"
        /  / 

   HT_Specific_rxn_vfvb(reactions) "Define reversible rxn_vfvb (vf > 0 and vb > 0) in HT model"
       /   /

   BL_Specific_rxn_vf(reactions) "Define irreversible rxn_vf (vf > 0 and vb = 0) in BL model"
        /  /

   BL_Specific_rxn_vb(reactions) "Define irreversible rxn_vb (vf = 0 and vb > 0) in BL model"
        /  / 

   BL_Specific_rxn_vfvb(reactions) "Define reversible rxn_vfvb (vf > 0 and vb > 0) in BL model"
       /   /       

   TR_Specific_rxn_vf(reactions) "Define irreversible rxn_vf (vf > 0 and vb = 0) in TR model"
        /  /

   TR_Specific_rxn_vb(reactions) "Define irreversible rxn_vb (vf = 0 and vb > 0) in TR model"
        /  / 

   TR_Specific_rxn_vfvb(reactions) "Define reversible rxn_vfvb (vf > 0 and vb > 0) in TR model"
       /   /
       
   PH_Specific_rxn_vf(reactions) "Define irreversible rxn_vf (vf > 0 and vb = 0) in PH model"
        /  /

   PH_Specific_rxn_vb(reactions) "Define irreversible rxn_vb (vf = 0 and vb > 0) in PH model"
        /  / 

   PH_Specific_rxn_vfvb(reactions) "Define reversible rxn_vfvb (vf > 0 and vb > 0) in PH model"
       /   /
       
   PB_Specific_rxn_vf(reactions) "Define irreversible rxn_vf (vf > 0 and vb = 0) in PB model"
        /  /

   PB_Specific_rxn_vb(reactions) "Define irreversible rxn_vb (vf = 0 and vb > 0) in PB model"
        /  / 

   PB_Specific_rxn_vfvb(reactions) "Define reversible rxn_vfvb (vf > 0 and vb > 0) in PB model"
       /   /;
*****************************************************************************************************************************************************
$offempty

***** Extra subset of CA and HT model for each medium ***********************************************************************************************
$onempty
sets
    Extra_uptake_rxn_DMEM(reactions) "Extra CA and HT uptake reactions for DMEM"
    /
     'R_EX_fvs[e]'
     'R_EX_CE5786[e]'
     'R_EX_mepi[e]'
     'R_EX_5mta[e]'
     'R_EX_fdp[e]'
     'R_EX_5aop[e]'

* Additional uptake 2026-5-28
*         'R_EX_fvs[e]'
    /

    Extra_uptake_rxn_HAM(reactions) "Extra CA and HT uptake reactions for HAM"
    /
     'R_EX_fvs[e]'
     'R_EX_CE5786[e]'
     'R_EX_mepi[e]'
     'R_EX_5mta[e]'
     'R_EX_fdp[e]'
     'R_EX_5aop[e]'

* Additional uptake 2026-5-28
         'R_EX_cholate[e]'
    /

    Extra_uptake_rxn_HPLM(reactions) "Extra CA and HT uptake reactions for HPLM"
    /
     'R_EX_fvs[e]'
     'R_EX_CE5786[e]'
     'R_EX_mepi[e]'
     'R_EX_5mta[e]'
     'R_EX_fdp[e]'
     'R_EX_5aop[e]'
     
* Additional uptake 2026-5-28
         'R_EX_cholate[e]'
    /

    Extra_uptake_rxn_RPMI(reactions) "Extra CA and HT uptake reactions for RPMI"
    /
     'R_EX_fvs[e]'
     'R_EX_CE5786[e]'
     'R_EX_mepi[e]'
     'R_EX_5mta[e]'
     'R_EX_fdp[e]'
     'R_EX_5aop[e]'
     
* Additional uptake 2026-5-28
          'R_EX_cholate[e]'
    /

    Extra_uptake_rxn_VMH(reactions) "Extra CA and HT uptake reactions for VMH"
    /
     'R_EX_fvs[e]'
     'R_EX_CE5786[e]'
     'R_EX_mepi[e]'
     'R_EX_5mta[e]'
     'R_EX_fdp[e]'
     'R_EX_5aop[e]'
     
* Additional uptake 2026-5-28
         'R_EX_cholate[e]'
    /
    
    Extra_uptake_rxn_ALLEx(reactions) "Extra CA and HT uptake reactions for Ex_Rxn"
     /  /;
$offempty
******************************************************************************************************************************************************  


$ontext
**** the following statements can be modified by a user ********************************************************************************************
uptake_rxn_DMEM(reactions) = uptake_rxn_DMEM(reactions) + uptake_rxn_DMEM_chsterol(reactions) + Extra_uptake_rxn_DMEM(reactions);
uptake_rxn_HAM_chsterol(reactions) = uptake_rxn_HAM(reactions) - uptake_rxn_HAM_chsterol(reactions) + Extra_uptake_rxn_HAM(reactions);
uptake_rxn_HPLM_chsterol(reactions) = uptake_rxn_HPLM(reactions) + uptake_rxn_HPLM_chsterol(reactions) + Extra_uptake_rxn_HPLM(reactions);
uptake_rxn_RPMI_chsterol(reactions) = uptake_rxn_RPMI(reactions) + uptake_rxn_RPMI_chsterol(reactions) + Extra_uptake_rxn_RPMI(reactions);
uptake_rxn_VMH_chsterol(reactions) = uptake_rxn_VMH(reactions) - uptake_rxn_VMH_chsterol(reactions) + Extra_uptake_rxn_VMH(reactions);
uptake_rxn_ALLEx(reactions) = no;
uptake_rxn_ALLEx(reactions) $ (exchange_rxn(reactions)) = yes;
uptake_rxn_ALLEx_chsterol(reactions) = uptake_rxn_ALLEx(reactions) - uptake_rxn_ALLEx_chsterol(reactions) + Extra_uptake_rxn_ALLEx(reactions);
$offtext

***** To obtain actual set for uptake_rxn for each medium ********************************************************************************************
uptake_rxn_%User_Medium%(reactions) = uptake_rxn_%User_Medium%(reactions) + Extra_uptake_rxn_%User_Medium%(reactions);
******************************************************************************************************************************************************

parameters
***** lower and upper bounds for computing multiobjective values of both CA and HT models ***********************************************************
   MultiObjValue_vf_LB(reactions)
     /
      'R_ATPS4mi'                  1.0E-3
      'R_Tau_syn'                  0
      'R_Abeta_syn'                0
      'R_IL6_syn'                  0
      'R_TNFA_syn'                 0
      'R_DM_Tau'                   0
      'R_DM_Abeta'                 0
      'R_DM_IL6'                   0
      'R_DM_TNFA'                  0
      'R_Ubiquitin_syn'           1.0E-6
     /

   MultiObjValue_vb_LB(reactions)
     /
      'R_ATPS4mi'                  0
      'R_Tau_syn'                  0
      'R_Abeta_syn'                0
      'R_IL6_syn'                  0
      'R_TNFA_syn'                 0
      'R_DM_Tau'                   0
      'R_DM_Abeta'                 0
      'R_DM_IL6'                   0
      'R_DM_TNFA'                  0
      'R_Ubiquitin_syn'            0  
     /


   MultiObjValue_vf_UB(reactions)
     /
      'R_ATPS4mi'                  38
      'R_Tau_syn'                  0.4488
      'R_Abeta_syn'                0.4488
      'R_IL6_syn'                  0.4488
      'R_TNFA_syn'                 0.4488
      'R_DM_Tau'                   0.0057
      'R_DM_Abeta'                 0.0052
      'R_DM_IL6'                   0.0189
      'R_DM_TNFA'                  0.0175
      'R_Ubiquitin_syn'            0.05
     /
      
   MultiObjValue_vb_UB(reactions)
     /
      'R_ATPS4mi'                  38
      'R_Tau_syn'                  0
      'R_Abeta_syn'                0
      'R_IL6_syn'                  0
      'R_TNFA_syn'                 0
      'R_DM_Tau'                   0
      'R_DM_Abeta'                 0
      'R_DM_IL6'                   0
      'R_DM_TNFA'                  0
      'R_Ubiquitin_syn'            0
     /
*****************************************************************************************************************************************************
  BL_target_level_LB(targetSet) "theoretical lower target levels for BL model"
  /
      'R_DM_atp_c_'                32
      'R_ATPS4mi'                  1.0E-3
      'R_Tau_syn'                  0
      'R_Abeta_syn'                0
      'R_IL6_syn'                  0
      'R_TNFA_syn'                 0
      'R_DM_Tau'                   0
      'R_DM_Abeta'                 0
      'R_DM_IL6'                   0
      'R_DM_TNFA'                  0
      'R_Ubiquitin_syn'            0
*      'R_KER_02243'                0
  /

  BL_target_level_UB(targetSet) "theoretical upper target levels for BL model"
  /
      'R_DM_atp_c_'                40
      'R_ATPS4mi'                  38
      'R_Tau_syn'                  0.4488
      'R_Abeta_syn'                0.4488
      'R_IL6_syn'                  0.4488
      'R_TNFA_syn'                 0.4488
      'R_DM_Tau'                   0.0057
      'R_DM_Abeta'                 0.0052
      'R_DM_IL6'                   0.0189
      'R_DM_TNFA'                  0.0175
      'R_Ubiquitin_syn'            0.05
  /
  HT_target_level_LB(targetSet) "theoretical lower target levels for HT model"
  /
      'R_DM_atp_c_'                32
      'R_ATPS4mi'                  1.0E-3
      'R_Tau_syn'                  0
      'R_Abeta_syn'                0
      'R_IL6_syn'                  0
      'R_TNFA_syn'                 0
      'R_DM_Tau'                   0
      'R_DM_Abeta'                 0
      'R_DM_IL6'                   0
      'R_DM_TNFA'                  0
      'R_Ubiquitin_syn'            0
*      'R_KER_02243'                0
  /

  CA_target_level_LB(targetSet) "theoretical lower target levels for CA model"
  /
      'R_DM_atp_c_'                32
      'R_ATPS4mi'                  1.0E-3
      'R_Tau_syn'                  0
      'R_Abeta_syn'                0
      'R_IL6_syn'                  0
      'R_TNFA_syn'                 0
      'R_DM_Tau'                   0
      'R_DM_Abeta'                 0
      'R_DM_IL6'                   0
      'R_DM_TNFA'                  0
      'R_Ubiquitin_syn'           1.0E-6
  /

  HT_target_level_UB(targetSet) "theoretical upper target levels for HT model"
  /
      'R_DM_atp_c_'                40
      'R_ATPS4mi'                  38
      'R_Tau_syn'                  0
      'R_Abeta_syn'                0
      'R_IL6_syn'                  0
      'R_TNFA_syn'                 0
      'R_DM_Tau'                   0
      'R_DM_Abeta'                 0
      'R_DM_IL6'                   0
      'R_DM_TNFA'                  0
      'R_Ubiquitin_syn'           0.05
  /

  CA_target_level_UB(targetSet) "theoretical upper target levels for CA model"
  /
      'R_DM_atp_c_'                40
      'R_ATPS4mi'                  38
      'R_Tau_syn'                  0.4488
      'R_Abeta_syn'                0.4488
      'R_IL6_syn'                  0.4488
      'R_TNFA_syn'                 0.4488
      'R_DM_Tau'                   0.0057
      'R_DM_Abeta'                 0.0052
      'R_DM_IL6'                   0.0189
      'R_DM_TNFA'                  0.0175
      'R_Ubiquitin_syn'            0.05
      
  /

  vb_DM_uptake_LB(reactions) "lower bound of demanded uptake flux"
  /
   'R_EX_o2[e]'         1.0000E-03
   'R_EX_glc_D[e]'      1.0
*   'R_EX_glc_D[e]'      3.4466789370

  /

  vb_DM_uptake_UB(reactions) "upper bound of demanded uptake flux"
  /
   'R_EX_o2[e]'         6.0000E+00
   'R_EX_glc_D[e]'      1.0   
*   'R_EX_glc_D[e]'      5.1700184050

  /

  vb_DM_Exchange_UB(reactions) "upper bounds of demanded exchange vb"
  /
*   'R_EX_co[e]'        1.0000E+00
   'R_EX_h2o2[e]'      1.0000E+00
   'R_EX_hco3[e]'      1.0000E+02
   'R_EX_o2s[e]'       1.0000E+00
   'R_EX_co2[e]'       1.0000E+02
   'R_EX_h[e]'         1.0000E+02
   'R_EX_h2o[e]'       1.0000E+02
   'R_EX_pi[e]'        1.0000E+02

  /
   vf_DM_Exchange_UB(reactions) "upper bounds of demanded exchange vf"
  
***** LB and UB of intracellular uptake, section and exchange reactions of CA and HT models *********************************************************
   BL_Specific_rxn_vb_LB(reactions) "lower bound for Specific_rxn_vb and BL_Specific_rxn_vfvb (vb > 0) in BL model"
   BL_Specific_rxn_vb_UB(reactions) "upper bound for Specific_rxn_vb and BL_Specific_rxn_vfvb (vb > 0) in BL model"
   BL_Specific_rxn_vf_LB(reactions) "lower bound for Specific_rxn_vf and BL_Specific_rxn_vfvb (vf > 0) in BL model"
   BL_Specific_rxn_vf_UB(reactions) "upper bound for Specific_rxn_vf and BL_Specific_rxn_vfvb (vf > 0) in BL model"
   
   HT_Specific_rxn_vb_LB(reactions) "lower bound for Specific_rxn_vb and HT_Specific_rxn_vfvb (vb > 0) in HT model"
   HT_Specific_rxn_vb_UB(reactions) "upper bound for Specific_rxn_vb and HT_Specific_rxn_vfvb (vb > 0) in HT model"
   HT_Specific_rxn_vf_LB(reactions) "lower bound for Specific_rxn_vf and HT_Specific_rxn_vfvb (vf > 0) in HT model"
   HT_Specific_rxn_vf_UB(reactions) "upper bound for Specific_rxn_vf and HT_Specific_rxn_vfvb (vf > 0) in HT model"
   
   CA_Specific_rxn_vb_LB(reactions) "lower bound for Specific_rxn_vb and CA_Specific_rxn_vfvb (vb > 0) in CA model"
    
   CA_Specific_rxn_vb_UB(reactions) "upper bound for Specific_rxn_vb and CA_Specific_rxn_vfvb (vb > 0) in CA model"

   CA_Specific_rxn_vf_LB(reactions) "lower bound for Specific_rxn_vb and CA_Specific_rxn_vfvb (vf > 0) in CA model"
*     /'R_ATPS4mi'   10/     

   CA_Specific_rxn_vf_UB(reactions) "upper bound for Specific_rxn_vb and CA_Specific_rxn_vfvb (vf > 0) in CA model"
*    /'R_ATPS4mi'   38/

   TR_Specific_rxn_vb_LB(reactions) "lower bound for Specific_rxn_vb and TR_Specific_rxn_vfvb (vb > 0) in TR model"   
   TR_Specific_rxn_vb_UB(reactions) "upper bound for Specific_rxn_vb and TR_Specific_rxn_vfvb (vb > 0) in TR model"
   TR_Specific_rxn_vf_LB(reactions) "lower bound for Specific_rxn_vb and TR_Specific_rxn_vfvb (vf > 0) in TR model"
   TR_Specific_rxn_vf_UB(reactions) "upper bound for Specific_rxn_vb and TR_Specific_rxn_vfvb (vf > 0) in TR model"
   PH_Specific_rxn_vb_LB(reactions) "lower bound for Specific_rxn_vb and PH_Specific_rxn_vfvb (vb > 0) in PH model"   
   PH_Specific_rxn_vb_UB(reactions) "upper bound for Specific_rxn_vb and PH_Specific_rxn_vfvb (vb > 0) in PH model"
   PH_Specific_rxn_vf_LB(reactions) "lower bound for Specific_rxn_vb and PH_Specific_rxn_vfvb (vf > 0) in PH model"
   PH_Specific_rxn_vf_UB(reactions) "upper bound for Specific_rxn_vb and PH_Specific_rxn_vfvb (vf > 0) in PH model"
   PB_Specific_rxn_vb_LB(reactions) "lower bound for Specific_rxn_vb and PB_Specific_rxn_vfvb (vb > 0) in PB model"   
   PB_Specific_rxn_vb_UB(reactions) "upper bound for Specific_rxn_vb and PB_Specific_rxn_vfvb (vb > 0) in PB model"
   PB_Specific_rxn_vf_LB(reactions) "lower bound for Specific_rxn_vb and PB_Specific_rxn_vfvb (vf > 0) in PB model"
   PB_Specific_rxn_vf_UB(reactions) "upper bound for Specific_rxn_vb and PB_Specific_rxn_vfvb (vf > 0) in PB model";
   
*****************************************************************************************************************************************************

***** using the intial values in A1 model ***********************************************************************************************************
BL_Specific_rxn_vb_LB(BL_Specific_rxn_vb) $ (card(BL_Specific_rxn_vb) = 0) = vb_initial_LB(BL_Specific_rxn_vb);
BL_Specific_rxn_vb_UB(BL_Specific_rxn_vb) $ (card(BL_Specific_rxn_vb) = 0) = vb_initial_UB(BL_Specific_rxn_vb);
BL_Specific_rxn_vf_LB(BL_Specific_rxn_vf) $ (card(BL_Specific_rxn_vf) = 0) = vf_initial_LB(BL_Specific_rxn_vf);
BL_Specific_rxn_vf_UB(BL_Specific_rxn_vf) $ (card(BL_Specific_rxn_vf) = 0) = vf_initial_UB(BL_Specific_rxn_vf);
  
HT_Specific_rxn_vb_LB(HT_Specific_rxn_vb) $ (card(HT_Specific_rxn_vb) = 0) = vb_initial_LB(HT_Specific_rxn_vb);
HT_Specific_rxn_vb_UB(HT_Specific_rxn_vb) $ (card(HT_Specific_rxn_vb) = 0) = vb_initial_UB(HT_Specific_rxn_vb);
HT_Specific_rxn_vf_LB(HT_Specific_rxn_vf) $ (card(HT_Specific_rxn_vf) = 0) = vf_initial_LB(HT_Specific_rxn_vf);
HT_Specific_rxn_vf_UB(HT_Specific_rxn_vf) $ (card(HT_Specific_rxn_vf) = 0) = vf_initial_UB(HT_Specific_rxn_vf);

CA_Specific_rxn_vb_LB(CA_Specific_rxn_vb) $ (card(CA_Specific_rxn_vb) = 0) = vb_initial_LB(CA_Specific_rxn_vb);
CA_Specific_rxn_vb_UB(CA_Specific_rxn_vb) $ (card(CA_Specific_rxn_vb) = 0) = vb_initial_UB(CA_Specific_rxn_vb);
CA_Specific_rxn_vf_LB(CA_Specific_rxn_vf) $ (card(CA_Specific_rxn_vf) = 0) = vf_initial_LB(CA_Specific_rxn_vf);
CA_Specific_rxn_vf_UB(CA_Specific_rxn_vf) $ (card(CA_Specific_rxn_vf) = 0) = vf_initial_UB(CA_Specific_rxn_vf);

TR_Specific_rxn_vb_LB(TR_Specific_rxn_vb) $ (card(TR_Specific_rxn_vb) = 0) = vb_initial_LB(TR_Specific_rxn_vb);
TR_Specific_rxn_vb_UB(TR_Specific_rxn_vb) $ (card(TR_Specific_rxn_vb) = 0) = vb_initial_UB(TR_Specific_rxn_vb);
TR_Specific_rxn_vf_LB(TR_Specific_rxn_vf) $ (card(TR_Specific_rxn_vf) = 0) = vf_initial_LB(TR_Specific_rxn_vf);
TR_Specific_rxn_vf_UB(TR_Specific_rxn_vf) $ (card(TR_Specific_rxn_vf) = 0) = vf_initial_UB(TR_Specific_rxn_vf);

PH_Specific_rxn_vb_LB(PH_Specific_rxn_vb) $ (card(PH_Specific_rxn_vb) = 0) = vb_initial_LB(PH_Specific_rxn_vb);
PH_Specific_rxn_vb_UB(PH_Specific_rxn_vb) $ (card(PH_Specific_rxn_vb) = 0) = vb_initial_UB(PH_Specific_rxn_vb);
PH_Specific_rxn_vf_LB(PH_Specific_rxn_vf) $ (card(PH_Specific_rxn_vf) = 0) = vf_initial_LB(PH_Specific_rxn_vf);
PH_Specific_rxn_vf_UB(PH_Specific_rxn_vf) $ (card(PH_Specific_rxn_vf) = 0) = vf_initial_UB(PH_Specific_rxn_vf);

PB_Specific_rxn_vb_LB(PB_Specific_rxn_vb) $ (card(PB_Specific_rxn_vb) = 0) = vb_initial_LB(PB_Specific_rxn_vb);
PB_Specific_rxn_vb_UB(PB_Specific_rxn_vb) $ (card(PB_Specific_rxn_vb) = 0) = vb_initial_UB(PB_Specific_rxn_vb);
PB_Specific_rxn_vf_LB(PB_Specific_rxn_vf) $ (card(PB_Specific_rxn_vf) = 0) = vf_initial_LB(PB_Specific_rxn_vf);
PB_Specific_rxn_vf_UB(PB_Specific_rxn_vf) $ (card(PB_Specific_rxn_vf) = 0) = vf_initial_UB(PB_Specific_rxn_vf);
*****************************************************************************************************************************************************

