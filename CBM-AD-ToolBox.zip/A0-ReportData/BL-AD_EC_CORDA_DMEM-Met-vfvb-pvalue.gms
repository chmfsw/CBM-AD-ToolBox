$onMulti
Parameters
  biocomp_AD_EC_CORDA_DMEM(biocompound<) "biocompounds defined in AD_EC_CORDA_DMEM model"
  /
     'S_gluala[e]'          -3.00,     'S_xolest181_hs[e]'           3.00,     'S_HC00005[e]'           1.50,     'S_ldl_hs[e]'           1.50,
     'S_mi145p[c]'          -3.00,     'S_HC00718[c]'          -1.00,     'S_acetol[c]'          -1.50,     'S_dcamp[c]'          -3.00,
     'S_12ppd_S[c]'          -1.50,     'S_itaccoa[m]'          -3.00,     'S_clpn_hs[c]'          -3.00,     'S_focytC[m]'          -2.50,
     'S_ficytC[m]'          -2.50,     'S_2kmb[c]'          -3.00,     'S_13dpg[c]'           3.00,     'S_g3p[c]'           3.00,
     'S_retinol_9_cis[c]'          -3.00,     'S_r1p[c]'          -3.00,     'S_retinal_cis_9[c]'          -3.00,     'S_HC00664[c]'          -3.00,
     'S_HC01180[c]'          -3.00,     'S_HC01842[c]'          -1.00,     'S_r5p[c]'          -3.00,     'S_6pgc[c]'           3.00,
     'S_6pgl[c]'           3.00,     'S_M02686[c]'          -3.00,     'S_M02758[c]'          -3.00,     'S_ubiquitin[c]'           3.00,
     'S_abeta[c]'           3.00,     'S_tau[c]'           3.00,     'S_TNFA[c]'           3.00,     'S_IL6[c]'           3.00,
     'S_1p3h5c[c][m]'          -1.00,     'S_2mop[c][m]'           3.00,     'S_cdpchol[c][r]'          -3.00,     'S_cdpdag_hs[c][m]'          -3.00,
     'S_coa[c][l][m][n][r][x]'          -3.00,     'S_dudp[c][m]'          -3.00,     'S_dump[c][m]'          -3.00,     'S_dutp[c][m]'          -3.00,
     'S_g6p[c][r]'          -3.00,     'S_gcald[c][m]'           2.50,     'S_hpyr[c][m][x]'           2.50,     'S_lald_L[c][m]'          -1.50,
     'S_methf[c][m]'           3.00,     'S_nadph[c][m][r][x]'          -2.50,     'S_pail45p_hs[c][n]'          -3.00,     'S_pail5p_hs[c][n]'          -3.00,
     'S_pyr[c][m][x]'          -2.50,     'S_10fthf[c][e][l][m]'           3.00,     'S_2pg[c][e]'           1.50,     'S_3mop[c][e][m]'          -3.00,
     'S_3pg[c][e][m]'           1.50,     'S_4hpro_LT[c][e][m]'          -2.50,     'S_4mop[c][e][m]'          -3.00,     'S_5mthf[c][e]'           3.00,
     'S_5thf[c][e][l][m]'          -3.00,     'S_6thf[c][e][l][m]'          -3.00,     'S_7thf[c][e][l][m]'          -3.00,     'S_adp[c][e][g][l][m][n][r]'          -3.00,
     'S_ahcys[c][e][m][r]'          -1.00,     'S_akg[c][e][m][x]'           2.50,     'S_ala_L[c][e][x]'          -1.00,     'S_amet[c][e][m][r]'          -1.00,
     'S_amp[c][e][g][m][n][r][x]'           1.50,     'S_arg_L[c][e][m]'           1.00,     'S_ascb_L[c][e]'          -1.50,     'S_asn_L[c][e][m]'           3.00,
     'S_asp_L[c][e][m]'          -2.50,     'S_atp[c][e][g][l][m][n][r][x]'          -3.00,     'S_cdp[c][e][m][n]'          -3.00,     'S_cgly[c][e]'          -3.00,
     'S_chol[c][e][m][n]'          -3.00,     'S_cholate[c][e][m][r][x]'          -2.50,     'S_cholp[c][e][g][l]'           1.50,     'S_chsterol[c][e][l][m][r]'           1.50,
     'S_cit[c][e][m]'           3.00,     'S_citr_L[c][e][m]'          -3.00,     'S_cl[c][e]'          -3.00,     'S_cmp[c][e][g][m][n][r]'          -3.00,
     'S_co2[c][e][m][r][x]'          -3.00,     'S_crm_hs[c][e][g][l][n][r]'          -3.00,     'S_ctp[c][e][m][n]'          -3.00,     'S_cys_L[c][e][m]'           3.00,
     'S_dag_hs[c][e][n][r]'          -3.00,     'S_dchac[c][e]'          -2.50,     'S_dcmp[c][e][m][n]'          -3.00,     'S_dcyt[c][e][m][n]'          -3.00,
     'S_dhdascb[c][e]'          -1.50,     'S_dhf[c][e][l][m]'          -1.00,     'S_ethamp[c][e][r]'          -1.00,     'S_fol[c][e][m]'          -2.50,
     'S_fum[c][e][m]'          -3.00,     'S_g3pc[c][e]'           3.00,     'S_gal[c][e][l]'          -1.50,     'S_gdp[c][e][g][m]'          -3.00,
     'S_glc_D[c][e][l][r]'           2.00,     'S_glcn[c][e]'           3.00,     'S_gln_L[c][e][m]'           3.00,     'S_glu_L[c][e][l][m][r]'          -3.00,
     'S_gluside_hs[c][e][g][l][r]'          -3.00,     'S_glx[c][e][m][x]'          -3.00,     'S_gly[c][e][m][x]'          -2.50,     'S_glyald[c][e][m]'           1.50,
     'S_glyc[c][e][m]'           1.50,     'S_glyc_R[c][e][m]'          -3.00,     'S_glyclt[c][e][m][x]'           2.50,     'S_glypro[c][e]'          -3.00,
     'S_gsn[c][e]'          -3.00,     'S_gthox[c][e][m][r]'          -3.00,     'S_gthrd[c][e][m][r]'          -3.00,     'S_gtp[c][e][m]'          -3.00,
     'S_h[c][e][g][i][l][m][n][r][x]'          -2.50,     'S_h2o[c][e][g][l][m][n][r][x]'          -3.00,     'S_h2o2[c][e][l][m][r][x]'          -3.00,     'S_HC00342[c][e][m]'           3.00,
     'S_HC00900[c][e][m]'           3.00,     'S_hco3[c][e][m]'          -3.00,     'S_his_L[c][e]'           3.00,     'S_hxan[c][e]'          -3.00,
     'S_icit[c][e][m]'           3.00,     'S_idp[c][e][m]'          -3.00,     'S_ile_L[c][e][m]'           1.00,     'S_imp[c][e]'          -3.00,
     'S_inost[c][e]'          -3.00,     'S_ins[c][e]'          -3.00,     'S_itacon[c][e][m]'          -3.00,     'S_itp[c][e][m]'          -3.00,
     'S_lac_L[c][e][m][x]'          -1.50,     'S_Lcystin[c][e]'           3.00,     'S_leu_L[c][e][m]'           1.00,     'S_lpchol_hs[c][e]'           3.00,
     'S_lys_L[c][e][m]'           3.00,     'S_M01989[c][e]'          -3.00,     'S_mal_L[c][e][m][x]'           2.50,     'S_met_L[c][e][m]'           1.00,
     'S_mlthf[c][e][m]'           3.00,     'S_mthgxl[c][e]'          -1.50,     'S_na1[c][e][g][x]'          -2.50,     'S_nad[c][e][m][n][r][x]'          -2.50,
     'S_nadh[c][e][m][r][x]'          -2.50,     'S_nadp[c][e][m][r][x]'          -2.50,     'S_nh4[c][e][m][n][r][x]'          -3.00,     'S_no[c][e]'          -3.00,
     'S_o2[c][e][m][n][r][x]'          -2.50,     'S_o2s[c][e][m]'          -2.50,     'S_oaa[c][e][m][x]'          -3.00,     'S_orot[c][e]'          -3.00,
     'S_orot5p[c][e]'          -3.00,     'S_oxa[c][e][m][x]'          -1.00,     'S_pa_hs[c][e][m][n]'          -3.00,     'S_pail_hs[c][e][n]'          -3.00,
     'S_pchol_hs[c][e][r]'           1.50,     'S_pe_hs[c][e][r]'          -3.00,     'S_pep[c][e][m]'           1.50,     'S_pglyc_hs[c][e]'          -3.00,
     'S_phe_L[c][e][m]'          -3.00,     'S_pi[c][e][g][l][m][n][r][x]'          -3.00,     'S_ppi[c][e][m][n][r][x]'           1.50,     'S_pro_L[c][e][m]'           1.00,
     'S_prpp[c][e]'          -3.00,     'S_ps_hs[c][e]'          -3.00,     'S_pydx[c][e]'          -3.00,     'S_pydxn[c][e]'          -3.00,
     'S_retinal[c][e][r]'          -3.00,     'S_retinol[c][e][r]'          -3.00,     'S_Rtotal[c][e][g][l]'           1.50,     'S_Rtotal2[c][e]'           1.50,
     'S_Rtotal3[c][e]'           1.50,     'S_ser_L[c][e][m][x]'           1.50,     'S_so4[c][e][l][r]'          -3.00,     'S_sphmyln_hs[c][e][g][l][r]'          -3.00,
     'S_succ[c][e][m][x]'           3.00,     'S_thf[c][e][l][m]'          -2.50,     'S_thr_L[c][e]'           3.00,     'S_trp_L[c][e]'           3.00,
     'S_tyr_L[c][e]'           3.00,     'S_udp[c][e][g][l][n][r]'          -3.00,     'S_ump[c][e][g][l][n][r]'          -3.00,     'S_ura[c][e]'          -3.00,
     'S_urea[c][e][m]'           3.00,     'S_uri[c][e][l]'          -3.00,     'S_val_L[c][e][m]'           1.00,     'S_xan[c][e]'          -3.00,
     'S_xolest2_hs[c][e][l][r]'           3.00,     'S_xtsn[c][e]'          -3.00
    /

$onMulti
  rxn_vf_AD_EC_CORDA_DMEM(reactions<) "rxn_vf defined in AD_EC_CORDA_DMEM model"
  /
     'R_EX_chsterol[e]'           3.00,     'R_EX_dag_hs[e]'          -3.00,     'R_EX_gluala[e]'          -3.00,     'R_EX_gsn[e]'          -3.00,
     'R_EX_gthox[e]'          -3.00,     'R_EX_hco3[e]'          -3.00,     'R_EX_no[e]'          -3.00,     'R_EX_o2s[e]'          -1.50,
     'R_EX_oxa[e]'          -3.00,     'R_EX_pchol_hs[e]'          -3.00,     'R_EX_Rtotal[e]'           1.50,     'R_EX_Rtotal2[e]'           1.50,
     'R_EX_Rtotal3[e]'           1.50,     'R_EX_xolest2_hs[e]'           3.00,     'R_EX_orot[e]'          -3.00,     'R_EX_cholp[e]'           3.00,
     'R_EX_ethamp[e]'          -1.00,     'R_EX_xolest181_hs[e]'           3.00,     'R_EX_glyclt[e]'           3.00,     'R_EX_oaa[e]'          -3.00,
     'R_EX_glcn[e]'           3.00,     'R_EX_co2[e]'          -3.00,     'R_EX_dcyt[e]'          -3.00,     'R_EX_fum[e]'          -3.00,
     'R_EX_glypro[e]'          -3.00,     'R_EX_pi[e]'          -3.00,     'R_EX_uri[e]'          -3.00,     'R_EX_nh4[e]'          -3.00,
     'R_EX_HC00005[e]'           1.50,     'R_EX_M01989[e]'          -3.00
    /

$onMulti
  rxn_vb_AD_EC_CORDA_DMEM(reactions<) "rxn_vb defined in AD_EC_CORDA_DMEM model"
  /
     'R_EX_chol[e]'          -3.00,     'R_EX_cholate[e]'          -2.50,     'R_EX_gthrd[e]'          -3.00,     'R_EX_h2o2[e]'          -3.00,
     'R_EX_Lcystin[e]'           3.00,     'R_EX_pe_hs[e]'          -3.00,     'R_EX_pglyc_hs[e]'          -3.00,     'R_EX_ps_hs[e]'          -3.00,
     'R_EX_orot5p[e]'          -3.00,     'R_EX_asn_L[e]'           3.00,     'R_EX_asp_L[e]'           3.00,     'R_EX_glu_L[e]'          -3.00,
     'R_EX_h[e]'          -2.50,     'R_EX_h2o[e]'          -3.00,     'R_EX_ile_L[e]'           3.00,     'R_EX_leu_L[e]'           3.00,
     'R_EX_lys_L[e]'           3.00,     'R_EX_met_L[e]'           3.00,     'R_EX_o2[e]'          -1.50,     'R_EX_pro_L[e]'           1.00,
     'R_EX_ser_L[e]'           2.00,     'R_EX_val_L[e]'           3.00,     'R_EX_gly[e]'          -2.50,     'R_EX_ala_L[e]'          -2.50,
     'R_EX_his_L[e]'           3.00,     'R_EX_thr_L[e]'           3.00,     'R_EX_gln_L[e]'           3.00,     'R_EX_phe_L[e]'           3.00,
     'R_EX_tyr_L[e]'           3.00,     'R_EX_arg_L[e]'           1.00,     'R_EX_nh4[e]'          -3.00,     'R_EX_hxan[e]'          -3.00,
     'R_EX_trp_L[e]'           3.00,     'R_EX_pydxn[e]'          -3.00,     'R_EX_ldl_hs[e]'           1.50,     'R_EX_gluside_hs[e]'          -3.00

    /

$onMulti
  log2_Met_CAHT_AD_EC_CORDA_DMEM(biocompound<) "log2_Met_CAHT defined in AD_EC_CORDA_DMEM model"
  /
     'S_gluala[e]'       -39.86313714,     'S_xolest181_hs[e]'        39.04903909,     'S_HC00005[e]'         4.80948445,     'S_ldl_hs[e]'         4.80948445,
     'S_mi145p[c]'       -36.51689051,     'S_HC00718[c]'        -1.07115976,     'S_acetol[c]'        -2.87583737,     'S_dcamp[c]'       -37.60041620,
     'S_12ppd_S[c]'        -2.88553839,     'S_itaccoa[m]'       -42.38882952,     'S_clpn_hs[c]'       -35.39681442,     'S_focytC[m]'        -1.77641346,
     'S_ficytC[m]'        -1.77641346,     'S_2kmb[c]'       -37.06033685,     'S_13dpg[c]'        40.27665284,     'S_g3p[c]'        40.27665284,
     'S_retinol_9_cis[c]'       -34.35219553,     'S_r1p[c]'       -39.86313714,     'S_retinal_cis_9[c]'       -34.35219553,     'S_HC00664[c]'       -35.00486358,
     'S_HC01180[c]'       -35.00486358,     'S_HC01842[c]'        -1.07115976,     'S_r5p[c]'       -33.32883703,     'S_6pgc[c]'        39.86313714,
     'S_6pgl[c]'        39.86313714,     'S_M02686[c]'       -39.12465548,     'S_M02758[c]'       -39.12465548,     'S_ubiquitin[c]'        27.46765398,
     'S_abeta[c]'        31.28202029,     'S_tau[c]'        31.43472152,     'S_TNFA[c]'        32.17408971,     'S_IL6[c]'        31.40860851,
     'S_1p3h5c[c][m]'        -1.40653581,     'S_2mop[c][m]'        42.12541075,     'S_cdpchol[c][r]'       -36.98169442,     'S_cdpdag_hs[c][m]'       -35.39681442,
     'S_coa[c][l][m][n][r][x]'       -42.38882952,     'S_dudp[c][m]'        -0.98050261,     'S_dump[c][m]'       -39.05653933,     'S_dutp[c][m]'        -0.97295805,
     'S_g6p[c][r]'        -0.09471312,     'S_gcald[c][m]'         3.41965969,     'S_hpyr[c][m][x]'         3.41965969,     'S_lald_L[c][m]'        -2.88553839,
     'S_methf[c][m]'        43.96760987,     'S_nadph[c][m][r][x]'        -0.96346961,     'S_pail45p_hs[c][n]'       -37.51689051,     'S_pail5p_hs[c][n]'       -36.51689051,
     'S_pyr[c][m][x]'        -2.12601851,     'S_10fthf[c][e][l][m]'        43.96760987,     'S_2pg[c][e]'         6.39444695,     'S_3mop[c][e][m]'       -37.27923592,
     'S_3pg[c][e][m]'         5.39444695,     'S_4hpro_LT[c][e][m]'        -2.40165822,     'S_4mop[c][e][m]'       -36.77082207,     'S_5mthf[c][e]'        39.63845822,
     'S_5thf[c][e][l][m]'       -39.72955645,     'S_6thf[c][e][l][m]'       -39.72955645,     'S_7thf[c][e][l][m]'       -40.72955645,     'S_adp[c][e][g][l][m][n][r]'        -1.05986858,
     'S_ahcys[c][e][m][r]'        -1.07115976,     'S_akg[c][e][m][x]'         1.15559511,     'S_ala_L[c][e][x]'        -0.39753931,     'S_amet[c][e][m][r]'        -1.07115976,
     'S_amp[c][e][g][m][n][r][x]'         3.75123934,     'S_arg_L[c][e][m]'         2.81781907,     'S_ascb_L[c][e]'        -6.28066233,     'S_asn_L[c][e][m]'        38.43937030,
     'S_asp_L[c][e][m]'        -4.31331033,     'S_atp[c][e][g][l][m][n][r][x]'        -1.05998375,     'S_cdp[c][e][m][n]'       -35.98169442,     'S_cgly[c][e]'        -4.85323165,
     'S_chol[c][e][m][n]'       -40.27937776,     'S_cholate[c][e][m][r][x]'        -1.80060247,     'S_cholp[c][e][g][l]'         1.15969289,     'S_chsterol[c][e][l][m][r]'         3.80948445,
     'S_cit[c][e][m]'        42.48926423,     'S_citr_L[c][e][m]'       -35.20675596,     'S_cl[c][e]'       -36.53639122,     'S_cmp[c][e][g][m][n][r]'       -37.39675254,
     'S_co2[c][e][m][r][x]'        -0.98808927,     'S_crm_hs[c][e][g][l][n][r]'       -37.56665692,     'S_ctp[c][e][m][n]'       -35.98169442,     'S_cys_L[c][e][m]'        37.23870436,
     'S_dag_hs[c][e][n][r]'       -37.51689051,     'S_dchac[c][e]'        -1.80060247,     'S_dcmp[c][e][m][n]'       -40.05653933,     'S_dcyt[c][e][m][n]'       -40.64150183,
     'S_dhdascb[c][e]'        -6.28066233,     'S_dhf[c][e][l][m]'        -0.46413823,     'S_ethamp[c][e][r]'        -1.07115976,     'S_fol[c][e][m]'        -1.75837533,
     'S_fum[c][e][m]'       -43.26827236,     'S_g3pc[c][e]'        39.69169034,     'S_gal[c][e][l]'        -1.03399900,     'S_gdp[c][e][g][m]'       -38.00708765,
     'S_glc_D[c][e][l][r]'         0.52819565,     'S_glcn[c][e]'        40.86313714,     'S_gln_L[c][e][m]'        39.11508173,     'S_glu_L[c][e][l][m][r]'        -3.75836521,
     'S_gluside_hs[c][e][g][l][r]'       -35.98169442,     'S_glx[c][e][m][x]'       -43.54234433,     'S_gly[c][e][m][x]'        -1.05071945,     'S_glyald[c][e][m]'         6.39444695,
     'S_glyc[c][e][m]'         5.22452195,     'S_glyc_R[c][e][m]'       -33.88220589,     'S_glyclt[c][e][m][x]'         4.41965969,     'S_glypro[c][e]'       -39.22638419,
     'S_gsn[c][e]'       -40.52601965,     'S_gthox[c][e][m][r]'       -10.67956574,     'S_gthrd[c][e][m][r]'        -4.84057448,     'S_gtp[c][e][m]'       -38.00708765,
     'S_h[c][e][g][i][l][m][n][r][x]'        -1.26190930,     'S_h2o[c][e][g][l][m][n][r][x]'        -1.27082946,     'S_h2o2[c][e][l][m][r][x]'       -13.99765943,     'S_HC00342[c][e][m]'        43.81517361,
     'S_HC00900[c][e][m]'        42.12541075,     'S_hco3[c][e][m]'       -43.40537337,     'S_his_L[c][e]'        38.12699599,     'S_hxan[c][e]'       -40.86313714,
     'S_icit[c][e][m]'        42.09966361,     'S_idp[c][e][m]'       -43.38882952,     'S_ile_L[c][e][m]'         1.32661352,     'S_imp[c][e]'       -37.60041620,
     'S_inost[c][e]'       -38.62131737,     'S_ins[c][e]'       -37.60041620,     'S_itacon[c][e][m]'       -42.38882952,     'S_itp[c][e][m]'       -43.38882952,
     'S_lac_L[c][e][m][x]'        -2.10898964,     'S_Lcystin[c][e]'        34.45058927,     'S_leu_L[c][e][m]'         3.09855165,     'S_lpchol_hs[c][e]'        40.69169034,
     'S_lys_L[c][e][m]'        39.45247986,     'S_M01989[c][e]'       -42.10726622,     'S_mal_L[c][e][m][x]'         0.72305217,     'S_met_L[c][e][m]'         0.71053804,
     'S_mlthf[c][e][m]'        44.03765603,     'S_mthgxl[c][e]'        -2.87583737,     'S_na1[c][e][g][x]'        -1.38534694,     'S_nad[c][e][m][n][r][x]'        -1.81714086,
     'S_nadh[c][e][m][r][x]'        -1.81714086,     'S_nadp[c][e][m][r][x]'        -0.96346961,     'S_nh4[c][e][m][n][r][x]'       -40.75392744,     'S_no[c][e]'       -36.20675596,
     'S_o2[c][e][m][n][r][x]'        -1.80574463,     'S_o2s[c][e][m]'        -1.74776868,     'S_oaa[c][e][m][x]'       -44.01454734,     'S_orot[c][e]'       -40.86313714,
     'S_orot5p[c][e]'        -0.98064460,     'S_oxa[c][e][m][x]'        -0.71662275,     'S_pa_hs[c][e][m][n]'       -37.76795465,     'S_pail_hs[c][e][n]'       -38.27398598,
     'S_pchol_hs[c][e][r]'         0.49275988,     'S_pe_hs[c][e][r]'       -40.56667067,     'S_pep[c][e][m]'         6.39444695,     'S_pglyc_hs[c][e]'       -36.71869301,
     'S_phe_L[c][e][m]'        -6.78742071,     'S_pi[c][e][g][l][m][n][r][x]'        -1.05686494,     'S_ppi[c][e][m][n][r][x]'         1.33260321,     'S_pro_L[c][e][m]'         0.53954787,
     'S_prpp[c][e]'       -39.86313714,     'S_ps_hs[c][e]'       -38.90105307,     'S_pydx[c][e]'       -40.12843668,     'S_pydxn[c][e]'       -41.12843668,
     'S_retinal[c][e][r]'       -34.65173183,     'S_retinol[c][e][r]'       -34.65173183,     'S_Rtotal[c][e][g][l]'         7.13141255,     'S_Rtotal2[c][e]'         4.80948445,
     'S_Rtotal3[c][e]'         4.80948445,     'S_ser_L[c][e][m][x]'         0.64525632,     'S_so4[c][e][l][r]'       -44.55072553,     'S_sphmyln_hs[c][e][g][l][r]'       -36.98169442,
     'S_succ[c][e][m][x]'        38.85734959,     'S_thf[c][e][l][m]'        -0.82203010,     'S_thr_L[c][e]'        39.40803996,     'S_trp_L[c][e]'        36.07638269,
     'S_tyr_L[c][e]'        37.72275566,     'S_udp[c][e][g][l][n][r]'       -39.05653933,     'S_ump[c][e][g][l][n][r]'        -0.98050261,     'S_ura[c][e]'       -39.84748738,
     'S_urea[c][e][m]'        46.47502805,     'S_uri[c][e][l]'        -0.96639923,     'S_val_L[c][e][m]'         8.24951598,     'S_xan[c][e]'       -39.52601965,
     'S_xolest2_hs[c][e][l][r]'        38.21561455,     'S_xtsn[c][e]'       -39.52601965
    /

$onMulti
  log2_vf_CAHT_AD_EC_CORDA_DMEM(reactions<) "log2_vfCAHT defined in AD_EC_CORDA_DMEM model"
  /
     'R_EX_chsterol[e]'        40.27665284,     'R_EX_dag_hs[e]'       -36.51689051,     'R_EX_gluala[e]'       -39.86313714,     'R_EX_gsn[e]'       -39.52601965,
     'R_EX_gthox[e]'       -38.86313714,     'R_EX_hco3[e]'       -37.39662201,     'R_EX_no[e]'       -35.20675596,     'R_EX_o2s[e]'        -1.68855009,
     'R_EX_oxa[e]'       -42.55629458,     'R_EX_pchol_hs[e]'       -34.88220589,     'R_EX_Rtotal[e]'         6.39444695,     'R_EX_Rtotal2[e]'         4.80948445,
     'R_EX_Rtotal3[e]'         4.80948445,     'R_EX_xolest2_hs[e]'        38.21561455,     'R_EX_orot[e]'       -39.86313714,     'R_EX_cholp[e]'        39.13262501,
     'R_EX_ethamp[e]'        -9.14970957,     'R_EX_xolest181_hs[e]'        39.04903909,     'R_EX_glyclt[e]'        40.27665284,     'R_EX_oaa[e]'       -39.97690081,
     'R_EX_glcn[e]'        39.86313714,     'R_EX_co2[e]'        -0.83473517,     'R_EX_dcyt[e]'       -39.05653933,     'R_EX_fum[e]'       -35.20854787,
     'R_EX_glypro[e]'       -38.22638419,     'R_EX_pi[e]'        -0.94659679,     'R_EX_uri[e]'        -0.95981045,     'R_EX_nh4[e]'       -35.53639122,
     'R_EX_HC00005[e]'         4.80948445,     'R_EX_M01989[e]'       -41.10726622
    /

$onMulti
  log2_vb_CAHT_AD_EC_CORDA_DMEM(reactions<) "log2_vb_CAHT defined in AD_EC_CORDA_DMEM model"
  /
     'R_EX_chol[e]'       -39.27937776,     'R_EX_cholate[e]'        -1.80060247,     'R_EX_gthrd[e]'        -3.85323165,     'R_EX_h2o2[e]'       -39.86313714,
     'R_EX_Lcystin[e]'        33.43173329,     'R_EX_pe_hs[e]'       -39.56667067,     'R_EX_pglyc_hs[e]'       -35.71869301,     'R_EX_ps_hs[e]'       -37.90105307,
     'R_EX_orot5p[e]'        -0.98064460,     'R_EX_asn_L[e]'        37.43937030,     'R_EX_asp_L[e]'        38.19855671,     'R_EX_glu_L[e]'        -1.07884120,
     'R_EX_h[e]'        -0.78866542,     'R_EX_h2o[e]'        -1.01488690,     'R_EX_ile_L[e]'        37.60584944,     'R_EX_leu_L[e]'        38.86937371,
     'R_EX_lys_L[e]'        38.45247986,     'R_EX_met_L[e]'        36.77087490,     'R_EX_o2[e]'        -2.11744519,     'R_EX_pro_L[e]'         0.53954787,
     'R_EX_ser_L[e]'         0.30801690,     'R_EX_val_L[e]'        38.51220560,     'R_EX_gly[e]'        -1.12970773,     'R_EX_ala_L[e]'        -4.44383746,
     'R_EX_his_L[e]'        37.12699599,     'R_EX_thr_L[e]'        38.40803996,     'R_EX_gln_L[e]'        38.11508173,     'R_EX_phe_L[e]'        37.24771473,
     'R_EX_tyr_L[e]'        36.72275566,     'R_EX_arg_L[e]'         2.81781907,     'R_EX_nh4[e]'       -38.50902333,     'R_EX_hxan[e]'       -39.86313714,
     'R_EX_trp_L[e]'        35.07638269,     'R_EX_pydxn[e]'       -40.12843668,     'R_EX_ldl_hs[e]'         4.80948445,     'R_EX_gluside_hs[e]'       -35.98169442

    /;
