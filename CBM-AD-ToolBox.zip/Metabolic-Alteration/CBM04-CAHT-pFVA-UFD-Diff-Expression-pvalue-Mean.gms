$title Metabolite flow variation analysis for fuzzy multiobjective FBA and UFD problems
$Ontext
multiobjective FBA problem for HT model:
Fuzzy max v_ATP
Fuzzy max v_PHGDH
N (vf-vb) = 0
vf/b_LB <= vf/b <= vf/b_UB

UFD problem for HT model:
min sum(cf * (vf^2 +vb^2))
N (vf - vb) = 0
vf/b_LB <= vf/b <= vf/b_UB
v_ATP >= v_ATP_optima
v_PHGDH >= v_PHGDH_optima

multiobjective FBA problem for CA model:
Fuzzy max v_ATP
Fuzzy max v_biomass
N (vf-vb) = 0
vf/b_LB <= vf/b <= vf/b_UB

UFD problem for CA model:
min sum(cf * (vf^2 +vb^2))
N (vf - vb) = 0
vf/b_LB <= vf/b <= vf/b_UB
v_ATP >= v_ATP_optima
v_biomass >= v_PHGDH_biomass

Definition of indices
3:    Complete Increase
2.5:  Complete Increase Plus
2:    Partial Increase
1.5:  Partial Increase Plus
1:    Inclusive Increase
0:    Unchange
-1:   Inclusive Decrease
-1.5: Inclusive Decrease Minus
-2:   Partial Decrease
-2.5  Partial Decrease Minus
-3:   Complete Decrease
$Offtext

$offlisting
$offdigit

**** The user has to provide the following name --------------------------------
$setglobal modelName01 BL
$setglobal modelName02 AD
$setglobal modelName03 EC
$setglobal modelName04 CORDA
$setglobal modelName0 %modelName02%_%modelName03%_%modelName04%
$setglobal modelName1 %modelName01%-%modelName02%-%modelName03%
$setglobal modelName2 %modelName04%-R3D-CCU4-AD-TRIM63

$setglobal modelPath A0-Model-CABL-v2

* assign the path of the model data
$setglobal ModelData "C:\CBM-AD-ToolBox\%modelPath%\%modelName1%-%modelName2%\"

*$setglobal CandData "%ModelData%\Cand-Enz-Met-Rxn\"

* assign the path of the computational results
$setglobal ReportData "C:\CBM-AD-ToolBox\A0-ReportData\"
*-------------------------------------------------------------------------------

**** modelName3 = Default, LeakyFree (User's provided) -------------------------
$setglobal modelName3 LeakyFree

**** version for medium provided by a user *************************************
$setglobal User_Medium DMEM
$setglobal No_uptake 2
$setglobal No_secretion 1
$setglobal No_DM_sink 1
$setglobal No_uptake_demand 1

* ObjFunction_UFD evalution
* No_UFD_Obj = 1: One norm excluded exchange_rxn; = 2: One norm included exchange_rxn
* No_UFD_Obj = 3: Two norm excluded exchange_rxn; = 4: Two norm included exchange_rxn
$setglobal No_UFD_Obj 2

**** tolerance for CABL_mean and ratio(CA/BL) ***********************************
$setglobal tol_mean_eps 0
$setglobal tol_LFC_eps 0

* maximal points for evaluating differential expression
$setglobal NO_iterMax 800

* A usre estimated maximum No. of fuzzy objectives in A2 file for ObjectSet
$setglobal No_FObject 50

* random method
$setglobal NO_Method 4

* minimum value for random limit ratio [limit_raio_min, 1]
$setglobal limit_ratio_min 0.025

* P_two value threshold
$setglobal P_value_Threshold 0.05

* Pattern_level
$setglobal pattern_level 1

* biocompound class to print
* index_biocomp_class = 1: biocompound_class1 + 2 + 3 + 4
* index_biocomp_class = 2: biocompound_class5 + 6
* index_biocomp_class = 3: biocompound_class3 + 4 + 5 + 6
$setglobal index_Biocomp_class 3

* The user needs to provide the following 6 includeed files for solving this problem ****************************************************************
$include %ModelData%A1-%modelName1%-%modelName2%-Model.gms
$include %ModelData%A1-%modelName1%-%modelName2%-GPRmodel.gms
$include %ModelData%A1-%modelName1%-%modelName2%-Weight-Rxn.gms
$include %ModelData%A2-%modelName1%-%modelName2%-Fuzzy-MultiObj.gms
$include %ModelData%A3-%modelName1%-%modelName2%-%modelName3%-Flux-bounds.gms
$include %ModelData%A3-%modelName1%-%modelName2%-uptake-Subset.gms
$include %ModelData%A4-%modelName1%-%modelName2%-Biocompound.gms

$include %ModelData%A9-%modelName1%-%modelName2%-Species-Biocomp-ChokePt.gms

*---- prepare for writing the computational results ----------------------------
$set outputFilename1 z1-%modelName1%-%modelName2%-%modelName3%-FVA-Met-CAHT-%User_Medium%-%NO_Method%-UFD%No_UFD_Obj%
$set outputFilename2 z2-%modelName1%-%modelName2%-%modelName3%-FVA-rxn-CAHT-%User_Medium%-%NO_Method%-UFD%No_UFD_Obj%
$set outputFilename3 z3-%modelName1%-%modelName2%-%modelName3%-Print-Met-rxn-CAHT-%User_Medium%-%NO_Method%-UFD%No_UFD_Obj%
$set outputFilename4 z4-%modelName1%-%modelName2%-%modelName3%-FullSet-Met-CAHT-%User_Medium%-%NO_Method%-UFD%No_UFD_Obj%
$set outputFilename5 z5-%modelName1%-%modelName2%-%modelName3%-FullSet-rxn-CAHT-%User_Medium%-%NO_Method%-UFD%No_UFD_Obj%
$set outputFilename6 z6-%modelName01%-%modelName0%-%User_Medium%-Met-vfvb-pvalue-test
$set outputFilename7 %modelName01%-%modelName0%_%User_Medium%-Met-vfvb-pvalue
*--------------------------------------------------------------------------------

$onempty
sets
   itermax "Total points to evaluate obj_limit_ratio"
       /NP1*NP%NO_itermax%, NPI1*NPI%No_FObject%, NP_I, NP_F/
       
   NP(itermax) "number of random points for evaluating obj_limit_ratio"
       /NP1*NP%NO_itermax%/
       
   NPI(itermax) "number of corner points for evaluating obj_limit_ratio"
     /NPI1*NPI%No_FObject%/

   print_biocomp_pool(biocompound) "print a user assigned synthesis rates for biocomp_poot, e.g. exchange biocompounds"
    / /

   print_biocomp(biocompound) "print additional synthesis rates for biocompounds"
          /   /

   print_rxn_pool(reactions) "print a user assigned fluxes for rxn_pool"
         /  / 
        
   print_rxn(reactions) "print additional fluxes for reactions"
        /  /

   secretion_rxn(reactions) "secretion reactions"
   uptake_rxn(reactions) "uptake reactions"    
   BioComp_ExpWarb(biocompound) "sum of biocompound_exp and biocompound_Warburg"
   Regulated_rxn_v(reactions) "dynamic subset1 for itermax to indicate for regulating up/down vb/vf"

   dyn_reactions(reactions) "dynamic subsets to declare the reactions in HT/CA model"
   dyn_species(species) "dynamic subsets to declare the species in HT/CA model"
   dyn_Biocomp(Biocompound) "dynamic subsets to declare the biocompounds in HT/CA model"
   dyn_irrev_rxn(reactions) "dynamic subset for irrevsible reactions"
   dyn_rev_rxn(reactions) "dynamic subset for reversible reactions"
   dyn_exchange_rxn(reactions) "dynamic subset for exchange reactions"
   dyn_ObjectSet(objectSet) "dynamic subsets of ObjectSet"
   dyn_Fmax_Object(objectSet) "dynamic subsets of fuzzy max Objectives"  
   dyn_Fmin_Object(objectSet) "dynamic subsets of fuzzy min Objectives"
   dyn_priority_obj(ObjectSet) "dynamic subset of priority objectives"
   HT_itermax(itermax) "Total points to evaluate obj_limit_ratio for HT"
   CA_itermax(itermax) "Total points to evaluate obj_limit_ratio for CA"   
   dyn_NPI(itermax) "dynamic subset of number of corner points for evaluating obj_limit_ratio"
   BioCompound_pool(BioCompound) "Biocompounds pool defined on the model";   
$offempty

**** reset reversible and irrevserable reactions ****************************************************************************************************
rev_rxn(reactions) = rev_rxn(reactions) + irrev2rev_rxn(reactions) + irrev_vb_rxn(reactions) - rev2irrev_rxn(reactions);
irrev_rxn(reactions) = irrev_rxn(reactions) + rev2irrev_rxn(reactions) - irrev2rev_rxn(reactions);
*****************************************************************************************************************************************************
***** decide the Candidate_Enz_g1 by the user *******************************************************************************************************
uptake_rxn(reactions) $ (uptake_rxn_%User_Medium%(reactions)) = yes;

secretion_rxn(reactions) = exchange_rxn(reactions) - uptake_rxn(reactions) - uptake_demand(reactions) -
                           exchange_demand(reactions) - uptake_fixed(reactions) - secretion_demand(reactions);

**** define biocompound_pool(biocompound) to evaluate metabolite-flow rates *************************************************************************
$ontext
select intracellular, extracellular or both as a set of Candidate_Met_G2
 biocompound_class1: species participate in at least two intracellular compartments, but not included in the extracellular compartment
 biocompound_class2: species participate in the extracellular compartment, but also in other intracellular compartments
 biocompound_class3: species participate in the extracellular compartment only, but not existed in the intrcellular compartments
 biocompound_class4: species participate in a single intracellular compartment only, but not existed in the extracellular compartment
 biocompound_class5: metabolites participate in at least two intracellular compartments, but not existed in the extracellular compartment
 biocompound_class6: metabolites participate in the overall (intracellular and extracellular) compartments
 1: biocompound_class1+4; 2: biocompound_class2+3; biocompound_class1+2+3+4; 4: biocompound_class3+4+5+6; 5: the user's provided
$offtext
*biocompound_pool(biocompound) = biocompound_class1(biocompound) + biocompound_class2(biocompound) +
*                                biocompound_class3(biocompound) + biocompound_class4(biocompound) +
*                                biocompound_class5(biocompound) + biocompound_class6(biocompound);
                                
*biocompound_pool(biocompound) = biocompound_class2(biocompound) + biocompound_class3(biocompound) + biocompound_class4(biocompound) +
*                                biocompound_class5(biocompound) + biocompound_class6(biocompound);
*
*biocompound_pool(biocompound) = biocompound_class1(biocompound) + biocompound_class4(biocompound) + biocompound_class5(biocompound);
 
biocompound_pool(biocompound) $ (%index_biocomp_class% = 1) = biocompound_class1(biocompound) + biocompound_class2(biocompound) +
                                                              biocompound_class3(biocompound) + biocompound_class4(biocompound);
                                                              
biocompound_pool(biocompound) $ (%index_biocomp_class% = 2) = biocompound_class5(biocompound) + biocompound_class6(biocompound);

biocompound_pool(biocompound) $ (%index_biocomp_class% = 3) = biocompound_class3(biocompound) + biocompound_class4(biocompound) +
                                                              biocompound_class5(biocompound) + biocompound_class6(biocompound);
                                
BioComp_ExpWarb(biocompound) = biocompound_exp(biocompound) + biocompound_Warburg(biocompound);
*****************************************************************************************************************************************************

**** A user assigned biocomp_pool and rxn_pool to print out *****************************************************************************************
print_biocomp_pool(biocompound) = biocompound_pool(biocompound);

*print_rxn_pool(reactions) = uptake_rxn(reactions) + secretion_rxn(reactions);
print_rxn_pool(reactions) = exchange_rxn(reactions);

*print_rxn_pool(reactions) $ (not reactions_NCA(reactions)) = yes;
*****************************************************************************************************************************************************

print_biocomp(biocompound) = print_biocomp(biocompound) + print_biocomp_pool(biocompound);
print_rxn(reactions) = print_rxn(reactions) + print_rxn_pool(reactions);
*****************************************************************************************************************************************************

Parameters
*----- Weighting factor depends on RNA-seq expression having HC, MC, NC and others 
   Weight_factor_Rxn_HC "Weighting factor for rxn with high confidence" /0.25/
   Weight_factor_Rxn_MC "Weighting factor for rxn with medium confidence" /0.5/
   Weight_factor_Rxn_NC "Weighting factor for rxn with not detected" /0.75/
   Weight_factor_Rxn_OT "Weighting factor for rxn with others" /1/

   Weight_Lambda(ObjectSet) "Weighting factor for MemObjvalue_FBA"
   tol_eps "numerical tolerance" /1.0e-12/
   tol_mean "tolerance for mean_CAHT" /%tol_mean_eps%/
   tol_LFC "tolerence for log2(CA/HT)" /%tol_LFC_eps%/
   flag_uptake "irreversible (vf = 0); 2: reversible (exchange)" /%No_uptake%/
   flag_secretion "1: irreversible (vb = 0); 2: reversible (exchange)" /%No_secretion%/
   flag_DM_sink "1: set DM_sink_rxn to irrev_rxn; 2: keep orignal setting" /%No_DM_sink%/
   flag_uptake_demand "irreversible (vf = 0); 2: reversible (exchange)" /%No_uptake_demand%/
   flag_UFD_Obj "selection of UDF_Obj for UFD problem" /%No_UFD_Obj%/      
   flag_print "0: print similarity index only; 1: print all data" /0/
   RegStrength_param "regulation strength parameter for up/down regulation" /1/

   Method_random "random method" /%NO_Method%/
   startTime, number1, number2 "CPU time accounting indices"
   rand_C1(itermax, ObjectSet) "random number"
   rand_C2(itermax, ObjectSet) "random number"
   bestmem_XR(ObjectSet) "bestmem"
* random sampling points
   Obj_limit_ratio(iterMax, ObjectSet) "minimum ratio for optimizing objective of basal problem"   
   CA_Obj_limit_ratio(iterMax, ObjectSet) "minimum ratio for optimizing objective of CA"
   HT_Obj_limit_ratio(iterMax, ObjectSet) "minimum ratio for optimizing objective of HT"
   MultiObjValue_max(ObjectSet) "maximum objective values"
   MultiObjValue_min(ObjectSet) "minimum objective values"    
   FluxBound_vf_LB(reactions) "lower bound for each forward flux"
   FluxBound_vf_UB(reactions) "upper bound for each forward flux"
   FluxBound_vb_LB(reactions) "lower bound for each backward flux"
   FluxBound_vb_UB(reactions) "lower bound for each backward flux"
   MultiObj_Weight(ObjectSet) "Weight of cellular objectives"
   coef_CellularObj_vf(ObjectSet, reactions) "cellular objective coefficients for vf"
   coef_CellularObj_vb(ObjectSet, reactions) "cellular objective coefficients for vb"
   index_rxn(reactions) "index for each irreversible/reversible reaction"
   HT_index_Met(biocompound) "index of biocompound chokepoints for HT"
   CA_index_Met(biocompound) "index of biocompound chokepoints for CA"   
   MultiObjValue_min(ObjectSet) "minimum values for multiobjectives in inner and outer optimization problem"
   MultiObjValue_max(ObjectSet) "maximum values for multiobjectives in inner and outer optimization problem"
   HT_Index_Wt_rxn(reactions) "index of reactionss belongs to HC, MC, ND and others for HT cells"
   CA_Index_Wt_rxn(reactions) "index of reactionss belongs to HC, MC, ND and others for CA cells";   

*%%%%% solver options %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
options
* LPSolvers "LP solver option"
*     /BARON, BDMLP, CBC, CONOPT, CPLEX, CPLEXD, GUROBI, IPOPTH, KNITRO, LINDO, MINOS, SNOPT, XPRESS/
   LP = BARON

* QCPsolver "solver option"
*     /BARON, CONOPT, COUENNE, CPLEX, CPLEXD, GUROBI, IPOPTH, KNITRO, LINDO, MINOS, SCIP, SNOPT, XPRESS/
   QCP = BARON

* relative optimality criterion
   optcr = 1.0e-8

* To assign GAMS to be less disk active
*   solvelink = 5 
 
* maximum time available to solve in seconds
   reslim = 100000

* equations listed per block
   limrow = 0

* variables listed per block
   limcol = 0

* solver's solution output printed
   solprint = off

* solver's system output printed
   sysout = off;
*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


*%%%%% the user can modify the following procedures %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
* indicator for irreversible or reversible reactions
index_rxn(irrev_rxn) = 1;
index_rxn(rev_rxn) = 2;

* indicator for biocompound chokepoints; 1: biocomp_chokept_SISO; 2: biocomp_chokept_SIMO; 3: biocomp_chokept_MISO; 0: Orthers
HT_index_Met(biocompound) $ (biocomp_chokept_SISO(biocompound) and not biocompound_NHT(biocompound)) = 1;
HT_index_Met(biocompound) $ (biocomp_chokept_SIMO(biocompound) and not biocompound_NHT(biocompound)) = 2;
HT_index_Met(biocompound) $ (biocomp_chokept_MISO(biocompound) and not biocompound_NHT(biocompound)) = 3;
CA_index_Met(biocompound) $ (biocomp_chokept_SISO(biocompound) and not biocompound_NCA(biocompound)) = 1;
CA_index_Met(biocompound) $ (biocomp_chokept_SIMO(biocompound) and not biocompound_NCA(biocompound)) = 2;
CA_index_Met(biocompound) $ (biocomp_chokept_MISO(biocompound) and not biocompound_NCA(biocompound)) = 3;

* indecator for reactions 4: HC, 3: MC, 2:ND, 1: OT, 0: Not existed in CA/HT models *****************************************************************
**** Others reactions for HT cells  
HT_Index_Wt_rxn(reactions) = 1;
HT_Index_Wt_rxn(reactions) $ (HT_Reactions_NC(reactions)) = 2;
HT_Index_Wt_rxn(reactions) $ (HT_Reactions_MC(reactions)) = 3;
HT_Index_Wt_rxn(reactions) $ (HT_Reactions_HC(reactions)) = 4;
HT_Index_Wt_rxn(reactions) $ (reactions_NHT(reactions)) = 0;

**** Others reactions for CA cells  
CA_Index_Wt_rxn(reactions) = 1;
CA_Index_Wt_rxn(reactions) $ (CA_Reactions_NC(reactions)) = 2;
CA_Index_Wt_rxn(reactions) $ (CA_Reactions_MC(reactions)) = 3;
CA_Index_Wt_rxn(reactions) $ (CA_Reactions_HC(reactions)) = 4;
CA_Index_Wt_rxn(reactions) $ (reactions_NCA(reactions)) = 0;
*****************************************************************************************************************************************************

***** assign objective coefficient ******************************************************************************************************************
coef_CellularObj_vf(syn_vf_rxn(objectSet, reactions)) = 1;
coef_CellularObj_vb(syn_vb_rxn(objectSet, reactions)) = 1;

coef_CellularObj_vf(deg_vf_rxn(objectSet, reactions)) = -1;
coef_CellularObj_vb(deg_vb_rxn(objectSet, reactions)) = -1;
*****************************************************************************************************************************************************

*%%%%% assign the initial flux bounds from leaky dataset %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
FluxBound_vf_LB(reactions) = vf_initial_LB(reactions);
FluxBound_vb_LB(reactions) = vb_initial_LB(reactions);
FluxBound_vf_UB(reactions) = vf_initial_UB(reactions);
FluxBound_vb_UB(reactions) = vb_initial_UB(reactions);

***** assgin the upper bounds of irreversible reactions and backward irreversible reactions to be zero
FluxBound_vb_UB(reactions) $ (irrev_rxn(reactions)) = 0;
FluxBound_vf_LB(reactions) $ (irrev_vb_rxn(reactions)) = 0;
FluxBound_vf_UB(reactions) $ (irrev_vb_rxn(reactions)) = 0;
*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

***** set DM_sink_rxn secretion_rxn to irreversible reactions ******************
if(flag_DM_sink = 1,
   FluxBound_vf_LB(DM_sink_rxn) = vf_initial_LB(DM_sink_rxn);
   FluxBound_vf_UB(DM_sink_rxn) = vf_initial_UB(DM_sink_rxn);
   FluxBound_vb_LB(DM_sink_rxn) = 0;
   FluxBound_vb_UB(DM_sink_rxn) = 0;);

***** uptake_rxn assigns as irreversible reactions
if(flag_uptake = 1,
   FluxBound_vf_LB(uptake_rxn) = 0;
   FluxBound_vf_UB(uptake_rxn) = 0;
   FluxBound_vb_LB(uptake_rxn(reactions)) = vb_initial_LB(uptake_rxn);;
   FluxBound_vb_UB(uptake_rxn(reactions)) = vb_initial_UB(uptake_rxn););

***** uptake_rxn assigns as reversible (exchange) reactions
if(flag_uptake = 2,
   FluxBound_vf_LB(uptake_rxn) = vf_initial_LB(uptake_rxn);
   FluxBound_vf_UB(uptake_rxn) = vf_initial_UB(uptake_rxn);
   FluxBound_vb_LB(uptake_rxn(reactions)) = vb_initial_LB(uptake_rxn);
   FluxBound_vb_UB(uptake_rxn(reactions)) = vb_initial_UB(uptake_rxn););

***** secretion_rxn assigns as irreversible reactions
if(flag_secretion = 1,
   FluxBound_vf_LB(secretion_rxn) = vf_initial_LB(secretion_rxn);
   FluxBound_vf_UB(secretion_rxn) = vf_initial_UB(secretion_rxn);
   FluxBound_vb_LB(secretion_rxn) = 0;
   FluxBound_vb_UB(secretion_rxn) = 0;);

***** secretion_rxn assigns as reversible (exchange) reactions
if(flag_secretion = 2,
   FluxBound_vf_LB(secretion_rxn) = vf_initial_LB(secretion_rxn);
   FluxBound_vf_UB(secretion_rxn) = vf_initial_UB(secretion_rxn);
   FluxBound_vb_LB(secretion_rxn) = vb_initial_LB(secretion_rxn);
   FluxBound_vb_UB(secretion_rxn) = vb_initial_UB(secretion_rxn););
*****************************************************************************************************************************************************
FluxBound_vf_LB(exchange_demand) $ (card(exchange_demand) > 0) = vf_initial_LB(exchange_demand);
FluxBound_vf_UB(exchange_demand) $ (card(exchange_demand) > 0) = vf_initial_UB(exchange_demand);
FluxBound_vb_LB(exchange_demand) $ (card(exchange_demand) > 0) = vb_initial_LB(exchange_demand);
FluxBound_vb_UB(exchange_demand) $ (card(exchange_demand) > 0) = vb_DM_Exchange_UB(exchange_demand);

if(flag_uptake_demand = 1,
   FluxBound_vf_LB(uptake_demand) $ (card(uptake_demand) > 0) = 0;
   FluxBound_vf_UB(uptake_demand) $ (card(uptake_demand) > 0) = 0;);

if(flag_uptake_demand = 2,
   FluxBound_vf_LB(uptake_demand) $ (card(uptake_demand) > 0) = vf_initial_LB(uptake_demand);
   FluxBound_vf_UB(uptake_demand) $ (card(uptake_demand) > 0) = vf_initial_UB(uptake_demand););

FluxBound_vb_LB(uptake_demand) $ (card(uptake_demand) > 0) = vb_DM_uptake_LB(uptake_demand);
FluxBound_vb_UB(uptake_demand) $ (card(uptake_demand) > 0) = vb_DM_uptake_UB(uptake_demand);

FluxBound_vb_LB(secretion_demand) $ (card(secretion_demand) > 0) = 0;
FluxBound_vb_UB(secretion_demand) $ (card(secretion_demand) > 0) = 0;
*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

*----- MultiObjValue_min and multiObjValue_max are computed by a user provided vf_UB and vb_UB ------------------------------------------------------
MultiObjValue_min(ObjectSet) =  sum(reactions, coef_CellularObj_vf(ObjectSet, reactions) * MultiObjValue_vf_LB(reactions)) +
                                sum(reactions, coef_CellularObj_vb(ObjectSet, reactions) * MultiObjValue_vb_LB(reactions));
                                
MultiObjValue_max(ObjectSet) =  sum(reactions, coef_CellularObj_vf(ObjectSet, reactions) * MultiObjValue_vf_UB(reactions)) +
                                sum(reactions, coef_CellularObj_vb(ObjectSet, reactions) * MultiObjValue_vb_UB(reactions));

display MultiObjValue_min, MultiObjValue_max;
*****************************************************************************************************************************************************

Parameters
   count, number1, number2, i_loop "count number"
   startTime, endTime, elapsedTime "CPU time accounting indices"
   HT_MultiObjvalue_Optim(ObjectSet) "HT optimal objectives"   
   HT_Species_SynRate(iterMax, species) "healthy synthesis rate for each species"
   HT_BioComp_SynRate(iterMax, BioCompound) "healthy synthesis rate for each BioCompound"  
   HT_BioComp_SynRate_min(biocompound) "minimum HT synthesis rate for each biocompound"
   HT_BioComp_SynRate_max(biocompound) "maximum HT synthesis rate for each biocompound"
   HT_vf_FBA(reactions)  "HT FBA forward fluxes, vf_HT"
   HT_vb_FBA(reactions)  "HT FBA backward fluxes, vb_HT"
   HT_v_FBA(reactions)  "store HT FBA fluxes, v_FBA"      
   HT_vf_UFD(iterMax, reactions)  "healthy UFD forward fluxes"
   HT_vb_UFD(iterMax, reactions)  "healthy UFD backward fluxes"
   HT_v_UFD(iterMax, reactions)  "healthy UFD fluxes"
   HT_v_UFD_min(reactions) "minimum bound of interval HT vmin = smin(vf - vb) for each reaction"
   HT_v_UFD_max(reactions) "maximum bound of interval HT vmax = smax(vf - vb) for each reaction"
   HT_vf_UFD_min(reactions) "minimum bound of interval HT_vf for each reaction"
   HT_vf_UFD_max(reactions) "maximum bound of interval HT_vf for each reaction"
   HT_vb_UFD_min(reactions) "minimum bound of interval HT_vb for each reaction"
   HT_vb_UFD_max(reactions) "maximum bound of interval HT_vb for each reaction"   
   HT_FBA_ModelStat "healthy FBA Problem model state"
   HT_UFD_ModelStat(iterMax) "healthy UFD model stat"
   CA_MultiObjvalue_Optim(ObjectSet) "HT optimal objectives"      
   CA_Species_SynRate(iterMax, species) "healthy synthesis rate for each species"
   CA_BioComp_SynRate(iterMax, BioCompound) "healthy synthesis rate for each BioCompound"
   CA_BioComp_SynRate_min(biocompound) "minimum CA synthesis rate for each biocompound"
   CA_BioComp_SynRate_max(biocompound) "maximum CA synthesis rate for each biocompound"
   CA_vf_FBA(reactions)  "CA FBA forward fluxes, vf_CA"
   CA_vb_FBA(reactions)  "CA FBA backward fluxes, vb_CA"
   CA_v_FBA(reactions)  "store CA FBA fluxes, v_FBA"     
   CA_vf_UFD(iterMax, reactions)  "healthy UFD forward fluxes"
   CA_vb_UFD(iterMax, reactions)  "healthy UFD backward fluxes"
   CA_v_UFD(iterMax, reactions)  "healthy UFD fluxes"
   CA_v_UFD_min(reactions) "minimum bound of interval CA vmin = smin(vf - vb) for each reaction"
   CA_v_UFD_max(reactions) "maximum bound of interval CA vmax = smax(vf - vb) for each reaction"
   CA_vf_UFD_min(reactions) "minimum bound of interval CA_vf for each reaction"
   CA_vf_UFD_max(reactions) "maximum bound of interval CA_vf for each reaction"
   CA_vb_UFD_min(reactions) "minimum bound of interval CA_vb for each reaction"
   CA_vb_UFD_max(reactions) "maximum bound of interval CA_vb for each reaction"   
   CA_FBA_ModelStat "healthy FBA Problem model state"
   CA_UFD_ModelStat(iterMax) "healthy UFD model stat"
   target_limit_LB(targetSet) "limits for desired target forward reactions"
   target_limit_UB(targetSet) "limits for desired target forward reactions"
   Mem_Obj_FBA_limit(ObjectSet) "limits of multiobjectives for UFD problem"
   Mem_Obj_FBA_Optim(ObjectSet) "Optimal fuzzy multiobjectives for FBA problem"   
   basal_vf(reactions) "basal vf used for computing CA/HT/PH model"
   basal_vb(reactions) "basal vb used for computing CA/HT/PH model"
   Weight_coef_rxn(reactions) "Weighting coefficients of rxn for computing objective in UFD"
   NO_priority_obj "number of priority_objective functions"
   CAHT_BioComp_Pattern(biocompound) "biocomp_Synrate pattern between interval CA and HT"
   CAHT_v_Pattern(reactions) "flux pattern between interval vnet for CA and HT"
   CAHT_vf_Pattern(reactions) "flux pattern between interval vf for CA and HT"
   CAHT_vb_Pattern(reactions) "flux pattern between interval vb for CA and HT"      
   ratio_Met_SynRate_CAHT_min(biocompound) "minimum CA/HT synthesis rate for each biocompound"
   ratio_Met_SynRate_CAHT_max(biocompound) "maximum CA/HT synthesis rate for each biocompound"
   ratio_vf_CAHT_min(reactions) "minimum CA/HT of interval CA_vf and HT_vf for each reaction"
   ratio_vf_CAHT_max(reactions) "maximum CA/HT of interval CA_vf and HT_vf for each reaction"
   ratio_vb_CAHT_min(reactions) "minimum CA/HT of interval CA_vb and HT_vb for each reaction"
   ratio_vb_CAHT_max(reactions) "maximum CA/HT of interval CA_vb and HT_vb for each reaction"   
   ratio_v_CAHT_min(reactions) "minimum CA/HT of interval CA_vnet and HT_vnet for each reaction"
   ratio_v_CAHT_max(reactions) "maximum CA/HT of interval CA_vnet and HT_vnet for each reaction"
   mean_HT_BioComp_SynRate(BioCompound) "mean of HT_BioComp_SynRate"
   SDev_HT_Biocomp_SynRate(Biocompound) "standard deviation of HT_BioComp_SynRate"
   CICD_HT_BioComp_Synrate(Biocompound) "CICD = (Max - min)/(Max + min)"
   mean_CA_BioComp_SynRate(BioCompound) "mean of CA_BioComp_SynRate"
   mean_CAHT_BioComp(BioCompound) "mean of CA + HT BioComp_SynRate"   
   SDev_CA_Biocomp_SynRate(Biocompound) "standard deviation of CA_BioComp_SynRate"
   CICD_CA_BioComp_Synrate(Biocompound) "CICD = (Max - min)/(Max + min)"   
   mean_HT_v_UFD(reactions)  "mean of HT_v_UFD"
   mean_CA_v_UFD(reactions)  "mean of CA_v_UFD"
   mean_HT_vf_UFD(reactions)  "mean of HT_vf_UFD"
   mean_CA_vf_UFD(reactions)  "mean of CA_vf_UFD"
   mean_HT_vb_UFD(reactions)  "mean of HT_vb_UFD"
   mean_CA_vb_UFD(reactions)  "mean of CA_vb_UFD"   
   mean_CAHT_v_UFD(reactions)  "mean of CA_v_UFD + HT_v_UFD"
   mean_CAHT_vf_UFD(reactions)  "mean of CA_vf_UFD + HT_vf_UFD"
   mean_CAHT_vb_UFD(reactions)  "mean of CA_vb_UFD + HT_vb_UFD"    
   SDev_HT_v_UFD(reactions)  "standary deviation of HT_v_UFD"
   SDev_CA_v_UFD(reactions)  "standary deviation of CA_v_UFD"
   SDev_HT_vf_UFD(reactions)  "standary deviation of HT_vf_UFD"
   SDev_CA_vf_UFD(reactions)  "standary deviation of CA_vf_UFD"
   SDev_HT_vb_UFD(reactions)  "standary deviation of HT_vb_UFD"
   SDev_CA_vb_UFD(reactions)  "standary deviation of CA_vb_UFD"   
   CICD_HT_v_UFD(reactions) "CICD = (Max - min)/(Max + min): CICD < 0 or > 1: Max < 0 and Min < 0)"
   CICD_CA_v_UFD(reactions) "CICD = (Max - min)/(Max + min): CICD < 0 or > 1: Max < 0 and Min < 0)"
   CICD_HT_vf_UFD(reactions) "CICD = (Max - min)/(Max + min): CICD < 0 or > 1: Max < 0 and Min < 0)"
   CICD_CA_vf_UFD(reactions) "CICD = (Max - min)/(Max + min): CICD < 0 or > 1: Max < 0 and Min < 0)"
   CICD_HT_vb_UFD(reactions) "CICD = (Max - min)/(Max + min): CICD < 0 or > 1: Max < 0 and Min < 0)"
   CICD_CA_vb_UFD(reactions) "CICD = (Max - min)/(Max + min): CICD < 0 or > 1: Max < 0 and Min < 0)"      
   log2_Met_CAHT_mean(Biocompound) "log2(CA/HT) of BioComp_SynRate"
   log2_v_mean_CAHT(reactions) "log2(CA/HT)_mean of vf"      
   log2_vf_mean_CAHT(reactions) "log2(CA/HT)_mean of vf"   
   log2_vb_mean_CAHT(reactions) "log2(CA/HT)_mean of vb"    
   ratio_v_CAHT_mean(reactions) "ratio of CA/HT for net fluxes";     

*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
free Variables
   ObjValue_FBA "Cellular objective for basal FBA problem"
   S_ObjValue_FBA "single objective for basal FBA problem"   
   ObjValue_UFD "sum of squre fluxes for determining Uniformed flux distribution";

positive variables
   MultiObjvalue_FBA(ObjectSet) "multi-cellular objectives for FBA problem"
   Mem_Objvalue_FBA(objectSet) "membership objective functiona for FBA problem"
   Lambda "equivalent min value"
   vf(reactions)  "forward fluxes"
   vb(reactions) "backward fluxes";

equations
   dxdt(species) "material balance equations for the metabolic networks"
   ObjFunction_FBA "cellular objective for FBA problem"
   S_ObjFunction_FBA "Single objective for FBA problem"    
   Mem_FuzzyMax_Obj_FBA(objectSet) "Membership grade for fuzzy max objectives for FBA problem"
   Mem_FuzzyMin_Obj_FBA(objectSet) "Membership grade for fuzzy min objectives for FBA problem"   
   MultiObjFunction_FBA(ObjectSet) "multi-cellular objectives for basal FBA problem"
   ObjFunction_UFD1 "One norm excluded exhange_rxn for UFD problem"
   ObjFunction_UFD2 "One norm included exhange_rxn for UFD problem"
   ObjFunction_UFD3 "Two norm excluded exhange_rxn for UFD problem"
   ObjFunction_UFD4 "Two norm included exhange_rxn for UFD problem"   
   InEqual_MemObjvalue_FBA(objectSet)"inequality constraints for equivalent FBA problem"
   InEqual_ObjFTN_UFD(ObjectSet) "inequality constraint of the optimal cellular objective for the basal FBA"
   Inequal_target_LB(targetSet) "limits for desired target forward reactions"
   Inequal_target_UB(targetSet) "limits for desired target2 forward reactions";

* flux balance model
dxdt(dyn_species)..
   sum(dyn_reactions, S_matrix(dyn_species, dyn_reactions) * (vf(dyn_reactions) - vb(dyn_reactions))) =e= 0.0;

* lower bound for target reactions
Inequal_target_LB(targetSet)..
   target_limit_LB(targetSet) =l= vf(targetSet) - vb(targetSet);

* upper bound for target reactions
Inequal_target_UB(targetSet)..
   vf(targetSet) - vb(targetSet) =l= target_limit_UB(targetSet);

* multi-objective function values
MultiObjFunction_FBA(dyn_ObjectSet)..
   MultiObjValue_FBA(dyn_ObjectSet) =e= sum(dyn_reactions, coef_CellularObj_vf(dyn_ObjectSet, dyn_reactions) * vf(dyn_reactions)) +
                                        sum(dyn_reactions, coef_CellularObj_vb(dyn_ObjectSet, dyn_reactions) * vb(dyn_reactions));

* membership for fuzzy max objective Functions
Mem_FuzzyMax_Obj_FBA(dyn_Fmax_Object)..
   mem_objvalue_FBA(dyn_Fmax_Object) =e= (MultiObjValue_FBA(dyn_Fmax_Object) - MultiObjValue_min(dyn_Fmax_Object))/
                                         (MultiObjValue_max(dyn_Fmax_Object) - MultiObjValue_min(dyn_Fmax_Object));
                                          
* membership for fuzzy max objective Functions
Mem_FuzzyMin_Obj_FBA(dyn_Fmin_Object)..
   mem_objvalue_FBA(dyn_Fmin_Object) =e= (MultiObjValue_max(dyn_Fmin_Object) - MultiObjValue_FBA(dyn_Fmin_Object))/
                                         (MultiObjValue_max(dyn_Fmin_Object) - MultiObjValue_min(dyn_Fmin_Object));

* single objective function for FBA problem
S_ObjFunction_FBA..
  S_ObjValue_FBA =e= sum(dyn_ObjectSet, MultiObjValue_FBA(dyn_ObjectSet)); 

* objective function for FBA problem
ObjFunction_FBA..
   ObjValue_FBA =e= 0.5 * (sum(dyn_ObjectSet $ (dyn_priority_obj(dyn_ObjectSet)),
                               mem_objvalue_FBA(dyn_ObjectSet))/NO_priority_obj + Lambda);
   
* inequality constraints for equivalent FBA problem
InEqual_MemObjvalue_FBA(dyn_objectSet)..
   Lambda =l= weight_Lambda(dyn_ObjectSet) * mem_objvalue_FBA(dyn_ObjectSet);

* objective for determining the Uniformed flux distribution: One Norm parsimonious flux balance analysis
ObjFunction_UFD1..
   ObjValue_UFD =e= sum(dyn_reactions $ (not exchange_rxn(dyn_reactions)),
                        weight_coef_rxn(dyn_reactions) * (vf(dyn_reactions) + vb(dyn_reactions)));
                        
ObjFunction_UFD2..
   ObjValue_UFD =e= sum(dyn_reactions,
                        weight_coef_rxn(dyn_reactions) * (vf(dyn_reactions) + vb(dyn_reactions)));
                        
* objective for determining the Uniformed flux distribution: One Norm parsimonious flux balance analysis
ObjFunction_UFD3..                       
   ObjValue_UFD =e= sum(dyn_reactions $ (not exchange_rxn(dyn_reactions)), weight_coef_rxn(dyn_reactions) *
                                        (sqr(vf(dyn_reactions)) + sqr(vb(dyn_reactions))));
                                        
* objective for determining the Uniformed flux distribution: One Norm parsimonious flux balance analysis
ObjFunction_UFD4..                       
   ObjValue_UFD =e= sum(dyn_reactions, weight_coef_rxn(dyn_reactions) *
                                        (sqr(vf(dyn_reactions)) + sqr(vb(dyn_reactions))));

                        
* inequality constraint to obtain the identical optimal cellular objective value
InEqual_ObjFTN_UFD(dyn_ObjectSet)..
   mem_objvalue_FBA(dyn_ObjectSet) =g= Weight_Lambda(dyn_ObjectSet) * Mem_Obj_FBA_limit(dyn_ObjectSet);

model
   Single_FBA_Problem
      /dxdt, Inequal_target_LB, Inequal_target_UB, MultiObjFunction_FBA, S_ObjFunction_FBA/;

model
   FBA_Problem
      /dxdt, Inequal_target_LB, Inequal_target_UB, MultiObjFunction_FBA, Mem_FuzzyMax_Obj_FBA, Mem_FuzzyMin_Obj_FBA,
       InEqual_MemObjvalue_FBA, ObjFunction_FBA/;

model
   UFD1_Problem
     /dxdt, Inequal_target_LB, Inequal_target_UB, MultiObjFunction_FBA,  Mem_FuzzyMax_Obj_FBA, Mem_FuzzyMin_Obj_FBA,
      InEqual_ObjFTN_UFD, ObjFunction_UFD1/;
      
model
   UFD2_Problem
     /dxdt, Inequal_target_LB, Inequal_target_UB, MultiObjFunction_FBA,  Mem_FuzzyMax_Obj_FBA, Mem_FuzzyMin_Obj_FBA,
      InEqual_ObjFTN_UFD, ObjFunction_UFD2/;
      
model
   UFD3_Problem
     /dxdt, Inequal_target_LB, Inequal_target_UB, MultiObjFunction_FBA,  Mem_FuzzyMax_Obj_FBA, Mem_FuzzyMin_Obj_FBA,
      InEqual_ObjFTN_UFD, ObjFunction_UFD3/;
      
model
   UFD4_Problem
     /dxdt, Inequal_target_LB, Inequal_target_UB, MultiObjFunction_FBA,  Mem_FuzzyMax_Obj_FBA, Mem_FuzzyMin_Obj_FBA,
      InEqual_ObjFTN_UFD, ObjFunction_UFD4/; 
*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

***** Fuzzy multiobjective HT FBA Problem ***********************************************************************************************************
dyn_reactions(reactions) = no;
dyn_species(species) = no;
dyn_Biocomp(biocompound) = no;
dyn_irrev_rxn(reactions) = no;
dyn_rev_rxn(reactions) = no;
dyn_exchange_rxn(reactions) = no;
dyn_objectSet(objectSet) = no;
dyn_Fmax_Object(ObjectSet) = no;
dyn_Fmin_Object(ObjectSet) = no;
dyn_priority_obj(ObjectSet) = no;
dyn_NPI(itermax) = no;

dyn_reactions(reactions) $ (not reactions_NHT(reactions)) = yes;
dyn_species(species) $ (not species_NHT(species)) = yes;
dyn_Biocomp(biocompound) $ (not biocompound_NHT(biocompound)) = yes;
dyn_irrev_rxn(reactions) $ (not reactions_NHT(reactions) and irrev_rxn(reactions)) = yes;
dyn_rev_rxn(reactions) $ (not reactions_NHT(reactions) and rev_rxn(reactions)) = yes;
dyn_exchange_rxn(reactions) $ (not reactions_NHT(reactions) and exchange_rxn(reactions)) = yes;
dyn_Fmax_Object(ObjectSet) $ (FmaxObj_inner_HT(ObjectSet)) = yes;
dyn_Fmin_Object(ObjectSet) $ (FminObj_inner_HT(ObjectSet)) = yes;
dyn_objectSet(objectSet) = dyn_Fmax_Object(ObjectSet) + dyn_Fmin_Object(ObjectSet);
dyn_priority_obj(ObjectSet) $ (PriObj_inner_HT(ObjectSet)) = yes;
No_priority_obj = card(dyn_priority_obj);

*%%%%% initialization of Obj_limit_ratio(iterMax, ObjectSet) %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
*----- read and write the seed for the random number generator -----------------
startTime = jnow;
execseed = 1 + gmillisec(jnow);

loop(NPI $ (ord(NPI) <= card(dyn_objectSet)), dyn_NPI(NPI) = yes;);
  
HT_itermax(itermax) = NP(itermax) + dyn_NPI(itermax);
HT_itermax('NP_I') = yes;
HT_itermax('NP_F') = yes;
   
*----- initialize a population of candidate individuals ------------------------
if(Method_random = 1,
   loop(NP, Obj_limit_ratio(NP, dyn_objectSet) = uniform(%limit_ratio_min%, 1);););

if(Method_random = 2,   
   loop(dyn_objectSet, Obj_limit_ratio(NP, dyn_objectSet) = uniform(0%limit_ratio_min%, 1);););

if(Method_random = 3,
   Obj_limit_ratio(NP, dyn_objectSet) = uniform(%limit_ratio_min%, 1););

if(Method_random = 4,
*   bestmem_XR(dyn_objectSet) = uniform(%limit_ratio_min%, 1);
   bestmem_XR(dyn_objectSet) = (1 + %limit_ratio_min%)/2;
   rand_C1(NP, dyn_objectSet) = uniform(0, 1);
   rand_C2(NP, dyn_objectSet) = uniform(0, 1);
   Obj_limit_ratio(NP, dyn_objectSet) $ (rand_C1(NP, dyn_objectSet) < bestmem_XR(dyn_objectSet)) =
                                             bestmem_XR(dyn_objectSet) - rand_C2(NP, dyn_objectSet) * bestmem_XR(dyn_objectSet);
   Obj_limit_ratio(NP, dyn_objectSet) $ (rand_C1(NP, dyn_objectSet) >= bestmem_XR(dyn_objectSet)) =
                                             bestmem_XR(dyn_objectSet) + rand_C2(NP, dyn_objectSet) * (1 - bestmem_XR(dyn_objectSet)););

* assign obj_limit_ratio at initial and final points
number1 = 1; 
loop(dyn_NPI, number2 = 1;
     loop(dyn_objectSet, Obj_limit_ratio(dyn_NPI, dyn_objectSet) $ (number1 = number2) = 1; number2 = number2 + 1;); number1 = number1 + 1;);

Obj_limit_ratio('NP_I', dyn_objectSet) = %limit_ratio_min%;
Obj_limit_ratio('NP_F', dyn_objectSet) = 1;
*----- end of initialization ---------------------------------------------------
HT_Obj_limit_ratio(HT_itermax, dyn_ObjectSet) = Obj_limit_ratio(HT_itermax, dyn_ObjectSet);
*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

*---- restrictions for the lower and upper bounds of fluxes --------------------
vf.lo(dyn_reactions) = FluxBound_vf_LB(dyn_reactions);
vf.up(dyn_reactions) = FluxBound_vf_UB(dyn_reactions);
vb.lo(dyn_reactions) = FluxBound_vb_LB(dyn_reactions);
vb.up(dyn_reactions) = FluxBound_vb_UB(dyn_reactions);

* assign vb = 0 for the irreversible fluxes
vb.lo(irrev_rxn) = 0;
vb.up(irrev_rxn) = 0;
vb.fx(irrev_rxn) = 0;
vb.lo(DM_sink_rxn(reactions)) $ (flag_DM_sink = 1) = 0;
vb.up(DM_sink_rxn(reactions)) $ (flag_DM_sink = 1) = 0;
vb.fx(DM_sink_rxn(reactions)) $ (flag_DM_sink = 1) = 0;
vf.lo(irrev_vb_rxn(reactions)) = 0;
vf.up(irrev_vb_rxn(reactions)) = 0;
vf.fx(irrev_vb_rxn(reactions)) = 0;

* assign the demanded uptake/secretion reactions
vf.fx(uptake_demand) = 0;
vb.fx(secretion_demand) = 0;
vb.fx(uptake_fixed) = FluxBound_vb_LB(uptake_fixed);

* irreversible uptake_rxn and secretion_rxn
vf.fx(uptake_rxn(dyn_reactions)) $ (flag_uptake = 1) = 0;
vb.fx(secretion_rxn(dyn_reactions)) $ (flag_secretion = 1) = 0;
vf.fx(uptake_demand(dyn_reactions)) $ (card(uptake_demand) > 0) = 0;
vb.fx(secretion_demand(dyn_reactions)) $ (card(secretion_demand) > 0) = 0;
********************************************************************************

*** Assign vf > 0 and vb = 0 for the Specific_rxn_vf --------------------------------
if(card(HT_Specific_rxn_vf) > 0,
   vf.lo(HT_Specific_rxn_vf) =  HT_Specific_rxn_vf_LB(HT_Specific_rxn_vf);
   vf.up(HT_Specific_rxn_vf) =  HT_Specific_rxn_vf_UB(HT_Specific_rxn_vf);
   vb.lo(HT_Specific_rxn_vf) =  0;
   vb.up(HT_Specific_rxn_vf) =  0;
   vb.fx(HT_Specific_rxn_vf) =  0;);
********************************************************************************
*** Assign vf = 0 and vb > 0 for the Specific_rxn_vb --------------------------------
if(card(HT_Specific_rxn_vb) > 0,
   vb.lo(HT_Specific_rxn_vb) =  HT_Specific_rxn_vb_LB(HT_Specific_rxn_vb);
   vb.up(HT_Specific_rxn_vb) =  HT_Specific_rxn_vb_UB(HT_Specific_rxn_vb);
   vf.lo(HT_Specific_rxn_vb) =  0;
   vf.up(HT_Specific_rxn_vb) =  0;
   vf.fx(HT_Specific_rxn_vb) =  0;);
 
*** Assign vf > 0 and vb > 0 for the Specific_rxn_vfvb -------------------------------
if(card(HT_Specific_rxn_vfvb) > 0,
   vf.lo(HT_Specific_rxn_vfvb) =  HT_Specific_rxn_vf_LB(HT_Specific_rxn_vfvb);
   vf.up(HT_Specific_rxn_vfvb) =  HT_Specific_rxn_vf_UB(HT_Specific_rxn_vfvb);
   vb.lo(HT_Specific_rxn_vfvb) =  HT_Specific_rxn_vb_LB(HT_Specific_rxn_vfvb);
   vb.up(HT_Specific_rxn_vfvb) =  HT_Specific_rxn_vb_UB(HT_Specific_rxn_vfvb););    
******************************************************************************* 

*----- compute the lower and upper bounds for the target reactions
target_limit_LB(targetSet) = 0;
target_limit_UB(targetSet) = 0;
target_limit_LB(targetSet) = HT_target_level_LB(targetSet);
target_limit_UB(targetSet) = HT_target_level_UB(targetSet);
MultiObjValue_FBA.lo(ObjectSet) = MultiObjValue_min(objectSet);
MultiObjValue_FBA.up(ObjectSet) = MultiObjValue_max(objectSet);
mem_objvalue_FBA.lo(objectSet) = 0;
mem_objvalue_FBA.up(objectSet) = 1;
Lambda.lo = 0;
Lambda.up = 1;
*-------------------------------------------------------------------------------

* set Weightin factor for mee_objvalue_FBA for HT ------------------------------
Weight_Lambda(ObjectSet) = 0;
Weight_Lambda(ObjectSet) = HT_Weight_mem_obj_FBA(ObjectSet);
*-------------------------------------------------------------------------------

* Determine the normal flux distribution by solving the Primal FBA Problem
solve FBA_Problem using LP maximizing objValue_FBA;
HT_vf_FBA(dyn_reactions) = max(vf.l(dyn_reactions), 0);
HT_vb_FBA(dyn_reactions) = max(vb.l(dyn_reactions), 0);
HT_v_FBA(dyn_reactions) = HT_vf_FBA(dyn_reactions) - HT_vb_FBA(dyn_reactions);
HT_MultiObjvalue_Optim(Objectset) = 0;
HT_MultiObjvalue_Optim(dyn_objectset) = sum(dyn_reactions, coef_CellularObj_vf(dyn_objectset, dyn_reactions) * HT_vf_FBA(dyn_reactions)) +
                                        sum(dyn_reactions, coef_CellularObj_vb(dyn_objectset, dyn_reactions) * HT_vb_FBA(dyn_reactions));
HT_FBA_ModelStat = FBA_Problem.modelstat ;

**** assign Weighting coefficients for Rxn for computing ObjValue in UFD ****************************************************************************
Weight_coef_rxn(reactions) = Weight_factor_Rxn_OT;
Weight_coef_rxn(reactions) $ (HT_Reactions_HC(reactions)) = Weight_factor_Rxn_HC;
Weight_coef_rxn(reactions) $ (HT_Reactions_MC(reactions)) = Weight_factor_Rxn_MC;
Weight_coef_rxn(reactions) $ (HT_Reactions_NC(reactions)) = Weight_factor_Rxn_NC;
*****************************************************************************************************************************************************
* limit for membership functions in inner UFD problem *************************
Mem_Obj_FBA_Optim(ObjectSet) = 0;
Mem_Obj_FBA_Optim(dyn_Fmax_Object) = ((HT_MultiObjvalue_Optim(dyn_Fmax_Object) - MultiObjValue_min(dyn_Fmax_Object))/
                                      (MultiObjValue_max(dyn_Fmax_Object) - MultiObjValue_min(dyn_Fmax_Object)));
                                        
Mem_Obj_FBA_Optim(dyn_Fmin_Object) = ((MultiObjValue_max(dyn_Fmin_Object) - HT_MultiObjvalue_Optim(dyn_Fmin_Object))/
                                      (MultiObjValue_max(dyn_Fmin_Object) - MultiObjValue_min(dyn_Fmin_Object)));
Mem_Obj_FBA_Optim(dyn_ObjectSet) = max(min( Mem_Obj_FBA_Optim(dyn_ObjectSet), 1), 0);                                      
*******************************************************************************
***** HT UFD problem ********************************************************************************************************************************
loop(HT_itermax,
*---- restrictions for the lower and upper bounds of fluxes --------------------
     vf.lo(reactions) = FluxBound_vf_LB(reactions);
     vf.up(reactions) = FluxBound_vf_UB(reactions);
     vb.lo(reactions) = FluxBound_vb_LB(reactions);
     vb.up(reactions) = FluxBound_vb_UB(reactions);

* assign vb = 0 for the irreversible fluxes
     vb.lo(irrev_rxn) = 0;
     vb.up(irrev_rxn) = 0;
     vb.fx(irrev_rxn) = 0;
     vb.lo(DM_sink_rxn(reactions)) $ (flag_DM_sink = 1) = 0;
     vb.up(DM_sink_rxn(reactions)) $ (flag_DM_sink = 1) = 0;
     vb.fx(DM_sink_rxn(reactions)) $ (flag_DM_sink = 1) = 0;
     vf.lo(irrev_vb_rxn(reactions)) = 0;
     vf.up(irrev_vb_rxn(reactions)) = 0;
     vf.fx(irrev_vb_rxn(reactions)) = 0;

* assign the demanded uptake/secretion reactions
     vf.fx(uptake_demand) = 0;
     vb.fx(secretion_demand) = 0;
     vb.fx(uptake_fixed) = FluxBound_vb_LB(uptake_fixed);

* irreversible uptake_rxn and secretion_rxn
     vf.fx(uptake_rxn(reactions)) $ (flag_uptake = 1) = 0;
     vb.fx(secretion_rxn(reactions)) $ (flag_secretion = 1) = 0;
     vf.fx(uptake_demand(reactions)) $ (card(uptake_demand) > 0) = 0;
     vb.fx(secretion_demand(reactions)) $ (card(secretion_demand) > 0) = 0;
********************************************************************************
*** Assign vf > 0 and vb = 0 for the Specific_rxn_vf --------------------------------
     if(card(HT_Specific_rxn_vf) > 0,
        vf.lo(HT_Specific_rxn_vf) =  HT_Specific_rxn_vf_LB(HT_Specific_rxn_vf);
        vf.up(HT_Specific_rxn_vf) =  HT_Specific_rxn_vf_UB(HT_Specific_rxn_vf);
        vb.lo(HT_Specific_rxn_vf) =  0;
        vb.up(HT_Specific_rxn_vf) =  0;
        vb.fx(HT_Specific_rxn_vf) =  0;);
********************************************************************************
*** Assign vf = 0 and vb > 0 for the Specific_rxn_vb --------------------------------
     if(card(HT_Specific_rxn_vb) > 0,
        vb.lo(HT_Specific_rxn_vb) =  HT_Specific_rxn_vb_LB(HT_Specific_rxn_vb);
        vb.up(HT_Specific_rxn_vb) =  HT_Specific_rxn_vb_UB(HT_Specific_rxn_vb);
        vf.lo(HT_Specific_rxn_vb) =  0;
        vf.up(HT_Specific_rxn_vb) =  0;
        vf.fx(HT_Specific_rxn_vb) =  0;);
 
*** Assign vf > 0 and vb > 0 for the Specific_rxn_vfvb -------------------------------
     if(card(HT_Specific_rxn_vfvb) > 0,
        vf.lo(HT_Specific_rxn_vfvb) =  HT_Specific_rxn_vf_LB(HT_Specific_rxn_vfvb);
        vf.up(HT_Specific_rxn_vfvb) =  HT_Specific_rxn_vf_UB(HT_Specific_rxn_vfvb);
        vb.lo(HT_Specific_rxn_vfvb) =  HT_Specific_rxn_vb_LB(HT_Specific_rxn_vfvb);
        vb.up(HT_Specific_rxn_vfvb) =  HT_Specific_rxn_vb_UB(HT_Specific_rxn_vfvb););    
******************************************************************************* 

     Mem_Obj_FBA_limit(dyn_ObjectSet) = HT_Obj_limit_ratio(HT_itermax, dyn_ObjectSet) * Mem_Obj_FBA_Optim(dyn_ObjectSet);    
     HT_vf_UFD(HT_iterMax, reactions) = 0;
     HT_vb_UFD(HT_iterMax, reactions) = 0;
     HT_v_UFD(HT_iterMax, reactions) = 0;
     
     if(flag_UFD_Obj = 1, solve UFD1_Problem using LP minimizing ObjValue_UFD;);
     if(flag_UFD_Obj = 2, solve UFD2_Problem using LP minimizing ObjValue_UFD;);
     if(flag_UFD_Obj = 3, solve UFD3_Problem using QCP minimizing ObjValue_UFD;);
     if(flag_UFD_Obj = 4, solve UFD4_Problem using QCP minimizing ObjValue_UFD;);
     HT_vf_UFD(HT_iterMax, dyn_reactions) = max(vf.l(dyn_reactions), 0);
     HT_vb_UFD(HT_iterMax, dyn_reactions) = max(vb.l(dyn_reactions), 0);
*     HT_vf_UFD(HT_iterMax, dyn_rev_rxn) = max(vf.l(dyn_rev_rxn), 0);
*     HT_vb_UFD(HT_iterMax, dyn_irrev_rxn) = max(vb.l(dyn_irrev_rxn), 0);
     

     HT_v_UFD(HT_iterMax, dyn_reactions) = HT_vf_UFD(HT_iterMax, dyn_reactions) - HT_vb_UFD(HT_iterMax, dyn_reactions);
     HT_UFD_ModelStat(HT_iterMax) = UFD%No_UFD_Obj%_Problem.modelstat;
);
*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
* compute synthesis rate and degradation rate for each species at the normal state
HT_Species_SynRate(iterMax, species) = 0;
loop(dyn_species,
     HT_Species_SynRate(HT_iterMax, dyn_species) = sum(dyn_reactions, S_Matrix(dyn_species, dyn_reactions) $
                                                    (S_Matrix(dyn_species, dyn_reactions) > 0) * HT_vf_UFD(HT_iterMax, dyn_reactions)) -
                                                 sum(dyn_reactions, S_Matrix(dyn_species, dyn_reactions) $
                                                    (S_Matrix(dyn_species, dyn_reactions) < 0) * HT_vb_UFD(HT_iterMax, dyn_reactions)););

* compute synthesis rate and degradation rate for each biocompound at the normal state
HT_BioComp_SynRate(iterMax, BioCompound) = 0;
loop(dyn_BioComp,
     HT_BioComp_SynRate(HT_iterMax, dyn_BioComp) = sum(dyn_species $ (BioCompound_species(dyn_BioComp, dyn_species)),
                                                     HT_Species_SynRate(HT_iterMax, dyn_species)););
                                                     
* minimum and maximum Biocomp_synthesis rate, vf, vb
HT_BioComp_SynRate_min(dyn_BioComp) = smin(HT_iterMax, HT_BioComp_SynRate(HT_iterMax, dyn_BioComp));
HT_BioComp_SynRate_max(dyn_BioComp) = smax(HT_iterMax, HT_BioComp_SynRate(HT_iterMax, dyn_BioComp));

HT_v_UFD_min(dyn_reactions) = smin(HT_iterMax, HT_v_UFD(HT_iterMax, dyn_reactions));
HT_v_UFD_max(dyn_reactions) = smax(HT_iterMax, HT_v_UFD(HT_iterMax, dyn_reactions));
HT_vf_UFD_min(dyn_reactions) = smin(HT_iterMax, HT_vf_UFD(HT_iterMax, dyn_reactions));
HT_vf_UFD_max(dyn_reactions) = smax(HT_iterMax, HT_vf_UFD(HT_iterMax, dyn_reactions));
HT_vb_UFD_min(dyn_reactions) = smin(HT_iterMax, HT_vb_UFD(HT_iterMax, dyn_reactions));
HT_vb_UFD_max(dyn_reactions) = smax(HT_iterMax, HT_vb_UFD(HT_iterMax, dyn_reactions));
*****************************************************************************************************************************************************
*****************************************************************************************************************************************************
CICD_HT_v_UFD(dyn_reactions) = (HT_v_UFD_max(dyn_reactions) - HT_v_UFD_min(dyn_reactions))/
                               (HT_v_UFD_max(dyn_reactions) + HT_v_UFD_min(dyn_reactions) + tol_eps);
                               
CICD_HT_vf_UFD(dyn_reactions) = (HT_vf_UFD_max(dyn_reactions) - HT_vf_UFD_min(dyn_reactions))/
                                (HT_vf_UFD_max(dyn_reactions) + HT_vf_UFD_min(dyn_reactions) + tol_eps);
CICD_HT_vb_UFD(dyn_reactions) = (HT_vb_UFD_max(dyn_reactions) - HT_vb_UFD_min(dyn_reactions))/
                                (HT_vb_UFD_max(dyn_reactions) + HT_vb_UFD_min(dyn_reactions) + tol_eps);                                
*****************************************************************************************************************************************************
***** mean and standary deviation of metabolite flow rates and fluxes *******************************************************************************
mean_HT_BioComp_SynRate(BioCompound) = sum(HT_iterMax, HT_BioComp_SynRate(HT_iterMax, BioCompound))/card(HT_iterMax);

SDev_HT_Biocomp_SynRate(Biocompound) = sqrt(sum(HT_iterMax, sqr(HT_BioComp_SynRate(HT_iterMax, BioCompound) -
                                                mean_HT_BioComp_SynRate(BioCompound)))/(card(HT_iterMax) - 1));
CICD_HT_BioComp_SynRate(dyn_BioComp) = (HT_BioComp_SynRate_max(dyn_BioComp) - HT_BioComp_SynRate_min(dyn_BioComp))/
                                       (HT_BioComp_SynRate_max(dyn_BioComp) + HT_BioComp_SynRate_min(dyn_BioComp) + tol_eps);

mean_HT_v_UFD(reactions) = sum(HT_iterMax, HT_v_UFD(HT_iterMax, reactions))/card(HT_iterMax);
SDev_HT_v_UFD(reactions) = sqrt(sum(HT_iterMax, sqr(HT_v_UFD(HT_iterMax, reactions) - mean_HT_v_UFD(reactions)))/(card(HT_iterMax) - 1));
mean_HT_vf_UFD(reactions) = sum(HT_iterMax, HT_vf_UFD(HT_iterMax, reactions))/card(HT_iterMax);
SDev_HT_vf_UFD(reactions) = sqrt(sum(HT_iterMax, sqr(HT_vf_UFD(HT_iterMax, reactions) - mean_HT_vf_UFD(reactions)))/(card(HT_iterMax) - 1));
mean_HT_vb_UFD(reactions) = sum(HT_iterMax, HT_vb_UFD(HT_iterMax, reactions))/card(HT_iterMax);
SDev_HT_vb_UFD(reactions) = sqrt(sum(HT_iterMax, sqr(HT_vb_UFD(HT_iterMax, reactions) - mean_HT_vb_UFD(reactions)))/(card(HT_iterMax) - 1));

*****************************************************************************************************************************************************

***** CA FBA_Problem ********************************************************************************************************************************
***** assign reactions and species in CA models as dynamic sets ****************
dyn_reactions(reactions) = no;
dyn_species(species) = no;
dyn_Biocomp(biocompound) = no;
dyn_irrev_rxn(reactions) = no;
dyn_rev_rxn(reactions) = no;
dyn_exchange_rxn(reactions) = no;
dyn_objectSet(objectSet) = no;
dyn_Fmax_Object(ObjectSet) = no;
dyn_Fmin_Object(ObjectSet) = no;
dyn_priority_obj(ObjectSet) = no;
dyn_NPI(itermax) = no;

dyn_reactions(reactions) $ (not reactions_NCA(reactions)) = yes;
dyn_species(species) $ (not species_NCA(species)) = yes;
dyn_Biocomp(biocompound) $ (not biocompound_NCA(biocompound)) = yes;
dyn_irrev_rxn(reactions) $ (not reactions_NCA(reactions) and irrev_rxn(reactions)) = yes;
dyn_rev_rxn(reactions) $ (not reactions_NCA(reactions) and rev_rxn(reactions)) = yes;
dyn_exchange_rxn(reactions) $ (not reactions_NCA(reactions) and exchange_rxn(reactions)) = yes;
dyn_Fmax_Object(ObjectSet) $ (FmaxObj_inner_CA(ObjectSet)) = yes;
dyn_Fmin_Object(ObjectSet) $ (FminObj_inner_CA(ObjectSet)) = yes;
dyn_objectSet(objectSet) = dyn_Fmax_Object(ObjectSet) + dyn_Fmin_Object(ObjectSet);
dyn_priority_obj(ObjectSet) $ (PriObj_inner_CA(ObjectSet)) = yes;
No_priority_obj = card(dyn_priority_obj);

*%%%%% initialization of Obj_limit_ratio(iterMax, ObjectSet) %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
*----- read and write the seed for the random number generator -----------------
Obj_limit_ratio(itermax, dyn_objectSet) = 0;

loop(NPI $ (ord(NPI) <= card(dyn_objectSet)), dyn_NPI(NPI) = yes;);

CA_itermax(itermax) = NP(itermax) + dyn_NPI(itermax);
CA_itermax('NP_I') = yes;
CA_itermax('NP_F') = yes;

*----- initialize a population of candidate individuals ------------------------
if(Method_random = 1,
   loop(NP, Obj_limit_ratio(NP, dyn_objectSet) = uniform(%limit_ratio_min%, 1);););

if(Method_random = 2,   
   loop(dyn_objectSet, Obj_limit_ratio(NP, dyn_objectSet) = uniform(%limit_ratio_min%, 1);););

if(Method_random = 3,
   Obj_limit_ratio(NP, dyn_objectSet) = uniform(%limit_ratio_min%, 1););

if(Method_random = 4,
   bestmem_XR(objectSet) = 0;
   bestmem_XR(dyn_objectSet) = uniform(%limit_ratio_min%, 1);
   rand_C1(NP, dyn_objectSet) = uniform(0, 1);
   rand_C2(NP, dyn_objectSet) = uniform(0, 1);
   Obj_limit_ratio(NP, dyn_objectSet) $ (rand_C1(NP, dyn_objectSet) < bestmem_XR(dyn_objectSet)) =
                                             bestmem_XR(dyn_objectSet) - rand_C2(NP, dyn_objectSet) * bestmem_XR(dyn_objectSet);
   Obj_limit_ratio(NP, dyn_objectSet) $ (rand_C1(NP, dyn_objectSet) >= bestmem_XR(dyn_objectSet)) =
                                             bestmem_XR(dyn_objectSet) + rand_C2(NP, dyn_objectSet) * (1 - bestmem_XR(dyn_objectSet)););

* assign obj_limit_ratio at initial and final points
number1 = 1; 
loop(dyn_NPI, number2 = 1;
     loop(dyn_objectSet, Obj_limit_ratio(dyn_NPI, dyn_objectSet) $ (number1 = number2) = 1; number2 = number2 + 1;); number1 = number1 + 1;);

Obj_limit_ratio('NP_I', dyn_objectSet) = %limit_ratio_min%;
Obj_limit_ratio('NP_F', dyn_objectSet) = 1;
*----- end of initialization ---------------------------------------------------
CA_Obj_limit_ratio(CA_itermax, dyn_ObjectSet) = Obj_limit_ratio(CA_itermax, dyn_ObjectSet);

*---- restrictions for the lower and upper bounds of fluxes --------------------
vf.lo(dyn_reactions) = FluxBound_vf_LB(dyn_reactions);
vf.up(dyn_reactions) = FluxBound_vf_UB(dyn_reactions);
vb.lo(dyn_reactions) = FluxBound_vb_LB(dyn_reactions);
vb.up(dyn_reactions) = FluxBound_vb_UB(dyn_reactions);

* assign vb = 0 for the irreversible fluxes
vb.lo(irrev_rxn) = 0;
vb.up(irrev_rxn) = 0;
vb.fx(irrev_rxn) = 0;
vb.lo(DM_sink_rxn(reactions)) $ (flag_DM_sink = 1) = 0;
vb.up(DM_sink_rxn(reactions)) $ (flag_DM_sink = 1) = 0;
vb.fx(DM_sink_rxn(reactions)) $ (flag_DM_sink = 1) = 0;
vf.lo(irrev_vb_rxn(reactions)) = 0;
vf.up(irrev_vb_rxn(reactions)) = 0;
vf.fx(irrev_vb_rxn(reactions)) = 0;

* assign the demanded uptake/secretion reactions
vf.fx(uptake_demand) = 0;
vb.fx(secretion_demand) = 0;
vb.fx(uptake_fixed) = FluxBound_vb_LB(uptake_fixed);

* irreversible uptake_rxn and secretion_rxn
vf.fx(uptake_rxn(dyn_reactions)) $ (flag_uptake = 1) = 0;
vb.fx(secretion_rxn(dyn_reactions)) $ (flag_secretion = 1) = 0;
vf.fx(uptake_demand(dyn_reactions)) $ (card(uptake_demand) > 0) = 0;
vb.fx(secretion_demand(dyn_reactions)) $ (card(secretion_demand) > 0) = 0;
********************************************************************************

*** Assign vf > 0 and vb = 0 for the Specific_rxn_vf --------------------------------
if(card(CA_Specific_rxn_vf) > 0,
   vf.lo(CA_Specific_rxn_vf) =  CA_Specific_rxn_vf_LB(CA_Specific_rxn_vf);
   vf.up(CA_Specific_rxn_vf) =  CA_Specific_rxn_vf_UB(CA_Specific_rxn_vf);
   vb.lo(CA_Specific_rxn_vf) =  0;
   vb.up(CA_Specific_rxn_vf) =  0;
   vb.fx(CA_Specific_rxn_vf) =  0;);
********************************************************************************
*** Assign vf = 0 and vb > 0 for the Specific_rxn_vb --------------------------------
if(card(CA_Specific_rxn_vb) > 0,
   vb.lo(CA_Specific_rxn_vb) =  CA_Specific_rxn_vb_LB(CA_Specific_rxn_vb);
   vb.up(CA_Specific_rxn_vb) =  CA_Specific_rxn_vb_UB(CA_Specific_rxn_vb);
   vf.lo(CA_Specific_rxn_vb) =  0;
   vf.up(CA_Specific_rxn_vb) =  0;
   vf.fx(CA_Specific_rxn_vb) =  0;);
 
*** Assign vf > 0 and vb > 0 for the Specific_rxn_vfvb -------------------------------
if(card(CA_Specific_rxn_vfvb) > 0,
   vf.lo(CA_Specific_rxn_vfvb) =  CA_Specific_rxn_vf_LB(CA_Specific_rxn_vfvb);
   vf.up(CA_Specific_rxn_vfvb) =  CA_Specific_rxn_vf_UB(CA_Specific_rxn_vfvb);
   vb.lo(CA_Specific_rxn_vfvb) =  CA_Specific_rxn_vb_LB(CA_Specific_rxn_vfvb);
   vb.up(CA_Specific_rxn_vfvb) =  CA_Specific_rxn_vb_UB(CA_Specific_rxn_vfvb););    
*******************************************************************************  

*----- compute the lower and upper bounds for the target reactions
target_limit_LB(targetSet) = 0;
target_limit_UB(targetSet) = 0;
target_limit_LB(targetSet) = CA_target_level_LB(targetSet);
target_limit_UB(targetSet) = CA_target_level_UB(targetSet);
MultiObjValue_FBA.lo(ObjectSet) = MultiObjValue_min(objectSet);
MultiObjValue_FBA.up(ObjectSet) = MultiObjValue_max(objectSet);
mem_objvalue_FBA.lo(objectSet) = 0;
mem_objvalue_FBA.up(objectSet) = 1;
Lambda.lo = 0;
Lambda.up = 1;
*-------------------------------------------------------------------------------

* set Weightin factor for mee_objvalue_FBA for CA ------------------------------
Weight_Lambda(ObjectSet) = 0;
Weight_Lambda(ObjectSet) = CA_Weight_mem_obj_FBA(ObjectSet);
*-------------------------------------------------------------------------------

* Determine the normal flux distribution by solving the Primal FBA Problem
solve FBA_Problem using LP maximizing objValue_FBA;
CA_vf_FBA(dyn_reactions) = max(vf.l(dyn_reactions), 0);
CA_vb_FBA(dyn_reactions) = max(vb.l(dyn_reactions), 0);
CA_v_FBA(dyn_reactions) = CA_vf_FBA(dyn_reactions) - CA_vb_FBA(dyn_reactions);
CA_MultiObjvalue_Optim(Objectset) = 0;
CA_MultiObjvalue_Optim(dyn_objectset) = sum(dyn_reactions, coef_CellularObj_vf(dyn_objectset, dyn_reactions) * CA_vf_FBA(dyn_reactions)) +
                                         sum(dyn_reactions, coef_CellularObj_vb(dyn_objectset, dyn_reactions) * CA_vb_FBA(dyn_reactions));
CA_FBA_ModelStat = FBA_Problem.modelstat ;

**** assign Weighting coefficients for Rxn for computing ObjValue in UFD ****************************************************************************
Weight_coef_rxn(reactions) = Weight_factor_Rxn_OT;
Weight_coef_rxn(reactions) $ (CA_Reactions_HC(reactions)) = Weight_factor_Rxn_HC;
Weight_coef_rxn(reactions) $ (CA_Reactions_MC(reactions)) = Weight_factor_Rxn_MC;
Weight_coef_rxn(reactions) $ (CA_Reactions_NC(reactions)) = Weight_factor_Rxn_NC;
*****************************************************************************************************************************************************
Mem_Obj_FBA_Optim(ObjectSet) = 0;
Mem_Obj_FBA_Optim(dyn_Fmax_Object) = ((CA_MultiObjvalue_Optim(dyn_Fmax_Object) - MultiObjValue_min(dyn_Fmax_Object))/
                                      (MultiObjValue_max(dyn_Fmax_Object) - MultiObjValue_min(dyn_Fmax_Object)));
                                        
Mem_Obj_FBA_Optim(dyn_Fmin_Object) = ((MultiObjValue_max(dyn_Fmin_Object) - CA_MultiObjvalue_Optim(dyn_Fmin_Object))/
                                      (MultiObjValue_max(dyn_Fmin_Object) - MultiObjValue_min(dyn_Fmin_Object)));
Mem_Obj_FBA_Optim(dyn_ObjectSet) = max(min(Mem_Obj_FBA_Optim(dyn_ObjectSet), 1), 0);
***** CA UFD problem ********************************************************************************************************************************
loop(CA_itermax,
*---- restrictions for the lower and upper bounds of fluxes --------------------
     vf.lo(reactions) = FluxBound_vf_LB(reactions);
     vf.up(reactions) = FluxBound_vf_UB(reactions);
     vb.lo(reactions) = FluxBound_vb_LB(reactions);
     vb.up(reactions) = FluxBound_vb_UB(reactions);

* assign vb = 0 for the irreversible fluxes
     vb.lo(irrev_rxn) = 0;
     vb.up(irrev_rxn) = 0;
     vb.fx(irrev_rxn) = 0;
     vb.lo(DM_sink_rxn(reactions)) $ (flag_DM_sink = 1) = 0;
     vb.up(DM_sink_rxn(reactions)) $ (flag_DM_sink = 1) = 0;
     vb.fx(DM_sink_rxn(reactions)) $ (flag_DM_sink = 1) = 0;
     vf.lo(irrev_vb_rxn(reactions)) = 0;
     vf.up(irrev_vb_rxn(reactions)) = 0;
     vf.fx(irrev_vb_rxn(reactions)) = 0;

* assign the demanded uptake/secretion reactions
     vf.fx(uptake_demand) = 0;
     vb.fx(secretion_demand) = 0;
     vb.fx(uptake_fixed) = FluxBound_vb_LB(uptake_fixed);

* irreversible uptake_rxn and secretion_rxn
     vf.fx(uptake_rxn(reactions)) $ (flag_uptake = 1) = 0;
     vb.fx(secretion_rxn(reactions)) $ (flag_secretion = 1) = 0;
     vf.fx(uptake_demand(reactions)) $ (card(uptake_demand) > 0) = 0;
     vb.fx(secretion_demand(reactions)) $ (card(secretion_demand) > 0) = 0;
********************************************************************************

*** Assign vf > 0 and vb = 0 for the Specific_rxn_vf --------------------------------
     if(card(CA_Specific_rxn_vf) > 0,
        vf.lo(CA_Specific_rxn_vf) =  CA_Specific_rxn_vf_LB(CA_Specific_rxn_vf);
        vf.up(CA_Specific_rxn_vf) =  CA_Specific_rxn_vf_UB(CA_Specific_rxn_vf);
        vb.lo(CA_Specific_rxn_vf) =  0;
        vb.up(CA_Specific_rxn_vf) =  0;
        vb.fx(CA_Specific_rxn_vf) =  0;);
********************************************************************************
*** Assign vf = 0 and vb > 0 for the Specific_rxn_vb --------------------------------
     if(card(CA_Specific_rxn_vb) > 0,
        vb.lo(CA_Specific_rxn_vb) =  CA_Specific_rxn_vb_LB(CA_Specific_rxn_vb);
        vb.up(CA_Specific_rxn_vb) =  CA_Specific_rxn_vb_UB(CA_Specific_rxn_vb);
        vf.lo(CA_Specific_rxn_vb) =  0;
        vf.up(CA_Specific_rxn_vb) =  0;
        vf.fx(CA_Specific_rxn_vb) =  0;);
 
*** Assign vf > 0 and vb > 0 for the Specific_rxn_vfvb -------------------------------
     if(card(CA_Specific_rxn_vfvb) > 0,
        vf.lo(CA_Specific_rxn_vfvb) =  CA_Specific_rxn_vf_LB(CA_Specific_rxn_vfvb);
        vf.up(CA_Specific_rxn_vfvb) =  CA_Specific_rxn_vf_UB(CA_Specific_rxn_vfvb);
        vb.lo(CA_Specific_rxn_vfvb) =  CA_Specific_rxn_vb_LB(CA_Specific_rxn_vfvb);
        vb.up(CA_Specific_rxn_vfvb) =  CA_Specific_rxn_vb_UB(CA_Specific_rxn_vfvb););    
******************************************************************************* 

     Mem_Obj_FBA_limit(dyn_ObjectSet) = CA_Obj_limit_ratio(CA_itermax, dyn_ObjectSet) * Mem_Obj_FBA_Optim(dyn_ObjectSet);    
     CA_vf_UFD(CA_iterMax, reactions) = 0;
     CA_vb_UFD(CA_iterMax, reactions) = 0;
     CA_v_UFD(CA_iterMax, reactions) = 0;    

     if(flag_UFD_Obj = 1, solve UFD1_Problem using LP minimizing ObjValue_UFD;);
     if(flag_UFD_Obj = 2, solve UFD2_Problem using LP minimizing ObjValue_UFD;);
     if(flag_UFD_Obj = 3, solve UFD3_Problem using QCP minimizing ObjValue_UFD;);
     if(flag_UFD_Obj = 4, solve UFD4_Problem using QCP minimizing ObjValue_UFD;);
     CA_vf_UFD(CA_iterMax, dyn_reactions) = max(vf.l(dyn_reactions), 0);
     CA_vb_UFD(CA_iterMax, dyn_reactions) = max(vb.l(dyn_reactions), 0);
*     CA_vf_UFD(CA_iterMax, dyn_rev_rxn) = max(vf.l(dyn_rev_rxn), 0);
*    CA_vb_UFD(CA_iterMax, dyn_irrev_rxn) = max(vb.l(dyn_irrev_rxn), 0);

     CA_v_UFD(CA_iterMax, dyn_reactions) = CA_vf_UFD(CA_iterMax, dyn_reactions) - CA_vb_UFD(CA_iterMax, dyn_reactions);
     CA_UFD_ModelStat(CA_iterMax) = UFD%No_UFD_Obj%_Problem.modelstat;
);
*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
* compute synthesis rate and degradation rate for each species at the normal state
CA_Species_SynRate(iterMax, species) = 0;
loop(dyn_species,
     CA_Species_SynRate(CA_iterMax, dyn_species) = sum(dyn_reactions, S_Matrix(dyn_species, dyn_reactions) $
                                                    (S_Matrix(dyn_species, dyn_reactions) > 0) * CA_vf_UFD(CA_iterMax, dyn_reactions)) -
                                                 sum(dyn_reactions, S_Matrix(dyn_species, dyn_reactions) $
                                                    (S_Matrix(dyn_species, dyn_reactions) < 0) * CA_vb_UFD(CA_iterMax, dyn_reactions)););

* compute synthesis rate and degradation rate for each biocompound at the normal state
CA_BioComp_SynRate(iterMax, BioCompound) = 0;
loop(dyn_BioComp,
     CA_BioComp_SynRate(CA_iterMax, dyn_BioComp) = sum(dyn_species $ (BioCompound_species(dyn_BioComp, dyn_species)),
                                                     CA_Species_SynRate(CA_iterMax, dyn_species)););
                                                     
* minimum and maximum Biocomp_synthesis rate, vf, vb
CA_BioComp_SynRate_min(dyn_BioComp) = smin(CA_iterMax, CA_BioComp_SynRate(CA_iterMax, dyn_BioComp));
CA_BioComp_SynRate_max(dyn_BioComp) = smax(CA_iterMax, CA_BioComp_SynRate(CA_iterMax, dyn_BioComp));

CA_v_UFD_min(dyn_reactions) = smin(CA_iterMax, CA_v_UFD(CA_iterMax, dyn_reactions));
CA_v_UFD_max(dyn_reactions) = smax(CA_iterMax, CA_v_UFD(CA_iterMax, dyn_reactions));
CA_vf_UFD_min(dyn_reactions) = smin(CA_iterMax, CA_vf_UFD(CA_iterMax, dyn_reactions));
CA_vf_UFD_max(dyn_reactions) = smax(CA_iterMax, CA_vf_UFD(CA_iterMax, dyn_reactions));
CA_vb_UFD_min(dyn_reactions) = smin(CA_iterMax, CA_vb_UFD(CA_iterMax, dyn_reactions));
CA_vb_UFD_max(dyn_reactions) = smax(CA_iterMax, CA_vb_UFD(CA_iterMax, dyn_reactions));
*****************************************************************************************************************************************************

***** inteval BioComp_SynRate changes = [CA_min, CA_max]/[HT_min, HT_max] ***************************************************************************
ratio_Met_SynRate_CAHT_min(biocompound) = min((CA_BioComp_SynRate_min(biocompound) + tol_eps)/(HT_BioComp_SynRate_min(biocompound) + tol_eps),
                                            (CA_BioComp_SynRate_min(biocompound) + tol_eps)/(HT_BioComp_SynRate_max(biocompound) + tol_eps),
                                            (CA_BioComp_SynRate_max(biocompound) + tol_eps)/(HT_BioComp_SynRate_min(biocompound) + tol_eps),
                                            (CA_BioComp_SynRate_max(biocompound) + tol_eps)/(HT_BioComp_SynRate_max(biocompound) + tol_eps));
                                            
ratio_Met_SynRate_CAHT_max(biocompound) = max((CA_BioComp_SynRate_min(biocompound) + tol_eps)/(HT_BioComp_SynRate_min(biocompound) + tol_eps),
                                            (CA_BioComp_SynRate_min(biocompound) + tol_eps)/(HT_BioComp_SynRate_max(biocompound) + tol_eps),
                                            (CA_BioComp_SynRate_max(biocompound) + tol_eps)/(HT_BioComp_SynRate_min(biocompound) + tol_eps),
                                            (CA_BioComp_SynRate_max(biocompound) + tol_eps)/(HT_BioComp_SynRate_max(biocompound) + tol_eps));
******************************************************************************************************************************************************
***** inteval flux changes = [CA_min, CA_max]/[HT_min, HT_max] ***************************************************************************************
ratio_vf_CAHT_min(reactions) = min((CA_vf_UFD_min(reactions) + tol_eps)/(HT_vf_UFD_min(reactions) + tol_eps),
                                 (CA_vf_UFD_min(reactions) + tol_eps)/(HT_vf_UFD_max(reactions) + tol_eps),
                                 (CA_vf_UFD_max(reactions) + tol_eps)/(HT_vf_UFD_min(reactions) + tol_eps),
                                 (CA_vf_UFD_max(reactions) + tol_eps)/(HT_vf_UFD_max(reactions) + tol_eps));
ratio_vf_CAHT_max(reactions) = max((CA_vf_UFD_min(reactions) + tol_eps)/(HT_vf_UFD_min(reactions) + tol_eps),
                                 (CA_vf_UFD_min(reactions) + tol_eps)/(HT_vf_UFD_max(reactions) + tol_eps),
                                 (CA_vf_UFD_max(reactions) + tol_eps)/(HT_vf_UFD_min(reactions) + tol_eps),
                                 (CA_vf_UFD_max(reactions) + tol_eps)/(HT_vf_UFD_max(reactions) + tol_eps));
                                 
ratio_vb_CAHT_min(reactions) = min((CA_vb_UFD_min(reactions) + tol_eps)/(HT_vb_UFD_min(reactions) + tol_eps),
                                 (CA_vb_UFD_min(reactions) + tol_eps)/(HT_vb_UFD_max(reactions) + tol_eps),
                                 (CA_vb_UFD_max(reactions) + tol_eps)/(HT_vb_UFD_min(reactions) + tol_eps),
                                 (CA_vb_UFD_max(reactions) + tol_eps)/(HT_vb_UFD_max(reactions) + tol_eps));
ratio_vb_CAHT_max(reactions) = max((CA_vb_UFD_min(reactions) + tol_eps)/(HT_vb_UFD_min(reactions) + tol_eps),
                                 (CA_vb_UFD_min(reactions) + tol_eps)/(HT_vb_UFD_max(reactions) + tol_eps),
                                 (CA_vb_UFD_max(reactions) + tol_eps)/(HT_vb_UFD_min(reactions) + tol_eps),
                                 (CA_vb_UFD_max(reactions) + tol_eps)/(HT_vb_UFD_max(reactions) + tol_eps));
                                 
ratio_v_CAHT_min(reactions) = min((CA_v_UFD_min(reactions) + tol_eps)/(HT_v_UFD_min(reactions) + tol_eps),
                                (CA_v_UFD_min(reactions) + tol_eps)/(HT_v_UFD_max(reactions) + tol_eps),
                                (CA_v_UFD_max(reactions) + tol_eps)/(HT_v_UFD_min(reactions) + tol_eps),
                                (CA_v_UFD_max(reactions) + tol_eps)/(HT_v_UFD_max(reactions) + tol_eps));
ratio_v_CAHT_max(reactions) = max((CA_v_UFD_min(reactions) + tol_eps)/(HT_v_UFD_min(reactions) + tol_eps),
                                (CA_v_UFD_min(reactions) + tol_eps)/(HT_v_UFD_max(reactions) + tol_eps),
                                (CA_v_UFD_max(reactions) + tol_eps)/(HT_v_UFD_min(reactions) + tol_eps),
                                (CA_v_UFD_max(reactions) + tol_eps)/(HT_v_UFD_max(reactions) + tol_eps));                                
*****************************************************************************************************************************************************
*****************************************************************************************************************************************************
CICD_CA_v_UFD(dyn_reactions) = (CA_v_UFD_max(dyn_reactions) - CA_v_UFD_min(dyn_reactions))/
                               (CA_v_UFD_max(dyn_reactions) + CA_v_UFD_min(dyn_reactions) + tol_eps);
CICD_CA_vf_UFD(dyn_reactions) = (CA_vf_UFD_max(dyn_reactions) - CA_vf_UFD_min(dyn_reactions))/
                                (CA_vf_UFD_max(dyn_reactions) + CA_vf_UFD_min(dyn_reactions) + tol_eps);
CICD_CA_vb_UFD(dyn_reactions) = (CA_vb_UFD_max(dyn_reactions) - CA_vb_UFD_min(dyn_reactions))/
                                (CA_vb_UFD_max(dyn_reactions) + CA_vb_UFD_min(dyn_reactions) + tol_eps);                                
*****************************************************************************************************************************************************

***** mean and standary deviation of metabolite flow rates and fluxes *******************************************************************************
mean_CA_BioComp_SynRate(BioCompound) = sum(CA_iterMax, CA_BioComp_SynRate(CA_iterMax, BioCompound))/card(CA_iterMax);

SDev_CA_Biocomp_SynRate(Biocompound) = sqrt(sum(CA_iterMax, sqr(CA_BioComp_SynRate(CA_iterMax, BioCompound) -
                                                mean_CA_BioComp_SynRate(BioCompound)))/(card(CA_iterMax) - 1));
                                                
CICD_CA_BioComp_SynRate(dyn_BioComp) = (CA_BioComp_SynRate_max(dyn_BioComp) - CA_BioComp_SynRate_min(dyn_BioComp))/
                                       (CA_BioComp_SynRate_max(dyn_BioComp) + CA_BioComp_SynRate_min(dyn_BioComp) + tol_eps);

mean_CA_v_UFD(reactions) = sum(CA_iterMax, CA_v_UFD(CA_iterMax, reactions))/card(CA_iterMax);
SDev_CA_v_UFD(reactions) = sqrt(sum(CA_iterMax, sqr(CA_v_UFD(CA_iterMax, reactions) - mean_CA_v_UFD(reactions)))/(card(CA_iterMax) - 1));
mean_CA_vf_UFD(reactions) = sum(CA_iterMax, CA_vf_UFD(CA_iterMax, reactions))/card(CA_iterMax);
SDev_CA_vf_UFD(reactions) = sqrt(sum(CA_iterMax, sqr(CA_vf_UFD(CA_iterMax, reactions) - mean_CA_vf_UFD(reactions)))/(card(CA_iterMax) - 1));
mean_CA_vb_UFD(reactions) = sum(CA_iterMax, CA_vb_UFD(CA_iterMax, reactions))/card(CA_iterMax);
SDev_CA_vb_UFD(reactions) = sqrt(sum(CA_iterMax, sqr(CA_vb_UFD(CA_iterMax, reactions) - mean_CA_vb_UFD(reactions)))/(card(CA_iterMax) - 1));

log2_Met_CAHT_mean(Biocompound) = log2((mean_CA_BioComp_SynRate(BioCompound) + tol_EPS)/(mean_HT_BioComp_SynRate(BioCompound) + tol_EPS));
ratio_v_CAHT_mean(reactions) = (mean_CA_v_UFD(reactions) + tol_eps)/(mean_HT_v_UFD(reactions) + tol_eps);
*****************************************************************************************************************************************************
log2_v_mean_CAHT(reactions) = log2(abs(ratio_v_CAHT_mean(reactions)));
log2_vf_mean_CAHT(reactions) = log2((mean_CA_vf_UFD(reactions) + tol_EPS)/(mean_HT_vf_UFD(reactions) + tol_EPS));
log2_vb_mean_CAHT(reactions) = log2((mean_CA_vb_UFD(reactions) + tol_EPS)/(mean_HT_vb_UFD(reactions) + tol_EPS));

mean_CAHT_BioComp(BioCompound) = (mean_CA_BioComp_SynRate(BioCompound) + mean_HT_BioComp_SynRate(BioCompound))/2;
mean_CAHT_v_UFD(reactions) = (mean_CA_v_UFD(reactions) + mean_HT_v_UFD(reactions))/2;
mean_CAHT_vf_UFD(reactions) = (mean_CA_vf_UFD(reactions) + mean_HT_vf_UFD(reactions))/2;
mean_CAHT_vb_UFD(reactions) = (mean_CA_vb_UFD(reactions) + mean_HT_vb_UFD(reactions))/2;

***** Trend of Biocomp_synRate fot Intervel CA and BL ***********************************************************************************************
CAHT_BioComp_Pattern(biocompound) = 0;

* inclusive increase interval
CAHT_BioComp_Pattern(biocompound) $ (HT_Biocomp_SynRate_min(biocompound) >= CA_Biocomp_SynRate_min(biocompound) and
                                     HT_Biocomp_SynRate_max(biocompound) <= CA_Biocomp_SynRate_max(biocompound) and
                                     mean_HT_BioComp_SynRate(BioCompound) > mean_CA_BioComp_SynRate(BioCompound)) = -1;
                                     
* inclusive increase plus interval
CAHT_BioComp_Pattern(biocompound) $ (HT_Biocomp_SynRate_min(biocompound) >= CA_Biocomp_SynRate_min(biocompound) and
                                     HT_Biocomp_SynRate_max(biocompound) <= CA_Biocomp_SynRate_max(biocompound) and
                                     mean_HT_BioComp_SynRate(BioCompound) <= mean_CA_BioComp_SynRate(BioCompound)) = 1.5;
                                     
* partial increase interval
CAHT_BioComp_Pattern(biocompound) $ (HT_Biocomp_SynRate_min(biocompound) <= CA_Biocomp_SynRate_min(biocompound) and
                                     HT_Biocomp_SynRate_max(biocompound) < CA_Biocomp_SynRate_max(biocompound) and
                                     HT_Biocomp_SynRate_max(biocompound) > CA_Biocomp_SynRate_min(biocompound) and
                                     mean_HT_BioComp_SynRate(BioCompound) > mean_CA_Biocomp_SynRate(biocompound)) = -2;

* partial increase plus interval
CAHT_BioComp_Pattern(biocompound) $ (HT_Biocomp_SynRate_min(biocompound) <= CA_Biocomp_SynRate_min(biocompound) and
                                     HT_Biocomp_SynRate_max(biocompound) < CA_Biocomp_SynRate_max(biocompound) and
                                     HT_Biocomp_SynRate_max(biocompound) > CA_Biocomp_SynRate_min(biocompound) and
                                     mean_HT_BioComp_SynRate(BioCompound) <= mean_CA_Biocomp_SynRate(biocompound)) = 2.5;
                                     
* complete increase interval
CAHT_BioComp_Pattern(biocompound) $ (HT_Biocomp_SynRate_max(biocompound) <= CA_Biocomp_SynRate_min(biocompound)) = 3;

* inclusive decrease interval
CAHT_BioComp_Pattern(biocompound) $ (HT_Biocomp_SynRate_min(biocompound) <= CA_Biocomp_SynRate_min(biocompound) and
                                     HT_Biocomp_SynRate_max(biocompound) >= CA_Biocomp_SynRate_max(biocompound) and
                                     mean_HT_BioComp_SynRate(BioCompound) < mean_CA_BioComp_SynRate(BioCompound)) = 1;
                                     
* inclusive decrease minus interval-
CAHT_BioComp_Pattern(biocompound) $ (HT_Biocomp_SynRate_min(biocompound) <= CA_Biocomp_SynRate_min(biocompound) and
                                     HT_Biocomp_SynRate_max(biocompound) >= CA_Biocomp_SynRate_max(biocompound) and
                                     mean_HT_BioComp_SynRate(BioCompound) >= mean_CA_BioComp_SynRate(BioCompound)) = -1.5;
* partial decrease interval
CAHT_BioComp_Pattern(biocompound) $ (HT_Biocomp_SynRate_min(biocompound) > CA_Biocomp_SynRate_min(biocompound) and
                                     HT_Biocomp_SynRate_max(biocompound) >= CA_Biocomp_SynRate_max(biocompound) and
                                     HT_Biocomp_SynRate_min(biocompound) < CA_Biocomp_SynRate_max(biocompound) and
                                     mean_HT_BioComp_SynRate(BioCompound) < mean_CA_BioComp_SynRate(BioCompound)) = 2;
                                     
* partial decrease minus interval
CAHT_BioComp_Pattern(biocompound) $ (HT_Biocomp_SynRate_min(biocompound) > CA_Biocomp_SynRate_min(biocompound) and
                                     HT_Biocomp_SynRate_max(biocompound) >= CA_Biocomp_SynRate_max(biocompound) and
                                     HT_Biocomp_SynRate_min(biocompound) < CA_Biocomp_SynRate_max(biocompound) and
                                     mean_HT_BioComp_SynRate(BioCompound) >= mean_CA_BioComp_SynRate(BioCompound)) = -2.5;
                                     
* complete decrease interval
CAHT_BioComp_Pattern(biocompound) $ (HT_Biocomp_SynRate_min(biocompound) >= CA_Biocomp_SynRate_max(biocompound)) = -3;

* unchanged interval
CAHT_BioComp_Pattern(biocompound) $ (HT_Biocomp_SynRate_min(biocompound) = CA_Biocomp_SynRate_min(biocompound) and
                                     HT_Biocomp_SynRate_max(biocompound) = CA_Biocomp_SynRate_max(biocompound)) = 0;
*****************************************************************************************************************************************************
***** Trend of interval v fluxes fot CA and BL ******************************************************************************************************
CAHT_v_Pattern(reactions) = 0;

* inclusive increase interval
CAHT_v_Pattern(reactions) $ (HT_v_UFD_min(reactions) >= CA_v_UFD_min(reactions) and
                             HT_v_UFD_max(reactions) <= CA_v_UFD_max(reactions) and
                             mean_HT_v_UFD(reactions) > mean_CA_v_UFD(reactions)) = -1;
                             
* inclusive increase plus interval
CAHT_v_Pattern(reactions) $ (HT_v_UFD_min(reactions) >= CA_v_UFD_min(reactions) and
                             HT_v_UFD_max(reactions) <= CA_v_UFD_max(reactions) and
                             mean_HT_v_UFD(reactions) <= mean_CA_v_UFD(reactions)) = 1.5;
                             
* partial increase interval
CAHT_v_Pattern(reactions) $ (HT_v_UFD_min(reactions) <= CA_v_UFD_min(reactions) and
                             HT_v_UFD_max(reactions) < CA_v_UFD_max(reactions) and
                             HT_v_UFD_max(reactions) > CA_v_UFD_min(reactions) and
                             mean_HT_v_UFD(reactions) > mean_CA_v_UFD(reactions)) = -2;

* partial increase plus interval
CAHT_v_Pattern(reactions) $ (HT_v_UFD_min(reactions) <= CA_v_UFD_min(reactions) and
                             HT_v_UFD_max(reactions) < CA_v_UFD_max(reactions) and
                             HT_v_UFD_max(reactions) > CA_v_UFD_min(reactions) and
                             mean_HT_v_UFD(reactions) <= mean_CA_v_UFD(reactions)) = 2.5;                             

* complete increase interval
CAHT_v_Pattern(reactions) $ (HT_v_UFD_max(reactions) <= CA_v_UFD_min(reactions)) = 3;

* inclusive decrease interval
CAHT_v_Pattern(reactions) $ (HT_v_UFD_min(reactions) <= CA_v_UFD_min(reactions) and
                             HT_v_UFD_max(reactions) >= CA_v_UFD_max(reactions) and
                             mean_HT_v_UFD(reactions) < mean_CA_v_UFD(reactions)) = 1;

* inclusive decrease minus interval
CAHT_v_Pattern(reactions) $ (HT_v_UFD_min(reactions) <= CA_v_UFD_min(reactions) and
                             HT_v_UFD_max(reactions) >= CA_v_UFD_max(reactions) and
                             mean_HT_v_UFD(reactions) >= mean_CA_v_UFD(reactions)) = -1.5;                             

* partial decrease interval
CAHT_v_Pattern(reactions) $ (HT_v_UFD_min(reactions) > CA_v_UFD_min(reactions) and
                             HT_v_UFD_max(reactions) >= CA_v_UFD_max(reactions) and
                             HT_v_UFD_min(reactions) < CA_v_UFD_max(reactions) and
                             mean_HT_v_UFD(reactions) < mean_CA_v_UFD(reactions)) = 2;
                             
* partial decrease minus interval
CAHT_v_Pattern(reactions) $ (HT_v_UFD_min(reactions) > CA_v_UFD_min(reactions) and
                             HT_v_UFD_max(reactions) >= CA_v_UFD_max(reactions) and
                             HT_v_UFD_min(reactions) < CA_v_UFD_max(reactions) and
                             mean_HT_v_UFD(reactions) >= mean_CA_v_UFD(reactions)) = -2.5;
                             
* complete decrease interval
CAHT_v_Pattern(reactions) $ (HT_v_UFD_min(reactions) >= CA_v_UFD_max(reactions)) = -3;

* unchanged interval
CAHT_v_Pattern(reactions) $ (HT_v_UFD_min(reactions) = CA_v_UFD_min(reactions) and
                             HT_v_UFD_max(reactions) = CA_v_UFD_max(reactions)) = 0;
*****************************************************************************************************************************************************
***** Trend of interval vf fluxes fot CA and BL ******************************************************************************************************
CAHT_vf_Pattern(reactions) = 0;

* inclusive increase interval
CAHT_vf_Pattern(reactions) $ (HT_vf_UFD_min(reactions) >= CA_vf_UFD_min(reactions) and
                             HT_vf_UFD_max(reactions) <= CA_vf_UFD_max(reactions) and
                             mean_HT_vf_UFD(reactions) > mean_CA_vf_UFD(reactions)) = -1;
                             
* inclusive increase plus interval
CAHT_vf_Pattern(reactions) $ (HT_vf_UFD_min(reactions) >= CA_vf_UFD_min(reactions) and
                             HT_vf_UFD_max(reactions) <= CA_vf_UFD_max(reactions) and
                             mean_HT_vf_UFD(reactions) <= mean_CA_vf_UFD(reactions)) = 1.5;
                             
* partial increase interval
CAHT_vf_Pattern(reactions) $ (HT_vf_UFD_min(reactions) <= CA_vf_UFD_min(reactions) and
                             HT_vf_UFD_max(reactions) < CA_vf_UFD_max(reactions) and
                             HT_vf_UFD_max(reactions) > CA_vf_UFD_min(reactions) and
                             mean_HT_vf_UFD(reactions) > mean_CA_vf_UFD(reactions)) = -2;

* partial increase plus interval
CAHT_vf_Pattern(reactions) $ (HT_vf_UFD_min(reactions) <= CA_vf_UFD_min(reactions) and
                             HT_vf_UFD_max(reactions) < CA_vf_UFD_max(reactions) and
                             HT_vf_UFD_max(reactions) > CA_vf_UFD_min(reactions) and
                             mean_HT_vf_UFD(reactions) <= mean_CA_vf_UFD(reactions)) = 2.5;                             

* complete increase interval
CAHT_vf_Pattern(reactions) $ (HT_vf_UFD_max(reactions) <= CA_vf_UFD_min(reactions)) = 3;

* inclusive decrease interval
CAHT_vf_Pattern(reactions) $ (HT_vf_UFD_min(reactions) <= CA_vf_UFD_min(reactions) and
                              HT_vf_UFD_max(reactions) >= CA_vf_UFD_max(reactions) and
                              mean_HT_vf_UFD(reactions) < mean_CA_vf_UFD(reactions)) = 1;

* inclusive decrease minus interval
CAHT_vf_Pattern(reactions) $ (HT_vf_UFD_min(reactions) <= CA_vf_UFD_min(reactions) and
                              HT_vf_UFD_max(reactions) >= CA_vf_UFD_max(reactions) and
                              mean_HT_vf_UFD(reactions) >= mean_CA_vf_UFD(reactions)) = -1.5;                             

* partial decrease interval
CAHT_vf_Pattern(reactions) $ (HT_vf_UFD_min(reactions) > CA_vf_UFD_min(reactions) and
                              HT_vf_UFD_max(reactions) >= CA_vf_UFD_max(reactions) and
                              HT_vf_UFD_min(reactions) < CA_vf_UFD_max(reactions) and
                              mean_HT_vf_UFD(reactions) < mean_CA_vf_UFD(reactions)) = 2;
                             
* partial decrease minus interval
CAHT_vf_Pattern(reactions) $ (HT_vf_UFD_min(reactions) > CA_vf_UFD_min(reactions) and
                             HT_vf_UFD_max(reactions) >= CA_vf_UFD_max(reactions) and
                             HT_vf_UFD_min(reactions) < CA_vf_UFD_max(reactions) and
                             mean_HT_vf_UFD(reactions) >= mean_CA_vf_UFD(reactions)) = -2.5;
                             
* complete decrease interval
CAHT_vf_Pattern(reactions) $ (HT_vf_UFD_min(reactions) >= CA_vf_UFD_max(reactions)) = -3;

* unchanged interval
CAHT_vf_Pattern(reactions) $ (HT_vf_UFD_min(reactions) = CA_vf_UFD_min(reactions) and
                             HT_vf_UFD_max(reactions) = CA_vf_UFD_max(reactions)) = 0;
*****************************************************************************************************************************************************
***** Trend of interval vb fluxes fot CA and BL ******************************************************************************************************
CAHT_vb_Pattern(reactions) = 0;

* inclusive increase interval
CAHT_vb_Pattern(reactions) $ (HT_vb_UFD_min(reactions) >= CA_vb_UFD_min(reactions) and
                              HT_vb_UFD_max(reactions) <= CA_vb_UFD_max(reactions) and
                              mean_HT_vb_UFD(reactions) > mean_CA_vb_UFD(reactions)) = -1;
                             
* inclusive increase plus interval
CAHT_vb_Pattern(reactions) $ (HT_vb_UFD_min(reactions) >= CA_vb_UFD_min(reactions) and
                              HT_vb_UFD_max(reactions) <= CA_vb_UFD_max(reactions) and
                              mean_HT_vb_UFD(reactions) <= mean_CA_vb_UFD(reactions)) = 1.5;
                             
* partial increase interval
CAHT_vb_Pattern(reactions) $ (HT_vb_UFD_min(reactions) <= CA_vb_UFD_min(reactions) and
                              HT_vb_UFD_max(reactions) < CA_vb_UFD_max(reactions) and
                              HT_vb_UFD_max(reactions) > CA_vb_UFD_min(reactions) and
                              mean_HT_vb_UFD(reactions) > mean_CA_vb_UFD(reactions)) = -2;

* partial increase plus interval
CAHT_vb_Pattern(reactions) $ (HT_vb_UFD_min(reactions) <= CA_vb_UFD_min(reactions) and
                             HT_vb_UFD_max(reactions) < CA_vb_UFD_max(reactions) and
                             HT_vb_UFD_max(reactions) > CA_vb_UFD_min(reactions) and
                             mean_HT_vb_UFD(reactions) <= mean_CA_vb_UFD(reactions)) = 2.5;                             

* complete increase interval
CAHT_vb_Pattern(reactions) $ (HT_vb_UFD_max(reactions) <= CA_vb_UFD_min(reactions)) = 3;

* inclusive decrease interval
CAHT_vb_Pattern(reactions) $ (HT_vb_UFD_min(reactions) <= CA_vb_UFD_min(reactions) and
                              HT_vb_UFD_max(reactions) >= CA_vb_UFD_max(reactions) and 
                              mean_HT_vb_UFD(reactions) < mean_CA_vb_UFD(reactions)) = 1;

* inclusive decrease minus interval
CAHT_vb_Pattern(reactions) $ (HT_vb_UFD_min(reactions) <= CA_vb_UFD_min(reactions) and
                              HT_vb_UFD_max(reactions) >= CA_vb_UFD_max(reactions) and
                              mean_HT_vb_UFD(reactions) >= mean_CA_vb_UFD(reactions)) = -1.5;                             

* partial decrease interval
CAHT_vb_Pattern(reactions) $ (HT_vb_UFD_min(reactions) > CA_vb_UFD_min(reactions) and
                              HT_vb_UFD_max(reactions) >= CA_vb_UFD_max(reactions) and
                              HT_vb_UFD_min(reactions) < CA_vb_UFD_max(reactions) and
                              mean_HT_vb_UFD(reactions) < mean_CA_vb_UFD(reactions)) = 2;
                             
* partial decrease minus interval
CAHT_vb_Pattern(reactions) $ (HT_vb_UFD_min(reactions) > CA_vb_UFD_min(reactions) and
                             HT_vb_UFD_max(reactions) >= CA_vb_UFD_max(reactions) and
                             HT_vb_UFD_min(reactions) < CA_vb_UFD_max(reactions) and
                             mean_HT_vb_UFD(reactions) >= mean_CA_vb_UFD(reactions)) = -2.5;
                             
* complete decrease interval
CAHT_vb_Pattern(reactions) $ (HT_vb_UFD_min(reactions) >= CA_vb_UFD_max(reactions)) = -3;

* unchanged interval
CAHT_vb_Pattern(reactions) $ (HT_vb_UFD_min(reactions) = CA_vb_UFD_min(reactions) and
                             HT_vb_UFD_max(reactions) = CA_vb_UFD_max(reactions)) = 0;
*****************************************************************************************************************************************************

***** Computing two tailed and one-tailed p-value ***************************************************************************************************
***** Set and paprameter for computing p-value ******************************************************************************************************
*------------------ Switch ----------------------------------------------------
Parameters
   P_one_Met(biocompound) "one-tailed p-value for bicompounds"
   P_two_Met(biocompound) "two-tailed p_value for bicompounds"
   P_one_vf(reactions) "one-tailed p-value for vf"
   P_two_vf(reactions) "two-tailed p-value for vf"
   P_one_vb(reactions) "one-tailed p-value for vb"
   P_two_vb(reactions) "two-tailed p-value for vb";     
*------------------ Sets & Data -----------------------------------------------

Parameter
  CA(itermax) "CA data"
  HT(itermax) "HT data";
* -------------------------------
* Summary statistics
* -------------------------------
Scalar nCA, nHT, meanCA, meanHT, varCA, varHT, PV_EPS;
PV_EPS    = 1e-32;

* Welch t-statistic and PV_df
Scalar PV_se, tStat, PV_df;
* -----------------------------------------------------------------------------
* Numerical p-value (Student's t) via Simpson's rule
* -----------------------------------------------------------------------------
Scalar PIval; PIval = 3.141592653589793;
* 2000 subintervals
Set PV_I / i0*i2000 /;  
Scalar PV_M; PV_M = card(PV_I) - 1;
Parameter PV_jj(PV_I), PV_x(PV_I), PV_W(PV_I), PV_fI(PV_I);
Set isEnd(PV_I), isOdd(PV_I);
Scalar tAbs, PV_h, PV_c, PV_integral, PV_cdf, pOneTailed, pTwoTailed;
Scalar PV_lnC;
* ----------------------------------------------------------------------------
**** Compute p-value for Met ************************************************************************************************************************
loop(biocompound $ (not biocompound_NCA(biocompound)
     and mean_CAHT_BioComp(BioCompound) >= tol_mean and abs(log2_Met_CAHT_mean(Biocompound)) >= tol_LFC), 

     CA(CA_itermax) = CA_BioComp_SynRate(CA_iterMax, biocompound);
     HT(HT_itermax) = HT_BioComp_SynRate(HT_iterMax, biocompound);     

$batInclude CBM04-p-value-Simpson-Solver-CAHT
*===================================================================================================================================================
     P_one_Met(biocompound) = pOneTailed;
     P_two_Met(biocompound) = pTwoTailed;
);

CA(CA_itermax) = 0;
HT(HT_itermax) = 0;
**** Compute p-value for vf ************************************************************************************************************************
loop(reactions $ (not reactions_NCA(reactions) and mean_CAHT_vf_UFD(reactions) >= tol_mean and
                  abs(log2_vf_mean_CAHT(reactions)) >= tol_LFC), 

     CA(CA_itermax) = CA_vf_UFD(CA_iterMax, reactions);
     HT(HT_itermax) = HT_vf_UFD(HT_iterMax, reactions);     

$batInclude CBM04-p-value-Simpson-Solver-CAHT
*===================================================================================================================================================
     P_one_vf(reactions) = pOneTailed;
     P_two_vf(reactions) = pTwoTailed;                  
);

CA(CA_itermax) = 0;
HT(HT_itermax) = 0;
**** Compute p-value for vb ************************************************************************************************************************
loop(reactions $ (not reactions_NCA(reactions) and mean_CAHT_vb_UFD(reactions) >= tol_mean and
                  abs(log2_vb_mean_CAHT(reactions)) >= tol_LFC),
     CA(CA_itermax) = CA_vb_UFD(CA_iterMax, reactions);
     HT(HT_itermax) = HT_vb_UFD(HT_iterMax, reactions);     

$batInclude CBM04-p-value-Simpson-Solver-CAHT
*===================================================================================================================================================
     P_one_vb(reactions) = pOneTailed;
     P_two_vb(reactions) = pTwoTailed;                  
);
        
file result1 /%ReportData%%outputFilename1%.csv/;
result1.pc = 5;  result1.ps = 130;  result1.pw = 25000; result1.nr = 0; result1.nz = 1.0e-20;
put result1;
put system.title /;
put "Date", system.date:4:0, " ", "Time", system.time /; put /;

put /;
put "Target"; put "HT_target_level_LB"; put "HT_target_level_UB"; put " "; put "CA_target_level_LB"; put "CA_target_level_UB";  put /;
loop(targetSet, put targetSet.tl; put HT_target_level_LB(targetSet):18:10; put HT_target_level_UB(targetSet):18:10; put " ";
     put CA_target_level_LB(targetSet):18:10; put CA_target_level_UB(targetSet):18:10; put /;);

put /; put "MultiObjvalue_min and MultiObjvalue_max for CA and HT model #####"; put /;
put "Objective"; put "MultiObjvalue_min"; put "MultiObjvalue_max"; put /;
loop(objectset, put objectset.tl:0; put MultiObjvalue_min(objectset):18:10; put MultiObjvalue_max(objectset):18:10; put /;);

put /; put "Weighting factor for rxn with HC, MC, NC and OT assigned by the user";
put /; put "Weight_factor_Rxn_HC"; put "Weight_factor_Rxn_MC"; put "Weight_factor_Rxn_NC"; put "Weight_factor_Rxn_OT"; 
put /; put Weight_factor_Rxn_HC; put Weight_factor_Rxn_MC; put Weight_factor_Rxn_NC; put Weight_factor_Rxn_OT; put /;

put /; put "Weighting factors for mem_objvalue_FBA of CA and HT models"; put /;
put "CA_Weight_mem_obj_FBA"; for(i_loop =1 to sum(objectset, (CA_Weight_mem_obj_FBA(objectset) > 0) = 1) - 1, put " ";);
put "HT_Weight_mem_obj_FBA"; put /;
loop(ObjectSet $ (CA_Weight_mem_obj_FBA(ObjectSet) > 0), put objectset.tl:0;); 
loop(ObjectSet $ (HT_Weight_mem_obj_FBA(ObjectSet) > 0), put objectset.tl:0;); put /;
loop(ObjectSet $ (CA_Weight_mem_obj_FBA(ObjectSet) > 0), put CA_Weight_mem_obj_FBA(ObjectSet):10:4;);
loop(ObjectSet $ (HT_Weight_mem_obj_FBA(ObjectSet) > 0), put CA_Weight_mem_obj_FBA(ObjectSet):10:4;);
put /;

put /;
put "Numbers of species, reactions and candidate reactions can be selected:"; put /;
put "No. species"; put "No. reactions"; put "exchange_rxn"; put "uptake_demand"; put "uptake_fixed";
put "exchange_demand"; put /;
put card(species); put card(reactions); put card(exchange_rxn); put card(uptake_demand); put card(uptake_fixed);
put card(exchange_demand);
put /;

put /; put "Synthesis vf and vb reactions of the multiobjective in the optimization problem"; put /;
loop(objectset,
     put "Objectset"; put "Synthesis vf reactions"; put /;
     put objectset.tl; 
     number1 = 0; 
     loop(reactions $ (syn_vf_rxn(objectset, reactions)), put reactions.tl; number1 = number1 + 1;
          if(number1 = 20, put " "; put /; number1 = 0;);); put /;

     number1 = 0; put " "; put "Synthesis vb reactions:"; put /;
     loop(reactions $ (syn_vb_rxn(objectset, reactions)), put reactions.tl; number1 = number1 + 1;
          if(number1 = 20, put " "; put /; number1 = 0;);); put /;
);

put /; put "Demanded uptake reactions:"; put /;
put "uptake_demand"; put "vf_LB"; put "vf_UB"; put "vb_LB"; put "vb_UB"; put "status"; put /;
loop(uptake_demand, put uptake_demand.tl; put FluxBound_vf_LB(uptake_demand):18:10; put FluxBound_vf_UB(uptake_demand):18:10;
     put FluxBound_vb_LB(uptake_demand):18:10; put FluxBound_vb_UB(uptake_demand):18:10;
     if(uptake_fixed(uptake_demand), put "vb.fixed";); put /;);

put /; put "Demanded exchange reactions:"; put /;
put "exchange_demand"; put "vf_LB"; put "vf_UB"; put "vb_LB"; put "vb_UB"; put /;
loop(exchange_demand, put exchange_demand.tl; put FluxBound_vf_LB(exchange_demand):18:10; put FluxBound_vf_UB(exchange_demand):18:10;
     put FluxBound_vb_LB(exchange_demand):18:10; put FluxBound_vb_UB(exchange_demand):18:10; put /;);

put "===== Check CA_FBA_modelstat, HT_FBA_modelStat, CA_UFD_modelstat, and HT_UFD_modelStat ======"; put /;
put "Model"; put "FBA_modelstat"; put "UFD_modelStat(iterMax)"; put /;
put "CA model"; put CA_FBA_ModelStat; loop(CA_iterMax, put CA_UFD_ModelStat(CA_iterMax);); put /;
put "HT model"; put HT_FBA_ModelStat; loop(HT_itermax, put HT_UFD_ModelStat(HT_iterMax);); put /;
put "Tol_mean"; put tol_mean:16:10; put "Tol_LFC"; put tol_LFC:16:10; put /;

put /; put "########## Biocomp_Synthesis rates for CA and HT models ##########"; put /;
put "Trend = 3: Complete increase; 2.5: Complete increase(+); 2: Partial increase; 1.5: Inclusive increase(+); 1: Inclusive increase; 0: Unchange";
put /; put "-1: Inclusive decrease; -1.5: Inclusive decrease(-); -2: Partial decrease; -2.5: Partial decrease(-); -3: Complete decrease";
put /; put "CA/HT_index_Met = 1: biocomp_chokept_SISO; 2: biocomp_chokept_SIMO; 3: biocomp_chokept_MISO; 0: not chokepoints";
put /; put "Biocomp"; put "CA_min"; put "CA_max"; put "mean_CA"; put"CA_basal"; put "HT_min"; put "HT_max"; put "mean_HT";
put "HT_basal"; put "log2(CA/HT)_min"; put "log2(CA/HT)_max";
put "log2(CA/HT)_mean"; put "Trend of CAHT"; put "CA_Choke point"; put "HT_Choke point"; put /;
loop(biocompound $ (not biocompound_NCA(biocompound)
     and mean_CAHT_BioComp(BioCompound) >= tol_mean and abs(log2_Met_CAHT_mean(Biocompound)) >= tol_LFC), put biocompound.tl:0;
     put CA_BioComp_SynRate_min(BioCompound):18:10; put CA_BioComp_SynRate_max(BioCompound):18:10;
     put mean_CA_BioComp_SynRate(BioCompound):18:10; put CA_BioComp_SynRate('NP_F', BioCompound):18:10;
     put HT_BioComp_SynRate_min(BioCompound):18:10; put HT_BioComp_SynRate_max(BioCompound):18:10;
     put mean_HT_BioComp_SynRate(BioCompound):18:10; put HT_BioComp_SynRate('NP_F', BioCompound):18:10;
     put log2(ratio_Met_SynRate_CAHT_min(biocompound)):18:10; put log2(ratio_Met_SynRate_CAHT_max(biocompound)):18:10;
     put log2_Met_CAHT_mean(Biocompound):18:10; put CAHT_BioComp_Pattern(biocompound); put CA_index_Met(biocompound); put HT_index_Met(biocompound);
put /;);
putclose result1;
*****************************************************************************************************************************************************

file result2 /%ReportData%%outputFilename2%.csv/;
result2.pc = 5;  result2.ps = 130;  result2.pw = 25000; result2.nr = 0; result2.nz = 1.0e-20;
put result2;
put system.title /;
put "Date", system.date:4:0, " ", "Time", system.time /; put /;

put /;
put "Target"; put "HT_target_level_LB"; put "HT_target_level_UB"; put " "; put "CA_target_level_LB"; put "CA_target_level_UB";  put /;
loop(targetSet, put targetSet.tl; put HT_target_level_LB(targetSet):18:10; put HT_target_level_UB(targetSet):18:10; put " ";
     put CA_target_level_LB(targetSet):18:10; put CA_target_level_UB(targetSet):18:10; put /;);

put /; put "MultiObjvalue_min and MultiObjvalue_max for CA and HT model #####"; put /;
put "Objective"; put "MultiObjvalue_min"; put "MultiObjvalue_max"; put /;
loop(objectset, put objectset.tl:0; put MultiObjvalue_min(objectset):18:10; put MultiObjvalue_max(objectset):18:10; put /;);

put /; put "Weighting factor for rxn with HC, MC, NC and OT assigned by the user";
put /; put "Weight_factor_Rxn_HC"; put "Weight_factor_Rxn_MC"; put "Weight_factor_Rxn_NC"; put "Weight_factor_Rxn_OT"; 
put /; put Weight_factor_Rxn_HC; put Weight_factor_Rxn_MC; put Weight_factor_Rxn_NC; put Weight_factor_Rxn_OT; put /;

put /; put "Weighting factors for mem_objvalue_FBA of CA and HT models"; put /;
put "CA_Weight_mem_obj_FBA"; for(i_loop =1 to sum(objectset, (CA_Weight_mem_obj_FBA(objectset) > 0) = 1) - 1, put " ";);
put "HT_Weight_mem_obj_FBA"; put /;
loop(ObjectSet $ (CA_Weight_mem_obj_FBA(ObjectSet) > 0), put objectset.tl:0;); 
loop(ObjectSet $ (HT_Weight_mem_obj_FBA(ObjectSet) > 0), put objectset.tl:0;); put /;
loop(ObjectSet $ (CA_Weight_mem_obj_FBA(ObjectSet) > 0), put CA_Weight_mem_obj_FBA(ObjectSet):10:4;);
loop(ObjectSet $ (HT_Weight_mem_obj_FBA(ObjectSet) > 0), put CA_Weight_mem_obj_FBA(ObjectSet):10:4;);
put /;

put /;
put "Numbers of species, reactions and candidate reactions can be selected:"; put /;
put "No. species"; put "No. reactions"; put "exchange_rxn"; put "uptake_demand"; put "uptake_fixed";
put "exchange_demand"; put /;
put card(species); put card(reactions); put card(exchange_rxn); put card(uptake_demand); put card(uptake_fixed);
put card(exchange_demand);
put /;

put /; put "Synthesis vf and vb reactions of the multiobjective in the optimization problem"; put /;
loop(objectset,
     put "Objectset"; put "Synthesis vf reactions"; put /;
     put objectset.tl; 
     number1 = 0; 
     loop(reactions $ (syn_vf_rxn(objectset, reactions)), put reactions.tl; number1 = number1 + 1;
          if(number1 = 20, put " "; put /; number1 = 0;);); put /;
     number1 = 0; put " "; put "Synthesis vb reactions:"; put /;
     loop(reactions $ (syn_vb_rxn(objectset, reactions)), put reactions.tl; number1 = number1 + 1;
          if(number1 = 20, put " "; put /; number1 = 0;);); put /;
);

put /; put "Demanded uptake reactions:"; put /;
put "uptake_demand"; put "vf_LB"; put "vf_UB"; put "vb_LB"; put "vb_UB"; put "status"; put /;
loop(uptake_demand, put uptake_demand.tl; put FluxBound_vf_LB(uptake_demand):18:10; put FluxBound_vf_UB(uptake_demand):18:10;
     put FluxBound_vb_LB(uptake_demand):18:10; put FluxBound_vb_UB(uptake_demand):18:10;
     if(uptake_fixed(uptake_demand), put "vb.fixed";); put /;);

put /; put "Demanded exchange reactions:"; put /;
put "exchange_demand"; put "vf_LB"; put "vf_UB"; put "vb_LB"; put "vb_UB"; put /;
loop(exchange_demand, put exchange_demand.tl; put FluxBound_vf_LB(exchange_demand):18:10; put FluxBound_vf_UB(exchange_demand):18:10;
     put FluxBound_vb_LB(exchange_demand):18:10; put FluxBound_vb_UB(exchange_demand):18:10; put /;);

put "===== Check CA_FBA_modelstat, HT_FBA_modelStat, CA_UFD_modelstat, and HT_UFD_modelStat ======"; put /;
put "Model"; put "FBA_modelstat"; put "UFD_modelStat(iterMax)"; put /;
put "CA model"; put CA_FBA_ModelStat; loop(CA_iterMax, put CA_UFD_ModelStat(CA_iterMax);); put /;
put "HT model"; put HT_FBA_ModelStat; loop(HT_itermax, put HT_UFD_ModelStat(HT_iterMax);); put /;
put "Tol_mean"; put tol_mean:16:10; put "Tol_LFC"; put tol_LFC:16:10; put /;

put /; put "########## Net Fluxes v = vf - vb for CA and HT models ##########"; put /;
put "Trend = 3: Complete increase; 2.5: Complete increase(+); 2: Partial increase; 1.5: Inclusive increase(+); 1: Inclusive increase; 0: Unchange";
put /; put "-1: Inclusive decrease; -1.5: Inclusive decrease(-); -2: Partial decrease; -2.5: Partial decrease(-); -3: Complete decrease";
put /; put "index_rxn = 1: irrev_rxn; 2: rev_rxn";
put "CA/HT_index_wt_rxn = 4: HC reactions, 3: MC reactions, 2: NC reactions, 1: Other reactions, 0: Not existed in CA/HT model"; 
put /; put "v"; put "CA_min"; put "CA_max"; put "mean_CA"; put "CA_basal"; put "HT_min"; put "HT_max"; put "mean_HT"; put "HT_basal"; 
       put "ratio(CA/HT)_min"; put "ratio(CA/HT)_max"; put "log2(CA/HT)_mean"; put "Trend of CAHT"; put "irrev/rev_rxn";
       put " "; put "CA_Index_wt_rxn"; put "HT_Index_wt_rxn"; put /;
loop(reactions $ (not reactions_NCA(reactions) and mean_CAHT_v_UFD(reactions) >= tol_mean and
                  abs(log2_v_mean_CAHT(reactions)) >= tol_LFC), put reactions.tl:0;
     put CA_v_UFD_min(reactions):18:10; put CA_v_UFD_max(reactions):18:10;
     put mean_CA_v_UFD(reactions):18:10; put CA_v_UFD('NP_F', reactions):18:10;
     put HT_v_UFD_min(reactions):18:10; put HT_v_UFD_max(reactions):18:10;
     put mean_HT_v_UFD(reactions):18:10; put HT_v_UFD('NP_F', reactions):18:10;
     put ratio_v_CAHT_min(reactions):18:10; put ratio_v_CAHT_max(reactions):18:10; put log2_v_mean_CAHT(reactions):18:10; 
     put CAHT_v_Pattern(reactions); put index_rxn(reactions); put " "; put CA_Index_wt_rxn(reactions); put HT_Index_wt_rxn(reactions);
put /;);


put /; put "########## Forward Fluxes vf for CA and HT models ##########"; put /;
put "Trend = 3: Complete increase; 2.5: Complete increase(+); 2: Partial increase; 1.5: Inclusive increase(+); 1: Inclusive increase; 0: Unchange";
put /; put "-1: Inclusive decrease; -1.5: Inclusive decrease(-); -2: Partial decrease; -2.5: Partial decrease(-); -3: Complete decrease";
put /; put "index_rxn = 1: irrev_rxn; 2: rev_rxn";
put /; put "vf"; put "CA_min"; put "CA_max"; put "mean_CA"; put "CA_basal"; put "HT_min"; put "HT_max"; put "mean_HT"; put "HT_basal"; 
       put "log2(CA/HT)_min"; put "log2(CA/HT)_max"; put "log2(CA/HT)_mean"; put "Trend of CAHT"; put "irrev/rev_rxn";
       put " "; put "CA_Index_wt_rxn"; put "HT_Index_wt_rxn"; put /;
loop(reactions $ (not reactions_NCA(reactions) and mean_CAHT_vf_UFD(reactions) >= tol_mean and
                  abs(log2_vf_mean_CAHT(reactions)) >= tol_LFC), put reactions.tl:0;
     put CA_vf_UFD_min(reactions):18:10; put CA_vf_UFD_max(reactions):18:10;
     put mean_CA_vf_UFD(reactions):18:10; put CA_vf_UFD('NP_F', reactions):18:10;
     put HT_vf_UFD_min(reactions):18:10; put HT_vf_UFD_max(reactions):18:10;
     put mean_HT_vf_UFD(reactions):18:10; put HT_vf_UFD('NP_F', reactions):18:10;
     put log2(ratio_vf_CAHT_min(reactions)):18:10; put log2(ratio_vf_CAHT_max(reactions)):18:10; put log2_vf_mean_CAHT(reactions):18:10; 
     put CAHT_vf_Pattern(reactions); put index_rxn(reactions); put " "; put CA_Index_wt_rxn(reactions); put HT_Index_wt_rxn(reactions);
put /;);

put /; put "########## Backward Fluxes vb for CA and HT models ##########"; put /;
put "Trend = 3: Complete increase; 2.5: Complete increase(+); 2: Partial increase; 1.5: Inclusive increase(+); 1: Inclusive increase; 0: Unchange";
put /; put "-1: Inclusive decrease; -1.5: Inclusive decrease(-); -2: Partial decrease; -2.5: Partial decrease(-); -3: Complete decrease";
put /; put "index_rxn = 1: irrev_rxn; 2: rev_rxn";
put /; put "vb"; put "CA_min"; put "CA_max"; put "mean_CA"; put "CA_basal"; put "HT_min"; put "HT_max"; put "mean_HT"; put "HT_basal";
       put "log2(CA/HT)_min"; put "log2(CA/HT)_max"; put "log2(CA/HT)_mean"; put "Trend of CAHT"; put "irrev/rev_rxn";
       put " "; put "CA_Index_wt_rxn"; put "HT_Index_wt_rxn"; put /;
loop(reactions $ (not reactions_NCA(reactions) and mean_CAHT_vb_UFD(reactions) >= tol_mean and
                   abs(log2_vb_mean_CAHT(reactions)) >= tol_LFC), put reactions.tl:0;
     put CA_vb_UFD_min(reactions):18:10; put CA_vb_UFD_max(reactions):18:10;
     put mean_CA_vb_UFD(reactions):18:10; put CA_vb_UFD('NP_F', reactions):18:10;
     put HT_vb_UFD_min(reactions):18:10; put HT_vb_UFD_max(reactions):18:10;
     put mean_HT_vb_UFD(reactions):18:10; put HT_vb_UFD('NP_F', reactions):18:10;
     put log2(ratio_vb_CAHT_min(reactions)):18:10; put log2(ratio_vb_CAHT_max(reactions)):18:10; put log2_vb_mean_CAHT(reactions):18:10;
     put CAHT_vb_Pattern(reactions); put index_rxn(reactions); put " "; put CA_Index_wt_rxn(reactions); put HT_Index_wt_rxn(reactions);
put /;);
putclose result2;
*****************************************************************************************************************************************************

file result3 /%ReportData%%outputFilename3%.csv/;
result3.pc = 5;  result3.ps = 130;  result3.pw = 25000; result3.nr = 0; result3.nz = 1.0e-20;
if(card(print_biocomp) > 0,
   put result3;
   put system.title /;
   put "Date", system.date:4:0, " ", "Time", system.time /;
   put "Tol_mean"; put tol_mean:16:10; put "Tol_LFC"; put tol_LFC:16:10; put /;
   put /; put "########## Differential expression of Biocomp_Synthesis rate for CA and HT models ##########"; put /;
   put "Trend = 3: Complete increase; 2.5: Complete increase(+); 2: Partial increase; 1.5: Inclusive increase(+); 1: Inclusive increase; 0: Unchange";
   put /; put "-1: Inclusive decrease; -1.5: Inclusive decrease(-); -2: Partial decrease; -2.5: Partial decrease(-); -3: Complete decrease";
   put /; put "CA/HT_index_Met = 1: biocomp_chokept_SISO; 2: biocomp_chokept_SIMO; 3: biocomp_chokept_MISO; 0: not chokepoints";
   put /; put " "; put "CA_BioComp_SynRate(CA_iterMax)"; for(i_loop = 1 to card(CA_iterMax) - 1, put " ";);
   put "HT_BioComp_SynRate(HT_iterMax)"; put /;
   put "BioComp"; loop(CA_itermax, put CA_iterMax.tl:0;); loop(HT_itermax, put HT_iterMax.tl:0;);
   put " "; put "Mean_CA"; put "SDev_CA"; put "CA_min"; put "CA_max"; put "CICD_CA"; put "Mean_HT"; put "SDev_HT";
   put "HT_min"; put "HT_max"; put "CICD_HT"; put "log2(CA/HT)_min"; put "log2(CA/HT)_max";
   put "log2(CA/HT)_mean"; put "Trend of CAHT"; put "CA_Choke point"; put "HT_Choke point";
   put "p_two_Met"; put /; 
   loop(biocompound $ (not biocompound_NCA(biocompound) and print_biocomp(biocompound)
        and mean_CAHT_BioComp(BioCompound) >= tol_mean and abs(log2_Met_CAHT_mean(Biocompound)) >= tol_LFC), put biocompound.tl:0;      
        loop(CA_itermax, put CA_BioComp_SynRate(CA_iterMax, biocompound):18:10;);
        loop(HT_itermax, put HT_BioComp_SynRate(HT_iterMax, biocompound):18:10;);
        put " "; put mean_CA_BioComp_SynRate(BioCompound):18:10; put SDev_CA_Biocomp_SynRate(Biocompound):18:10;
                 put CA_BioComp_SynRate_min(BioCompound):18:10; put CA_BioComp_SynRate_max(BioCompound):18:10; 
                 put CICD_CA_Biocomp_SynRate(Biocompound):18:10; 
                 put mean_HT_BioComp_SynRate(BioCompound):18:10; put SDev_HT_Biocomp_SynRate(Biocompound):18:10;
                 put HT_BioComp_SynRate_min(BioCompound):18:10; put HT_BioComp_SynRate_max(BioCompound):18:10;               
                 put CICD_HT_Biocomp_SynRate(Biocompound):18:10; put log2(ratio_Met_SynRate_CAHT_min(biocompound)):18:10;
                 put log2(ratio_Met_SynRate_CAHT_max(biocompound)):18:10; put log2_Met_CAHT_mean(Biocompound):18:10;
                 put CAHT_BioComp_Pattern(biocompound); put CA_index_Met(biocompound); put HT_index_Met(biocompound);
                 put P_two_Met(biocompound):18:10;
   put /;););

if(card(print_rxn) > 0,
   put /; put "Tol_mean"; put tol_mean:16:10; put "Tol_LFC"; put tol_LFC:16:10; put /;
   put /; put "##### Net fluxes v = vf - vb for CA and HT models #####"; put /;
   put "Trend = 3: Complete increase; 2.5: Complete increase(+); 2: Partial increase; 1.5: Inclusive increase(+); 1: Inclusive increase; 0: Unchange";
   put /; put "-1: Inclusive decrease; -1.5: Inclusive decrease(-); -2: Partial decrease; -2.5: Partial decrease(-); -3: Complete decrease";
   put /; put "index_rxn = 1: irrev_rxn; 2: rev_rxn" ;
   put "CA/HT_index_wt_rxn = 4: HC reactions, 3: MC reactions, 2: NC reactions, 1: Other reactions, 0: Not existed in CA/HT model"; 
   put /; put " "; put "CA_v_UFD(CA_iterMax)"; for(i_loop = 1 to card(CA_iterMax) - 1, put " ";); put "HT_v_UFD(HT_iterMax)"; put /;
   put "rxn"; loop(CA_itermax, put CA_iterMax.tl:0;); loop(HT_itermax, put HT_iterMax.tl:0;);
   put " "; put "Mean_CA"; put "SDev_CA"; put "CA_v_UFD_min"; put "CA_v_UFD_max"; put "CICD_CA_v_UFD"; put "Mean_HT"; put "SDev_HT";
   put "HT_v_UFD_min"; put "HT_v_UFD_max";  put "CICD_HT_v_UFD"; put "ratio(CA/HT)_min"; put "ratio(CA/HT)_max";
   put "log2(CA/HT)_mean"; put "Trend of CAHT"; put "irrev/rev_rxn"; put " "; put "CA_Index_wt_rxn"; put "HT_Index_wt_rxn"; put /;
   loop(reactions $(not reactions_NCA(reactions) and print_rxn(reactions) and
        mean_CAHT_v_UFD(reactions) >= tol_mean and abs(log2_v_mean_CAHT(reactions)) >= tol_LFC), put reactions.tl:0;
        loop(CA_itermax, put CA_v_UFD(CA_iterMax, reactions):18:10;);
        loop(HT_itermax, put HT_v_UFD(HT_iterMax, reactions):18:10;); put " ";
        put mean_CA_v_UFD(reactions):18:10; put SDev_CA_v_UFD(reactions):18:10; put CA_v_UFD_min(reactions):18:10;
        put CA_v_UFD_max(reactions):18:10;  put CICD_CA_v_UFD(reactions):18:10;
        put mean_HT_v_UFD(reactions):18:10; put SDev_HT_v_UFD(reactions):18:10; put HT_v_UFD_min(reactions):18:10;
        put HT_v_UFD_max(reactions):18:10; put CICD_HT_v_UFD(reactions):18:10;
        put ratio_v_CAHT_min(reactions):18:10; put ratio_v_CAHT_max(reactions):18:10;
        put log2_v_mean_CAHT(reactions):18:10; put CAHT_v_Pattern(reactions); put index_rxn(reactions);
        put " "; put CA_Index_wt_rxn(reactions); put HT_Index_wt_rxn(reactions);
   put /;);
   
   put /; put "########## Forward Fluxes vf for CA and HT models ##########"; put /;
   put "Trend = 3: Complete increase; 2.5: Complete increase(+); 2: Partial increase; 1.5: Inclusive increase(+); 1: Inclusive increase; 0: Unchange";
   put /; put "-1: Inclusive decrease; -1.5: Inclusive decrease(-); -2: Partial decrease; -2.5: Partial decrease(-); -3: Complete decrease";
   put /; put "index_rxn = 1: irrev_rxn; 2: rev_rxn";
   put "CA/HT_index_wt_rxn = 4: HC reactions, 3: MC reactions, 2: NC reactions, 1: Other reactions, 0: Not existed in CA/HT model";  
   put /; put " "; put "CA_vf_UFD(CA_iterMax)"; for(i_loop = 1 to card(CA_iterMax) - 1, put " ";); put "HT_vf_UFD(HT_iterMax)"; put /;
   put "rxn"; loop(CA_itermax, put CA_iterMax.tl:0;); loop(HT_itermax, put HT_iterMax.tl:0;);   
   put " "; put "Mean_CA_vf"; put "SDev_CA_vf"; put "CA_vf_UFD_min"; put "CA_vf_UFD_max"; put "CICD_CA_vf_UFD";
   put "Mean_HT_vf"; put "SDev_HT_vf"; put "HT_vf_UFD_min"; put "HT_vf_UFD_max"; put "CICD_HT_vf_UFD";   
   put "log2(CA/HT)_min"; put "log2(CA/HT)_max"; put "log2(CA/HT)_mean"; put "Trend of CAHT"; put "irrev/rev_rxn";
   put " "; put "CA_Index_wt_rxn"; put "HT_Index_wt_rxn"; put "P_two_vf"; put /;
   loop(reactions $(not reactions_NCA(reactions) and print_rxn(reactions) and
        mean_CAHT_vf_UFD(reactions) >= tol_mean and abs(log2_vf_mean_CAHT(reactions)) >= tol_LFC), put reactions.tl:0;
        loop(CA_itermax, put CA_vf_UFD(CA_iterMax, reactions):18:10;);
        loop(HT_itermax, put HT_vf_UFD(HT_iterMax, reactions):18:10;); put " ";
        put mean_CA_vf_UFD(reactions):18:10; put SDev_CA_vf_UFD(reactions):18:10; put CA_vf_UFD_min(reactions):18:10;
        put CA_vf_UFD_max(reactions):18:10;  put CICD_CA_vf_UFD(reactions):18:10;
        put mean_HT_vf_UFD(reactions):18:10; put SDev_HT_vf_UFD(reactions):18:10; put HT_vf_UFD_min(reactions):18:10;
        put HT_vf_UFD_max(reactions):18:10; put CICD_HT_vf_UFD(reactions):18:10;
        put log2(ratio_vf_CAHT_min(reactions)):18:10; put log2(ratio_vf_CAHT_max(reactions)):18:10;
        put log2_vf_mean_CAHT(reactions):18:10; put CAHT_vf_Pattern(reactions); put index_rxn(reactions);
        put " "; put CA_Index_wt_rxn(reactions); put HT_Index_wt_rxn(reactions); put P_two_vf(reactions):18:10;
   put /;);

   put /; put "########## Backward fluxes vb for CA and HT models ##########"; put /;
   put "Trend = 3: Complete increase; 2.5: Complete increase(+); 2: Partial increase; 1.5: Inclusive increase(+); 1: Inclusive increase; 0: Unchange";
   put /; put "-1: Inclusive decrease; -1.5: Inclusive decrease(-); -2: Partial decrease; -2.5: Partial decrease(-); -3: Complete decrease";
   put /; put "index_rxn = 1: irrev_rxn; 2: rev_rxn";
   put "CA/HT_index_wt_rxn = 4: HC reactions, 3: MC reactions, 2: NC reactions, 1: Other reactions, 0: Not existed in CA/HT model";
   put /; put " "; put "CA_vb_UFD(CA_iterMax)"; for(i_loop = 1 to card(CA_iterMax) - 1, put " ";); put "HT_vb_UFD(HT_iterMax)"; put /;
   put "rxn"; loop(CA_itermax, put CA_iterMax.tl:0;); loop(HT_itermax, put HT_iterMax.tl:0;);
   
   put " "; put "Mean_CA_vb"; put "SDev_CA_vb"; put "CA_vb_UFD_min"; put "CA_vb_UFD_max"; put "CICD_CA_vb_UFD";
   put "Mean_HT_vb"; put "SDev_HT_vb"; put "HT_vb_UFD_min"; put "HT_vb_UFD_max"; put "CICD_HT_vb_UFD";   
   put "log2(CA/HT)_min"; put "log2(CA/HT)_max"; put "log2(CA/HT)_mean"; put "Trend of CAHT"; put "irrev/rev_rxn";
   put " "; put "CA_Index_wt_rxn"; put "HT_Index_wt_rxn"; put "P_two_vb"; put /;
   loop(reactions $ (not reactions_NCA(reactions) and print_rxn(reactions) and
        mean_CAHT_vb_UFD(reactions) >= tol_mean and abs(log2_vb_mean_CAHT(reactions)) >= tol_LFC), put reactions.tl:0;
        loop(CA_itermax, put CA_vb_UFD(CA_iterMax, reactions):18:10;);
        loop(HT_itermax, put HT_vb_UFD(HT_iterMax, reactions):18:10;); put " ";
        put mean_CA_vb_UFD(reactions):18:10; put SDev_CA_vb_UFD(reactions):18:10; put CA_vb_UFD_min(reactions):18:10;
        put CA_vb_UFD_max(reactions):18:10;  put CICD_CA_vb_UFD(reactions):18:10;
        put mean_HT_vb_UFD(reactions):18:10; put SDev_HT_vb_UFD(reactions):18:10; put HT_vb_UFD_min(reactions):18:10;
        put HT_vb_UFD_max(reactions):18:10; put CICD_HT_vb_UFD(reactions):18:10;
        put log2(ratio_vb_CAHT_min(reactions)):18:10; put log2(ratio_vb_CAHT_max(reactions)):18:10;
        put log2_vb_mean_CAHT(reactions):18:10; put CAHT_vb_Pattern(reactions); put index_rxn(reactions);
        put " "; put CA_Index_wt_rxn(reactions); put HT_Index_wt_rxn(reactions); put P_two_vb(reactions):18:10;       
   put /;);

putclose result3;);
*****************************************************************************************************************************************************

file result4 /%ReportData%%outputFilename4%.csv/;
result4.pc = 5;  result4.ps = 130;  result4.pw = 25000; result4.nr = 0; result4.nz = 1.0e-20;
put result4;
put system.title /;
put "Date", system.date:4:0, " ", "Time", system.time /; put /;

put "===== Check CA_FBA_modelstat, HT_FBA_modelStat, CA_UFD_modelstat, and HT_UFD_modelStat ======"; put /;
put "Model"; put "FBA_modelstat"; put "UFD_modelStat(iterMax)"; put /;
put "CA model"; put CA_FBA_ModelStat; loop(CA_iterMax, put CA_UFD_ModelStat(CA_iterMax);); put /;
put "HT model"; put HT_FBA_ModelStat; loop(HT_itermax, put HT_UFD_ModelStat(HT_iterMax);); put /;
put "Tol_mean"; put tol_mean:16:10; put "Tol_LFC"; put tol_LFC:16:10; put /;
put /; put "########## Differential expression of Biocomp_Synthesis rate for CA and HT models ##########"; put /;
put "Trend = 3: Complete increase; 2.5: Complete increase(+); 2: Partial increase; 1.5: Inclusive increase(+); 1: Inclusive increase; 0: Unchange";
put /; put "-1: Inclusive decrease; -1.5: Inclusive decrease(-); -2: Partial decrease; -2.5: Partial decrease(-); -3: Complete decrease";
put /; put "CA/HT_index_Met = 1: biocomp_chokept_SISO; 2: biocomp_chokept_SIMO; 3: biocomp_chokept_MISO; 0: not chokepoints";
put /; put " "; put "CA_BioComp_SynRate(CA_iterMax)"; for(i_loop = 1 to card(CA_iterMax) - 1, put " ";);
put "HT_BioComp_SynRate(HT_iterMax)"; put /;
put "BioComp"; loop(CA_itermax, put CA_iterMax.tl:0;); loop(HT_itermax, put HT_iterMax.tl:0;);
put " "; put "Mean_CA"; put "SDev_CA"; put "CA_min"; put "CA_max"; put "CICD_CA"; put "Mean_HT"; put "SDev_HT";
put "HT_min"; put "HT_max"; put "CICD_HT"; put "log2(CA/HT)_min"; put "log2(CA/HT)_max"; put "log2(CA/HT)_mean";
put "Trend of CAHT"; put "CA_Choke point"; put "HT_Choke point"; put /;
loop(biocompound $ (not biocompound_NCA(biocompound)
     and mean_CAHT_BioComp(BioCompound) >= tol_mean and abs(log2_Met_CAHT_mean(Biocompound)) >= tol_LFC), put biocompound.tl:0;
     loop(CA_itermax, put CA_BioComp_SynRate(CA_iterMax, biocompound):18:10;);
     loop(HT_itermax, put HT_BioComp_SynRate(HT_iterMax, biocompound):18:10;);
     put " "; put mean_CA_BioComp_SynRate(BioCompound):18:10; put SDev_CA_Biocomp_SynRate(Biocompound):18:10;
              put CA_BioComp_SynRate_min(BioCompound):18:10; put CA_BioComp_SynRate_max(BioCompound):18:10; 
              put CICD_CA_Biocomp_SynRate(Biocompound):18:10; 
              put mean_HT_BioComp_SynRate(BioCompound):18:10; put SDev_HT_Biocomp_SynRate(Biocompound):18:10;
              put HT_BioComp_SynRate_min(BioCompound):18:10; put HT_BioComp_SynRate_max(BioCompound):18:10;               
              put CICD_HT_Biocomp_SynRate(Biocompound):18:10; put log2(ratio_Met_SynRate_CAHT_min(biocompound)):18:10;
              put log2(ratio_Met_SynRate_CAHT_max(biocompound)):18:10; put log2_Met_CAHT_mean(Biocompound):18:10;
              put CAHT_BioComp_Pattern(biocompound); put CA_index_Met(biocompound); put HT_index_Met(biocompound);
put /;);
putclose result4;
*****************************************************************************************************************************************************

file result5 /%ReportData%%outputFilename5%.csv/;
result5.pc = 5;  result5.ps = 130;  result5.pw = 25000; result5.nr = 0; result5.nz = 1.0e-20;
put result5;
put system.title /;
put "Date", system.date:4:0, " ", "Time", system.time /; put /;

put "===== Check CA_FBA_modelstat, HT_FBA_modelStat, CA_UFD_modelstat, and HT_UFD_modelStat ======"; put /;
put "Model"; put "FBA_modelstat"; put "UFD_modelStat(iterMax)"; put /;
put "CA model"; put CA_FBA_ModelStat; loop(CA_itermax, put CA_UFD_ModelStat(CA_iterMax);); put /;
put "HT model"; put HT_FBA_ModelStat; loop(HT_itermax, put HT_UFD_ModelStat(HT_iterMax);); put /;
put "Tol_mean"; put tol_mean:16:10; put "Tol_LFC"; put tol_LFC:16:10; put /;

put /; put "##### Net fluxes v = vf - vb for CA and HT models #####"; put /;
put "Trend = 3: Complete increase; 2.5: Complete increase(+); 2: Partial increase; 1.5: Inclusive increase(+); 1: Inclusive increase; 0: Unchange";
put /; put "-1: Inclusive decrease; -1.5: Inclusive decrease(-); -2: Partial decrease; -2.5: Partial decrease(-); -3: Complete decrease";
put /; put "index_rxn = 1: irrev_rxn; 2: rev_rxn";
put "CA/HT_index_wt_rxn = 4: HC reactions, 3: MC reactions, 2: NC reactions, 1: Other reactions, 0: Not existed in CA/HT model";
put /; put " "; put "CA_v_UFD(CA_iterMax)"; for(i_loop = 1 to card(CA_iterMax) - 1, put " ";); put "HT_v_UFD(HT_iterMax)"; put /;
put "rxn"; loop(CA_itermax, put CA_iterMax.tl:0;); loop(HT_itermax, put HT_iterMax.tl:0;);
put " "; put "Mean_CA"; put "SDev_CA"; put "CA_v_UFD_min"; put "CA_v_UFD_max"; put "CICD_CA_v_UFD"; put "Mean_HT"; put "SDev_HT";
put "HT_v_UFD_min"; put "HT_v_UFD_max";  put "CICD_HT_v_UFD"; put "ratio(CA/HT)_min"; put "ratio(CA/HT)_max"; put "log2(CA/HT)_mean";
put "Trend of CAHT"; put "irrev/rev_rxn"; put " "; put "CA_Index_wt_rxn"; put "HT_Index_wt_rxn"; put /;
loop(reactions $(not reactions_NCA(reactions) and mean_CAHT_v_UFD(reactions) >= tol_mean and
                 abs(ratio_v_CAHT_mean(reactions)) >= tol_LFC), put reactions.tl:0;
     loop(CA_itermax, put CA_v_UFD(CA_iterMax, reactions):18:10;);
     loop(HT_itermax, put HT_v_UFD(HT_iterMax, reactions):18:10;); put " ";
     put mean_CA_v_UFD(reactions):18:10; put SDev_CA_v_UFD(reactions):18:10; put CA_v_UFD_min(reactions):18:10;
     put CA_v_UFD_max(reactions):18:10;  put CICD_CA_v_UFD(reactions):18:10;
     put mean_HT_v_UFD(reactions):18:10; put SDev_HT_v_UFD(reactions):18:10; put HT_v_UFD_min(reactions):18:10;
     put HT_v_UFD_max(reactions):18:10; put CICD_HT_v_UFD(reactions):18:10;
     put ratio_v_CAHT_min(reactions):18:10; put ratio_v_CAHT_max(reactions):18:10; put log2_v_mean_CAHT(reactions):18:10;     
     put CAHT_v_Pattern(reactions); put index_rxn(reactions); put " "; put CA_Index_wt_rxn(reactions); put HT_Index_wt_rxn(reactions);
put /;);
   
put /; put "########## Forward Fluxes vf for CA and HT models ##########"; put /;
put "Trend = 3: Complete increase; 2.5: Complete increase(+); 2: Partial increase; 1.5: Inclusive increase(+); 1: Inclusive increase; 0: Unchange";
put /; put "-1: Inclusive decrease; -1.5: Inclusive decrease(-); -2: Partial decrease; -2.5: Partial decrease(-); -3: Complete decrease";
put /; put "index_rxn = 1: irrev_rxn; 2: rev_rxn";
put "CA/HT_index_wt_rxn = 4: HC reactions, 3: MC reactions, 2: NC reactions, 1: Other reactions, 0: Not existed in CA/HT model"; 
put /; put " "; put "CA_vf_UFD(CA_iterMax)"; for(i_loop = 1 to card(CA_iterMax) - 1, put " ";); put "HT_vf_UFD(HT_iterMax)"; put /;
put "rxn"; loop(CA_itermax, put CA_iterMax.tl:0;); loop(HT_itermax, put HT_iterMax.tl:0;);   
put " "; put "Mean_CA_vf"; put "SDev_CA_vf"; put "CA_vf_UFD_min"; put "CA_vf_UFD_max"; put "CICD_CA_vf_UFD";
put "Mean_HT_vf"; put "SDev_HT_vf"; put "HT_vf_UFD_min"; put "HT_vf_UFD_max"; put "CICD_HT_vf_UFD";   
put "log2(CA/HT)_min"; put "log2(CA/HT)_max"; put "log2(CA/HT)_mean"; put "Trend of CAHT"; put "irrev/rev_rxn";
put " "; put "CA_Index_wt_rxn"; put "HT_Index_wt_rxn"; put /;
loop(reactions $(not reactions_NCA(reactions) and mean_CAHT_vf_UFD(reactions) >= tol_mean and
                 abs(log2_vf_mean_CAHT(reactions)) >= tol_LFC), put reactions.tl:0;
     loop(CA_itermax, put CA_vf_UFD(CA_iterMax, reactions):18:10;);
     loop(HT_itermax, put HT_vf_UFD(HT_iterMax, reactions):18:10;); put " ";
     put mean_CA_vf_UFD(reactions):18:10; put SDev_CA_vf_UFD(reactions):18:10; put CA_vf_UFD_min(reactions):18:10;
     put CA_vf_UFD_max(reactions):18:10;  put CICD_CA_vf_UFD(reactions):18:10;
     put mean_HT_vf_UFD(reactions):18:10; put SDev_HT_vf_UFD(reactions):18:10; put HT_vf_UFD_min(reactions):18:10;
     put HT_vf_UFD_max(reactions):18:10; put CICD_HT_vf_UFD(reactions):18:10;
     put log2(ratio_vf_CAHT_min(reactions)):18:10; put log2(ratio_vf_CAHT_max(reactions)):18:10; put log2_vf_mean_CAHT(reactions):18:10; 
     put CAHT_vf_Pattern(reactions); put index_rxn(reactions); put " "; put CA_Index_wt_rxn(reactions); put HT_Index_wt_rxn(reactions);
put /;);

put /; put "########## Backward fluxes vb for CA and HT models ##########"; put /;
put "Trend = 3: Complete increase; 2.5: Complete increase(+); 2: Partial increase; 1.5: Inclusive increase(+); 1: Inclusive increase; 0: Unchange";
put /; put "-1: Inclusive decrease; -1.5: Inclusive decrease(-); -2: Partial decrease; -2.5: Partial decrease(-); -3: Complete decrease";
put /; put "index_rxn = 1: irrev_rxn; 2: rev_rxn";
put "CA/HT_index_wt_rxn = 4: HC reactions, 3: MC reactions, 2: NC reactions, 1: Other reactions, 0: Not existed in CA/HT model";
put /; put " "; put "CA_vb_UFD(CA_iterMax)"; for(i_loop = 1 to card(CA_iterMax) - 1, put " ";); put "HT_vb_UFD(HT_iterMax)"; put /;
put "rxn"; loop(CA_itermax, put CA_iterMax.tl:0;); loop(HT_itermax, put HT_iterMax.tl:0;);   
put " "; put "Mean_CA_vb"; put "SDev_CA_vb"; put "CA_vb_UFD_min"; put "CA_vb_UFD_max"; put "CICD_CA_vb_UFD";
put "Mean_HT_vb"; put "SDev_HT_vb"; put "HT_vb_UFD_min"; put "HT_vb_UFD_max"; put "CICD_HT_vb_UFD";   
put "log2(CA/HT)_min"; put "log2(CA/HT)_max"; put "log2(CA/HT)_mean"; put "Trend of CAHT"; put "irrev/rev_rxn";
put " "; put "CA_Index_wt_rxn"; put "HT_Index_wt_rxn"; put /;
loop(reactions $(not reactions_NCA(reactions) and mean_CAHT_vb_UFD(reactions) >= tol_mean and
                 abs(log2_vb_mean_CAHT(reactions)) >= tol_LFC), put reactions.tl:0;
     loop(CA_itermax, put CA_vb_UFD(CA_iterMax, reactions):18:10;);
     loop(HT_itermax, put HT_vb_UFD(HT_iterMax, reactions):18:10;); put " ";
     put mean_CA_vb_UFD(reactions):18:10; put SDev_CA_vb_UFD(reactions):18:10; put CA_vb_UFD_min(reactions):18:10;
     put CA_vb_UFD_max(reactions):18:10;  put CICD_CA_vb_UFD(reactions):18:10;
     put mean_HT_vb_UFD(reactions):18:10; put SDev_HT_vb_UFD(reactions):18:10; put HT_vb_UFD_min(reactions):18:10;
     put HT_vb_UFD_max(reactions):18:10; put CICD_HT_vb_UFD(reactions):18:10;
     put log2(ratio_vb_CAHT_min(reactions)):18:10; put log2(ratio_vb_CAHT_max(reactions)):18:10; put log2_vb_mean_CAHT(reactions):18:10; 
     put CAHT_vb_Pattern(reactions); put index_rxn(reactions); put " "; put CA_Index_wt_rxn(reactions); put HT_Index_wt_rxn(reactions);
put /;);
putclose result5;
*****************************************************************************************************************************************************

file result6 /%ReportData%%outputFilename6%.CSV/;
result6.pc = 5;  result6.ps = 130;  result6.pw = 25000; result6.nr = 0; result6.nz = 1.0e-20;
put result6;
put system.title /;
put "Date", system.date:4:0, " ", "Time", system.time /; put /;

***** print Met *********************************
put "===== Biomarkers for Metabolites ====="; put /;
put "Met"; put "_%modelName0%_%User_Medium%"; put "log2_Met_CAHT_Mean"; put /;
loop(biocompound $ (not biocompound_NCA(biocompound) and print_biocomp(biocompound)
        and mean_CAHT_BioComp(BioCompound) >= tol_mean and (abs(log2_Met_CAHT_mean(Biocompound)) >= tol_LFC)
        and (p_two_Met(biocompound) <= %P_value_Threshold%) and (abs(CAHT_BioComp_Pattern(biocompound)) >= %Pattern_Level%)),        
        put biocompound.tl:0; put CAHT_BioComp_Pattern(biocompound); put log2_Met_CAHT_mean(Biocompound):16:8; put /;);

***** print vf **********************************
put /; put "===== Biomarkers for vf ====="; put /;
put "rxn_vf"; put "%modelName0%_%User_Medium%"; put "log2_vf_mean_CAHT"; put /;
loop(reactions $(not reactions_NCA(reactions) and print_rxn(reactions) and
        mean_CAHT_vf_UFD(reactions) >= tol_mean and abs(log2_vf_mean_CAHT(reactions)) >= tol_LFC
        and (p_two_vf(reactions) <= %P_value_Threshold%) and (abs(CAHT_vf_Pattern(reactions)) >= %Pattern_Level%)),
        put reactions.tl:0; put CAHT_vf_Pattern(reactions); put log2_vf_mean_CAHT(reactions):16:8; put /;);

***** print vb **********************************
put /; put "===== Biomarkers for vb ====="; put /;
put "rxn_vb"; put "%modelName0%_%User_Medium%"; put "log2_vb_mean_CAHT"; put /;
loop(reactions $ (not reactions_NCA(reactions) and print_rxn(reactions) and
        mean_CAHT_vb_UFD(reactions) >= tol_mean and abs(log2_vb_mean_CAHT(reactions)) >= tol_LFC
        and (p_two_vb(reactions) <= %P_value_Threshold%) and (abs(CAHT_vb_Pattern(reactions)) >= %Pattern_Level%)),
        put reactions.tl:0; put CAHT_vb_Pattern(reactions); put log2_vb_mean_CAHT(reactions):16:8; put /;);        
putclose result6;
*****************************************************************************************************************************************************

parameter
ord_biocomp(biocompound), count0, count,
ord_vf(reactions), ord_vb(reactions);

file result7 /%ReportData%%outputFilename7%.gms/;
put result7;
put '$onMulti'; put /;
put "Parameters"; put /;
put @3, put 'biocomp_%modelName0%_%User_Medium%(biocompound<) "biocompounds defined in %modelName0%_%User_Medium% model"'; put /;
put @3, "/" ; put /;
***** print Met *********************************
count = 0;
number1 = 0;
ord_biocomp(biocompound) = 0;
loop(biocompound $ (not biocompound_NCA(biocompound) and print_biocomp(biocompound)
        and mean_CAHT_BioComp(BioCompound) >= tol_mean and (abs(log2_Met_CAHT_mean(Biocompound)) >= tol_LFC)
        and (p_two_Met(biocompound) <= %P_value_Threshold%) and (abs(CAHT_BioComp_Pattern(biocompound)) >= %Pattern_Level%)),
        number1 = number1 + 1; ord_biocomp(biocompound) = number1;);

loop(biocompound $ (not biocompound_NCA(biocompound) and print_biocomp(biocompound)
        and mean_CAHT_BioComp(BioCompound) >= tol_mean and (abs(log2_Met_CAHT_mean(Biocompound)) >= tol_LFC)
        and (p_two_Met(biocompound) <= %P_value_Threshold%) and (abs(CAHT_BioComp_Pattern(biocompound)) >= %Pattern_Level%)),        
        for(count0 = 1 to 5, put " ";); put "'";  put biocompound.tl:0; put "'   "; 
        put CAHT_BioComp_Pattern(biocompound);
        if(ord_biocomp(biocompound) < number1, put ","; else put " ";);
        count = count + 1; if (count = 4, put /; count = 0;););
put /; put @5, "/"; put /;

***** print vf **********************************
put /; put '$onMulti'; put /;
put @3, put 'rxn_vf_%modelName0%_%User_Medium%(reactions<) "rxn_vf defined in %modelName0%_%User_Medium% model"'; put /;
put @3, "/" ; put /;

count = 0;
number1 = 0;
ord_vf(reactions) = 0;
loop(reactions $(not reactions_NCA(reactions) and print_rxn(reactions) and
        mean_CAHT_vf_UFD(reactions) >= tol_mean and abs(log2_vf_mean_CAHT(reactions)) >= tol_LFC
        and (p_two_vf(reactions) <= %P_value_Threshold%) and (abs(CAHT_vf_Pattern(reactions)) >= %Pattern_Level%)),
        number1 = number1 + 1; ord_vf(reactions) = number1;);
    
loop(reactions $(not reactions_NCA(reactions) and print_rxn(reactions) and
        mean_CAHT_vf_UFD(reactions) >= tol_mean and abs(log2_vf_mean_CAHT(reactions)) >= tol_LFC
        and (p_two_vf(reactions) <= %P_value_Threshold%) and (abs(CAHT_vf_Pattern(reactions)) >= %Pattern_Level%)),

        for(count0 = 1 to 5, put " ";); put "'";  put reactions.tl:0; put "'   "; 
        put CAHT_vf_Pattern(reactions);
        if(ord_vf(reactions) < number1, put ","; else put " ";);
        count = count + 1; if (count = 4, put /; count = 0;););
put /; put @5, "/"; put /;

***** print vb **********************************
put /; put '$onMulti'; put /;
put @3, put 'rxn_vb_%modelName0%_%User_Medium%(reactions<) "rxn_vb defined in %modelName0%_%User_Medium% model"'; put /;
put @3, "/" ; put /;

count = 0;
number1 = 0;
ord_vb(reactions) = 0;
loop(reactions $ (not reactions_NCA(reactions) and print_rxn(reactions) and
        mean_CAHT_vb_UFD(reactions) >= tol_mean and abs(log2_vb_mean_CAHT(reactions)) >= tol_LFC
        and (p_two_vb(reactions) <= %P_value_Threshold%) and (abs(CAHT_vb_Pattern(reactions)) >= %Pattern_Level%)),
        number1 = number1 + 1; ord_vb(reactions) = number1;);

loop(reactions $ (not reactions_NCA(reactions) and print_rxn(reactions) and
        mean_CAHT_vb_UFD(reactions) >= tol_mean and abs(log2_vb_mean_CAHT(reactions)) >= tol_LFC
        and (p_two_vb(reactions) <= %P_value_Threshold%) and (abs(CAHT_vb_Pattern(reactions)) >= %Pattern_Level%)),
        for(count0 = 1 to 5, put " ";); put "'";  put reactions.tl:0; put "'   "; 
        put CAHT_vb_Pattern(reactions);
        if(ord_vb(reactions) < number1, put ","; else put " ";);
        count = count + 1; if (count = 4, put /; count = 0;););
put /; put @5, "/"; put /;

***** print log2_Met_CAHT *********************************
put /; put '$onMulti'; put /;
put @3, put 'log2_Met_CAHT_%modelName0%_%User_Medium%(biocompound<) "log2_Met_CAHT defined in %modelName0%_%User_Medium% model"'; put /;
put @3, "/" ; put /;

count = 0;
number1 = 0;
ord_biocomp(biocompound) = 0;
loop(biocompound $ (not biocompound_NCA(biocompound) and print_biocomp(biocompound)
        and mean_CAHT_BioComp(BioCompound) >= tol_mean and (abs(log2_Met_CAHT_mean(Biocompound)) >= tol_LFC)
        and (p_two_Met(biocompound) <= %P_value_Threshold%) and (abs(CAHT_BioComp_Pattern(biocompound)) >= %Pattern_Level%)),
        number1 = number1 + 1; ord_biocomp(biocompound) = number1;);

loop(biocompound $ (not biocompound_NCA(biocompound) and print_biocomp(biocompound)
        and mean_CAHT_BioComp(BioCompound) >= tol_mean and (abs(log2_Met_CAHT_mean(Biocompound)) >= tol_LFC)
        and (p_two_Met(biocompound) <= %P_value_Threshold%) and (abs(CAHT_BioComp_Pattern(biocompound)) >= %Pattern_Level%)),        
        for(count0 = 1 to 5, put " ";); put "'";  put biocompound.tl:0; put "'   "; 
        put log2_Met_CAHT_mean(Biocompound):16:8;
        if(ord_biocomp(biocompound) < number1, put ","; else put " ";);
        count = count + 1; if (count = 4, put /; count = 0;););
put /; put @5, "/"; put /;

***** print log2_vf_CAHT **********************************
put /; put '$onMulti'; put /;
put @3, put 'log2_vf_CAHT_%modelName0%_%User_Medium%(reactions<) "log2_vfCAHT defined in %modelName0%_%User_Medium% model"'; put /;
put @3, "/" ; put /;

count = 0;
number1 = 0;
ord_vf(reactions) = 0;
loop(reactions $(not reactions_NCA(reactions) and print_rxn(reactions) and
        mean_CAHT_vf_UFD(reactions) >= tol_mean and abs(log2_vf_mean_CAHT(reactions)) >= tol_LFC
        and (p_two_vf(reactions) <= %P_value_Threshold%) and (abs(CAHT_vf_Pattern(reactions)) >= %Pattern_Level%)),
        number1 = number1 + 1; ord_vf(reactions) = number1;);
    
loop(reactions $(not reactions_NCA(reactions) and print_rxn(reactions) and
        mean_CAHT_vf_UFD(reactions) >= tol_mean and abs(log2_vf_mean_CAHT(reactions)) >= tol_LFC
        and (p_two_vf(reactions) <= %P_value_Threshold%) and (abs(CAHT_vf_Pattern(reactions)) >= %Pattern_Level%)),

        for(count0 = 1 to 5, put " ";); put "'";  put reactions.tl:0; put "'   "; 
        put log2_vf_mean_CAHT(reactions):16:8;
        if(ord_vf(reactions) < number1, put ","; else put " ";);
        count = count + 1; if (count = 4, put /; count = 0;););
put /; put @5, "/"; put /;

***** print log2_vb_CAHT **********************************
put /; put '$onMulti'; put /;
put @3, put 'log2_vb_CAHT_%modelName0%_%User_Medium%(reactions<) "log2_vb_CAHT defined in %modelName0%_%User_Medium% model"'; put /;
put @3, "/" ; put /;

count = 0;
number1 = 0;
ord_vb(reactions) = 0;
loop(reactions $ (not reactions_NCA(reactions) and print_rxn(reactions) and
        mean_CAHT_vb_UFD(reactions) >= tol_mean and abs(log2_vb_mean_CAHT(reactions)) >= tol_LFC
        and (p_two_vb(reactions) <= %P_value_Threshold%) and (abs(CAHT_vb_Pattern(reactions)) >= %Pattern_Level%)),
        number1 = number1 + 1; ord_vb(reactions) = number1;);

loop(reactions $ (not reactions_NCA(reactions) and print_rxn(reactions) and
        mean_CAHT_vb_UFD(reactions) >= tol_mean and abs(log2_vb_mean_CAHT(reactions)) >= tol_LFC
        and (p_two_vb(reactions) <= %P_value_Threshold%) and (abs(CAHT_vb_Pattern(reactions)) >= %Pattern_Level%)),
        for(count0 = 1 to 5, put " ";); put "'";  put reactions.tl:0; put "'   "; 
        put log2_vb_mean_CAHT(reactions):16:8;
        if(ord_vb(reactions) < number1, put ","; else put " ";);
        count = count + 1; if (count = 4, put /; count = 0;););
put /; put @5, "/;"; put /;
putclose result7;
*****************************************************************************************************************************************************
