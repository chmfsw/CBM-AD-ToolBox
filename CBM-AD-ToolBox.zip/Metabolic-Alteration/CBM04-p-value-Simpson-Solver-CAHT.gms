***** Batch include file ****************************************************************************************************************************
nCA    = card(itermax);
nHT    = card(itermax);
meanCA = sum(itermax, CA(itermax)) / max(PV_EPS,nCA);
meanHT = sum(itermax, HT(itermax)) / max(PV_EPS,nHT);
varCA  = sum(itermax, sqr(CA(itermax) - meanCA)) / max(PV_EPS,(nCA - 1));
varHT  = sum(itermax, sqr(HT(itermax) - meanHT)) / max(PV_EPS,(nHT - 1));

* Welch t-statistic and PV_df
PV_se  = sqrt(varCA/max(PV_EPS,nCA) + varHT/max(PV_EPS, nHT));
tStat  = (meanCA - meanHT) / max(PV_EPS,PV_se);

PV_df  = sqr(varCA/nCA + varHT/nHT)
        / max(PV_EPS, (sqr(varCA/nCA)/max(PV_EPS,(nCA-1))
        + sqr(varHT/nHT)/max(PV_EPS,(nHT-1))));

* -------------------------------
* Numerical p-value (Student's t) via Simpson's rule
* -------------------------------
tAbs = abs(tStat);

if (tAbs = 0,
   pOneTailed = 0.5;
   pTwoTailed = 1;
else
   PV_jj(PV_I) = ord(PV_I) - 1;
   PV_h        = tAbs / max(1,PV_M);
   PV_x(PV_I)  = PV_jj(PV_I) * PV_h;

   PV_W(PV_I)  = 2;
   isOdd(PV_I) = yes $ (mod(PV_jj(PV_I),2) = 1);
   isEnd(PV_I) = yes $ (PV_jj(PV_I) = 0 or PV_jj(PV_I) = PV_M);
   PV_W(PV_I) $ isOdd(PV_I) = 4;
   PV_W(PV_I) $ isEnd(PV_I) = 1;

* ---- Safe t-distribution constant using logGamma ----
* PV_lnC = lnΓ((ν+1)/2) - 0.5*(lnν + lnπ) - lnΓ(ν/2)

PV_lnC = logGamma(max(PV_EPS, 0.5*(PV_df+1)))
    - 0.5*log(max(PV_EPS,PV_df)*PIval)
    - logGamma(max(PV_EPS, 0.5*PV_df));
PV_c = exp(PV_lnC);

* ---- PDF values ----
   PV_fI(PV_I) = PV_c * rpower(1 + sqr(PV_x(PV_I))/max(PV_EPS,PV_df), -0.5*(PV_df+1));

* ---- Simpson PV_integral ----
   PV_integral = (PV_h / 3) * sum(PV_I, PV_W(PV_I) * PV_fI(PV_I));

   PV_cdf = 0.5 + PV_integral;
   PV_cdf = min(1, max(0,PV_cdf));

   pOneTailed = 1 - PV_cdf;
   if (pOneTailed < 0, pOneTailed = 0);
   pTwoTailed = min(1, 2*pOneTailed);
);
*****************************************************************************************************************************************************
Display meanCA, meanHT, varCA, varHT, tStat, PV_df, pOneTailed, pTwoTailed;

