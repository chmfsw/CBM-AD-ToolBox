$title Identifying Antivirus Targets of genome-scale metabolic model by the nested hybrid differential evolution
$Ontext
Coding strategy:
pop_XI(NP, Dim_XI) is represented by integer variables for candidate biocompounds in NHDE
pop_XI(NP, Dim_XR) is represented by real variable 0.05, 1) for the regulation strength parameter in NHDE

max fitness = max min{mem_grade} - penalty_term
where penalty = penalty_parameter * sum(Dim_h, abs(constraint_h(Dim_h)))

decision problem solving by NHDE:
Outer optimization problem:
  Min Vbiomass_TR
  max V_ATP_PH, min Vbiomass_PH
  fuzzy dissimilarity of flux and metabolite-flow for PH to CA model
  fuzzy similarity of flux and metabolite-flow for PH to HT model

subject to fuzzy multiobjective inner optimization problems
    Fuuzy max and Duzzy min for FBA problem
    min UFD problem

The integer decision variables x_HDE for HDE, which are represented how many deleted reactions
are required by the user, are coded by the orders of the candidate reactions.
The orders of the integer decisions x_HDE are then decoded as in which reactions to be deleted, z_HDE.

decoding strategy for up/down/knockout regulation for the i-th forward/backward reaction

Regulation strategy
z_HDE = 1: Up-regulated synthesis rate for the targeted biocompounds:
                          HL_vf + C (vf_UB - HT_vf) <= vf <= vf_UB
                          HT_vb + C (vb_UB - HT_vb) <= vb <= vb_UB

z_HDE = 2: Down-regulated synthesis rate fir the targeted biocompounds:
                          vf_LB <= vf <= HT_vf + C (vf_LB - HT_vf)
                          vb_LB <= vb <= HT_vb + C (vb_LB - HT_vb)

z_HDE = 3: Knockout vf and vb: vf = vb = 0
where the regulation strength parameter (C) is provided by the user.

Fluxes are catalyzed by isozymes:
                        (1 - a) HT_vf <= vf <= (1 + a) HT_vf
                        (1 - a) HT_vb <= vb <= (1 + a) HT_vb                        

TR: treated CA model
PH: perturbed HT model
CA: cancer model
HT: healthy model
BL: union of CA and HT model

Index_sumz = 21 and 22: PHCA, PHHT
Index_sumz = 23 and 24: PHHT, TRHT
Index_sumz = 41 and 42: PHCA, PHHT, TRCA, TRHT

Fuzzy similarity: PHHT, TRHT
Fuzzy dissimilarity: PHCA

*----- fitness evaluation ------------------------------------------------------
* Metabolic deviation (dissimilarity) for PH model to CA template
best_mem_MD_PHCA = ((best_mem_rxn_PHCA + best_mem_Met_PHCA)/2 + min(best_mem_rxn_PHCA, best_mem_Met_PHCA))/2;

* Metabolic deviation (similarity) for PH model to HT template
best_mem_MD_PHHT = ((best_mem_rxn_PHHT + best_mem_Met_PHHT)/2 + min(best_mem_rxn_PHHT, best_mem_Met_PHHT))/2;

* Metabolic deviation (similarity) for TR model to HT template
best_mem_MD_TRHT = ((best_mem_rxn_TRHT + best_mem_Met_TRHT)/2 + min(best_mem_rxn_TRHT, best_mem_Met_TRHT))/2;

* Metabolic deviation (dissimilarity) for TR model to CA template
best_mem_MD_TRCA = ((best_mem_rxn_TRCA + best_mem_Met_TRCA)/2 + min(best_mem_rxn_TRCA, best_mem_Met_TRCA))/2;

* Metabolic deviation of fuzzy dissimilarity and similarity for PHCA, TRCA, TRHT, and PHHT
best_mem_MD_TP $ (index_sumz = 1 or index_sumz = 21 or index_sumz = 22) =
                 ((best_mem_MD_PHCA + best_mem_MD_PHHT)/2 + min(best_mem_MD_PHCA, best_mem_MD_PHHT))/2;

best_mem_MD_TP $ (index_sumz = 41 or index_sumz = 42) =
                 ((best_mem_MD_PHCA + best_mem_MD_PHHT + best_mem_MD_TRHT + best_mem_MD_TRCA)/4 +
                   min(best_mem_MD_PHCA, best_mem_MD_PHHT, best_mem_MD_TRHT, best_mem_MD_TRCA))/2;

* Metabolic deviation of fuzzy similarity for TRHT, and PHHT
best_mem_MD_TP $ (index_sumz = 23 or index_sumz = 24) =
                 ((best_mem_MD_TRHT + best_mem_MD_PHHT)/2 + min(best_mem_MD_TRHT, best_mem_MD_PHHT))/2;
                 
*----- prioity fitness evaluation ----------------------------------------------
best_constraint = constraint_FBA_TR + constraint_UFD_TR + constraint_FBA_PH + constraint_UFD_PH;
best_fitness $ (index_sumZ = 1) = mem_PriObj_Outer_TR;
best_fitness $ (index_sumZ = 21 or index_sumZ = 23 or index_sumz = 41) = (best_mem_CV_TR +
                                                                             min(best_mem_CV_TR, best_mem_CV_PH, best_mem_MD_TP))/2;
best_fitness $ (index_sumZ = 22 or index_sumZ = 24 or index_sumz = 42) = ((best_mem_CV_TR + best_mem_CV_PH)/2 +
                                                                             min(best_mem_CV_TR, best_mem_CV_PH, best_mem_MD_TP))/2;
best_fitness = best_fitness - best_constraint;
best_fitness $ (flag_sumZ = 1) = best_fitness + best_mem_sumZ;
*-------------------------------------------------------------------------------

$offtext

$offlisting
$offdigit

**** The user has to provide the following name --------------------------------
$setglobal modelName01 BL
$setglobal modelName02 AD
$setglobal modelName03 EC
$setglobal modelName04 CORDA
$setglobal modelName0 %modelName02%_%modelName03%_%modelName04%
$setglobal modelName1 %modelName01%-%modelName02%-%modelName03%
$setglobal modelName2 %modelName04%-R3D-CCU4-AD-TRIM63

$setglobal modelPath A0-Model-CABL-v2

* assign the path of the model data
$setglobal ModelData "C:\CBM-AD-ToolBox\%modelPath%\%modelName1%-%modelName2%\"

* assign the path of the computational results
$setglobal ReportData "C:\CBM-AD-ToolBox\A0-ReportData\"
*-------------------------------------------------------------------------------

**** modelName3 = Default, LeakyFree (User's provided) -------------------------
$setglobal modelName3 LeakyFree

**** version for medium provided by a user *************************************
$setglobal User_Medium DMEM

* index_sumz = 1, 21, 22, 23, 24, 41, 42
$setglobal No_index_sumZ 41
$setglobal No_flag_sumZ 0
$setglobal No_strategy 2

$setglobal No_uptake 2
$setglobal No_secretion 1
$setglobal No_DM_sink 1
$setglobal No_uptake_demand 1

$setglobal Model_Print %modelName02%_%modelName03%_%User_Medium%_%No_strategy%

* ObjFunction_UFD evalution
* No_UFD_Obj = 1: One norm excluded exchange_rxn; = 2: One norm included exchange_rxn
* No_UFD_Obj = 3: Two norm excluded exchange_rxn; = 4: Two norm included exchange_rxn
$setglobal No_UFD_Obj 2

*Candidate model for the drug target discovery problem: No_candidate_enz = CAHT or CA
$setglobal No_candidate_enz CA

* select regulated action for candidate_enz_g1(enzymes); 1: up, 2: down, 3: KO
$setglobal No_UpDownKO_min_g1 2
$setglobal No_UpDownKO_max_g1 3

* select regulated action for candidate_enz_g2(enzymes); 1: up, 2: down, 3: KO
$setglobal No_UpDownKO_min_g2 2
$setglobal No_UpDownKO_max_g2 3

$setglobal Enz_G1 'E0582'
$setglobal Enz_G2 'Down'
*-------------------------------------------------------------------------------

* The user needs to provide the following 6 includeed files for solving this problem ****************************************************************
$include %ModelData%A1-%modelName1%-%modelName2%-Model.gms
$include %ModelData%A1-%modelName1%-%modelName2%-GPRmodel.gms
$include %ModelData%A1-%modelName1%-%modelName2%-Weight-Rxn.gms
$include %ModelData%A2-%modelName1%-%modelName2%-Fuzzy-MultiObj.gms
$include %ModelData%A3-%modelName1%-%modelName2%-%modelName3%-Flux-bounds.gms
$include %ModelData%A3-%modelName1%-%modelName2%-uptake-Subset.gms
$include %ModelData%A4-%modelName1%-%modelName2%-Biocompound.gms

*$include %CandData%A5-%modelName1%-%modelName2%-%modelName3%-TRCA-CandEnz-%No_candidate_enz%-%No_uptake%%No_secretion%-%User_Medium%.gms
$include %ModelData%A5-%modelName1%-%modelName2%-Default-Cand-Enz-Met-Rxn.gms

$include %ModelData%A9-%modelName1%-%modelName2%-Species-Biocomp-ChokePt.gms

*---- prepare for writing the computational results ----------------------------
$set outputFilename1 z-%modelName1%-%modelName2%-s%No_strategy%-UFD%No_UFD_Obj%-%Enz_G1%-%Enz_G2%-%User_Medium%
$set outputFilename2 %modelName01%-%Model_Print%-Mem-Grades-%Enz_G1%-%Enz_G2%
*-------------------------------------------------------------------------------
*****************************************************************************************************************************************************

*===== the user provides the following data ====================================
$onempty
sets
   Candidate_Enz_g1(enzymes) "first group of candidate enzymes to be regulated"
      /'%Enz_G1%'/
  
   Candidate_Enz_g2(enzymes) "second group of candidate enzymes to be regulated"
*       /'%Enz_G2%'/
/
E0101
E0141
E0209
E0224
E0302
E0522
E0582
E0603
E0617
E0633
E0643
E0708
E0722
E0725
E0761
E0778
E0801
E0986
E1002
E1041
E1056
E1128
E1238
E1240
E1594
E1705
E1713
E1909
E2193
         
/

   excluded_candidate_Enz(enzymes) "enzymes are exclued from the candidate_enz"
           /  /

   excluded_candidate_Enz_g1(enzymes) "specific candidate enzymes are exclued from the candidate_enz_g1"
        / /

   excluded_candidate_Enz_g2(enzymes) "unspecific candidate enzymes are exclued from the candidate_enz_g2"
        / '%Enz_G1%'/

   print_BioComp(Biocompound) "print computational results provided by the user"
       /  /
   
   print_rxn(reactions) "print reaction fluxes provided by the user"
    /    /
      
   uptake_rxn(reactions) "uptake reactions"            
   secretion_rxn(reactions) "secretion reactions"
   BioComp_ExpWarb(biocompound) "sum of biocompound_exp and BioCompound_Warburg"
   BioComp_PHHT(biocompound) "the intersection of biocompounds for PH/HT models"
   species_PHHT(species) "the intersection of species for PH/HT models"
   rxn_vf_PHHT(reactions) "the intersection of reactions for PH/HT models"
   rxn_vb_PHHT(reactions) "the intersection of reactions for PH/HT models"
   BioComp_PHCA(biocompound) "the intersection of biocompounds for PH/CA models"
   species_PHCA(species) "the intersection of species for PH/CA models"
   rxn_vf_PHCA(reactions) "the intersection of reactions for PH/CA models"
   rxn_vb_PHCA(reactions) "the intersection of reactions for PH/CA models"
   BioComp_TRCA(biocompound) "the intersection of biocompounds for TR/CA models"
   species_TRCA(species) "the intersection of species for TR/CA models"
   rxn_vf_TRCA(reactions) "the intersection of reactions for TR/CA models"
   rxn_vb_TRCA(reactions) "the intersection of reactions for TR/CA models"    
   BioComp_TRHT(biocompound) "the intersection of biocompounds for TR/HT models"
   species_TRHT(species) "the intersection of species for TR/HT models"
   rxn_vf_TRHT(reactions) "the intersection of reactions for TR/HT models"
   rxn_vb_TRHT(reactions) "the intersection of reactions for TR/HT models"    
   Regulated_rxn_v(reactions) "dynamic subset1 for itermax to indicate for regulating up/down vb/vf"
   Regulated_rxn_vf(reactions) "dynamic subset1 for itermax to indicate for regulating up/down vf"
   Regulated_rxn_vb(reactions) "dynamic subset1 for itermax to indicate for regulating up/down vb"
   dyn_Reg_ExRxn(reactions) "regulated reactions for each individual"
   dyn_reactions(reactions) "dynamic subsets to declare the reactions in HT/CA model"
   dyn_species(species) "dynamic subsets to declare the species in HT/CA model"
   dyn_BioComp(Biocompound) "dynamic subsets to declare the biocompounds in HT/CA model"
   dyn_irrev_rxn(reactions) "dynamic subset for irrevsible reactions"
   dyn_rev_rxn(reactions) "dynamic subset for reversible reactions"    
   dyn_exchange_rxn(reactions) "dynamic subset for exchange reactions"
   dyn_ObjectSet(objectSet) "dynamic subsets of ObjectSet in inner optimization problem"
   dyn_Fmax_Object(objectSet) "dynamic subsets of fuzzy max Objectives in inner optimization problem"  
   dyn_Fmin_Object(objectSet) "dynamic subsets of fuzzy min Objectives in inner optimization problem"
   dyn_priority_obj(ObjectSet) "dynamic subset of priority objectives in inner optimization problem"
   dyn_obj_outer(objectSet) "dynamic subsets of ObjectSet in outer optimization problem"
   dyn_Fmax_Obj_outer(ObjectSet) "dynamic subsets of fuzzy max Objectives in outer optimization problem" 
   dyn_Fmin_Obj_outer(ObjectSet) "dynamic subsets of fuzzy min Objectives in outer optimization problem" 
   dyn_priority_outer(ObjectSet) "dynamic subset of priority objectives in outer optimization problem"  
   nonzero_v(reactions) "nonzero v between two models"
   nonzero_vf(reactions) "nonzero vf between two models"
   nonzero_vb(reactions) "nonzero vf between two models"
   nonzero_BioComp(biocompound) "nonzero biocomp_synth rate between two model";

**** reset reversible and irrevserable reactions ****************************************************************************************************
rev_rxn(reactions) = rev_rxn(reactions) + irrev2rev_rxn(reactions) + irrev_vb_rxn(reactions) - rev2irrev_rxn(reactions);
irrev_rxn(reactions) = irrev_rxn(reactions) + rev2irrev_rxn(reactions) - irrev2rev_rxn(reactions);

uptake_rxn(reactions) $ (uptake_rxn_%User_Medium%(reactions)) = yes;

secretion_rxn(reactions) = exchange_rxn(reactions) - uptake_rxn(reactions) - uptake_demand(reactions) -
                           exchange_demand(reactions) - secretion_demand(reactions);
*****************************************************************************************************************************************************
***** decide the Candidate_Enz_g1 by the user *******************************************************************************************************
*----- Using the following statement, excluded_candidate_Enz_g1 must be assigned as the empty set
excluded_candidate_Enz(enzymes) = excluded_candidate_Enz(enzymes) + transport_enz(enzymes) +
                                  Met_NonGPR_enz(enzymes) + exchange_enz(enzymes) + DM_sink_enz(enzymes);
if(card(Candidate_Enz_g2) = 0,
   Candidate_Enz_g2(enzymes) = feasible_enz(enzymes) - excluded_candidate_Enz(enzymes) - Candidate_Enz_g1(enzymes););

* delete unchangeable enzymes in Candidate_Enz_G2
excluded_candidate_Enz_g2(enzymes) $ (candidate_Enz_g2(enzymes) and sum(RegulationSet, (index_Enz_Reg(enzymes, RegulationSet) > 0) = 1) = 0) = yes;
excluded_candidate_Enz_g1(enzymes) $ (candidate_Enz_g1(enzymes) and sum(RegulationSet, (index_Enz_Reg(enzymes, RegulationSet) > 0) = 1) = 0) = yes;
Candidate_Enz_g1(enzymes) = Candidate_Enz_g1(enzymes) - excluded_candidate_Enz_g1(enzymes);
Candidate_Enz_g2(enzymes) = Candidate_Enz_g2(enzymes) - excluded_Candidate_Enz_g2(enzymes);
*****************************************************************************************************************************************************
sets
*----- define the sets for the HDE solver --------------------------------------
   Dim_XIR "total No. of regulated EnzRxn and No. of regulation strength parameter"
          /XI1*XI2, RSP1/

   Dim_XI1(Dim_XIR) "the specific Candidate Enzymes to be manipulated that are provided by the user"
          /XI1/

   Dim_XR(Dim_XIR) "No. of regulation strength parameter"
         /RSP1/

   NP "population size for HDE in the outer optimization program" /NP1*NP50/

   itermax "maximum of of iterations for HDE" /iter1*iter20/

   Dim_XI(Dim_XIR) "total No. of regulated EnzRxn"
   Dim_XI2(Dim_XIR) "the unspecific candidate Enzymes to be manipulated"

*----- iterate_DynSubset(nSolution) "dynamic subset for iteactively solving HDE
   itermax_DynSubset1(itermax) "dynamic subset1 for itermax"
   itermax_DynSubset2(itermax) "dynamic subset2 for itermax";
$offEmpty

Parameters      
*----- weighting factor depends on RNA-seq expression having HC, MC, NC and others 
   Weight_factor_Rxn_HC "weighting factor for rxn with high confidence" /0.25/
   Weight_factor_Rxn_MC "weighting factor for rxn with medium confidence" /0.5/
   Weight_factor_Rxn_NC "weighting factor for rxn with not detected" /0.75/
   Weight_factor_Rxn_OT "weighting factor for rxn with others" /1/  

   Weight_Lambda(ObjectSet) "weighting factor for MemObjvalue_FBA"
   flag_uptake "1: irreversible (vf = 0); 2: reversible (exchange)" /%No_uptake%/
   flag_secretion "1: irreversible (vb = 0); 2: reversible (exchange)" /%No_secretion%/
   flag_DM_sink "1: set DM_sink_rxn to irrev_rxn; 2: keep orignal setting" /%No_DM_sink%/
   flag_uptake_demand "1: irreversible (vf = 0); 2: reversible (exchange)" /%No_uptake_demand%/
   flag_UFD_Obj "selection of UDF_Obj for UFD problem" /%No_UFD_Obj%/    
   flag_BioComp "biocompound_PHBL inclues/excludes Warburg/Exp, 1: included; 2: excluded"  /1/
   mem_Bound_ratio "ratio of lower and upper bounds for membership function" /4/
   UB_zero "upper bound for flux with zero value" /1.0E-5/
   
* flux bounded ratio is restricted by isozymes: (1 - a) vf_basal <= vf <=  (1 + a)*vf_basal
   flux_bounded_ratio "ratio for evaluating lower and upper bounds of reactions catalyzed isozymes" /0.03/

*%%%%% the user can modify the following procedures %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
*----- parameters provided for HDE ---------------------------------------------
   index_sumZ "index_sumZ = 20 or 40: fitness evaluation method" /%No_index_sumZ%/
   flag_sumZ "flag_sumZ = 0: sum(z) is not included in fitness; flag_sumZ = 1: fitness including sum(z)" /%No_flag_sumZ%/
   strategy "strategy (1-10) of mutation operation used in HDE"  /%No_strategy%/
   extra_gene_min "extra number of genes is added sumZ_min for evaluating pop_Mem_sumZ(NP)"  /0/
   Method_1 "user provided the migration or not, Method_1 = 0: switched off migration" /1/
   Method_4 "user provided the initinal population, method_4 = 1"  /0/
*  method_5 = 0: fixed F_X for all NP
*  method_5 = 1, 2: F_X = uniform(F_XLB, F_XUB)
*  method_5 = 3, 4: F_X = F_XLB + uniform(0,1) * F_XUB; self-adapting parameter
*  method_5 = 1, 3: identical F_X for all NP
*  method_5 = 2, 4: F_X(NP) for each NP
   Method_5 "method of mutation factor" /1/
   Method_S "Method_S = 1 random mutation stratey; Method_S = 0 user strategy"  /0/
   
   F_XLB "lower bound of mutation scaling factor" /0.1/
   F_XUB "upper bound of mutation scaling factor" /0.9/
   F_eps "criterion for self-adpating parameter F_XR" /0.2/
   CR_eps "criterion for self-adpating parameter CR_XR" /0.2/
   F_XNP "initial identical mutation factor, method_5 = 0" /0.8/   
   CR_XNP "initial identical crossover factor, method_5 = 0" /0.8/
   Method_6 "user provided the force migration if index_migration >= method_6" /5/
   VTR "expected fitness value to reach"  /1.0e20/
   VTR_G "expected constrained tolerance to reach" /0.0/
   epsilon_ratio "ratio for tolerance of  population diversity, [0, 1]" /0.05/
   epsilon1 "tolerance of population diversity, epsilon1 = epsilon_ratio * card(Dim_XI)/card(Dim_BI)"
   epsilon2 "tolerance for gene diversity" /0.01/
   penalty "penalty paramter for evaluating infeasible inner optimization problem" /1.0e3/
   penalty_update_ratio "penalty parameter updating ratio" /10/
   nPenalty_update "number of penalty updating" /4/
   flag_Noncandidate_enz "flag used to indicate whether some extra reactions to be excluded in the candidate_enz, flag_exxlude = 0: do nothing"  / 1/
   tol_eps "numerical tolerance" /1.0e-12/
   tol_constraint "tolerance for best_constraints" /1.0e-6/
*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

   target_limit(targetSet) "limits for desired target"
   index_rxn(reactions) "indicator, index_rxn = 1: irreversible reactions; index_rxn = 2: reversible reactions"
   FluxBound_vf_LB(reactions) "lower bound for each forward flux"
   FluxBound_vf_UB(reactions) "upper bound for each forward flux"
   FluxBound_vb_LB(reactions) "lower bound for each backward flux"
   FluxBound_vb_UB(reactions) "upper bound for each backward flux"
   FluxBound_v_LB(reactions) "lower bound for each net flux"
   FluxBound_v_UB(reactions) "upper bound for each net flux"
   tmp_FluxBound_vf_LB(reactions) "lower bound for each forward flux"
   tmp_FluxBound_vf_UB(reactions) "upper bound for each forward flux"
   tmp_FluxBound_vb_LB(reactions) "lower bound for each backward flux"
   tmp_FluxBound_vb_UB(reactions) "upper bound for each backward flux"    
   MultiObj_weight(ObjectSet) "weight of multiobjectives for CA and HT model"
   coef_CellularObj_vf(ObjectSet, reactions) "cellular objective coefficients for vf"
   coef_CellularObj_vb(ObjectSet, reactions) "cellular objective coefficients for vb"
   index_HT_rxn_wt(reactions) "index of weighting parameter for HT reactions: HC = 4, MC = 3, NC = 2, OT = 1"
   index_CA_rxn_wt(reactions) "index of weighting parameter for CA reactions: HC = 4, MC = 3, NC = 2, OT = 1"
   TR_Reg_Factor_min(Dim_XR) "min bound of regulation strength parameter for up/down regulation"
   TR_Reg_Factor_max(Dim_XR) "max bound of regulation strength parameter for up/down regulation"
   weight_coef_rxn(reactions) "weighting coefficients of rxn for computing objective in UFD"
   MultiObjValue_min(ObjectSet) "minimum values for multiobjectives in inner and outer optimization problem"
   MultiObjValue_max(ObjectSet) "maximum values for multiobjectives in inner and outer optimization problem";     

***** Define sets for computing fuzzy dissimilarity and fuzzy similariy objectives in the outer optimization problem ********************************
*** assign the set of experiments and Warburg observations
BioComp_ExpWarb(biocompound) = biocompound_exp(biocompound) + BioCompound_Warburg(biocompound);

*** Assign the set of fuzzy dissimilarity objectives for PHCA model
BioComp_PHCA(biocompound) $ (not biocompound_NCA(biocompound) and not biocompound_NHT(biocompound)) = yes;
Species_PHCA(Species) $ (not species_NCA(species) and not species_NHT(species)) = yes;
rxn_vf_PHCA(reactions) $ (not reactions_NCA(reactions) and not reactions_NHT(reactions)) = yes;
rxn_vb_PHCA(reactions) $ (not reactions_NCA(reactions) and not reactions_NHT(reactions) and rev_rxn(reactions)) = yes;

*** Assign the set of fuzzy dissimilarity objectives for TRCA model
BioComp_TRCA(biocompound) $ (not biocompound_NCA(biocompound)) = yes;
Species_TRCA(Species) $ (not species_NCA(species)) = yes;
rxn_vf_TRCA(reactions) $ (not reactions_NCA(reactions)) = yes;
rxn_vb_TRCA(reactions) $ (not reactions_NCA(reactions) and rev_rxn(reactions)) = yes;

*** Assign the set of fuzzy similarity objectives for PHHT model
BioComp_PHHT(biocompound) $ (not biocompound_NHT(biocompound)) = yes;
Species_PHHT(Species) $ (not species_NHT(species)) = yes;
rxn_vf_PHHT(reactions) $ (not reactions_NHT(reactions)) = yes;
rxn_vb_PHHT(reactions) $ (not reactions_NHT(reactions) and rev_rxn(reactions)) = yes;

*** Assign the set of fuzzy similarity objectives for TRHT model
BioComp_TRHT(biocompound) $ (not biocompound_NCA(biocompound) and not biocompound_NHT(biocompound)) = yes;
Species_TRHT(Species) $ (not species_NCA(species) and not species_NHT(species)) = yes;
rxn_vf_TRHT(reactions) $ (not reactions_NCA(reactions) and not reactions_NHT(reactions)) = yes;
rxn_vb_TRHT(reactions) $ (not reactions_NCA(reactions) and not reactions_NHT(reactions) and rev_rxn(reactions)) = yes;
*****************************************************************************************************************************************************

*** Excluded the set of experiments and Warburg observations to compute fuzzy dissimilarty and similarity objectives in outer optimization problem
if(flag_BioComp = 2,
   Biocomp_PHCA(biocompound) = no;
   Biocomp_TRCA(biocompound) = no;   
   Biocomp_PHHT(biocompound) = no;
   Biocomp_TRHT(biocompound) = no;   
   BioComp_PHCA(biocompound) $ (not BioComp_ExpWarb(biocompound) and not biocompound_NCA(biocompound) and not biocompound_NHT(biocompound)) = yes;
   BioComp_TRCA(biocompound) $ (not BioComp_ExpWarb(biocompound) and not biocompound_NCA(biocompound)) = yes;   
   Biocomp_PHHT(biocompound) $ (not BioComp_ExpWarb(biocompound) and not biocompound_NHT(biocompound)) = yes;
   Biocomp_TRHT(biocompound) $ (not BioComp_ExpWarb(biocompound) and not biocompound_NCA(biocompound) and not biocompound_NHT(biocompound)) = yes; 
);
*****************************************************************************************************************************************************

*%%%%% the user can modify the following procedures %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
*  max bound of regulation strength parameter for up/down regulation
TR_Reg_Factor_min(Dim_XR) = 0.01;
TR_Reg_Factor_max(Dim_XR) = 1;

***** Check weighting factor **************************************************
if(((card(HT_Reactions_HC) + card(HT_Reactions_MC) + card(HT_Reactions_NC) +
     card(CA_Reactions_HC) + card(CA_Reactions_MC) + card(CA_Reactions_NC)) = 0),
     Weight_factor_Rxn_HC = Weight_factor_Rxn_OT; 
     Weight_factor_Rxn_MC = Weight_factor_Rxn_OT;
     Weight_factor_Rxn_NC = Weight_factor_Rxn_OT;);
*******************************************************************************
     
* indicator for irreversible or reversible reactions
index_rxn(irrev_rxn) = 1;
index_rxn(rev_rxn) = 2;

* 4 = High confidence; 3 = medium confidence; 2 = negative confidence; 1 = other confidence; 0 = rxn_NCA or NHT
index_HT_rxn_wt(reactions) = 1;
index_HT_rxn_wt(HT_Reactions_NC) = 2;
index_HT_rxn_wt(HT_Reactions_MC) = 3;
index_HT_rxn_wt(HT_Reactions_HC) = 4;
index_HT_rxn_wt(reactions) $ (reactions_NHT(reactions))= 0;

index_CA_rxn_wt(reactions) = 1;
index_CA_rxn_wt(CA_Reactions_NC) = 2;
index_CA_rxn_wt(CA_Reactions_MC) = 3;
index_CA_rxn_wt(CA_Reactions_HC) = 4;
index_CA_rxn_wt(reactions) $ (reactions_NCA(reactions))= 0;

***** assign objective coefficient ******************************************************************************************************************
coef_CellularObj_vf(syn_vf_rxn(objectSet, reactions)) = 1;
coef_CellularObj_vb(syn_vb_rxn(objectSet, reactions)) = 1;

coef_CellularObj_vf(deg_vf_rxn(objectSet, reactions)) = -1;
coef_CellularObj_vb(deg_vb_rxn(objectSet, reactions)) = -1;
*****************************************************************************************************************************************************

*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
*%%%%% assign the initial flux bounds from leaky dataset %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
FluxBound_vf_LB(reactions) = vf_initial_LB(reactions);
FluxBound_vb_LB(reactions) = vb_initial_LB(reactions);
FluxBound_vf_UB(reactions) = vf_initial_UB(reactions);
FluxBound_vb_UB(reactions) = vb_initial_UB(reactions);

***** assgin the upper bounds of irreversible reactions and backward irreversible reactions to be zero
FluxBound_vb_UB(reactions) $ (irrev_rxn(reactions)) = 0;
FluxBound_vf_LB(reactions) $ (irrev_vb_rxn(reactions)) = 0;
FluxBound_vf_UB(reactions) $ (irrev_vb_rxn(reactions)) = 0;

*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

***** set DM_sink_rxn secretion_rxn to irreversible reactions ******************
if(flag_DM_sink = 1,
   FluxBound_vf_LB(DM_sink_rxn) = vf_initial_LB(DM_sink_rxn);
   FluxBound_vf_UB(DM_sink_rxn) = vf_initial_UB(DM_sink_rxn);
   FluxBound_vb_LB(DM_sink_rxn) = 0;
   FluxBound_vb_UB(DM_sink_rxn) = 0;);

*$ontext
***** uptake_rxn assigns as irreversible reactions
if(flag_uptake = 1,
   FluxBound_vf_LB(uptake_rxn) = 0;
   FluxBound_vf_UB(uptake_rxn) = 0;
   FluxBound_vb_LB(uptake_rxn) = vb_initial_LB(uptake_rxn);;
   FluxBound_vb_UB(uptake_rxn) = vb_initial_UB(uptake_rxn););

***** uptake_rxn assigns as reversible (exchange) reactions
if(flag_uptake = 2,
   FluxBound_vf_LB(uptake_rxn) = vf_initial_LB(uptake_rxn);
   FluxBound_vf_UB(uptake_rxn) = vf_initial_UB(uptake_rxn);
   FluxBound_vb_LB(uptake_rxn) = vb_initial_LB(uptake_rxn);
   FluxBound_vb_UB(uptake_rxn) = vb_initial_UB(uptake_rxn););

***** secretion_rxn assigns as irreversible reactions
if(flag_secretion = 1,
   FluxBound_vf_LB(secretion_rxn) = vf_initial_LB(secretion_rxn);
   FluxBound_vf_UB(secretion_rxn) = vf_initial_UB(secretion_rxn);
   FluxBound_vb_LB(secretion_rxn) = 0;
   FluxBound_vb_UB(secretion_rxn) = 0;);


***** secretion_rxn assigns as reversible (exchange) reactions
if(flag_secretion = 2,
   FluxBound_vf_LB(secretion_rxn) = vf_initial_LB(secretion_rxn);
   FluxBound_vf_UB(secretion_rxn) = vf_initial_UB(secretion_rxn);
   FluxBound_vb_LB(secretion_rxn) = vb_initial_LB(secretion_rxn);
   FluxBound_vb_UB(secretion_rxn) = vb_initial_UB(secretion_rxn););
*$offText

*****************************************************************************************************************************************************
FluxBound_vf_LB(exchange_demand) $ (card(exchange_demand) > 0) = vf_initial_LB(exchange_demand);
FluxBound_vf_UB(exchange_demand) $ (card(exchange_demand) > 0) = vf_initial_UB(exchange_demand);
FluxBound_vb_LB(exchange_demand) $ (card(exchange_demand) > 0) = vb_initial_LB(exchange_demand);
FluxBound_vb_UB(exchange_demand) $ (card(exchange_demand) > 0) = vb_DM_Exchange_UB(exchange_demand);

if(flag_uptake_demand = 1,
   FluxBound_vf_LB(uptake_demand) $ (card(uptake_demand) > 0) = 0;
   FluxBound_vf_UB(uptake_demand) $ (card(uptake_demand) > 0) = 0;);

if(flag_uptake_demand = 2,
   FluxBound_vf_LB(uptake_demand) $ (card(uptake_demand) > 0) = vf_initial_LB(uptake_demand);
   FluxBound_vf_UB(uptake_demand) $ (card(uptake_demand) > 0) = vf_initial_UB(uptake_demand););

FluxBound_vb_LB(uptake_demand) $ (card(uptake_demand) > 0) = vb_DM_uptake_LB(uptake_demand);
FluxBound_vb_UB(uptake_demand) $ (card(uptake_demand) > 0) = vb_DM_uptake_UB(uptake_demand);

FluxBound_vb_LB(secretion_demand) $ (card(secretion_demand) > 0) = 0;
FluxBound_vb_UB(secretion_demand) $ (card(secretion_demand) > 0) = 0;
*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

*--- set the oringinal bounds for all fluxes --------------------------------------------------------------------------------------------------------
tmp_FluxBound_vf_LB(reactions) = FluxBound_vf_LB(reactions);
tmp_FluxBound_vb_LB(reactions) = FluxBound_vb_LB(reactions);
tmp_FluxBound_vf_UB(reactions) = FluxBound_vf_UB(reactions);
tmp_FluxBound_vb_UB(reactions) = FluxBound_vb_UB(reactions);
*----------------------------------------------------------------------------------------------------------------------------------------------------

FluxBound_v_LB(reactions) = FluxBound_vf_LB(reactions) - FluxBound_vb_UB(reactions);
FluxBound_v_UB(reactions) = FluxBound_vf_UB(reactions) - FluxBound_vb_LB(reactions);

*----- MultiObjValue_min and multiObjValue_max are computed by a user provided vf_UB and vb_UB -----------------------------------------------------
MultiObjValue_min(ObjectSet) =  sum(reactions, coef_CellularObj_vf(ObjectSet, reactions) * MultiObjValue_vf_LB(reactions)) +
                                sum(reactions, coef_CellularObj_vb(ObjectSet, reactions) * MultiObjValue_vb_LB(reactions));
                                
MultiObjValue_max(ObjectSet) =  sum(reactions, coef_CellularObj_vf(ObjectSet, reactions) * MultiObjValue_vf_UB(reactions)) +
                                sum(reactions, coef_CellularObj_vb(ObjectSet, reactions) * MultiObjValue_vb_UB(reactions));
*****************************************************************************************************************************************************

*%%%%% solver options %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
options
* LPSolvers "LP solver option"
*     /BARON, BDMLP, CBC, CONOPT, CPLEX, CPLEXD, GUROBI, IPOPTH, KNITRO, LINDO, MINOS, SNOPT, XPRESS/
   LP = BARON

* QCPsolver "solver option"
*     /BARON, CONOPT, COUENNE, CPLEX, CPLEXD, GUROBI, IPOPTH, KNITRO, LINDO, MINOS, SCIP, SNOPT, XPRESS/
   QCP = BARON

* relative optimality criterion
*   optcr = 1.0e-8

* To assign GAMS to be less disk active
*   solvelink = 5 
 
* maximum time available to solve in seconds
   reslim = 100000

* equations listed per block
   limrow = 0

* variables listed per block
   limcol = 0

* solver's solution output printed
   solprint = off

* solver's system output printed
   sysout = off;
*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

* determine flux distributions for normal and abnormal state -------------------
Parameters
   count, number1, number2 "count number"
   startTime, endTime, elapsedTime "CPU time accounting indices"
   HT_Species_SynRate(species) "healthy synthesis rate for each species"
   HT_BioComp_SynRate(BioCompound) "healthy synthesis rate for each BioCompound"
   tmp_vf_FBA(reactions) "tmp FBA forward fluxes"
   tmp_vb_FBA(reactions) "tmp FBA backward fluxes"
   tmp_MultiObjvalue_Optim(Objectset) "tmp multiobjectives for FBA problem"
   HT_vf_FBA(reactions)  "healthy FBA forward fluxes"
   HT_vb_FBA(reactions)  "healthy FBA backward fluxes"
   HT_v_FBA(reactions)  "healthy net FBA fluxes"
   HT_vf_UFD(reactions)  "healthy UFD forward fluxes"
   HT_vb_UFD(reactions)  "healthy UFD backward fluxes"
   HT_v_UFD(reactions)  "healthy UFD fluxes"
   HT_FBA_ModelStat "healthy FBA Problem model state"
   HT_UFD_ModelStat "healthy UFD model stat"
   CA_Species_SynRate(Species)  "disease synthesis rate for each species"
   CA_BioComp_SynRate(BioCompound) "disease synthesis rate for each biocompound"
   CA_vf_FBA(reactions)  "disease FBA forward fluxes"
   CA_vb_FBA(reactions)  "disease FBA backward fluxes"
   CA_vf_UFD(reactions) "disease UFD forward fluxes"
   CA_vb_UFD(reactions) "disease UFD backward fluxes"
   CA_v_UFD(reactions) "disease UFD net fluxes"
   CA_FBA_ModelStat "disease FBA Problem model state"
   CA_UFD_ModelStat "disease UFD Problem model state"
   TR_Species_SynRate(species) "treated synthesis rate for each species"
   TR_BioComp_SynRate(BioCompound) "treated synthesis rate for each BioCompound"
   TR_vf_UFD(reactions) "treated UFD forward fluxes"
   TR_vb_UFD(reactions) "treated UFD backward fluxes"
   TR_v_UFD(reactions) "treatedd UFD net fluxes"
   TR_FBA_ModelStat "treated FBD Problem model state"
   TR_UFD_ModelStat "treated UFD Problem model state"
   PH_Species_SynRate(species) "perturbed synthesis rate for each species"
   PH_BioComp_SynRate(BioCompound) "perturbed synthesis rate for each BioCompound"
   PH_vf_FBA(reactions) "perturbed FBA forward fluxes, vf"
   PH_vb_FBA(reactions) "perturbed FBA backward fluxes, vb"
   PH_v_FBA(reactions) "perturbed FBA net fluxes, v = vf - vb"
   PH_vf_UFD(reactions) "perturbed UFD forward fluxes"
   PH_vb_UFD(reactions) "perturbed UFD backward fluxes"
   PH_v_UFD(reactions) "perturbed UFD net fluxes"
   PH_FBA_ModelStat "perturbed FBD Problem model state"
   PH_UFD_ModelStat "perturbed UFD Problem model state"
   HT_MetFlowRate_LB(biocompound) "lower bound for HT synthesis rate of each biocompound"
   HT_MetFlowRate_UB(biocompound) "upper bound for HT synthesis rate of each biocompound"
   HT_SpeciesFlowRate_LB(species) "lower bound for HT synthesis rate of each species"
   HT_SpeciesFlowRate_UB(species) "upper bound for HT synthesis rate of each species"
   HT_vf_rxn_LB(reactions) "lower bound for HT vf flux of each forward reaction"
   HT_vb_rxn_LB(reactions) "lower bound for HT vb flux of each backward reaction"
   HT_vf_rxn_UB(reactions) "upper bound for HT vf flux of each forward reaction"
   HT_vb_rxn_UB(reactions) "upper bound for HT vb flux of each backward reaction"   
   CA_MetFlowRate_LB(biocompound) "lower bound for CA synthesis rate of each biocompound"
   CA_MetFlowRate_UB(biocompound) "upper bound for CA synthesis rate of each biocompound"   
   CA_SpeciesFlowRate_LB(species) "lower bound for CA synthesis rate of each species"
   CA_SpeciesFlowRate_UB(species) "upper bound for CA synthesis rate of each species"
   CA_vf_rxn_LB(reactions) "lower bound for CA vf flux of each forward reaction"
   CA_vb_rxn_LB(reactions) "lower bound for CA vb flux of each backward reaction"
   CA_vf_rxn_UB(reactions) "upper bound for CA vf flux of each forward reaction"
   CA_vb_rxn_UB(reactions) "upper bound for CA vb flux of each backward reaction" 
   mem_FObj_CV_TR(ObjectSet) "membership function of fuzzy objectives for CV of TR model"
   mem_FObj_CV_PH(ObjectSet) "membership function of fuzzy objectives for CV of PH model"
   L_mem_Met_Exp(BioCompound) "left membership function of synthesis rate to experiment"
   R_mem_Met_Exp(BioCompound) "right membership function of synthesis rate to experiment"   
   L_mem_Met_tmp(BioCompound) "left membership function of synthes rate for temporary models"
   R_mem_Met_tmp(BioCompound) "right membership function of synthesis rate for temporary models"   
   mem_Met_tmp(Biocompound) "equal membership grade of synthesis rate for temporary models"   
   mem_Met_Exp(BioCompound) "eual membership grade of PHBL synthesis rate to experiment"   
   L_mem_vf_tmp(reactions) "left membership function of vf for temporary models"
   L_mem_vb_tmp(reactions) "left membership function of vb for temporary models"
   R_mem_vf_tmp(reactions) "right membership function of vf for temporary models"
   R_mem_vb_tmp(reactions) "right membership function of vb for temporary models"   
   mem_vf_tmp(reactions) "equal membership grade of vf for temporary models"
   mem_vb_tmp(reactions) "equal membership grade of vf for temporary models"   
   mem_PriObj_Outer_TR  "priority objective value for outer optimization problem"
   mem_PriObj_Outer_PH  "priority objective value for outer optimization problem"     
   target_limit_LB(targetSet) "limits for desired target forward reactions"
   target_limit_UB(targetSet) "limits for desired target forward reactions"
   basal_vf(reactions) "basal vf used for computing CA/HT/PH model"
   basal_vb(reactions) "basal vb used for computing CA/HT/PH model"
   Mem_Obj_FBA_limit(ObjectSet) "limits of fuzzy multiobjectives for UFD problem"
   NO_priority_obj "number of priority_objective functions"
   NO_priority_outer "number of priority_objective functions in outer optimization problem"
   NO_nonzero_v_PHHT "No. of nonzero v for PH and HT models"
   NO_nonzero_vf_PHHT "No. of nonzero vf for PH and HT models"
   NO_nonzero_vb_PHHT "No. of nonzero vb for PH and HT models"   
   NO_nonzero_BioComp_PHHT "No. of nonzero biocomp_synth rate for PH and HT models"
   NO_nonzero_v_PHCA "No. of nonzero v for PH and CA models"
   NO_nonzero_vf_PHCA "No. of nonzero vf for PH and CA models"
   NO_nonzero_vb_PHCA "No. of nonzero vb for PH and CA models"   
   NO_nonzero_BioComp_PHCA "No. of nonzero biocomp_synth rate for PH and CA models"
   NO_nonzero_v_TRCA "No. of nonzero v for TR and CA models"
   NO_nonzero_vf_TRCA "No. of nonzero vf for TR and CA models"
   NO_nonzero_vb_TRCA "No. of nonzero vb for TR and CA models"   
   NO_nonzero_BioComp_TRCA "No. of nonzero biocomp_synth rate for TR and CA models"    
   NO_nonzero_v_TRHT "No. of nonzero v for TR and HT models"
   NO_nonzero_vf_TRHT "No. of nonzero vf for TR and HT models"
   NO_nonzero_vb_TRHT "No. of nonzero vb for TR and HT models"   
   NO_nonzero_BioComp_TRHT "No. of nonzero biocomp_synth rate for TR and HT models"
   TR_Mem_Obj_FBA_limit(ObjectSet) "limits of fuzzy multiobjectives for UFD problem"
   PH_Mem_Obj_FBA_limit(ObjectSet) "limits of fuzzy multiobjectives for UFD problem"
   HT_Mem_Obj_FBA_limit(ObjectSet) "limits of fuzzy multiobjectives for UFD problem"
   CA_Mem_Obj_FBA_limit(ObjectSet) "limits of fuzzy multiobjectives for UFD problem"   
   TR_MultiObjvalue_Optim(objectset)  "store optimal BL objective values"
   PH_MultiObjvalue_Optim(objectset)  "store optimal BL objective values"   
   HT_MultiObjvalue_Optim(objectset)  "store optimal HT objective values"
   CA_MultiObjvalue_Optim(objectset)  "store optimal CA objective values"
   No_iden_enz_BL(enzymes) "No. of identical enzymes for each feasible enzyme in BL model"
   No_iden_enz_CA(enzymes) "No. of identical enzymes for each feasible enzyme in CA model"
   No_iden_enz_HT(enzymes) "No. of identical enzymes for each feasible enzyme in HT model"
   No_isozymes_BL(enzymes) "No. of isozymes for each feaible enzyme in BL model"
   No_isozymes_CA(enzymes) "No. of isozymes for each feaible enzyme in CA model"
   No_isozymes_HT(enzymes) "No. of isozymes for each feaible enzyme in HT model";

*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
free Variables
   ObjValue_FBA "Cellular objective for basal FBA problem"
   S_ObjValue_FBA "single objective for basal FBA problem"   
   ObjValue_UFD "sum of squre fluxes for determining Uniformed flux distribution";

positive variables
   MultiObjvalue_FBA(ObjectSet) "multi-cellular objectives for FBA problem"
   Mem_Objvalue_FBA(objectSet) "membership objective functiona for FBA problem"
   Lambda "equivalent min value"
   vf(reactions)  "forward fluxes"
   vb(reactions) "backward fluxes";

equations
   dxdt(species) "material balance equations for the metabolic networks"
   ObjFunction_FBA "cellular objective for FBA problem"
   S_ObjFunction_FBA "Single objective for FBA problem"    
   Mem_FuzzyMax_Obj_FBA(objectSet) "Membership grade for fuzzy max objectives for FBA problem"
   Mem_FuzzyMin_Obj_FBA(objectSet) "Membership grade for fuzzy min objectives for FBA problem"   
   MultiObjFunction_FBA(ObjectSet) "multi-cellular objectives for basal FBA problem"
   ObjFunction_UFD1 "One norm excluded exhange_rxn for UFD problem"
   ObjFunction_UFD2 "One norm included exhange_rxn for UFD problem"
   ObjFunction_UFD3 "Two norm excluded exhange_rxn for UFD problem"
   ObjFunction_UFD4 "Two norm included exhange_rxn for UFD problem"   
   InEqual_MemObjvalue_FBA(objectSet)"inequality constraints for equivalent FBA problem"
   InEqual_ObjFTN_UFD(ObjectSet) "inequality constraint of the optimal cellular objective for the basal FBA"
   Inequal_target_LB(targetSet) "limits for desired target forward reactions"
   Inequal_target_UB(targetSet) "limits for desired target2 forward reactions";

* flux balance model
dxdt(dyn_species)..
   sum(dyn_reactions, S_matrix(dyn_species, dyn_reactions) * (vf(dyn_reactions) - vb(dyn_reactions))) =e= 0.0;

* lower bound for target reactions
Inequal_target_LB(targetSet)..
   target_limit_LB(targetSet) =l= vf(targetSet) - vb(targetSet);

* upper bound for target reactions
Inequal_target_UB(targetSet)..
   vf(targetSet) - vb(targetSet) =l= target_limit_UB(targetSet);

* multi-objective function values
MultiObjFunction_FBA(dyn_ObjectSet)..
   MultiObjValue_FBA(dyn_ObjectSet) =e= sum(dyn_reactions, coef_CellularObj_vf(dyn_ObjectSet, dyn_reactions) * vf(dyn_reactions)) +
                                        sum(dyn_reactions, coef_CellularObj_vb(dyn_ObjectSet, dyn_reactions) * vb(dyn_reactions));

* membership for fuzzy max objective Functions
Mem_FuzzyMax_Obj_FBA(dyn_Fmax_Object)..
   mem_objvalue_FBA(dyn_Fmax_Object) =e= (MultiObjValue_FBA(dyn_Fmax_Object) - MultiObjValue_min(dyn_Fmax_Object))/
                                         (MultiObjValue_max(dyn_Fmax_Object) - MultiObjValue_min(dyn_Fmax_Object));
                                          
* membership for fuzzy max objective Functions
Mem_FuzzyMin_Obj_FBA(dyn_Fmin_Object)..
   mem_objvalue_FBA(dyn_Fmin_Object) =e= (MultiObjValue_max(dyn_Fmin_Object) - MultiObjValue_FBA(dyn_Fmin_Object))/
                                         (MultiObjValue_max(dyn_Fmin_Object) - MultiObjValue_min(dyn_Fmin_Object));

* single objective function for FBA problem
S_ObjFunction_FBA..
  S_ObjValue_FBA =e= sum(dyn_ObjectSet, MultiObjValue_FBA(dyn_ObjectSet)); 

* objective function for FBA problem
ObjFunction_FBA..
   ObjValue_FBA =e= 0.5 * (sum(dyn_ObjectSet $ (dyn_priority_obj(dyn_ObjectSet)),
                               mem_objvalue_FBA(dyn_ObjectSet))/NO_priority_obj + Lambda);
   
* inequality constraints for equivalent FBA problem
InEqual_MemObjvalue_FBA(dyn_objectSet)..
   Lambda =l= weight_Lambda(dyn_ObjectSet) * mem_objvalue_FBA(dyn_ObjectSet);

* objective for determining the Uniformed flux distribution: One Norm parsimonious flux balance analysis
ObjFunction_UFD1..
   ObjValue_UFD =e= sum(dyn_reactions $ (not exchange_rxn(dyn_reactions)),
                        weight_coef_rxn(dyn_reactions) * (vf(dyn_reactions) + vb(dyn_reactions)));
                        
ObjFunction_UFD2..
   ObjValue_UFD =e= sum(dyn_reactions,
                        weight_coef_rxn(dyn_reactions) * (vf(dyn_reactions) + vb(dyn_reactions)));
                        
* objective for determining the Uniformed flux distribution: One Norm parsimonious flux balance analysis
ObjFunction_UFD3..                       
   ObjValue_UFD =e= sum(dyn_reactions $ (not exchange_rxn(dyn_reactions)), weight_coef_rxn(dyn_reactions) *
                                        (sqr(vf(dyn_reactions)) + sqr(vb(dyn_reactions))));
                                        
* objective for determining the Uniformed flux distribution: One Norm parsimonious flux balance analysis
ObjFunction_UFD4..                       
   ObjValue_UFD =e= sum(dyn_reactions, weight_coef_rxn(dyn_reactions) *
                                        (sqr(vf(dyn_reactions)) + sqr(vb(dyn_reactions))));

                        
* inequality constraint to obtain the identical optimal cellular objective value
InEqual_ObjFTN_UFD(dyn_ObjectSet)..
   mem_objvalue_FBA(dyn_ObjectSet) =g= Weight_Lambda(dyn_ObjectSet) * Mem_Obj_FBA_limit(dyn_ObjectSet);

model
   Single_FBA_Problem
      /dxdt, Inequal_target_LB, Inequal_target_UB, MultiObjFunction_FBA, S_ObjFunction_FBA/;

model
   FBA_Problem
      /dxdt, Inequal_target_LB, Inequal_target_UB, MultiObjFunction_FBA, Mem_FuzzyMax_Obj_FBA, Mem_FuzzyMin_Obj_FBA,
       InEqual_MemObjvalue_FBA, ObjFunction_FBA/;

model
   UFD1_Problem
     /dxdt, Inequal_target_LB, Inequal_target_UB, MultiObjFunction_FBA,  Mem_FuzzyMax_Obj_FBA, Mem_FuzzyMin_Obj_FBA,
      InEqual_ObjFTN_UFD, ObjFunction_UFD1/;
      
model
   UFD2_Problem
     /dxdt, Inequal_target_LB, Inequal_target_UB, MultiObjFunction_FBA,  Mem_FuzzyMax_Obj_FBA, Mem_FuzzyMin_Obj_FBA,
      InEqual_ObjFTN_UFD, ObjFunction_UFD2/;
      
model
   UFD3_Problem
     /dxdt, Inequal_target_LB, Inequal_target_UB, MultiObjFunction_FBA,  Mem_FuzzyMax_Obj_FBA, Mem_FuzzyMin_Obj_FBA,
      InEqual_ObjFTN_UFD, ObjFunction_UFD3/;
      
model
   UFD4_Problem
     /dxdt, Inequal_target_LB, Inequal_target_UB, MultiObjFunction_FBA,  Mem_FuzzyMax_Obj_FBA, Mem_FuzzyMin_Obj_FBA,
      InEqual_ObjFTN_UFD, ObjFunction_UFD4/; 
*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

*$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
***** Fuzzy multiobjective inner HT FBA Problem *****************************************************************************************************
***** assign reactions and species in CA models as dynamic sets ****************
dyn_reactions(reactions) = no;
dyn_species(species) = no;
dyn_BioComp(biocompound) = no;
dyn_irrev_rxn(reactions) = no;
dyn_rev_rxn(reactions) = no;
dyn_exchange_rxn(reactions) = no;
dyn_objectSet(objectSet) = no;
dyn_Fmax_Object(ObjectSet) = no;
dyn_Fmin_Object(ObjectSet) = no;
dyn_priority_obj(ObjectSet) = no;
dyn_reactions(reactions) $ (not reactions_NHT(reactions)) = yes;
dyn_species(species) $ (not species_NHT(species)) = yes;
dyn_BioComp(biocompound) $ (not biocompound_NHT(biocompound)) = yes;
dyn_irrev_rxn(reactions) $ (not reactions_NHT(reactions) and irrev_rxn(reactions)) = yes;
dyn_rev_rxn(reactions) $ (not reactions_NHT(reactions) and rev_rxn(reactions)) = yes;
dyn_exchange_rxn(reactions) $ (not reactions_NHT(reactions) and exchange_rxn(reactions)) = yes;
dyn_Fmax_Object(ObjectSet) $ (FmaxObj_inner_HT(ObjectSet)) = yes;
dyn_Fmin_Object(ObjectSet) $ (FminObj_inner_HT(ObjectSet)) = yes;
dyn_objectSet(objectSet) = dyn_Fmax_Object(ObjectSet) + dyn_Fmin_Object(ObjectSet);
dyn_priority_obj(ObjectSet) $ (PriObj_inner_HT(ObjectSet)) = yes;
No_priority_obj = card(dyn_priority_obj);

*--- reset the oringinal bounds for all fluxes ------------------------------------------------------------------------------------------------------
FluxBound_vf_LB(reactions) = tmp_FluxBound_vf_LB(reactions);
FluxBound_vb_LB(reactions) = tmp_FluxBound_vb_LB(reactions);
FluxBound_vf_UB(reactions) = tmp_FluxBound_vf_UB(reactions);
FluxBound_vb_UB(reactions) = tmp_FluxBound_vb_UB(reactions);
*----------------------------------------------------------------------------------------------------------------------------------------------------

*---- restrictions for the lower and upper bounds of fluxes --------------------
vf.lo(reactions) = FluxBound_vf_LB(reactions);
vf.up(reactions) = FluxBound_vf_UB(reactions);
vb.lo(reactions) = FluxBound_vb_LB(reactions);
vb.up(reactions) = FluxBound_vb_UB(reactions);

* assign vb = 0 for the irreversible fluxes
vb.lo(irrev_rxn) = 0;
vb.up(irrev_rxn) = 0;
vb.fx(irrev_rxn) = 0;
vb.lo(DM_sink_rxn(reactions)) $ (flag_DM_sink = 1) = 0;
vb.up(DM_sink_rxn(reactions)) $ (flag_DM_sink = 1) = 0;
vb.fx(DM_sink_rxn(reactions)) $ (flag_DM_sink = 1) = 0;
vf.lo(irrev_vb_rxn(reactions)) = 0;
vf.up(irrev_vb_rxn(reactions)) = 0;
vf.fx(irrev_vb_rxn(reactions)) = 0;

* assign the demanded uptake/secretion reactions
vf.fx(uptake_demand) = 0;
vb.fx(secretion_demand) = 0;
vb.fx(uptake_fixed) = FluxBound_vb_LB(uptake_fixed);

* irreversible uptake_rxn and secretion_rxn
vf.fx(uptake_rxn(reactions)) $ (flag_uptake = 1) = 0;
vb.fx(secretion_rxn(reactions)) $ (flag_secretion = 1) = 0;
vf.fx(uptake_demand(reactions)) $ (card(uptake_demand) > 0) = 0;
vb.fx(secretion_demand(reactions)) $ (card(secretion_demand) > 0) = 0;
********************************************************************************

*** Assign vf > 0 and vb = 0 for the Specific_rxn_vf --------------------------------
if(card(HT_Specific_rxn_vf) > 0,
   vf.lo(HT_Specific_rxn_vf) =  HT_Specific_rxn_vf_LB(HT_Specific_rxn_vf);
   vf.up(HT_Specific_rxn_vf) =  HT_Specific_rxn_vf_UB(HT_Specific_rxn_vf);
   vb.lo(HT_Specific_rxn_vf) =  0;
   vb.up(HT_Specific_rxn_vf) =  0;
   vb.fx(HT_Specific_rxn_vf) =  0;);
********************************************************************************
*** Assign vf = 0 and vb > 0 for the Specific_rxn_vb --------------------------------
if(card(HT_Specific_rxn_vb) > 0,
   vb.lo(HT_Specific_rxn_vb) =  HT_Specific_rxn_vb_LB(HT_Specific_rxn_vb);
   vb.up(HT_Specific_rxn_vb) =  HT_Specific_rxn_vb_UB(HT_Specific_rxn_vb);
   vf.lo(HT_Specific_rxn_vb) =  0;
   vf.up(HT_Specific_rxn_vb) =  0;
   vf.fx(HT_Specific_rxn_vb) =  0;);
 
*** Assign vf > 0 and vb > 0 for the Specific_rxn_vfvb -------------------------------
if(card(HT_Specific_rxn_vfvb) > 0,
   vf.lo(HT_Specific_rxn_vfvb) =  HT_Specific_rxn_vf_LB(HT_Specific_rxn_vfvb);
   vf.up(HT_Specific_rxn_vfvb) =  HT_Specific_rxn_vf_UB(HT_Specific_rxn_vfvb);
   vb.lo(HT_Specific_rxn_vfvb) =  HT_Specific_rxn_vb_LB(HT_Specific_rxn_vfvb);
   vb.up(HT_Specific_rxn_vfvb) =  HT_Specific_rxn_vb_UB(HT_Specific_rxn_vfvb););    
******************************************************************************* 

*----- compute the lower and upper bounds for the target reactions
target_limit_LB(targetSet) = 0;
target_limit_UB(targetSet) = 0;
target_limit_LB(targetSet) = HT_target_level_LB(targetSet);
target_limit_UB(targetSet) = HT_target_level_UB(targetSet);
MultiObjValue_FBA.lo(ObjectSet) = MultiObjValue_min(objectSet);
MultiObjValue_FBA.up(ObjectSet) = MultiObjValue_max(objectSet);
mem_objvalue_FBA.lo(objectSet) = 0;
mem_objvalue_FBA.up(objectSet) = 1;
Lambda.lo = 0;
Lambda.up = 1;
*-------------------------------------------------------------------------------
* set weightin factor for mee_objvalue_FBA for HT ------------------------------
Weight_Lambda(ObjectSet) = 0;
Weight_Lambda(ObjectSet) = HT_Weight_mem_obj_FBA(ObjectSet);
*-------------------------------------------------------------------------------
* Determine the normal flux distribution by solving the Primal FBA Problem
solve FBA_Problem using LP maximizing objValue_FBA;
HT_vf_FBA(reactions) = max(vf.l(reactions), 0);
HT_vb_FBA(reactions) = max(vb.l(reactions), 0);
HT_v_FBA(reactions) = HT_vf_FBA(reactions) - HT_vb_FBA(reactions);
HT_MultiObjvalue_Optim(Objectset) = 0;
HT_MultiObjvalue_Optim(dyn_objectset) = sum(dyn_reactions, coef_CellularObj_vf(dyn_objectset, dyn_reactions) * HT_vf_FBA(dyn_reactions)) +
                                        sum(dyn_reactions, coef_CellularObj_vb(dyn_objectset, dyn_reactions) * HT_vb_FBA(dyn_reactions));
HT_FBA_ModelStat = FBA_Problem.modelstat ;

***** inner HT UFD problem **************************************************************************************************************************
Mem_Obj_FBA_limit(ObjectSet) = 0;
Mem_Obj_FBA_limit(dyn_Fmax_Object) = ((HT_MultiObjvalue_Optim(dyn_Fmax_Object) - MultiObjValue_min(dyn_Fmax_Object))/
                                      (MultiObjValue_max(dyn_Fmax_Object) - MultiObjValue_min(dyn_Fmax_Object)));
                                        
Mem_Obj_FBA_limit(dyn_Fmin_Object) = ((MultiObjValue_max(dyn_Fmin_Object) - HT_MultiObjvalue_Optim(dyn_Fmin_Object))/
                                      (MultiObjValue_max(dyn_Fmin_Object) - MultiObjValue_min(dyn_Fmin_Object)));
Mem_Obj_FBA_limit(dyn_ObjectSet) = max(min( Mem_Obj_FBA_limit(dyn_ObjectSet), 1), 0);                                        
**** assign weighting coefficients for Rxn for computing ObjValue in UFD ****************************************************************************
weight_coef_rxn(reactions) = Weight_factor_Rxn_OT;
weight_coef_rxn(reactions) $ (HT_Reactions_HC(reactions)) = Weight_factor_Rxn_HC;
weight_coef_rxn(reactions) $ (HT_Reactions_MC(reactions)) = Weight_factor_Rxn_MC;
weight_coef_rxn(reactions) $ (HT_Reactions_NC(reactions)) = Weight_factor_Rxn_NC;
*****************************************************************************************************************************************************
*----- compute the lower and upper bounds for the target reactions ------------
target_limit_LB(targetSet) = 0;
target_limit_UB(targetSet) = 0;
target_limit_LB(targetSet) = HT_target_level_LB(targetSet);
target_limit_UB(targetSet) = HT_target_level_UB(targetSet);
MultiObjValue_FBA.lo(ObjectSet) = MultiObjValue_min(objectSet);
MultiObjValue_FBA.up(ObjectSet) = MultiObjValue_max(objectSet);
mem_objvalue_FBA.lo(objectSet) = 0;
mem_objvalue_FBA.up(objectSet) = 1;
*------------------------------------------------------------------------------

if(flag_UFD_Obj = 1, solve UFD1_Problem using LP minimizing ObjValue_UFD;);
if(flag_UFD_Obj = 2, solve UFD2_Problem using LP minimizing ObjValue_UFD;);
if(flag_UFD_Obj = 3, solve UFD3_Problem using QCP minimizing ObjValue_UFD;);
if(flag_UFD_Obj = 4, solve UFD4_Problem using QCP minimizing ObjValue_UFD;);
HT_vf_UFD(dyn_reactions) = max(vf.l(dyn_reactions), 0);
HT_vb_UFD(dyn_reactions) = max(vb.l(dyn_reactions), 0);
HT_v_UFD(dyn_reactions) = HT_vf_UFD(dyn_reactions) - HT_vb_UFD(dyn_reactions);
HT_UFD_ModelStat = UFD%No_UFD_Obj%_Problem.modelstat;

*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
* compute synthesis rate and degradation rate for each species at the normal state
HT_Species_SynRate(species) = 0;
loop(dyn_species,
     HT_Species_SynRate(dyn_species) = sum(dyn_reactions, S_Matrix(dyn_species, dyn_reactions) $
                                          (S_Matrix(dyn_species, dyn_reactions) > 0) * HT_vf_UFD(dyn_reactions)) -
                                       sum(dyn_reactions, S_Matrix(dyn_species, dyn_reactions) $
                                          (S_Matrix(dyn_species, dyn_reactions) < 0) * HT_vb_UFD(dyn_reactions)););

* compute synthesis rate and degradation rate for each biocompound at the normal state
HT_BioComp_SynRate(BioCompound) = 0;
loop(dyn_BioComp,
     HT_BioComp_SynRate(dyn_BioComp) = sum(dyn_species $ (BioCompound_species(dyn_BioComp, dyn_species)),
                                           HT_Species_SynRate(dyn_species)););
*****************************************************************************************************************************************************

***** Fuzzy multiobjective inner CA FBA Problem *****************************************************************************************************
***** assign reactions and species in CA models as dynamic sets ****************
dyn_reactions(reactions) = no;
dyn_species(species) = no;
dyn_BioComp(biocompound) = no;
dyn_irrev_rxn(reactions) = no;
dyn_rev_rxn(reactions) = no;
dyn_exchange_rxn(reactions) = no;
dyn_objectSet(objectSet) = no;
dyn_Fmax_Object(ObjectSet) = no;
dyn_Fmin_Object(ObjectSet) = no;
dyn_priority_obj(ObjectSet) = no;
dyn_reactions(reactions) $ (not reactions_NCA(reactions)) = yes;
dyn_species(species) $ (not species_NCA(species)) = yes;
dyn_BioComp(biocompound) $ (not biocompound_NCA(biocompound)) = yes;
dyn_irrev_rxn(reactions) $ (not reactions_NCA(reactions) and irrev_rxn(reactions)) = yes;
dyn_rev_rxn(reactions) $ (not reactions_NCA(reactions) and rev_rxn(reactions)) = yes;
dyn_exchange_rxn(reactions) $ (not reactions_NCA(reactions) and exchange_rxn(reactions)) = yes;
dyn_Fmax_Object(ObjectSet) $ (FmaxObj_inner_CA(ObjectSet)) = yes;
dyn_Fmin_Object(ObjectSet) $ (FminObj_inner_CA(ObjectSet)) = yes;
dyn_objectSet(objectSet) = dyn_Fmax_Object(ObjectSet) + dyn_Fmin_Object(ObjectSet);
dyn_priority_obj(ObjectSet) $ (PriObj_inner_CA(ObjectSet)) = yes;
No_priority_obj = card(dyn_priority_obj);

*--- reset the oringinal bounds for all fluxes ------------------------------------------------------------------------------------------------------
FluxBound_vf_LB(reactions) = tmp_FluxBound_vf_LB(reactions);
FluxBound_vb_LB(reactions) = tmp_FluxBound_vb_LB(reactions);
FluxBound_vf_UB(reactions) = tmp_FluxBound_vf_UB(reactions);
FluxBound_vb_UB(reactions) = tmp_FluxBound_vb_UB(reactions);
*----------------------------------------------------------------------------------------------------------------------------------------------------

*---- restrictions for the lower and upper bounds of fluxes --------------------
vf.lo(reactions) = FluxBound_vf_LB(reactions);
vf.up(reactions) = FluxBound_vf_UB(reactions);
vb.lo(reactions) = FluxBound_vb_LB(reactions);
vb.up(reactions) = FluxBound_vb_UB(reactions);

* assign vb = 0 for the irreversible fluxes
vb.lo(irrev_rxn) = 0;
vb.up(irrev_rxn) = 0;
vb.fx(irrev_rxn) = 0;
vb.lo(DM_sink_rxn(reactions)) $ (flag_DM_sink = 1) = 0;
vb.up(DM_sink_rxn(reactions)) $ (flag_DM_sink = 1) = 0;
vb.fx(DM_sink_rxn(reactions)) $ (flag_DM_sink = 1) = 0;
vf.lo(irrev_vb_rxn(reactions)) = 0;
vf.up(irrev_vb_rxn(reactions)) = 0;
vf.fx(irrev_vb_rxn(reactions)) = 0;

* assign the demanded uptake/secretion reactions
vf.fx(uptake_demand) = 0;
vb.fx(secretion_demand) = 0;
vb.fx(uptake_fixed) = FluxBound_vb_LB(uptake_fixed);

* irreversible uptake_rxn and secretion_rxn
vf.fx(uptake_rxn(reactions)) $ (flag_uptake = 1) = 0;
vb.fx(secretion_rxn(reactions)) $ (flag_secretion = 1) = 0;
vf.fx(uptake_demand(reactions)) $ (card(uptake_demand) > 0) = 0;
vb.fx(secretion_demand(reactions)) $ (card(secretion_demand) > 0) = 0;
********************************************************************************

*** Assign vf > 0 and vb = 0 for the Specific_rxn_vf --------------------------------
if(card(CA_Specific_rxn_vf) > 0,
   vf.lo(CA_Specific_rxn_vf) =  CA_Specific_rxn_vf_LB(CA_Specific_rxn_vf);
   vf.up(CA_Specific_rxn_vf) =  CA_Specific_rxn_vf_UB(CA_Specific_rxn_vf);
   vb.lo(CA_Specific_rxn_vf) =  0;
   vb.up(CA_Specific_rxn_vf) =  0;
   vb.fx(CA_Specific_rxn_vf) =  0;);
********************************************************************************
*** Assign vf = 0 and vb > 0 for the Specific_rxn_vb --------------------------------
if(card(CA_Specific_rxn_vb) > 0,
   vb.lo(CA_Specific_rxn_vb) =  CA_Specific_rxn_vb_LB(CA_Specific_rxn_vb);
   vb.up(CA_Specific_rxn_vb) =  CA_Specific_rxn_vb_UB(CA_Specific_rxn_vb);
   vf.lo(CA_Specific_rxn_vb) =  0;
   vf.up(CA_Specific_rxn_vb) =  0;
   vf.fx(CA_Specific_rxn_vb) =  0;);
 
*** Assign vf > 0 and vb > 0 for the Specific_rxn_vfvb -------------------------------
if(card(CA_Specific_rxn_vfvb) > 0,
   vf.lo(CA_Specific_rxn_vfvb) =  CA_Specific_rxn_vf_LB(CA_Specific_rxn_vfvb);
   vf.up(CA_Specific_rxn_vfvb) =  CA_Specific_rxn_vf_UB(CA_Specific_rxn_vfvb);
   vb.lo(CA_Specific_rxn_vfvb) =  CA_Specific_rxn_vb_LB(CA_Specific_rxn_vfvb);
   vb.up(CA_Specific_rxn_vfvb) =  CA_Specific_rxn_vb_UB(CA_Specific_rxn_vfvb););    
******************************************************************************* 

*----- compute the lower and upper bounds for the target reactions
target_limit_LB(targetSet) = 0;
target_limit_UB(targetSet) = 0;
target_limit_LB(targetSet) = CA_target_level_LB(targetSet);
target_limit_UB(targetSet) = CA_target_level_UB(targetSet);
MultiObjValue_FBA.lo(ObjectSet) = MultiObjValue_min(objectSet);
MultiObjValue_FBA.up(ObjectSet) = MultiObjValue_max(objectSet);
mem_objvalue_FBA.lo(objectSet) = 0;
mem_objvalue_FBA.up(objectSet) = 1;
Lambda.lo = 0;
Lambda.up = 1;
*-------------------------------------------------------------------------------
* set weightin factor for mem_objvalue_FBA for CA ------------------------------
Weight_Lambda(ObjectSet) = 0;
Weight_Lambda(ObjectSet) = CA_Weight_mem_obj_FBA(ObjectSet);
*-------------------------------------------------------------------------------
solve FBA_Problem using LP maximizing objValue_FBA;
CA_FBA_ModelStat = FBA_Problem.modelstat;
CA_vf_FBA(dyn_reactions) = max(vf.l(dyn_reactions), 0);
CA_vb_FBA(dyn_reactions) = max(vb.l(dyn_reactions), 0);
CA_MultiObjvalue_Optim(Objectset) = 0;
CA_MultiObjvalue_Optim(dyn_objectset) = sum(dyn_reactions, coef_CellularObj_vf(dyn_objectset, dyn_reactions) * CA_vf_FBA(dyn_reactions)) +
                                        sum(dyn_reactions, coef_CellularObj_vb(dyn_objectset, dyn_reactions) * CA_vb_FBA(dyn_reactions));
***** inner CA UFD problem **************************************************************************************************************************
Mem_Obj_FBA_limit(ObjectSet) = 0;
Mem_Obj_FBA_limit(dyn_Fmax_Object) = ((CA_MultiObjvalue_Optim(dyn_Fmax_Object) - MultiObjValue_min(dyn_Fmax_Object))/
                                      (MultiObjValue_max(dyn_Fmax_Object) - MultiObjValue_min(dyn_Fmax_Object)));
                                        
Mem_Obj_FBA_limit(dyn_Fmin_Object) = ((MultiObjValue_max(dyn_Fmin_Object) - CA_MultiObjvalue_Optim(dyn_Fmin_Object))/
                                      (MultiObjValue_max(dyn_Fmin_Object) - MultiObjValue_min(dyn_Fmin_Object)));
Mem_Obj_FBA_limit(dyn_ObjectSet) = max(min( Mem_Obj_FBA_limit(dyn_ObjectSet), 1), 0);
**** assign weighting coefficients for Rxn for computing ObjValue in UFD ****************************************************************************
weight_coef_rxn(reactions) = Weight_factor_Rxn_OT;
weight_coef_rxn(reactions) $ (CA_Reactions_HC(reactions)) = Weight_factor_Rxn_HC;
weight_coef_rxn(reactions) $ (CA_Reactions_MC(reactions)) = Weight_factor_Rxn_MC;
weight_coef_rxn(reactions) $ (CA_Reactions_NC(reactions)) = Weight_factor_Rxn_NC;
*****************************************************************************************************************************************************

*----- compute the lower and upper bounds for the target reactions ------------
target_limit_LB(targetSet) = 0;
target_limit_UB(targetSet) = 0;
target_limit_LB(targetSet) = CA_target_level_LB(targetSet);
target_limit_UB(targetSet) = CA_target_level_UB(targetSet);
MultiObjValue_FBA.lo(ObjectSet) = MultiObjValue_min(objectSet);
MultiObjValue_FBA.up(ObjectSet) = MultiObjValue_max(objectSet);
mem_objvalue_FBA.lo(objectSet) = 0;
mem_objvalue_FBA.up(objectSet) = 1;
*------------------------------------------------------------------------------

if(flag_UFD_Obj = 1, solve UFD1_Problem using LP minimizing ObjValue_UFD;);
if(flag_UFD_Obj = 2, solve UFD2_Problem using LP minimizing ObjValue_UFD;);
if(flag_UFD_Obj = 3, solve UFD3_Problem using QCP minimizing ObjValue_UFD;);
if(flag_UFD_Obj = 4, solve UFD4_Problem using QCP minimizing ObjValue_UFD;);
CA_vf_UFD(dyn_reactions) = max(vf.l(dyn_reactions), 0);
CA_vb_UFD(dyn_reactions) = max(vb.l(dyn_reactions), 0);
CA_v_UFD(dyn_reactions) = CA_vf_UFD(dyn_reactions) - CA_vb_UFD(dyn_reactions);
CA_UFD_ModelStat = UFD%No_UFD_Obj%_Problem.modelstat;

* compute synthesis rate and degradation rate for each species at the normal state
CA_Species_SynRate(species) = 0;
loop(dyn_species,
     CA_Species_SynRate(dyn_species) = sum(dyn_reactions, S_Matrix(dyn_species, dyn_reactions) $
                                          (S_Matrix(dyn_species, dyn_reactions) > 0) * CA_vf_UFD(dyn_reactions)) -
                                       sum(dyn_reactions, S_Matrix(dyn_species, dyn_reactions) $
                                          (S_Matrix(dyn_species, dyn_reactions) < 0) * CA_vb_UFD(dyn_reactions)););

* compute synthesis rate and degradation rate for each biocompound at the normal state
CA_BioComp_SynRate(BioCompound) = 0;
loop(dyn_BioComp,
     CA_BioComp_SynRate(dyn_BioComp) = sum(dyn_species $ (BioCompound_species(dyn_BioComp, dyn_species)),
                                           CA_Species_SynRate(dyn_species)););

*$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
***** Nested HDE for solving mixed-integer optimization problem *************************************************************************************
***** exclude some extra species in candidate_Enz(:) ************************************************************************************************
if(flag_Noncandidate_Enz = 1, candidate_Enz(Enzymes) = candidate_Enz(Enzymes) - excluded_candidate_Enz(Enzymes) -
                                                                                excluded_candidate_Enz_g1(Enzymes););
*----------------------------------------------------------------------------------------------------------------------------------------------------

***** exclude some extra enzymes in candidate_enz(:) ************************************************************************************************
Candidate_Enz_g1(Enzymes) = Candidate_Enz_g1(Enzymes) - excluded_candidate_Enz_g1(Enzymes);

if(card(Candidate_Enz_g2) > 0,
   candidate_Enz(Enzymes) = no;
   Candidate_Enz_g2(Enzymes) = Candidate_Enz_g2(Enzymes) - excluded_candidate_Enz_g2(Enzymes);
   candidate_Enz(Enzymes) = Candidate_Enz_g1(Enzymes) + Candidate_Enz_g2(Enzymes););

if(card(Candidate_Enz_g2) = 0,
   Candidate_Enz_g2(Enzymes) = Candidate_Enz(Enzymes) - Candidate_Enz_g1(Enzymes) - excluded_candidate_Enz_g2(Enzymes);
   candidate_Enz(Enzymes) = candidate_Enz(Enzymes) - excluded_candidate_Enz(Enzymes););
*****************************************************************************************************************************************************

set
   Dim_BI(Enzymes) "the set for binary variables from the candidate Enzymess"
   Dim_BI1(Enzymes) "the set for binary variables from candidate_g1"
   Dim_BI2(Enzymes) "the set for binary variables from candidate_g2"
   dyn_Dim_BI(Enzymes) "dynamic set for Dim_BI";

Dim_BI1(Enzymes) = candidate_Enz_g1(Enzymes);
Dim_BI2(Enzymes) = candidate_Enz_g2(Enzymes);
Dim_BI(Enzymes) = Dim_BI1(Enzymes) + Dim_BI2(Enzymes);
candidate_Enz(Enzymes) = Dim_BI(Enzymes);
*-------------------------------------------------------------------------------

Dim_XI(Dim_XIR) $ (not Dim_XR(Dim_XIR)) = yes;
*Dim_XI2(Dim_XIR) $ (not (Dim_XI1(Dim_XIR) + Dim_XR(Dim_XIR))) = yes;
Dim_XI2(Dim_XIR) = Dim_XI(Dim_XIR) - Dim_XI1(Dim_XIR);

abort $ (card(Dim_XI1) = 0 and card(Candidate_Enz_g1) > 0) " Error: Candidate_Enz_g1 must set to be empty";
abort $ (card(Dim_XI1) > 0 and card(Candidate_Enz_g1) = 0) " Error: Dim_XI1 must set to be empty";
abort $ (card(BioComp_ExpWarb) > card(Experiment_RFC)) " Error: card(BioComp_ExpWarb) must be less than to card(Experiment_RFC)";

alias(Dim_h, species);
alias(NP, NP_j);
alias(NP, NP_k);

parameters
*----- parameters used in HDE --------------------------------------------------
   F_X(NP) "mutation scaling factor ratio for normal random"
   F_CR(NP) "combined factor used for strategy_6 in mutation operation"
   CR_X(NP) "crossover factor for decision variables, higher value as higher choosing pop_XR"
   restnum "number of migration performed in HDE"
   nfeval "number of total function calls"
   nfeval_FBA_max, nfeval_UFD_min "number of function calls for max FBA, min/max FVA"
   XIR_min(Dim_XIR) "lower bound of integer decision variables for the candidate group"
   XIR_max(Dim_XIR) "upper bound of integer decision variables for the candidate group"
   sumZ_max "the desired total number of the selected reactions to be deleted"
   z_HDE(Enzymes) "decoded binary decision variables"  
   bestmemit_XB(enzymes) "temporal best binary decision variables to be knockout"
   bestmemit_XI(Dim_XIR) "temporal best integer decision variables"
   bm_XI(NP, Dim_XIR) "population of the best integer decision variables"
   rot_HDE(NP) "the sequence of the random permutation"
   rt_HDE(NP) "temporary rotated sequence for each permuted orders"
   ind_HDE(NP) "the permuted order for each element of the set"
   rand_HDE(NP) "uniform random distribution"
   a1_HDE(NP) "the permuted order for each element of the set"
   a2_HDE(NP) "the permuted order for each element of the set"
   a3_HDE(NP) "the permuted order for each element of the set"
   a4_HDE(NP) "the permuted order for each element of the set"
   a5_HDE(NP) "the permuted order for each element of the set"
   Gene_Diversity(NP, enzymes) "indices for gene diversity"
   Gene_Diversity_R(NP, Dim_XIR) "indices for gene diversity"
   pop_diversity "population diversity"
   index_migration "account index for force migration"
   rand_C1(NP, Dim_XIR) "random number used in migration"
   rand_C2(NP, Dim_XIR) "random number used in crossover and migration"
   number0, number, number_penalty "temporary parameter"
   NP_order(NP) "the initial order for each element in the defined set NP"
   constraint_h(species) "constraint values for equality"
   constraint_g "constraint to evaluate non-unique growth coupled strain"
   constraint_FBA_TR "constraint for solving FBA-TR model"
   constraint_UFD_TR "constraint for solving UFD-TR model"
   constraint_FBA_PH "constraint for solving FBA-PH model"
   constraint_UFD_PH "constraint for solving UFD-PH model"    
   iter_penalty0, iter_penalty "No. of iterations for updating penalty parameter"
   counter, counter1, i_loop "temporal counting parameters"
   best_TR_Reg_Factor "best regulation strength parameter for up/down regulation"
   TR_Reg_Factor(NP) "regulation strength parameter for up/down regulation"
   popold_XB(NP, Enzymes) "binary decision variables at the previous iteration"   
   popold_XI(NP, Dim_XIR) "population of integer decision variables at the previous iteration"
   pop_XI(NP, Dim_XIR) "population of integer decision variables for each iteration"
   pop_XB(NP, Enzymes) "binary decision variables to be knockout or not for each individual"
   pop_Mem_sumZ(NP) "membership grade of sum(z) for each individual"
   pop_fitness(NP) "fitness for each individual in the optimization problem"
   pop_modelStat_FBA(NP) "modelstat for solving FBA problem"
   pop_modelStat_UFD(NP) "modelstat for solving UFD problem"
   pop_FMObj_inner_TR(NP, objectSet) "Fuzzy multiobjective in inner optimization CA model"
   pop_FMObj_outer_TR(NP, objectSet) "Fuzzy multiobjective in outer optimization TR model"   
   pop_FMObj_inner_PH(NP, objectSet) "Fuzzy multiobjective in inner optimization BL model"
   pop_FMObj_outer_PH(NP, objectSet) "Fuzzy multiobjective in outer optimization PH model"   
   pop_mem_Met_Exp_PHHT(NP) "membership grade of PH SynthRate to experiment"  
   pop_mem_CV_TR(NP) "membership grade of CV for TR model"     
   pop_mem_CV_PH(NP) "membership grade of CV for PH model"
   pop_mem_MD_TP(NP) "membership grade of MD for TR and PH model"
   pop_mem_MD_PHCA(NP) "membership grade of MD for PHCA model"
   pop_mem_MD_TRCA(NP) "membership grade of MD for TRCA model"   
   pop_mem_MD_PHHT(NP) "membership grade of MD for PHHT model"
   pop_mem_MD_TRHT(NP) "membership grade of MD for TRHT model"    
   pop_mem_Met_PHHT(NP) "membership grade of synthes rate for PH to HT"
   pop_mem_rxn_PHHT(NP) "membership grade of rxn for PH to HT"   
   pop_mem_Met_PHCA(NP) "membership grade of synthes rate for PH to CA"
   pop_mem_rxn_PHCA(NP) "membership grade of rxn for PH to CA"
   pop_mem_Met_TRCA(NP) "membership grade of synthes rate for TR to CA"
   pop_mem_rxn_TRCA(NP) "membership grade of rxn for TR to CA"   
   pop_mem_Met_TRHT(NP) "membership grade of synthes rate for TR to HT"
   pop_mem_rxn_TRHT(NP) "membership grade of rxn for TR to HT"   
   pop_constraint(NP) "penalty constraint for infeasible solution in the optimization problem"
   ui_XI(NP, Dim_XIR) "temporal population of the integer decision variables in mutation operation"
   ui_XB(NP, Enzymes) "temporal binary decision variables in mutation operation"
   ui_Mem_sumZ(NP) "membership grade of sum(z) for each mutant individual"   
   ui_fitness(NP) "fitness for each mutant individual in mutation operation"
   ui_modelstat_FBA(NP) "modelstat for solving mutant FBA problem"
   ui_modelstat_UFD(NP) "modelstat for solving mutant UFD problem"
   ui_MultiObjValue_TR(NP, objectSet) "multiobjective value for TR model"
   ui_MultiObjValue_PH(NP, objectSet) "multiobjective value for PH model"
   ui_FMObj_inner_TR(NP, objectSet) "Fuzzy multiobjective in inner optimization CA model"
   ui_FMObj_outer_TR(NP, objectSet) "Fuzzy multiobjective in outer optimization TR model"   
   ui_FMObj_inner_PH(NP, objectSet) "Fuzzy multiobjective in inner optimization BL model"
   ui_FMObj_outer_PH(NP, objectSet) "Fuzzy multiobjective in outer optimization PH model" 
   ui_mem_Met_Exp_PHHT(NP) "membership grade of PH SynthRate to experiment"  
   ui_mem_CV_TR(NP) "membership grade of CV for TR model"     
   ui_mem_CV_PH(NP) "membership grade of CV for PH model"
   ui_mem_MD_TP(NP) "membership grade of MD for TR and PH model"
   ui_mem_MD_PHCA(NP) "membership grade of MD for PHCA model"
   ui_mem_MD_TRCA(NP) "membership grade of MD for TRCA model"   
   ui_mem_MD_PHHT(NP) "membership grade of MD for PHHT model"
   ui_mem_MD_TRHT(NP) "membership grade of MD for TRHT model"    
   ui_mem_Met_PHHT(NP) "membership grade of synthes rate for PH to HT"
   ui_mem_rxn_PHHT(NP) "membership grade of rxn for PH to HT"   
   ui_mem_Met_PHCA(NP) "membership grade of synthes rate for PH to CA"
   ui_mem_rxn_PHCA(NP) "membership grade of rxn for PH to CA"
   ui_mem_Met_TRCA(NP) "membership grade of synthes rate for TR to CA"
   ui_mem_rxn_TRCA(NP) "membership grade of rxn for TR to CA"   
   ui_mem_Met_TRHT(NP) "membership grade of synthes rate for TR to HT"
   ui_mem_rxn_TRHT(NP) "membership grade of rxn for TR to HT"       
   ui_constraint(NP) "penalty constraint for infeasible solution in the optimization problem"
   best_modelStat "modelstat for the best solution"
   bestmem_XI(Dim_XIR) "the best integer decision variables"
   bestmem_XB(enzymes) "the best binary decision variables to be knockout"
   best_Mem_sumZ  "best membership grade of sum(z)"   
   best_fitness "the best fitness value in the optimization problem"
   best_fitnessit "the best fitness in the previous iteration"     
   best_constraint "the constrained value for the best individual" 
   best_FMObj_inner_TR(objectSet) "best multiobjective value for inner CA model"
   best_FMObj_inner_PH(objectSet) "best multiobjective value for inner BL model"
   best_FMObj_outer_TR(objectSet) "best multiobjective value for outer TR model"
   best_FMObj_outer_PH(objectSet) "best multiobjective value for outer PH model"   
   best_mem_Met_Exp_PHHT "best membership grade of PH SynthRate to experiment"  
   best_mem_CV_TR "best membership grade of CV for TR model"
   best_mem_CV_PH "best membership grade of CV for PH model"   
   best_mem_MD_TP "best membership grade of MD for PH and TR model"  
   best_mem_MD_PHCA "best membership grade of MD for PHCA model"
   best_mem_MD_TRCA "best membership grade of MD for TRCA model"   
   best_mem_MD_PHHT "best membership grade of MD for PHHT model"
   best_mem_MD_TRHT "best membership grade of MD for TRHT model"   
   best_mem_rxn_PHHT "best membership grade of fuzzy equal to fluxes of PH to HT"
   best_mem_Met_PHHT "best membership grade of fuzzy equal to met_flow of PH to HT"
   best_mem_rxn_PHCA "best membership grade of fuzzy equal to fluxes of PH to CA"
   best_mem_Met_PHCA "best membership grade of fuzzy equal to met_flow of PH to CA"
   best_mem_rxn_TRCA "best membership grade of fuzzy equal to fluxes of TR to CA"
   best_mem_Met_TRCA "best membership grade of fuzzy equal to met_flow of TR to CA"   
   best_mem_rxn_TRHT "best membership grade of fuzzy equal to fluxes of TR to HT"
   best_mem_Met_TRHT "best membership grade of fuzzy equal to met_flow of TR to HT"    
   store_bestmem_XI(itermax, Dim_XIR) "store the best integer decision variables"
   store_bestmem_XB(itermax, enzymes) "store the best binary decision variables to be knockout"
   store_best_mem_sumz(itermax) "store best membership grade of sum(z)"   
   store_best_fitness(itermax) "store the best fitness value in the optimization problem"
   store_best_constraint(itermax) "store the best fitness value in the optimization problem"
*   store_best_FMObj_inner_TR(itermax, objectSet) "store best multiobjective value for inner CA model"
*   store_best_FMObj_inner_PH(itermax, objectSet) "store best multiobjective value for inner BL model"
   store_best_FMObj_outer_TR(itermax, objectSet) "store best multiobjective value for outer TR model"
   store_best_FMObj_outer_PH(itermax, objectSet) "store best multiobjective value for outer PH model"   
   store_best_mem_Met_Exp_PHHT(itermax) "store best membership grade of PHHT SynthRate to experiment"   
   store_best_mem_CV_TR(itermax) "store best membership grade of CV for TR model"
   store_best_mem_CV_PH(itermax) "store best membership grade of CV for PH model"
   store_best_mem_MD_TP(itermax) "store best membership grade of MD for PH and TR model"      
   store_best_mem_MD_PHCA(itermax) "store best membership grade of MD for PHCA"
   store_best_mem_MD_TRCA(itermax) "store best membership grade of MD for TRCA"   
   store_best_mem_MD_PHHT(itermax) "store best membership grade of MD for PHHT"   
   store_best_mem_MD_TRHT(itermax) "store best membership grade of MD for TRHT"
   store_best_mem_rxn_PHHT(itermax) "store best membership grade of fuzzy equal to fluxes of PH to HT"
   store_best_mem_Met_PHHT(itermax) "store best membership grade of fuzzy equal to met_flow of PH to HT"
   store_best_mem_rxn_PHCA(itermax) "store best membership grade of fuzzy equal to fluxes of PH to CA"
   store_best_mem_Met_PHCA(itermax) "store best membership grade of fuzzy equal to met_flow of PH to CA"
   store_best_mem_rxn_TRCA(itermax) "store best membership grade of fuzzy equal to fluxes of TR to CA"
   store_best_mem_Met_TRCA(itermax) "store best membership grade of fuzzy equal to met_flow of TR to CA"   
   store_best_mem_rxn_TRHT(itermax) "store best membership grade of fuzzy equal to fluxes of TR to HT"
   store_best_mem_Met_TRHT(itermax) "store best membership grade of fuzzy equal to met_flow of TR to HT"  
   ord_enzymes(enzymes) 'order of candidate enzymes'
   SumZ_gene(enzymes) 'sum of genes for each enzyme to be manipulated'
   sumZ_min0 'original minimum number of selected genes to be manipulated'
   SumZ_max, sumZ_min 'maximum/minimum number of selected genes to be manipulated'
   z_HDE_tmp(reactions, enzymes) "temp decoded binary decision variables"
   z_isozyme_rxn_enz(reactions, enzymes) "regulated reaction and its relative isozymes in the model"
   z_isozyme_rxn(reactions) "subset of reactions regulated by isozymes in the model"
   tmp_MultiObjValue(ObjectSet) "temporary cell viability objective values"
   tmp_constraint_h "temporary equality constraint";
 
***** lower and uper bound of healthy metabolite-flow rate for evaluating fuzzy equal ***************************************************************
HT_MetFlowRate_LB(Biocompound) $ (HT_BioComp_SynRate(Biocompound) > 0) = HT_BioComp_SynRate(Biocompound)/mem_Bound_ratio;
HT_MetFlowRate_UB(Biocompound) $ (HT_BioComp_SynRate(Biocompound) > 0) = HT_BioComp_SynRate(Biocompound)*mem_Bound_ratio;
HT_MetFlowRate_LB(Biocompound) $ (HT_BioComp_SynRate(Biocompound) = 0) = 0;
HT_MetFlowRate_UB(Biocompound) $ (HT_BioComp_SynRate(Biocompound) = 0) = UB_zero;
*****************************************************************************************************************************************************
***** lower and uper bound of healthy vf and vb for evaluating fuzzy equal **************************************************************************
HT_vf_rxn_LB(reactions) $ (HT_vf_UFD(reactions) > 0) = HT_vf_UFD(reactions)/mem_Bound_ratio;
HT_vf_rxn_UB(reactions) $ (HT_vf_UFD(reactions) > 0) = HT_vf_UFD(reactions)*mem_Bound_ratio;
HT_vf_rxn_LB(reactions) $ (HT_vf_UFD(reactions) = 0) = 0;
HT_vf_rxn_UB(reactions) $ (HT_vf_UFD(reactions) = 0) = UB_zero;

HT_vb_rxn_LB(reactions) $ (HT_vb_UFD(reactions) > 0) = HT_vb_UFD(reactions)/mem_Bound_ratio;
HT_vb_rxn_UB(reactions) $ (HT_vb_UFD(reactions) > 0) = HT_vb_UFD(reactions)*mem_Bound_ratio;
HT_vb_rxn_LB(reactions) $ (HT_vb_UFD(reactions) = 0) = 0;
HT_vb_rxn_UB(reactions) $ (HT_vb_UFD(reactions) = 0) = UB_zero;
*****************************************************************************************************************************************************
***** lower and uper bound of healthy metabolite-flow rate for evaluating fuzzy equal ***************************************************************
CA_MetFlowRate_LB(Biocompound) $ (CA_BioComp_SynRate(Biocompound) > 0) = CA_BioComp_SynRate(Biocompound)/mem_Bound_ratio;
CA_MetFlowRate_UB(Biocompound) $ (CA_BioComp_SynRate(Biocompound) > 0) = CA_BioComp_SynRate(Biocompound)*mem_Bound_ratio;
CA_MetFlowRate_LB(Biocompound) $ (CA_BioComp_SynRate(Biocompound) = 0) = 0;
CA_MetFlowRate_UB(Biocompound) $ (CA_BioComp_SynRate(Biocompound) = 0) = UB_zero;
*****************************************************************************************************************************************************
***** lower and uper bound of healthy vf and vb for evaluating fuzzy equal **************************************************************************
CA_vf_rxn_LB(reactions) $ (CA_vf_UFD(reactions) > 0) = CA_vf_UFD(reactions)/mem_Bound_ratio;
CA_vf_rxn_UB(reactions) $ (CA_vf_UFD(reactions) > 0) = CA_vf_UFD(reactions)*mem_Bound_ratio;
CA_vf_rxn_LB(reactions) $ (CA_vf_UFD(reactions) = 0) = 0;
CA_vf_rxn_UB(reactions) $ (CA_vf_UFD(reactions) = 0) = UB_zero;

CA_vb_rxn_LB(reactions) $ (CA_vb_UFD(reactions) > 0) = CA_vb_UFD(reactions)/mem_Bound_ratio;
CA_vb_rxn_UB(reactions) $ (CA_vb_UFD(reactions) > 0) = CA_vb_UFD(reactions)*mem_Bound_ratio;
CA_vb_rxn_LB(reactions) $ (CA_vb_UFD(reactions) = 0) = 0;
CA_vb_rxn_UB(reactions) $ (CA_vb_UFD(reactions) = 0) = UB_zero;
*****************************************************************************************************************************************************

***** compute No. of identical enzymes and No. of isozymes for each feaible enzymes in BL, CA and HT models *****************************************
alias(dyn_enzymes, enzymes);
No_iden_enz_BL(dyn_enzymes) = sum(enzymes $ (identical_enz(dyn_enzymes, enzymes)), 1);
No_iden_enz_CA(dyn_enzymes) = sum(enzymes $ (identical_enz(dyn_enzymes, enzymes) and (not enzymes_NCA(dyn_enzymes))), 1);
No_iden_enz_HT(dyn_enzymes) = sum(enzymes $ (identical_enz(dyn_enzymes, enzymes) and (not enzymes_NHT(dyn_enzymes))), 1);
No_isozymes_BL(dyn_enzymes) = sum(enzymes $ (isozymes(dyn_enzymes, enzymes)), 1);
No_isozymes_CA(dyn_enzymes) = sum(enzymes $ (isozymes(dyn_enzymes, enzymes) and (not enzymes_NCA(dyn_enzymes))), 1);
No_isozymes_HT(dyn_enzymes) = sum(enzymes $ (isozymes(dyn_enzymes, enzymes) and (not enzymes_NHT(dyn_enzymes))), 1);

*%%%%% assign multiobj_weignt obtained from CA model %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
method_6 = round(card(itermax)/method_6);

*%%%%% the user provided data which depend on the BLOP %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
epsilon1 = epsilon_ratio * card(Dim_XIR)/(card(Dim_BI) + card(Dim_XR));
XIR_min(Dim_XIR) = 1;
xIR_max(Dim_XI1) = card(Dim_BI1);
xIR_max(Dim_XI2) = card(Dim_BI2);
XIR_min(Dim_XR) = TR_Reg_Factor_min(Dim_XR);
XIR_max(Dim_XR) = TR_Reg_Factor_max(Dim_XR);

***** evaluate the set and number of genes for each candidate_enz ***********************************************************************************
loop(enzymes, SumZ_gene(enzymes) = sum(genes $ (enzyme_gene(enzymes, genes)), 1););
*****************************************************************************************************************************************************
***** calculate maximum number of genes for candidate_enz *******************************************************************************************
sumZ_max = 0;
number1 = 0;
loop(candidate_enz, number1 = number1 + 1; ord_enzymes(candidate_enz) = number1;);
for(counter = 1 to card(Dim_XI),
    number1 = smax(candidate_enz $(ord_enzymes(candidate_enz) > 0), SumZ_gene(candidate_enz));
    number2 = 1;
    loop(candidate_enz $ (SumZ_gene(candidate_enz) = number1 and number2 = 1),
         ord_enzymes(candidate_enz) = 0; number2 = 0;);
    sumZ_max = sumZ_max + number1;);
sumZ_max = sumZ_max + 1;

***** calculate minimum number of genes for candidate_enz **********************
sumZ_min0 = 0;
number1 = 0;
loop(candidate_enz, number1 = number1 + 1; ord_enzymes(candidate_enz) = number1;);
for(counter = 1 to card(Dim_XI),
    number1 = smin(candidate_enz $(ord_enzymes(candidate_enz) > 0), SumZ_gene(candidate_enz));
    number2 = 1;
    loop(candidate_enz $ (SumZ_gene(candidate_enz) = number1 and number2 = 1),
         ord_enzymes(candidate_enz) = 0; number2 = 0;);
    sumZ_min0 = sumZ_min0 + number1;);
sumZ_min = sumZ_min0 + extra_gene_min;
*****************************************************************************************************************************************************

*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
* normalization of sum of fuzzy membership functions
startTime = jnow;
iter_penalty0 = round(card(itermax)/nPenalty_update);
iter_penalty = iter_penalty0;
number_penalty = 1;

*----- read and write the seed for the random number generator -----------------
*execseed = 1 + gmillisec(jnow);
execseed = uniformint(1, 86400) + gmillisec(jnow);

*----- initialization of the sequence order for the defined set ----------------
number = 0;
loop(NP, number = number + 1; NP_order(NP) = number;);

*---- Initial mutation strategy for method_S = 1 -------------------------------
if(strategy >= 29,
   method_S = 1;
   strategy $ (Method_S = 1) = uniformint(1, 28););

*----- initialize a population of candidate individuals ------------------------
index_migration = 0;
pop_XI(NP, Dim_XI) = uniformInt(XIR_min(Dim_XI), XIR_max(Dim_XI));
pop_XI(NP, Dim_XR) = uniform(XIR_min(Dim_XR), XIR_max(Dim_XR));
*----- end of initialization ---------------------------------------------------

*----- compute the initial fitness and evaluate the best one -------------------
*%%%%% the user can modify the following procedures %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
best_fitness = -1.0e20;
best_fitnessit = best_fitness;
best_constraint = 1.0e20;
pop_constraint(NP) = 0;
nfeval = 0;
nfeval_FBA_max = 0;
nfeval_UFD_min = 0;
*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

*----- decode Candidate_Enz orders to select the regulated reactions -----------
$offorder
pop_XB(NP, Dim_BI) = 0;
loop(Dim_XI1, pop_XB(NP, Dim_BI1) $ (ord(Dim_BI1) = pop_XI(NP, Dim_XI1)) = uniformInt(%No_UPDownKO_min_g1%, %No_UPDownKO_max_g1%););
loop(Dim_XI2, pop_XB(NP, Dim_BI2) $ (ord(Dim_BI2) = pop_XI(NP, Dim_XI2)) = uniformInt(%No_UPDownKO_min_g2%, %No_UPDownKO_max_g2%););
$onorder
*-------------------------------------------------------------------------------

* assign regulation strength parameter for each individual
TR_Reg_Factor(NP) = pop_XI(NP, "RSP1");
*-------------------------------------------------------------------------------

*%%%%% the user can modify the following procedures %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
loop(NP,
***** assign reactions and species in FMO CA models as dynamic sets ****************   
     dyn_reactions(reactions) = no;
     dyn_species(species) = no;
     dyn_BioComp(biocompound) = no;
     dyn_irrev_rxn(reactions) = no;
     dyn_rev_rxn(reactions) = no;
     dyn_exchange_rxn(reactions) = no;
     dyn_objectSet(objectSet) = no;
     dyn_Fmax_Object(ObjectSet) = no;
     dyn_Fmin_Object(ObjectSet) = no;
     dyn_priority_obj(ObjectSet) = no;
     dyn_obj_outer(objectSet) = no;
     dyn_Fmax_Obj_outer(ObjectSet) = no;
     dyn_Fmin_Obj_outer(ObjectSet) = no;
     dyn_priority_outer(ObjectSet) = no;    
**** objectives used in inner optimization problem
     dyn_reactions(reactions) $ (not reactions_NCA(reactions)) = yes;
     dyn_species(species) $ (not species_NCA(species)) = yes;
     dyn_BioComp(biocompound) $ (not biocompound_NCA(biocompound)) = yes;
     dyn_irrev_rxn(reactions) $ (not reactions_NCA(reactions) and irrev_rxn(reactions)) = yes;
     dyn_rev_rxn(reactions) $ (not reactions_NCA(reactions) and rev_rxn(reactions)) = yes;
     dyn_exchange_rxn(reactions) $ (not reactions_NCA(reactions) and exchange_rxn(reactions)) = yes;
     dyn_Fmax_Object(ObjectSet) $ (FmaxObj_inner_TR(ObjectSet)) = yes;
     dyn_Fmin_Object(ObjectSet) $ (FminObj_inner_TR(ObjectSet)) = yes;
     dyn_objectSet(objectSet) = dyn_Fmax_Object(ObjectSet) + dyn_Fmin_Object(ObjectSet);
     dyn_priority_obj(ObjectSet) $ (PriObj_inner_TR(ObjectSet)) = yes;
     No_priority_obj = card(PriObj_inner_TR);
**** objectives used in outer optimization problem     
     dyn_Fmax_Obj_outer(ObjectSet) $ (FmaxObj_Outer_TR(ObjectSet)) = yes;
     dyn_Fmin_Obj_outer(ObjectSet) $ (FminObj_Outer_TR(ObjectSet)) = yes;
     dyn_obj_outer(objectSet) = dyn_Fmax_Obj_outer(ObjectSet) + dyn_Fmin_Obj_outer(ObjectSet);
     dyn_priority_outer(ObjectSet) $ (PriObj_Outer_TR(ObjectSet)) = yes;
     No_priority_outer = card(PriObj_Outer_TR);
********************************************************************************
***** Set the weighting factors and limits for FBA objectives ******************
     basal_vf(reactions) = 0;
     basal_vb(reactions) = 0;
     basal_vf(reactions) = CA_vf_UFD(reactions);
     basal_vb(reactions) = CA_vb_UFD(reactions);

     z_HDE(Dim_BI) = 0;
     z_HDE(Dim_BI) = pop_XB(NP, Dim_BI);
*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

     pop_Mem_sumZ(NP) $ (flag_sumz < 2) = (sumZ_max - sum(Dim_BI, (z_HDE(Dim_BI) > 0) = 1))/(sumZ_max - 1);
     pop_Mem_sumZ(NP) $ (flag_sumz = 2) = sum(Dim_BI, (z_HDE(Dim_BI) > 0) = 1)/(sumZ_max - 1);
*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
*--- reset the oringinal bounds for all fluxes ------------------------------------------------------------------------------------------------------
     FluxBound_vf_LB(reactions) = tmp_FluxBound_vf_LB(reactions);
     FluxBound_vb_LB(reactions) = tmp_FluxBound_vb_LB(reactions);
     FluxBound_vf_UB(reactions) = tmp_FluxBound_vf_UB(reactions);
     FluxBound_vb_UB(reactions) = tmp_FluxBound_vb_UB(reactions);
*----------------------------------------------------------------------------------------------------------------------------------------------------
 
*---- restrictions for the lower and upper bounds of fluxes --------------------
     vf.lo(reactions) = FluxBound_vf_LB(reactions);
     vf.up(reactions) = FluxBound_vf_UB(reactions);
     vb.lo(reactions) = FluxBound_vb_LB(reactions);
     vb.up(reactions) = FluxBound_vb_UB(reactions);
*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

     z_isozyme_rxn_enz(reactions, enzymes) = no;
     z_isozyme_rxn(reactions) = no;
     z_HDE_tmp(reactions, enzymes) = 0;
     Regulated_Rxn_v(reactions) = NO;
     dyn_Reg_ExRxn(reactions) = no;
     loop(Dim_BI $ (z_HDE(Dim_BI) >= 1),
          Regulated_rxn_v(reactions) $ (enzyme_Reg_rxn_v(Dim_BI, reactions) and dyn_reactions(reactions)) = yes;

***** assign the regulated reactions to be some levels *************************
* up regulated v
          if(z_HDE(Dim_BI) = 1,
             vf.lo(Regulated_rxn_v(reactions)) = basal_vf(reactions) + TR_Reg_factor(NP) * (FluxBound_vf_UB(reactions) - basal_vf(reactions));
             vf.up(Regulated_rxn_v(reactions)) = FluxBound_vf_UB(reactions);
             vb.lo(Regulated_rxn_v(reactions)) = FluxBound_vb_LB(reactions);
             vb.up(Regulated_rxn_v(reactions)) = basal_vb(reactions) + TR_Reg_factor(NP) * (FluxBound_vb_LB(reactions) - basal_vb(reactions)););

* down regulated v
          if(z_HDE(Dim_BI) = 2,
             vf.lo(Regulated_rxn_v(reactions)) = FluxBound_vf_LB(reactions);
             vf.up(Regulated_rxn_v(reactions)) = basal_vf(reactions) + TR_Reg_factor(NP) * (FluxBound_vf_LB(reactions) - basal_vf(reactions));
             vb.lo(Regulated_rxn_v(reactions)) = basal_vb(reactions) + TR_Reg_factor(NP) * (FluxBound_vb_UB(reactions) - basal_vb(reactions));
             vb.up(Regulated_rxn_v(reactions)) = FluxBound_vb_UB(reactions);

*---- the down regulated reaction by Dim_BI is dominatd by other isozymes ------
            vf.lo(reactions) $ (Regulated_rxn_v(reactions) and isozyme_rxn(reactions)) = (1 - flux_bounded_ratio) * basal_vf(reactions);
            vf.up(reactions) $ (Regulated_rxn_v(reactions) and isozyme_rxn(reactions)) = (1 + flux_bounded_ratio) * basal_vf(reactions);
            vb.lo(reactions) $ (Regulated_rxn_v(reactions) and isozyme_rxn(reactions)) = (1 - flux_bounded_ratio) * basal_vb(reactions);
            vb.up(reactions) $ (Regulated_rxn_v(reactions) and isozyme_rxn(reactions)) = (1 + flux_bounded_ratio) * basal_vb(reactions););
*-------------------------------------------------------------------------------
*---- knockout vf and vb -------------------------------------------------------
          if(z_HDE(Dim_BI) = 3,
             vf.fx(Regulated_rxn_v(reactions)) = 0;
             vb.fx(Regulated_rxn_v(reactions)) = 0;

*---- the KO reaction by Dim_BI is dominatd by other isozymes ------------------
            vf.lo(reactions) $ (Regulated_rxn_v(reactions) and isozyme_rxn(reactions)) = (1 - flux_bounded_ratio) * basal_vf(reactions);
            vf.up(reactions) $ (Regulated_rxn_v(reactions) and isozyme_rxn(reactions)) = (1 + flux_bounded_ratio) * basal_vf(reactions);
            vb.lo(reactions) $ (Regulated_rxn_v(reactions) and isozyme_rxn(reactions)) = (1 - flux_bounded_ratio) * basal_vb(reactions);
            vb.up(reactions) $ (Regulated_rxn_v(reactions) and isozyme_rxn(reactions)) = (1 + flux_bounded_ratio) * basal_vb(reactions););
*-------------------------------------------------------------------------------
*---- reaction is regulated by isozyme -----------------------------------------
          z_isozyme_rxn(reactions) $ (Regulated_rxn_v(reactions) and isozyme_rxn(reactions)) = yes;
          z_isozyme_rxn_enz(reactions, Dim_BI) $ (Regulated_rxn_v(reactions) and isozyme_rxn(reactions)) = yes;
          z_HDE_tmp(reactions, Dim_BI) $ (Regulated_rxn_v(reactions) and isozyme_rxn(reactions)) = z_HDE(Dim_BI);
          dyn_Reg_ExRxn(reactions) = dyn_Reg_ExRxn(reactions) + Regulated_rxn_v(reactions);
          Regulated_Rxn_v(reactions) = NO;);

***** Decide the regulated reaction to be up/down/KO if all isozymes are selected by NHDE ***********************************************************
     if((card(Dim_XI) > 1 and sum(reactions $ (z_isozyme_rxn(reactions)), 1) > 0),
         loop(reactions $ (z_isozyme_rxn(reactions) and sum(Dim_BI $ (z_HDE(Dim_BI) >= 1 and z_isozyme_rxn_enz(reactions, Dim_BI)), 1) =
                           sum(enzymes $ (isozyme_rxn_enz(reactions, enzymes)), 1)),

*---- The reaction is KO if all isozymes are KO, z_HDE_tmp = 3 --------------------------------------------------------------------------------------
              if(sum(Dim_BI $ (z_HDE(Dim_BI) >= 1), z_HDE_tmp(reactions, Dim_BI)) = 3 * sum(Dim_BI $ (z_isozyme_rxn_enz(reactions, Dim_BI)), 1),
                 vf.fx(reactions) $ (z_isozyme_rxn(reactions)) = 0;
                 vb.fx(reactions) $ (z_isozyme_rxn(reactions)) = 0;);

*---- The reaction is down/up, (set to down firstly) if one of the isozymes is down/up --------------------------------------------------------------
              if(sum(Dim_BI $ (z_HDE(Dim_BI) >= 1), z_HDE_tmp(reactions, Dim_BI)) < 3 * sum(Dim_BI $ (z_isozyme_rxn_enz(reactions, Dim_BI) ), 1),
                 vf.lo(reactions) $ (z_isozyme_rxn(reactions)) = FluxBound_vf_LB(reactions);
                 vf.up(reactions) $ (z_isozyme_rxn(reactions)) = basal_vf(reactions) + TR_Reg_factor(NP) *
                                                                 (FluxBound_vf_LB(reactions) - basal_vf(reactions));
                 vb.lo(reactions) $ (z_isozyme_rxn(reactions)) = basal_vb(reactions) + TR_Reg_factor(NP) *
                                                                 (FluxBound_vb_UB(reactions) - basal_vb(reactions));
                 vb.up(reactions) $ (z_isozyme_rxn(reactions)) = FluxBound_vb_UB(reactions););

*---- The above reaction is reassigned to up, if one of the isozymes is up --------------------------------------------------------------------------
              loop(Dim_BI $ (z_HDE(Dim_BI) >= 1 and z_HDE_tmp(reactions, Dim_BI) = 1 and z_isozyme_rxn(reactions)),
                   vf.lo(reactions) = basal_vf(reactions) + TR_Reg_factor(NP) * (FluxBound_vf_UB(reactions) - basal_vf(reactions));
                   vf.up(reactions) = FluxBound_vf_UB(reactions);
                   vb.lo(reactions) = FluxBound_vb_LB(reactions);
                   vb.up(reactions) = basal_vb(reactions) + TR_Reg_factor(NP) * (FluxBound_vb_LB(reactions) - basal_vb(reactions));
                   break $ (z_HDE_tmp(reactions, Dim_BI) = 1););
         );
     );
    
*----------------------------------------------------------------------------------------------------------------------------------------------------
*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
* assign vb = 0 for the irreversible fluxes
     vb.lo(irrev_rxn) = 0;
     vb.up(irrev_rxn) = 0;
     vb.fx(irrev_rxn) = 0;
     vb.fx(DM_sink_rxn(reactions)) $ (flag_DM_sink = 1) = 0;
     vf.lo(irrev_vb_rxn(reactions)) = 0;
     vf.up(irrev_vb_rxn(reactions)) = 0;
     vf.fx(irrev_vb_rxn(reactions)) = 0;

* assign the demanded uptake/secretion reactions
     vf.fx(uptake_demand) = 0;
     vb.fx(secretion_demand) = 0;
     vb.fx(uptake_fixed) = FluxBound_vb_LB(uptake_fixed);

* irreversible uptake_rxn and secretion_rxn
     vf.fx(uptake_rxn(reactions)) $ (flag_uptake = 1 and not dyn_Reg_ExRxn(reactions)) = 0;
     vb.fx(secretion_rxn(reactions)) $ (flag_secretion = 1 and not dyn_Reg_ExRxn(reactions)) = 0;

     vf.fx(uptake_demand(reactions)) $ (card(uptake_demand) > 0) = 0;
     vb.fx(secretion_demand(reactions)) $ (card(secretion_demand) > 0) = 0;
********************************************************************************

*** Assign vf > 0 and vb = 0 for the Specific_rxn_vf --------------------------------
     if(card(TR_Specific_rxn_vf) > 0,
        vf.lo(TR_Specific_rxn_vf) =  TR_Specific_rxn_vf_LB(TR_Specific_rxn_vf);
        vf.up(TR_Specific_rxn_vf) =  TR_Specific_rxn_vf_UB(TR_Specific_rxn_vf);
        vb.lo(TR_Specific_rxn_vf) =  0;
        vb.up(TR_Specific_rxn_vf) =  0;
        vb.fx(TR_Specific_rxn_vf) =  0;);
********************************************************************************
*** Assign vf = 0 and vb > 0 for the Specific_rxn_vb --------------------------------
     if(card(TR_Specific_rxn_vb) > 0,
        vb.lo(TR_Specific_rxn_vb) =  TR_Specific_rxn_vb_LB(TR_Specific_rxn_vb);
        vb.up(TR_Specific_rxn_vb) =  TR_Specific_rxn_vb_UB(TR_Specific_rxn_vb);
        vf.lo(TR_Specific_rxn_vb) =  0;
        vf.up(TR_Specific_rxn_vb) =  0;
        vf.fx(TR_Specific_rxn_vb) =  0;);
 
*** Assign vf > 0 and vb > 0 for the Specific_rxn_vfvb -------------------------------
     if(card(TR_Specific_rxn_vfvb) > 0,
        vf.lo(TR_Specific_rxn_vfvb) =  TR_Specific_rxn_vf_LB(TR_Specific_rxn_vfvb);
        vf.up(TR_Specific_rxn_vfvb) =  TR_Specific_rxn_vf_UB(TR_Specific_rxn_vfvb);
        vb.lo(TR_Specific_rxn_vfvb) =  TR_Specific_rxn_vb_LB(TR_Specific_rxn_vfvb);
        vb.up(TR_Specific_rxn_vfvb) =  TR_Specific_rxn_vb_UB(TR_Specific_rxn_vfvb););    
*******************************************************************************

*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
***** Set the weighting factors and limits for FBA objectives ******************
*----- compute the lower and upper bounds for the target reactions
     target_limit_LB(targetSet) = 0;
     target_limit_UB(targetSet) = 0;
     target_limit_LB(targetSet) = CA_target_level_LB(targetSet);
     target_limit_UB(targetSet) = CA_target_level_UB(targetSet);
     MultiObjValue_FBA.lo(ObjectSet) = MultiObjValue_min(objectSet);
     MultiObjValue_FBA.up(ObjectSet) = MultiObjValue_max(objectSet);
     mem_objvalue_FBA.lo(objectSet) = 0;
     mem_objvalue_FBA.up(objectSet) = 1;
     TR_MultiObjvalue_Optim(objectset) = 0;
     Lambda.lo = 0;
     Lambda.up = 1;     
*-------------------------------------------------------------------------------
* set weightin factor for mem_objvalue_FBA for CA ------------------------------
     Weight_Lambda(ObjectSet) = 0;
     Weight_Lambda(ObjectSet) = TR_Weight_mem_obj_FBA(ObjectSet);
*-------------------------------------------------------------------------------
*---- solve regulated FBA problem ----------------------------------------------
     solve FBA_Problem using LP maximizing objValue_FBA ;
     nfeval_FBA_max = nfeval_FBA_max + 1;
     nfeval = nfeval + 1;
     pop_modelstat_FBA(NP) = FBA_Problem.modelstat;
     tmp_vf_FBA(reactions) = 0;
     tmp_vb_FBA(reactions) = 0;
     tmp_vf_FBA(dyn_reactions) = max(vf.l(dyn_reactions), 0);
     tmp_vb_FBA(dyn_reactions) = max(vb.l(dyn_reactions), 0);
     tmp_MultiObjvalue_Optim(Objectset) = 0;
     tmp_MultiObjvalue_Optim(dyn_objectset) = sum(dyn_reactions, coef_CellularObj_vf(dyn_objectset, dyn_reactions) * tmp_vf_FBA(dyn_reactions)) +
                                              sum(dyn_reactions, coef_CellularObj_vb(dyn_objectset, dyn_reactions) * tmp_vb_FBA(dyn_reactions));
     TR_MultiObjvalue_Optim(dyn_objectset) = tmp_MultiObjvalue_Optim(dyn_objectset);     

*---- infeasible solution ------------------------------------------------------
     if(pop_modelstat_FBA(NP) > 2,
        pop_FMObj_inner_TR(NP, ObjectSet) = 0;
        pop_FMObj_inner_PH(NP, ObjectSet) = 0;
        pop_FMObj_outer_TR(NP, ObjectSet) = 0;
        pop_FMObj_outer_PH(NP, ObjectSet) = 0;        
        pop_mem_Met_Exp_PHHT(NP) = 0;
        pop_mem_CV_TR(NP) = 0;
        pop_mem_CV_PH(NP) = 0;
        pop_mem_MD_TP(NP) = 0;
        pop_mem_Met_PHHT(NP) = 0;
        pop_mem_rxn_PHHT(NP) = 0;
        pop_mem_Met_PHCA(NP) = 0;
        pop_mem_rxn_PHCA(NP) = 0;
        pop_mem_Met_TRCA(NP) = 0;
        pop_mem_rxn_TRCA(NP) = 0;        
        pop_mem_Met_TRHT(NP) = 0;
        pop_mem_rxn_TRHT(NP) = 0;
        constraint_h(Dim_h) = 0;
        constraint_h(Dim_h) = sum(reactions, S_Matrix(Dim_h, reactions) * (vf.l(reactions) - vb.l(reactions)));
        tmp_constraint_h = sum(dyn_Fmin_Object, mem_objvalue_FBA.l(dyn_Fmin_Object) -
                               (MultiObjValue_max(dyn_Fmin_Object) - TR_MultiObjvalue_Optim(dyn_Fmin_Object))/
                               (MultiObjValue_max(dyn_Fmin_Object) - MultiObjValue_min(dyn_Fmin_Object))) +
                           sum(dyn_Fmax_Object, mem_objvalue_FBA.l(dyn_Fmax_Object) -
                               (TR_MultiObjvalue_Optim(dyn_Fmax_Object) - MultiObjValue_min(dyn_Fmax_Object))/
                               (MultiObjValue_max(dyn_Fmax_Object) - MultiObjValue_min(dyn_Fmax_Object)));                             
        constraint_g = sum(targetSet, max((target_limit_LB(targetSet) - (vf.l(targetSet) - vb.l(targetSet))), 0)) +
                       sum(targetSet, max(((vf.l(targetSet) - vb.l(targetSet)) - target_limit_UB(targetSet)), 0)) +
                       sum(dyn_ObjectSet, max((Lambda.l - mem_objvalue_FBA.l(dyn_ObjectSet)), 0));   
        constraint_FBA_TR = penalty * (sum(Dim_h, abs(constraint_h(Dim_h)) + abs(tmp_constraint_h)) + constraint_g););
*-------------------------------------------------------------------------------

*---- solve UFD problem --------------------------------------------------------
*%%%%% the user can modify the following procedures %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     if(pop_modelstat_FBA(NP) <= 2,
        pop_FMObj_inner_TR(NP, dyn_ObjectSet) = TR_MultiObjvalue_Optim(dyn_objectset);       
        Mem_Obj_FBA_limit(ObjectSet) = 0;
        Mem_Obj_FBA_limit(dyn_Fmax_Object) = ((TR_MultiObjvalue_Optim(dyn_Fmax_Object) - MultiObjValue_min(dyn_Fmax_Object))/
                                              (MultiObjValue_max(dyn_Fmax_Object) - MultiObjValue_min(dyn_Fmax_Object)));
                                        
        Mem_Obj_FBA_limit(dyn_Fmin_Object) = ((MultiObjValue_max(dyn_Fmin_Object) - TR_MultiObjvalue_Optim(dyn_Fmin_Object))/
                                              (MultiObjValue_max(dyn_Fmin_Object) - MultiObjValue_min(dyn_Fmin_Object)));
        Mem_Obj_FBA_limit(dyn_ObjectSet) = max(min( Mem_Obj_FBA_limit(dyn_ObjectSet), 1), 0);                                              
** assign weighting coefficients for Rxn for computing ObjValue in UFD ******************************************************************************
        weight_coef_rxn(reactions) = Weight_factor_Rxn_OT;
        weight_coef_rxn(reactions) $ (CA_Reactions_HC(reactions)) = Weight_factor_Rxn_HC;
        weight_coef_rxn(reactions) $ (CA_Reactions_MC(reactions)) = Weight_factor_Rxn_MC;
        weight_coef_rxn(reactions) $ (CA_Reactions_NC(reactions)) = Weight_factor_Rxn_NC;
*****************************************************************************************************************************************************        
*----- compute the lower and upper bounds for the target reactions ------------
        target_limit_LB(targetSet) = 0;
        target_limit_UB(targetSet) = 0;
        target_limit_LB(targetSet) = CA_target_level_LB(targetSet);
        target_limit_UB(targetSet) = CA_target_level_UB(targetSet);
        MultiObjValue_FBA.lo(ObjectSet) = MultiObjValue_min(objectSet);
        MultiObjValue_FBA.up(ObjectSet) = MultiObjValue_max(objectSet);
        mem_objvalue_FBA.lo(objectSet) = 0;
        mem_objvalue_FBA.up(objectSet) = 1;
*------------------------------------------------------------------------------
        
        TR_vf_UFD(reactions) = 0;
        TR_vb_UFD(reactions) = 0;
        if(flag_UFD_Obj = 1, solve UFD1_Problem using LP minimizing ObjValue_UFD;);
        if(flag_UFD_Obj = 2, solve UFD2_Problem using LP minimizing ObjValue_UFD;);
        if(flag_UFD_Obj = 3, solve UFD3_Problem using QCP minimizing ObjValue_UFD;);
        if(flag_UFD_Obj = 4, solve UFD4_Problem using QCP minimizing ObjValue_UFD;);
        nfeval_UFD_min = nfeval_UFD_min + 1;
        nfeval = nfeval + 1;
        pop_modelstat_UFD(NP) = UFD%No_UFD_Obj%_Problem.modelstat;
        TR_vf_UFD(reactions) = max(vf.l(reactions), 0);
        TR_vb_UFD(reactions) = max(vb.l(reactions), 0);
        TR_v_UFD(reactions) = TR_vf_UFD(reactions) - TR_vb_UFD(reactions);
 
*---- infeasible solution ------------------------------------------------------
        if(pop_modelstat_UFD(NP) > 2,
           pop_FMObj_inner_TR(NP, ObjectSet) = 0;
           pop_FMObj_inner_PH(NP, ObjectSet) = 0;
           pop_FMObj_outer_TR(NP, ObjectSet) = 0;
           pop_FMObj_outer_PH(NP, ObjectSet) = 0;           
           pop_mem_Met_Exp_PHHT(NP) = 0;           
           pop_mem_CV_TR(NP) = 0;
           pop_mem_CV_PH(NP) = 0;
           pop_mem_MD_TP(NP) = 0;
           pop_mem_Met_PHHT(NP) = 0;
           pop_mem_rxn_PHHT(NP) = 0;
           pop_mem_Met_PHCA(NP) = 0;
           pop_mem_rxn_PHCA(NP) = 0;
           pop_mem_Met_TRCA(NP) = 0;
           pop_mem_rxn_TRCA(NP) = 0;           
           pop_mem_Met_TRHT(NP) = 0;
           pop_mem_rxn_TRHT(NP) = 0;
           constraint_h(Dim_h) = 0;
           constraint_h(Dim_h) = sum(reactions, S_Matrix(Dim_h, reactions) * (vf.l(reactions) - vb.l(reactions)));
           tmp_constraint_h = sum(dyn_Fmin_Object, mem_objvalue_FBA.l(dyn_Fmin_Object) -
                               (MultiObjValue_max(dyn_Fmin_Object) - MultiObjValue_FBA.l(dyn_Fmin_Object))/
                               (MultiObjValue_max(dyn_Fmin_Object) - MultiObjValue_min(dyn_Fmin_Object))) +
                              sum(dyn_Fmax_Object, mem_objvalue_FBA.l(dyn_Fmax_Object) -
                               (MultiObjValue_FBA.l(dyn_Fmax_Object) - MultiObjValue_min(dyn_Fmax_Object))/
                               (MultiObjValue_max(dyn_Fmax_Object) - MultiObjValue_min(dyn_Fmax_Object)));                              
           constraint_g = sum(targetSet, max((target_limit_LB(targetSet) - (vf.l(targetSet) - vb.l(targetSet))), 0)) +
                          sum(targetSet, max(((vf.l(targetSet) - vb.l(targetSet)) - target_limit_UB(targetSet)), 0)) +
                          sum(dyn_ObjectSet, max((Mem_Obj_FBA_limit(dyn_ObjectSet) - mem_objvalue_FBA.l(dyn_ObjectSet)), 0));   
           constraint_UFD_TR = penalty * (sum(Dim_h, abs(constraint_h(Dim_h)) + abs(tmp_constraint_h)) + constraint_g););
*-------------------------------------------------------------------------------

        if(pop_modelstat_UFD(NP) <= 2,
        
**** compute membership grades of fuzzy max and min objectives for outer TR model *******************************************************************
           TR_MultiObjvalue_Optim(Objectset) = 0;
           TR_MultiObjvalue_Optim(dyn_obj_outer) = sum(dyn_reactions, coef_CellularObj_vf(dyn_obj_outer, dyn_reactions) * TR_vf_UFD(dyn_reactions)) +
                                                   sum(dyn_reactions, coef_CellularObj_vb(dyn_obj_outer, dyn_reactions) * TR_vb_UFD(dyn_reactions));  
           pop_FMObj_outer_TR(NP, dyn_obj_outer) = TR_MultiObjvalue_Optim(dyn_obj_outer);
           
**** compute membership grades of fuzzy max and min objectives for outer TR model *******************************************************************
           Mem_Obj_FBA_limit(ObjectSet) = 0;
           Mem_Obj_FBA_limit(dyn_Fmax_Obj_outer) = (TR_MultiObjvalue_Optim(dyn_Fmax_Obj_outer) - MultiObjValue_min(dyn_Fmax_Obj_outer))/
                                                   (MultiObjValue_max(dyn_Fmax_Obj_outer) - MultiObjValue_min(dyn_Fmax_Obj_outer));
           Mem_Obj_FBA_limit(dyn_Fmin_Obj_outer) = (MultiObjValue_max(dyn_Fmin_Obj_outer) - TR_MultiObjvalue_Optim(dyn_Fmin_Obj_outer))/
                                                   (MultiObjValue_max(dyn_Fmin_Obj_outer) - MultiObjValue_min(dyn_Fmin_Obj_outer));
           Mem_Obj_FBA_limit(dyn_obj_outer) = max(min( Mem_Obj_FBA_limit(dyn_obj_outer), 1), 0);                                       
           mem_PriObj_Outer_TR = sum(dyn_priority_outer, Mem_Obj_FBA_limit(dyn_priority_outer))/No_priority_outer;
           pop_mem_CV_TR(NP) = 0.5 * (mem_PriObj_Outer_TR + smin(dyn_obj_outer, Mem_Obj_FBA_limit(dyn_obj_outer)));
*****************************************************************************************************************************************************

*=== compute synthesis rate for each species of treated TR model ====================================================================================
           TR_Species_SynRate(species) = 0;
           loop(dyn_species,
                TR_Species_SynRate(dyn_species) = sum(dyn_reactions, S_Matrix(dyn_species, dyn_reactions) $
                                                      (S_Matrix(dyn_species, dyn_reactions) > 0) * TR_vf_UFD(dyn_reactions))
                                                 - sum(dyn_reactions, S_Matrix(dyn_Species, dyn_reactions) $
                                                      (S_Matrix(dyn_species, dyn_reactions) < 0) * TR_vb_UFD(dyn_reactions)););

***** compute synthesis rate for each biocompound of treated TR model *******************************************************************************
           TR_BioComp_SynRate(BioCompound) = 0;
           loop(dyn_BioComp,
                TR_BioComp_SynRate(dyn_BioComp) = sum(dyn_Species $ (BioCompound_species(dyn_BioComp, dyn_Species)),
                                                       TR_Species_SynRate(dyn_Species)););
                                                       
***** compute fuzzy similarity of metabolite-flow and its membership grade for TRHT model ***********************************************************
           L_mem_Met_tmp(biocompound) = 0;
           R_mem_Met_tmp(biocompound) = 0;
           mem_Met_tmp(biocompound) = 0;             
           L_mem_Met_tmp(BioComp_TRHT) $ (HT_BioComp_SynRate(BioComp_TRHT) > 0) =
                                         (TR_BioComp_SynRate(BioComp_TRHT) - HT_MetFlowRate_LB(BioComp_TRHT))/
                                         (HT_BioComp_SynRate(BioComp_TRHT) - HT_MetFlowRate_LB(BioComp_TRHT));                                         
           L_mem_Met_tmp(BioComp_TRHT) $ (HT_BioComp_SynRate(BioComp_TRHT) = 0) = 1;
           R_mem_Met_tmp(BioComp_TRHT) = (HT_MetFlowRate_UB(BioComp_TRHT) - TR_BioComp_SynRate(BioComp_TRHT))/
                                         (HT_MetFlowRate_UB(BioComp_TRHT) - HT_BioComp_SynRate(BioComp_TRHT));  
           mem_Met_tmp(BioComp_TRHT) = max(min(L_mem_Met_tmp(BioComp_TRHT), R_mem_Met_tmp(BioComp_TRHT), 1), 0);             

           nonzero_Biocomp(biocompound) = no;             
           nonzero_Biocomp(biocompound) $ ((TR_BioComp_SynRate(biocompound) > 0 or
                                            HT_BioComp_SynRate(biocompound) > 0) and BioComp_TRHT(biocompound)) = yes;

           No_nonzero_Biocomp_TRHT = card(nonzero_Biocomp);                                               
           pop_mem_Met_TRHT(NP) = sum(BioCompound $ (nonzero_Biocomp(biocompound)), mem_Met_tmp(BioCompound))/No_nonzero_Biocomp_TRHT;

*****************************************************************************************************************************************************
***** compute fuzzy similarity of flux and its membership grade for TRHT model **********************************************************************
           L_mem_vf_tmp(reactions) = 0;
           R_mem_vf_tmp(reactions) = 0;
           L_mem_vb_tmp(reactions) = 0;
           R_mem_vb_tmp(reactions) = 0;
           L_mem_vf_tmp(rxn_vf_TRHT) $ (HT_vf_UFD(rxn_vf_TRHT) > 0) =
                                       (TR_vf_UFD(rxn_vf_TRHT) - HT_vf_rxn_LB(rxn_vf_TRHT))/
                                       (HT_vf_UFD(rxn_vf_TRHT) - HT_vf_rxn_LB(rxn_vf_TRHT));
           L_mem_vf_tmp(rxn_vf_TRHT) $ (HT_vf_UFD(rxn_vf_TRHT) = 0) = 1;
           R_mem_vf_tmp(rxn_vf_TRHT) = (HT_vf_rxn_UB(rxn_vf_TRHT) - TR_vf_UFD(rxn_vf_TRHT))/
                                       (HT_vf_rxn_UB(rxn_vf_TRHT)- HT_vf_UFD(rxn_vf_TRHT));           
           L_mem_vb_tmp(rxn_vb_TRHT) $ (HT_vb_UFD(rxn_vb_TRHT) > 0) =
                                       (TR_vb_UFD(rxn_vb_TRHT) - HT_vb_rxn_LB(rxn_vb_TRHT))/
                                       (HT_vb_UFD(rxn_vb_TRHT) - HT_vb_rxn_LB(rxn_vb_TRHT));
           L_mem_vb_tmp(rxn_vb_TRHT) $ (HT_vb_UFD(rxn_vb_TRHT) = 0) = 1;
           R_mem_vb_tmp(rxn_vb_TRHT) = (HT_vb_rxn_UB(rxn_vb_TRHT) - TR_vb_UFD(rxn_vb_TRHT))/
                                       (HT_vb_rxn_UB(rxn_vb_TRHT)- HT_vb_UFD(rxn_vb_TRHT));    

**** intialization
           mem_vf_tmp(reactions) = 0;
           mem_vb_tmp(reactions) = 0;
              
           mem_vf_tmp(rxn_vf_TRHT) = max(min(L_mem_vf_tmp(rxn_vf_TRHT), R_mem_vf_tmp(rxn_vf_TRHT), 1), 0);
           mem_vb_tmp(rxn_vb_TRHT) = max(min(L_mem_vb_tmp(rxn_vb_TRHT), R_mem_vb_tmp(rxn_vb_TRHT), 1), 0);

           nonzero_vf(reactions) = no;
           nonzero_vf(reactions) $ ((TR_vf_UFD(reactions) > 0 or
                                     HT_vf_UFD(reactions) > 0) and rxn_vf_TRHT(reactions)) = yes;
           nonzero_vb(reactions) = no;
           nonzero_vb(reactions) $ ((TR_vb_UFD(reactions) > 0 or
                                     HT_vb_UFD(reactions) > 0) and rxn_vb_TRHT(reactions)) = yes;

           nonzero_v(reactions) = no;                               
           nonzero_v(reactions) =  nonzero_vf(reactions) + nonzero_vb(reactions);
           No_nonzero_vf_TRHT = card(nonzero_vf);
           No_nonzero_vb_TRHT = card(nonzero_vb);              
           No_nonzero_v_TRHT = card(nonzero_v);
           pop_mem_rxn_TRHT(NP) = sum(reactions $ (nonzero_v(reactions)),             
                                      min(mem_vf_tmp(reactions),mem_vb_tmp(reactions)))/No_nonzero_v_TRHT;           
*====================================================================================================================================================
***** compute fuzzy dissimilarity of metabolite-flow and its membership grade for TRCA model ********************************************************
           L_mem_Met_tmp(biocompound) = 0;
           R_mem_Met_tmp(biocompound) = 0;
           mem_Met_tmp(biocompound) = 0;             
           L_mem_Met_tmp(BioComp_TRCA) $ (CA_BioComp_SynRate(BioComp_TRCA) > 0) =         
                                         (CA_BioComp_SynRate(BioComp_TRCA) - TR_BioComp_SynRate(BioComp_TRCA))/
                                         (CA_BioComp_SynRate(BioComp_TRCA) - CA_MetFlowRate_LB(BioComp_TRCA));
           L_mem_Met_tmp(BioComp_TRCA) $ (CA_BioComp_SynRate(BioComp_TRCA) = 0) = 0;
           R_mem_Met_tmp(BioComp_TRCA) = (TR_BioComp_SynRate(BioComp_TRCA) - CA_BioComp_SynRate(BioComp_TRCA))/
                                         (CA_MetFlowRate_UB(BioComp_TRCA) - CA_BioComp_SynRate(BioComp_TRCA));                                         
           mem_Met_tmp(BioComp_TRCA) = min(max(L_mem_Met_tmp(BioComp_TRCA), R_mem_Met_tmp(BioComp_TRCA), 0), 1);

           nonzero_Biocomp(biocompound) = no;             
           nonzero_Biocomp(biocompound) $ ((TR_BioComp_SynRate(biocompound) > 0 or
                                            CA_BioComp_SynRate(biocompound) > 0) and BioComp_TRCA(biocompound)) = yes;

           No_nonzero_Biocomp_TRCA = card(nonzero_Biocomp);                                               
           pop_mem_Met_TRCA(NP) = sum(BioCompound $ (nonzero_Biocomp(biocompound)), mem_Met_tmp(BioCompound))/No_nonzero_Biocomp_TRCA;

***** compute fuzzy dissimilarity of flux and its membership grade for TRCA model ********************************************************************
           L_mem_vf_tmp(reactions) = 0;
           R_mem_vf_tmp(reactions) = 0;
           L_mem_vb_tmp(reactions) = 0;
           R_mem_vb_tmp(reactions) = 0;          
           L_mem_vf_tmp(rxn_vf_TRCA) $ (CA_vf_UFD(rxn_vf_TRCA) > 0) = (CA_vf_UFD(rxn_vf_TRCA) - TR_vf_UFD(rxn_vf_TRCA))/
                                                                     (CA_vf_UFD(rxn_vf_TRCA) - CA_vf_rxn_LB(rxn_vf_TRCA));
           L_mem_vf_tmp(rxn_vf_TRCA) $ (CA_vf_UFD(rxn_vf_TRCA) = 0) = 0;          
           R_mem_vf_tmp(rxn_vf_TRCA) = (TR_vf_UFD(rxn_vf_TRCA) - CA_vf_UFD(rxn_vf_TRCA))/
                                       (CA_vf_rxn_UB(rxn_vf_TRCA)- CA_vf_UFD(rxn_vf_TRCA));                                       
           L_mem_vb_tmp(rxn_vb_TRCA) $ (CA_vb_UFD(rxn_vb_TRCA) > 0) = (CA_vb_UFD(rxn_vb_TRCA) - TR_vb_UFD(rxn_vb_TRCA))/
                                                                      (CA_vb_UFD(rxn_vb_TRCA) - CA_vb_rxn_LB(rxn_vb_TRCA));
           L_mem_vb_tmp(rxn_vb_TRCA) $ (CA_vb_UFD(rxn_vb_TRCA) = 0) = 0;                                                                                                            
           R_mem_vb_tmp(rxn_vb_TRCA) = (TR_vb_UFD(rxn_vb_TRCA) - CA_vb_UFD(rxn_vb_TRCA))/
                                       (CA_vb_rxn_UB(rxn_vb_TRCA)- CA_vb_UFD(rxn_vb_TRCA));    

**** intialization
           mem_vf_tmp(reactions) = 0;
           mem_vb_tmp(reactions) = 0;               
           mem_vf_tmp(rxn_vf_TRCA) = min(max(L_mem_vf_tmp(rxn_vf_TRCA), R_mem_vf_tmp(rxn_vf_TRCA), 0), 1);
           mem_vb_tmp(rxn_vb_TRCA) = min(max(L_mem_vb_tmp(rxn_vb_TRCA), R_mem_vb_tmp(rxn_vb_TRCA), 0), 1);

           nonzero_vf(reactions) = no;
           nonzero_vf(reactions) $ ((TR_vf_UFD(reactions) > 0 or
                                     CA_vf_UFD(reactions) > 0) and rxn_vf_TRCA(reactions)) = yes;
           nonzero_vb(reactions) = no;
           nonzero_vb(reactions) $ ((TR_vb_UFD(reactions) > 0 or
                                     CA_vb_UFD(reactions) > 0) and rxn_vb_TRCA(reactions)) = yes;
                                     
           nonzero_v(reactions) = no;                               
           nonzero_v(reactions) =  nonzero_vf(reactions) + nonzero_vb(reactions);
           No_nonzero_vf_TRCA = card(nonzero_vf);
           No_nonzero_vb_TRCA = card(nonzero_vb);              
           No_nonzero_v_TRCA = card(nonzero_v);
           pop_mem_rxn_TRCA(NP) = sum(reactions $ (nonzero_v(reactions)),             
                                      max(mem_vf_tmp(reactions),mem_vb_tmp(reactions)))/No_nonzero_v_TRCA;  
*****************************************************************************************************************************************************
           constraint_FBA_TR  = 0;
           constraint_UFD_TR  = 0;
*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
*===== evaluating side effects to solve perturbed FBA and UFD problems of HT model ==================================================================
***** Fuzzy multiobjective HT FBA Problem ***********************************************************************************************************
***** assign reactions and species in FMO HT models as dynamic sets ****************   
           dyn_reactions(reactions) = no;
           dyn_species(species) = no;
           dyn_BioComp(biocompound) = no;
           dyn_irrev_rxn(reactions) = no;
           dyn_rev_rxn(reactions) = no;
           dyn_exchange_rxn(reactions) = no;
           dyn_objectSet(objectSet) = no;
           dyn_Fmax_Object(ObjectSet) = no;
           dyn_Fmin_Object(ObjectSet) = no;
           dyn_priority_obj(ObjectSet) = no;
           dyn_obj_outer(objectSet) = no;
           dyn_Fmax_Obj_outer(ObjectSet) = no;
           dyn_Fmin_Obj_outer(ObjectSet) = no;
           dyn_priority_outer(ObjectSet) = no;    

**** objectives used in inner optimization problem
           dyn_reactions(reactions)  $ (not reactions_NHT(reactions)) = yes;
           dyn_species(species) $ (not species_NHT(species)) = yes;
           dyn_BioComp(biocompound) $ (not biocompound_NHT(biocompound)) = yes;
           dyn_irrev_rxn(reactions) $ (not reactions_NHT(reactions) and irrev_rxn(reactions)) = yes;
           dyn_rev_rxn(reactions) $ (not reactions_NHT(reactions) and rev_rxn(reactions)) = yes;
           dyn_exchange_rxn(reactions) $ (not reactions_NHT(reactions) and exchange_rxn(reactions)) = yes;
           dyn_Fmax_Object(ObjectSet) $ (FmaxObj_inner_PH(ObjectSet)) = yes;
           dyn_Fmin_Object(ObjectSet) $ (FminObj_inner_PH(ObjectSet)) = yes;
           dyn_objectSet(objectSet) = dyn_Fmax_Object(ObjectSet) + dyn_Fmin_Object(ObjectSet);
           dyn_priority_obj(ObjectSet) $ (PriObj_inner_PH(ObjectSet)) = yes;
           No_priority_obj = card(PriObj_inner_PH);
**** objectives used in outer optimization problem     
           dyn_Fmax_Obj_outer(ObjectSet) $ (FmaxObj_Outer_PH(ObjectSet)) = yes;
           dyn_Fmin_Obj_outer(ObjectSet) $ (FminObj_Outer_PH(ObjectSet)) = yes;
           dyn_obj_outer(objectSet) = dyn_Fmax_Obj_outer(ObjectSet) + dyn_Fmin_Obj_outer(ObjectSet);
           dyn_priority_outer(ObjectSet) $ (PriObj_Outer_PH(ObjectSet)) = yes;
           No_priority_outer = card(PriObj_Outer_PH);
********************************************************************************

***** Set the weighting factors and limits for FBA objectives ******************
           basal_vf(reactions) = 0;
           basal_vb(reactions) = 0;
           basal_vf(reactions) = HT_vf_UFD(reactions);
           basal_vb(reactions) = HT_vb_UFD(reactions);
*******************************************************************************
*--- reset the oringinal bounds for all fluxes ------------------------------------------------------------------------------------------------------
           FluxBound_vf_LB(reactions) = tmp_FluxBound_vf_LB(reactions);
           FluxBound_vb_LB(reactions) = tmp_FluxBound_vb_LB(reactions);
           FluxBound_vf_UB(reactions) = tmp_FluxBound_vf_UB(reactions);
           FluxBound_vb_UB(reactions) = tmp_FluxBound_vb_UB(reactions);
*----------------------------------------------------------------------------------------------------------------------------------------------------
 
*---- restrictions for the lower and upper bounds of fluxes --------------------
           vf.lo(reactions) = FluxBound_vf_LB(reactions);
           vf.up(reactions) = FluxBound_vf_UB(reactions);
           vb.lo(reactions) = FluxBound_vb_LB(reactions);
           vb.up(reactions) = FluxBound_vb_UB(reactions);

*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
           z_isozyme_rxn_enz(reactions, enzymes) = no;
           z_isozyme_rxn(reactions) = no;
           z_HDE_tmp(reactions, enzymes) = 0;
           Regulated_Rxn_v(reactions) = NO;
           dyn_Reg_ExRxn(reactions) = no;
           loop(Dim_BI $ (z_HDE(Dim_BI) >= 1),
                Regulated_rxn_v(reactions) $ (enzyme_Reg_rxn_v(Dim_BI, reactions) and dyn_reactions(reactions)) = yes;

***** assign the regulated reactions to be some levels *************************
* up regulated v
                if(z_HDE(Dim_BI) = 1,
                   vf.lo(Regulated_rxn_v(reactions)) = basal_vf(reactions) + TR_Reg_factor(NP) * (FluxBound_vf_UB(reactions) - basal_vf(reactions));
                   vf.up(Regulated_rxn_v(reactions)) = FluxBound_vf_UB(reactions);
                   vb.lo(Regulated_rxn_v(reactions)) = FluxBound_vb_LB(reactions);
                   vb.up(Regulated_rxn_v(reactions)) = basal_vb(reactions) + TR_Reg_factor(NP) * (FluxBound_vb_LB(reactions) - basal_vb(reactions)););

* down regulated v
                if(z_HDE(Dim_BI) = 2,
                   vf.lo(Regulated_rxn_v(reactions)) = FluxBound_vf_LB(reactions);
                   vf.up(Regulated_rxn_v(reactions)) = basal_vf(reactions) + TR_Reg_factor(NP) * (FluxBound_vf_LB(reactions) - basal_vf(reactions));
                   vb.lo(Regulated_rxn_v(reactions)) = basal_vb(reactions) + TR_Reg_factor(NP) * (FluxBound_vb_UB(reactions) - basal_vb(reactions));
                   vb.up(Regulated_rxn_v(reactions)) = FluxBound_vb_UB(reactions);

*---- the down regulated reaction by Dim_BI is dominatd by other isozymes ------
                   vf.lo(reactions) $ (Regulated_rxn_v(reactions) and isozyme_rxn(reactions)) = (1 - flux_bounded_ratio) * basal_vf(reactions);
                   vf.up(reactions) $ (Regulated_rxn_v(reactions) and isozyme_rxn(reactions)) = (1 + flux_bounded_ratio) * basal_vf(reactions);
                   vb.lo(reactions) $ (Regulated_rxn_v(reactions) and isozyme_rxn(reactions)) = (1 - flux_bounded_ratio) * basal_vb(reactions);
                   vb.up(reactions) $ (Regulated_rxn_v(reactions) and isozyme_rxn(reactions)) = (1 + flux_bounded_ratio) * basal_vb(reactions););
*-------------------------------------------------------------------------------
*---- knockout vf and vb -------------------------------------------------------
                if(z_HDE(Dim_BI) = 3,
                   vf.fx(Regulated_rxn_v(reactions)) = 0;
                   vb.fx(Regulated_rxn_v(reactions)) = 0;

*---- the KO reaction by Dim_BI is dominatd by other isozymes ------------------
                   vf.lo(reactions) $ (Regulated_rxn_v(reactions) and isozyme_rxn(reactions)) = (1 - flux_bounded_ratio) * basal_vf(reactions);
                   vf.up(reactions) $ (Regulated_rxn_v(reactions) and isozyme_rxn(reactions)) = (1 + flux_bounded_ratio) * basal_vf(reactions);
                   vb.lo(reactions) $ (Regulated_rxn_v(reactions) and isozyme_rxn(reactions)) = (1 - flux_bounded_ratio) * basal_vb(reactions);
                   vb.up(reactions) $ (Regulated_rxn_v(reactions) and isozyme_rxn(reactions)) = (1 + flux_bounded_ratio) * basal_vb(reactions););
*-------------------------------------------------------------------------------

*---- reaction is regulated by isozyme -----------------------------------------
                   z_isozyme_rxn(reactions) $ (Regulated_rxn_v(reactions) and isozyme_rxn(reactions)) = yes;
                   z_isozyme_rxn_enz(reactions, Dim_BI) $ (Regulated_rxn_v(reactions) and isozyme_rxn(reactions)) = yes;
                   z_HDE_tmp(reactions, Dim_BI) $ (Regulated_rxn_v(reactions) and isozyme_rxn(reactions)) = z_HDE(Dim_BI);
                   dyn_Reg_ExRxn(reactions) = dyn_Reg_ExRxn(reactions) + Regulated_rxn_v(reactions);
                   Regulated_Rxn_v(reactions) = NO;);

***** Decide the regulated reaction to be up/down/KO if all isozymes are selected by NHDE ***********************************************************
           if((card(Dim_XI) > 1 and sum(reactions $ (z_isozyme_rxn(reactions)), 1) > 0),
              loop(reactions $ (z_isozyme_rxn(reactions) and sum(Dim_BI $ (z_HDE(Dim_BI) >= 1 and z_isozyme_rxn_enz(reactions, Dim_BI)), 1) =
                                sum(enzymes $ (isozyme_rxn_enz(reactions, enzymes)), 1)),
*---- The reaction is KO if all isozymes are KO, z_HDE_tmp = 3 --------------------------------------------------------------------------------------
                   if(sum(Dim_BI $ (z_HDE(Dim_BI) >= 1), z_HDE_tmp(reactions, Dim_BI)) = 3 * sum(Dim_BI $ (z_HDE(Dim_BI) >= 1 and z_isozyme_rxn_enz(reactions, Dim_BI)), 1),
                      vf.fx(reactions) $ (z_isozyme_rxn(reactions)) = 0;
                      vb.fx(reactions) $ (z_isozyme_rxn(reactions)) = 0;);

*---- The reaction is down/up, (set to down firstly) if one of the isozymes is down/up --------------------------------------------------------------
                   if(sum(Dim_BI $ (z_HDE(Dim_BI) >= 1), z_HDE_tmp(reactions, Dim_BI)) < 3 * sum(Dim_BI $ (z_HDE(Dim_BI) >= 1 and z_isozyme_rxn_enz(reactions, Dim_BI) ), 1),
                      vf.lo(reactions) $ (z_isozyme_rxn(reactions)) = FluxBound_vf_LB(reactions);
                      vf.up(reactions) $ (z_isozyme_rxn(reactions)) = basal_vf(reactions) + TR_Reg_factor(NP) *
                                                                     (FluxBound_vf_LB(reactions) - basal_vf(reactions));
                      vb.lo(reactions) $ (z_isozyme_rxn(reactions)) = basal_vb(reactions) + TR_Reg_factor(NP) *
                                                                     (FluxBound_vb_UB(reactions) - basal_vb(reactions));
                      vb.up(reactions) $ (z_isozyme_rxn(reactions)) = FluxBound_vb_UB(reactions););

*---- The above reaction is reassigned to up, if one of the isozymes is up --------------------------------------------------------------------------
                   loop(Dim_BI $ (z_HDE(Dim_BI) >= 1 and z_HDE_tmp(reactions, Dim_BI) = 1 and z_isozyme_rxn(reactions)),
                        vf.lo(reactions) = basal_vf(reactions) + TR_Reg_factor(NP) * (FluxBound_vf_UB(reactions) - basal_vf(reactions));
                        vf.up(reactions) = FluxBound_vf_UB(reactions);
                        vb.lo(reactions) = FluxBound_vb_LB(reactions);
                        vb.up(reactions) = basal_vb(reactions) + TR_Reg_factor(NP) * (FluxBound_vb_LB(reactions) - basal_vb(reactions));
                        break $ (z_HDE_tmp(reactions, Dim_BI) = 1););
              );
           );
*----------------------------------------------------------------------------------------------------------------------------------------------------

*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
* assign vb = 0 for the irreversible fluxes
           vb.lo(irrev_rxn) = 0;
           vb.up(irrev_rxn) = 0;
           vb.fx(irrev_rxn) = 0;
           vb.fx(DM_sink_rxn(reactions)) $ (flag_DM_sink = 1) = 0;
           vf.lo(irrev_vb_rxn(reactions)) = 0;
           vf.up(irrev_vb_rxn(reactions)) = 0;
           vf.fx(irrev_vb_rxn(reactions)) = 0;

* assign the demanded uptake/secretion reactions
           vf.fx(uptake_demand) = 0;
           vb.fx(secretion_demand) = 0;
           vb.fx(uptake_fixed) = FluxBound_vb_LB(uptake_fixed);

* irreversible uptake_rxn and secretion_rxn
           vf.fx(uptake_rxn(reactions)) $ (flag_uptake = 1 and not dyn_Reg_ExRxn(reactions)) = 0;
           vb.fx(secretion_rxn(reactions)) $ (flag_secretion = 1 and not dyn_Reg_ExRxn(reactions)) = 0;

           vf.fx(uptake_demand(reactions)) $ (card(uptake_demand) > 0) = 0;
           vb.fx(secretion_demand(reactions)) $ (card(secretion_demand) > 0) = 0;
********************************************************************************

*** Assign vf > 0 and vb = 0 for the Specific_rxn_vf --------------------------------
           if(card(PH_Specific_rxn_vf) > 0,
              vf.lo(PH_Specific_rxn_vf) =  PH_Specific_rxn_vf_LB(PH_Specific_rxn_vf);
              vf.up(PH_Specific_rxn_vf) =  PH_Specific_rxn_vf_UB(PH_Specific_rxn_vf);
              vb.lo(PH_Specific_rxn_vf) =  0;
              vb.up(PH_Specific_rxn_vf) =  0;
              vb.fx(PH_Specific_rxn_vf) =  0;);
********************************************************************************
*** Assign vf = 0 and vb > 0 for the Specific_rxn_vb --------------------------------
           if(card(PH_Specific_rxn_vb) > 0,
              vb.lo(PH_Specific_rxn_vb) =  PH_Specific_rxn_vb_LB(PH_Specific_rxn_vb);
              vb.up(PH_Specific_rxn_vb) =  PH_Specific_rxn_vb_UB(PH_Specific_rxn_vb);
              vf.lo(PH_Specific_rxn_vb) =  0;
              vf.up(PH_Specific_rxn_vb) =  0;
              vf.fx(PH_Specific_rxn_vb) =  0;); 
*** Assign vf > 0 and vb > 0 for the Specific_rxn_vfvb -------------------------------
           if(card(PH_Specific_rxn_vfvb) > 0,
              vf.lo(PH_Specific_rxn_vfvb) =  PH_Specific_rxn_vf_LB(PH_Specific_rxn_vfvb);
              vf.up(PH_Specific_rxn_vfvb) =  PH_Specific_rxn_vf_UB(PH_Specific_rxn_vfvb);
              vb.lo(PH_Specific_rxn_vfvb) =  PH_Specific_rxn_vb_LB(PH_Specific_rxn_vfvb);
              vb.up(PH_Specific_rxn_vfvb) =  PH_Specific_rxn_vb_UB(PH_Specific_rxn_vfvb););    
*******************************************************************************

*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
*----- compute the lower and upper bounds for the target reactions
           target_limit_LB(targetSet) = 0;
           target_limit_UB(targetSet) = 0;
           target_limit_LB(targetSet) = HT_target_level_LB(targetSet);
           target_limit_UB(targetSet) = HT_target_level_UB(targetSet);
           MultiObjValue_FBA.lo(ObjectSet) = MultiObjValue_min(objectSet);
           MultiObjValue_FBA.up(ObjectSet) = MultiObjValue_max(objectSet);
           mem_objvalue_FBA.lo(objectSet) = 0;
           mem_objvalue_FBA.up(objectSet) = 1;
           PH_MultiObjvalue_Optim(ObjectSet) = 0;
           Lambda.lo = 0;
           Lambda.up = 1;           
*-------------------------------------------------------------------------------
* set weightin factor for mem_objvalue_FBA for HT ------------------------------
           Weight_Lambda(ObjectSet) = 0;
           Weight_Lambda(ObjectSet) = PH_Weight_mem_obj_FBA(ObjectSet);
*-------------------------------------------------------------------------------
*---- solve mutant FBA problem considering side effect -------------------------
           solve FBA_Problem using LP maximizing objValue_FBA ;
           nfeval_FBA_max = nfeval_FBA_max + 1;
           nfeval = nfeval + 1;
           tmp_vf_FBA(reactions) = 0;
           tmp_vb_FBA(reactions) = 0;
           tmp_vf_FBA(dyn_reactions) = max(vf.l(dyn_reactions), 0);
           tmp_vb_FBA(dyn_reactions) = max(vb.l(dyn_reactions), 0);
           tmp_MultiObjvalue_Optim(Objectset) = 0;
           tmp_MultiObjvalue_Optim(dyn_objectset) = sum(dyn_reactions, coef_CellularObj_vf(dyn_objectset, dyn_reactions) * tmp_vf_FBA(dyn_reactions)) +
                                                    sum(dyn_reactions, coef_CellularObj_vb(dyn_objectset, dyn_reactions) * tmp_vb_FBA(dyn_reactions));           
           PH_MultiObjvalue_Optim(dyn_objectset) = tmp_MultiObjvalue_Optim(dyn_objectset);
*---- infeasible solution ------------------------------------------------------
           if(FBA_Problem.modelstat > 2,
              pop_FMObj_inner_TR(NP, ObjectSet) $ (pop_modelstat_UFD(NP) > 2) = 0;
              pop_FMObj_inner_PH(NP, ObjectSet) = 0;
              pop_FMObj_outer_TR(NP, ObjectSet) $ (pop_modelstat_UFD(NP) > 2) = 0;
              pop_FMObj_outer_PH(NP, ObjectSet) = 0;  
              pop_mem_CV_TR(NP) $ (pop_modelstat_UFD(NP) > 2) = 0;
              pop_mem_Met_Exp_PHHT(NP) = 0;
              pop_mem_CV_PH(NP) = 0;
              pop_mem_MD_TP(NP) = 0;
              pop_mem_Met_PHHT(NP) = 0;
              pop_mem_rxn_PHHT(NP) = 0;
              pop_mem_Met_PHCA(NP) = 0;
              pop_mem_rxn_PHCA(NP) = 0;
              pop_mem_Met_TRCA(NP) = 0;
              pop_mem_rxn_TRCA(NP) = 0;              
              pop_mem_Met_TRHT(NP) $ (pop_modelstat_UFD(NP) > 2) = 0;
              pop_mem_rxn_TRHT(NP) $ (pop_modelstat_UFD(NP) > 2) = 0;
              constraint_h(Dim_h) = 0;
              constraint_h(Dim_h) = sum(reactions, S_Matrix(Dim_h, reactions) * (vf.l(reactions) - vb.l(reactions)));
              tmp_constraint_h = sum(dyn_Fmin_Object, mem_objvalue_FBA.l(dyn_Fmin_Object) -
                                    (MultiObjValue_max(dyn_Fmin_Object) - PH_MultiObjvalue_Optim(dyn_Fmin_Object))/
                                    (MultiObjValue_max(dyn_Fmin_Object) - MultiObjValue_min(dyn_Fmin_Object))) +
                                 sum(dyn_Fmax_Object, mem_objvalue_FBA.l(dyn_Fmax_Object) -
                                    (PH_MultiObjvalue_Optim(dyn_Fmax_Object) - MultiObjValue_min(dyn_Fmax_Object))/
                                    (MultiObjValue_max(dyn_Fmax_Object) - MultiObjValue_min(dyn_Fmax_Object)));                              
              constraint_g = sum(targetSet, max((target_limit_LB(targetSet) - (vf.l(targetSet) - vb.l(targetSet))), 0)) +
                             sum(targetSet, max(((vf.l(targetSet) - vb.l(targetSet)) - target_limit_UB(targetSet)), 0)) +
                             sum(dyn_ObjectSet, max((Lambda.l - mem_objvalue_FBA.l(dyn_ObjectSet)), 0));   
              constraint_FBA_PH = penalty * (sum(Dim_h, abs(constraint_h(Dim_h)) + abs(tmp_constraint_h)) + constraint_g););

*-------------------------------------------------------------------------------           

**** mutant UFD problem considering side effect ********************************
           if(FBA_Problem.modelstat <= 2,  
              pop_FMObj_inner_PH(NP, dyn_ObjectSet) = PH_MultiObjvalue_Optim(dyn_objectset);
              Mem_Obj_FBA_limit(ObjectSet) = 0;
              Mem_Obj_FBA_limit(dyn_Fmax_Object) = ((PH_MultiObjvalue_Optim(dyn_Fmax_Object) - MultiObjValue_min(dyn_Fmax_Object))/
                                                    (MultiObjValue_max(dyn_Fmax_Object) - MultiObjValue_min(dyn_Fmax_Object)));                                          
              Mem_Obj_FBA_limit(dyn_Fmin_Object) = ((MultiObjValue_max(dyn_Fmin_Object) - PH_MultiObjvalue_Optim(dyn_Fmin_Object))/
                                                    (MultiObjValue_max(dyn_Fmin_Object) - MultiObjValue_min(dyn_Fmin_Object)));
              Mem_Obj_FBA_limit(dyn_ObjectSet) = max(min( Mem_Obj_FBA_limit(dyn_ObjectSet), 1), 0);                                                 

** assign weighting coefficients for Rxn for computing ObjValue in UFD ****************************************************************************
              weight_coef_rxn(reactions) = Weight_factor_Rxn_OT;
              weight_coef_rxn(reactions) $ (HT_Reactions_HC(reactions)) = Weight_factor_Rxn_HC;
              weight_coef_rxn(reactions) $ (HT_Reactions_MC(reactions)) = Weight_factor_Rxn_MC;
              weight_coef_rxn(reactions) $ (HT_Reactions_NC(reactions)) = Weight_factor_Rxn_NC;
*****************************************************************************************************************************************************
*----- compute the lower and upper bounds for the target reactions ------------
              target_limit_LB(targetSet) = 0;
              target_limit_UB(targetSet) = 0;
              target_limit_LB(targetSet) = HT_target_level_LB(targetSet);
              target_limit_UB(targetSet) = HT_target_level_UB(targetSet);
              MultiObjValue_FBA.lo(ObjectSet) = MultiObjValue_min(objectSet);
              MultiObjValue_FBA.up(ObjectSet) = MultiObjValue_max(objectSet);
              mem_objvalue_FBA.lo(objectSet) = 0;
              mem_objvalue_FBA.up(objectSet) = 1;
*------------------------------------------------------------------------------
             
              PH_vf_UFD(reactions) = 0;
              PH_vb_UFD(reactions) = 0;
              if(flag_UFD_Obj = 1, solve UFD1_Problem using LP minimizing ObjValue_UFD;);
              if(flag_UFD_Obj = 2, solve UFD2_Problem using LP minimizing ObjValue_UFD;);
              if(flag_UFD_Obj = 3, solve UFD3_Problem using QCP minimizing ObjValue_UFD;);
              if(flag_UFD_Obj = 4, solve UFD4_Problem using QCP minimizing ObjValue_UFD;);
              nfeval_UFD_min = nfeval_UFD_min + 1;
              nfeval = nfeval + 1;);
              
*----- infeasible solution for UFD problem -------------------------------------
           if(UFD%No_UFD_Obj%_Problem.modelstat > 2,           
              pop_FMObj_inner_TR(NP, ObjectSet) $ (pop_modelstat_UFD(NP) > 2) = 0;
              pop_FMObj_inner_PH(NP, ObjectSet) = 0;
              pop_FMObj_outer_TR(NP, ObjectSet) $ (pop_modelstat_UFD(NP) > 2) = 0;
              pop_FMObj_outer_PH(NP, ObjectSet) = 0;  
              pop_mem_CV_TR(NP) $ (pop_modelstat_UFD(NP) > 2) = 0;
              pop_mem_Met_Exp_PHHT(NP) = 0;
              pop_mem_CV_PH(NP) = 0;
              pop_mem_MD_TP(NP) = 0;
              pop_mem_Met_PHHT(NP) = 0;
              pop_mem_rxn_PHHT(NP) = 0;
              pop_mem_Met_PHCA(NP) = 0;
              pop_mem_rxn_PHCA(NP) = 0;
              pop_mem_Met_TRCA(NP) = 0;
              pop_mem_rxn_TRCA(NP) = 0;              
              pop_mem_Met_TRHT(NP) $ (pop_modelstat_UFD(NP) > 2) = 0;
              pop_mem_rxn_TRHT(NP) $ (pop_modelstat_UFD(NP) > 2) = 0;
              constraint_h(Dim_h) = 0;
              constraint_h(Dim_h) = sum(reactions, S_Matrix(Dim_h, reactions) * (vf.l(reactions) - vb.l(reactions)));
              tmp_constraint_h = sum(dyn_Fmin_Object, mem_objvalue_FBA.l(dyn_Fmin_Object) -
                                    (MultiObjValue_max(dyn_Fmin_Object) - MultiObjValue_FBA.l(dyn_Fmin_Object))/
                                    (MultiObjValue_max(dyn_Fmin_Object) - MultiObjValue_min(dyn_Fmin_Object))) +
                                 sum(dyn_Fmax_Object, mem_objvalue_FBA.l(dyn_Fmax_Object) -
                                    (MultiObjValue_FBA.l(dyn_Fmax_Object) - MultiObjValue_min(dyn_Fmax_Object))/
                                    (MultiObjValue_max(dyn_Fmax_Object) - MultiObjValue_min(dyn_Fmax_Object)));                             
              constraint_g = sum(targetSet, max((target_limit_LB(targetSet) - (vf.l(targetSet) - vb.l(targetSet))), 0)) +
                             sum(targetSet, max(((vf.l(targetSet) - vb.l(targetSet)) - target_limit_UB(targetSet)), 0)) +
                             sum(dyn_ObjectSet, max((Lambda.l - mem_objvalue_FBA.l(dyn_ObjectSet)), 0));   
              constraint_UFD_PH = penalty * (sum(Dim_h, abs(constraint_h(Dim_h)) + abs(tmp_constraint_h)) + constraint_g););
*-------------------------------------------------------------------------------   

*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%              
           if(FBA_Problem.modelstat <= 2 and UFD%No_UFD_Obj%_Problem.modelstat <= 2,
* compute synthesis rate and degradation rate for each BioCompound at the mutant state
              PH_vf_UFD(reactions) = max(vf.l(reactions), 0);
              PH_vb_UFD(reactions) = max(vb.l(reactions), 0);
              PH_v_UFD(reactions) = PH_vf_UFD(reactions) - PH_vb_UFD(reactions);
 
**** compute membership grades of fuzzy max and min objectives for outer PH model *******************************************************************
              PH_MultiObjvalue_Optim(Objectset) = 0;
              PH_MultiObjvalue_Optim(dyn_obj_outer) = sum(dyn_reactions, coef_CellularObj_vf(dyn_obj_outer, dyn_reactions) * PH_vf_UFD(dyn_reactions)) +
                                                      sum(dyn_reactions, coef_CellularObj_vb(dyn_obj_outer, dyn_reactions) * PH_vb_UFD(dyn_reactions));  
              pop_FMObj_outer_PH(NP, dyn_obj_outer) = PH_MultiObjvalue_Optim(dyn_obj_outer);
           
**** compute membership grades of fuzzy max and min objectives for outer PH model *******************************************************************
              Mem_Obj_FBA_limit(ObjectSet) = 0;
              Mem_Obj_FBA_limit(dyn_Fmax_Obj_outer) = (PH_MultiObjvalue_Optim(dyn_Fmax_Obj_outer) - MultiObjValue_min(dyn_Fmax_Obj_outer))/
                                                      (MultiObjValue_max(dyn_Fmax_Obj_outer) - MultiObjValue_min(dyn_Fmax_Obj_outer));
              Mem_Obj_FBA_limit(dyn_Fmin_Obj_outer) = (MultiObjValue_max(dyn_Fmin_Obj_outer) - PH_MultiObjvalue_Optim(dyn_Fmin_Obj_outer))/
                                                      (MultiObjValue_max(dyn_Fmin_Obj_outer) - MultiObjValue_min(dyn_Fmin_Obj_outer));
              Mem_Obj_FBA_limit(dyn_obj_outer) = max(min( Mem_Obj_FBA_limit(dyn_obj_outer), 1), 0);                                                  
              mem_PriObj_Outer_PH = sum(dyn_priority_outer, Mem_Obj_FBA_limit(dyn_priority_outer))/No_priority_outer;
              pop_mem_CV_PH(NP) = 0.5 * (mem_PriObj_Outer_PH + smin(dyn_obj_outer, Mem_Obj_FBA_limit(dyn_obj_outer)));
*****************************************************************************************************************************************************

*=== compute synthesis rate for each species of treated PH model ====================================================================================
              PH_Species_SynRate(species) = 0;
              loop(dyn_species,
                   PH_Species_SynRate(dyn_species) = sum(dyn_reactions, S_Matrix(dyn_species, dyn_reactions) $
                                                        (S_Matrix(dyn_species, dyn_reactions) > 0) * PH_vf_UFD(dyn_reactions))
                                                   - sum(dyn_reactions, S_Matrix(dyn_Species, dyn_reactions) $
                                                        (S_Matrix(dyn_species, dyn_reactions) < 0) * PH_vb_UFD(dyn_reactions)););

***** compute synthesis rate for each biocompound of treated PH model ******************************************************************************
              PH_BioComp_SynRate(BioCompound) = 0;
              loop(dyn_BioComp,
                   PH_BioComp_SynRate(dyn_BioComp) = sum(dyn_Species $ (BioCompound_species(dyn_BioComp, dyn_Species)),
                                                         PH_Species_SynRate(dyn_Species)););       
*****************************************************************************************************************************************************

***** compute fuzzy dissimilarity of metabolite-flow and its membership grade for PHCA model ********************************************************
              L_mem_Met_tmp(biocompound) = 0;
              R_mem_Met_tmp(biocompound) = 0;
              mem_Met_tmp(biocompound) = 0;             
              L_mem_Met_tmp(BioComp_PHCA) $ (CA_BioComp_SynRate(BioComp_PHCA) > 0) =
                                            (CA_BioComp_SynRate(BioComp_PHCA) - PH_BioComp_SynRate(BioComp_PHCA))/
                                            (CA_BioComp_SynRate(BioComp_PHCA) - CA_MetFlowRate_LB(BioComp_PHCA));
              L_mem_Met_tmp(BioComp_PHCA) $ (CA_BioComp_SynRate(BioComp_PHCA) = 0) = 0;              
              R_mem_Met_tmp(BioComp_PHCA) = (PH_BioComp_SynRate(BioComp_PHCA) - CA_BioComp_SynRate(BioComp_PHCA))/
                                            (CA_MetFlowRate_UB(BioComp_PHCA) - CA_BioComp_SynRate(BioComp_PHCA));
              mem_Met_tmp(BioComp_PHCA) = min(max(L_mem_Met_tmp(BioComp_PHCA), R_mem_Met_tmp(BioComp_PHCA), 0), 1);            

              nonzero_Biocomp(biocompound) = no;             
              nonzero_Biocomp(biocompound) $ ((PH_BioComp_SynRate(biocompound) > 0 or
                                               CA_BioComp_SynRate(biocompound) > 0) and BioComp_PHCA(biocompound)) = yes;

              No_nonzero_Biocomp_PHCA = card(nonzero_Biocomp);                                               
              pop_mem_Met_PHCA(NP) = sum(BioCompound $ (nonzero_Biocomp(biocompound)), mem_Met_tmp(BioCompound))/No_nonzero_Biocomp_PHCA;

***** compute fuzzy dissimilarity of flux and its membership grade for PHCA model **********************************************************************
              L_mem_vf_tmp(reactions) = 0;
              R_mem_vf_tmp(reactions) = 0;
              L_mem_vb_tmp(reactions) = 0;
              R_mem_vb_tmp(reactions) = 0;
              L_mem_vf_tmp(rxn_vf_PHCA) $ (CA_vf_UFD(rxn_vf_PHCA) > 0) = (CA_vf_UFD(rxn_vf_PHCA) - PH_vf_UFD(rxn_vf_PHCA))/
                                                                        (CA_vf_UFD(rxn_vf_PHCA) - CA_vf_rxn_LB(rxn_vf_PHCA));
              L_mem_vf_tmp(rxn_vf_PHCA) $ (CA_vf_UFD(rxn_vf_PHCA) = 0) = 0;           
              R_mem_vf_tmp(rxn_vf_PHCA) = (PH_vf_UFD(rxn_vf_PHCA) - CA_vf_UFD(rxn_vf_PHCA))/
                                          (CA_vf_rxn_UB(rxn_vf_PHCA)- CA_vf_UFD(rxn_vf_PHCA));                                       
              L_mem_vb_tmp(rxn_vb_PHCA) $ (CA_vb_UFD(rxn_vb_PHCA) > 0) = (CA_vb_UFD(rxn_vb_PHCA) - PH_vb_UFD(rxn_vb_PHCA))/
                                                                         (CA_vb_UFD(rxn_vb_PHCA) - CA_vb_rxn_LB(rxn_vb_PHCA));
              L_mem_vb_tmp(rxn_vb_PHCA) $ (CA_vb_UFD(rxn_vb_PHCA) = 0) = 0;                                     
              R_mem_vb_tmp(rxn_vb_PHCA) = (PH_vb_UFD(rxn_vb_PHCA) - CA_vb_UFD(rxn_vb_PHCA))/
                                          (CA_vb_rxn_UB(rxn_vb_PHCA)- CA_vb_UFD(rxn_vb_PHCA)); 

**** intialization
              mem_vf_tmp(reactions) = 0;
              mem_vb_tmp(reactions) = 0;               
              mem_vf_tmp(rxn_vf_PHCA) = min(max(L_mem_vf_tmp(rxn_vf_PHCA), R_mem_vf_tmp(rxn_vf_PHCA), 0), 1);
              mem_vb_tmp(rxn_vb_PHCA) = min(max(L_mem_vb_tmp(rxn_vb_PHCA), R_mem_vb_tmp(rxn_vb_PHCA), 0), 1);

              nonzero_vf(reactions) = no;
              nonzero_vf(reactions) $ ((PH_vf_UFD(reactions) > 0 or
                                        CA_vf_UFD(reactions) > 0) and rxn_vf_PHCA(reactions)) = yes;
              nonzero_vb(reactions) = no;
              nonzero_vb(reactions) $ ((PH_vb_UFD(reactions) > 0 or
                                        CA_vb_UFD(reactions) > 0) and rxn_vb_PHCA(reactions)) = yes;

              nonzero_v(reactions) = no;                               
              nonzero_v(reactions) =  nonzero_vf(reactions) + nonzero_vb(reactions);
              No_nonzero_vf_PHCA = card(nonzero_vf);
              No_nonzero_vb_PHCA = card(nonzero_vb);              
              No_nonzero_v_PHCA = card(nonzero_v);
              pop_mem_rxn_PHCA(NP) = sum(reactions $ (nonzero_v(reactions)),             
                                         max(mem_vf_tmp(reactions),mem_vb_tmp(reactions)))/No_nonzero_v_PHCA;  
*****************************************************************************************************************************************************

*=== compute fuzzy similarity of metabolite-flow and its membership grade for PHHT model ============================================================
*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
***** compute fuzzy similarity  of Warburg and experiments for PHHT model 
              L_mem_Met_Exp(BioCompound) = 0;
              R_mem_Met_Exp(BioCompound) = 0;
              mem_Met_Exp(BioCompound) = 0;
              L_mem_Met_Exp(BioComp_ExpWarb) $ (HT_BioComp_SynRate(BioComp_ExpWarb) > 0) =
                                               (PH_BioComp_SynRate(BioComp_ExpWarb) - HT_MetFlowRate_LB(BioComp_ExpWarb))/
                                               (HT_BioComp_SynRate(BioComp_ExpWarb) - HT_MetFlowRate_LB(BioComp_ExpWarb));
              L_mem_Met_Exp(BioComp_ExpWarb) $ (HT_BioComp_SynRate(BioComp_ExpWarb) = 0) = 1;
              R_mem_Met_Exp(BioComp_ExpWarb) = (HT_MetFlowRate_UB(BioComp_ExpWarb) - PH_BioComp_SynRate(BioComp_ExpWarb))/
                                               (HT_MetFlowRate_UB(BioComp_ExpWarb) - HT_BioComp_SynRate(BioComp_ExpWarb));
              mem_Met_Exp(BioComp_ExpWarb) = max(min(L_mem_Met_Exp(BioComp_ExpWarb), R_mem_Met_Exp(BioComp_ExpWarb), 1), 0);
              pop_mem_Met_Exp_PHHT(NP) = sum(BioComp_ExpWarb, mem_Met_Exp(BioComp_ExpWarb))/card(BioComp_ExpWarb);

*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
***** compute fuzzy similarity of metabolite flow rates for biocompounds of PHHT model **********************************************************************
              L_mem_Met_tmp(biocompound) = 0;
              R_mem_Met_tmp(biocompound) = 0;
              mem_Met_tmp(biocompound) = 0;             
              L_mem_Met_tmp(BioComp_PHHT) $ (HT_BioComp_SynRate(BioComp_PHHT) > 0) =
                                            (PH_BioComp_SynRate(BioComp_PHHT) - HT_MetFlowRate_LB(BioComp_PHHT))/
                                            (HT_BioComp_SynRate(BioComp_PHHT) - HT_MetFlowRate_LB(BioComp_PHHT)); 
              L_mem_Met_tmp(BioComp_PHHT) $ (HT_BioComp_SynRate(BioComp_PHHT) = 0) = 1;

              R_mem_Met_tmp(BioComp_PHHT) = (HT_MetFlowRate_UB(BioComp_PHHT) - PH_BioComp_SynRate(BioComp_PHHT))/
                                            (HT_MetFlowRate_UB(BioComp_PHHT) - HT_BioComp_SynRate(BioComp_PHHT));  
              mem_Met_tmp(BioComp_PHHT) = max(min(L_mem_Met_tmp(BioComp_PHHT), R_mem_Met_tmp(BioComp_PHHT), 1), 0);             

              nonzero_Biocomp(biocompound) = no;             
              nonzero_Biocomp(biocompound) $ ((PH_BioComp_SynRate(biocompound) > 0 or
                                               HT_BioComp_SynRate(biocompound) > 0) and BioComp_PHHT(biocompound)) = yes;

              No_nonzero_Biocomp_PHHT = card(nonzero_Biocomp);                                               
              pop_mem_Met_PHHT(NP) = sum(BioCompound $ (nonzero_Biocomp(biocompound)), mem_Met_tmp(BioCompound))/No_nonzero_Biocomp_PHHT;

*****************************************************************************************************************************************************
***** compute fuzzy similarity of flux and its membership grade for PHHT model **********************************************************************
              L_mem_vf_tmp(reactions) = 0;
              R_mem_vf_tmp(reactions) = 0;
              L_mem_vb_tmp(reactions) = 0;
              R_mem_vb_tmp(reactions) = 0;
              L_mem_vf_tmp(rxn_vf_PHHT) $ (HT_vf_UFD(rxn_vf_PHHT) > 0) =
                                          (PH_vf_UFD(rxn_vf_PHHT) - HT_vf_rxn_LB(rxn_vf_PHHT))/
                                          (HT_vf_UFD(rxn_vf_PHHT) - HT_vf_rxn_LB(rxn_vf_PHHT));
              L_mem_vf_tmp(rxn_vf_PHHT) $ (HT_vf_UFD(rxn_vf_PHHT) = 0) = 1;
              R_mem_vf_tmp(rxn_vf_PHHT) = (HT_vf_rxn_UB(rxn_vf_PHHT) - PH_vf_UFD(rxn_vf_PHHT))/
                                          (HT_vf_rxn_UB(rxn_vf_PHHT)- HT_vf_UFD(rxn_vf_PHHT));                                          
              L_mem_vb_tmp(rxn_vb_PHHT) $ (HT_vb_UFD(rxn_vb_PHHT) > 0) =
                                          (PH_vb_UFD(rxn_vb_PHHT) - HT_vb_rxn_LB(rxn_vb_PHHT))/
                                          (HT_vb_UFD(rxn_vb_PHHT) - HT_vb_rxn_LB(rxn_vb_PHHT));
              L_mem_vb_tmp(rxn_vb_PHHT) $ (HT_vb_UFD(rxn_vb_PHHT) = 0) = 1;
              R_mem_vb_tmp(rxn_vb_PHHT) = (HT_vb_rxn_UB(rxn_vb_PHHT) - PH_vb_UFD(rxn_vb_PHHT))/
                                          (HT_vb_rxn_UB(rxn_vb_PHHT)- HT_vb_UFD(rxn_vb_PHHT));    

**** intialization
              mem_vf_tmp(reactions) = 0;
              mem_vb_tmp(reactions) = 0;              
              mem_vf_tmp(rxn_vf_PHHT) = max(min(L_mem_vf_tmp(rxn_vf_PHHT), R_mem_vf_tmp(rxn_vf_PHHT), 1), 0);
              mem_vb_tmp(rxn_vb_PHHT) = max(min(L_mem_vb_tmp(rxn_vb_PHHT), R_mem_vb_tmp(rxn_vb_PHHT), 1), 0);

              nonzero_vf(reactions) = no;
              nonzero_vf(reactions) $ ((PH_vf_UFD(reactions) > 0 or
                                        HT_vf_UFD(reactions) > 0) and rxn_vf_PHHT(reactions)) = yes;
              nonzero_vb(reactions) = no;
              nonzero_vb(reactions) $ ((PH_vb_UFD(reactions) > 0 or
                                        HT_vb_UFD(reactions) > 0) and rxn_vb_PHHT(reactions)) = yes;
              nonzero_v(reactions) = no;                               
              nonzero_v(reactions) =  nonzero_vf(reactions) + nonzero_vb(reactions);
              No_nonzero_vf_PHHT = card(nonzero_vf);
              No_nonzero_vb_PHHT = card(nonzero_vb);              
              No_nonzero_v_PHHT = card(nonzero_v);
              pop_mem_rxn_PHHT(NP) = sum(reactions $ (nonzero_v(reactions)),             
                                         min(mem_vf_tmp(reactions),mem_vb_tmp(reactions)))/No_nonzero_v_PHHT;           
*====================================================================================================================================================
              constraint_FBA_PH = 0;
              constraint_UFD_PH = 0;
           );
        );
     ); 
*====================================================================================================================================================    
*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

*----- fitness evaluation ------------------------------------------------------
* Metabolic deviation (dissimilarity) for PH model to CA template
pop_mem_MD_PHCA(NP) = ((pop_mem_rxn_PHCA(NP) + pop_mem_Met_PHCA(NP))/2 + min(pop_mem_rxn_PHCA(NP), pop_mem_Met_PHCA(NP)))/2;

* Metabolic deviation (similarity) for PH model to HT template
pop_mem_MD_PHHT(NP) = ((pop_mem_rxn_PHHT(NP) + pop_mem_Met_PHHT(NP))/2 + min(pop_mem_rxn_PHHT(NP), pop_mem_Met_PHHT(NP)))/2;

* Metabolic deviation (similarity) for TR model to HT template
pop_mem_MD_TRHT(NP) = ((pop_mem_rxn_TRHT(NP) + pop_mem_Met_TRHT(NP))/2 + min(pop_mem_rxn_TRHT(NP), pop_mem_Met_TRHT(NP)))/2;

* Metabolic deviation (dissimilarity) for TR model to CA template
pop_mem_MD_TRCA(NP) = ((pop_mem_rxn_TRCA(NP) + pop_mem_Met_TRCA(NP))/2 + min(pop_mem_rxn_TRCA(NP), pop_mem_Met_TRCA(NP)))/2;

* Metabolic deviation of fuzzy dissimilarity and similarity for PHCA, TRCA TRHT, and PHHT
pop_mem_MD_TP(NP) $ (index_sumz = 1 or index_sumz = 21 or index_sumz = 22) = ((pop_mem_MD_PHCA(NP) + pop_mem_MD_PHHT(NP))/2 +
                                                                               min(pop_mem_MD_PHCA(NP), pop_mem_MD_PHHT(NP)))/2;

pop_mem_MD_TP(NP) $ (index_sumz = 41 or index_sumz = 42) = ((pop_mem_MD_PHCA(NP) + pop_mem_MD_PHHT(NP) + pop_mem_MD_TRHT(NP) + pop_mem_MD_TRCA(NP))/4 +
                                                            min(pop_mem_MD_PHCA(NP), pop_mem_MD_PHHT(NP), pop_mem_MD_TRHT(NP), pop_mem_MD_TRCA(NP)))/2;

* Metabolic deviation of fuzzy similarity for TRHT, and PHHT
pop_mem_MD_TP(NP) $ (index_sumz = 23 or index_sumz = 24) = ((pop_mem_MD_TRHT(NP) + pop_mem_MD_PHHT(NP))/2 +
                                                             min(pop_mem_MD_TRHT(NP), pop_mem_MD_PHHT(NP)))/2;

pop_constraint(NP) = constraint_FBA_TR + constraint_UFD_TR + constraint_FBA_PH + constraint_UFD_PH;
*----- prioity fitness evaluation ----------------------------------------------
pop_fitness(NP) $ (index_sumZ = 1) = mem_PriObj_Outer_TR;
pop_fitness(NP) $ (index_sumZ = 21 or index_sumZ = 23 or index_sumz = 41) = (pop_mem_CV_TR(NP) +
                                                                             min(pop_mem_CV_TR(NP), pop_mem_CV_PH(NP), pop_mem_MD_TP(NP)))/2;
pop_fitness(NP) $ (index_sumZ = 22 or index_sumZ = 24 or index_sumz = 42) = ((pop_mem_CV_TR(NP) + pop_mem_CV_PH(NP))/2 +
                                                                             min(pop_mem_CV_TR(NP), pop_mem_CV_PH(NP), pop_mem_MD_TP(NP)))/2;
pop_fitness(NP) = pop_fitness(NP) - pop_constraint(NP);                                                                             
pop_fitness(NP) $ (flag_sumZ = 1) = pop_fitness(NP) + pop_mem_sumZ(NP););
*-------------------------------------------------------------------------------
*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

*---- find the best fitness and individual -------------------------------------
best_fitness = smax(NP, pop_fitness(NP));
loop(NP $ (pop_fitness(NP) >= best_fitness),
     best_FMObj_inner_TR(ObjectSet) = 0;
     best_FMObj_inner_PH(ObjectSet) = 0;
     best_FMObj_outer_TR(ObjectSet) = 0;
     best_FMObj_outer_PH(ObjectSet) = 0;
     bestmem_XB(Dim_BI) = 0;
     bestmem_XI(Dim_XIR) = 0;     
     best_FMObj_inner_TR(ObjectSet) = pop_FMObj_inner_TR(NP, objectSet);
     best_FMObj_inner_PH(ObjectSet) = pop_FMObj_inner_PH(NP, objectSet);
     best_FMObj_outer_TR(ObjectSet) = pop_FMObj_outer_TR(NP, objectSet);
     best_FMObj_outer_PH(ObjectSet) = pop_FMObj_outer_PH(NP, objectSet);       
     bestmem_XB(Dim_BI) = pop_XB(NP, Dim_BI);
     bestmem_XI(Dim_XIR) = pop_XI(NP, Dim_XIR);    
     best_Mem_sumZ  = pop_Mem_sumZ(NP);
     best_modelstat = pop_modelstat_UFD(NP);
     best_constraint = pop_constraint(NP);         
     best_fitness = pop_fitness(NP);
     best_mem_Met_Exp_PHHT = pop_mem_Met_Exp_PHHT(NP);         
     best_mem_CV_TR = pop_mem_CV_TR(NP);
     best_mem_CV_PH = pop_mem_CV_PH(NP);
     best_mem_MD_TP = pop_mem_MD_TP(NP);
     best_mem_MD_PHCA = pop_mem_MD_PHCA(NP);
     best_mem_MD_TRCA = pop_mem_MD_TRCA(NP);     
     best_mem_MD_PHHT = pop_mem_MD_PHHT(NP); 
     best_mem_MD_TRHT = pop_mem_MD_TRHT(NP);      
     best_mem_Met_PHHT = pop_mem_Met_PHHT(NP);
     best_mem_rxn_PHHT = pop_mem_rxn_PHHT(NP);
     best_mem_Met_PHCA = pop_mem_Met_PHCA(NP);
     best_mem_rxn_PHCA = pop_mem_rxn_PHCA(NP);
     best_mem_Met_TRCA = pop_mem_Met_TRCA(NP);
     best_mem_rxn_TRCA = pop_mem_rxn_TRCA(NP);     
     best_mem_Met_TRHT = pop_mem_Met_TRHT(NP);
     best_mem_rxn_TRHT = pop_mem_rxn_TRHT(NP);
 );

*----- perform nested HDE computation ------------------------------------------
bestmemit_XB(Dim_BI) = 0;
bestmemit_XI(Dim_XIR) = 0;
bm_XI(NP, Dim_XIR) = 0;
restnum = 0;
*----- intialization of mutation and crossover factors -------------------------
F_XNP $ (Method_5 >= 1) = (F_XLB + F_XUB)/2;
CR_XNP $ (Method_5 >= 1) = F_XNP;
F_X(NP) = F_XNP;
CR_X(NP) = CR_XNP;

*----- iterative solving nested HDE computation --------------------------------
loop(itermax $ ((best_fitness < VTR) or (best_constraint > VTR_G)),
     popold_XI(NP, Dim_XIR) = pop_XI(NP, Dim_XIR);
     popold_XB(NP, Dim_BI) = pop_XB(NP, Dim_BI);

*----- compute the random permutation for ind_HDE(NP) --------------------------
     rand_HDE(NP) = uniform(0, 1);
     ind_HDE(NP) = 1;
     loop(NP,
          number = 1;
          loop(NP_j $ ((rand_HDE(NP) > rand_HDE(NP_j)) and (card(NP_j) <= card(NP))), number = number + 1;);
          loop(NP_k $ ((rand_HDE(NP-1) = rand_HDE(NP_k)) and (card(NP_k) <= card(NP)-1)), number = number + 1;);
          ind_HDE(NP) = number;);

*----- compute the random permutation for a1_HDE(NP) ---------------------------
     rand_HDE(NP) = uniform(0, 1);
     a1_HDE(NP) = 1;
     loop(NP,
          number = 1;
          loop(NP_j $ ((rand_HDE(NP) > rand_HDE(NP_j)) and (card(NP_j) <= card(NP))), number = number + 1;);
          loop(NP_k $ ((rand_HDE(NP-1) = rand_HDE(NP_k)) and (card(NP_k) <= card(NP)-1)), number = number + 1;);
          a1_HDE(NP) = number;);

*----- compute the random permutation for rot_HDE(NP) --------------------------
     rand_HDE(NP) = uniform(0, 1);
     rot_HDE(NP) = 1;
     loop(NP,
          number = 1;
          loop(NP_j $ ((rand_HDE(NP) > rand_HDE(NP_j)) and (card(NP_j) <= card(NP))), number = number + 1;);
          loop(NP_k $ ((rand_HDE(NP-1) = rand_HDE(NP_k)) and (card(NP_k) <= card(NP)-1)), number = number + 1;);
          rot_HDE(NP) = number;);

*----- compute permuted orders for each individual -----------------------------
     rt_HDE(NP) = mod((rot_HDE(NP) + ind_HDE('NP1')), 5);
     a2_HDE(NP) = a1_HDE(NP + (rt_HDE(NP) + 1 - NP_order(NP)));
     rt_HDE(NP) = mod((rot_HDE(NP) + ind_HDE('NP2')), 5);
     a3_HDE(NP) = a2_HDE(NP + (rt_HDE(NP) + 1 - NP_order(NP)));
     rt_HDE(NP) = mod((rot_HDE(NP) + ind_HDE('NP3')), 5);
     a4_HDE(NP) = a3_HDE(NP + (rt_HDE(NP) + 1 - NP_order(NP)));
     rt_HDE(NP) = mod((rot_HDE(NP) + ind_HDE('NP4')), 5);
     a5_HDE(NP) = a4_HDE(NP + (rt_HDE(NP) + 1 - NP_order(NP)));

*----- assign the best individual ----------------------------------------------
     loop(NP, bm_XI(NP, Dim_XIR) = bestmem_XI(Dim_XIR););

*----- check random mutation strategy ------------------------------------------
     if(best_fitness > best_fitnessit,
        best_fitnessit = best_fitness;
     else
        strategy $ (Method_S = 1) = uniformint(1, 28););

*----- mutation operation ------------------------------------------------------
     F_X(NP) $ (Method_5 = 0) = F_X(NP);
     if(Method_5 = 1,
        F_XNP = uniform(F_XLB, F_XUB);
        F_X(NP) = F_XNP;);
     F_X(NP) $ (Method_5 = 2) = uniform(F_XLB, F_XUB);    

* self-adapting parameter
     if(Method_5 = 3, 
        F_XNP $ (uniform(0,1) < F_eps) = F_XLB + F_XUB * uniform(0, 1);
        F_X(NP) = F_XNP;);        
     F_X(NP) $ (Method_5 = 4 and uniform(0,1) < F_eps) = F_XLB + F_XUB * uniform(0, 1);
* best/1
     if (strategy = 1,
         ui_XI(NP, Dim_XIR) = bm_XI(NP, Dim_XIR) +
                              F_X(NP) * (popold_XI(NP + (a1_HDE(NP) - NP_order(NP)), Dim_XIR) -
                                     popold_XI(NP + (a2_HDE(NP) - NP_order(NP)), Dim_XIR)););
* rand/1
     if (strategy = 2,
         ui_XI(NP, Dim_XIR) = popold_XI(NP + (a3_HDE(NP) - NP_order(NP)), Dim_XIR) +
                              F_X(NP) * (popold_XI(NP + (a1_HDE(NP) - NP_order(NP)), Dim_XIR) -
                                     popold_XI(NP + (a2_HDE(NP) - NP_order(NP)), Dim_XIR)););
* current-to-best/1                                     
     if (strategy = 3,
         ui_XI(NP, Dim_XIR) = popold_XI(NP, Dim_XIR) + F_X(NP) * (bm_XI(NP, Dim_XIR) - popold_XI(NP, Dim_XIR) +
                              popold_XI(NP + (a1_HDE(NP) - NP_order(NP)), Dim_XIR) -
                              popold_XI(NP + (a2_HDE(NP) - NP_order(NP)), Dim_XIR)););
* best/2                              
     if (strategy = 4,
         ui_XI(NP, Dim_XIR) = bm_XI(NP, Dim_XIR) +
                              F_X(NP) * (popold_XI(NP + (a1_HDE(NP) - NP_order(NP)), Dim_XIR) -
                                     popold_XI(NP + (a2_HDE(NP) - NP_order(NP)), Dim_XIR) +
                                     popold_XI(NP + (a3_HDE(NP) - NP_order(NP)), Dim_XIR) -
                                     popold_XI(NP + (a4_HDE(NP) - NP_order(NP)), Dim_XIR)););
* rand/2                                     
     if (strategy = 5,
         ui_XI(NP, Dim_XIR) = popold_XI(NP + (a5_HDE(NP) - NP_order(NP)), Dim_XIR) +
                              F_X(NP) * (popold_XI(NP + (a1_HDE(NP) - NP_order(NP)), Dim_XIR) -
                                     popold_XI(NP + (a2_HDE(NP) - NP_order(NP)), Dim_XIR) +
                                     popold_XI(NP + (a3_HDE(NP) - NP_order(NP)), Dim_XIR) -
                                     popold_XI(NP + (a4_HDE(NP) - NP_order(NP)), Dim_XIR)););
* current-to-best/w1                                    
     if (strategy = 6,
         F_CR(NP) = uniform(0, 1);
         ui_XI(NP, Dim_XIR) = popold_XI(NP, Dim_XIR) +  F_CR(NP) * (bm_XI(NP, Dim_XIR) - popold_XI(NP, Dim_XIR)) +
                              F_X(NP) * (popold_XI(NP + (a1_HDE(NP) - NP_order(NP)), Dim_XIR) -
                                     popold_XI(NP + (a2_HDE(NP) - NP_order(NP)), Dim_XIR)););
* current-to-best/w2
     if (strategy = 7,
         F_CR(NP) = uniform(0, 1);
         ui_XI(NP, Dim_XIR) = popold_XI(NP, Dim_XIR) +  F_CR(NP) * (bm_XI(NP, Dim_XIR) - popold_XI(NP, Dim_XIR)) +
                              F_X(NP) * (popold_XI(NP + (a1_HDE(NP) - NP_order(NP)), Dim_XIR) -
                                     popold_XI(NP + (a2_HDE(NP) - NP_order(NP)), Dim_XIR) +
                                     popold_XI(NP + (a3_HDE(NP) - NP_order(NP)), Dim_XIR) -
                                     popold_XI(NP + (a4_HDE(NP) - NP_order(NP)), Dim_XIR)););
* s1 + s2
     if (strategy = 8,
         ui_XI(NP, Dim_XIR) $ (ord(NP) <= card(NP)/2) = bm_XI(NP, Dim_XIR) +
                                                              F_X(NP) * (popold_XI(NP + (a1_HDE(NP) - NP_order(NP)), Dim_XIR) -
                                                              popold_XI(NP + (a2_HDE(NP) - NP_order(NP)), Dim_XIR));
         ui_XI(NP, Dim_XIR) $ (ord(NP) >= (1 + card(NP)/2)) = popold_XI(NP + (a3_HDE(NP) - NP_order(NP)), Dim_XIR) +
                                                              F_X(NP) * (popold_XI(NP + (a1_HDE(NP) - NP_order(NP)), Dim_XIR) -
                                                                         popold_XI(NP + (a2_HDE(NP) - NP_order(NP)), Dim_XIR)););
* s1 + s3
     if (strategy = 9,
         ui_XI(NP, Dim_XIR) $ (ord(NP) <= card(NP)/2) = bm_XI(NP, Dim_XIR) +
                                                        F_X(NP) * (popold_XI(NP + (a1_HDE(NP) - NP_order(NP)), Dim_XIR) -
                                                        popold_XI(NP + (a2_HDE(NP) - NP_order(NP)), Dim_XIR));
         ui_XI(NP, Dim_XIR) $ (ord(NP) >= (1 + card(NP)/2)) = popold_XI(NP, Dim_XIR) + F_X(NP) * (bm_XI(NP, Dim_XIR) +
                                                              popold_XI(NP + (a1_HDE(NP) - NP_order(NP)), Dim_XIR) -
                                                              popold_XI(NP + (a2_HDE(NP) - NP_order(NP)), Dim_XIR)););
* s2 + s3
     if (strategy = 10,
         ui_XI(NP, Dim_XIR) $ (ord(NP) <= card(NP)/2) = popold_XI(NP + (a3_HDE(NP) - NP_order(NP)), Dim_XIR) +
                                                        F_X(NP) * (popold_XI(NP + (a1_HDE(NP) - NP_order(NP)), Dim_XIR) -
                                                        popold_XI(NP + (a2_HDE(NP) - NP_order(NP)), Dim_XIR));
         ui_XI(NP, Dim_XIR) $ (ord(NP) >= (1 + card(NP)/2)) = popold_XI(NP, Dim_XIR) + F_X(NP) * (bm_XI(NP, Dim_XIR) +
                                                              popold_XI(NP + (a1_HDE(NP) - NP_order(NP)), Dim_XIR) -
                                                              popold_XI(NP + (a2_HDE(NP) - NP_order(NP)), Dim_XIR)););
* s2 + s4
     if (strategy = 11,
         ui_XI(NP, Dim_XIR) $ (ord(NP) <= card(NP)/2) = popold_XI(NP + (a3_HDE(NP) - NP_order(NP)), Dim_XIR) +
                                                        F_X(NP) * (popold_XI(NP + (a1_HDE(NP) - NP_order(NP)), Dim_XIR) -
                                                        popold_XI(NP + (a2_HDE(NP) - NP_order(NP)), Dim_XIR));
         ui_XI(NP, Dim_XIR) $ (ord(NP) >= (1 + card(NP)/2)) = bm_XI(NP, Dim_XIR) +
                                                              F_X(NP) * (popold_XI(NP + (a1_HDE(NP) - NP_order(NP)), Dim_XIR) -
                                                                         popold_XI(NP + (a2_HDE(NP) - NP_order(NP)), Dim_XIR) +
                                                                         popold_XI(NP + (a3_HDE(NP) - NP_order(NP)), Dim_XIR) -
                                                                         popold_XI(NP + (a4_HDE(NP) - NP_order(NP)), Dim_XIR)););
* s2 + s5
     if (strategy = 12,
         ui_XI(NP, Dim_XIR) $ (ord(NP) <= card(NP)/2) = popold_XI(NP + (a3_HDE(NP) - NP_order(NP)), Dim_XIR) +
                                                        F_X(NP) * (popold_XI(NP + (a1_HDE(NP) - NP_order(NP)), Dim_XIR) -
                                                        popold_XI(NP + (a2_HDE(NP) - NP_order(NP)), Dim_XIR));
         ui_XI(NP, Dim_XIR) $ (ord(NP) >= (1 + card(NP)/2)) = popold_XI(NP + (a5_HDE(NP) - NP_order(NP)), Dim_XIR) +
                                                              F_X(NP) * (popold_XI(NP + (a1_HDE(NP) - NP_order(NP)), Dim_XIR) -
                                                                         popold_XI(NP + (a2_HDE(NP) - NP_order(NP)), Dim_XIR) +
                                                                         popold_XI(NP + (a3_HDE(NP) - NP_order(NP)), Dim_XIR) -
                                                                         popold_XI(NP + (a4_HDE(NP) - NP_order(NP)), Dim_XIR)););
* s2 + s6
     if (strategy = 13,
         ui_XI(NP, Dim_XIR) $ (ord(NP) <= card(NP)/2) = popold_XI(NP + (a3_HDE(NP) - NP_order(NP)), Dim_XIR) +
                                                        F_X(NP) * (popold_XI(NP + (a1_HDE(NP) - NP_order(NP)), Dim_XIR) -
                                                        popold_XI(NP + (a2_HDE(NP) - NP_order(NP)), Dim_XIR));
         F_CR(NP) = uniform(0, 1);                                                        
         ui_XI(NP, Dim_XIR) $ (ord(NP) >= (1 + card(NP)/2)) = popold_XI(NP, Dim_XIR) +  F_CR(NP) *
                                                             (bm_XI(NP, Dim_XIR) - popold_XI(NP, Dim_XIR)) +
                                                              F_X(NP) * (popold_XI(NP + (a1_HDE(NP) - NP_order(NP)), Dim_XIR) -
                                                                         popold_XI(NP + (a2_HDE(NP) - NP_order(NP)), Dim_XIR)););
* s2 + s7
     if (strategy = 14,
         ui_XI(NP, Dim_XIR) $ (ord(NP) <= card(NP)/2) = popold_XI(NP + (a3_HDE(NP) - NP_order(NP)), Dim_XIR) +
                                                        F_X(NP) * (popold_XI(NP + (a1_HDE(NP) - NP_order(NP)), Dim_XIR) -
                                                        popold_XI(NP + (a2_HDE(NP) - NP_order(NP)), Dim_XIR));
         F_CR(NP) = uniform(0, 1);                                               
         ui_XI(NP, Dim_XIR) $ (ord(NP) >= (1 + card(NP)/2)) = popold_XI(NP, Dim_XIR) +  F_CR(NP) *
                                                             (bm_XI(NP, Dim_XIR) - popold_XI(NP, Dim_XIR)) +
                                                              F_X(NP) * (popold_XI(NP + (a1_HDE(NP) - NP_order(NP)), Dim_XIR) -
                                                                         popold_XI(NP + (a2_HDE(NP) - NP_order(NP)), Dim_XIR) +
                                                                         popold_XI(NP + (a3_HDE(NP) - NP_order(NP)), Dim_XIR) -
                                                                         popold_XI(NP + (a4_HDE(NP) - NP_order(NP)), Dim_XIR)););
* s5 + s7
     if (strategy = 15,
         ui_XI(NP, Dim_XIR) $ (ord(NP) <= card(NP)/2) = popold_XI(NP + (a5_HDE(NP) - NP_order(NP)), Dim_XIR) +
                                                        F_X(NP) * (popold_XI(NP + (a1_HDE(NP) - NP_order(NP)), Dim_XIR) -
                                                                   popold_XI(NP + (a2_HDE(NP) - NP_order(NP)), Dim_XIR) +
                                                                   popold_XI(NP + (a3_HDE(NP) - NP_order(NP)), Dim_XIR) -
                                                                   popold_XI(NP + (a4_HDE(NP) - NP_order(NP)), Dim_XIR));
         F_CR(NP) = uniform(0, 1);                                                                   
         ui_XI(NP, Dim_XIR) $ (ord(NP) >= (1 + card(NP)/2)) = popold_XI(NP, Dim_XIR) +  F_CR(NP) *
                                                             (bm_XI(NP, Dim_XIR) - popold_XI(NP, Dim_XIR)) +
                                                              F_X(NP) * (popold_XI(NP + (a1_HDE(NP) - NP_order(NP)), Dim_XIR) -
                                                                         popold_XI(NP + (a2_HDE(NP) - NP_order(NP)), Dim_XIR) +
                                                                         popold_XI(NP + (a3_HDE(NP) - NP_order(NP)), Dim_XIR) -
                                                                         popold_XI(NP + (a4_HDE(NP) - NP_order(NP)), Dim_XIR)););
* s1 + s5
     if (strategy = 16,
         ui_XI(NP, Dim_XIR) $ (ord(NP) <= card(NP)/2) = bm_XI(NP, Dim_XIR) +
                                                        F_X(NP) * (popold_XI(NP + (a1_HDE(NP) - NP_order(NP)), Dim_XIR) -
                                                                   popold_XI(NP + (a2_HDE(NP) - NP_order(NP)), Dim_XIR));
         ui_XI(NP, Dim_XIR) $ (ord(NP) >= (1 + card(NP)/2)) = popold_XI(NP + (a5_HDE(NP) - NP_order(NP)), Dim_XIR) +
                                                              F_X(NP) * (popold_XI(NP + (a1_HDE(NP) - NP_order(NP)), Dim_XIR) -
                                                                         popold_XI(NP + (a2_HDE(NP) - NP_order(NP)), Dim_XIR) +
                                                                         popold_XI(NP + (a3_HDE(NP) - NP_order(NP)), Dim_XIR) -
                                                                         popold_XI(NP + (a4_HDE(NP) - NP_order(NP)), Dim_XIR)););
* s3 + s5
     if (strategy = 17,
         ui_XI(NP, Dim_XIR) $ (ord(NP) <= card(NP)/2) = popold_XI(NP, Dim_XIR) +
                                                        F_X(NP) * (bm_XI(NP, Dim_XIR) - popold_XI(NP, Dim_XIR) +
                                                                   popold_XI(NP + (a1_HDE(NP) - NP_order(NP)), Dim_XIR) -
                                                                   popold_XI(NP + (a2_HDE(NP) - NP_order(NP)), Dim_XIR));
         ui_XI(NP, Dim_XIR) $ (ord(NP) >= (1 + card(NP)/2)) = popold_XI(NP + (a5_HDE(NP) - NP_order(NP)), Dim_XIR) +
                                                              F_X(NP) * (popold_XI(NP + (a1_HDE(NP) - NP_order(NP)), Dim_XIR) -
                                                                         popold_XI(NP + (a2_HDE(NP) - NP_order(NP)), Dim_XIR) +
                                                                         popold_XI(NP + (a3_HDE(NP) - NP_order(NP)), Dim_XIR) -
                                                                         popold_XI(NP + (a4_HDE(NP) - NP_order(NP)), Dim_XIR)););
* s4 + s5
     if (strategy = 18,
         ui_XI(NP, Dim_XIR) $ (ord(NP) <= card(NP)/2) = bm_XI(NP, Dim_XIR) +
                                                        F_X(NP) * (popold_XI(NP + (a1_HDE(NP) - NP_order(NP)), Dim_XIR) -
                                                                   popold_XI(NP + (a2_HDE(NP) - NP_order(NP)), Dim_XIR) +
                                                                   popold_XI(NP + (a3_HDE(NP) - NP_order(NP)), Dim_XIR) -
                                                                   popold_XI(NP + (a4_HDE(NP) - NP_order(NP)), Dim_XIR));
         ui_XI(NP, Dim_XIR) $ (ord(NP) >= (1 + card(NP)/2)) = popold_XI(NP + (a5_HDE(NP) - NP_order(NP)), Dim_XIR) +
                                                              F_X(NP) * (popold_XI(NP + (a1_HDE(NP) - NP_order(NP)), Dim_XIR) -
                                                                         popold_XI(NP + (a2_HDE(NP) - NP_order(NP)), Dim_XIR) +
                                                                         popold_XI(NP + (a3_HDE(NP) - NP_order(NP)), Dim_XIR) -
                                                                         popold_XI(NP + (a4_HDE(NP) - NP_order(NP)), Dim_XIR)););
* s5 + s6
     if (strategy = 19,
         ui_XI(NP, Dim_XIR) $ (ord(NP) <= card(NP)/2) = popold_XI(NP + (a5_HDE(NP) - NP_order(NP)), Dim_XIR) +
                                                        F_X(NP) * (popold_XI(NP + (a1_HDE(NP) - NP_order(NP)), Dim_XIR) -
                                                                   popold_XI(NP + (a2_HDE(NP) - NP_order(NP)), Dim_XIR) +
                                                                   popold_XI(NP + (a3_HDE(NP) - NP_order(NP)), Dim_XIR) -
                                                                   popold_XI(NP + (a4_HDE(NP) - NP_order(NP)), Dim_XIR));
         F_CR(NP) = uniform(0, 1);                                                          
         ui_XI(NP, Dim_XIR) $ (ord(NP) >= (1 + card(NP)/2)) = popold_XI(NP, Dim_XIR) +
                                                              F_CR(NP) * (bm_XI(NP, Dim_XIR) - popold_XI(NP, Dim_XIR)) +
                                                              F_X(NP) * (popold_XI(NP + (a1_HDE(NP) - NP_order(NP)), Dim_XIR) -
                                                                         popold_XI(NP + (a2_HDE(NP) - NP_order(NP)), Dim_XIR)););
* s1 + s4
     if (strategy = 20,
         ui_XI(NP, Dim_XIR) $ (ord(NP) <= card(NP)/2) = bm_XI(NP, Dim_XIR) +
                                                     F_X(NP) * (popold_XI(NP + (a1_HDE(NP) - NP_order(NP)), Dim_XIR) -
                                                                popold_XI(NP + (a2_HDE(NP) - NP_order(NP)), Dim_XIR));
         ui_XI(NP, Dim_XIR) $ (ord(NP) >= (1 + card(NP)/2)) = bm_XI(NP, Dim_XIR) +
                                                           F_X(NP) * (popold_XI(NP + (a1_HDE(NP) - NP_order(NP)), Dim_XIR) -
                                                                      popold_XI(NP + (a2_HDE(NP) - NP_order(NP)), Dim_XIR) +
                                                                      popold_XI(NP + (a3_HDE(NP) - NP_order(NP)), Dim_XIR) -
                                                                      popold_XI(NP + (a4_HDE(NP) - NP_order(NP)), Dim_XIR)););
* s1 + s6
     if (strategy = 21,
         ui_XI(NP, Dim_XIR) $ (ord(NP) <= card(NP)/2) = bm_XI(NP, Dim_XIR) +
                                                     F_X(NP) * (popold_XI(NP + (a1_HDE(NP) - NP_order(NP)), Dim_XIR) -
                                                                popold_XI(NP + (a2_HDE(NP) - NP_order(NP)), Dim_XIR));
         F_CR(NP) = uniform(0, 1);                                                                
         ui_XI(NP, Dim_XIR) $ (ord(NP) >= (1 + card(NP)/2)) = popold_XI(NP, Dim_XIR) +
                                                           F_CR(NP) * (bm_XI(NP, Dim_XIR) - popold_XI(NP, Dim_XIR)) +
                                                                       F_X(NP) * (popold_XI(NP + (a1_HDE(NP) - NP_order(NP)), Dim_XIR) -
                                                                       popold_XI(NP + (a2_HDE(NP) - NP_order(NP)), Dim_XIR)););
* s1 + s7
     if (strategy = 22,
         ui_XI(NP, Dim_XIR) $ (ord(NP) <= card(NP)/2) = bm_XI(NP, Dim_XIR) +
                                                     F_X(NP) * (popold_XI(NP + (a1_HDE(NP) - NP_order(NP)), Dim_XIR) -
                                                                popold_XI(NP + (a2_HDE(NP) - NP_order(NP)), Dim_XIR));
         F_CR(NP) = uniform(0, 1);                                                                            
         ui_XI(NP, Dim_XIR) $ (ord(NP) >= (1 + card(NP)/2)) = popold_XI(NP, Dim_XIR) +
                                                           F_CR(NP) * (bm_XI(NP, Dim_XIR) - popold_XI(NP, Dim_XIR)) +
                                                           F_X(NP) * (popold_XI(NP + (a1_HDE(NP) - NP_order(NP)), Dim_XIR) -
                                                                      popold_XI(NP + (a2_HDE(NP) - NP_order(NP)), Dim_XIR) +
                                                                      popold_XI(NP + (a3_HDE(NP) - NP_order(NP)), Dim_XIR) -
                                                                      popold_XI(NP + (a4_HDE(NP) - NP_order(NP)), Dim_XIR)););
* s3 + s4
     if (strategy = 23,
         ui_XI(NP, Dim_XIR) $ (ord(NP) <= card(NP)/2) = popold_XI(NP, Dim_XIR) +
                                                     F_X(NP) * (bm_XI(NP, Dim_XIR) - popold_XI(NP, Dim_XIR) +
                                                                popold_XI(NP + (a1_HDE(NP) - NP_order(NP)), Dim_XIR) -
                                                                popold_XI(NP + (a2_HDE(NP) - NP_order(NP)), Dim_XIR));
         ui_XI(NP, Dim_XIR) $ (ord(NP) >= (1 + card(NP)/2)) = bm_XI(NP, Dim_XIR) +
                                                           F_X(NP) * (popold_XI(NP + (a1_HDE(NP) - NP_order(NP)), Dim_XIR) -
                                                                      popold_XI(NP + (a2_HDE(NP) - NP_order(NP)), Dim_XIR) +
                                                                      popold_XI(NP + (a3_HDE(NP) - NP_order(NP)), Dim_XIR) -
                                                                      popold_XI(NP + (a4_HDE(NP) - NP_order(NP)), Dim_XIR)););
* s3 + s6
     if (strategy = 24,
         ui_XI(NP, Dim_XIR) $ (ord(NP) <= card(NP)/2) = popold_XI(NP, Dim_XIR) +
                                                     F_X(NP) * (bm_XI(NP, Dim_XIR) - popold_XI(NP, Dim_XIR) +
                                                                popold_XI(NP + (a1_HDE(NP) - NP_order(NP)), Dim_XIR) -
                                                                popold_XI(NP + (a2_HDE(NP) - NP_order(NP)), Dim_XIR));
         F_CR(NP) = uniform(0, 1);                                                                
         ui_XI(NP, Dim_XIR) $ (ord(NP) >= (1 + card(NP)/2)) = popold_XI(NP, Dim_XIR) +
                                                           F_CR(NP) * (bm_XI(NP, Dim_XIR) - popold_XI(NP, Dim_XIR)) +
                                                                       F_X(NP) * (popold_XI(NP + (a1_HDE(NP) - NP_order(NP)), Dim_XIR) -
                                                                       popold_XI(NP + (a2_HDE(NP) - NP_order(NP)), Dim_XIR)););
* s3 + s7
     if (strategy = 25,
         ui_XI(NP, Dim_XIR) $ (ord(NP) <= card(NP)/2) = popold_XI(NP, Dim_XIR) +
                                                     F_X(NP) * (bm_XI(NP, Dim_XIR) - popold_XI(NP, Dim_XIR) +
                                                                popold_XI(NP + (a1_HDE(NP) - NP_order(NP)), Dim_XIR) -
                                                                popold_XI(NP + (a2_HDE(NP) - NP_order(NP)), Dim_XIR));
         F_CR(NP) = uniform(0, 1);                                                                
         ui_XI(NP, Dim_XIR) $ (ord(NP) >= (1 + card(NP)/2)) = popold_XI(NP, Dim_XIR) +
                                                           F_CR(NP) * (bm_XI(NP, Dim_XIR) - popold_XI(NP, Dim_XIR)) +
                                                           F_X(NP) * (popold_XI(NP + (a1_HDE(NP) - NP_order(NP)), Dim_XIR) -
                                                                      popold_XI(NP + (a2_HDE(NP) - NP_order(NP)), Dim_XIR) +
                                                                      popold_XI(NP + (a3_HDE(NP) - NP_order(NP)), Dim_XIR) -
                                                                      popold_XI(NP + (a4_HDE(NP) - NP_order(NP)), Dim_XIR)););
* s4 + s6
     if (strategy = 26,
         ui_XI(NP, Dim_XIR) $ (ord(NP) <= card(NP)/2) = bm_XI(NP, Dim_XIR) +
                                                     F_X(NP) * (popold_XI(NP + (a1_HDE(NP) - NP_order(NP)), Dim_XIR) -
                                                                popold_XI(NP + (a2_HDE(NP) - NP_order(NP)), Dim_XIR) +
                                                                popold_XI(NP + (a3_HDE(NP) - NP_order(NP)), Dim_XIR) -
                                                                popold_XI(NP + (a4_HDE(NP) - NP_order(NP)), Dim_XIR));
         F_CR(NP) = uniform(0, 1);                                                                
         ui_XI(NP, Dim_XIR) $ (ord(NP) >= (1 + card(NP)/2)) = popold_XI(NP, Dim_XIR) +
                                                           F_CR(NP) * (bm_XI(NP, Dim_XIR) - popold_XI(NP, Dim_XIR)) +
                                                                       F_X(NP) * (popold_XI(NP + (a1_HDE(NP) - NP_order(NP)), Dim_XIR) -
                                                                       popold_XI(NP + (a2_HDE(NP) - NP_order(NP)), Dim_XIR)););
* s4 + s7
     if (strategy = 27,
         ui_XI(NP, Dim_XIR) $ (ord(NP) <= card(NP)/2) = bm_XI(NP, Dim_XIR) +
                                                     F_X(NP) * (popold_XI(NP + (a1_HDE(NP) - NP_order(NP)), Dim_XIR) -
                                                                popold_XI(NP + (a2_HDE(NP) - NP_order(NP)), Dim_XIR) +
                                                                popold_XI(NP + (a3_HDE(NP) - NP_order(NP)), Dim_XIR) -
                                                                popold_XI(NP + (a4_HDE(NP) - NP_order(NP)), Dim_XIR));
         F_CR(NP) = uniform(0, 1);                                                                
         ui_XI(NP, Dim_XIR) $ (ord(NP) >= (1 + card(NP)/2)) = popold_XI(NP, Dim_XIR) +
                                                           F_CR(NP) * (bm_XI(NP, Dim_XIR) - popold_XI(NP, Dim_XIR)) +
                                                           F_X(NP) * (popold_XI(NP + (a1_HDE(NP) - NP_order(NP)), Dim_XIR) -
                                                                      popold_XI(NP + (a2_HDE(NP) - NP_order(NP)), Dim_XIR) +
                                                                      popold_XI(NP + (a3_HDE(NP) - NP_order(NP)), Dim_XIR) -
                                                                      popold_XI(NP + (a4_HDE(NP) - NP_order(NP)), Dim_XIR)););
* s6 + s7
     if (strategy = 28,
         F_CR(NP) = uniform(0, 1);
         ui_XI(NP, Dim_XIR) $ (ord(NP) <= card(NP)/2) = popold_XI(NP, Dim_XIR) +
                                                     F_CR(NP) * (bm_XI(NP, Dim_XIR) - popold_XI(NP, Dim_XIR)) +
                                                     F_X(NP) * (popold_XI(NP + (a1_HDE(NP) - NP_order(NP)), Dim_XIR) -
                                                                popold_XI(NP + (a2_HDE(NP) - NP_order(NP)), Dim_XIR));
         ui_XI(NP, Dim_XIR) $ (ord(NP) >= (1 + card(NP)/2)) = popold_XI(NP, Dim_XIR) +
                                                           F_CR(NP) * (bm_XI(NP, Dim_XIR) - popold_XI(NP, Dim_XIR)) +
                                                           F_X(NP) * (popold_XI(NP + (a1_HDE(NP) - NP_order(NP)), Dim_XIR) -
                                                                      popold_XI(NP + (a2_HDE(NP) - NP_order(NP)), Dim_XIR) +
                                                                      popold_XI(NP + (a3_HDE(NP) - NP_order(NP)), Dim_XIR) -
                                                                      popold_XI(NP + (a4_HDE(NP) - NP_order(NP)), Dim_XIR));); 

*---- round the real variables to integer variables ----------------------------
    ui_XI(NP, Dim_XI) = round(ui_XI(NP, Dim_XI));

*----- crossover operation -----------------------------------------------------
* self-adapting parameter
*    if(Method_5 = 1 or Method_5 = 3,
*       CR_XNP $ (uniform(0, 1) < CR_eps) = uniform(0, 1);
*       CR_X(NP) = CR_XNP;);
*    if(Method_5 = 2 or Method_5 = 4,
    CR_X(NP) $ (Method_5 = 0) = CR_XNP;
    if(Method_5 >= 1,    
       CR_X(NP) $ (uniform(0, 1) < CR_eps) = uniform(0, 1););  
    rand_C2(NP, Dim_XIR) = uniform(0, 1);
    ui_XI(NP, Dim_XIR) $ (rand_C2(NP, Dim_XIR) >= CR_X(NP)) = popold_XI(NP, Dim_XIR);

*----- restriction operation ---------------------------------------------------
    ui_XI(NP, Dim_XI) $ ((ui_XI(NP, Dim_XI) < XIR_min(Dim_XI)) or (ui_XI(NP, Dim_XI) > XIR_max(Dim_XI)))
                                                          = uniformInt(XIR_min(Dim_XI), XIR_max(Dim_XI));
    ui_XI(NP, Dim_XR) $ (ui_XI(NP, Dim_XR) < XIR_min(Dim_XR)) = XIR_min(Dim_XR);
    ui_XI(NP, Dim_XR) $ (ui_XI(NP, Dim_XR) > XIR_max(Dim_XR)) = XIR_max(Dim_XR);

*----- decode Candidate_Enz orders to select the regulated reactions -----------
$offorder
    ui_XB(NP, Dim_BI) = 0;
    loop(Dim_XI1, ui_XB(NP, Dim_BI1) $ (ord(Dim_BI1) = ui_XI(NP, Dim_XI1)) = uniformInt(%No_UPDownKO_min_g1%, %No_UPDownKO_max_g1%););
    loop(Dim_XI2, ui_XB(NP, Dim_BI2) $ (ord(Dim_BI2) = ui_XI(NP, Dim_XI2)) = uniformInt(%No_UPDownKO_min_g2%, %No_UPDownKO_max_g2%););
$onorder
*-------------------------------------------------------------------------------

* assign regulation strength parameter for each individual
    TR_Reg_Factor(NP) = ui_XI(NP, "RSP1");
*-------------------------------------------------------------------------------

    loop(NP,
*%%%%% the user can modify the following procedures %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
***** assign reactions and species in FMO CA models as dynamic sets ****************   
         dyn_reactions(reactions) = no;
         dyn_species(species) = no;
         dyn_BioComp(biocompound) = no;
         dyn_irrev_rxn(reactions) = no;
         dyn_rev_rxn(reactions) = no;
         dyn_exchange_rxn(reactions) = no;
         dyn_objectSet(objectSet) = no;
         dyn_Fmax_Object(ObjectSet) = no;
         dyn_Fmin_Object(ObjectSet) = no;
         dyn_priority_obj(ObjectSet) = no;
         dyn_obj_outer(objectSet) = no;
         dyn_Fmax_Obj_outer(ObjectSet) = no;
         dyn_Fmin_Obj_outer(ObjectSet) = no;
         dyn_priority_outer(ObjectSet) = no;    
**** objectives used in inner optimization problem
         dyn_reactions(reactions) $ (not reactions_NCA(reactions)) = yes;
         dyn_species(species) $ (not species_NCA(species)) = yes;
         dyn_BioComp(biocompound) $ (not biocompound_NCA(biocompound)) = yes;
         dyn_irrev_rxn(reactions) $ (not reactions_NCA(reactions) and irrev_rxn(reactions)) = yes;
         dyn_rev_rxn(reactions) $ (not reactions_NCA(reactions) and rev_rxn(reactions)) = yes;
         dyn_exchange_rxn(reactions) $ (not reactions_NCA(reactions) and exchange_rxn(reactions)) = yes;
         dyn_Fmax_Object(ObjectSet) $ (FmaxObj_inner_TR(ObjectSet)) = yes;
         dyn_Fmin_Object(ObjectSet) $ (FminObj_inner_TR(ObjectSet)) = yes;
         dyn_objectSet(objectSet) = dyn_Fmax_Object(ObjectSet) + dyn_Fmin_Object(ObjectSet);
         dyn_priority_obj(ObjectSet) $ (PriObj_inner_TR(ObjectSet)) = yes;
         No_priority_obj = card(PriObj_inner_TR);
**** objectives used in outer optimization problem     
         dyn_Fmax_Obj_outer(ObjectSet) $ (FmaxObj_Outer_TR(ObjectSet)) = yes;
         dyn_Fmin_Obj_outer(ObjectSet) $ (FminObj_Outer_TR(ObjectSet)) = yes;
         dyn_obj_outer(objectSet) = dyn_Fmax_Obj_outer(ObjectSet) + dyn_Fmin_Obj_outer(ObjectSet);
         dyn_priority_outer(ObjectSet) $ (PriObj_Outer_TR(ObjectSet)) = yes;
         No_priority_outer = card(PriObj_Outer_TR);
********************************************************************************
***** Set the weighting factors and limits for FBA objectives ******************
         basal_vf(reactions) = 0;
         basal_vb(reactions) = 0;
         basal_vf(reactions) = CA_vf_UFD(reactions);
         basal_vb(reactions) = CA_vb_UFD(reactions);

         z_HDE(Dim_BI) = 0;
         z_HDE(Dim_BI) = ui_XB(NP, Dim_BI);
*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
         ui_Mem_sumZ(NP) $ (flag_sumz < 2) = (sumZ_max - sum(Dim_BI, (z_HDE(Dim_BI) > 0) = 1))/(sumZ_max - 1);
         ui_Mem_sumZ(NP) $ (flag_sumz = 2) = sum(Dim_BI, (z_HDE(Dim_BI) > 0) = 1)/(sumZ_max - 1);
*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
*--- reset the oringinal bounds for all fluxes ------------------------------------------------------------------------------------------------------
         FluxBound_vf_LB(reactions) = tmp_FluxBound_vf_LB(reactions);
         FluxBound_vb_LB(reactions) = tmp_FluxBound_vb_LB(reactions);
         FluxBound_vf_UB(reactions) = tmp_FluxBound_vf_UB(reactions);
         FluxBound_vb_UB(reactions) = tmp_FluxBound_vb_UB(reactions);
*----------------------------------------------------------------------------------------------------------------------------------------------------
*---- restrictions for the lower and upper bounds of fluxes --------------------
         vf.lo(reactions) = FluxBound_vf_LB(reactions);
         vf.up(reactions) = FluxBound_vf_UB(reactions);
         vb.lo(reactions) = FluxBound_vb_LB(reactions);
         vb.up(reactions) = FluxBound_vb_UB(reactions);

*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
         z_isozyme_rxn_enz(reactions, enzymes) = no;
         z_isozyme_rxn(reactions) = no;
         z_HDE_tmp(reactions, enzymes) = 0;
         Regulated_Rxn_v(reactions) = NO;
         dyn_Reg_ExRxn(reactions) = no;
         loop(Dim_BI $ (z_HDE(Dim_BI) >= 1),
              Regulated_rxn_v(reactions) $ (enzyme_Reg_rxn_v(Dim_BI, reactions) and dyn_reactions(reactions)) = yes;

***** assign the regulated reactions to be some levels *************************
* up regulated v
              if(z_HDE(Dim_BI) = 1,
                 vf.lo(Regulated_rxn_v(reactions)) = basal_vf(reactions) + TR_Reg_factor(NP) * (FluxBound_vf_UB(reactions) - basal_vf(reactions));
                 vf.up(Regulated_rxn_v(reactions)) = FluxBound_vf_UB(reactions);
                 vb.lo(Regulated_rxn_v(reactions)) = FluxBound_vb_LB(reactions);
                 vb.up(Regulated_rxn_v(reactions)) = basal_vb(reactions) + TR_Reg_factor(NP) * (FluxBound_vb_LB(reactions) - basal_vb(reactions)););

* down regulated v
              if(z_HDE(Dim_BI) = 2,
                 vf.lo(Regulated_rxn_v(reactions)) = FluxBound_vf_LB(reactions);
                 vf.up(Regulated_rxn_v(reactions)) = basal_vf(reactions) + TR_Reg_factor(NP) * (FluxBound_vf_LB(reactions) - basal_vf(reactions));
                 vb.lo(Regulated_rxn_v(reactions)) = basal_vb(reactions) + TR_Reg_factor(NP) * (FluxBound_vb_UB(reactions) - basal_vb(reactions));
                 vb.up(Regulated_rxn_v(reactions)) = FluxBound_vb_UB(reactions);

*---- the down regulated reaction by Dim_BI is dominatd by other isozymes ------
                 vf.lo(reactions) $ (Regulated_rxn_v(reactions) and isozyme_rxn(reactions)) = (1 - flux_bounded_ratio) * basal_vf(reactions);
                 vf.up(reactions) $ (Regulated_rxn_v(reactions) and isozyme_rxn(reactions)) = (1 + flux_bounded_ratio) * basal_vf(reactions);
                 vb.lo(reactions) $ (Regulated_rxn_v(reactions) and isozyme_rxn(reactions)) = (1 - flux_bounded_ratio) * basal_vb(reactions);
                 vb.up(reactions) $ (Regulated_rxn_v(reactions) and isozyme_rxn(reactions)) = (1 + flux_bounded_ratio) * basal_vb(reactions););
*-------------------------------------------------------------------------------
*---- knockout vf and vb -------------------------------------------------------
              if(z_HDE(Dim_BI) = 3,
                 vf.fx(Regulated_rxn_v(reactions)) = 0;
                 vb.fx(Regulated_rxn_v(reactions)) = 0;

*---- the KO reaction by Dim_BI is dominatd by other isozymes ------------------
                 vf.lo(reactions) $ (Regulated_rxn_v(reactions) and isozyme_rxn(reactions)) = (1 - flux_bounded_ratio) * basal_vf(reactions);
                 vf.up(reactions) $ (Regulated_rxn_v(reactions) and isozyme_rxn(reactions)) = (1 + flux_bounded_ratio) * basal_vf(reactions);
                 vb.lo(reactions) $ (Regulated_rxn_v(reactions) and isozyme_rxn(reactions)) = (1 - flux_bounded_ratio) * basal_vb(reactions);
                 vb.up(reactions) $ (Regulated_rxn_v(reactions) and isozyme_rxn(reactions)) = (1 + flux_bounded_ratio) * basal_vb(reactions););
*-------------------------------------------------------------------------------
*---- reaction is regulated by isozyme -----------------------------------------
              z_isozyme_rxn(reactions) $ (Regulated_rxn_v(reactions) and isozyme_rxn(reactions)) = yes;
              z_isozyme_rxn_enz(reactions, Dim_BI) $ (Regulated_rxn_v(reactions) and isozyme_rxn(reactions)) = yes;
              z_HDE_tmp(reactions, Dim_BI) $ (Regulated_rxn_v(reactions) and isozyme_rxn(reactions)) = z_HDE(Dim_BI);
              dyn_Reg_ExRxn(reactions) = dyn_Reg_ExRxn(reactions) + Regulated_rxn_v(reactions);
              Regulated_Rxn_v(reactions) = NO;);

***** Decide the regulated reaction to be up/down/KO if all isozymes are selected by NHDE ***********************************************************
         if((card(Dim_XI) > 1 and sum(reactions $ (z_isozyme_rxn(reactions)), 1) > 0),
             loop(reactions $ (z_isozyme_rxn(reactions) and sum(Dim_BI $ (z_HDE(Dim_BI) >= 1 and z_isozyme_rxn_enz(reactions, Dim_BI)), 1) =
                               sum(enzymes $ (isozyme_rxn_enz(reactions, enzymes)), 1)),

*---- The reaction is KO if all isozymes are KO, z_HDE_tmp = 3 --------------------------------------------------------------------------------------
                  if(sum(Dim_BI $ (z_HDE(Dim_BI) >= 1), z_HDE_tmp(reactions, Dim_BI)) = 3 * sum(Dim_BI $ (z_HDE(Dim_BI) >= 1 and z_isozyme_rxn_enz(reactions, Dim_BI)), 1),
                     vf.fx(reactions) $ (z_isozyme_rxn(reactions)) = 0;
                     vb.fx(reactions) $ (z_isozyme_rxn(reactions)) = 0;);

*---- The reaction is down/up, (set to down firstly) if one of the isozymes is down/up --------------------------------------------------------------
                  if(sum(Dim_BI $ (z_HDE(Dim_BI) >= 1), z_HDE_tmp(reactions, Dim_BI)) < 3 * sum(Dim_BI $ (z_HDE(Dim_BI) >= 1 and z_isozyme_rxn_enz(reactions, Dim_BI) ), 1),
                     vf.lo(reactions) $ (z_isozyme_rxn(reactions)) = FluxBound_vf_LB(reactions);
                     vf.up(reactions) $ (z_isozyme_rxn(reactions)) = basal_vf(reactions) + TR_Reg_factor(NP) *
                                                                            (FluxBound_vf_LB(reactions) - basal_vf(reactions));
                     vb.lo(reactions) $ (z_isozyme_rxn(reactions)) = basal_vb(reactions) + TR_Reg_factor(NP) *
                                                                            (FluxBound_vb_UB(reactions) - basal_vb(reactions));
                     vb.up(reactions) $ (z_isozyme_rxn(reactions)) = FluxBound_vb_UB(reactions););

*---- The above reaction is reassigned to up, if one of the isozymes is up --------------------------------------------------------------------------
                  loop(Dim_BI $ (z_HDE(Dim_BI) >= 1 and z_HDE_tmp(reactions, Dim_BI) = 1 and z_isozyme_rxn(reactions)),
                       vf.lo(reactions) = basal_vf(reactions) + TR_Reg_factor(NP) * (FluxBound_vf_UB(reactions) - basal_vf(reactions));
                       vf.up(reactions) = FluxBound_vf_UB(reactions);
                       vb.lo(reactions) = FluxBound_vb_LB(reactions);
                       vb.up(reactions) = basal_vb(reactions) + TR_Reg_factor(NP) * (FluxBound_vb_LB(reactions) - basal_vb(reactions));
                       break $ (z_HDE_tmp(reactions, Dim_BI) = 1););
             );
         );
         
*----------------------------------------------------------------------------------------------------------------------------------------------------
*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
* assign vb = 0 for the irreversible fluxes
         vb.lo(irrev_rxn) = 0;
         vb.up(irrev_rxn) = 0;
         vb.fx(irrev_rxn) = 0;
         vb.fx(DM_sink_rxn(reactions)) $ (flag_DM_sink = 1) = 0;
         vf.lo(irrev_vb_rxn(reactions)) = 0;
         vf.up(irrev_vb_rxn(reactions)) = 0;
         vf.fx(irrev_vb_rxn(reactions)) = 0;

* assign the demanded uptake/secretion reactions
         vf.fx(uptake_demand) = 0;
         vb.fx(secretion_demand) = 0;
         vb.fx(uptake_fixed) = FluxBound_vb_LB(uptake_fixed);

* irreversible uptake_rxn and secretion_rxn
         vf.fx(uptake_rxn(reactions)) $ (flag_uptake = 1 and not dyn_Reg_ExRxn(reactions)) = 0;
         vb.fx(secretion_rxn(reactions)) $ (flag_secretion = 1 and not dyn_Reg_ExRxn(reactions)) = 0;

         vf.fx(uptake_demand(reactions)) $ (card(uptake_demand) > 0) = 0;
         vb.fx(secretion_demand(reactions)) $ (card(secretion_demand) > 0) = 0;
********************************************************************************
*** Assign vf > 0 and vb = 0 for the Specific_rxn_vf --------------------------------
         if(card(TR_Specific_rxn_vf) > 0,
            vf.lo(TR_Specific_rxn_vf) =  TR_Specific_rxn_vf_LB(TR_Specific_rxn_vf);
            vf.up(TR_Specific_rxn_vf) =  TR_Specific_rxn_vf_UB(TR_Specific_rxn_vf);
            vb.lo(TR_Specific_rxn_vf) =  0;
            vb.up(TR_Specific_rxn_vf) =  0;
            vb.fx(TR_Specific_rxn_vf) =  0;);
********************************************************************************
*** Assign vf = 0 and vb > 0 for the Specific_rxn_vb --------------------------------
         if(card(TR_Specific_rxn_vb) > 0,
            vb.lo(TR_Specific_rxn_vb) =  TR_Specific_rxn_vb_LB(TR_Specific_rxn_vb);
            vb.up(TR_Specific_rxn_vb) =  TR_Specific_rxn_vb_UB(TR_Specific_rxn_vb);
            vf.lo(TR_Specific_rxn_vb) =  0;
            vf.up(TR_Specific_rxn_vb) =  0;
            vf.fx(TR_Specific_rxn_vb) =  0;);
*** Assign vf > 0 and vb > 0 for the Specific_rxn_vfvb -------------------------------
         if(card(TR_Specific_rxn_vfvb) > 0,
            vf.lo(TR_Specific_rxn_vfvb) =  TR_Specific_rxn_vf_LB(TR_Specific_rxn_vfvb);
            vf.up(TR_Specific_rxn_vfvb) =  TR_Specific_rxn_vf_UB(TR_Specific_rxn_vfvb);
            vb.lo(TR_Specific_rxn_vfvb) =  TR_Specific_rxn_vb_LB(TR_Specific_rxn_vfvb);
            vb.up(TR_Specific_rxn_vfvb) =  TR_Specific_rxn_vb_UB(TR_Specific_rxn_vfvb););    
*******************************************************************************  
*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
***** Set the weighting factors and limits for FBA objectives ******************
*----- compute the lower and upper bounds for the target reactions
         target_limit_LB(targetSet) = 0;
         target_limit_UB(targetSet) = 0;
         target_limit_LB(targetSet) = CA_target_level_LB(targetSet);
         target_limit_UB(targetSet) = CA_target_level_UB(targetSet);
         MultiObjValue_FBA.lo(ObjectSet) = MultiObjValue_min(objectSet);
         MultiObjValue_FBA.up(ObjectSet) = MultiObjValue_max(objectSet);
         mem_objvalue_FBA.lo(objectSet) = 0;
         mem_objvalue_FBA.up(objectSet) = 1;
         TR_MultiObjvalue_Optim(objectset) = 0;
         Lambda.lo = 0;
         Lambda.up = 1;         
*-------------------------------------------------------------------------------
* set weightin factor for mem_objvalue_FBA for CA ------------------------------
         Weight_Lambda(ObjectSet) = 0;
         Weight_Lambda(ObjectSet) = TR_Weight_mem_obj_FBA(ObjectSet);
*-------------------------------------------------------------------------------
*---- solve regulated FBA problem ----------------------------------------------
         solve FBA_Problem using LP maximizing objValue_FBA;
         nfeval_FBA_max = nfeval_FBA_max + 1;
         nfeval = nfeval + 1;
         ui_modelstat_FBA(NP) = FBA_Problem.modelstat;
         ui_constraint(NP) = 0;
         tmp_vf_FBA(reactions) = 0;
         tmp_vb_FBA(reactions) = 0;
         tmp_vf_FBA(dyn_reactions) = max(vf.l(dyn_reactions), 0);
         tmp_vb_FBA(dyn_reactions) = max(vb.l(dyn_reactions), 0);
         tmp_MultiObjvalue_Optim(Objectset) = 0;
         tmp_MultiObjvalue_Optim(dyn_objectset) = sum(dyn_reactions, coef_CellularObj_vf(dyn_objectset, dyn_reactions) * tmp_vf_FBA(dyn_reactions)) +
                                                  sum(dyn_reactions, coef_CellularObj_vb(dyn_objectset, dyn_reactions) * tmp_vb_FBA(dyn_reactions));
         TR_MultiObjvalue_Optim(dyn_objectset) = tmp_MultiObjvalue_Optim(dyn_objectset);

*---- infeasible solution ------------------------------------------------------
         if(ui_modelstat_FBA(NP) > 2,         
            ui_FMObj_inner_TR(NP, ObjectSet) = 0;
            ui_FMObj_inner_PH(NP, ObjectSet) = 0;
            ui_FMObj_outer_TR(NP, ObjectSet) = 0;
            ui_FMObj_outer_PH(NP, ObjectSet) = 0;        
            ui_mem_Met_Exp_PHHT(NP) = 0;
            ui_mem_CV_TR(NP) = 0;
            ui_mem_CV_PH(NP) = 0;
            ui_mem_MD_TP(NP) = 0;
            ui_mem_Met_PHHT(NP) = 0;
            ui_mem_rxn_PHHT(NP) = 0;
            ui_mem_Met_PHCA(NP) = 0;
            ui_mem_rxn_PHCA(NP) = 0;
            ui_mem_Met_TRCA(NP) = 0;
            ui_mem_rxn_TRCA(NP) = 0;            
            ui_mem_Met_TRHT(NP) = 0;
            ui_mem_rxn_TRHT(NP) = 0;
            constraint_h(Dim_h) = 0;
            constraint_h(Dim_h) = sum(reactions, S_Matrix(Dim_h, reactions) * (vf.l(reactions) - vb.l(reactions)));
            tmp_constraint_h = sum(dyn_Fmin_Object, mem_objvalue_FBA.l(dyn_Fmin_Object) -
                                  (MultiObjValue_max(dyn_Fmin_Object) - TR_MultiObjvalue_Optim(dyn_Fmin_Object))/
                                  (MultiObjValue_max(dyn_Fmin_Object) - MultiObjValue_min(dyn_Fmin_Object))) +
                               sum(dyn_Fmax_Object, mem_objvalue_FBA.l(dyn_Fmax_Object) -
                                  (TR_MultiObjvalue_Optim(dyn_Fmax_Object) - MultiObjValue_min(dyn_Fmax_Object))/
                                  (MultiObjValue_max(dyn_Fmax_Object) - MultiObjValue_min(dyn_Fmax_Object)));                             
            constraint_g = sum(targetSet, max((target_limit_LB(targetSet) - (vf.l(targetSet) - vb.l(targetSet))), 0)) +
                           sum(targetSet, max(((vf.l(targetSet) - vb.l(targetSet)) - target_limit_UB(targetSet)), 0)) +
                           sum(dyn_ObjectSet, max((Lambda.l - mem_objvalue_FBA.l(dyn_ObjectSet)), 0));   
            constraint_FBA_TR = penalty * (sum(Dim_h, abs(constraint_h(Dim_h)) + abs(tmp_constraint_h)) + constraint_g););

*---- solve UFD problem --------------------------------------------------------
*%%%%% the user can modify the following procedures %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
         if(ui_modelstat_FBA(NP) <= 2,    
            ui_FMObj_inner_TR(NP, dyn_ObjectSet) = TR_MultiObjvalue_Optim(dyn_objectset);
            Mem_Obj_FBA_limit(ObjectSet) = 0;
            Mem_Obj_FBA_limit(dyn_Fmax_Object) = ((TR_MultiObjvalue_Optim(dyn_Fmax_Object) - MultiObjValue_min(dyn_Fmax_Object))/
                                                  (MultiObjValue_max(dyn_Fmax_Object) - MultiObjValue_min(dyn_Fmax_Object)));
                                        
            Mem_Obj_FBA_limit(dyn_Fmin_Object) = ((MultiObjValue_max(dyn_Fmin_Object) - TR_MultiObjvalue_Optim(dyn_Fmin_Object))/
                                                  (MultiObjValue_max(dyn_Fmin_Object) - MultiObjValue_min(dyn_Fmin_Object)));
            Mem_Obj_FBA_limit(dyn_ObjectSet) = max(min( Mem_Obj_FBA_limit(dyn_ObjectSet), 1), 0);
            
** assign weighting coefficients for Rxn for computing ObjValue in UFD ******************************************************************************
            weight_coef_rxn(reactions) = Weight_factor_Rxn_OT;
            weight_coef_rxn(reactions) $ (CA_Reactions_HC(reactions)) = Weight_factor_Rxn_HC;
            weight_coef_rxn(reactions) $ (CA_Reactions_MC(reactions)) = Weight_factor_Rxn_MC;
            weight_coef_rxn(reactions) $ (CA_Reactions_NC(reactions)) = Weight_factor_Rxn_NC;
*****************************************************************************************************************************************************
*----- compute the lower and upper bounds for the target reactions ------------
            target_limit_LB(targetSet) = 0;
            target_limit_UB(targetSet) = 0;
            target_limit_LB(targetSet) = CA_target_level_LB(targetSet);
            target_limit_UB(targetSet) = CA_target_level_UB(targetSet);
            MultiObjValue_FBA.lo(ObjectSet) = MultiObjValue_min(objectSet);
            MultiObjValue_FBA.up(ObjectSet) = MultiObjValue_max(objectSet);
            mem_objvalue_FBA.lo(objectSet) = 0;
            mem_objvalue_FBA.up(objectSet) = 1;
*------------------------------------------------------------------------------
 
            TR_vf_UFD(reactions) = 0;
            TR_vb_UFD(reactions) = 0;
            if(flag_UFD_Obj = 1, solve UFD1_Problem using LP minimizing ObjValue_UFD;);
            if(flag_UFD_Obj = 2, solve UFD2_Problem using LP minimizing ObjValue_UFD;);
            if(flag_UFD_Obj = 3, solve UFD3_Problem using QCP minimizing ObjValue_UFD;);
            if(flag_UFD_Obj = 4, solve UFD4_Problem using QCP minimizing ObjValue_UFD;);
            nfeval_UFD_min = nfeval_UFD_min + 1;
            nfeval = nfeval + 1;
            ui_modelstat_UFD(NP) = UFD%No_UFD_Obj%_Problem.modelstat;
            TR_vf_UFD(reactions) = max(vf.l(reactions), 0);
            TR_vb_UFD(reactions) = max(vb.l(reactions), 0);
            TR_v_UFD(reactions) = TR_vf_UFD(reactions) - TR_vb_UFD(reactions);

*---- infeasible solution ------------------------------------------------------
            if(ui_modelstat_UFD(NP) > 2,          
               ui_FMObj_inner_TR(NP, ObjectSet) = 0;
               ui_FMObj_inner_PH(NP, ObjectSet) = 0;
               ui_FMObj_outer_TR(NP, ObjectSet) = 0;
               ui_FMObj_outer_PH(NP, ObjectSet) = 0;           
               ui_mem_Met_Exp_PHHT(NP) = 0;           
               ui_mem_CV_TR(NP) = 0;
               ui_mem_CV_PH(NP) = 0;
               ui_mem_MD_TP(NP) = 0;
               ui_mem_Met_PHHT(NP) = 0;
               ui_mem_rxn_PHHT(NP) = 0;
               ui_mem_Met_PHCA(NP) = 0;
               ui_mem_rxn_PHCA(NP) = 0;
               ui_mem_Met_TRCA(NP) = 0;
               ui_mem_rxn_TRCA(NP) = 0;               
               ui_mem_Met_TRHT(NP) = 0;
               ui_mem_rxn_TRHT(NP) = 0;
               constraint_h(Dim_h) = 0;
               constraint_h(Dim_h) = sum(reactions, S_Matrix(Dim_h, reactions) * (vf.l(reactions) - vb.l(reactions)));
               tmp_constraint_h = sum(dyn_Fmin_Object, mem_objvalue_FBA.l(dyn_Fmin_Object) -
                                     (MultiObjValue_max(dyn_Fmin_Object) - MultiObjValue_FBA.l(dyn_Fmin_Object))/
                                     (MultiObjValue_max(dyn_Fmin_Object) - MultiObjValue_min(dyn_Fmin_Object))) +
                                  sum(dyn_Fmax_Object, mem_objvalue_FBA.l(dyn_Fmax_Object) -
                                     (MultiObjValue_FBA.l(dyn_Fmax_Object) - MultiObjValue_min(dyn_Fmax_Object))/
                                     (MultiObjValue_max(dyn_Fmax_Object) - MultiObjValue_min(dyn_Fmax_Object)));                             
               constraint_g = sum(targetSet, max((target_limit_LB(targetSet) - (vf.l(targetSet) - vb.l(targetSet))), 0)) +
                              sum(targetSet, max(((vf.l(targetSet) - vb.l(targetSet)) - target_limit_UB(targetSet)), 0)) +
                              sum(dyn_ObjectSet, max((Mem_Obj_FBA_limit(dyn_ObjectSet) - mem_objvalue_FBA.l(dyn_ObjectSet)), 0));   
               constraint_UFD_TR = penalty * (sum(Dim_h, abs(constraint_h(Dim_h)) + abs(tmp_constraint_h)) + constraint_g););
*-------------------------------------------------------------------------------

*---- solve UFD problem --------------------------------------------------------
*%%%%% the user can modify the following procedures %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            if(ui_modelstat_UFD(NP) <= 2,

**** compute membership grades of fuzzy max and min objectives for outer TR model *******************************************************************
               TR_MultiObjvalue_Optim(Objectset) = 0;
               TR_MultiObjvalue_Optim(dyn_obj_outer) = sum(dyn_reactions, coef_CellularObj_vf(dyn_obj_outer, dyn_reactions) * TR_vf_UFD(dyn_reactions)) +
                                                       sum(dyn_reactions, coef_CellularObj_vb(dyn_obj_outer, dyn_reactions) * TR_vb_UFD(dyn_reactions));  
               ui_FMObj_outer_TR(NP, dyn_obj_outer) = TR_MultiObjvalue_Optim(dyn_obj_outer);
           
**** compute membership grades of fuzzy max and min objectives for outer TR model *******************************************************************
               Mem_Obj_FBA_limit(ObjectSet) = 0;
               Mem_Obj_FBA_limit(dyn_Fmax_Obj_outer) = (TR_MultiObjvalue_Optim(dyn_Fmax_Obj_outer) - MultiObjValue_min(dyn_Fmax_Obj_outer))/
                                                       (MultiObjValue_max(dyn_Fmax_Obj_outer) - MultiObjValue_min(dyn_Fmax_Obj_outer));
               Mem_Obj_FBA_limit(dyn_Fmin_Obj_outer) = (MultiObjValue_max(dyn_Fmin_Obj_outer) - TR_MultiObjvalue_Optim(dyn_Fmin_Obj_outer))/
                                                       (MultiObjValue_max(dyn_Fmin_Obj_outer) - MultiObjValue_min(dyn_Fmin_Obj_outer));
               Mem_Obj_FBA_limit(dyn_Obj_outer) = max(min( Mem_Obj_FBA_limit(dyn_Obj_outer), 1), 0);                                 
               mem_PriObj_Outer_TR = sum(dyn_priority_outer, Mem_Obj_FBA_limit(dyn_priority_outer))/No_priority_outer;
               ui_mem_CV_TR(NP) = 0.5 * (mem_PriObj_Outer_TR + smin(dyn_obj_outer, Mem_Obj_FBA_limit(dyn_obj_outer)));
*****************************************************************************************************************************************************

*=== compute synthesis rate for each species of treated TR model ====================================================================================
               TR_Species_SynRate(species) = 0;
               loop(dyn_species,
                    TR_Species_SynRate(dyn_species) = sum(dyn_reactions, S_Matrix(dyn_species, dyn_reactions) $
                                                         (S_Matrix(dyn_species, dyn_reactions) > 0) * TR_vf_UFD(dyn_reactions))
                                                    - sum(dyn_reactions, S_Matrix(dyn_Species, dyn_reactions) $
                                                         (S_Matrix(dyn_species, dyn_reactions) < 0) * TR_vb_UFD(dyn_reactions)););

***** compute synthesis rate for each biocompound of treated TR model ******************************************************************************
               TR_BioComp_SynRate(BioCompound) = 0;
               loop(dyn_BioComp,
                    TR_BioComp_SynRate(dyn_BioComp) = sum(dyn_Species $ (BioCompound_species(dyn_BioComp, dyn_Species)),
                                                          TR_Species_SynRate(dyn_Species)););
                                                           
***** compute fuzzy similarity of metabolite-flow and its membership grade for TRHT model ***********************************************************             
               L_mem_Met_tmp(biocompound) = 0;
               R_mem_Met_tmp(biocompound) = 0;
               mem_Met_tmp(biocompound) = 0;             
               L_mem_Met_tmp(BioComp_TRHT) $ (HT_BioComp_SynRate(BioComp_TRHT) > 0) =
                                             (TR_BioComp_SynRate(BioComp_TRHT) - HT_MetFlowRate_LB(BioComp_TRHT))/
                                             (HT_BioComp_SynRate(BioComp_TRHT) - HT_MetFlowRate_LB(BioComp_TRHT));                                         
               L_mem_Met_tmp(BioComp_TRHT) $ (HT_BioComp_SynRate(BioComp_TRHT) = 0) = 1;
               R_mem_Met_tmp(BioComp_TRHT) = (HT_MetFlowRate_UB(BioComp_TRHT) - TR_BioComp_SynRate(BioComp_TRHT))/
                                             (HT_MetFlowRate_UB(BioComp_TRHT) - HT_BioComp_SynRate(BioComp_TRHT));  
               mem_Met_tmp(BioComp_TRHT) = max(min(L_mem_Met_tmp(BioComp_TRHT), R_mem_Met_tmp(BioComp_TRHT), 1), 0);

               nonzero_Biocomp(biocompound) = no;             
               nonzero_Biocomp(biocompound) $ ((TR_BioComp_SynRate(biocompound) > 0 or
                                                HT_BioComp_SynRate(biocompound) > 0) and BioComp_TRHT(biocompound)) = yes;

               No_nonzero_Biocomp_TRHT = card(nonzero_Biocomp);                                               
               ui_mem_Met_TRHT(NP) = sum(BioCompound $ (nonzero_Biocomp(biocompound)), mem_Met_tmp(BioCompound))/No_nonzero_Biocomp_TRHT;

*****************************************************************************************************************************************************
***** compute fuzzy similarity of flux and its membership grade for TRHT model **********************************************************************
               L_mem_vf_tmp(reactions) = 0;
               R_mem_vf_tmp(reactions) = 0;
               L_mem_vb_tmp(reactions) = 0;
               R_mem_vb_tmp(reactions) = 0;
               L_mem_vf_tmp(rxn_vf_TRHT) $ (HT_vf_UFD(rxn_vf_TRHT) > 0) =
                                           (TR_vf_UFD(rxn_vf_TRHT) - HT_vf_rxn_LB(rxn_vf_TRHT))/
                                           (HT_vf_UFD(rxn_vf_TRHT) - HT_vf_rxn_LB(rxn_vf_TRHT));
               L_mem_vf_tmp(rxn_vf_TRHT) $ (HT_vf_UFD(rxn_vf_TRHT) = 0) = 1;
               R_mem_vf_tmp(rxn_vf_TRHT) = (HT_vf_rxn_UB(rxn_vf_TRHT) - TR_vf_UFD(rxn_vf_TRHT))/
                                           (HT_vf_rxn_UB(rxn_vf_TRHT)- HT_vf_UFD(rxn_vf_TRHT));           
               L_mem_vb_tmp(rxn_vb_TRHT) $ (HT_vb_UFD(rxn_vb_TRHT) > 0) =
                                           (TR_vb_UFD(rxn_vb_TRHT) - HT_vb_rxn_LB(rxn_vb_TRHT))/
                                           (HT_vb_UFD(rxn_vb_TRHT) - HT_vb_rxn_LB(rxn_vb_TRHT));
               L_mem_vb_tmp(rxn_vb_TRHT) $ (HT_vb_UFD(rxn_vb_TRHT) = 0) = 1;
               R_mem_vb_tmp(rxn_vb_TRHT) = (HT_vb_rxn_UB(rxn_vb_TRHT) - TR_vb_UFD(rxn_vb_TRHT))/
                                           (HT_vb_rxn_UB(rxn_vb_TRHT)- HT_vb_UFD(rxn_vb_TRHT));  
**** intialization
               mem_vf_tmp(reactions) = 0;
               mem_vb_tmp(reactions) = 0;              
               mem_vf_tmp(rxn_vf_TRHT) = max(min(L_mem_vf_tmp(rxn_vf_TRHT), R_mem_vf_tmp(rxn_vf_TRHT), 1), 0);
               mem_vb_tmp(rxn_vb_TRHT) = max(min(L_mem_vb_tmp(rxn_vb_TRHT), R_mem_vb_tmp(rxn_vb_TRHT), 1), 0);

               nonzero_vf(reactions) = no;
               nonzero_vf(reactions) $ ((TR_vf_UFD(reactions) > 0 or
                                         HT_vf_UFD(reactions) > 0) and rxn_vf_TRHT(reactions)) = yes;
               nonzero_vb(reactions) = no;
               nonzero_vb(reactions) $ ((TR_vb_UFD(reactions) > 0 or
                                         HT_vb_UFD(reactions) > 0) and rxn_vb_TRHT(reactions)) = yes;
               nonzero_v(reactions) = no;                               
               nonzero_v(reactions) =  nonzero_vf(reactions) + nonzero_vb(reactions);
               No_nonzero_vf_TRHT = card(nonzero_vf);
               No_nonzero_vb_TRHT = card(nonzero_vb);              
               No_nonzero_v_TRHT = card(nonzero_v);
               ui_mem_rxn_TRHT(NP) = sum(reactions $ (nonzero_v(reactions)),             
                                         min(mem_vf_tmp(reactions),mem_vb_tmp(reactions)))/No_nonzero_v_TRHT;           
*====================================================================================================================================================
***** compute fuzzy dissimilarity of metabolite-flow and its membership grade for TRCA model *********************************************************
               L_mem_Met_tmp(biocompound) = 0;
               R_mem_Met_tmp(biocompound) = 0;
               mem_Met_tmp(biocompound) = 0;             
               L_mem_Met_tmp(BioComp_TRCA) $ (CA_BioComp_SynRate(BioComp_TRCA) > 0) =         
                                             (CA_BioComp_SynRate(BioComp_TRCA) - TR_BioComp_SynRate(BioComp_TRCA))/
                                             (CA_BioComp_SynRate(BioComp_TRCA) - CA_MetFlowRate_LB(BioComp_TRCA));
               L_mem_Met_tmp(BioComp_TRCA) $ (CA_BioComp_SynRate(BioComp_TRCA) = 0) = 0;
               R_mem_Met_tmp(BioComp_TRCA) = (TR_BioComp_SynRate(BioComp_TRCA) - CA_BioComp_SynRate(BioComp_TRCA))/
                                             (CA_MetFlowRate_UB(BioComp_TRCA) - CA_BioComp_SynRate(BioComp_TRCA));
               mem_Met_tmp(BioComp_TRCA) = min(max(L_mem_Met_tmp(BioComp_TRCA), R_mem_Met_tmp(BioComp_TRCA), 0), 1);

               nonzero_Biocomp(biocompound) = no;             
               nonzero_Biocomp(biocompound) $ ((TR_BioComp_SynRate(biocompound) > 0 or
                                                CA_BioComp_SynRate(biocompound) > 0) and BioComp_TRCA(biocompound)) = yes;

               No_nonzero_Biocomp_TRCA = card(nonzero_Biocomp);                                               
               ui_mem_Met_TRCA(NP) = sum(BioCompound $ (nonzero_Biocomp(biocompound)), mem_Met_tmp(BioCompound))/No_nonzero_Biocomp_TRCA;

***** compute fuzzy dissimilarity of flux and its membership grade for TRCA model *******************************************************************
               L_mem_vf_tmp(reactions) = 0;
               R_mem_vf_tmp(reactions) = 0;
               L_mem_vb_tmp(reactions) = 0;
               R_mem_vb_tmp(reactions) = 0;          
               L_mem_vf_tmp(rxn_vf_TRCA) $ (CA_vf_UFD(rxn_vf_TRCA) > 0) = (CA_vf_UFD(rxn_vf_TRCA) - TR_vf_UFD(rxn_vf_TRCA))/
                                                                         (CA_vf_UFD(rxn_vf_TRCA) - CA_vf_rxn_LB(rxn_vf_TRCA));
               L_mem_vf_tmp(rxn_vf_TRCA) $ (CA_vf_UFD(rxn_vf_TRCA) = 0) = 0;           
               R_mem_vf_tmp(rxn_vf_TRCA) = (TR_vf_UFD(rxn_vf_TRCA) - CA_vf_UFD(rxn_vf_TRCA))/
                                           (CA_vf_rxn_UB(rxn_vf_TRCA)- CA_vf_UFD(rxn_vf_TRCA));                                       
               L_mem_vb_tmp(rxn_vb_TRCA) $ (CA_vb_UFD(rxn_vb_TRCA) > 0) = (CA_vb_UFD(rxn_vb_TRCA) - TR_vb_UFD(rxn_vb_TRCA))/
                                                                          (CA_vb_UFD(rxn_vb_TRCA) - CA_vb_rxn_LB(rxn_vb_TRCA));
               L_mem_vb_tmp(rxn_vb_TRCA) $ (CA_vb_UFD(rxn_vb_TRCA) = 0) = 0;                                       
               R_mem_vb_tmp(rxn_vb_TRCA) = (TR_vb_UFD(rxn_vb_TRCA) - CA_vb_UFD(rxn_vb_TRCA))/
                                           (CA_vb_rxn_UB(rxn_vb_TRCA)- CA_vb_UFD(rxn_vb_TRCA)); 
**** intialization
               mem_vf_tmp(reactions) = 0;
               mem_vb_tmp(reactions) = 0;               
               mem_vf_tmp(rxn_vf_TRCA) = min(max(L_mem_vf_tmp(rxn_vf_TRCA), R_mem_vf_tmp(rxn_vf_TRCA), 0), 1);
               mem_vb_tmp(rxn_vb_TRCA) = min(max(L_mem_vb_tmp(rxn_vb_TRCA), R_mem_vb_tmp(rxn_vb_TRCA), 0), 1);

               nonzero_vf(reactions) = no;
               nonzero_vf(reactions) $ ((TR_vf_UFD(reactions) > 0 or
                                         CA_vf_UFD(reactions) > 0) and rxn_vf_TRCA(reactions)) = yes;
               nonzero_vb(reactions) = no;
               nonzero_vb(reactions) $ ((TR_vb_UFD(reactions) > 0 or
                                         CA_vb_UFD(reactions) > 0) and rxn_vb_TRCA(reactions)) = yes;                                     
               nonzero_v(reactions) = no;                               
               nonzero_v(reactions) =  nonzero_vf(reactions) + nonzero_vb(reactions);
               No_nonzero_vf_TRCA = card(nonzero_vf);
               No_nonzero_vb_TRCA = card(nonzero_vb);              
               No_nonzero_v_TRCA = card(nonzero_v);
               ui_mem_rxn_TRCA(NP) = sum(reactions $ (nonzero_v(reactions)),             
                                         max(mem_vf_tmp(reactions),mem_vb_tmp(reactions)))/No_nonzero_v_TRCA;  
*====================================================================================================================================================
               constraint_FBA_TR = 0;
               constraint_UFD_TR = 0;
*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                   

*===== evaluating side effects to solve perturbed FBA and UFD problems of HT model ==================================================================
***** Fuzzy multiobjective HT FBA Problem ***********************************************************************************************************
***** assign reactions and species in FMO HT models as dynamic sets ****************   
               dyn_reactions(reactions) = no;
               dyn_species(species) = no;
               dyn_BioComp(biocompound) = no;
               dyn_irrev_rxn(reactions) = no;
               dyn_rev_rxn(reactions) = no;
               dyn_exchange_rxn(reactions) = no;
               dyn_objectSet(objectSet) = no;
               dyn_Fmax_Object(ObjectSet) = no;
               dyn_Fmin_Object(ObjectSet) = no;
               dyn_priority_obj(ObjectSet) = no;
               dyn_obj_outer(objectSet) = no;
               dyn_Fmax_Obj_outer(ObjectSet) = no;
               dyn_Fmin_Obj_outer(ObjectSet) = no;
               dyn_priority_outer(ObjectSet) = no;    

**** objectives used in inner optimization problem
               dyn_reactions(reactions)  $ (not reactions_NHT(reactions)) = yes;
               dyn_species(species) $ (not species_NHT(species)) = yes;
               dyn_BioComp(biocompound) $ (not biocompound_NHT(biocompound)) = yes;
               dyn_irrev_rxn(reactions) $ (not reactions_NHT(reactions) and irrev_rxn(reactions)) = yes;
               dyn_rev_rxn(reactions) $ (not reactions_NHT(reactions) and rev_rxn(reactions)) = yes;
               dyn_exchange_rxn(reactions) $ (not reactions_NHT(reactions) and exchange_rxn(reactions)) = yes;
               dyn_Fmax_Object(ObjectSet) $ (FmaxObj_inner_PH(ObjectSet)) = yes;
               dyn_Fmin_Object(ObjectSet) $ (FminObj_inner_PH(ObjectSet)) = yes;
               dyn_objectSet(objectSet) = dyn_Fmax_Object(ObjectSet) + dyn_Fmin_Object(ObjectSet);
               dyn_priority_obj(ObjectSet) $ (PriObj_inner_PH(ObjectSet)) = yes;
               No_priority_obj = card(PriObj_inner_PH);
**** objectives used in outer optimization problem     
               dyn_Fmax_Obj_outer(ObjectSet) $ (FmaxObj_Outer_PH(ObjectSet)) = yes;
               dyn_Fmin_Obj_outer(ObjectSet) $ (FminObj_Outer_PH(ObjectSet)) = yes;
               dyn_obj_outer(objectSet) = dyn_Fmax_Obj_outer(ObjectSet) + dyn_Fmin_Obj_outer(ObjectSet);
               dyn_priority_outer(ObjectSet) $ (PriObj_Outer_PH(ObjectSet)) = yes;
               No_priority_outer = card(PriObj_Outer_PH);
********************************************************************************

***** Set the weighting factors and limits for FBA objectives ******************
               basal_vf(reactions) = 0;
               basal_vb(reactions) = 0;
               basal_vf(reactions) = HT_vf_UFD(reactions);
               basal_vb(reactions) = HT_vb_UFD(reactions);

*--- reset the oringinal bounds for all fluxes ------------------------------------------------------------------------------------------------------
               FluxBound_vf_LB(reactions) = tmp_FluxBound_vf_LB(reactions);
               FluxBound_vb_LB(reactions) = tmp_FluxBound_vb_LB(reactions);
               FluxBound_vf_UB(reactions) = tmp_FluxBound_vf_UB(reactions);
               FluxBound_vb_UB(reactions) = tmp_FluxBound_vb_UB(reactions);
*----------------------------------------------------------------------------------------------------------------------------------------------------               

*---- restrictions for the lower and upper bounds of fluxes --------------------
               vf.lo(reactions) = FluxBound_vf_LB(reactions);
               vf.up(reactions) = FluxBound_vf_UB(reactions);
               vb.lo(reactions) = FluxBound_vb_LB(reactions);
               vb.up(reactions) = FluxBound_vb_UB(reactions);

*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
               z_isozyme_rxn_enz(reactions, enzymes) = no;
               z_isozyme_rxn(reactions) = no;
               z_HDE_tmp(reactions, enzymes) = 0;
               Regulated_Rxn_v(reactions) = NO;
               dyn_Reg_ExRxn(reactions) = no;
               loop(Dim_BI $ (z_HDE(Dim_BI) >= 1),
                    Regulated_rxn_v(reactions) $ (enzyme_Reg_rxn_v(Dim_BI, reactions) and dyn_reactions(reactions)) = yes;

***** assign the regulated reactions to be some levels *************************
* up regulated v
                    if(z_HDE(Dim_BI) = 1,
                       vf.lo(Regulated_rxn_v(reactions)) = basal_vf(reactions) + TR_Reg_factor(NP) * (FluxBound_vf_UB(reactions) - basal_vf(reactions));
                       vf.up(Regulated_rxn_v(reactions)) = FluxBound_vf_UB(reactions);
                       vb.lo(Regulated_rxn_v(reactions)) = FluxBound_vb_LB(reactions);
                       vb.up(Regulated_rxn_v(reactions)) = basal_vb(reactions) + TR_Reg_factor(NP) * (FluxBound_vb_LB(reactions) - basal_vb(reactions)););

* down regulated v
                    if(z_HDE(Dim_BI) = 2,
                       vf.lo(Regulated_rxn_v(reactions)) = FluxBound_vf_LB(reactions);
                       vf.up(Regulated_rxn_v(reactions)) = basal_vf(reactions) + TR_Reg_factor(NP) * (FluxBound_vf_LB(reactions) - basal_vf(reactions));
                       vb.lo(Regulated_rxn_v(reactions)) = basal_vb(reactions) + TR_Reg_factor(NP) * (FluxBound_vb_UB(reactions) - basal_vb(reactions));
                       vb.up(Regulated_rxn_v(reactions)) = FluxBound_vb_UB(reactions);

*---- the down regulated reaction by Dim_BI is dominatd by other isozymes ------
                       vf.lo(reactions) $ (Regulated_rxn_v(reactions) and isozyme_rxn(reactions)) = (1 - flux_bounded_ratio) * basal_vf(reactions);
                       vf.up(reactions) $ (Regulated_rxn_v(reactions) and isozyme_rxn(reactions)) = (1 + flux_bounded_ratio) * basal_vf(reactions);
                       vb.lo(reactions) $ (Regulated_rxn_v(reactions) and isozyme_rxn(reactions)) = (1 - flux_bounded_ratio) * basal_vb(reactions);
                       vb.up(reactions) $ (Regulated_rxn_v(reactions) and isozyme_rxn(reactions)) = (1 + flux_bounded_ratio) * basal_vb(reactions););
*-------------------------------------------------------------------------------
*---- knockout vf and vb -------------------------------------------------------
                    if(z_HDE(Dim_BI) = 3,
                       vf.fx(Regulated_rxn_v(reactions)) = 0;
                       vb.fx(Regulated_rxn_v(reactions)) = 0;

*---- the KO reaction by Dim_BI is dominatd by other isozymes ------------------
                       vf.lo(reactions) $ (Regulated_rxn_v(reactions) and isozyme_rxn(reactions)) = (1 - flux_bounded_ratio) * basal_vf(reactions);
                       vf.up(reactions) $ (Regulated_rxn_v(reactions) and isozyme_rxn(reactions)) = (1 + flux_bounded_ratio) * basal_vf(reactions);
                       vb.lo(reactions) $ (Regulated_rxn_v(reactions) and isozyme_rxn(reactions)) = (1 - flux_bounded_ratio) * basal_vb(reactions);
                       vb.up(reactions) $ (Regulated_rxn_v(reactions) and isozyme_rxn(reactions)) = (1 + flux_bounded_ratio) * basal_vb(reactions););
*-------------------------------------------------------------------------------
*---- reaction is regulated by isozyme -----------------------------------------
                    z_isozyme_rxn(reactions) $ (Regulated_rxn_v(reactions) and isozyme_rxn(reactions)) = yes;
                    z_isozyme_rxn_enz(reactions, Dim_BI) $ (Regulated_rxn_v(reactions) and isozyme_rxn(reactions)) = yes;
                    z_HDE_tmp(reactions, Dim_BI) $ (Regulated_rxn_v(reactions) and isozyme_rxn(reactions)) = z_HDE(Dim_BI);
                    dyn_Reg_ExRxn(reactions) = dyn_Reg_ExRxn(reactions) + Regulated_rxn_v(reactions);
                    Regulated_Rxn_v(reactions) = NO;);

***** Decide the regulated reaction to be up/down/KO if all isozymes are selected by NHDE ***********************************************************
               if((card(Dim_XI) > 1 and sum(reactions $ (z_isozyme_rxn(reactions)), 1) > 0),
                   loop(reactions $ (z_isozyme_rxn(reactions) and sum(Dim_BI $ (z_HDE(Dim_BI) >= 1 and z_isozyme_rxn_enz(reactions, Dim_BI)), 1) =
                                     sum(enzymes $ (isozyme_rxn_enz(reactions, enzymes)), 1)),
*---- The reaction is KO if all isozymes are KO, z_HDE_tmp = 3 --------------------------------------------------------------------------------------
                        if(sum(Dim_BI $ (z_HDE(Dim_BI) >= 1), z_HDE_tmp(reactions, Dim_BI)) = 3 * sum(Dim_BI $ (z_HDE(Dim_BI) >= 1 and z_isozyme_rxn_enz(reactions, Dim_BI)), 1),
                           vf.fx(reactions) $ (z_isozyme_rxn(reactions)) = 0;
                           vb.fx(reactions) $ (z_isozyme_rxn(reactions)) = 0;);

*---- The reaction is down/up, (set to down firstly) if one of the isozymes is down/up --------------------------------------------------------------
                        if(sum(Dim_BI $ (z_HDE(Dim_BI) >= 1), z_HDE_tmp(reactions, Dim_BI)) < 3 * sum(Dim_BI $ (z_HDE(Dim_BI) >= 1 and z_isozyme_rxn_enz(reactions, Dim_BI)), 1),
                           vf.lo(reactions) $ (z_isozyme_rxn(reactions)) = FluxBound_vf_LB(reactions);
                           vf.up(reactions) $ (z_isozyme_rxn(reactions)) = basal_vf(reactions) + TR_Reg_factor(NP) *
                                                                          (FluxBound_vf_LB(reactions) - basal_vf(reactions));
                           vb.lo(reactions) $ (z_isozyme_rxn(reactions)) = basal_vb(reactions) + TR_Reg_factor(NP) *
                                                                          (FluxBound_vb_UB(reactions) - basal_vb(reactions));
                           vb.up(reactions) $ (z_isozyme_rxn(reactions)) = FluxBound_vb_UB(reactions););

*---- The above reaction is reassigned to up, if one of the isozymes is up --------------------------------------------------------------------------
                        loop(Dim_BI $ (z_HDE(Dim_BI) >= 1 and z_HDE_tmp(reactions, Dim_BI) = 1 and z_isozyme_rxn(reactions)),
                             vf.lo(reactions) = basal_vf(reactions) + TR_Reg_factor(NP) * (FluxBound_vf_UB(reactions) - basal_vf(reactions));
                             vf.up(reactions) = FluxBound_vf_UB(reactions);
                             vb.lo(reactions) = FluxBound_vb_LB(reactions);
                             vb.up(reactions) = basal_vb(reactions) + TR_Reg_factor(NP) * (FluxBound_vb_LB(reactions) - basal_vb(reactions));
                             break $ (z_HDE_tmp(reactions, Dim_BI) = 1););
                   );
               );
              
*----------------------------------------------------------------------------------------------------------------------------------------------------
*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

* assign vb = 0 for the irreversible fluxes
               vb.lo(irrev_rxn) = 0;
               vb.up(irrev_rxn) = 0;
               vb.fx(irrev_rxn) = 0;
               vb.fx(DM_sink_rxn(reactions)) $ (flag_DM_sink = 1) = 0;
               vf.lo(irrev_vb_rxn(reactions)) = 0;
               vf.up(irrev_vb_rxn(reactions)) = 0;
               vf.fx(irrev_vb_rxn(reactions)) = 0;

* assign the demanded uptake/secretion reactions
               vf.fx(uptake_demand) = 0;
               vb.fx(secretion_demand) = 0;
               vb.fx(uptake_fixed) = FluxBound_vb_LB(uptake_fixed);

* irreversible uptake_rxn and secretion_rxn
               vf.fx(uptake_rxn(reactions)) $ (flag_uptake = 1 and not dyn_Reg_ExRxn(reactions)) = 0;
               vb.fx(secretion_rxn(reactions)) $ (flag_secretion = 1 and not dyn_Reg_ExRxn(reactions)) = 0;
               vf.fx(uptake_demand(reactions)) $ (card(uptake_demand) > 0) = 0;
               vb.fx(secretion_demand(reactions)) $ (card(secretion_demand) > 0) = 0;
********************************************************************************

*** Assign vf > 0 and vb = 0 for the Specific_rxn_vf --------------------------------
               if(card(PH_Specific_rxn_vf) > 0,
                  vf.lo(PH_Specific_rxn_vf) =  PH_Specific_rxn_vf_LB(PH_Specific_rxn_vf);
                  vf.up(PH_Specific_rxn_vf) =  PH_Specific_rxn_vf_UB(PH_Specific_rxn_vf);
                  vb.lo(PH_Specific_rxn_vf) =  0;
                  vb.up(PH_Specific_rxn_vf) =  0;
                  vb.fx(PH_Specific_rxn_vf) =  0;);
********************************************************************************
*** Assign vf = 0 and vb > 0 for the Specific_rxn_vb --------------------------------
               if(card(PH_Specific_rxn_vb) > 0,
                  vb.lo(PH_Specific_rxn_vb) =  PH_Specific_rxn_vb_LB(PH_Specific_rxn_vb);
                  vb.up(PH_Specific_rxn_vb) =  PH_Specific_rxn_vb_UB(PH_Specific_rxn_vb);
                  vf.lo(PH_Specific_rxn_vb) =  0;
                  vf.up(PH_Specific_rxn_vb) =  0;
                  vf.fx(PH_Specific_rxn_vb) =  0;);
*** Assign vf > 0 and vb > 0 for the Specific_rxn_vfvb -------------------------------
               if(card(PH_Specific_rxn_vfvb) > 0,
                  vf.lo(PH_Specific_rxn_vfvb) =  PH_Specific_rxn_vf_LB(PH_Specific_rxn_vfvb);
                  vf.up(PH_Specific_rxn_vfvb) =  PH_Specific_rxn_vf_UB(PH_Specific_rxn_vfvb);
                  vb.lo(PH_Specific_rxn_vfvb) =  PH_Specific_rxn_vb_LB(PH_Specific_rxn_vfvb);
                  vb.up(PH_Specific_rxn_vfvb) =  PH_Specific_rxn_vb_UB(PH_Specific_rxn_vfvb););    
******************************************************************************* 

*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
*----- compute the lower and upper bounds for the target reactions
               target_limit_LB(targetSet) = 0;
               target_limit_UB(targetSet) = 0;
               target_limit_LB(targetSet) = HT_target_level_LB(targetSet);
               target_limit_UB(targetSet) = HT_target_level_UB(targetSet);
               MultiObjValue_FBA.lo(ObjectSet) = MultiObjValue_min(objectSet);
               MultiObjValue_FBA.up(ObjectSet) = MultiObjValue_max(objectSet);
               mem_objvalue_FBA.lo(objectSet) = 0;
               mem_objvalue_FBA.up(objectSet) = 1;
               PH_MultiObjvalue_Optim(ObjectSet) = 0;
               Lambda.lo = 0;
               Lambda.up = 1;               
*-------------------------------------------------------------------------------
* set weightin factor for mem_objvalue_FBA for HT ------------------------------
               Weight_Lambda(ObjectSet) = 0;
               Weight_Lambda(ObjectSet) = PH_Weight_mem_obj_FBA(ObjectSet);
*-------------------------------------------------------------------------------
*---- solve mutant FBA problem considering side effect -------------------------
               solve FBA_Problem using LP maximizing objValue_FBA ;
               nfeval_FBA_max = nfeval_FBA_max + 1;
               nfeval = nfeval + 1;
               tmp_vf_FBA(reactions) = 0;
               tmp_vb_FBA(reactions) = 0;
               tmp_vf_FBA(dyn_reactions) = max(vf.l(dyn_reactions), 0);
               tmp_vb_FBA(dyn_reactions) = max(vb.l(dyn_reactions), 0);
               tmp_MultiObjvalue_Optim(Objectset) = 0;
               tmp_MultiObjvalue_Optim(dyn_objectset) = sum(dyn_reactions, coef_CellularObj_vf(dyn_objectset, dyn_reactions) * tmp_vf_FBA(dyn_reactions)) +
                                                        sum(dyn_reactions, coef_CellularObj_vb(dyn_objectset, dyn_reactions) * tmp_vb_FBA(dyn_reactions));               
               PH_MultiObjvalue_Optim(dyn_objectset) = tmp_MultiObjvalue_Optim(dyn_objectset);

*---- infeasible solution ------------------------------------------------------
               if(FBA_Problem.modelstat > 2,
                  ui_FMObj_inner_TR(NP, ObjectSet) $ (ui_modelstat_UFD(NP) > 2) = 0;
                  ui_FMObj_inner_PH(NP, ObjectSet) = 0;
                  ui_FMObj_outer_TR(NP, ObjectSet) $ (ui_modelstat_UFD(NP) > 2) = 0;
                  ui_FMObj_outer_PH(NP, ObjectSet) = 0;  
                  ui_mem_CV_TR(NP) $ (ui_modelstat_UFD(NP) > 2) = 0;
                  ui_mem_Met_Exp_PHHT(NP) = 0;
                  ui_mem_CV_PH(NP) = 0;
                  ui_mem_MD_TP(NP) = 0;
                  ui_mem_Met_PHHT(NP) = 0;
                  ui_mem_rxn_PHHT(NP) = 0;
                  ui_mem_Met_PHCA(NP) = 0;
                  ui_mem_rxn_PHCA(NP) = 0;
                  ui_mem_Met_TRCA(NP) = 0;
                  ui_mem_rxn_TRCA(NP) = 0;                  
                  ui_mem_Met_TRHT(NP) $ (ui_modelstat_UFD(NP) > 2) = 0;
                  ui_mem_rxn_TRHT(NP) $ (ui_modelstat_UFD(NP) > 2) = 0;
                  constraint_h(Dim_h) = 0;
                  constraint_h(Dim_h) = sum(reactions, S_Matrix(Dim_h, reactions) * (vf.l(reactions) - vb.l(reactions)));
                  tmp_constraint_h = sum(dyn_Fmin_Object, mem_objvalue_FBA.l(dyn_Fmin_Object) -
                                        (MultiObjValue_max(dyn_Fmin_Object) - PH_MultiObjvalue_Optim(dyn_Fmin_Object))/
                                        (MultiObjValue_max(dyn_Fmin_Object) - MultiObjValue_min(dyn_Fmin_Object))) +
                                     sum(dyn_Fmax_Object, mem_objvalue_FBA.l(dyn_Fmax_Object) -
                                        (PH_MultiObjvalue_Optim(dyn_Fmax_Object) - MultiObjValue_min(dyn_Fmax_Object))/
                                        (MultiObjValue_max(dyn_Fmax_Object) - MultiObjValue_min(dyn_Fmax_Object)));                              
                  constraint_g = sum(targetSet, max((target_limit_LB(targetSet) - (vf.l(targetSet) - vb.l(targetSet))), 0)) +
                                 sum(targetSet, max(((vf.l(targetSet) - vb.l(targetSet)) - target_limit_UB(targetSet)), 0)) +
                                 sum(dyn_ObjectSet, max((Lambda.l - mem_objvalue_FBA.l(dyn_ObjectSet)), 0));   
                  constraint_FBA_PH = penalty * (sum(Dim_h, abs(constraint_h(Dim_h)) + abs(tmp_constraint_h)) + constraint_g););
*-------------------------------------------------------------------------------  
       
**** mutant UFD problem considering side effect ********************************
               if(FBA_Problem.modelstat <= 2, 
                  ui_FMObj_inner_PH(NP, dyn_ObjectSet) = PH_MultiObjvalue_Optim(dyn_objectset);
                  Mem_Obj_FBA_limit(ObjectSet) = 0;
                  Mem_Obj_FBA_limit(dyn_Fmax_Object) = ((PH_MultiObjvalue_Optim(dyn_Fmax_Object) - MultiObjValue_min(dyn_Fmax_Object))/
                                                        (MultiObjValue_max(dyn_Fmax_Object) - MultiObjValue_min(dyn_Fmax_Object)));
                  Mem_Obj_FBA_limit(dyn_Fmin_Object) = ((MultiObjValue_max(dyn_Fmin_Object) - PH_MultiObjvalue_Optim(dyn_Fmin_Object))/
                                                        (MultiObjValue_max(dyn_Fmin_Object) - MultiObjValue_min(dyn_Fmin_Object)));
                  Mem_Obj_FBA_limit(dyn_obj_outer) = max(min( Mem_Obj_FBA_limit(dyn_obj_outer), 1), 0);                                     

** assign weighting coefficients for Rxn for computing ObjValue in UFD ****************************************************************************
                  weight_coef_rxn(reactions) = Weight_factor_Rxn_OT;
                  weight_coef_rxn(reactions) $ (HT_Reactions_HC(reactions)) = Weight_factor_Rxn_HC;
                  weight_coef_rxn(reactions) $ (HT_Reactions_MC(reactions)) = Weight_factor_Rxn_MC;
                  weight_coef_rxn(reactions) $ (HT_Reactions_NC(reactions)) = Weight_factor_Rxn_NC;
*****************************************************************************************************************************************************
*----- compute the lower and upper bounds for the target reactions ------------
                  target_limit_LB(targetSet) = 0;
                  target_limit_UB(targetSet) = 0;
                  target_limit_LB(targetSet) = HT_target_level_LB(targetSet);
                  target_limit_UB(targetSet) = HT_target_level_UB(targetSet);
                  MultiObjValue_FBA.lo(ObjectSet) = MultiObjValue_min(objectSet);
                  MultiObjValue_FBA.up(ObjectSet) = MultiObjValue_max(objectSet);
                  mem_objvalue_FBA.lo(objectSet) = 0;
                  mem_objvalue_FBA.up(objectSet) = 1;
*------------------------------------------------------------------------------
              
                  PH_vf_UFD(reactions) = 0;
                  PH_vb_UFD(reactions) = 0;
                  if(flag_UFD_Obj = 1, solve UFD1_Problem using LP minimizing ObjValue_UFD;);
                  if(flag_UFD_Obj = 2, solve UFD2_Problem using LP minimizing ObjValue_UFD;);
                  if(flag_UFD_Obj = 3, solve UFD3_Problem using QCP minimizing ObjValue_UFD;);
                  if(flag_UFD_Obj = 4, solve UFD4_Problem using QCP minimizing ObjValue_UFD;);
                  nfeval_UFD_min = nfeval_UFD_min + 1;
                  nfeval = nfeval + 1;);

*---- infeasible solution ------------------------------------------------------
               if(UFD%No_UFD_Obj%_Problem.modelstat > 2,
                  ui_FMObj_inner_TR(NP, ObjectSet) $ (ui_modelstat_UFD(NP) > 2) = 0;
                  ui_FMObj_inner_PH(NP, ObjectSet) = 0;
                  ui_FMObj_outer_TR(NP, ObjectSet) $ (ui_modelstat_UFD(NP) > 2) = 0;
                  ui_FMObj_outer_PH(NP, ObjectSet) = 0;  
                  ui_mem_CV_TR(NP) $ (ui_modelstat_UFD(NP) > 2) = 0;
                  ui_mem_Met_Exp_PHHT(NP) = 0;
                  ui_mem_CV_PH(NP) = 0;
                  ui_mem_MD_TP(NP) = 0;
                  ui_mem_Met_PHHT(NP) = 0;
                  ui_mem_rxn_PHHT(NP) = 0;
                  ui_mem_Met_PHCA(NP) = 0;
                  ui_mem_rxn_PHCA(NP) = 0;
                  ui_mem_Met_TRCA(NP) = 0;
                  ui_mem_rxn_TRCA(NP) = 0;                  
                  ui_mem_Met_TRHT(NP) $ (ui_modelstat_UFD(NP) > 2) = 0;
                  ui_mem_rxn_TRHT(NP) $ (ui_modelstat_UFD(NP) > 2) = 0;
                  constraint_h(Dim_h) = 0;
                  constraint_h(Dim_h) = sum(reactions, S_Matrix(Dim_h, reactions) * (vf.l(reactions) - vb.l(reactions)));
                  tmp_constraint_h = sum(dyn_Fmin_Object, mem_objvalue_FBA.l(dyn_Fmin_Object) -
                                        (MultiObjValue_max(dyn_Fmin_Object) - MultiObjValue_FBA.l(dyn_Fmin_Object))/
                                        (MultiObjValue_max(dyn_Fmin_Object) - MultiObjValue_min(dyn_Fmin_Object))) +
                                     sum(dyn_Fmax_Object, mem_objvalue_FBA.l(dyn_Fmax_Object) -
                                        (MultiObjValue_FBA.l(dyn_Fmax_Object) - MultiObjValue_min(dyn_Fmax_Object))/
                                        (MultiObjValue_max(dyn_Fmax_Object) - MultiObjValue_min(dyn_Fmax_Object)));                             
                  constraint_g = sum(targetSet, max((target_limit_LB(targetSet) - (vf.l(targetSet) - vb.l(targetSet))), 0)) +
                                 sum(targetSet, max(((vf.l(targetSet) - vb.l(targetSet)) - target_limit_UB(targetSet)), 0)) +
                                 sum(dyn_ObjectSet, max((Lambda.l - mem_objvalue_FBA.l(dyn_ObjectSet)), 0));   
                  constraint_UFD_PH = penalty * (sum(Dim_h, abs(constraint_h(Dim_h)) + abs(tmp_constraint_h)) + constraint_g););
*-------------------------------------------------------------------------------   
                          
*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%              
               if(FBA_Problem.modelstat <= 2 and UFD%No_UFD_Obj%_Problem.modelstat <= 2,
* compute synthesis rate and degradation rate for each BioCompound at the mutant state
                  PH_vf_UFD(reactions) = max(vf.l(reactions), 0);
                  PH_vb_UFD(reactions) = max(vb.l(reactions), 0);
                  PH_v_UFD(reactions) = PH_vf_UFD(reactions) - PH_vb_UFD(reactions);                

**** compute membership grades of fuzzy max and min objectives for outer PH model *******************************************************************
                  PH_MultiObjvalue_Optim(Objectset) = 0;
                  PH_MultiObjvalue_Optim(dyn_obj_outer) = sum(dyn_reactions, coef_CellularObj_vf(dyn_obj_outer, dyn_reactions) * PH_vf_UFD(dyn_reactions)) +
                                                          sum(dyn_reactions, coef_CellularObj_vb(dyn_obj_outer, dyn_reactions) * PH_vb_UFD(dyn_reactions));  
                  ui_FMObj_outer_PH(NP, dyn_obj_outer) = PH_MultiObjvalue_Optim(dyn_obj_outer);
           
**** compute membership grades of fuzzy max and min objectives for outer PH model *******************************************************************
                  Mem_Obj_FBA_limit(ObjectSet) = 0;
                  Mem_Obj_FBA_limit(dyn_Fmax_Obj_outer) = (PH_MultiObjvalue_Optim(dyn_Fmax_Obj_outer) - MultiObjValue_min(dyn_Fmax_Obj_outer))/
                                                          (MultiObjValue_max(dyn_Fmax_Obj_outer) - MultiObjValue_min(dyn_Fmax_Obj_outer));
                  Mem_Obj_FBA_limit(dyn_Fmin_Obj_outer) = (MultiObjValue_max(dyn_Fmin_Obj_outer) - PH_MultiObjvalue_Optim(dyn_Fmin_Obj_outer))/
                                                          (MultiObjValue_max(dyn_Fmin_Obj_outer) - MultiObjValue_min(dyn_Fmin_Obj_outer));
                  Mem_Obj_FBA_limit(dyn_obj_outer) = max(min( Mem_Obj_FBA_limit(dyn_obj_outer), 1), 0);                              
                  mem_PriObj_Outer_PH = sum(dyn_priority_outer, Mem_Obj_FBA_limit(dyn_priority_outer))/No_priority_outer;
                  ui_mem_CV_PH(NP) = 0.5 * (mem_PriObj_Outer_PH + smin(dyn_obj_outer, Mem_Obj_FBA_limit(dyn_obj_outer)));
*****************************************************************************************************************************************************

*=== compute synthesis rate for each species of treated PH model ====================================================================================
                  PH_Species_SynRate(species) = 0;
                  loop(dyn_species,
                       PH_Species_SynRate(dyn_species) = sum(dyn_reactions, S_Matrix(dyn_species, dyn_reactions) $
                                                            (S_Matrix(dyn_species, dyn_reactions) > 0) * PH_vf_UFD(dyn_reactions))
                                                       - sum(dyn_reactions, S_Matrix(dyn_Species, dyn_reactions) $
                                                            (S_Matrix(dyn_species, dyn_reactions) < 0) * PH_vb_UFD(dyn_reactions)););

***** compute synthesis rate for each biocompound of treated PH model *******************************************************************************
                  PH_BioComp_SynRate(BioCompound) = 0;
                  loop(dyn_BioComp,
                       PH_BioComp_SynRate(dyn_BioComp) = sum(dyn_Species $ (BioCompound_species(dyn_BioComp, dyn_Species)),
                                                             PH_Species_SynRate(dyn_Species)););       
*****************************************************************************************************************************************************

***** compute fuzzy dissimilarity of metabolite-flow and its membership grade for PHCA model *********************************************************
                  L_mem_Met_tmp(biocompound) = 0;
                  R_mem_Met_tmp(biocompound) = 0;
                  mem_Met_tmp(biocompound) = 0;             
                  L_mem_Met_tmp(BioComp_PHCA) $ (CA_BioComp_SynRate(BioComp_PHCA) > 0) =
                                                (CA_BioComp_SynRate(BioComp_PHCA) - PH_BioComp_SynRate(BioComp_PHCA))/
                                                (CA_BioComp_SynRate(BioComp_PHCA) - CA_MetFlowRate_LB(BioComp_PHCA));
                  L_mem_Met_tmp(BioComp_PHCA) $ (CA_BioComp_SynRate(BioComp_PHCA) = 0) = 0;
              
                  R_mem_Met_tmp(BioComp_PHCA) = (PH_BioComp_SynRate(BioComp_PHCA) - CA_BioComp_SynRate(BioComp_PHCA))/
                                                (CA_MetFlowRate_UB(BioComp_PHCA) - CA_BioComp_SynRate(BioComp_PHCA));
                  mem_Met_tmp(BioComp_PHCA) = min(max(L_mem_Met_tmp(BioComp_PHCA), R_mem_Met_tmp(BioComp_PHCA), 0), 1);  

                  nonzero_Biocomp(biocompound) = no;             
                  nonzero_Biocomp(biocompound) $ ((PH_BioComp_SynRate(biocompound) > 0 or
                                                   CA_BioComp_SynRate(biocompound) > 0) and BioComp_PHCA(biocompound)) = yes;

                  No_nonzero_Biocomp_PHCA = card(nonzero_Biocomp);                                               
                  ui_mem_Met_PHCA(NP) = sum(BioCompound $ (nonzero_Biocomp(biocompound)), mem_Met_tmp(BioCompound))/No_nonzero_Biocomp_PHCA;

***** compute fuzzy dissimilarity of flux and its membership grade for PHCA model *******************************************************************                                             
                  L_mem_vf_tmp(reactions) = 0;
                  R_mem_vf_tmp(reactions) = 0;
                  L_mem_vb_tmp(reactions) = 0;
                  R_mem_vb_tmp(reactions) = 0;
                  L_mem_vf_tmp(rxn_vf_PHCA) $ (CA_vf_UFD(rxn_vf_PHCA) > 0) = (CA_vf_UFD(rxn_vf_PHCA) - PH_vf_UFD(rxn_vf_PHCA))/
                                                                            (CA_vf_UFD(rxn_vf_PHCA) - CA_vf_rxn_LB(rxn_vf_PHCA));
                  L_mem_vf_tmp(rxn_vf_PHCA) $ (CA_vf_UFD(rxn_vf_PHCA) = 0) = 0;           
                  R_mem_vf_tmp(rxn_vf_PHCA) = (PH_vf_UFD(rxn_vf_PHCA) - CA_vf_UFD(rxn_vf_PHCA))/
                                              (CA_vf_rxn_UB(rxn_vf_PHCA)- CA_vf_UFD(rxn_vf_PHCA));                                       
                  L_mem_vb_tmp(rxn_vb_PHCA) $ (CA_vb_UFD(rxn_vb_PHCA) > 0) = (CA_vb_UFD(rxn_vb_PHCA) - PH_vb_UFD(rxn_vb_PHCA))/
                                                                             (CA_vb_UFD(rxn_vb_PHCA) - CA_vb_rxn_LB(rxn_vb_PHCA));
                  L_mem_vb_tmp(rxn_vb_PHCA) $ (CA_vb_UFD(rxn_vb_PHCA) = 0) = 0;                                     
                  R_mem_vb_tmp(rxn_vb_PHCA) = (PH_vb_UFD(rxn_vb_PHCA) - CA_vb_UFD(rxn_vb_PHCA))/
                                              (CA_vb_rxn_UB(rxn_vb_PHCA)- CA_vb_UFD(rxn_vb_PHCA));

**** intialization
                  mem_vf_tmp(reactions) = 0;
                  mem_vb_tmp(reactions) = 0;               
                  mem_vf_tmp(rxn_vf_PHCA) = min(max(L_mem_vf_tmp(rxn_vf_PHCA), R_mem_vf_tmp(rxn_vf_PHCA), 0), 1);
                  mem_vb_tmp(rxn_vb_PHCA) = min(max(L_mem_vb_tmp(rxn_vb_PHCA), R_mem_vb_tmp(rxn_vb_PHCA), 0), 1);

                  nonzero_vf(reactions) = no;
                  nonzero_vf(reactions) $ ((PH_vf_UFD(reactions) > 0 or
                                            CA_vf_UFD(reactions) > 0) and rxn_vf_PHCA(reactions)) = yes;
                  nonzero_vb(reactions) = no;
                  nonzero_vb(reactions) $ ((PH_vb_UFD(reactions) > 0 or
                                            CA_vb_UFD(reactions) > 0) and rxn_vb_PHCA(reactions)) = yes;                                         
                  nonzero_v(reactions) = no;                               
                  nonzero_v(reactions) =  nonzero_vf(reactions) + nonzero_vb(reactions);
                  No_nonzero_vf_PHCA = card(nonzero_vf);
                  No_nonzero_vb_PHCA = card(nonzero_vb);              
                  No_nonzero_v_PHCA = card(nonzero_v);
                  ui_mem_rxn_PHCA(NP) = sum(reactions $ (nonzero_v(reactions)),             
                                            max(mem_vf_tmp(reactions),mem_vb_tmp(reactions)))/No_nonzero_v_PHCA;  
*====================================================================================================================================================

*==== compute fuzzy similarity of metabolite-flow and its membership grade for PHHT model ===========================================================
*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

***** compute fuzzy similarity of Warburg and experiments for PHHT model        
                 L_mem_Met_Exp(BioCompound) = 0;
                 R_mem_Met_Exp(BioCompound) = 0;
                 mem_Met_Exp(BioCompound) = 0;
                 L_mem_Met_Exp(BioComp_ExpWarb) $ (HT_BioComp_SynRate(BioComp_ExpWarb) > 0) =
                                                  (PH_BioComp_SynRate(BioComp_ExpWarb) - HT_MetFlowRate_LB(BioComp_ExpWarb))/
                                                  (HT_BioComp_SynRate(BioComp_ExpWarb) - HT_MetFlowRate_LB(BioComp_ExpWarb));
                 L_mem_Met_Exp(BioComp_ExpWarb) $ (HT_BioComp_SynRate(BioComp_ExpWarb) = 0) = 1;

                 R_mem_Met_Exp(BioComp_ExpWarb) = (HT_MetFlowRate_UB(BioComp_ExpWarb) - PH_BioComp_SynRate(BioComp_ExpWarb))/
                                                  (HT_MetFlowRate_UB(BioComp_ExpWarb) - HT_BioComp_SynRate(BioComp_ExpWarb));
                 mem_Met_Exp(BioComp_ExpWarb) = max(min(L_mem_Met_Exp(BioComp_ExpWarb), R_mem_Met_Exp(BioComp_ExpWarb), 1), 0);

                 ui_mem_Met_Exp_PHHT(NP) = sum(BioComp_ExpWarb, mem_Met_Exp(BioComp_ExpWarb))/card(BioComp_ExpWarb);

*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
***** compute fuzzy similarity of metabolite flow rates for biocompounds of PHHT model **********************************************************************
                 L_mem_Met_tmp(biocompound) = 0;
                 R_mem_Met_tmp(biocompound) = 0;
                 mem_Met_tmp(biocompound) = 0;             
                 L_mem_Met_tmp(BioComp_PHHT) $ (HT_BioComp_SynRate(BioComp_PHHT) > 0) =
                                               (PH_BioComp_SynRate(BioComp_PHHT) - HT_MetFlowRate_LB(BioComp_PHHT))/
                                               (HT_BioComp_SynRate(BioComp_PHHT) - HT_MetFlowRate_LB(BioComp_PHHT)); 
                 L_mem_Met_tmp(BioComp_PHHT) $ (HT_BioComp_SynRate(BioComp_PHHT) = 0) = 1;

                 R_mem_Met_tmp(BioComp_PHHT) = (HT_MetFlowRate_UB(BioComp_PHHT) - PH_BioComp_SynRate(BioComp_PHHT))/
                                               (HT_MetFlowRate_UB(BioComp_PHHT) - HT_BioComp_SynRate(BioComp_PHHT));  
                 mem_Met_tmp(BioComp_PHHT) = max(min(L_mem_Met_tmp(BioComp_PHHT), R_mem_Met_tmp(BioComp_PHHT), 1), 0); 

                 nonzero_Biocomp(biocompound) = no;             
                 nonzero_Biocomp(biocompound) $ ((PH_BioComp_SynRate(biocompound) > 0 or
                                                  HT_BioComp_SynRate(biocompound) > 0) and BioComp_PHHT(biocompound)) = yes;
                 No_nonzero_Biocomp_PHHT = card(nonzero_Biocomp);                                               
                 ui_mem_Met_PHHT(NP) = sum(BioCompound $ (nonzero_Biocomp(biocompound)), mem_Met_tmp(BioCompound))/No_nonzero_Biocomp_PHHT;

*****************************************************************************************************************************************************
***** compute fuzzy similarity of flux and its membership grade for PHHT model **********************************************************************
                 L_mem_vf_tmp(reactions) = 0;
                 R_mem_vf_tmp(reactions) = 0;
                 L_mem_vb_tmp(reactions) = 0;
                 R_mem_vb_tmp(reactions) = 0;
                 L_mem_vf_tmp(rxn_vf_PHHT) $ (HT_vf_UFD(rxn_vf_PHHT) > 0) =
                                             (PH_vf_UFD(rxn_vf_PHHT) - HT_vf_rxn_LB(rxn_vf_PHHT))/
                                             (HT_vf_UFD(rxn_vf_PHHT) - HT_vf_rxn_LB(rxn_vf_PHHT));
                 L_mem_vf_tmp(rxn_vf_PHHT) $ (HT_vf_UFD(rxn_vf_PHHT) = 0) = 1;
                 R_mem_vf_tmp(rxn_vf_PHHT) = (HT_vf_rxn_UB(rxn_vf_PHHT) - PH_vf_UFD(rxn_vf_PHHT))/
                                             (HT_vf_rxn_UB(rxn_vf_PHHT)- HT_vf_UFD(rxn_vf_PHHT));                                          
                 L_mem_vb_tmp(rxn_vb_PHHT) $ (HT_vb_UFD(rxn_vb_PHHT) > 0) =
                                             (PH_vb_UFD(rxn_vb_PHHT) - HT_vb_rxn_LB(rxn_vb_PHHT))/
                                             (HT_vb_UFD(rxn_vb_PHHT) - HT_vb_rxn_LB(rxn_vb_PHHT));
                 L_mem_vb_tmp(rxn_vb_PHHT) $ (HT_vb_UFD(rxn_vb_PHHT) = 0) = 1;
                 R_mem_vb_tmp(rxn_vb_PHHT) = (HT_vb_rxn_UB(rxn_vb_PHHT) - PH_vb_UFD(rxn_vb_PHHT))/
                                             (HT_vb_rxn_UB(rxn_vb_PHHT)- HT_vb_UFD(rxn_vb_PHHT)); 

**** intialization
                 mem_vf_tmp(reactions) = 0;
                 mem_vb_tmp(reactions) = 0; 
                 mem_vf_tmp(rxn_vf_PHHT) = max(min(L_mem_vf_tmp(rxn_vf_PHHT), R_mem_vf_tmp(rxn_vf_PHHT), 1), 0);
                 mem_vb_tmp(rxn_vb_PHHT) = max(min(L_mem_vb_tmp(rxn_vb_PHHT), R_mem_vb_tmp(rxn_vb_PHHT), 1), 0);

                 nonzero_vf(reactions) = no;
                 nonzero_vf(reactions) $ ((PH_vf_UFD(reactions) > 0 or
                                           HT_vf_UFD(reactions) > 0) and rxn_vf_PHHT(reactions)) = yes;
                 nonzero_vb(reactions) = no;
                 nonzero_vb(reactions) $ ((PH_vb_UFD(reactions) > 0 or
                                           HT_vb_UFD(reactions) > 0) and rxn_vb_PHHT(reactions)) = yes;                                          
                 nonzero_v(reactions) = no;                               
                 nonzero_v(reactions) =  nonzero_vf(reactions) + nonzero_vb(reactions);
                 No_nonzero_vf_PHHT = card(nonzero_vf);
                 No_nonzero_vb_PHHT = card(nonzero_vb);              
                 No_nonzero_v_PHHT = card(nonzero_v);
                 ui_mem_rxn_PHHT(NP) = sum(reactions $ (nonzero_v(reactions)),             
                                           min(mem_vf_tmp(reactions),mem_vb_tmp(reactions)))/No_nonzero_v_PHHT;           
*====================================================================================================================================================
                 constraint_FBA_PH = 0;
                 constraint_UFD_PH = 0;
              );
          );
      );    
*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
*----- fitness evaluation ------------------------------------------------------
* Metabolic deviation (dissimilarity) for PH model to CA template
ui_mem_MD_PHCA(NP) = ((ui_mem_rxn_PHCA(NP) + ui_mem_Met_PHCA(NP))/2 + min(ui_mem_rxn_PHCA(NP), ui_mem_Met_PHCA(NP)))/2;

* Metabolic deviation (similarity) for PH model to HT template
ui_mem_MD_PHHT(NP) = ((ui_mem_rxn_PHHT(NP) + ui_mem_Met_PHHT(NP))/2 + min(ui_mem_rxn_PHHT(NP), ui_mem_Met_PHHT(NP)))/2;

* Metabolic deviation (similarity) for TR model to HT template
ui_mem_MD_TRHT(NP) = ((ui_mem_rxn_TRHT(NP) + ui_mem_Met_TRHT(NP))/2 + min(ui_mem_rxn_TRHT(NP), ui_mem_Met_TRHT(NP)))/2;

* Metabolic deviation (dissimilarity) for TR model to CA template
ui_mem_MD_TRCA(NP) = ((ui_mem_rxn_TRCA(NP) + ui_mem_Met_TRCA(NP))/2 + min(ui_mem_rxn_TRCA(NP), ui_mem_Met_TRCA(NP)))/2;

* Metabolic deviation of fuzzy dissimilarity and similarity for PHCA, TRCA TRHT, and PHHT
ui_mem_MD_TP(NP) $ (index_sumz = 1 or index_sumz = 21 or index_sumz = 22) = ((ui_mem_MD_PHCA(NP) + ui_mem_MD_PHHT(NP))/2 +
                                                                               min(ui_mem_MD_PHCA(NP), ui_mem_MD_PHHT(NP)))/2;

ui_mem_MD_TP(NP) $ (index_sumz = 41 or index_sumz = 42) = ((ui_mem_MD_PHCA(NP) + ui_mem_MD_PHHT(NP) + ui_mem_MD_TRHT(NP) + ui_mem_MD_TRCA(NP))/4 +
                                                            min(ui_mem_MD_PHCA(NP), ui_mem_MD_PHHT(NP), ui_mem_MD_TRHT(NP), ui_mem_MD_TRCA(NP)))/2;

* Metabolic deviation of fuzzy similarity for TRHT, and PHHT
ui_mem_MD_TP(NP) $ (index_sumz = 23 or index_sumz = 24) = ((ui_mem_MD_TRHT(NP) + ui_mem_MD_PHHT(NP))/2 +
                                                             min(ui_mem_MD_TRHT(NP), ui_mem_MD_PHHT(NP)))/2;

*----- prioity fitness evaluation ----------------------------------------------
ui_constraint(NP) = constraint_FBA_TR + constraint_UFD_TR + constraint_FBA_PH + constraint_UFD_PH;
ui_fitness(NP) $ (index_sumZ = 1) = mem_PriObj_Outer_TR;
ui_fitness(NP) $ (index_sumZ = 21 or index_sumZ = 23 or index_sumz = 41) = (ui_mem_CV_TR(NP) +
                                                                             min(ui_mem_CV_TR(NP), ui_mem_CV_PH(NP), ui_mem_MD_TP(NP)))/2;
ui_fitness(NP) $ (index_sumZ = 22 or index_sumZ = 24 or index_sumz = 42) = ((ui_mem_CV_TR(NP) + ui_mem_CV_PH(NP))/2 +
                                                                             min(ui_mem_CV_TR(NP), ui_mem_CV_PH(NP), ui_mem_MD_TP(NP)))/2;
ui_fitness(NP) = ui_fitness(NP) - ui_constraint(NP);                                                                             
ui_fitness(NP) $ (flag_sumZ = 1) = ui_fitness(NP) + ui_mem_sumZ(NP););
*-------------------------------------------------------------------------------
*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

*---- selection operation ------------------------------------------------------
*---- compete pop_fitness(NP) with ui_pop(NP) ----------------------------------
    loop(NP $ (ui_fitness(NP) > pop_fitness(NP)),
         pop_FMObj_inner_TR(NP, objectSet) = 0;
         pop_FMObj_inner_PH(NP, objectSet) = 0;
         pop_FMObj_outer_TR(NP, objectSet) = 0;
         pop_FMObj_outer_PH(NP, objectSet) = 0;
         pop_XB(NP, Dim_BI) = 0;
         pop_XI(NP, Dim_XIR) = 0;     
         pop_FMObj_inner_TR(NP, objectSet) = ui_FMObj_inner_TR(NP, objectSet);
         pop_FMObj_inner_PH(NP, objectSet) = ui_FMObj_inner_PH(NP, objectSet);
         pop_FMObj_outer_TR(NP, objectSet) = ui_FMObj_outer_TR(NP, objectSet);
         pop_FMObj_outer_PH(NP, objectSet) = ui_FMObj_outer_PH(NP, objectSet);       
         pop_XB(NP, Dim_BI) = ui_XB(NP, Dim_BI);
         pop_XI(NP, Dim_XIR) = ui_XI(NP, Dim_XIR);    
         pop_Mem_sumZ(NP) = ui_Mem_sumZ(NP);
         pop_modelstat_UFD(NP) = ui_modelstat_UFD(NP);
         pop_constraint(NP) = ui_constraint(NP);         
         pop_fitness(NP) = ui_fitness(NP);
         pop_mem_Met_Exp_PHHT(NP) = ui_mem_Met_Exp_PHHT(NP);         
         pop_mem_CV_TR(NP) = ui_mem_CV_TR(NP);
         pop_mem_CV_PH(NP) = ui_mem_CV_PH(NP);
         pop_mem_MD_TP(NP) = ui_mem_MD_TP(NP);
         pop_mem_MD_PHCA(NP) = ui_mem_MD_PHCA(NP);
         pop_mem_MD_TRCA(NP) = ui_mem_MD_TRCA(NP);         
         pop_mem_MD_PHHT(NP) = ui_mem_MD_PHHT(NP); 
         pop_mem_MD_TRHT(NP) = ui_mem_MD_TRHT(NP); 
         pop_mem_Met_PHHT(NP) = ui_mem_Met_PHHT(NP);
         pop_mem_rxn_PHHT(NP) = ui_mem_rxn_PHHT(NP);
         pop_mem_Met_PHCA(NP) = ui_mem_Met_PHCA(NP);
         pop_mem_rxn_PHCA(NP) = ui_mem_rxn_PHCA(NP);
         pop_mem_Met_TRCA(NP) = ui_mem_Met_TRCA(NP);
         pop_mem_rxn_TRCA(NP) = ui_mem_rxn_TRCA(NP);        
         pop_mem_Met_TRHT(NP) = ui_mem_Met_TRHT(NP);
         pop_mem_rxn_TRHT(NP) = ui_mem_rxn_TRHT(NP);              
);

*---- find the best fitness and individual -------------------------------------
    best_fitness = smax(NP, pop_fitness(NP));
    loop(NP $ (pop_fitness(NP) >= best_fitness),
         best_FMObj_inner_TR(ObjectSet) = 0;
         best_FMObj_inner_PH(ObjectSet) = 0;
         best_FMObj_outer_TR(ObjectSet) = 0;
         best_FMObj_outer_PH(ObjectSet) = 0;
         bestmem_XB(Dim_BI) = 0;
         bestmem_XI(Dim_XIR) = 0;     
         best_FMObj_inner_TR(ObjectSet) = pop_FMObj_inner_TR(NP, objectSet);
         best_FMObj_inner_PH(ObjectSet) = pop_FMObj_inner_PH(NP, objectSet);
         best_FMObj_outer_TR(ObjectSet) = pop_FMObj_outer_TR(NP, objectSet);
         best_FMObj_outer_PH(ObjectSet) = pop_FMObj_outer_PH(NP, objectSet);       
         bestmem_XB(Dim_BI) = pop_XB(NP, Dim_BI);
         bestmem_XI(Dim_XIR) = pop_XI(NP, Dim_XIR);    
         best_Mem_sumZ  = pop_Mem_sumZ(NP);
         best_modelstat = pop_modelstat_UFD(NP);
         best_constraint = pop_constraint(NP);         
         best_fitness = pop_fitness(NP);
         best_mem_Met_Exp_PHHT = pop_mem_Met_Exp_PHHT(NP);         
         best_mem_CV_TR = pop_mem_CV_TR(NP);
         best_mem_CV_PH = pop_mem_CV_PH(NP);
         best_mem_MD_TP = pop_mem_MD_TP(NP);
         best_mem_MD_PHCA = pop_mem_MD_PHCA(NP);
         best_mem_MD_TRCA = pop_mem_MD_TRCA(NP);         
         best_mem_MD_PHHT = pop_mem_MD_PHHT(NP); 
         best_mem_MD_TRHT = pop_mem_MD_TRHT(NP);          
         best_mem_Met_PHHT = pop_mem_Met_PHHT(NP);
         best_mem_rxn_PHHT = pop_mem_rxn_PHHT(NP);
         best_mem_Met_PHCA = pop_mem_Met_PHCA(NP);
         best_mem_rxn_PHCA = pop_mem_rxn_PHCA(NP);
         best_mem_Met_TRCA = pop_mem_Met_TRCA(NP);
         best_mem_rxn_TRCA = pop_mem_rxn_TRCA(NP);         
         best_mem_Met_TRHT = pop_mem_Met_TRHT(NP);
         best_mem_rxn_TRHT = pop_mem_rxn_TRHT(NP);    
    );
*-------------------------------------------------------------------------------

*----- migration operation -----------------------------------------------------
*----- compute gene diversity for integer variables ----------------------------
    if (method_1 >= 1,
        gene_diversity(NP, Dim_BI) = 0;
        gene_diversity_R(NP, Dim_XIR) = 0;
        loop(NP, gene_diversity(NP, Dim_BI) $ ((pop_XB(NP, Dim_BI) - bestmem_XB(Dim_BI)) <> 0) = 1;);
        loop(NP, gene_diversity_R(NP, Dim_XR) $ (abs(pop_XI(NP, Dim_XR) - bestmem_XI(Dim_XR)) > epsilon2 * abs(bestmem_XI(Dim_XR))) = 1;);

        pop_diversity = (sum((NP, Dim_BI), gene_diversity(NP, Dim_BI)) + sum((NP, Dim_XR), gene_diversity_R(NP, Dim_XR)))
                         /((card(Dim_BI) + card(Dim_XR)) * (card(NP) - 1));

        if (pop_diversity <= epsilon1 or index_migration >= method_6,
            restnum = restnum + 1;

*****************************************************************************************************************************************************
*----- the population restart based on the best individual ---------------------
$ontext
            rand_C1(NP, Dim_XIR) = uniform(0, 1);
            pop_XI(NP, Dim_XIR) $ (rand_C1(NP, Dim_XIR) * (XIR_max(Dim_XIR) - XIR_min(Dim_XIR)) < (bestmem_XI(Dim_XIR) - XIR_min(Dim_XIR))) =
                                                                                       uniformInt(XIR_min(Dim_XIR), bestmem_XI(Dim_XIR) - 1);
            pop_XI(NP, Dim_XIR) $ (rand_C1(NP, Dim_XIR) * (XIR_max(Dim_XIR) - XIR_min(Dim_XIR)) >= (bestmem_XI(Dim_XIR) - XIR_min(Dim_XIR))) =
                                                                                       uniformInt(bestmem_XI(Dim_XIR) + 1, XIR_max(Dim_XIR));
$offtext
            rand_C1(NP, Dim_XIR) = uniform(0, 1);
            rand_C2(NP, Dim_XIR) = uniform(0, 1);
            pop_XI(NP, Dim_XIR) $ (rand_C1(NP, Dim_XIR) * (XIR_max(Dim_XIR) - XIR_min(Dim_XIR)) < (bestmem_XI(Dim_XIR) - XIR_min(Dim_XIR))) =
                                   bestmem_XI(Dim_XIR) + rand_C2(NP, Dim_XIR) * (XIR_min(Dim_XIR) - bestmem_XI(Dim_XIR));
            pop_XI(NP, Dim_XIR) $ (rand_C1(NP, Dim_XIR) * (XIR_max(Dim_XIR) - XIR_min(Dim_XIR)) >= (bestmem_XI(Dim_XIR) - XIR_min(Dim_XIR))) =
                                   bestmem_XI(Dim_XIR) + rand_C2(NP, Dim_XIR) * (XIR_max(Dim_XIR) - bestmem_XI(Dim_XIR));
            pop_XI(NP, Dim_XI) = round(pop_XI(NP, Dim_XI));

*----- the population restart using uniformInt ---------------------------------
*            pop_XI(NP, Dim_XIR) = uniformInt(XIR_min(Dim_XIR), XIR_max(Dim_XIR));
*****************************************************************************************************************************************************

*----- decode Candidate_Enz orders to select the regulated reactions -----------
$offorder
           pop_XB(NP, Dim_BI) = 0;
           loop(Dim_XI1, pop_XB(NP, Dim_BI1) $ (ord(Dim_BI1) = pop_XI(NP, Dim_XI1)) = uniformInt(%No_UPDownKO_min_g1%, %No_UPDownKO_max_g1%););
           loop(Dim_XI2, pop_XB(NP, Dim_BI2) $ (ord(Dim_BI2) = pop_XI(NP, Dim_XI2)) = uniformInt(%No_UPDownKO_min_g2%, %No_UPDownKO_max_g2%););
$onorder
*-------------------------------------------------------------------------------

* assign regulation strength parameter for each individual
            TR_Reg_Factor(NP) = pop_XI(NP, "RSP1");

*---- save the best individual -------------------------------------------------
            pop_FMObj_inner_TR('NP1', objectSet) = 0;
            pop_FMObj_inner_PH('NP1', objectSet) = 0;
            pop_FMObj_outer_TR('NP1', objectSet) = 0;
            pop_FMObj_outer_PH('NP1', objectSet) = 0;
            pop_XB('NP1', Dim_BI) = 0;
            pop_XI('NP1', Dim_XIR) = 0;     
            pop_FMObj_inner_TR('NP1', objectSet) = best_FMObj_inner_TR(objectSet);
            pop_FMObj_inner_PH('NP1', objectSet) = best_FMObj_inner_PH(objectSet);
            pop_FMObj_outer_TR('NP1', objectSet) = best_FMObj_outer_TR(objectSet);
            pop_FMObj_outer_PH('NP1', objectSet) = best_FMObj_outer_PH(objectSet);       
            pop_XB('NP1', Dim_BI) = bestmem_XB(Dim_BI);
            pop_XI('NP1', Dim_XIR) = bestmem_XI(Dim_XIR);    
            pop_Mem_sumZ('NP1') = best_Mem_sumZ;
            pop_modelstat_UFD('NP1') = best_modelstat;
            pop_constraint('NP1') = best_constraint;         
            pop_fitness('NP1') = best_fitness;
            pop_mem_Met_Exp_PHHT('NP1') = best_mem_Met_Exp_PHHT;         
            pop_mem_CV_TR('NP1') = best_mem_CV_TR;
            pop_mem_CV_PH('NP1') = best_mem_CV_PH;
            pop_mem_MD_TP('NP1') = best_mem_MD_TP;
            pop_mem_MD_PHCA('NP1') = best_mem_MD_PHCA;
            pop_mem_MD_TRCA('NP1') = best_mem_MD_TRCA;            
            pop_mem_MD_PHHT('NP1') = best_mem_MD_PHHT; 
            pop_mem_MD_TRHT('NP1') = best_mem_MD_TRHT; 
            pop_mem_Met_PHHT('NP1') = best_mem_Met_PHHT;
            pop_mem_rxn_PHHT('NP1') = best_mem_rxn_PHHT;
            pop_mem_Met_PHCA('NP1') = best_mem_Met_PHCA;
            pop_mem_rxn_PHCA('NP1') = best_mem_rxn_PHCA;
            pop_mem_Met_TRCA('NP1') = best_mem_Met_TRCA;
            pop_mem_rxn_TRCA('NP1') = best_mem_rxn_TRCA;            
            pop_mem_Met_TRHT('NP1') = best_mem_Met_TRHT;
            pop_mem_rxn_TRHT('NP1') = best_mem_rxn_TRHT;
         
*-------------------------------------------------------------------------------

*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            loop(NP $ (ord(NP) >= 2),
***** assign reactions and species in FMO CA models as dynamic sets *********************************************************************************   
                 dyn_reactions(reactions) = no;
                 dyn_species(species) = no;
                 dyn_BioComp(biocompound) = no;
                 dyn_irrev_rxn(reactions) = no;
                 dyn_rev_rxn(reactions) = no;
                 dyn_exchange_rxn(reactions) = no;
                 dyn_objectSet(objectSet) = no;
                 dyn_Fmax_Object(ObjectSet) = no;
                 dyn_Fmin_Object(ObjectSet) = no;
                 dyn_priority_obj(ObjectSet) = no;
                 dyn_obj_outer(objectSet) = no;
                 dyn_Fmax_Obj_outer(ObjectSet) = no;
                 dyn_Fmin_Obj_outer(ObjectSet) = no;
                 dyn_priority_outer(ObjectSet) = no;    
**** objectives used in inner optimization problem
                 dyn_reactions(reactions) $ (not reactions_NCA(reactions)) = yes;
                 dyn_species(species) $ (not species_NCA(species)) = yes;
                 dyn_BioComp(biocompound) $ (not biocompound_NCA(biocompound)) = yes;
                 dyn_irrev_rxn(reactions) $ (not reactions_NCA(reactions) and irrev_rxn(reactions)) = yes;
                 dyn_rev_rxn(reactions) $ (not reactions_NCA(reactions) and rev_rxn(reactions)) = yes;
                 dyn_exchange_rxn(reactions) $ (not reactions_NCA(reactions) and exchange_rxn(reactions)) = yes;
                 dyn_Fmax_Object(ObjectSet) $ (FmaxObj_inner_TR(ObjectSet)) = yes;
                 dyn_Fmin_Object(ObjectSet) $ (FminObj_inner_TR(ObjectSet)) = yes;
                 dyn_objectSet(objectSet) = dyn_Fmax_Object(ObjectSet) + dyn_Fmin_Object(ObjectSet);
                 dyn_priority_obj(ObjectSet) $ (PriObj_inner_TR(ObjectSet)) = yes;
                 No_priority_obj = card(PriObj_inner_TR);
**** objectives used in outer optimization problem     
                 dyn_Fmax_Obj_outer(ObjectSet) $ (FmaxObj_Outer_TR(ObjectSet)) = yes;
                 dyn_Fmin_Obj_outer(ObjectSet) $ (FminObj_Outer_TR(ObjectSet)) = yes;
                 dyn_obj_outer(objectSet) = dyn_Fmax_Obj_outer(ObjectSet) + dyn_Fmin_Obj_outer(ObjectSet);
                 dyn_priority_outer(ObjectSet) $ (PriObj_Outer_TR(ObjectSet)) = yes;
                 No_priority_outer = card(PriObj_Outer_TR);
********************************************************************************
***** Set the weighting factors and limits for FBA objectives ******************
                 basal_vf(reactions) = 0;
                 basal_vb(reactions) = 0;
                 basal_vf(reactions) = CA_vf_UFD(reactions);
                 basal_vb(reactions) = CA_vb_UFD(reactions);
********************************************************************************     
                 z_HDE(Dim_BI) = 0;
                 z_HDE(Dim_BI) = pop_XB(NP, Dim_BI);
            
*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                 pop_Mem_sumZ(NP) $ (flag_sumz < 2) = (sumZ_max - sum(Dim_BI, (z_HDE(Dim_BI) > 0) = 1))/(sumZ_max - 1);
                 pop_Mem_sumZ(NP) $ (flag_sumz = 2) = sum(Dim_BI, (z_HDE(Dim_BI) > 0) = 1)/(sumZ_max - 1);
*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
*--- reset the oringinal bounds for all fluxes ------------------------------------------------------------------------------------------------------
                 FluxBound_vf_LB(reactions) = tmp_FluxBound_vf_LB(reactions);
                 FluxBound_vb_LB(reactions) = tmp_FluxBound_vb_LB(reactions);
                 FluxBound_vf_UB(reactions) = tmp_FluxBound_vf_UB(reactions);
                 FluxBound_vb_UB(reactions) = tmp_FluxBound_vb_UB(reactions);
*----------------------------------------------------------------------------------------------------------------------------------------------------

*---- restrictions for the lower and upper bounds of fluxes --------------------
                 vf.lo(reactions) = FluxBound_vf_LB(reactions);
                 vf.up(reactions) = FluxBound_vf_UB(reactions);
                 vb.lo(reactions) = FluxBound_vb_LB(reactions);
                 vb.up(reactions) = FluxBound_vb_UB(reactions);
*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
   
                 z_isozyme_rxn_enz(reactions, enzymes) = no;
                 z_isozyme_rxn(reactions) = no;
                 z_HDE_tmp(reactions, enzymes) = 0;
                 Regulated_Rxn_v(reactions) = NO;
                 dyn_Reg_ExRxn(reactions) = no;
                 loop(Dim_BI $ (z_HDE(Dim_BI) >= 1),
                      Regulated_rxn_v(reactions) $ (enzyme_Reg_rxn_v(Dim_BI, reactions) and dyn_reactions(reactions)) = yes;

***** assign the regulated reactions to be some levels *************************
* up regulated v
                      if(z_HDE(Dim_BI) = 1,
                         vf.lo(Regulated_rxn_v(reactions)) = basal_vf(reactions) + TR_Reg_factor(NP) * (FluxBound_vf_UB(reactions) - basal_vf(reactions));
                         vf.up(Regulated_rxn_v(reactions)) = FluxBound_vf_UB(reactions);
                         vb.lo(Regulated_rxn_v(reactions)) = FluxBound_vb_LB(reactions);
                         vb.up(Regulated_rxn_v(reactions)) = basal_vb(reactions) + TR_Reg_factor(NP) * (FluxBound_vb_LB(reactions) - basal_vb(reactions)););

* down regulated v
                      if(z_HDE(Dim_BI) = 2,
                         vf.lo(Regulated_rxn_v(reactions)) = FluxBound_vf_LB(reactions);
                         vf.up(Regulated_rxn_v(reactions)) = basal_vf(reactions) + TR_Reg_factor(NP) * (FluxBound_vf_LB(reactions) - basal_vf(reactions));
                         vb.lo(Regulated_rxn_v(reactions)) = basal_vb(reactions) + TR_Reg_factor(NP) * (FluxBound_vb_UB(reactions) - basal_vb(reactions));
                         vb.up(Regulated_rxn_v(reactions)) = FluxBound_vb_UB(reactions);

*---- the down regulated reaction by Dim_BI is dominatd by other isozymes ------
                         vf.lo(reactions) $ (Regulated_rxn_v(reactions) and isozyme_rxn(reactions)) = (1 - flux_bounded_ratio) * basal_vf(reactions);
                         vf.up(reactions) $ (Regulated_rxn_v(reactions) and isozyme_rxn(reactions)) = (1 + flux_bounded_ratio) * basal_vf(reactions);
                         vb.lo(reactions) $ (Regulated_rxn_v(reactions) and isozyme_rxn(reactions)) = (1 - flux_bounded_ratio) * basal_vb(reactions);
                         vb.up(reactions) $ (Regulated_rxn_v(reactions) and isozyme_rxn(reactions)) = (1 + flux_bounded_ratio) * basal_vb(reactions););
*-------------------------------------------------------------------------------
*---- knockout vf and vb -------------------------------------------------------
                      if(z_HDE(Dim_BI) = 3,
                         vf.fx(Regulated_rxn_v(reactions)) = 0;
                         vb.fx(Regulated_rxn_v(reactions)) = 0;

*---- the KO reaction by Dim_BI is dominatd by other isozymes ------------------
                         vf.lo(reactions) $ (Regulated_rxn_v(reactions) and isozyme_rxn(reactions)) = (1 - flux_bounded_ratio) * basal_vf(reactions);
                         vf.up(reactions) $ (Regulated_rxn_v(reactions) and isozyme_rxn(reactions)) = (1 + flux_bounded_ratio) * basal_vf(reactions);
                         vb.lo(reactions) $ (Regulated_rxn_v(reactions) and isozyme_rxn(reactions)) = (1 - flux_bounded_ratio) * basal_vb(reactions);
                         vb.up(reactions) $ (Regulated_rxn_v(reactions) and isozyme_rxn(reactions)) = (1 + flux_bounded_ratio) * basal_vb(reactions););
*-------------------------------------------------------------------------------
*---- reaction is regulated by isozyme -----------------------------------------
                      z_isozyme_rxn(reactions) $ (Regulated_rxn_v(reactions) and isozyme_rxn(reactions)) = yes;
                      z_isozyme_rxn_enz(reactions, Dim_BI) $ (Regulated_rxn_v(reactions) and isozyme_rxn(reactions)) = yes;
                      z_HDE_tmp(reactions, Dim_BI) $ (Regulated_rxn_v(reactions) and isozyme_rxn(reactions)) = z_HDE(Dim_BI);
                      dyn_Reg_ExRxn(reactions) = dyn_Reg_ExRxn(reactions) + Regulated_rxn_v(reactions);
                      Regulated_Rxn_v(reactions) = NO;);

***** Decide the regulated reaction to be up/down/KO if all isozymes are selected by NHDE ***********************************************************
                 if((card(Dim_XI) > 1 and sum(reactions $ (z_isozyme_rxn(reactions)), 1) > 0),
                     loop(reactions $ (z_isozyme_rxn(reactions) and sum(Dim_BI $ (z_HDE(Dim_BI) >= 1 and z_isozyme_rxn_enz(reactions, Dim_BI)), 1) =
                                       sum(enzymes $ (isozyme_rxn_enz(reactions, enzymes)), 1)),

*---- The reaction is KO if all isozymes are KO, z_HDE_tmp = 3 --------------------------------------------------------------------------------------
                          if(sum(Dim_BI $ (z_HDE(Dim_BI) >= 1), z_HDE_tmp(reactions, Dim_BI)) = 3 * sum(Dim_BI $ (z_HDE(Dim_BI) >= 1 and z_isozyme_rxn_enz(reactions, Dim_BI)), 1),
                             vf.fx(reactions) $ (z_isozyme_rxn(reactions)) = 0;
                             vb.fx(reactions) $ (z_isozyme_rxn(reactions)) = 0;);

*---- The reaction is down/up, (set to down firstly) if one of the isozymes is down/up --------------------------------------------------------------
                          if(sum(Dim_BI $ (z_HDE(Dim_BI) >= 1), z_HDE_tmp(reactions, Dim_BI)) < 3 * sum(Dim_BI $ (z_HDE(Dim_BI) >= 1 and z_isozyme_rxn_enz(reactions, Dim_BI)), 1),
                             vf.lo(reactions) $ (z_isozyme_rxn(reactions)) = FluxBound_vf_LB(reactions);
                             vf.up(reactions) $ (z_isozyme_rxn(reactions)) = basal_vf(reactions) + TR_Reg_factor(NP) *
                                                                            (FluxBound_vf_LB(reactions) - basal_vf(reactions));
                             vb.lo(reactions) $ (z_isozyme_rxn(reactions)) = basal_vb(reactions) + TR_Reg_factor(NP) *
                                                                            (FluxBound_vb_UB(reactions) - basal_vb(reactions));
                             vb.up(reactions) $ (z_isozyme_rxn(reactions)) = FluxBound_vb_UB(reactions););

*---- The above reaction is reassigned to up, if one of the isozymes is up --------------------------------------------------------------------------
                          loop(Dim_BI $ (z_HDE(Dim_BI) >= 1 and z_HDE_tmp(reactions, Dim_BI) = 1 and z_isozyme_rxn(reactions)),
                               vf.lo(reactions) = basal_vf(reactions) + TR_Reg_factor(NP) * (FluxBound_vf_UB(reactions) - basal_vf(reactions));
                               vf.up(reactions) = FluxBound_vf_UB(reactions);
                               vb.lo(reactions) = FluxBound_vb_LB(reactions);
                               vb.up(reactions) = basal_vb(reactions) + TR_Reg_factor(NP) * (FluxBound_vb_LB(reactions) - basal_vb(reactions));
                               break $ (z_HDE_tmp(reactions, Dim_BI) = 1););
                     );
                 );
               
*----------------------------------------------------------------------------------------------------------------------------------------------------
*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
* assign vb = 0 for the irreversible fluxes
                 vb.lo(irrev_rxn) = 0;
                 vb.up(irrev_rxn) = 0;
                 vb.fx(irrev_rxn) = 0;
                 vb.fx(DM_sink_rxn(reactions)) $ (flag_DM_sink = 1) = 0;
                 vf.lo(irrev_vb_rxn(reactions)) = 0;
                 vf.up(irrev_vb_rxn(reactions)) = 0;
                 vf.fx(irrev_vb_rxn(reactions)) = 0;

* assign the demanded uptake/secretion reactions
                 vf.fx(uptake_demand) = 0;
                 vb.fx(secretion_demand) = 0;
                 vb.fx(uptake_fixed) = FluxBound_vb_LB(uptake_fixed);

* irreversible uptake_rxn and secretion_rxn
                 vf.fx(uptake_rxn(reactions)) $ (flag_uptake = 1 and not dyn_Reg_ExRxn(reactions)) = 0;
                 vb.fx(secretion_rxn(reactions)) $ (flag_secretion = 1 and not dyn_Reg_ExRxn(reactions)) = 0;

                 vf.fx(uptake_demand(reactions)) $ (card(uptake_demand) > 0) = 0;
                 vb.fx(secretion_demand(reactions)) $ (card(secretion_demand) > 0) = 0;
********************************************************************************

*** Assign vf > 0 and vb = 0 for the Specific_rxn_vf --------------------------------
                 if(card(TR_Specific_rxn_vf) > 0,
                    vf.lo(TR_Specific_rxn_vf) =  TR_Specific_rxn_vf_LB(TR_Specific_rxn_vf);
                    vf.up(TR_Specific_rxn_vf) =  TR_Specific_rxn_vf_UB(TR_Specific_rxn_vf);
                    vb.lo(TR_Specific_rxn_vf) =  0;
                    vb.up(TR_Specific_rxn_vf) =  0;
                    vb.fx(TR_Specific_rxn_vf) =  0;);
********************************************************************************
*** Assign vf = 0 and vb > 0 for the Specific_rxn_vb --------------------------------
                 if(card(TR_Specific_rxn_vb) > 0,
                    vb.lo(TR_Specific_rxn_vb) =  TR_Specific_rxn_vb_LB(TR_Specific_rxn_vb);
                    vb.up(TR_Specific_rxn_vb) =  TR_Specific_rxn_vb_UB(TR_Specific_rxn_vb);
                    vf.lo(TR_Specific_rxn_vb) =  0;
                    vf.up(TR_Specific_rxn_vb) =  0;
                    vf.fx(TR_Specific_rxn_vb) =  0;);
*** Assign vf > 0 and vb > 0 for the Specific_rxn_vfvb -------------------------------
                 if(card(TR_Specific_rxn_vfvb) > 0,
                    vf.lo(TR_Specific_rxn_vfvb) =  TR_Specific_rxn_vf_LB(TR_Specific_rxn_vfvb);
                    vf.up(TR_Specific_rxn_vfvb) =  TR_Specific_rxn_vf_UB(TR_Specific_rxn_vfvb);
                    vb.lo(TR_Specific_rxn_vfvb) =  TR_Specific_rxn_vb_LB(TR_Specific_rxn_vfvb);
                    vb.up(TR_Specific_rxn_vfvb) =  TR_Specific_rxn_vb_UB(TR_Specific_rxn_vfvb););    
*******************************************************************************

*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

***** Set the weighting factors and limits for FBA objectives ******************
*----- compute the lower and upper bounds for the target reactions
                 target_limit_LB(targetSet) = 0;
                 target_limit_UB(targetSet) = 0;
                 target_limit_LB(targetSet) = CA_target_level_LB(targetSet);
                 target_limit_UB(targetSet) = CA_target_level_UB(targetSet);
                 MultiObjValue_FBA.lo(ObjectSet) = MultiObjValue_min(objectSet);
                 MultiObjValue_FBA.up(ObjectSet) = MultiObjValue_max(objectSet);
                 mem_objvalue_FBA.lo(objectSet) = 0;
                 mem_objvalue_FBA.up(objectSet) = 1;
                 TR_MultiObjvalue_Optim(objectset) = 0;
                 Lambda.lo = 0;
                 Lambda.up = 1;                 
*-------------------------------------------------------------------------------
* set weightin factor for mem_objvalue_FBA for CA ------------------------------
                 Weight_Lambda(ObjectSet) = 0;
                 Weight_Lambda(ObjectSet) = TR_Weight_mem_obj_FBA(ObjectSet);
*-------------------------------------------------------------------------------
*---- solve regulated FBA problem ----------------------------------------------
                 solve FBA_Problem using LP maximizing objValue_FBA ;
                 nfeval_FBA_max = nfeval_FBA_max + 1;
                 nfeval = nfeval + 1;
                 pop_modelstat_FBA(NP) = FBA_Problem.modelstat;
                 pop_constraint(NP) = 0;
                 tmp_vf_FBA(reactions) = 0;
                 tmp_vb_FBA(reactions) = 0;
                 tmp_vf_FBA(dyn_reactions) = max(vf.l(dyn_reactions), 0);
                 tmp_vb_FBA(dyn_reactions) = max(vb.l(dyn_reactions), 0);
                 tmp_MultiObjvalue_Optim(Objectset) = 0;
                 tmp_MultiObjvalue_Optim(dyn_objectset) = sum(dyn_reactions, coef_CellularObj_vf(dyn_objectset, dyn_reactions) * tmp_vf_FBA(dyn_reactions)) +
                                                          sum(dyn_reactions, coef_CellularObj_vb(dyn_objectset, dyn_reactions) * tmp_vb_FBA(dyn_reactions));
                 TR_MultiObjvalue_Optim(dyn_objectset) = tmp_MultiObjvalue_Optim(dyn_objectset);
*---- infeasible solution ------------------------------------------------------
                 if(pop_modelstat_FBA(NP) > 2,
                    pop_FMObj_inner_TR(NP, ObjectSet) = 0;
                    pop_FMObj_inner_PH(NP, ObjectSet) = 0;
                    pop_FMObj_outer_TR(NP, ObjectSet) = 0;
                    pop_FMObj_outer_PH(NP, ObjectSet) = 0;        
                    pop_mem_Met_Exp_PHHT(NP) = 0;
                    pop_mem_CV_TR(NP) = 0;
                    pop_mem_CV_PH(NP) = 0;
                    pop_mem_MD_TP(NP) = 0;
                    pop_mem_Met_PHHT(NP) = 0;
                    pop_mem_rxn_PHHT(NP) = 0;
                    pop_mem_Met_PHCA(NP) = 0;
                    pop_mem_rxn_PHCA(NP) = 0;
                    pop_mem_Met_TRCA(NP) = 0;
                    pop_mem_rxn_TRCA(NP) = 0;                    
                    pop_mem_Met_TRHT(NP) = 0;
                    pop_mem_rxn_TRHT(NP) = 0;
                    constraint_h(Dim_h) = 0;
                    constraint_h(Dim_h) = sum(reactions, S_Matrix(Dim_h, reactions) * (vf.l(reactions) - vb.l(reactions)));
                    tmp_constraint_h = sum(dyn_Fmin_Object, mem_objvalue_FBA.l(dyn_Fmin_Object) -
                                          (MultiObjValue_max(dyn_Fmin_Object) - TR_MultiObjvalue_Optim(dyn_Fmin_Object))/
                                          (MultiObjValue_max(dyn_Fmin_Object) - MultiObjValue_min(dyn_Fmin_Object))) +
                                       sum(dyn_Fmax_Object, mem_objvalue_FBA.l(dyn_Fmax_Object) -
                                          (TR_MultiObjvalue_Optim(dyn_Fmax_Object) - MultiObjValue_min(dyn_Fmax_Object))/
                                          (MultiObjValue_max(dyn_Fmax_Object) - MultiObjValue_min(dyn_Fmax_Object)));                             
                    constraint_g = sum(targetSet, max((target_limit_LB(targetSet) - (vf.l(targetSet) - vb.l(targetSet))), 0)) +
                                   sum(targetSet, max(((vf.l(targetSet) - vb.l(targetSet)) - target_limit_UB(targetSet)), 0)) +
                                   sum(dyn_ObjectSet, max((Lambda.l - mem_objvalue_FBA.l(dyn_ObjectSet)), 0));   
                    constraint_FBA_TR = penalty * (sum(Dim_h, abs(constraint_h(Dim_h)) + abs(tmp_constraint_h)) + constraint_g););
*-------------------------------------------------------------------------------
*---- solve UFD problem --------------------------------------------------------
*%%%%% the user can modify the following procedures %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                 if(pop_modelstat_FBA(NP) <= 2,                   
                    pop_FMObj_inner_TR(NP, dyn_ObjectSet) = TR_MultiObjvalue_Optim(dyn_objectset);
                    Mem_Obj_FBA_limit(ObjectSet) = 0;
                    Mem_Obj_FBA_limit(dyn_Fmax_Object) = ((TR_MultiObjvalue_Optim(dyn_Fmax_Object) - MultiObjValue_min(dyn_Fmax_Object))/
                                                          (MultiObjValue_max(dyn_Fmax_Object) - MultiObjValue_min(dyn_Fmax_Object)));
                                        
                    Mem_Obj_FBA_limit(dyn_Fmin_Object) = ((MultiObjValue_max(dyn_Fmin_Object) - TR_MultiObjvalue_Optim(dyn_Fmin_Object))/
                                                          (MultiObjValue_max(dyn_Fmin_Object) - MultiObjValue_min(dyn_Fmin_Object)));
                    Mem_Obj_FBA_limit(dyn_ObjectSet) = max(min( Mem_Obj_FBA_limit(dyn_ObjectSet), 1), 0);                                    
** assign weighting coefficients for Rxn for computing ObjValue in UFD ****************************************************************************
                    weight_coef_rxn(reactions) = Weight_factor_Rxn_OT;
                    weight_coef_rxn(reactions) $ (CA_Reactions_HC(reactions)) = Weight_factor_Rxn_HC;
                    weight_coef_rxn(reactions) $ (CA_Reactions_MC(reactions)) = Weight_factor_Rxn_MC;
                    weight_coef_rxn(reactions) $ (CA_Reactions_NC(reactions)) = Weight_factor_Rxn_NC;
*****************************************************************************************************************************************************
*----- compute the lower and upper bounds for the target reactions ------------
                    target_limit_LB(targetSet) = 0;
                    target_limit_UB(targetSet) = 0;
                    target_limit_LB(targetSet) = CA_target_level_LB(targetSet);
                    target_limit_UB(targetSet) = CA_target_level_UB(targetSet);
                    MultiObjValue_FBA.lo(ObjectSet) = MultiObjValue_min(objectSet);
                    MultiObjValue_FBA.up(ObjectSet) = MultiObjValue_max(objectSet);
                    mem_objvalue_FBA.lo(objectSet) = 0;
                    mem_objvalue_FBA.up(objectSet) = 1;
*------------------------------------------------------------------------------
                   
                    TR_vf_UFD(reactions) = 0;
                    TR_vb_UFD(reactions) = 0;
                    if(flag_UFD_Obj = 1, solve UFD1_Problem using LP minimizing ObjValue_UFD;);
                    if(flag_UFD_Obj = 2, solve UFD2_Problem using LP minimizing ObjValue_UFD;);
                    if(flag_UFD_Obj = 3, solve UFD3_Problem using QCP minimizing ObjValue_UFD;);
                    if(flag_UFD_Obj = 4, solve UFD4_Problem using QCP minimizing ObjValue_UFD;);
                    nfeval_UFD_min = nfeval_UFD_min + 1;
                    nfeval = nfeval + 1;
                    pop_modelstat_UFD(NP) = UFD%No_UFD_Obj%_Problem.modelstat;
                    TR_vf_UFD(reactions) = max(vf.l(reactions), 0);
                    TR_vb_UFD(reactions) = max(vb.l(reactions), 0);
                    TR_v_UFD(reactions) = TR_vf_UFD(reactions) - TR_vb_UFD(reactions);
                    
*---- infeasible solution ------------------------------------------------------
                    if(pop_modelstat_UFD(NP) > 2,
                       pop_FMObj_inner_TR(NP, ObjectSet) = 0;
                       pop_FMObj_inner_PH(NP, ObjectSet) = 0;
                       pop_FMObj_outer_TR(NP, ObjectSet) = 0;
                       pop_FMObj_outer_PH(NP, ObjectSet) = 0;           
                       pop_mem_Met_Exp_PHHT(NP) = 0;           
                       pop_mem_CV_TR(NP) = 0;
                       pop_mem_CV_PH(NP) = 0;
                       pop_mem_MD_TP(NP) = 0;
                       pop_mem_Met_PHHT(NP) = 0;
                       pop_mem_rxn_PHHT(NP) = 0;
                       pop_mem_Met_PHCA(NP) = 0;
                       pop_mem_rxn_PHCA(NP) = 0;
                       pop_mem_Met_TRCA(NP) = 0;
                       pop_mem_rxn_TRCA(NP) = 0;                       
                       pop_mem_Met_TRHT(NP) = 0;
                       pop_mem_rxn_TRHT(NP) = 0;
                       constraint_h(Dim_h) = 0;
                       constraint_h(Dim_h) = sum(reactions, S_Matrix(Dim_h, reactions) * (vf.l(reactions) - vb.l(reactions)));
                       tmp_constraint_h = sum(dyn_Fmin_Object, mem_objvalue_FBA.l(dyn_Fmin_Object) -
                                             (MultiObjValue_max(dyn_Fmin_Object) - MultiObjValue_FBA.l(dyn_Fmin_Object))/
                                             (MultiObjValue_max(dyn_Fmin_Object) - MultiObjValue_min(dyn_Fmin_Object))) +
                                          sum(dyn_Fmax_Object, mem_objvalue_FBA.l(dyn_Fmax_Object) -
                                             (MultiObjValue_FBA.l(dyn_Fmax_Object) - MultiObjValue_min(dyn_Fmax_Object))/
                                             (MultiObjValue_max(dyn_Fmax_Object) - MultiObjValue_min(dyn_Fmax_Object)));                              
                       constraint_g = sum(targetSet, max((target_limit_LB(targetSet) - (vf.l(targetSet) - vb.l(targetSet))), 0)) +
                                      sum(targetSet, max(((vf.l(targetSet) - vb.l(targetSet)) - target_limit_UB(targetSet)), 0)) +
                                      sum(dyn_ObjectSet, max((Mem_Obj_FBA_limit(dyn_ObjectSet) - mem_objvalue_FBA.l(dyn_ObjectSet)), 0));   
                       constraint_UFD_TR = penalty * (sum(Dim_h, abs(constraint_h(Dim_h)) + abs(tmp_constraint_h)) + constraint_g););
*-------------------------------------------------------------------------------

                    if(pop_modelstat_UFD(NP) <= 2,
**** compute membership grades of fuzzy max and min objectives for outer TR model *******************************************************************
                       TR_MultiObjvalue_Optim(Objectset) = 0;
                       TR_MultiObjvalue_Optim(dyn_obj_outer) = sum(dyn_reactions, coef_CellularObj_vf(dyn_obj_outer, dyn_reactions) * TR_vf_UFD(dyn_reactions)) +
                                                               sum(dyn_reactions, coef_CellularObj_vb(dyn_obj_outer, dyn_reactions) * TR_vb_UFD(dyn_reactions));  
                       pop_FMObj_outer_TR(NP, dyn_obj_outer) = TR_MultiObjvalue_Optim(dyn_obj_outer);
           
**** compute membership grades of fuzzy max and min objectives for outer TR model *******************************************************************
                       Mem_Obj_FBA_limit(ObjectSet) = 0;
                       Mem_Obj_FBA_limit(dyn_Fmax_Obj_outer) = (TR_MultiObjvalue_Optim(dyn_Fmax_Obj_outer) - MultiObjValue_min(dyn_Fmax_Obj_outer))/
                                                               (MultiObjValue_max(dyn_Fmax_Obj_outer) - MultiObjValue_min(dyn_Fmax_Obj_outer));
                       Mem_Obj_FBA_limit(dyn_Fmin_Obj_outer) = (MultiObjValue_max(dyn_Fmin_Obj_outer) - TR_MultiObjvalue_Optim(dyn_Fmin_Obj_outer))/
                                                               (MultiObjValue_max(dyn_Fmin_Obj_outer) - MultiObjValue_min(dyn_Fmin_Obj_outer));
                       Mem_Obj_FBA_limit(dyn_Obj_outer) = max(min( Mem_Obj_FBA_limit(dyn_Obj_outer), 1), 0);                         
                       mem_PriObj_Outer_TR = sum(dyn_priority_outer, Mem_Obj_FBA_limit(dyn_priority_outer))/No_priority_outer;
                       pop_mem_CV_TR(NP) = 0.5 * (mem_PriObj_Outer_TR + smin(dyn_obj_outer, Mem_Obj_FBA_limit(dyn_obj_outer)));
*****************************************************************************************************************************************************

*=== compute synthesis rate for each species of treated TR model ====================================================================================
                       TR_Species_SynRate(species) = 0;
                       loop(dyn_species,
                            TR_Species_SynRate(dyn_species) = sum(dyn_reactions, S_Matrix(dyn_species, dyn_reactions) $
                                                                 (S_Matrix(dyn_species, dyn_reactions) > 0) * TR_vf_UFD(dyn_reactions))
                                                            - sum(dyn_reactions, S_Matrix(dyn_Species, dyn_reactions) $
                                                                 (S_Matrix(dyn_species, dyn_reactions) < 0) * TR_vb_UFD(dyn_reactions)););

***** compute synthesis rate for each biocompound of treated TR model ******************************************************************************
                       TR_BioComp_SynRate(BioCompound) = 0;
                       loop(dyn_BioComp,
                            TR_BioComp_SynRate(dyn_BioComp) = sum(dyn_Species $ (BioCompound_species(dyn_BioComp, dyn_Species)),
                                                                  TR_Species_SynRate(dyn_Species)););

***** compute fuzzy similarity of metabolite-flow and its membership grade for TRHT model ***********************************************************                      
                       L_mem_Met_tmp(biocompound) = 0;
                       R_mem_Met_tmp(biocompound) = 0;
                       mem_Met_tmp(biocompound) = 0;             
                       L_mem_Met_tmp(BioComp_TRHT) $ (HT_BioComp_SynRate(BioComp_TRHT) > 0) =
                                                     (TR_BioComp_SynRate(BioComp_TRHT) - HT_MetFlowRate_LB(BioComp_TRHT))/
                                                     (HT_BioComp_SynRate(BioComp_TRHT) - HT_MetFlowRate_LB(BioComp_TRHT));
                                         
                       L_mem_Met_tmp(BioComp_TRHT) $ (HT_BioComp_SynRate(BioComp_TRHT) = 0) = 1;
                       R_mem_Met_tmp(BioComp_TRHT) = (HT_MetFlowRate_UB(BioComp_TRHT) - TR_BioComp_SynRate(BioComp_TRHT))/
                                                     (HT_MetFlowRate_UB(BioComp_TRHT) - HT_BioComp_SynRate(BioComp_TRHT));
                       mem_Met_tmp(BioComp_TRHT) = max(min(L_mem_Met_tmp(BioComp_TRHT), R_mem_Met_tmp(BioComp_TRHT), 1), 0);

                       nonzero_Biocomp(biocompound) = no;             
                       nonzero_Biocomp(biocompound) $ ((TR_BioComp_SynRate(biocompound) > 0 or
                                                        HT_BioComp_SynRate(biocompound) > 0) and BioComp_TRHT(biocompound)) = yes;

                       No_nonzero_Biocomp_TRHT = card(nonzero_Biocomp);                                               
                       pop_mem_Met_TRHT(NP) = sum(BioCompound $ (nonzero_Biocomp(biocompound)), mem_Met_tmp(BioCompound))/No_nonzero_Biocomp_TRHT;

*****************************************************************************************************************************************************
***** compute fuzzy similarity of flux and its membership grade for TRHT model **********************************************************************        
                       L_mem_vf_tmp(reactions) = 0;
                       R_mem_vf_tmp(reactions) = 0;
                       L_mem_vb_tmp(reactions) = 0;
                       R_mem_vb_tmp(reactions) = 0;
                       L_mem_vf_tmp(rxn_vf_TRHT) $ (HT_vf_UFD(rxn_vf_TRHT) > 0) =
                                                   (TR_vf_UFD(rxn_vf_TRHT) - HT_vf_rxn_LB(rxn_vf_TRHT))/
                                                   (HT_vf_UFD(rxn_vf_TRHT) - HT_vf_rxn_LB(rxn_vf_TRHT));
                       L_mem_vf_tmp(rxn_vf_TRHT) $ (HT_vf_UFD(rxn_vf_TRHT) = 0) = 1;
                       R_mem_vf_tmp(rxn_vf_TRHT) = (HT_vf_rxn_UB(rxn_vf_TRHT) - TR_vf_UFD(rxn_vf_TRHT))/
                                                   (HT_vf_rxn_UB(rxn_vf_TRHT)- HT_vf_UFD(rxn_vf_TRHT));           
                       L_mem_vb_tmp(rxn_vb_TRHT) $ (HT_vb_UFD(rxn_vb_TRHT) > 0) =
                                                   (TR_vb_UFD(rxn_vb_TRHT) - HT_vb_rxn_LB(rxn_vb_TRHT))/
                                                   (HT_vb_UFD(rxn_vb_TRHT) - HT_vb_rxn_LB(rxn_vb_TRHT));
                       L_mem_vb_tmp(rxn_vb_TRHT) $ (HT_vb_UFD(rxn_vb_TRHT) = 0) = 1;
                       R_mem_vb_tmp(rxn_vb_TRHT) = (HT_vb_rxn_UB(rxn_vb_TRHT) - TR_vb_UFD(rxn_vb_TRHT))/
                                                   (HT_vb_rxn_UB(rxn_vb_TRHT)- HT_vb_UFD(rxn_vb_TRHT));    

**** intialization                      
                       mem_vf_tmp(reactions) = 0;
                       mem_vb_tmp(reactions) = 0;              
                       mem_vf_tmp(rxn_vf_TRHT) = max(min(L_mem_vf_tmp(rxn_vf_TRHT), R_mem_vf_tmp(rxn_vf_TRHT), 1), 0);
                       mem_vb_tmp(rxn_vb_TRHT) = max(min(L_mem_vb_tmp(rxn_vb_TRHT), R_mem_vb_tmp(rxn_vb_TRHT), 1), 0);

                       nonzero_vf(reactions) = no;
                       nonzero_vf(reactions) $ ((TR_vf_UFD(reactions) > 0 or
                                                 HT_vf_UFD(reactions) > 0) and rxn_vf_TRHT(reactions)) = yes;
                       nonzero_vb(reactions) = no;
                       nonzero_vb(reactions) $ ((TR_vb_UFD(reactions) > 0 or
                                                 HT_vb_UFD(reactions) > 0) and rxn_vb_TRHT(reactions)) = yes;
                       nonzero_v(reactions) = no;                               
                       nonzero_v(reactions) =  nonzero_vf(reactions) + nonzero_vb(reactions);
                       No_nonzero_vf_TRHT = card(nonzero_vf);
                       No_nonzero_vb_TRHT = card(nonzero_vb);              
                       No_nonzero_v_TRHT = card(nonzero_v);
                       pop_mem_rxn_TRHT(NP) = sum(reactions $ (nonzero_v(reactions)),             
                                              min(mem_vf_tmp(reactions),mem_vb_tmp(reactions)))/No_nonzero_v_TRHT;           
*====================================================================================================================================================
***** compute fuzzy dissimilarity of metabolite-flow and its membership grade for TRCA model ********************************************************
                       L_mem_Met_tmp(biocompound) = 0;
                       R_mem_Met_tmp(biocompound) = 0;
                       mem_Met_tmp(biocompound) = 0;             
                       L_mem_Met_tmp(BioComp_TRCA) $ (CA_BioComp_SynRate(BioComp_TRCA) > 0) =         
                                                     (CA_BioComp_SynRate(BioComp_TRCA) - TR_BioComp_SynRate(BioComp_TRCA))/
                                                     (CA_BioComp_SynRate(BioComp_TRCA) - CA_MetFlowRate_LB(BioComp_TRCA));
                       L_mem_Met_tmp(BioComp_TRCA) $ (CA_BioComp_SynRate(BioComp_TRCA) = 0) = 0;
                       R_mem_Met_tmp(BioComp_TRCA) = (TR_BioComp_SynRate(BioComp_TRCA) - CA_BioComp_SynRate(BioComp_TRCA))/
                                                     (CA_MetFlowRate_UB(BioComp_TRCA) - CA_BioComp_SynRate(BioComp_TRCA));
                       mem_Met_tmp(BioComp_TRCA) = min(max(L_mem_Met_tmp(BioComp_TRCA), R_mem_Met_tmp(BioComp_TRCA), 0), 1);

                       nonzero_Biocomp(biocompound) = no;             
                       nonzero_Biocomp(biocompound) $ ((TR_BioComp_SynRate(biocompound) > 0 or
                                                        CA_BioComp_SynRate(biocompound) > 0) and BioComp_TRCA(biocompound)) = yes;
                                                        
                       No_nonzero_Biocomp_TRCA = card(nonzero_Biocomp);                                               
                       pop_mem_Met_TRCA(NP) = sum(BioCompound $ (nonzero_Biocomp(biocompound)), mem_Met_tmp(BioCompound))/No_nonzero_Biocomp_TRCA;

***** compute fuzzy dissimilarity of flux and its membership grade for TRCA model *******************************************************************                   
                       L_mem_vf_tmp(reactions) = 0;
                       R_mem_vf_tmp(reactions) = 0;
                       L_mem_vb_tmp(reactions) = 0;
                       R_mem_vb_tmp(reactions) = 0;          
                       L_mem_vf_tmp(rxn_vf_TRCA) $ (CA_vf_UFD(rxn_vf_TRCA) > 0) = (CA_vf_UFD(rxn_vf_TRCA) - TR_vf_UFD(rxn_vf_TRCA))/
                                                                                 (CA_vf_UFD(rxn_vf_TRCA) - CA_vf_rxn_LB(rxn_vf_TRCA));
                       L_mem_vf_tmp(rxn_vf_TRCA) $ (CA_vf_UFD(rxn_vf_TRCA) = 0) = 0;           
                       R_mem_vf_tmp(rxn_vf_TRCA) = (TR_vf_UFD(rxn_vf_TRCA) - CA_vf_UFD(rxn_vf_TRCA))/
                                                   (CA_vf_rxn_UB(rxn_vf_TRCA)- CA_vf_UFD(rxn_vf_TRCA));
                       L_mem_vb_tmp(rxn_vb_TRCA) $ (CA_vb_UFD(rxn_vb_TRCA) > 0) = (CA_vb_UFD(rxn_vb_TRCA) - TR_vb_UFD(rxn_vb_TRCA))/
                                                                                  (CA_vb_UFD(rxn_vb_TRCA) - CA_vb_rxn_LB(rxn_vb_TRCA));
                       L_mem_vb_tmp(rxn_vb_TRCA) $ (CA_vb_UFD(rxn_vb_TRCA) = 0) = 0;                                       
                       R_mem_vb_tmp(rxn_vb_TRCA) = (TR_vb_UFD(rxn_vb_TRCA) - CA_vb_UFD(rxn_vb_TRCA))/
                                                   (CA_vb_rxn_UB(rxn_vb_TRCA)- CA_vb_UFD(rxn_vb_TRCA));
                                       
**** intialization
                       mem_vf_tmp(reactions) = 0;
                       mem_vb_tmp(reactions) = 0;               
                       mem_vf_tmp(rxn_vf_TRCA) = min(max(L_mem_vf_tmp(rxn_vf_TRCA), R_mem_vf_tmp(rxn_vf_TRCA), 0), 1);
                       mem_vb_tmp(rxn_vb_TRCA) = min(max(L_mem_vb_tmp(rxn_vb_TRCA), R_mem_vb_tmp(rxn_vb_TRCA), 0), 1);
             
                       nonzero_vf(reactions) = no;
                       nonzero_vf(reactions) $ ((TR_vf_UFD(reactions) > 0 or
                                                 CA_vf_UFD(reactions) > 0) and rxn_vf_TRCA(reactions)) = yes;
                       nonzero_vb(reactions) = no;
                       nonzero_vb(reactions) $ ((TR_vb_UFD(reactions) > 0 or
                                                 CA_vb_UFD(reactions) > 0) and rxn_vb_TRCA(reactions)) = yes;                                                
                       nonzero_v(reactions) = no;                               
                       nonzero_v(reactions) =  nonzero_vf(reactions) + nonzero_vb(reactions);
                       No_nonzero_vf_TRCA = card(nonzero_vf);
                       No_nonzero_vb_TRCA = card(nonzero_vb);              
                       No_nonzero_v_TRCA = card(nonzero_v);
                       pop_mem_rxn_TRCA(NP) = sum(reactions $ (nonzero_v(reactions)),             
                                              max(mem_vf_tmp(reactions),mem_vb_tmp(reactions)))/No_nonzero_v_TRCA;  
*====================================================================================================================================================
                       constraint_FBA_TR = 0;
                       constraint_UFD_TR = 0;
*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

*===== evaluating side effects to solve perturbed FBA and UFD problems of HT model ==================================================================
***** Fuzzy multiobjective HT FBA Problem ***********************************************************************************************************
***** assign reactions and species in FMO HT models as dynamic sets ****************   
                       dyn_reactions(reactions) = no;
                       dyn_species(species) = no;
                       dyn_BioComp(biocompound) = no;
                       dyn_irrev_rxn(reactions) = no;
                       dyn_rev_rxn(reactions) = no;
                       dyn_exchange_rxn(reactions) = no;
                       dyn_objectSet(objectSet) = no;
                       dyn_Fmax_Object(ObjectSet) = no;
                       dyn_Fmin_Object(ObjectSet) = no;
                       dyn_priority_obj(ObjectSet) = no;
                       dyn_obj_outer(objectSet) = no;
                       dyn_Fmax_Obj_outer(ObjectSet) = no;
                       dyn_Fmin_Obj_outer(ObjectSet) = no;
                       dyn_priority_outer(ObjectSet) = no;    

**** objectives used in inner optimization problem
                       dyn_reactions(reactions)  $ (not reactions_NHT(reactions)) = yes;
                       dyn_species(species) $ (not species_NHT(species)) = yes;
                       dyn_BioComp(biocompound) $ (not biocompound_NHT(biocompound)) = yes;
                       dyn_irrev_rxn(reactions) $ (not reactions_NHT(reactions) and irrev_rxn(reactions)) = yes;
                       dyn_rev_rxn(reactions) $ (not reactions_NHT(reactions) and rev_rxn(reactions)) = yes;
                       dyn_exchange_rxn(reactions) $ (not reactions_NHT(reactions) and exchange_rxn(reactions)) = yes;
                       dyn_Fmax_Object(ObjectSet) $ (FmaxObj_inner_PH(ObjectSet)) = yes;
                       dyn_Fmin_Object(ObjectSet) $ (FminObj_inner_PH(ObjectSet)) = yes;
                       dyn_objectSet(objectSet) = dyn_Fmax_Object(ObjectSet) + dyn_Fmin_Object(ObjectSet);
                       dyn_priority_obj(ObjectSet) $ (PriObj_inner_PH(ObjectSet)) = yes;
                       No_priority_obj = card(PriObj_inner_PH);
**** objectives used in outer optimization problem     
                       dyn_Fmax_Obj_outer(ObjectSet) $ (FmaxObj_Outer_PH(ObjectSet)) = yes;
                       dyn_Fmin_Obj_outer(ObjectSet) $ (FminObj_Outer_PH(ObjectSet)) = yes;
                       dyn_obj_outer(objectSet) = dyn_Fmax_Obj_outer(ObjectSet) + dyn_Fmin_Obj_outer(ObjectSet);
                       dyn_priority_outer(ObjectSet) $ (PriObj_Outer_PH(ObjectSet)) = yes;
                       No_priority_outer = card(PriObj_Outer_PH);
********************************************************************************
***** Set the weighting factors and limits for FBA objectives ******************
                       basal_vf(reactions) = 0;
                       basal_vb(reactions) = 0;
                       basal_vf(reactions) = HT_vf_UFD(reactions);
                       basal_vb(reactions) = HT_vb_UFD(reactions);
*--- reset the oringinal bounds for all fluxes ------------------------------------------------------------------------------------------------------
                       FluxBound_vf_LB(reactions) = tmp_FluxBound_vf_LB(reactions);
                       FluxBound_vb_LB(reactions) = tmp_FluxBound_vb_LB(reactions);
                       FluxBound_vf_UB(reactions) = tmp_FluxBound_vf_UB(reactions);
                       FluxBound_vb_UB(reactions) = tmp_FluxBound_vb_UB(reactions);
*----------------------------------------------------------------------------------------------------------------------------------------------------

*---- restrictions for the lower and upper bounds of fluxes --------------------
                       vf.lo(reactions) = FluxBound_vf_LB(reactions);
                       vf.up(reactions) = FluxBound_vf_UB(reactions);
                       vb.lo(reactions) = FluxBound_vb_LB(reactions);
                       vb.up(reactions) = FluxBound_vb_UB(reactions);

*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                       z_isozyme_rxn_enz(reactions, enzymes) = no;
                       z_isozyme_rxn(reactions) = no;
                       z_HDE_tmp(reactions, enzymes) = 0;
                       Regulated_Rxn_v(reactions) = NO;
                       dyn_Reg_ExRxn(reactions) = no;
                       loop(Dim_BI $ (z_HDE(Dim_BI) >= 1),
                            Regulated_rxn_v(reactions) $ (enzyme_Reg_rxn_v(Dim_BI, reactions) and dyn_reactions(reactions)) = yes;

***** assign the regulated reactions to be some levels *************************
* up regulated v
                            if(z_HDE(Dim_BI) = 1,
                               vf.lo(Regulated_rxn_v(reactions)) = basal_vf(reactions) + TR_Reg_factor(NP) * (FluxBound_vf_UB(reactions) - basal_vf(reactions));
                               vf.up(Regulated_rxn_v(reactions)) = FluxBound_vf_UB(reactions);
                               vb.lo(Regulated_rxn_v(reactions)) = FluxBound_vb_LB(reactions);
                               vb.up(Regulated_rxn_v(reactions)) = basal_vb(reactions) + TR_Reg_factor(NP) * (FluxBound_vb_LB(reactions) - basal_vb(reactions)););

* down regulated v
                            if(z_HDE(Dim_BI) = 2,
                               vf.lo(Regulated_rxn_v(reactions)) = FluxBound_vf_LB(reactions);
                               vf.up(Regulated_rxn_v(reactions)) = basal_vf(reactions) + TR_Reg_factor(NP) * (FluxBound_vf_LB(reactions) - basal_vf(reactions));
                               vb.lo(Regulated_rxn_v(reactions)) = basal_vb(reactions) + TR_Reg_factor(NP) * (FluxBound_vb_UB(reactions) - basal_vb(reactions));
                               vb.up(Regulated_rxn_v(reactions)) = FluxBound_vb_UB(reactions);

*---- the down regulated reaction by Dim_BI is dominatd by other isozymes ------
                               vf.lo(reactions) $ (Regulated_rxn_v(reactions) and isozyme_rxn(reactions)) = (1 - flux_bounded_ratio) * basal_vf(reactions);
                               vf.up(reactions) $ (Regulated_rxn_v(reactions) and isozyme_rxn(reactions)) = (1 + flux_bounded_ratio) * basal_vf(reactions);
                               vb.lo(reactions) $ (Regulated_rxn_v(reactions) and isozyme_rxn(reactions)) = (1 - flux_bounded_ratio) * basal_vb(reactions);
                               vb.up(reactions) $ (Regulated_rxn_v(reactions) and isozyme_rxn(reactions)) = (1 + flux_bounded_ratio) * basal_vb(reactions););
*-------------------------------------------------------------------------------
*---- knockout vf and vb -------------------------------------------------------
                            if(z_HDE(Dim_BI) = 3,
                               vf.fx(Regulated_rxn_v(reactions)) = 0;
                               vb.fx(Regulated_rxn_v(reactions)) = 0;

*---- the KO reaction by Dim_BI is dominatd by other isozymes ------------------
                               vf.lo(reactions) $ (Regulated_rxn_v(reactions) and isozyme_rxn(reactions)) = (1 - flux_bounded_ratio) * basal_vf(reactions);
                               vf.up(reactions) $ (Regulated_rxn_v(reactions) and isozyme_rxn(reactions)) = (1 + flux_bounded_ratio) * basal_vf(reactions);
                               vb.lo(reactions) $ (Regulated_rxn_v(reactions) and isozyme_rxn(reactions)) = (1 - flux_bounded_ratio) * basal_vb(reactions);
                               vb.up(reactions) $ (Regulated_rxn_v(reactions) and isozyme_rxn(reactions)) = (1 + flux_bounded_ratio) * basal_vb(reactions););
*-------------------------------------------------------------------------------
*---- reaction is regulated by isozyme -----------------------------------------
                            z_isozyme_rxn(reactions) $ (Regulated_rxn_v(reactions) and isozyme_rxn(reactions)) = yes;
                            z_isozyme_rxn_enz(reactions, Dim_BI) $ (Regulated_rxn_v(reactions) and isozyme_rxn(reactions)) = yes;
                            z_HDE_tmp(reactions, Dim_BI) $ (Regulated_rxn_v(reactions) and isozyme_rxn(reactions)) = z_HDE(Dim_BI);
                            dyn_Reg_ExRxn(reactions) = dyn_Reg_ExRxn(reactions) + Regulated_rxn_v(reactions);
                            Regulated_Rxn_v(reactions) = NO;);

***** Decide the regulated reaction to be up/down/KO if all isozymes are selected by NHDE ***********************************************************
                       if((card(Dim_XI) > 1 and sum(reactions $ (z_isozyme_rxn(reactions)), 1) > 0),
                           loop(reactions $ (z_isozyme_rxn(reactions) and sum(Dim_BI $ (z_HDE(Dim_BI) >= 1 and z_isozyme_rxn_enz(reactions, Dim_BI)), 1) =
                                            sum(enzymes $ (isozyme_rxn_enz(reactions, enzymes)), 1)),
*---- The reaction is KO if all isozymes are KO, z_HDE_tmp = 3 --------------------------------------------------------------------------------------
                                if(sum(Dim_BI $ (z_HDE(Dim_BI) >= 1), z_HDE_tmp(reactions, Dim_BI)) = 3 * sum(Dim_BI $ (z_HDE(Dim_BI) >= 1 and z_isozyme_rxn_enz(reactions, Dim_BI)), 1),
                                   vf.fx(reactions) $ (z_isozyme_rxn(reactions)) = 0;
                                   vb.fx(reactions) $ (z_isozyme_rxn(reactions)) = 0;);

*---- The reaction is down/up, (set to down firstly) if one of the isozymes is down/up --------------------------------------------------------------
                                if(sum(Dim_BI $ (z_HDE(Dim_BI) >= 1), z_HDE_tmp(reactions, Dim_BI)) < 3 * sum(Dim_BI $ (z_HDE(Dim_BI) >= 1 and z_isozyme_rxn_enz(reactions, Dim_BI)), 1),
                                   vf.lo(reactions) $ (z_isozyme_rxn(reactions)) = FluxBound_vf_LB(reactions);
                                   vf.up(reactions) $ (z_isozyme_rxn(reactions)) = basal_vf(reactions) + TR_Reg_factor(NP) *
                                                                                  (FluxBound_vf_LB(reactions) - basal_vf(reactions));
                                   vb.lo(reactions) $ (z_isozyme_rxn(reactions)) = basal_vb(reactions) + TR_Reg_factor(NP) *
                                                                                  (FluxBound_vb_UB(reactions) - basal_vb(reactions));
                                   vb.up(reactions) $ (z_isozyme_rxn(reactions)) = FluxBound_vb_UB(reactions););

*---- The above reaction is reassigned to up, if one of the isozymes is up --------------------------------------------------------------------------
                                loop(Dim_BI $ (z_HDE(Dim_BI) >= 1 and z_HDE_tmp(reactions, Dim_BI) = 1 and z_isozyme_rxn(reactions)),
                                     vf.lo(reactions) = basal_vf(reactions) + TR_Reg_factor(NP) * (FluxBound_vf_UB(reactions) - basal_vf(reactions));
                                     vf.up(reactions) = FluxBound_vf_UB(reactions);
                                     vb.lo(reactions) = FluxBound_vb_LB(reactions);
                                     vb.up(reactions) = basal_vb(reactions) + TR_Reg_factor(NP) * (FluxBound_vb_LB(reactions) - basal_vb(reactions));
                                     break $ (z_HDE_tmp(reactions, Dim_BI) = 1););
                           );
                       );                     
*----------------------------------------------------------------------------------------------------------------------------------------------------
*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
* assign vb = 0 for the irreversible fluxes
                       vb.lo(irrev_rxn) = 0;
                       vb.up(irrev_rxn) = 0;
                       vb.fx(irrev_rxn) = 0;
                       vb.fx(DM_sink_rxn(reactions)) $ (flag_DM_sink = 1) = 0;
                       vf.lo(irrev_vb_rxn(reactions)) = 0;
                       vf.up(irrev_vb_rxn(reactions)) = 0;
                       vf.fx(irrev_vb_rxn(reactions)) = 0;

* assign the demanded uptake/secretion reactions
                       vf.fx(uptake_demand) = 0;
                       vb.fx(secretion_demand) = 0;
                       vb.fx(uptake_fixed) = FluxBound_vb_LB(uptake_fixed);

* irreversible uptake_rxn and secretion_rxn
                       vf.fx(uptake_rxn(reactions)) $ (flag_uptake = 1 and not dyn_Reg_ExRxn(reactions)) = 0;
                       vb.fx(secretion_rxn(reactions)) $ (flag_secretion = 1 and not dyn_Reg_ExRxn(reactions)) = 0;
                       vf.fx(uptake_demand(reactions)) $ (card(uptake_demand) > 0) = 0;
                       vb.fx(secretion_demand(reactions)) $ (card(secretion_demand) > 0) = 0;
********************************************************************************

*** Assign vf > 0 and vb = 0 for the Specific_rxn_vf --------------------------------
                       if(card(PH_Specific_rxn_vf) > 0,
                          vf.lo(PH_Specific_rxn_vf) =  PH_Specific_rxn_vf_LB(PH_Specific_rxn_vf);
                          vf.up(PH_Specific_rxn_vf) =  PH_Specific_rxn_vf_UB(PH_Specific_rxn_vf);
                          vb.lo(PH_Specific_rxn_vf) =  0;
                          vb.up(PH_Specific_rxn_vf) =  0;
                          vb.fx(PH_Specific_rxn_vf) =  0;);
********************************************************************************
*** Assign vf = 0 and vb > 0 for the Specific_rxn_vb --------------------------------
                       if(card(PH_Specific_rxn_vb) > 0,
                          vb.lo(PH_Specific_rxn_vb) =  PH_Specific_rxn_vb_LB(PH_Specific_rxn_vb);
                          vb.up(PH_Specific_rxn_vb) =  PH_Specific_rxn_vb_UB(PH_Specific_rxn_vb);
                          vf.lo(PH_Specific_rxn_vb) =  0;
                          vf.up(PH_Specific_rxn_vb) =  0;
                          vf.fx(PH_Specific_rxn_vb) =  0;);
*** Assign vf > 0 and vb > 0 for the Specific_rxn_vfvb -------------------------------
                       if(card(PH_Specific_rxn_vfvb) > 0,
                          vf.lo(PH_Specific_rxn_vfvb) =  PH_Specific_rxn_vf_LB(PH_Specific_rxn_vfvb);
                          vf.up(PH_Specific_rxn_vfvb) =  PH_Specific_rxn_vf_UB(PH_Specific_rxn_vfvb);
                          vb.lo(PH_Specific_rxn_vfvb) =  PH_Specific_rxn_vb_LB(PH_Specific_rxn_vfvb);
                          vb.up(PH_Specific_rxn_vfvb) =  PH_Specific_rxn_vb_UB(PH_Specific_rxn_vfvb););    
*******************************************************************************

*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
*----- compute the lower and upper bounds for the target reactions
                       target_limit_LB(targetSet) = 0;
                       target_limit_UB(targetSet) = 0;
                       target_limit_LB(targetSet) = HT_target_level_LB(targetSet);
                       target_limit_UB(targetSet) = HT_target_level_UB(targetSet);
                       MultiObjValue_FBA.lo(ObjectSet) = MultiObjValue_min(objectSet);
                       MultiObjValue_FBA.up(ObjectSet) = MultiObjValue_max(objectSet);
                       mem_objvalue_FBA.lo(objectSet) = 0;
                       mem_objvalue_FBA.up(objectSet) = 1;
                       PH_MultiObjvalue_Optim(objectset) = 0;
                       Lambda.lo = 0;
                       Lambda.up = 1;              
*-------------------------------------------------------------------------------
* set weightin factor for mem_objvalue_FBA for HT ------------------------------
                       Weight_Lambda(ObjectSet) = 0;
                       Weight_Lambda(ObjectSet) = PH_Weight_mem_obj_FBA(ObjectSet);
*-------------------------------------------------------------------------------
*---- solve mutant FBA problem considering side effect -------------------------
                       solve FBA_Problem using LP maximizing objValue_FBA ;
                       nfeval_FBA_max = nfeval_FBA_max + 1;
                       nfeval = nfeval + 1;
                       tmp_vf_FBA(reactions) = 0;
                       tmp_vb_FBA(reactions) = 0;
                       tmp_vf_FBA(dyn_reactions) = max(vf.l(dyn_reactions), 0);
                       tmp_vb_FBA(dyn_reactions) = max(vb.l(dyn_reactions), 0);
                       tmp_MultiObjvalue_Optim(Objectset) = 0;
                       tmp_MultiObjvalue_Optim(dyn_objectset) = sum(dyn_reactions, coef_CellularObj_vf(dyn_objectset, dyn_reactions) * tmp_vf_FBA(dyn_reactions)) +
                                                                sum(dyn_reactions, coef_CellularObj_vb(dyn_objectset, dyn_reactions) * tmp_vb_FBA(dyn_reactions));                       
                       PH_MultiObjvalue_Optim(dyn_objectset) = tmp_MultiObjvalue_Optim(dyn_objectset);
*---- infeasible solution ------------------------------------------------------
                       if(FBA_Problem.modelstat > 2,
                          pop_FMObj_inner_TR(NP, ObjectSet) $ (pop_modelstat_UFD(NP) > 2) = 0;
                          pop_FMObj_inner_PH(NP, ObjectSet) = 0;
                          pop_FMObj_outer_TR(NP, ObjectSet) $ (pop_modelstat_UFD(NP) > 2) = 0;
                          pop_FMObj_outer_PH(NP, ObjectSet) = 0;  
                          pop_mem_CV_TR(NP) $ (pop_modelstat_UFD(NP) > 2) = 0;
                          pop_mem_Met_Exp_PHHT(NP) = 0;
                          pop_mem_CV_PH(NP) = 0;
                          pop_mem_MD_TP(NP) = 0;
                          pop_mem_Met_PHHT(NP) = 0;
                          pop_mem_rxn_PHHT(NP) = 0;
                          pop_mem_Met_PHCA(NP) = 0;
                          pop_mem_rxn_PHCA(NP) = 0;
                          pop_mem_Met_TRCA(NP) = 0;
                          pop_mem_rxn_TRCA(NP) = 0;                          
                          pop_mem_Met_TRHT(NP) $ (pop_modelstat_UFD(NP) > 2) = 0;
                          pop_mem_rxn_TRHT(NP) $ (pop_modelstat_UFD(NP) > 2) = 0;
                          constraint_h(Dim_h) = 0;
                          constraint_h(Dim_h) = sum(reactions, S_Matrix(Dim_h, reactions) * (vf.l(reactions) - vb.l(reactions)));
                          tmp_constraint_h = sum(dyn_Fmin_Object, mem_objvalue_FBA.l(dyn_Fmin_Object) -
                                                (MultiObjValue_max(dyn_Fmin_Object) - PH_MultiObjvalue_Optim(dyn_Fmin_Object))/
                                                (MultiObjValue_max(dyn_Fmin_Object) - MultiObjValue_min(dyn_Fmin_Object))) +
                                             sum(dyn_Fmax_Object, mem_objvalue_FBA.l(dyn_Fmax_Object) -
                                                (PH_MultiObjvalue_Optim(dyn_Fmax_Object) - MultiObjValue_min(dyn_Fmax_Object))/
                                                (MultiObjValue_max(dyn_Fmax_Object) - MultiObjValue_min(dyn_Fmax_Object)));                             
                          constraint_g = sum(targetSet, max((target_limit_LB(targetSet) - (vf.l(targetSet) - vb.l(targetSet))), 0)) +
                                         sum(targetSet, max(((vf.l(targetSet) - vb.l(targetSet)) - target_limit_UB(targetSet)), 0)) +
                                         sum(dyn_ObjectSet, max((Lambda.l - mem_objvalue_FBA.l(dyn_ObjectSet)), 0));   
                          constraint_FBA_PH = penalty * (sum(Dim_h, abs(constraint_h(Dim_h)) + abs(tmp_constraint_h)) + constraint_g););

*-------------------------------------------------------------------------------      

**** mutant UFD problem considering side effect ********************************
                       if(FBA_Problem.modelstat <= 2,  
                          pop_FMObj_inner_PH(NP, dyn_ObjectSet) = PH_MultiObjvalue_Optim(dyn_objectset);
                          Mem_Obj_FBA_limit(ObjectSet) = 0;
                          Mem_Obj_FBA_limit(dyn_Fmax_Object) = ((PH_MultiObjvalue_Optim(dyn_Fmax_Object) - MultiObjValue_min(dyn_Fmax_Object))/
                                                                (MultiObjValue_max(dyn_Fmax_Object) - MultiObjValue_min(dyn_Fmax_Object)));                                          
                          Mem_Obj_FBA_limit(dyn_Fmin_Object) = ((MultiObjValue_max(dyn_Fmin_Object) - PH_MultiObjvalue_Optim(dyn_Fmin_Object))/
                                                                (MultiObjValue_max(dyn_Fmin_Object) - MultiObjValue_min(dyn_Fmin_Object)));                       
                          Mem_Obj_FBA_limit(dyn_ObjectSet) = max(min( Mem_Obj_FBA_limit(dyn_ObjectSet), 1), 0);
** assign weighting coefficients for Rxn for computing ObjValue in UFD ****************************************************************************
                          weight_coef_rxn(reactions) = Weight_factor_Rxn_OT;
                          weight_coef_rxn(reactions) $ (HT_Reactions_HC(reactions)) = Weight_factor_Rxn_HC;
                          weight_coef_rxn(reactions) $ (HT_Reactions_MC(reactions)) = Weight_factor_Rxn_MC;
                          weight_coef_rxn(reactions) $ (HT_Reactions_NC(reactions)) = Weight_factor_Rxn_NC;
***************************************************************************************************************************************************
*----- compute the lower and upper bounds for the target reactions ------------
                          target_limit_LB(targetSet) = 0;
                          target_limit_UB(targetSet) = 0;
                          target_limit_LB(targetSet) = HT_target_level_LB(targetSet);
                          target_limit_UB(targetSet) = HT_target_level_UB(targetSet);
                          MultiObjValue_FBA.lo(ObjectSet) = MultiObjValue_min(objectSet);
                          MultiObjValue_FBA.up(ObjectSet) = MultiObjValue_max(objectSet);
                          mem_objvalue_FBA.lo(objectSet) = 0;
                          mem_objvalue_FBA.up(objectSet) = 1;
*------------------------------------------------------------------------------
                      
                          PH_vf_UFD(reactions) = 0;
                          PH_vb_UFD(reactions) = 0;
                          if(flag_UFD_Obj = 1, solve UFD1_Problem using LP minimizing ObjValue_UFD;);
                          if(flag_UFD_Obj = 2, solve UFD2_Problem using LP minimizing ObjValue_UFD;);
                          if(flag_UFD_Obj = 3, solve UFD3_Problem using QCP minimizing ObjValue_UFD;);
                          if(flag_UFD_Obj = 4, solve UFD4_Problem using QCP minimizing ObjValue_UFD;);
                          nfeval_UFD_min = nfeval_UFD_min + 1;
                          nfeval = nfeval + 1;);
                          
*---- infeasible solution ------------------------------------------------------
                       if(UFD%No_UFD_Obj%_Problem.modelstat > 2,
                          pop_FMObj_inner_TR(NP, ObjectSet) $ (pop_modelstat_UFD(NP) > 2) = 0;
                          pop_FMObj_inner_PH(NP, ObjectSet) = 0;
                          pop_FMObj_outer_TR(NP, ObjectSet) $ (pop_modelstat_UFD(NP) > 2) = 0;
                          pop_FMObj_outer_PH(NP, ObjectSet) = 0;  
                          pop_mem_CV_TR(NP) $ (pop_modelstat_UFD(NP) > 2) = 0;
                          pop_mem_Met_Exp_PHHT(NP) = 0;
                          pop_mem_CV_PH(NP) = 0;
                          pop_mem_MD_TP(NP) = 0;
                          pop_mem_Met_PHHT(NP) = 0;
                          pop_mem_rxn_PHHT(NP) = 0;
                          pop_mem_Met_PHCA(NP) = 0;
                          pop_mem_rxn_PHCA(NP) = 0;
                          pop_mem_Met_TRCA(NP) = 0;
                          pop_mem_rxn_TRCA(NP) = 0;                          
                          pop_mem_Met_TRHT(NP) $ (pop_modelstat_UFD(NP) > 2) = 0;
                          pop_mem_rxn_TRHT(NP) $ (pop_modelstat_UFD(NP) > 2) = 0;
                          constraint_h(Dim_h) = 0;
                          constraint_h(Dim_h) = sum(reactions, S_Matrix(Dim_h, reactions) * (vf.l(reactions) - vb.l(reactions)));
                          tmp_constraint_h = sum(dyn_Fmin_Object, mem_objvalue_FBA.l(dyn_Fmin_Object) -
                                                (MultiObjValue_max(dyn_Fmin_Object) - MultiObjValue_FBA.l(dyn_Fmin_Object))/
                                                (MultiObjValue_max(dyn_Fmin_Object) - MultiObjValue_min(dyn_Fmin_Object))) +
                                             sum(dyn_Fmax_Object, mem_objvalue_FBA.l(dyn_Fmax_Object) -
                                                (MultiObjValue_FBA.l(dyn_Fmax_Object) - MultiObjValue_min(dyn_Fmax_Object))/
                                                (MultiObjValue_max(dyn_Fmax_Object) - MultiObjValue_min(dyn_Fmax_Object)));                            
                          constraint_g = sum(targetSet, max((target_limit_LB(targetSet) - (vf.l(targetSet) - vb.l(targetSet))), 0)) +
                                         sum(targetSet, max(((vf.l(targetSet) - vb.l(targetSet)) - target_limit_UB(targetSet)), 0)) +
                                         sum(dyn_ObjectSet, max((Lambda.l - mem_objvalue_FBA.l(dyn_ObjectSet)), 0));   
                          constraint_UFD_PH = penalty * (sum(Dim_h, abs(constraint_h(Dim_h)) + abs(tmp_constraint_h)) + constraint_g););
*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%              
                           
                       if(FBA_Problem.modelstat <= 2 and UFD%No_UFD_Obj%_Problem.modelstat <= 2,
* compute synthesis rate and degradation rate for each BioCompound at the mutant state
                          PH_vf_UFD(reactions) = max(vf.l(reactions), 0);
                          PH_vb_UFD(reactions) = max(vb.l(reactions), 0);
                          PH_v_UFD(reactions) = PH_vf_UFD(reactions) - PH_vb_UFD(reactions);
 
**** compute membership grades of fuzzy max and min objectives for outer PH model *******************************************************************
                          PH_MultiObjvalue_Optim(Objectset) = 0;
                          PH_MultiObjvalue_Optim(dyn_obj_outer) = sum(dyn_reactions, coef_CellularObj_vf(dyn_obj_outer, dyn_reactions) * PH_vf_UFD(dyn_reactions)) +
                                                                  sum(dyn_reactions, coef_CellularObj_vb(dyn_obj_outer, dyn_reactions) * PH_vb_UFD(dyn_reactions));  
                          pop_FMObj_outer_PH(NP, dyn_obj_outer) = PH_MultiObjvalue_Optim(dyn_obj_outer);
           
**** compute membership grades of fuzzy max and min objectives for outer PH model *******************************************************************
                          Mem_Obj_FBA_limit(ObjectSet) = 0;
                          Mem_Obj_FBA_limit(dyn_Fmax_Obj_outer) = (PH_MultiObjvalue_Optim(dyn_Fmax_Obj_outer) - MultiObjValue_min(dyn_Fmax_Obj_outer))/
                                                                  (MultiObjValue_max(dyn_Fmax_Obj_outer) - MultiObjValue_min(dyn_Fmax_Obj_outer));
                          Mem_Obj_FBA_limit(dyn_Fmin_Obj_outer) = (MultiObjValue_max(dyn_Fmin_Obj_outer) - PH_MultiObjvalue_Optim(dyn_Fmin_Obj_outer))/
                                                                  (MultiObjValue_max(dyn_Fmin_Obj_outer) - MultiObjValue_min(dyn_Fmin_Obj_outer));
                          Mem_Obj_FBA_limit(dyn_Obj_outer) = max(min( Mem_Obj_FBA_limit(dyn_Obj_outer), 1), 0);                      
                          mem_PriObj_Outer_PH = sum(dyn_priority_outer, Mem_Obj_FBA_limit(dyn_priority_outer))/No_priority_outer;
                          pop_mem_CV_PH(NP) = 0.5 * (mem_PriObj_Outer_PH + smin(dyn_obj_outer, Mem_Obj_FBA_limit(dyn_obj_outer)));
*****************************************************************************************************************************************************
*=== compute synthesis rate for each species of treated PH model ====================================================================================
                          PH_Species_SynRate(species) = 0;
                          loop(dyn_species,
                               PH_Species_SynRate(dyn_species) = sum(dyn_reactions, S_Matrix(dyn_species, dyn_reactions) $
                                                                    (S_Matrix(dyn_species, dyn_reactions) > 0) * PH_vf_UFD(dyn_reactions))
                                                               - sum(dyn_reactions, S_Matrix(dyn_Species, dyn_reactions) $
                                                                    (S_Matrix(dyn_species, dyn_reactions) < 0) * PH_vb_UFD(dyn_reactions)););

***** compute synthesis rate for each biocompound of treated PH model ******************************************************************************
                          PH_BioComp_SynRate(BioCompound) = 0;
                          loop(dyn_BioComp,
                               PH_BioComp_SynRate(dyn_BioComp) = sum(dyn_Species $ (BioCompound_species(dyn_BioComp, dyn_Species)),
                                                                     PH_Species_SynRate(dyn_Species)););       
*****************************************************************************************************************************************************
***** compute fuzzy dissimilarity of metabolite-flow and its membership grade for PHCA model ********************************************************
                          L_mem_Met_tmp(biocompound) = 0;
                          R_mem_Met_tmp(biocompound) = 0;
                          mem_Met_tmp(biocompound) = 0;             
                          L_mem_Met_tmp(BioComp_PHCA) $ (CA_BioComp_SynRate(BioComp_PHCA) > 0) =
                                                        (CA_BioComp_SynRate(BioComp_PHCA) - PH_BioComp_SynRate(BioComp_PHCA))/
                                                        (CA_BioComp_SynRate(BioComp_PHCA) - CA_MetFlowRate_LB(BioComp_PHCA));
                          L_mem_Met_tmp(BioComp_PHCA) $ (CA_BioComp_SynRate(BioComp_PHCA) = 0) = 0;
                          R_mem_Met_tmp(BioComp_PHCA) = (PH_BioComp_SynRate(BioComp_PHCA) - CA_BioComp_SynRate(BioComp_PHCA))/
                                                        (CA_MetFlowRate_UB(BioComp_PHCA) - CA_BioComp_SynRate(BioComp_PHCA));
                          mem_Met_tmp(BioComp_PHCA) = min(max(L_mem_Met_tmp(BioComp_PHCA), R_mem_Met_tmp(BioComp_PHCA), 0), 1);            

                          nonzero_Biocomp(biocompound) = no;             
                          nonzero_Biocomp(biocompound) $ ((PH_BioComp_SynRate(biocompound) > 0 or
                                                           CA_BioComp_SynRate(biocompound) > 0) and BioComp_PHCA(biocompound)) = yes;                                                          
                          No_nonzero_Biocomp_PHCA = card(nonzero_Biocomp);                                               
                          pop_mem_Met_PHCA(NP) = sum(BioCompound $ (nonzero_Biocomp(biocompound)), mem_Met_tmp(BioCompound))/No_nonzero_Biocomp_PHCA;

***** compute fuzzy dissimilarity of flux and its membership grade for PHCA model *******************************************************************                                                     
                          L_mem_vf_tmp(reactions) = 0;
                          R_mem_vf_tmp(reactions) = 0;
                          L_mem_vb_tmp(reactions) = 0;
                          R_mem_vb_tmp(reactions) = 0;
                          L_mem_vf_tmp(rxn_vf_PHCA) $ (CA_vf_UFD(rxn_vf_PHCA) > 0) = (CA_vf_UFD(rxn_vf_PHCA) - PH_vf_UFD(rxn_vf_PHCA))/
                                                                                    (CA_vf_UFD(rxn_vf_PHCA) - CA_vf_rxn_LB(rxn_vf_PHCA));
                          L_mem_vf_tmp(rxn_vf_PHCA) $ (CA_vf_UFD(rxn_vf_PHCA) = 0) = 0;
                          R_mem_vf_tmp(rxn_vf_PHCA) = (PH_vf_UFD(rxn_vf_PHCA) - CA_vf_UFD(rxn_vf_PHCA))/
                                                      (CA_vf_rxn_UB(rxn_vf_PHCA)- CA_vf_UFD(rxn_vf_PHCA));                                       
                          L_mem_vb_tmp(rxn_vb_PHCA) $ (CA_vb_UFD(rxn_vb_PHCA) > 0) = (CA_vb_UFD(rxn_vb_PHCA) - PH_vb_UFD(rxn_vb_PHCA))/
                                                                                     (CA_vb_UFD(rxn_vb_PHCA) - CA_vb_rxn_LB(rxn_vb_PHCA));
                          L_mem_vb_tmp(rxn_vb_PHCA) $ (CA_vb_UFD(rxn_vb_PHCA) = 0) = 0;                                     
                          R_mem_vb_tmp(rxn_vb_PHCA) = (PH_vb_UFD(rxn_vb_PHCA) - CA_vb_UFD(rxn_vb_PHCA))/
                                                      (CA_vb_rxn_UB(rxn_vb_PHCA)- CA_vb_UFD(rxn_vb_PHCA)); 

**** intialization
                          mem_vf_tmp(reactions) = 0;
                          mem_vb_tmp(reactions) = 0;               
                          mem_vf_tmp(rxn_vf_PHCA) = min(max(L_mem_vf_tmp(rxn_vf_PHCA), R_mem_vf_tmp(rxn_vf_PHCA), 0), 1);
                          mem_vb_tmp(rxn_vb_PHCA) = min(max(L_mem_vb_tmp(rxn_vb_PHCA), R_mem_vb_tmp(rxn_vb_PHCA), 0), 1);

                          nonzero_vf(reactions) = no;
                          nonzero_vf(reactions) $ ((PH_vf_UFD(reactions) > 0 or
                                                    CA_vf_UFD(reactions) > 0) and rxn_vf_PHCA(reactions)) = yes;
                          nonzero_vb(reactions) = no;
                          nonzero_vb(reactions) $ ((PH_vb_UFD(reactions) > 0 or
                                                    CA_vb_UFD(reactions) > 0) and rxn_vb_PHCA(reactions)) = yes;
                          nonzero_v(reactions) = no;                               
                          nonzero_v(reactions) =  nonzero_vf(reactions) + nonzero_vb(reactions);
                          No_nonzero_vf_PHCA = card(nonzero_vf);
                          No_nonzero_vb_PHCA = card(nonzero_vb);              
                          No_nonzero_v_PHCA = card(nonzero_v);
                          pop_mem_rxn_PHCA(NP) = sum(reactions $ (nonzero_v(reactions)),             
                                                 max(mem_vf_tmp(reactions),mem_vb_tmp(reactions)))/No_nonzero_v_PHCA;  
*====================================================================================================================================================
*==== compute fuzzy similarity of metabolite-flow and its membership grade for PHHT model ===========================================================
*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
***** compute fuzzy similarity of Warburg and experiments for PHHT model 
                          L_mem_Met_Exp(BioCompound) = 0;
                          R_mem_Met_Exp(BioCompound) = 0;
                          mem_Met_Exp(BioCompound) = 0;
                          L_mem_Met_Exp(BioComp_ExpWarb) $ (HT_BioComp_SynRate(BioComp_ExpWarb) > 0) =
                                                           (PH_BioComp_SynRate(BioComp_ExpWarb) - HT_MetFlowRate_LB(BioComp_ExpWarb))/
                                                           (HT_BioComp_SynRate(BioComp_ExpWarb) - HT_MetFlowRate_LB(BioComp_ExpWarb));
                          L_mem_Met_Exp(BioComp_ExpWarb) $ (HT_BioComp_SynRate(BioComp_ExpWarb) = 0) = 1;
                          R_mem_Met_Exp(BioComp_ExpWarb) = (HT_MetFlowRate_UB(BioComp_ExpWarb) - PH_BioComp_SynRate(BioComp_ExpWarb))/
                                                           (HT_MetFlowRate_UB(BioComp_ExpWarb) - HT_BioComp_SynRate(BioComp_ExpWarb));
                          mem_Met_Exp(BioComp_ExpWarb) = max(min(L_mem_Met_Exp(BioComp_ExpWarb), R_mem_Met_Exp(BioComp_ExpWarb), 1), 0);
                          pop_mem_Met_Exp_PHHT(NP) = sum(BioComp_ExpWarb, mem_Met_Exp(BioComp_ExpWarb))/card(BioComp_ExpWarb);

*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
***** compute fuzzy similarity of metabolite flow rates for biocompounds of PHHT model 
                          L_mem_Met_tmp(biocompound) = 0;
                          R_mem_Met_tmp(biocompound) = 0;
                          mem_Met_tmp(biocompound) = 0;             
                          L_mem_Met_tmp(BioComp_PHHT) $ (HT_BioComp_SynRate(BioComp_PHHT) > 0) =
                                                        (PH_BioComp_SynRate(BioComp_PHHT) - HT_MetFlowRate_LB(BioComp_PHHT))/
                                                        (HT_BioComp_SynRate(BioComp_PHHT) - HT_MetFlowRate_LB(BioComp_PHHT)); 
                          L_mem_Met_tmp(BioComp_PHHT) $ (HT_BioComp_SynRate(BioComp_PHHT) = 0) = 1;
                          R_mem_Met_tmp(BioComp_PHHT) = (HT_MetFlowRate_UB(BioComp_PHHT) - PH_BioComp_SynRate(BioComp_PHHT))/
                                                        (HT_MetFlowRate_UB(BioComp_PHHT) - HT_BioComp_SynRate(BioComp_PHHT));  
                          mem_Met_tmp(BioComp_PHHT) = max(min(L_mem_Met_tmp(BioComp_PHHT), R_mem_Met_tmp(BioComp_PHHT), 1), 0); 

                          nonzero_Biocomp(biocompound) = no;             
                          nonzero_Biocomp(biocompound) $ ((PH_BioComp_SynRate(biocompound) > 0 or
                                                           HT_BioComp_SynRate(biocompound) > 0) and BioComp_PHHT(biocompound)) = yes;
                          No_nonzero_Biocomp_PHHT = card(nonzero_Biocomp);                                               
                          pop_mem_Met_PHHT(NP) = sum(BioCompound $ (nonzero_Biocomp(biocompound)), mem_Met_tmp(BioCompound))/No_nonzero_Biocomp_PHHT;

*****************************************************************************************************************************************************
***** compute fuzzy similarity of flux and its membership grade for PHHT model **********************************************************************        
                          L_mem_vf_tmp(reactions) = 0;
                          R_mem_vf_tmp(reactions) = 0;
                          L_mem_vb_tmp(reactions) = 0;
                          R_mem_vb_tmp(reactions) = 0;
                          L_mem_vf_tmp(rxn_vf_PHHT) $ (HT_vf_UFD(rxn_vf_PHHT) > 0) =
                                                      (PH_vf_UFD(rxn_vf_PHHT) - HT_vf_rxn_LB(rxn_vf_PHHT))/
                                                      (HT_vf_UFD(rxn_vf_PHHT) - HT_vf_rxn_LB(rxn_vf_PHHT));
                          L_mem_vf_tmp(rxn_vf_PHHT) $ (HT_vf_UFD(rxn_vf_PHHT) = 0) = 1;
                          R_mem_vf_tmp(rxn_vf_PHHT) = (HT_vf_rxn_UB(rxn_vf_PHHT) - PH_vf_UFD(rxn_vf_PHHT))/
                                                      (HT_vf_rxn_UB(rxn_vf_PHHT)- HT_vf_UFD(rxn_vf_PHHT));                                          
                          L_mem_vb_tmp(rxn_vb_PHHT) $ (HT_vb_UFD(rxn_vb_PHHT) > 0) =
                                                      (PH_vb_UFD(rxn_vb_PHHT) - HT_vb_rxn_LB(rxn_vb_PHHT))/
                                                      (HT_vb_UFD(rxn_vb_PHHT) - HT_vb_rxn_LB(rxn_vb_PHHT));
                          L_mem_vb_tmp(rxn_vb_PHHT) $ (HT_vb_UFD(rxn_vb_PHHT) = 0) = 1;
                          R_mem_vb_tmp(rxn_vb_PHHT) = (HT_vb_rxn_UB(rxn_vb_PHHT) - PH_vb_UFD(rxn_vb_PHHT))/
                                                      (HT_vb_rxn_UB(rxn_vb_PHHT)- HT_vb_UFD(rxn_vb_PHHT));    

**** intialization
                          mem_vf_tmp(reactions) = 0;
                          mem_vb_tmp(reactions) = 0;
                          mem_vf_tmp(rxn_vf_PHHT) = max(min(L_mem_vf_tmp(rxn_vf_PHHT), R_mem_vf_tmp(rxn_vf_PHHT), 1), 0);
                          mem_vb_tmp(rxn_vb_PHHT) = max(min(L_mem_vb_tmp(rxn_vb_PHHT), R_mem_vb_tmp(rxn_vb_PHHT), 1), 0);

                          nonzero_vf(reactions) = no;
                          nonzero_vf(reactions) $ ((PH_vf_UFD(reactions) > 0 or
                                                    HT_vf_UFD(reactions) > 0) and rxn_vf_PHHT(reactions)) = yes;
                          nonzero_vb(reactions) = no;
                          nonzero_vb(reactions) $ ((PH_vb_UFD(reactions) > 0 or
                                                    HT_vb_UFD(reactions) > 0) and rxn_vb_PHHT(reactions)) = yes;
                          nonzero_v(reactions) = no;                               
                          nonzero_v(reactions) =  nonzero_vf(reactions) + nonzero_vb(reactions);
                          No_nonzero_vf_PHHT = card(nonzero_vf);
                          No_nonzero_vb_PHHT = card(nonzero_vb);              
                          No_nonzero_v_PHHT = card(nonzero_v);
                          pop_mem_rxn_PHHT(NP) = sum(reactions $ (nonzero_v(reactions)),             
                                                 min(mem_vf_tmp(reactions),mem_vb_tmp(reactions)))/No_nonzero_v_PHHT;           
*====================================================================================================================================================
                          constraint_FBA_PH = 0;
                          constraint_UFD_PH = 0;
                       );
                    );
                );
*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
*----- fitness evaluation ------------------------------------------------------
* Metabolic deviation (dissimilarity) for PH model to CA template
pop_mem_MD_PHCA(NP) = ((pop_mem_rxn_PHCA(NP) + pop_mem_Met_PHCA(NP))/2 + min(pop_mem_rxn_PHCA(NP), pop_mem_Met_PHCA(NP)))/2;

* Metabolic deviation (similarity) for PH model to HT template
pop_mem_MD_PHHT(NP) = ((pop_mem_rxn_PHHT(NP) + pop_mem_Met_PHHT(NP))/2 + min(pop_mem_rxn_PHHT(NP), pop_mem_Met_PHHT(NP)))/2;

* Metabolic deviation (similarity) for TR model to HT template
pop_mem_MD_TRHT(NP) = ((pop_mem_rxn_TRHT(NP) + pop_mem_Met_TRHT(NP))/2 + min(pop_mem_rxn_TRHT(NP), pop_mem_Met_TRHT(NP)))/2;

* Metabolic deviation (dissimilarity) for TR model to CA template
pop_mem_MD_TRCA(NP) = ((pop_mem_rxn_TRCA(NP) + pop_mem_Met_TRCA(NP))/2 + min(pop_mem_rxn_TRCA(NP), pop_mem_Met_TRCA(NP)))/2;

* Metabolic deviation of fuzzy dissimilarity and similarity for PHCA, TRCA TRHT, and PHHT
pop_mem_MD_TP(NP) $ (index_sumz = 1 or index_sumz = 21 or index_sumz = 22) = ((pop_mem_MD_PHCA(NP) + pop_mem_MD_PHHT(NP))/2 +
                                                                               min(pop_mem_MD_PHCA(NP), pop_mem_MD_PHHT(NP)))/2;

pop_mem_MD_TP(NP) $ (index_sumz = 41 or index_sumz = 42) = ((pop_mem_MD_PHCA(NP) + pop_mem_MD_PHHT(NP) + pop_mem_MD_TRHT(NP) + pop_mem_MD_TRCA(NP))/4 +
                                                            min(pop_mem_MD_PHCA(NP), pop_mem_MD_PHHT(NP), pop_mem_MD_TRHT(NP), pop_mem_MD_TRCA(NP)))/2;

* Metabolic deviation of fuzzy similarity for TRHT, and PHHT
pop_mem_MD_TP(NP) $ (index_sumz = 23 or index_sumz = 24) = ((pop_mem_MD_TRHT(NP) + pop_mem_MD_PHHT(NP))/2 +
                                                             min(pop_mem_MD_TRHT(NP), pop_mem_MD_PHHT(NP)))/2;

*----- prioity fitness evaluation ----------------------------------------------
pop_constraint(NP) = constraint_FBA_TR + constraint_UFD_TR + constraint_FBA_PH + constraint_UFD_PH;
pop_fitness(NP) $ (index_sumZ = 1) = mem_PriObj_Outer_TR;
pop_fitness(NP) $ (index_sumZ = 21 or index_sumZ = 23 or index_sumz = 41) = (pop_mem_CV_TR(NP) +
                                                                             min(pop_mem_CV_TR(NP), pop_mem_CV_PH(NP), pop_mem_MD_TP(NP)))/2;
pop_fitness(NP) $ (index_sumZ = 22 or index_sumZ = 24 or index_sumz = 42) = ((pop_mem_CV_TR(NP) + pop_mem_CV_PH(NP))/2 +
                                                                             min(pop_mem_CV_TR(NP), pop_mem_CV_PH(NP), pop_mem_MD_TP(NP)))/2;
pop_fitness(NP) = pop_fitness(NP) - pop_constraint(NP);                                                                             
pop_fitness(NP) $ (flag_sumZ = 1) = pop_fitness(NP) + pop_mem_sumZ(NP););
*-------------------------------------------------------------------------------
*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

*---- find the best fitness and individual -------------------------------------
             best_fitness = smax(NP, pop_fitness(NP));
             loop(NP $ (pop_fitness(NP) >= best_fitness),
                  best_FMObj_inner_TR(ObjectSet) = 0;
                  best_FMObj_inner_PH(ObjectSet) = 0;
                  best_FMObj_outer_TR(ObjectSet) = 0;
                  best_FMObj_outer_PH(ObjectSet) = 0;
                  bestmem_XB(Dim_BI) = 0;
                  bestmem_XI(Dim_XIR) = 0;     
                  best_FMObj_inner_TR(ObjectSet) = pop_FMObj_inner_TR(NP, objectSet);
                  best_FMObj_inner_PH(ObjectSet) = pop_FMObj_inner_PH(NP, objectSet);
                  best_FMObj_outer_TR(ObjectSet) = pop_FMObj_outer_TR(NP, objectSet);
                  best_FMObj_outer_PH(ObjectSet) = pop_FMObj_outer_PH(NP, objectSet);
                  bestmem_XB(Dim_BI) = pop_XB(NP, Dim_BI);
                  bestmem_XI(Dim_XIR) = pop_XI(NP, Dim_XIR);    
                  best_Mem_sumZ  = pop_Mem_sumZ(NP);
                  best_modelstat = pop_modelstat_UFD(NP);
                  best_constraint = pop_constraint(NP);         
                  best_fitness = pop_fitness(NP);
                  best_mem_Met_Exp_PHHT = pop_mem_Met_Exp_PHHT(NP);
                  best_mem_CV_TR = pop_mem_CV_TR(NP);
                  best_mem_CV_PH = pop_mem_CV_PH(NP);
                  best_mem_MD_TP = pop_mem_MD_TP(NP);
                  best_mem_MD_PHCA = pop_mem_MD_PHCA(NP);
                  best_mem_MD_TRCA = pop_mem_MD_TRCA(NP);                  
                  best_mem_MD_PHHT = pop_mem_MD_PHHT(NP); 
                  best_mem_MD_TRHT = pop_mem_MD_TRHT(NP);                   
                  best_mem_Met_PHHT = pop_mem_Met_PHHT(NP);
                  best_mem_rxn_PHHT = pop_mem_rxn_PHHT(NP);
                  best_mem_Met_PHCA = pop_mem_Met_PHCA(NP);
                  best_mem_rxn_PHCA = pop_mem_rxn_PHCA(NP);
                  best_mem_Met_TRCA = pop_mem_Met_TRCA(NP);
                  best_mem_rxn_TRCA = pop_mem_rxn_TRCA(NP);                  
                  best_mem_Met_TRHT = pop_mem_Met_TRHT(NP);
                  best_mem_rxn_TRHT = pop_mem_rxn_TRHT(NP););
        index_migration = 0;););

*---- count for the forced migration -------------------------------------------
    if((sum(Dim_BI, (bestmemit_XB(Dim_BI) <> bestmem_XB(Dim_BI)) = 1) +
        sum(Dim_XR, (bestmemit_XI(Dim_XR) <> bestmem_XI(Dim_XR)) = 1)) > 0,
        index_migration = 0;
        bestmemit_XB(Dim_BI) = bestmem_XB(Dim_BI);
        bestmemit_XI(Dim_XIR) = bestmem_XI(Dim_XIR);
*----- store the best solution if it is different from the previous iteration --
        itermax_DynSubset2(itermax) = yes ;
        store_bestmem_XI(itermax_DynSubset2(itermax), Dim_XIR) = bestmem_XI(Dim_XIR);
        store_bestmem_XB(itermax_DynSubset2(itermax), Dim_BI) = bestmem_XB(Dim_BI);
        store_best_mem_sumz(itermax_DynSubset2(itermax)) = best_Mem_sumZ;
        store_best_fitness(itermax_DynSubset2(itermax)) = best_fitness;
        store_best_constraint(itermax_DynSubset2(itermax)) = best_constraint; 
*        store_best_FMObj_inner_TR(itermax_DynSubset2(itermax), objectSet) = best_FMObj_inner_TR(ObjectSet);
*        store_best_FMObj_inner_PH(itermax_DynSubset2(itermax), objectSet) = best_FMObj_inner_PH(ObjectSet);
        store_best_FMObj_outer_TR(itermax_DynSubset2(itermax), objectSet) = best_FMObj_outer_TR(ObjectSet);
        store_best_FMObj_outer_PH(itermax_DynSubset2(itermax), objectSet) = best_FMObj_outer_PH(ObjectSet); 
        store_best_mem_Met_Exp_PHHT(itermax_DynSubset2(itermax)) = best_mem_Met_Exp_PHHT;
        store_best_mem_CV_TR(itermax_DynSubset2(itermax)) = best_mem_CV_TR;
        store_best_mem_CV_PH(itermax_DynSubset2(itermax)) = best_mem_CV_PH;
        store_best_mem_MD_TP(itermax_DynSubset2(itermax)) = best_mem_MD_TP;
        store_best_mem_rxn_PHHT(itermax_DynSubset2(itermax)) = best_mem_rxn_PHHT;
        store_best_mem_Met_PHHT(itermax_DynSubset2(itermax)) = best_mem_Met_PHHT;
        store_best_mem_rxn_PHCA(itermax_DynSubset2(itermax)) = best_mem_rxn_PHCA;
        store_best_mem_Met_PHCA(itermax_DynSubset2(itermax)) = best_mem_Met_PHCA;
        store_best_mem_rxn_TRCA(itermax_DynSubset2(itermax)) = best_mem_rxn_TRCA;
        store_best_mem_Met_TRCA(itermax_DynSubset2(itermax)) = best_mem_Met_TRCA;         
        store_best_mem_rxn_TRHT(itermax_DynSubset2(itermax)) = best_mem_rxn_TRHT;
        store_best_mem_Met_TRHT(itermax_DynSubset2(itermax)) = best_mem_Met_TRHT;
        store_best_mem_MD_PHCA(itermax_DynSubset2(itermax)) = best_mem_MD_PHCA;
        store_best_mem_MD_TRCA(itermax_DynSubset2(itermax)) = best_mem_MD_TRCA;        
        store_best_mem_MD_PHHT(itermax_DynSubset2(itermax)) = best_mem_MD_PHHT; 
        store_best_mem_MD_TRHT(itermax_DynSubset2(itermax)) = best_mem_MD_TRHT;
    else
        index_migration = index_migration + 1;);
*---- end of migration ---------------------------------------------------------

*---- peanlty parameter updating -----------------------------------------------
    if (ord(itermax) > iter_penalty,
        penalty $ (best_constraint >= tol_constraint) = penalty_update_ratio * penalty;
        number_penalty = number_penalty + 1;
        iter_penalty = number_penalty  * iter_penalty0;);
*------------------------------------------------------------------------------- 
);
*---- end of MIHDE computation -------------------------------------------------
endTime = jnow;
elapsedTime = (endTime - startTime) * 86400 ;

* assign teh best regulation strength parameter
best_TR_Reg_Factor = bestmem_XI("RSP1");

****** write a solution report in CSV and spawn Excel to view it ************************************************************************************
file result1 /%ReportData%%outputFilename1%.csv/;
result1.pc = 5;  result1.ps = 130;  result1.pw = 5000; result1.nr = 0; result1.nz = 1.0e-20;
put result1;
put system.title /;
put "Date", put system.date, " ", "Time", system.time;
put /;
put /; put "Selected solver:", system.Sstring; put /;
put /; put "========== Input information for HDE solver =========="; put /;
put "NP"; put "itermax"; put "Method_1"; put "Method_4"; put "method_5"; put "method_S"; put "method_6";
put "VTR"; put "VTR_G"; put "F_XLB"; put "F_XUB"; put "F_eps"; put "CR_eps"; put "epsilon_ratio"; put "epsilon1";
put "strategy"; put "penalty"; put "penalty_update_ratio"; put "nPenalty_update"; put "tol_eps"; put /;
put card(NP):10:4; put card(itermax):10:4; put Method_1; put Method_4; put Method_5; put method_S;
put method_6; put VTR:10:4; put VTR_G:10:4; put F_XLB:10:4; put F_XUB:10:4; put F_eps:10:4; 
put CR_eps:10:4; put epsilon_ratio:10:4; put epsilon1:10:4; put strategy:10:4; put penalty:10:4;
put penalty_update_ratio:10:4; put nPenalty_update:10:4; put tol_eps:10:4; put /;

put /; put "flag_uptake"; put "flag_secretion"; put "flag_DM_sink"; put "flag_uptake_demand"; put "flag_BioComp"; put /;
put flag_uptake; put flag_secretion; put flag_DM_sink; put flag_uptake_demand; put flag_BioComp; put /;

put /; put "index_sumZ = (1, 21, 22, 23, 24, 41, 42) for fitnes evaluation"; put /;
*----- fitness evaluation ---------------------------------------------------------------------------------------------------------------------------
* Metabolic deviation (dissimilarity) for PH model to CA template
put "best_mem_MD_PHCA = ((best_mem_rxn_PHCA + best_mem_Met_PHCA)/2 + min(best_mem_rxn_PHCA, best_mem_Met_PHCA))/2;"; put/;

* Metabolic deviation (similarity) for PH model to HT template
put "best_mem_MD_PHHT = ((best_mem_rxn_PHHT + best_mem_Met_PHHT)/2 + min(best_mem_rxn_PHHT, best_mem_Met_PHHT))/2;"; put/;

* Metabolic deviation (similarity) for TR model to HT template
put "best_mem_MD_TRHT = ((best_mem_rxn_TRHT + best_mem_Met_TRHT)/2 + min(best_mem_rxn_TRHT, best_mem_Met_TRHT))/2;"; put/;

* Metabolic deviation (dissimilarity) for TR model to CA template
put "best_mem_MD_TRCA = ((best_mem_rxn_TRCA + best_mem_Met_TRCA)/2 + min(best_mem_rxn_TRCA, best_mem_Met_TRCA))/2;"; put/;

* Metabolic deviation of fuzzy dissimilarity and similarity for PHCA, TRCA, TRHT, and PHHT
put "best_mem_MD_TP $ (index_sumz = 1 or index_sumz = 21 or index_sumz = 22) ="; put/;
put "                 ((best_mem_MD_PHCA + best_mem_MD_PHHT)/2 +"; put/;
put "                   min(best_mem_MD_PHCA, best_mem_MD_PHHT))/2;"; put/;

put "best_mem_MD_TP $ (index_sumz = 41 or index_sumz = 42) ="; put/;
put "                 ((best_mem_MD_PHCA + best_mem_MD_PHHT + best_mem_MD_TRHT + best_mem_MD_TRCA)/4 +"; put/;
put "                   min(best_mem_MD_PHCA, best_mem_MD_PHHT, best_mem_MD_TRHT, best_mem_MD_TRCA))/2;"; put/;
* Metabolic deviation of fuzzy similarity for TRHT, and PHHT
put "best_mem_MD_TP $ (index_sumz = 23 or index_sumz = 24) = ((best_mem_MD_TRHT + best_mem_MD_PHHT)/2 +"; put /;
put "                                                             min(best_mem_MD_TRHT, best_mem_MD_PHHT))/2;"; put /;
*----- prioity fitness evaluation ----------------------------------------------
put "best_constraint = constraint_FBA_TR + constraint_UFD_TR + contraint_FBA_PH + constraint_UFD_PH;"; put /;
put "best_fitness $ (index_sumZ = 1) = mem_PriObj_Outer_TR;"; put/;
put "best_fitness $ (index_sumZ = 21 or index_sumZ = 23 or index_sumz = 41) = (best_mem_CV_TR +"; put /;
put "                                   min(best_mem_CV_TR, best_mem_CV_PH, best_mem_MD_TP))/2;"; put/;
put "best_fitness $ (index_sumZ = 22 or index_sumZ = 24 or index_sumz = 42) = ((best_mem_CV_TR + best_mem_CV_PH)/2 +"; put/;
put "                                                        min(best_mem_CV_TR, best_mem_CV_PH, best_mem_MD_TP))/2;"; put/;
put "best_fitness = best_fitness - best_constraint;"; put /;
put "best_fitness $ (flag_sumZ = 1) = best_fitness + best_mem_sumZ;);"; put/;
*----------------------------------------------------------------------------------------------------------------------------------------------------
put /; put "index_sumZ"; put index_sumZ; put "flag_sumZ"; put flag_sumZ; put /;

put /; put "No. of species, reacions, candidate enzymes, candidate_rxn groups and excluded_candidate_enz in the problem:"; put /;
put "No. species"; put "No. reactions"; put "species_CA"; put "species_HT"; put "transport_rxn"; put "exchange_rxn"; put "No. enzymes";
put "enzymes_CA"; put "enzymes_HT"; put "genes"; put "genes_CA"; put "genes_HT"; put "Candidate_enz";  put "excluded_candidate_Enz_g1";
put "excluded_candidate_Enz"; put "feasible_enz"; put "transport_enz"; put "Met_NonGPR_enz"; put "exchange_enz"; put "Dim_XIR"; put "Dim_XI"; put "Dim_XR"; put /;
put card(species); put card(reactions); put (card(species) - card(species_NHT)); put (card(species) - card(species_NCA)); put card(transport_rxn);
put card(exchange_rxn); put card(enzymes); put (card(enzymes) - card(enzymes_NHT));  put (card(enzymes) - card(enzymes_NCA));
put card(genes); put (card(genes) - card(genes_NHT)); put (card(genes) - card(genes_NCA)); put card(Dim_BI);
put card(excluded_candidate_Enz_g1); put card(excluded_candidate_Enz); put card(feasible_enz); put card(transport_enz);
put card(Met_NonGPR_enz); put card(exchange_enz); put card(Dim_XIR); put card(Dim_XI); put card(Dim_XR); put /;

put /;
put "Target"; put "HT_target_level_LB"; put "HT_target_level_UB"; put " "; put "CA_target_level_LB"; put "CA_target_level_UB";  put /;
loop(targetSet, put targetSet.tl; put HT_target_level_LB(targetSet):10:4; put HT_target_level_UB(targetSet):10:4; put " ";
     put CA_target_level_LB(targetSet):10:4; put CA_target_level_UB(targetSet):10:4; put /;);

put /; put "weighting factor for rxn with HC, MC, NC and OT assigned by the user";
put /; put "Weight_factor_Rxn_HC"; put "Weight_factor_Rxn_MC"; put "Weight_factor_Rxn_NC"; put "Weight_factor_Rxn_OT"; 
put /; put Weight_factor_Rxn_HC; put Weight_factor_Rxn_MC; put Weight_factor_Rxn_NC; put Weight_factor_Rxn_OT; put /;

put /; put "Weighting factors for mem_objvalue_FBA of CA, HT, TR and PH models"; put /;
put "CA_Weight_mem_obj_FBA"; for(i_loop =1 to sum(objectset, (CA_Weight_mem_obj_FBA(objectset) > 0) = 1) - 1, put " ";);
put "HT_Weight_mem_obj_FBA"; for(i_loop =1 to sum(objectset, (HT_Weight_mem_obj_FBA(objectset) > 0) = 1) - 1, put " ";);
put "TR_Weight_mem_obj_FBA"; for(i_loop =1 to sum(objectset, (TR_Weight_mem_obj_FBA(objectset) > 0) = 1) - 1, put " ";);
put "PH_Weight_mem_obj_FBA"; for(i_loop =1 to sum(objectset, (PH_Weight_mem_obj_FBA(objectset) > 0) = 1) - 1, put " ";); put /;
loop(ObjectSet $ (CA_Weight_mem_obj_FBA(ObjectSet) > 0), put objectset.tl:0;); 
loop(ObjectSet $ (HT_Weight_mem_obj_FBA(ObjectSet) > 0), put objectset.tl:0;);
loop(ObjectSet $ (TR_Weight_mem_obj_FBA(ObjectSet) > 0), put objectset.tl:0;);
loop(ObjectSet $ (PH_Weight_mem_obj_FBA(ObjectSet) > 0), put objectset.tl:0;); put /;
loop(ObjectSet $ (CA_Weight_mem_obj_FBA(ObjectSet) > 0), put CA_Weight_mem_obj_FBA(ObjectSet):10:4;);
loop(ObjectSet $ (HT_Weight_mem_obj_FBA(ObjectSet) > 0), put HT_Weight_mem_obj_FBA(ObjectSet):10:4;);
loop(ObjectSet $ (TR_Weight_mem_obj_FBA(ObjectSet) > 0), put TR_Weight_mem_obj_FBA(ObjectSet):10:4;);
loop(ObjectSet $ (PH_Weight_mem_obj_FBA(ObjectSet) > 0), put PH_Weight_mem_obj_FBA(ObjectSet):10:4;); put /;

put /; put "UpDOwnKO_min_g1"; put "UpDownKO_max_g1"; put "UpDOwnKO_min_g2"; put "UpDownKO_max_g2"; put "flux_bounded_ratio";
put "mem_bound_ratio"; put "UB_zero"; put /;
       put %No_UPDownKO_min_g1%; put put %No_UPDownKO_max_g1%; put %No_UPDownKO_min_g2%; put %No_UPDownKO_max_g2%; put flux_bounded_ratio:10:4;
       put mem_bound_ratio:10:4; put UB_zero:10:4; put /;

put /; put "Synthesis vf and vb reactions in the fuzzy multiobjective optimization problem"; put /;
loop(objectset,
     put "Objectset"; put "Synthesis vf reactions"; put /;
     put objectset.tl; 
     number = 0; 
     loop(reactions $ (syn_vf_rxn(objectset, reactions)), put reactions.tl; number = number + 1;
          if(number = 20, put " "; put /; number = 0;);); put /;

     number = 0; put " "; put "Synthesis vb reactions:"; put /;
     loop(reactions $ (syn_vb_rxn(objectset, reactions)), put reactions.tl; number = number + 1;
          if(number = 20, put " "; put /; number = 0;);); put /;);

put /;
put "########## Optimal targets determined by NHDE using the tissue-specific GSMM ##########"; put /;
put "===== Best fitness, constraint value, migrations, function calls and CPU time solved by Nested HDE"; put /;
put "restrum"; put "nfeval"; put "nfeval_FBA_max"; put "nfeval_UFD_min"; put "CPU time"; put /;
put restnum; put nfeval; put nfeval_FBA_max; put nfeval_UFD_min; put elapsedTime:10:4; put /;

put /;
put "Best_regulation strength parametrer for up/down regulation (C)"; put /;
put best_TR_Reg_Factor:10:4; put /;
put /; put "Coding strategy"; put /;
put "(z_HDE = 1) Up-regulated SynRate: [basal_vf + C (vf_UB - basal_vf)] <= vf <= vf_UB and basal_vb + C (vb_UB - basal_vb)] <= vb <= vb_UB"; put /;
put "(z_HDE = 2) Down-regulated SynRate: vf_LB <= vf <= [basal_vf + c(vf_LB - vf_basal)] and vb_LB <= vb <= [basal_vb + c(vb_LB - vb_basal)]"; put /;
put "(z_HDE = 3) Knockout SynRate: vf = vb = 0"; put /;

put /; put "========== Best fitness, cell mortality, cell viability and metabolic deviation for PHCA, TRCA, PHHT and TRHT obtained by NHDE =========="; put /;
put " "; put "Cell mortality"; put "Cell viability"; put "Metabolic deviation"; put "Dissimilarity of PHCA and TRCA"; put " ";
put "Similarity of PHHT and TRHT"; put " "; put "TR_outer_obj";
for(i_loop = 1 to (card(FmaxObj_Outer_TR) + card(FminObj_Outer_TR) - 1), put " ";); put "PH_outer_obj";
for(i_loop = 1 to (card(FmaxObj_Outer_PH) + card(FminObj_Outer_PH) - 1), put " ";); put "FBA_CA_inner_obj";
for(i_loop = 1 to (card(FmaxObj_inner_TR) + card(FminObj_inner_TR) - 1), put " ";); put "FBA_HT_inner_obj"; put /;
put "best_fitness"; put "best_mem_CV_TR"; put "best_mem_CV_PH"; put "best_mem_MD_TP"; put "best_mem_MD_PHCA"; put "best_mem_MD_TRCA";
put "best_mem_MD_PHHT"; put "best_mem_MD_TRHT"; 
loop(objectSet $ (FmaxObj_Outer_TR(ObjectSet) or FminObj_Outer_TR(ObjectSet)), put ObjectSet.tl:0;);
loop(objectSet $ (FmaxObj_Outer_PH(ObjectSet) or FminObj_Outer_PH(ObjectSet)), put ObjectSet.tl:0;);
loop(objectSet $ (FmaxObj_inner_TR(ObjectSet) or FminObj_inner_TR(ObjectSet)), put ObjectSet.tl:0;);
loop(objectSet $ (FmaxObj_inner_PH(ObjectSet) or FminObj_inner_PH(ObjectSet)), put ObjectSet.tl:0;);
put "best_mem_Met_PHCA"; put "best_mem_rxn_PHCA"; put "best_mem_Met_TRCA"; put "best_mem_rxn_TRCA"; put "best_mem_Met_PHHT";
put "best_mem_rxn_PHHT"; put "best_mem_Met_TRHT"; put "best_mem_rxn_TRHT"; put "best_mem_Met_Exp_PHHT"; put "best_sumZ";
put "best_constraint"; put "best_modelstat"; put /;
put best_fitness:10:4; put best_mem_CV_TR:10:4; put best_mem_CV_PH:10:4; put best_mem_MD_TP:10:4; put best_mem_MD_PHCA:10:4;
put best_mem_MD_TRCA:10:4; put best_mem_MD_PHHT:10:4; put best_mem_MD_TRHT:10:4;
loop(objectSet $ (FmaxObj_Outer_TR(ObjectSet) or FminObj_Outer_TR(ObjectSet)), put best_FMObj_outer_TR(ObjectSet):10:4;);
loop(objectSet $ (FmaxObj_Outer_PH(ObjectSet) or FminObj_Outer_PH(ObjectSet)), put best_FMObj_outer_PH(ObjectSet):10:4;);
loop(objectSet $ (FmaxObj_inner_TR(ObjectSet) or FminObj_inner_TR(ObjectSet)), put best_FMObj_inner_TR(ObjectSet):10:4;);
loop(objectSet $ (FmaxObj_inner_PH(ObjectSet) or FminObj_inner_PH(ObjectSet)), put best_FMObj_inner_PH(ObjectSet):10:4;);
put best_mem_Met_PHCA:10:4; put best_mem_rxn_PHCA:10:4; put best_mem_Met_TRCA:10:4; put best_mem_rxn_TRCA:10:4;
put best_mem_Met_PHHT:10:4; put best_mem_rxn_PHHT:10:4; put best_mem_Met_TRHT:10:4; put best_mem_rxn_TRHT:10:4;
put best_mem_Met_Exp_PHHT:10:4; put (sum(Dim_BI, (bestmem_XB(Dim_BI) > 0) = 1)); put best_constraint:10:4; put best_modelstat; put /;
*****************************************************************************************************************************************************
*****************************************************************************************************************************************************

*%%%%% the user can modify the following procedures %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
***** assign reactions and species in FMO CA models as dynamic sets *********************************************************************************   
dyn_reactions(reactions) = no;
dyn_species(species) = no;
dyn_BioComp(biocompound) = no;
dyn_irrev_rxn(reactions) = no;
dyn_rev_rxn(reactions) = no;
dyn_exchange_rxn(reactions) = no;
dyn_objectSet(objectSet) = no;
dyn_Fmax_Object(ObjectSet) = no;
dyn_Fmin_Object(ObjectSet) = no;
dyn_priority_obj(ObjectSet) = no;
dyn_obj_outer(objectSet) = no;
dyn_Fmax_Obj_outer(ObjectSet) = no;
dyn_Fmin_Obj_outer(ObjectSet) = no;
dyn_priority_outer(ObjectSet) = no;    
**** objectives used in inner optimization problem
dyn_reactions(reactions) $ (not reactions_NCA(reactions)) = yes;
dyn_species(species) $ (not species_NCA(species)) = yes;
dyn_BioComp(biocompound) $ (not biocompound_NCA(biocompound)) = yes;
dyn_irrev_rxn(reactions) $ (not reactions_NCA(reactions) and irrev_rxn(reactions)) = yes;
dyn_rev_rxn(reactions) $ (not reactions_NCA(reactions) and rev_rxn(reactions)) = yes;
dyn_exchange_rxn(reactions) $ (not reactions_NCA(reactions) and exchange_rxn(reactions)) = yes;
dyn_Fmax_Object(ObjectSet) $ (FmaxObj_inner_TR(ObjectSet)) = yes;
dyn_Fmin_Object(ObjectSet) $ (FminObj_inner_TR(ObjectSet)) = yes;
dyn_objectSet(objectSet) = dyn_Fmax_Object(ObjectSet) + dyn_Fmin_Object(ObjectSet);
dyn_priority_obj(ObjectSet) $ (PriObj_inner_TR(ObjectSet)) = yes;
No_priority_obj = card(PriObj_inner_TR);
**** objectives used in outer optimization problem     
dyn_Fmax_Obj_outer(ObjectSet) $ (FmaxObj_Outer_TR(ObjectSet)) = yes;
dyn_Fmin_Obj_outer(ObjectSet) $ (FminObj_Outer_TR(ObjectSet)) = yes;
dyn_obj_outer(objectSet) = dyn_Fmax_Obj_outer(ObjectSet) + dyn_Fmin_Obj_outer(ObjectSet);
dyn_priority_outer(ObjectSet) $ (PriObj_Outer_TR(ObjectSet)) = yes;
No_priority_outer = card(PriObj_Outer_TR);
*****************************************************************************************************************************************************

***** Set the weighting factors and limits for FBA objectives ******************
basal_vf(reactions) = 0;
basal_vb(reactions) = 0;
basal_vf(reactions) = CA_vf_UFD(reactions);
basal_vb(reactions) = CA_vb_UFD(reactions);

*--- reset the oringinal bounds for all fluxes ------------------------------------------------------------------------------------------------------
FluxBound_vf_LB(reactions) = tmp_FluxBound_vf_LB(reactions);
FluxBound_vb_LB(reactions) = tmp_FluxBound_vb_LB(reactions);
FluxBound_vf_UB(reactions) = tmp_FluxBound_vf_UB(reactions);
FluxBound_vb_UB(reactions) = tmp_FluxBound_vb_UB(reactions);
*----------------------------------------------------------------------------------------------------------------------------------------------------

*---- restrictions for the lower and upper bounds of fluxes --------------------
vf.lo(reactions) = FluxBound_vf_LB(reactions);
vf.up(reactions) = FluxBound_vf_UB(reactions);
vb.lo(reactions) = FluxBound_vb_LB(reactions);
vb.up(reactions) = FluxBound_vb_UB(reactions);

*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
z_isozyme_rxn_enz(reactions, enzymes) = no;
z_isozyme_rxn(reactions) = no;
z_HDE_tmp(reactions, Enzymes) = 0;
Regulated_Rxn_v(reactions) = NO;
dyn_Reg_ExRxn(reactions) = no;
loop(Dim_BI $ (bestmem_XB(Dim_BI) >= 1),
     Regulated_rxn_v(reactions) $ (enzyme_Reg_rxn_v(Dim_BI, reactions) and dyn_reactions(reactions)) = yes;

***** assign the regulated reactions to be some levels *************************
* up regulated v
     if(bestmem_XB(Dim_BI) = 1,
        vf.lo(Regulated_rxn_v(reactions)) = basal_vf(reactions) + best_TR_Reg_factor * (FluxBound_vf_UB(reactions) - basal_vf(reactions));
        vf.up(Regulated_rxn_v(reactions)) = FluxBound_vf_UB(reactions);
        vb.lo(Regulated_rxn_v(reactions)) = FluxBound_vb_LB(reactions);
        vb.up(Regulated_rxn_v(reactions)) = basal_vb(reactions) + best_TR_Reg_factor * (FluxBound_vb_LB(reactions) - basal_vb(reactions)););

* down regulated v
     if(bestmem_XB(Dim_BI) = 2,
        vf.lo(Regulated_rxn_v(reactions)) = FluxBound_vf_LB(reactions);
        vf.up(Regulated_rxn_v(reactions)) = basal_vf(reactions) + best_TR_Reg_factor * (FluxBound_vf_LB(reactions) - basal_vf(reactions));
        vb.lo(Regulated_rxn_v(reactions)) = basal_vb(reactions) + best_TR_Reg_factor * (FluxBound_vb_UB(reactions) - basal_vb(reactions));
        vb.up(Regulated_rxn_v(reactions)) = FluxBound_vb_UB(reactions);

*---- the down regulated reaction by Dim_BI is dominatd by other isozymes ------
        vf.lo(reactions) $ (Regulated_rxn_v(reactions) and isozyme_rxn(reactions)) = (1 - flux_bounded_ratio) * basal_vf(reactions);
        vf.up(reactions) $ (Regulated_rxn_v(reactions) and isozyme_rxn(reactions)) = (1 + flux_bounded_ratio) * basal_vf(reactions);
        vb.lo(reactions) $ (Regulated_rxn_v(reactions) and isozyme_rxn(reactions)) = (1 - flux_bounded_ratio) * basal_vb(reactions);
        vb.up(reactions) $ (Regulated_rxn_v(reactions) and isozyme_rxn(reactions)) = (1 + flux_bounded_ratio) * basal_vb(reactions););
*-------------------------------------------------------------------------------
*---- knockout vf and vb -------------------------------------------------------
     if(bestmem_XB(Dim_BI) = 3,
        vf.fx(Regulated_rxn_v(reactions)) = 0;
        vb.fx(Regulated_rxn_v(reactions)) = 0;

*---- the KO reaction by Dim_BI is dominatd by other isozymes ------------------
        vf.lo(reactions) $ (Regulated_rxn_v(reactions) and isozyme_rxn(reactions)) = (1 - flux_bounded_ratio) * basal_vf(reactions);
        vf.up(reactions) $ (Regulated_rxn_v(reactions) and isozyme_rxn(reactions)) = (1 + flux_bounded_ratio) * basal_vf(reactions);
        vb.lo(reactions) $ (Regulated_rxn_v(reactions) and isozyme_rxn(reactions)) = (1 - flux_bounded_ratio) * basal_vb(reactions);
        vb.up(reactions) $ (Regulated_rxn_v(reactions) and isozyme_rxn(reactions)) = (1 + flux_bounded_ratio) * basal_vb(reactions););
*-------------------------------------------------------------------------------
*---- reaction is regulated by isozyme -----------------------------------------
      z_isozyme_rxn(reactions) $ (Regulated_rxn_v(reactions) and isozyme_rxn(reactions)) = yes;
      z_isozyme_rxn_enz(reactions, Dim_BI) $ (Regulated_rxn_v(reactions) and isozyme_rxn(reactions)) = yes;
      z_HDE_tmp(reactions, Dim_BI) $ (Regulated_rxn_v(reactions) and isozyme_rxn(reactions)) = bestmem_XB(Dim_BI);
      dyn_Reg_ExRxn(reactions) = dyn_Reg_ExRxn(reactions) + Regulated_rxn_v(reactions);
      Regulated_Rxn_v(reactions) = NO;);

***** Decide the regulated reaction to be up/down/KO if all isozymes are selected by NHDE ***********************************************************
     if((card(Dim_XI) > 1 and sum(reactions $ (z_isozyme_rxn(reactions)), 1) > 0),
         loop(reactions $ (z_isozyme_rxn(reactions) and sum(Dim_BI $ (bestmem_XB(Dim_BI) >= 1 and z_isozyme_rxn_enz(reactions, Dim_BI)), 1) =
                                                        sum(enzymes $ (isozyme_rxn_enz(reactions, enzymes)), 1)),

*---- The reaction is KO if all isozymes are KO, z_HDE_tmp = 3 --------------------------------------------------------------------------------------
              if(sum(Dim_BI $ (bestmem_XB(Dim_BI) >= 1), z_HDE_tmp(reactions, Dim_BI)) = 3 * sum(Dim_BI $ (bestmem_XB(Dim_BI) >= 1 and z_isozyme_rxn_enz(reactions, Dim_BI)), 1),
                 vf.fx(reactions) $ (z_isozyme_rxn(reactions)) = 0;
                 vb.fx(reactions) $ (z_isozyme_rxn(reactions)) = 0;);

*------ reaction is down/up, (set to down firstly) if one of the isozymes is down/up --------------------------------------------------------------
              if(sum(Dim_BI $ (bestmem_XB(Dim_BI) >= 1), z_HDE_tmp(reactions, Dim_BI)) < 3 * sum(Dim_BI $ (bestmem_XB(Dim_BI) >= 1 and z_isozyme_rxn_enz(reactions, Dim_BI)), 1),
                 vf.lo(reactions) $ (z_isozyme_rxn(reactions)) = FluxBound_vf_LB(reactions);
                 vf.up(reactions) $ (z_isozyme_rxn(reactions)) = basal_vf(reactions) + best_TR_Reg_factor *
                                                                (FluxBound_vf_LB(reactions) - basal_vf(reactions));
                 vb.lo(reactions) $ (z_isozyme_rxn(reactions)) = basal_vb(reactions) + best_TR_Reg_factor *
                                                                (FluxBound_vb_UB(reactions) - basal_vb(reactions));
                 vb.up(reactions) $ (z_isozyme_rxn(reactions)) = FluxBound_vb_UB(reactions););

*---- The above reaction is reassigned to up, if one of the isozymes is up --------------------------------------------------------------------------
             loop(Dim_BI $ (bestmem_XB(Dim_BI) >= 1 and z_HDE_tmp(reactions, Dim_BI) = 1 and z_isozyme_rxn(reactions)),
                  vf.lo(reactions) = basal_vf(reactions) + best_TR_Reg_factor * (FluxBound_vf_UB(reactions) - basal_vf(reactions));
                  vf.up(reactions) = FluxBound_vf_UB(reactions);
                  vb.lo(reactions) = FluxBound_vb_LB(reactions);
                  vb.up(reactions) = basal_vb(reactions) + best_TR_Reg_factor * (FluxBound_vb_LB(reactions) - basal_vb(reactions));
                  break $ (z_HDE_tmp(reactions, Dim_BI) = 1););
         );
     );
*----------------------------------------------------------------------------------------------------------------------------------------------------
*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

* assign vb = 0 for the irreversible fluxes
vb.lo(irrev_rxn) = 0;
vb.up(irrev_rxn) = 0;
vb.fx(irrev_rxn) = 0;
vb.fx(DM_sink_rxn(reactions)) $ (flag_DM_sink = 1) = 0;
vf.lo(irrev_vb_rxn(reactions)) = 0;
vf.up(irrev_vb_rxn(reactions)) = 0;
vf.fx(irrev_vb_rxn(reactions)) = 0;

* assign the demanded uptake/secretion reactions
vf.fx(uptake_demand) = 0;
vb.fx(secretion_demand) = 0;
vb.fx(uptake_fixed) = FluxBound_vb_LB(uptake_fixed);

* irreversible uptake_rxn and secretion_rxn
vf.fx(uptake_rxn(reactions)) $ (flag_uptake = 1 and not dyn_Reg_ExRxn(reactions)) = 0;
vb.fx(secretion_rxn(reactions)) $ (flag_secretion = 1 and not dyn_Reg_ExRxn(reactions)) = 0;

vf.fx(uptake_demand(reactions)) $ (card(uptake_demand) > 0) = 0;
vb.fx(secretion_demand(reactions)) $ (card(secretion_demand) > 0) = 0;
********************************************************************************
*** Assign vf > 0 and vb = 0 for the Specific_rxn_vf --------------------------------
if(card(TR_Specific_rxn_vf) > 0,
   vf.lo(TR_Specific_rxn_vf) =  TR_Specific_rxn_vf_LB(TR_Specific_rxn_vf);
   vf.up(TR_Specific_rxn_vf) =  TR_Specific_rxn_vf_UB(TR_Specific_rxn_vf);
   vb.lo(TR_Specific_rxn_vf) =  0;
   vb.up(TR_Specific_rxn_vf) =  0;
   vb.fx(TR_Specific_rxn_vf) =  0;);
********************************************************************************
*** Assign vf = 0 and vb > 0 for the Specific_rxn_vb --------------------------------
if(card(TR_Specific_rxn_vb) > 0,
   vb.lo(TR_Specific_rxn_vb) =  TR_Specific_rxn_vb_LB(TR_Specific_rxn_vb);
   vb.up(TR_Specific_rxn_vb) =  TR_Specific_rxn_vb_UB(TR_Specific_rxn_vb);
   vf.lo(TR_Specific_rxn_vb) =  0;
   vf.up(TR_Specific_rxn_vb) =  0;
   vf.fx(TR_Specific_rxn_vb) =  0;);
*** Assign vf > 0 and vb > 0 for the Specific_rxn_vfvb -------------------------------
if(card(TR_Specific_rxn_vfvb) > 0,
   vf.lo(TR_Specific_rxn_vfvb) =  TR_Specific_rxn_vf_LB(TR_Specific_rxn_vfvb);
   vf.up(TR_Specific_rxn_vfvb) =  TR_Specific_rxn_vf_UB(TR_Specific_rxn_vfvb);
   vb.lo(TR_Specific_rxn_vfvb) =  TR_Specific_rxn_vb_LB(TR_Specific_rxn_vfvb);
   vb.up(TR_Specific_rxn_vfvb) =  TR_Specific_rxn_vb_UB(TR_Specific_rxn_vfvb););    
******************************************************************************* 
***** Set the weighting factors and limits for FBA objectives ******************
*----- compute the lower and upper bounds for the target reactions
target_limit_LB(targetSet) = 0;
target_limit_UB(targetSet) = 0;
target_limit_LB(targetSet) = CA_target_level_LB(targetSet);
target_limit_UB(targetSet) = CA_target_level_UB(targetSet);
MultiObjValue_FBA.lo(ObjectSet) = MultiObjValue_min(objectSet);
MultiObjValue_FBA.up(ObjectSet) = MultiObjValue_max(objectSet);
mem_objvalue_FBA.lo(objectSet) = 0;
mem_objvalue_FBA.up(objectSet) = 1;
TR_MultiObjvalue_Optim(objectset) = 0;
Lambda.lo = 0;
Lambda.up = 1;
*-------------------------------------------------------------------------------
* set weightin factor for mem_objvalue_FBA for CA ------------------------------
Weight_Lambda(ObjectSet) = 0;
Weight_Lambda(ObjectSet) = TR_Weight_mem_obj_FBA(ObjectSet);
*-------------------------------------------------------------------------------
*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
***** best FBA Problem ******************************************************************************************************************************
* Determine the normal flux distribution by solving the Primal FBA Problem
solve FBA_Problem using LP maximizing objValue_FBA ;
TR_FBA_ModelStat = FBA_Problem.modelstat ;
tmp_vf_FBA(reactions) = 0;
tmp_vb_FBA(reactions) = 0;
tmp_vf_FBA(dyn_reactions) = max(vf.l(dyn_reactions), 0);
tmp_vb_FBA(dyn_reactions) = max(vb.l(dyn_reactions), 0);
tmp_MultiObjvalue_Optim(Objectset) = 0;
tmp_MultiObjvalue_Optim(dyn_objectset) = sum(dyn_reactions, coef_CellularObj_vf(dyn_objectset, dyn_reactions) * tmp_vf_FBA(dyn_reactions)) +
                                         sum(dyn_reactions, coef_CellularObj_vb(dyn_objectset, dyn_reactions) * tmp_vb_FBA(dyn_reactions));
TR_MultiObjvalue_Optim(dyn_objectset) = tmp_MultiObjvalue_Optim(dyn_objectset);   
best_FMObj_inner_TR(dyn_ObjectSet) = TR_MultiObjvalue_Optim(dyn_objectset);

*----- infesiable solution ----------------------------------------------------
if(TR_FBA_ModelStat > 2,
   best_FMObj_inner_TR(ObjectSet) = 0;
   best_FMObj_inner_PH(ObjectSet) = 0;
   best_FMObj_outer_TR(ObjectSet) = 0;
   best_FMObj_outer_PH(ObjectSet) = 0;        
   best_mem_Met_Exp_PHHT = 0;
   best_mem_CV_TR = 0;
   best_mem_CV_PH = 0;
   best_mem_MD_TP = 0;
   best_mem_Met_PHHT = 0;
   best_mem_rxn_PHHT = 0;
   best_mem_Met_PHCA = 0;
   best_mem_rxn_PHCA = 0;
   best_mem_Met_TRCA = 0;
   best_mem_rxn_TRCA = 0;   
   best_mem_Met_TRHT = 0;
   best_mem_rxn_TRHT = 0;
   constraint_h(Dim_h) = 0;
   constraint_h(Dim_h) = sum(reactions, S_Matrix(Dim_h, reactions) * (vf.l(reactions) - vb.l(reactions)));
   tmp_constraint_h = sum(dyn_Fmin_Object, mem_objvalue_FBA.l(dyn_Fmin_Object) -
                         (MultiObjValue_max(dyn_Fmin_Object) - TR_MultiObjvalue_Optim(dyn_Fmin_Object))/
                         (MultiObjValue_max(dyn_Fmin_Object) - MultiObjValue_min(dyn_Fmin_Object))) +
                      sum(dyn_Fmax_Object, mem_objvalue_FBA.l(dyn_Fmax_Object) -
                         (TR_MultiObjvalue_Optim(dyn_Fmax_Object) - MultiObjValue_min(dyn_Fmax_Object))/
                         (MultiObjValue_max(dyn_Fmax_Object) - MultiObjValue_min(dyn_Fmax_Object)));                             
   constraint_g = sum(targetSet, max((target_limit_LB(targetSet) - (vf.l(targetSet) - vb.l(targetSet))), 0)) +
                  sum(targetSet, max(((vf.l(targetSet) - vb.l(targetSet)) - target_limit_UB(targetSet)), 0)) +
                  sum(dyn_ObjectSet, max((Lambda.l - mem_objvalue_FBA.l(dyn_ObjectSet)), 0));   
   constraint_FBA_TR = penalty * (sum(Dim_h, abs(constraint_h(Dim_h)) + abs(tmp_constraint_h)) + constraint_g););
*------------------------------------------------------------------------------

***** best UFD problem *******************************************************************************************************************************
Mem_Obj_FBA_limit(ObjectSet) = 0;
Mem_Obj_FBA_limit(dyn_Fmax_Object) = ((TR_MultiObjvalue_Optim(dyn_Fmax_Object) - MultiObjValue_min(dyn_Fmax_Object))/
                                      (MultiObjValue_max(dyn_Fmax_Object) - MultiObjValue_min(dyn_Fmax_Object)));
                                        
Mem_Obj_FBA_limit(dyn_Fmin_Object) = ((MultiObjValue_max(dyn_Fmin_Object) - TR_MultiObjvalue_Optim(dyn_Fmin_Object))/
                                      (MultiObjValue_max(dyn_Fmin_Object) - MultiObjValue_min(dyn_Fmin_Object)));
Mem_Obj_FBA_limit(dyn_ObjectSet) = max(min( Mem_Obj_FBA_limit(dyn_ObjectSet), 1), 0);
**** assign weighting coefficients for Rxn for computing ObjValue in UFD ****************************************************************************
weight_coef_rxn(reactions) = Weight_factor_Rxn_OT;
weight_coef_rxn(reactions) $ (CA_Reactions_HC(reactions)) = Weight_factor_Rxn_HC;
weight_coef_rxn(reactions) $ (CA_Reactions_MC(reactions)) = Weight_factor_Rxn_MC;
weight_coef_rxn(reactions) $ (CA_Reactions_NC(reactions)) = Weight_factor_Rxn_NC;
*****************************************************************************************************************************************************
*----- compute the lower and upper bounds for the target reactions ------------
target_limit_LB(targetSet) = 0;
target_limit_UB(targetSet) = 0;
target_limit_LB(targetSet) = CA_target_level_LB(targetSet);
target_limit_UB(targetSet) = CA_target_level_UB(targetSet);
MultiObjValue_FBA.lo(ObjectSet) = MultiObjValue_min(objectSet);
MultiObjValue_FBA.up(ObjectSet) = MultiObjValue_max(objectSet);
mem_objvalue_FBA.lo(objectSet) = 0;
mem_objvalue_FBA.up(objectSet) = 1;
*------------------------------------------------------------------------------

TR_vf_UFD(reactions) = 0;
TR_vb_UFD(reactions) = 0;
if(flag_UFD_Obj = 1, solve UFD1_Problem using LP minimizing ObjValue_UFD;);
if(flag_UFD_Obj = 2, solve UFD2_Problem using LP minimizing ObjValue_UFD;);
if(flag_UFD_Obj = 3, solve UFD3_Problem using QCP minimizing ObjValue_UFD;);
if(flag_UFD_Obj = 4, solve UFD4_Problem using QCP minimizing ObjValue_UFD;);
TR_vf_UFD(reactions) = max(vf.l(reactions), 0);
TR_vb_UFD(reactions) = max(vb.l(reactions), 0);
TR_v_UFD(reactions) = TR_vf_UFD(reactions) - TR_vb_UFD(reactions);
TR_UFD_ModelStat = UFD%No_UFD_Obj%_Problem.modelstat;

best_Mem_sumZ $ (flag_sumz < 2) = (sumZ_max - sum(Dim_BI, (bestmem_XB(Dim_BI) > 0) = 1))/(sumZ_max - 1);
best_Mem_sumZ $ (flag_sumz = 2) = sum(Dim_BI, (bestmem_XB(Dim_BI) > 0) = 1)/(sumZ_max - 1);

*---- infeasible solution ------------------------------------------------------
if(TR_UFD_ModelStat > 2,
   best_FMObj_inner_TR(ObjectSet) = 0;
   best_FMObj_inner_PH(ObjectSet) = 0;
   best_FMObj_outer_TR(ObjectSet) = 0;
   best_FMObj_outer_PH(ObjectSet) = 0;           
   best_mem_Met_Exp_PHHT = 0;           
   best_mem_CV_TR = 0;
   best_mem_CV_PH = 0;
   best_mem_MD_TP = 0;
   best_mem_Met_PHHT = 0;
   best_mem_rxn_PHHT = 0;
   best_mem_Met_PHCA = 0;
   best_mem_rxn_PHCA = 0;
   best_mem_Met_TRCA = 0;
   best_mem_rxn_TRCA = 0;   
   best_mem_Met_TRHT = 0;
   best_mem_rxn_TRHT = 0;
   constraint_h(Dim_h) = 0;  
   constraint_h(Dim_h) = sum(reactions, S_Matrix(Dim_h, reactions) * (vf.l(reactions) - vb.l(reactions)));
   tmp_constraint_h = sum(dyn_Fmin_Object, mem_objvalue_FBA.l(dyn_Fmin_Object) -
                         (MultiObjValue_max(dyn_Fmin_Object) - MultiObjValue_FBA.l(dyn_Fmin_Object))/
                         (MultiObjValue_max(dyn_Fmin_Object) - MultiObjValue_min(dyn_Fmin_Object))) +
                      sum(dyn_Fmax_Object, mem_objvalue_FBA.l(dyn_Fmax_Object) -
                         (MultiObjValue_FBA.l(dyn_Fmax_Object) - MultiObjValue_min(dyn_Fmax_Object))/
                         (MultiObjValue_max(dyn_Fmax_Object) - MultiObjValue_min(dyn_Fmax_Object)));                              
   constraint_g = sum(targetSet, max((target_limit_LB(targetSet) - (vf.l(targetSet) - vb.l(targetSet))), 0)) +
                  sum(targetSet, max(((vf.l(targetSet) - vb.l(targetSet)) - target_limit_UB(targetSet)), 0)) +
                  sum(dyn_ObjectSet, max((Mem_Obj_FBA_limit(dyn_ObjectSet) - mem_objvalue_FBA.l(dyn_ObjectSet)), 0));   
   constraint_UFD_TR = penalty * (sum(Dim_h, abs(constraint_h(Dim_h)) + abs(tmp_constraint_h)) + constraint_g););
*-------------------------------------------------------------------------------

if(TR_UFD_ModelStat <= 2,       
**** compute membership grades of fuzzy max and min objectives for outer TR model *******************************************************************
   TR_MultiObjvalue_Optim(Objectset) = 0;
   TR_MultiObjvalue_Optim(dyn_obj_outer) = sum(dyn_reactions, coef_CellularObj_vf(dyn_obj_outer, dyn_reactions) * TR_vf_UFD(dyn_reactions)) +
                                           sum(dyn_reactions, coef_CellularObj_vb(dyn_obj_outer, dyn_reactions) * TR_vb_UFD(dyn_reactions));  
   best_FMObj_outer_TR(dyn_obj_outer) = TR_MultiObjvalue_Optim(dyn_obj_outer);
           
**** compute membership grades of fuzzy max and min objectives for outer TR model *******************************************************************
   Mem_Obj_FBA_limit(ObjectSet) = 0;
   Mem_Obj_FBA_limit(dyn_Fmax_Obj_outer) = (TR_MultiObjvalue_Optim(dyn_Fmax_Obj_outer) - MultiObjValue_min(dyn_Fmax_Obj_outer))/
                                           (MultiObjValue_max(dyn_Fmax_Obj_outer) - MultiObjValue_min(dyn_Fmax_Obj_outer));
   Mem_Obj_FBA_limit(dyn_Fmin_Obj_outer) = (MultiObjValue_max(dyn_Fmin_Obj_outer) - TR_MultiObjvalue_Optim(dyn_Fmin_Obj_outer))/
                                           (MultiObjValue_max(dyn_Fmin_Obj_outer) - MultiObjValue_min(dyn_Fmin_Obj_outer));
   Mem_Obj_FBA_limit(dyn_obj_outer) = max(min( Mem_Obj_FBA_limit(dyn_obj_outer), 1), 0);                                       
   mem_PriObj_Outer_TR = sum(dyn_priority_outer, Mem_Obj_FBA_limit(dyn_priority_outer))/No_priority_outer;
   best_mem_CV_TR = 0.5 * (mem_PriObj_Outer_TR + smin(dyn_obj_outer, Mem_Obj_FBA_limit(dyn_obj_outer)));
   TR_Mem_Obj_FBA_limit(dyn_obj_outer) = Mem_Obj_FBA_limit(dyn_obj_outer);
*****************************************************************************************************************************************************

*=== compute synthesis rate for each species of treated TR model ====================================================================================
   TR_Species_SynRate(species) = 0;
   loop(dyn_species,
        TR_Species_SynRate(dyn_species) = sum(dyn_reactions, S_Matrix(dyn_species, dyn_reactions) $
                                             (S_Matrix(dyn_species, dyn_reactions) > 0) * TR_vf_UFD(dyn_reactions))
                                        - sum(dyn_reactions, S_Matrix(dyn_Species, dyn_reactions) $
                                             (S_Matrix(dyn_species, dyn_reactions) < 0) * TR_vb_UFD(dyn_reactions)););

***** compute synthesis rate for each biocompound of treated TR model ******************************************************************************
   TR_BioComp_SynRate(BioCompound) = 0;
   loop(dyn_BioComp,
        TR_BioComp_SynRate(dyn_BioComp) = sum(dyn_Species $ (BioCompound_species(dyn_BioComp, dyn_Species)),
                                              TR_Species_SynRate(dyn_Species)););

***** compute fuzzy similarity of metabolite-flow and its membership grade for TRHT model ***********************************************************
   L_mem_Met_tmp(biocompound) = 0;
   R_mem_Met_tmp(biocompound) = 0;
   mem_Met_tmp(biocompound) = 0;             
   L_mem_Met_tmp(BioComp_TRHT) $ (HT_BioComp_SynRate(BioComp_TRHT) > 0) =
                                 (TR_BioComp_SynRate(BioComp_TRHT) - HT_MetFlowRate_LB(BioComp_TRHT))/
                                 (HT_BioComp_SynRate(BioComp_TRHT) - HT_MetFlowRate_LB(BioComp_TRHT));                                        
   L_mem_Met_tmp(BioComp_TRHT) $ (HT_BioComp_SynRate(BioComp_TRHT) = 0) = 1;
   R_mem_Met_tmp(BioComp_TRHT) = (HT_MetFlowRate_UB(BioComp_TRHT) - TR_BioComp_SynRate(BioComp_TRHT))/
                                 (HT_MetFlowRate_UB(BioComp_TRHT) - HT_BioComp_SynRate(BioComp_TRHT));
   mem_Met_tmp(BioComp_TRHT) = max(min(L_mem_Met_tmp(BioComp_TRHT), R_mem_Met_tmp(BioComp_TRHT), 1), 0);
   nonzero_Biocomp(biocompound) = no;             
   nonzero_Biocomp(biocompound) $ ((TR_BioComp_SynRate(biocompound) > 0 or
                                    HT_BioComp_SynRate(biocompound) > 0) and BioComp_TRHT(biocompound)) = yes;

   No_nonzero_Biocomp_TRHT = card(nonzero_Biocomp);                                               
   best_mem_Met_TRHT = sum(BioCompound $ (nonzero_Biocomp(biocompound)), mem_Met_tmp(BioCompound))/No_nonzero_Biocomp_TRHT;

*****************************************************************************************************************************************************
***** compute fuzzy similarity of flux and its membership grade for TRHT model **********************************************************************
   L_mem_vf_tmp(reactions) = 0;
   R_mem_vf_tmp(reactions) = 0;
   L_mem_vb_tmp(reactions) = 0;
   R_mem_vb_tmp(reactions) = 0;
   L_mem_vf_tmp(rxn_vf_TRHT) $ (HT_vf_UFD(rxn_vf_TRHT) > 0) =
                               (TR_vf_UFD(rxn_vf_TRHT) - HT_vf_rxn_LB(rxn_vf_TRHT))/
                               (HT_vf_UFD(rxn_vf_TRHT) - HT_vf_rxn_LB(rxn_vf_TRHT));
   L_mem_vf_tmp(rxn_vf_TRHT) $ (HT_vf_UFD(rxn_vf_TRHT) = 0) = 1;
   R_mem_vf_tmp(rxn_vf_TRHT) = (HT_vf_rxn_UB(rxn_vf_TRHT) - TR_vf_UFD(rxn_vf_TRHT))/
                               (HT_vf_rxn_UB(rxn_vf_TRHT)- HT_vf_UFD(rxn_vf_TRHT));           
   L_mem_vb_tmp(rxn_vb_TRHT) $ (HT_vb_UFD(rxn_vb_TRHT) > 0) =
                               (TR_vb_UFD(rxn_vb_TRHT) - HT_vb_rxn_LB(rxn_vb_TRHT))/
                               (HT_vb_UFD(rxn_vb_TRHT) - HT_vb_rxn_LB(rxn_vb_TRHT));
   L_mem_vb_tmp(rxn_vb_TRHT) $ (HT_vb_UFD(rxn_vb_TRHT) = 0) = 1;
   R_mem_vb_tmp(rxn_vb_TRHT) = (HT_vb_rxn_UB(rxn_vb_TRHT) - TR_vb_UFD(rxn_vb_TRHT))/
                               (HT_vb_rxn_UB(rxn_vb_TRHT)- HT_vb_UFD(rxn_vb_TRHT));    

**** intialization
   mem_vf_tmp(reactions) = 0;
   mem_vb_tmp(reactions) = 0;            
   mem_vf_tmp(rxn_vf_TRHT) = max(min(L_mem_vf_tmp(rxn_vf_TRHT), R_mem_vf_tmp(rxn_vf_TRHT), 1), 0);
   mem_vb_tmp(rxn_vb_TRHT) = max(min(L_mem_vb_tmp(rxn_vb_TRHT), R_mem_vb_tmp(rxn_vb_TRHT), 1), 0);           

   nonzero_vf(reactions) = no;
   nonzero_vf(reactions) $ ((TR_vf_UFD(reactions) > 0 or
                             HT_vf_UFD(reactions) > 0) and rxn_vf_TRHT(reactions)) = yes;
   nonzero_vb(reactions) = no;
   nonzero_vb(reactions) $ ((TR_vb_UFD(reactions) > 0 or
                             HT_vb_UFD(reactions) > 0) and rxn_vb_TRHT(reactions)) = yes;
   nonzero_v(reactions) = no;                               
   nonzero_v(reactions) =  nonzero_vf(reactions) + nonzero_vb(reactions);
   No_nonzero_vf_TRHT = card(nonzero_vf);
   No_nonzero_vb_TRHT = card(nonzero_vb);              
   No_nonzero_v_TRHT = card(nonzero_v);
   best_mem_rxn_TRHT = sum(reactions $ (nonzero_v(reactions)),             
                           min(mem_vf_tmp(reactions),mem_vb_tmp(reactions)))/No_nonzero_v_TRHT;           
*====================================================================================================================================================
***** compute fuzzy dissimilarity of metabolite-flow and its membership grade for TRCA model ********************************************************
   L_mem_Met_tmp(biocompound) = 0;
   R_mem_Met_tmp(biocompound) = 0;
   mem_Met_tmp(biocompound) = 0;             
   L_mem_Met_tmp(BioComp_TRCA) $ (CA_BioComp_SynRate(BioComp_TRCA) > 0) =         
                                 (CA_BioComp_SynRate(BioComp_TRCA) - TR_BioComp_SynRate(BioComp_TRCA))/
                                 (CA_BioComp_SynRate(BioComp_TRCA) - CA_MetFlowRate_LB(BioComp_TRCA));
   L_mem_Met_tmp(BioComp_TRCA) $ (CA_BioComp_SynRate(BioComp_TRCA) = 0) = 0;
   R_mem_Met_tmp(BioComp_TRCA) = (TR_BioComp_SynRate(BioComp_TRCA) - CA_BioComp_SynRate(BioComp_TRCA))/
                                 (CA_MetFlowRate_UB(BioComp_TRCA) - CA_BioComp_SynRate(BioComp_TRCA));
   mem_Met_tmp(BioComp_TRCA) = min(max(L_mem_Met_tmp(BioComp_TRCA), R_mem_Met_tmp(BioComp_TRCA), 0), 1);
   nonzero_Biocomp(biocompound) = no;             
   nonzero_Biocomp(biocompound) $ ((TR_BioComp_SynRate(biocompound) > 0 or
                                    CA_BioComp_SynRate(biocompound) > 0) and BioComp_TRCA(biocompound)) = yes;

   No_nonzero_Biocomp_TRCA = card(nonzero_Biocomp);                                               
   best_mem_Met_TRCA = sum(BioCompound $ (nonzero_Biocomp(biocompound)), mem_Met_tmp(BioCompound))/No_nonzero_Biocomp_TRCA;

***** compute fuzzy similarity of flux and its membership grade for TRCA model **********************************************************************
   L_mem_vf_tmp(reactions) = 0;
   R_mem_vf_tmp(reactions) = 0;
   L_mem_vb_tmp(reactions) = 0;
   R_mem_vb_tmp(reactions) = 0;          
   L_mem_vf_tmp(rxn_vf_TRCA) $ (CA_vf_UFD(rxn_vf_TRCA) > 0) = (CA_vf_UFD(rxn_vf_TRCA) - TR_vf_UFD(rxn_vf_TRCA))/
                                                             (CA_vf_UFD(rxn_vf_TRCA) - CA_vf_rxn_LB(rxn_vf_TRCA));
   L_mem_vf_tmp(rxn_vf_TRCA) $ (CA_vf_UFD(rxn_vf_TRCA) = 0) = 0;         
   R_mem_vf_tmp(rxn_vf_TRCA) = (TR_vf_UFD(rxn_vf_TRCA) - CA_vf_UFD(rxn_vf_TRCA))/
                               (CA_vf_rxn_UB(rxn_vf_TRCA)- CA_vf_UFD(rxn_vf_TRCA));                                    
   L_mem_vb_tmp(rxn_vb_TRCA) $ (CA_vb_UFD(rxn_vb_TRCA) > 0) = (CA_vb_UFD(rxn_vb_TRCA) - TR_vb_UFD(rxn_vb_TRCA))/
                                                              (CA_vb_UFD(rxn_vb_TRCA) - CA_vb_rxn_LB(rxn_vb_TRCA));
   L_mem_vb_tmp(rxn_vb_TRCA) $ (CA_vb_UFD(rxn_vb_TRCA) = 0) = 0;                                       
   R_mem_vb_tmp(rxn_vb_TRCA) = (TR_vb_UFD(rxn_vb_TRCA) - CA_vb_UFD(rxn_vb_TRCA))/
                               (CA_vb_rxn_UB(rxn_vb_TRCA)- CA_vb_UFD(rxn_vb_TRCA)); 

**** intialization
   mem_vf_tmp(reactions) = 0;
   mem_vb_tmp(reactions) = 0;               
   mem_vf_tmp(rxn_vf_TRCA) = min(max(L_mem_vf_tmp(rxn_vf_TRCA), R_mem_vf_tmp(rxn_vf_TRCA), 0), 1);
   mem_vb_tmp(rxn_vb_TRCA) = min(max(L_mem_vb_tmp(rxn_vb_TRCA), R_mem_vb_tmp(rxn_vb_TRCA), 0), 1);             
   nonzero_vf(reactions) = no;
   nonzero_vf(reactions) $ ((TR_vf_UFD(reactions) > 0 or
                             CA_vf_UFD(reactions) > 0) and rxn_vf_TRCA(reactions)) = yes;
   nonzero_vb(reactions) = no;
   nonzero_vb(reactions) $ ((TR_vb_UFD(reactions) > 0 or
                             CA_vb_UFD(reactions) > 0) and rxn_vb_TRCA(reactions)) = yes;                            
   nonzero_v(reactions) = no;                               
   nonzero_v(reactions) =  nonzero_vf(reactions) + nonzero_vb(reactions);
   No_nonzero_vf_TRCA = card(nonzero_vf);
   No_nonzero_vb_TRCA = card(nonzero_vb);              
   No_nonzero_v_TRCA = card(nonzero_v);
   best_mem_rxn_TRCA = sum(reactions $ (nonzero_v(reactions)),             
                            max(mem_vf_tmp(reactions),mem_vb_tmp(reactions)))/No_nonzero_v_TRCA;  
*====================================================================================================================================================       
   constraint_FBA_TR = 0;
   constraint_UFD_TR = 0;
);
*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
*===== evaluating metabolic perturbation of HT model to solve FBA and UFD problems ==================================================================
***** assign reactions and species in FMO HT models as dynamic sets ****************   
dyn_reactions(reactions) = no;
dyn_species(species) = no;
dyn_BioComp(biocompound) = no;
dyn_irrev_rxn(reactions) = no;
dyn_rev_rxn(reactions) = no;
dyn_exchange_rxn(reactions) = no;
dyn_objectSet(objectSet) = no;
dyn_Fmax_Object(ObjectSet) = no;
dyn_Fmin_Object(ObjectSet) = no;
dyn_priority_obj(ObjectSet) = no;
dyn_obj_outer(objectSet) = no;
dyn_Fmax_Obj_outer(ObjectSet) = no;
dyn_Fmin_Obj_outer(ObjectSet) = no;
dyn_priority_outer(ObjectSet) = no;    

**** objectives used in inner optimization problem
dyn_reactions(reactions)  $ (not reactions_NHT(reactions)) = yes;
dyn_species(species) $ (not species_NHT(species)) = yes;
dyn_BioComp(biocompound) $ (not biocompound_NHT(biocompound)) = yes;
dyn_irrev_rxn(reactions) $ (not reactions_NHT(reactions) and irrev_rxn(reactions)) = yes;
dyn_rev_rxn(reactions) $ (not reactions_NHT(reactions) and rev_rxn(reactions)) = yes;
dyn_exchange_rxn(reactions) $ (not reactions_NHT(reactions) and exchange_rxn(reactions)) = yes;
dyn_Fmax_Object(ObjectSet) $ (FmaxObj_inner_PH(ObjectSet)) = yes;
dyn_Fmin_Object(ObjectSet) $ (FminObj_inner_PH(ObjectSet)) = yes;
dyn_objectSet(objectSet) = dyn_Fmax_Object(ObjectSet) + dyn_Fmin_Object(ObjectSet);
dyn_priority_obj(ObjectSet) $ (PriObj_inner_PH(ObjectSet)) = yes;
No_priority_obj = card(PriObj_inner_PH);
**** objectives used in outer optimization problem     
dyn_Fmax_Obj_outer(ObjectSet) $ (FmaxObj_Outer_PH(ObjectSet)) = yes;
dyn_Fmin_Obj_outer(ObjectSet) $ (FminObj_Outer_PH(ObjectSet)) = yes;
dyn_obj_outer(objectSet) = dyn_Fmax_Obj_outer(ObjectSet) + dyn_Fmin_Obj_outer(ObjectSet);
dyn_priority_outer(ObjectSet) $ (PriObj_Outer_PH(ObjectSet)) = yes;
No_priority_outer = card(PriObj_Outer_PH);
********************************************************************************
***** Set the weighting factors and limits for FBA objectives ******************
basal_vf(reactions) = 0;
basal_vb(reactions) = 0;
basal_vf(reactions) = HT_vf_UFD(reactions);
basal_vb(reactions) = HT_vb_UFD(reactions);

*--- reset the oringinal bounds for all fluxes ------------------------------------------------------------------------------------------------------
FluxBound_vf_LB(reactions) = tmp_FluxBound_vf_LB(reactions);
FluxBound_vb_LB(reactions) = tmp_FluxBound_vb_LB(reactions);
FluxBound_vf_UB(reactions) = tmp_FluxBound_vf_UB(reactions);
FluxBound_vb_UB(reactions) = tmp_FluxBound_vb_UB(reactions);
*----------------------------------------------------------------------------------------------------------------------------------------------------

*---- restrictions for the lower and upper bounds of fluxes --------------------
vf.lo(reactions) = FluxBound_vf_LB(reactions);
vf.up(reactions) = FluxBound_vf_UB(reactions);
vb.lo(reactions) = FluxBound_vb_LB(reactions);
vb.up(reactions) = FluxBound_vb_UB(reactions);

*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
z_isozyme_rxn_enz(reactions, enzymes) = no;
z_isozyme_rxn(reactions) = no;
z_HDE_tmp(reactions, enzymes) = 0;
Regulated_Rxn_v(reactions) = NO;
dyn_Reg_ExRxn(reactions) = no;
loop(Dim_BI $ (bestmem_XB(Dim_BI) >= 1),
     Regulated_rxn_v(reactions) $ (enzyme_Reg_rxn_v(Dim_BI, reactions) and dyn_reactions(reactions)) = yes;

***** assign the regulated reactions to be some levels *************************
* up regulated v
     if(bestmem_XB(Dim_BI) = 1,
        vf.lo(Regulated_rxn_v(reactions)) = basal_vf(reactions) + best_TR_Reg_factor * (FluxBound_vf_UB(reactions) - basal_vf(reactions));
        vf.up(Regulated_rxn_v(reactions)) = FluxBound_vf_UB(reactions);
        vb.lo(Regulated_rxn_v(reactions)) = FluxBound_vb_LB(reactions);
        vb.up(Regulated_rxn_v(reactions)) = basal_vb(reactions) + best_TR_Reg_factor * (FluxBound_vb_LB(reactions) - basal_vb(reactions)););

* down regulated v
     if(bestmem_XB(Dim_BI) = 2,
        vf.lo(Regulated_rxn_v(reactions)) = FluxBound_vf_LB(reactions);
        vf.up(Regulated_rxn_v(reactions)) = basal_vf(reactions) + best_TR_Reg_factor * (FluxBound_vf_LB(reactions) - basal_vf(reactions));
        vb.lo(Regulated_rxn_v(reactions)) = basal_vb(reactions) + best_TR_Reg_factor * (FluxBound_vb_UB(reactions) - basal_vb(reactions));
        vb.up(Regulated_rxn_v(reactions)) = FluxBound_vb_UB(reactions);

*---- the down regulated reaction by Dim_BI is dominatd by other isozymes ------
        vf.lo(reactions) $ (Regulated_rxn_v(reactions) and isozyme_rxn(reactions)) = (1 - flux_bounded_ratio) * basal_vf(reactions);
        vf.up(reactions) $ (Regulated_rxn_v(reactions) and isozyme_rxn(reactions)) = (1 + flux_bounded_ratio) * basal_vf(reactions);
        vb.lo(reactions) $ (Regulated_rxn_v(reactions) and isozyme_rxn(reactions)) = (1 - flux_bounded_ratio) * basal_vb(reactions);
        vb.up(reactions) $ (Regulated_rxn_v(reactions) and isozyme_rxn(reactions)) = (1 + flux_bounded_ratio) * basal_vb(reactions););
*-------------------------------------------------------------------------------
*---- knockout vf and vb -------------------------------------------------------
     if(bestmem_XB(Dim_BI) = 3,
        vf.fx(Regulated_rxn_v(reactions)) = 0;
        vb.fx(Regulated_rxn_v(reactions)) = 0;

*---- the KO reaction by Dim_BI is dominatd by other isozymes ------------------
        vf.lo(reactions) $ (Regulated_rxn_v(reactions) and isozyme_rxn(reactions)) = (1 - flux_bounded_ratio) * basal_vf(reactions);
        vf.up(reactions) $ (Regulated_rxn_v(reactions) and isozyme_rxn(reactions)) = (1 + flux_bounded_ratio) * basal_vf(reactions);
        vb.lo(reactions) $ (Regulated_rxn_v(reactions) and isozyme_rxn(reactions)) = (1 - flux_bounded_ratio) * basal_vb(reactions);
        vb.up(reactions) $ (Regulated_rxn_v(reactions) and isozyme_rxn(reactions)) = (1 + flux_bounded_ratio) * basal_vb(reactions););
*-------------------------------------------------------------------------------
*---- reaction is regulated by isozyme -----------------------------------------
     z_isozyme_rxn(reactions) $ (Regulated_rxn_v(reactions) and isozyme_rxn(reactions)) = yes;
     z_isozyme_rxn_enz(reactions, Dim_BI) $ (Regulated_rxn_v(reactions) and isozyme_rxn(reactions)) = yes;
     z_HDE_tmp(reactions, Dim_BI) $ (Regulated_rxn_v(reactions) and isozyme_rxn(reactions)) = bestmem_XB(Dim_BI);
     dyn_Reg_ExRxn(reactions) = dyn_Reg_ExRxn(reactions) + Regulated_rxn_v(reactions);
     Regulated_Rxn_v(reactions) = NO;);

***** Decide the regulated reaction to be up/down/KO if all isozymes are selected by NHDE ***********************************************************
     if((card(Dim_XI) > 1 and sum(reactions $ (z_isozyme_rxn(reactions)), 1) > 0),
         loop(reactions $ (z_isozyme_rxn(reactions) and sum(Dim_BI $ (bestmem_XB(Dim_BI) >= 1 and z_isozyme_rxn_enz(reactions, Dim_BI)), 1) =
                                                        sum(enzymes $ (isozyme_rxn_enz(reactions, enzymes)), 1)),
*---- The reaction is KO if all isozymes are KO, z_HDE_tmp = 3 --------------------------------------------------------------------------------------
              if(sum(Dim_BI $ (bestmem_XB(Dim_BI) >= 1), z_HDE_tmp(reactions, Dim_BI)) = 3 * sum(Dim_BI $ (bestmem_XB(Dim_BI) >= 1 and z_isozyme_rxn_enz(reactions, Dim_BI)), 1),
                 vf.fx(reactions) $ (z_isozyme_rxn(reactions)) = 0;
                 vb.fx(reactions) $ (z_isozyme_rxn(reactions)) = 0;);

*------ reaction is down/up, (set to down firstly) if one of the isozymes is down/up --------------------------------------------------------------
              if(sum(Dim_BI $ (bestmem_XB(Dim_BI) >= 1), z_HDE_tmp(reactions, Dim_BI)) < 3 * sum(Dim_BI $ (bestmem_XB(Dim_BI) >= 1 and z_isozyme_rxn_enz(reactions, Dim_BI)), 1),
                 vf.lo(reactions) $ (z_isozyme_rxn(reactions)) = FluxBound_vf_LB(reactions);
                 vf.up(reactions) $ (z_isozyme_rxn(reactions)) = basal_vf(reactions) + best_TR_Reg_factor *
                                                       (FluxBound_vf_LB(reactions) - basal_vf(reactions));
                 vb.lo(reactions) $ (z_isozyme_rxn(reactions)) = basal_vb(reactions) + best_TR_Reg_factor *
                                                       (FluxBound_vb_UB(reactions) - basal_vb(reactions));
                 vb.up(reactions) $ (z_isozyme_rxn(reactions)) = FluxBound_vb_UB(reactions););

*---- The above reaction is reassigned to up, if one of the isozymes is up --------------------------------------------------------------------------
             loop(Dim_BI $ (bestmem_XB(Dim_BI) >= 1 and z_HDE_tmp(reactions, Dim_BI) = 1 and z_isozyme_rxn(reactions)),
                  vf.lo(reactions) = basal_vf(reactions) + best_TR_Reg_factor * (FluxBound_vf_UB(reactions) - basal_vf(reactions));
                  vf.up(reactions) = FluxBound_vf_UB(reactions);
                  vb.lo(reactions) = FluxBound_vb_LB(reactions);
                  vb.up(reactions) = basal_vb(reactions) + best_TR_Reg_factor * (FluxBound_vb_LB(reactions) - basal_vb(reactions));
                  break $ (z_HDE_tmp(reactions, Dim_BI) = 1););
         );
     );   
*----------------------------------------------------------------------------------------------------------------------------------------------------
*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

* assign vb = 0 for the irreversible fluxes
vb.lo(irrev_rxn) = 0;
vb.up(irrev_rxn) = 0;
vb.fx(irrev_rxn) = 0;
vb.fx(DM_sink_rxn(reactions)) $ (flag_DM_sink = 1) = 0;
vf.lo(irrev_vb_rxn(reactions)) = 0;
vf.up(irrev_vb_rxn(reactions)) = 0;
vf.fx(irrev_vb_rxn(reactions)) = 0;

* assign the demanded uptake/secretion reactions
vf.fx(uptake_demand) = 0;
vb.fx(secretion_demand) = 0;
vb.fx(uptake_fixed) = FluxBound_vb_LB(uptake_fixed);

* irreversible uptake_rxn and secretion_rxn
vf.fx(uptake_rxn(reactions)) $ (flag_uptake = 1 and not dyn_Reg_ExRxn(reactions)) = 0;
vb.fx(secretion_rxn(reactions)) $ (flag_secretion = 1 and not dyn_Reg_ExRxn(reactions)) = 0;

vf.fx(uptake_demand(reactions)) $ (card(uptake_demand) > 0) = 0;
vb.fx(secretion_demand(reactions)) $ (card(secretion_demand) > 0) = 0;
********************************************************************************
*** Assign vf > 0 and vb = 0 for the Specific_rxn_vf --------------------------------
if(card(PH_Specific_rxn_vf) > 0,
   vf.lo(PH_Specific_rxn_vf) =  PH_Specific_rxn_vf_LB(PH_Specific_rxn_vf);
   vf.up(PH_Specific_rxn_vf) =  PH_Specific_rxn_vf_UB(PH_Specific_rxn_vf);
   vb.lo(PH_Specific_rxn_vf) =  0;
   vb.up(PH_Specific_rxn_vf) =  0;
   vb.fx(PH_Specific_rxn_vf) =  0;);
********************************************************************************
*** Assign vf = 0 and vb > 0 for the Specific_rxn_vb --------------------------------
if(card(PH_Specific_rxn_vb) > 0,
   vb.lo(PH_Specific_rxn_vb) =  PH_Specific_rxn_vb_LB(PH_Specific_rxn_vb);
   vb.up(PH_Specific_rxn_vb) =  PH_Specific_rxn_vb_UB(PH_Specific_rxn_vb);
   vf.lo(PH_Specific_rxn_vb) =  0;
   vf.up(PH_Specific_rxn_vb) =  0;
   vf.fx(PH_Specific_rxn_vb) =  0;);
*** Assign vf > 0 and vb > 0 for the Specific_rxn_vfvb -------------------------------
if(card(PH_Specific_rxn_vfvb) > 0,
   vf.lo(PH_Specific_rxn_vfvb) =  PH_Specific_rxn_vf_LB(PH_Specific_rxn_vfvb);
   vf.up(PH_Specific_rxn_vfvb) =  PH_Specific_rxn_vf_UB(PH_Specific_rxn_vfvb);
   vb.lo(PH_Specific_rxn_vfvb) =  PH_Specific_rxn_vb_LB(PH_Specific_rxn_vfvb);
   vb.up(PH_Specific_rxn_vfvb) =  PH_Specific_rxn_vb_UB(PH_Specific_rxn_vfvb););    
******************************************************************************* 
*----- compute the lower and upper bounds for the target reactions
target_limit_LB(targetSet) = 0;
target_limit_UB(targetSet) = 0;
target_limit_LB(targetSet) = HT_target_level_LB(targetSet);
target_limit_UB(targetSet) = HT_target_level_UB(targetSet);
MultiObjValue_FBA.lo(ObjectSet) = MultiObjValue_min(objectSet);
MultiObjValue_FBA.up(ObjectSet) = MultiObjValue_max(objectSet);
mem_objvalue_FBA.lo(objectSet) = 0;
mem_objvalue_FBA.up(objectSet) = 1;
PH_MultiObjvalue_Optim(ObjectSet) = 0;
Lambda.lo = 0;
Lambda.up = 1;
*-------------------------------------------------------------------------------
* set weightin factor for mem_objvalue_FBA for HT ------------------------------
Weight_Lambda(ObjectSet) = 0;
Weight_Lambda(ObjectSet) = PH_Weight_mem_obj_FBA(ObjectSet);
*-------------------------------------------------------------------------------
*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

*---- solve mutant FBA problem considering side effect -------------------------
solve FBA_Problem using LP maximizing objValue_FBA ;
tmp_vf_FBA(reactions) = 0;
tmp_vb_FBA(reactions) = 0;
tmp_vf_FBA(dyn_reactions) = max(vf.l(dyn_reactions), 0);
tmp_vb_FBA(dyn_reactions) = max(vb.l(dyn_reactions), 0);
tmp_MultiObjvalue_Optim(Objectset) = 0;
tmp_MultiObjvalue_Optim(dyn_objectset) = sum(dyn_reactions, coef_CellularObj_vf(dyn_objectset, dyn_reactions) * tmp_vf_FBA(dyn_reactions)) +
                                         sum(dyn_reactions, coef_CellularObj_vb(dyn_objectset, dyn_reactions) * tmp_vb_FBA(dyn_reactions));
PH_MultiObjvalue_Optim(dyn_objectset) = tmp_MultiObjvalue_Optim(dyn_objectset);
best_FMObj_inner_PH(dyn_ObjectSet) = PH_MultiObjvalue_Optim(dyn_objectset);

*----- infeasible solution ----------------------------------------------------
if(FBA_Problem.modelstat > 2,
   best_FMObj_inner_TR(ObjectSet) $ (TR_UFD_ModelStat > 2) = 0;
   best_FMObj_inner_PH(ObjectSet) = 0;
   best_FMObj_outer_TR(ObjectSet) $ (TR_UFD_ModelStat > 2) = 0;
   best_FMObj_outer_PH(ObjectSet) = 0;  
   best_mem_CV_TR $ (TR_UFD_ModelStat > 2) = 0;
   best_mem_Met_Exp_PHHT = 0;
   best_mem_CV_PH = 0;
   best_mem_MD_TP = 0;
   best_mem_Met_PHHT = 0;
   best_mem_rxn_PHHT = 0;
   best_mem_Met_PHCA = 0;
   best_mem_rxn_PHCA = 0;
   best_mem_Met_TRCA = 0;
   best_mem_rxn_TRCA = 0;   
   best_mem_Met_TRHT $ (TR_UFD_ModelStat > 2) = 0;
   best_mem_rxn_TRHT $ (TR_UFD_ModelStat > 2) = 0;
   constraint_h(Dim_h) = 0;
   constraint_h(Dim_h) = sum(reactions, S_Matrix(Dim_h, reactions) * (vf.l(reactions) - vb.l(reactions)));
   tmp_constraint_h = sum(dyn_Fmin_Object, mem_objvalue_FBA.l(dyn_Fmin_Object) -
                         (MultiObjValue_max(dyn_Fmin_Object) - PH_MultiObjvalue_Optim(dyn_Fmin_Object))/
                         (MultiObjValue_max(dyn_Fmin_Object) - MultiObjValue_min(dyn_Fmin_Object))) +
                      sum(dyn_Fmax_Object, mem_objvalue_FBA.l(dyn_Fmax_Object) -
                         (PH_MultiObjvalue_Optim(dyn_Fmax_Object) - MultiObjValue_min(dyn_Fmax_Object))/
                         (MultiObjValue_max(dyn_Fmax_Object) - MultiObjValue_min(dyn_Fmax_Object)));                              
   constraint_g = sum(targetSet, max((target_limit_LB(targetSet) - (vf.l(targetSet) - vb.l(targetSet))), 0)) +
                  sum(targetSet, max(((vf.l(targetSet) - vb.l(targetSet)) - target_limit_UB(targetSet)), 0)) +
                  sum(dyn_ObjectSet, max((Lambda.l - mem_objvalue_FBA.l(dyn_ObjectSet)), 0));   
   constraint_FBA_PH = penalty * (sum(Dim_h, abs(constraint_h(Dim_h)) + abs(tmp_constraint_h)) + constraint_g););
*------------------------------------------------------------------------------

**** mutant UFD problem considering side effect ********************************
if(FBA_Problem.modelstat <= 2,
   best_FMObj_inner_PH(dyn_ObjectSet) = PH_MultiObjvalue_Optim(dyn_objectset);
   Mem_Obj_FBA_limit(ObjectSet) = 0;
   Mem_Obj_FBA_limit(dyn_Fmax_Object) = ((PH_MultiObjvalue_Optim(dyn_Fmax_Object) - MultiObjValue_min(dyn_Fmax_Object))/
                                         (MultiObjValue_max(dyn_Fmax_Object) - MultiObjValue_min(dyn_Fmax_Object)));
   Mem_Obj_FBA_limit(dyn_Fmin_Object) = ((MultiObjValue_max(dyn_Fmin_Object) - PH_MultiObjvalue_Optim(dyn_Fmin_Object))/
                                         (MultiObjValue_max(dyn_Fmin_Object) - MultiObjValue_min(dyn_Fmin_Object)));
   Mem_Obj_FBA_limit(dyn_ObjectSet) = max(min( Mem_Obj_FBA_limit(dyn_ObjectSet), 1), 0);  
**** assign weighting coefficients for Rxn for computing ObjValue in UFD ****************************************************************************
   weight_coef_rxn(reactions) = Weight_factor_Rxn_OT;
   weight_coef_rxn(reactions) $ (HT_Reactions_HC(reactions)) = Weight_factor_Rxn_HC;
   weight_coef_rxn(reactions) $ (HT_Reactions_MC(reactions)) = Weight_factor_Rxn_MC;
   weight_coef_rxn(reactions) $ (HT_Reactions_NC(reactions)) = Weight_factor_Rxn_NC;
*****************************************************************************************************************************************************
*----- compute the lower and upper bounds for the target reactions ------------
   target_limit_LB(targetSet) = 0;
   target_limit_UB(targetSet) = 0;
   target_limit_LB(targetSet) = HT_target_level_LB(targetSet);
   target_limit_UB(targetSet) = HT_target_level_UB(targetSet);
   MultiObjValue_FBA.lo(ObjectSet) = MultiObjValue_min(objectSet);
   MultiObjValue_FBA.up(ObjectSet) = MultiObjValue_max(objectSet);
   mem_objvalue_FBA.lo(objectSet) = 0;
   mem_objvalue_FBA.up(objectSet) = 1;
*------------------------------------------------------------------------------

   PH_vf_UFD(reactions) = 0;
   PH_vb_UFD(reactions) = 0;
   PH_MultiObjvalue_Optim(objectset) = 0;
   if(flag_UFD_Obj = 1, solve UFD1_Problem using LP minimizing ObjValue_UFD;);
   if(flag_UFD_Obj = 2, solve UFD2_Problem using LP minimizing ObjValue_UFD;);
   if(flag_UFD_Obj = 3, solve UFD3_Problem using QCP minimizing ObjValue_UFD;);
   if(flag_UFD_Obj = 4, solve UFD4_Problem using QCP minimizing ObjValue_UFD;);
   PH_MultiObjvalue_Optim(dyn_objectset) = max(MultiObjValue_FBA.l(dyn_ObjectSet), 0););

if(FBA_Problem.modelstat <= 2 and UFD%No_UFD_Obj%_Problem.modelstat <= 2,
* compute synthesis rate and degradation rate for each BioCompound at the mutant state
   PH_vf_UFD(reactions) = max(vf.l(reactions), 0);
   PH_vb_UFD(reactions) = max(vb.l(reactions), 0);
   PH_v_UFD(reactions) = PH_vf_UFD(reactions) - PH_vb_UFD(reactions);

**** compute membership grades of fuzzy max and min objectives for outer PH model *******************************************************************
   PH_MultiObjvalue_Optim(Objectset) = 0;
   PH_MultiObjvalue_Optim(dyn_obj_outer) = sum(dyn_reactions, coef_CellularObj_vf(dyn_obj_outer, dyn_reactions) * PH_vf_UFD(dyn_reactions)) +
                                           sum(dyn_reactions, coef_CellularObj_vb(dyn_obj_outer, dyn_reactions) * PH_vb_UFD(dyn_reactions));  
   best_FMObj_outer_PH(dyn_obj_outer) = PH_MultiObjvalue_Optim(dyn_obj_outer);
           
**** compute membership grades of fuzzy max and min objectives for outer PH model *******************************************************************
   Mem_Obj_FBA_limit(ObjectSet) = 0;
   Mem_Obj_FBA_limit(dyn_Fmax_Obj_outer) = (PH_MultiObjvalue_Optim(dyn_Fmax_Obj_outer) - MultiObjValue_min(dyn_Fmax_Obj_outer))/
                                           (MultiObjValue_max(dyn_Fmax_Obj_outer) - MultiObjValue_min(dyn_Fmax_Obj_outer));
   Mem_Obj_FBA_limit(dyn_Fmin_Obj_outer) = (MultiObjValue_max(dyn_Fmin_Obj_outer) - PH_MultiObjvalue_Optim(dyn_Fmin_Obj_outer))/
                                           (MultiObjValue_max(dyn_Fmin_Obj_outer) - MultiObjValue_min(dyn_Fmin_Obj_outer));
   Mem_Obj_FBA_limit(dyn_obj_outer) = max(min( Mem_Obj_FBA_limit(dyn_obj_outer), 1), 0);                                                  
   mem_PriObj_Outer_PH = sum(dyn_priority_outer, Mem_Obj_FBA_limit(dyn_priority_outer))/No_priority_outer;
   best_mem_CV_PH = 0.5 * (mem_PriObj_Outer_PH + smin(dyn_obj_outer, Mem_Obj_FBA_limit(dyn_obj_outer)));
   PH_Mem_Obj_FBA_limit(dyn_obj_outer) = Mem_Obj_FBA_limit(dyn_obj_outer);   
*****************************************************************************************************************************************************
*=== compute synthesis rate for each species of treated PH model ====================================================================================
   PH_Species_SynRate(species) = 0;
   loop(dyn_species,
        PH_Species_SynRate(dyn_species) = sum(dyn_reactions, S_Matrix(dyn_species, dyn_reactions) $
                                             (S_Matrix(dyn_species, dyn_reactions) > 0) * PH_vf_UFD(dyn_reactions))
                                        - sum(dyn_reactions, S_Matrix(dyn_Species, dyn_reactions) $
                                             (S_Matrix(dyn_species, dyn_reactions) < 0) * PH_vb_UFD(dyn_reactions)););

***** compute synthesis rate for each biocompound of treated PH model *******************************************************************************
   PH_BioComp_SynRate(BioCompound) = 0;
   loop(dyn_BioComp,
        PH_BioComp_SynRate(dyn_BioComp) = sum(dyn_Species $ (BioCompound_species(dyn_BioComp, dyn_Species)),
                                              PH_Species_SynRate(dyn_Species)););       
*****************************************************************************************************************************************************
***** compute fuzzy dissimilarity of metabolite-flow and its membership grade for PHCA model ********************************************************
   L_mem_Met_tmp(biocompound) = 0;
   R_mem_Met_tmp(biocompound) = 0;
   mem_Met_tmp(biocompound) = 0;             
   L_mem_Met_tmp(BioComp_PHCA) $ (CA_BioComp_SynRate(BioComp_PHCA) > 0) =
                                 (CA_BioComp_SynRate(BioComp_PHCA) - PH_BioComp_SynRate(BioComp_PHCA))/
                                 (CA_BioComp_SynRate(BioComp_PHCA) - CA_MetFlowRate_LB(BioComp_PHCA));
   L_mem_Met_tmp(BioComp_PHCA) $ (CA_BioComp_SynRate(BioComp_PHCA) = 0) = 0;             
   R_mem_Met_tmp(BioComp_PHCA) = (PH_BioComp_SynRate(BioComp_PHCA) - CA_BioComp_SynRate(BioComp_PHCA))/
                                 (CA_MetFlowRate_UB(BioComp_PHCA) - CA_BioComp_SynRate(BioComp_PHCA));
   mem_Met_tmp(BioComp_PHCA) = min(max(L_mem_Met_tmp(BioComp_PHCA), R_mem_Met_tmp(BioComp_PHCA), 0), 1);

   nonzero_Biocomp(biocompound) = no;             
   nonzero_Biocomp(biocompound) $ ((PH_BioComp_SynRate(biocompound) > 0 or
                                    CA_BioComp_SynRate(biocompound) > 0) and BioComp_PHCA(biocompound)) = yes;
                                    
   No_nonzero_Biocomp_PHCA = card(nonzero_Biocomp);                                               
   best_mem_Met_PHCA = sum(BioCompound $ (nonzero_Biocomp(biocompound)), mem_Met_tmp(BioCompound))/No_nonzero_Biocomp_PHCA;

***** compute fuzzy dissimilarity of flux and its membership grade for PHCA model **********************************************************************
   L_mem_vf_tmp(reactions) = 0;
   R_mem_vf_tmp(reactions) = 0;
   L_mem_vb_tmp(reactions) = 0;
   R_mem_vb_tmp(reactions) = 0;
   L_mem_vf_tmp(rxn_vf_PHCA) $ (CA_vf_UFD(rxn_vf_PHCA) > 0) = (CA_vf_UFD(rxn_vf_PHCA) - PH_vf_UFD(rxn_vf_PHCA))/
                                                             (CA_vf_UFD(rxn_vf_PHCA) - CA_vf_rxn_LB(rxn_vf_PHCA));
   L_mem_vf_tmp(rxn_vf_PHCA) $ (CA_vf_UFD(rxn_vf_PHCA) = 0) = 0;           
   R_mem_vf_tmp(rxn_vf_PHCA) = (PH_vf_UFD(rxn_vf_PHCA) - CA_vf_UFD(rxn_vf_PHCA))/
                               (CA_vf_rxn_UB(rxn_vf_PHCA)- CA_vf_UFD(rxn_vf_PHCA));                                    
   L_mem_vb_tmp(rxn_vb_PHCA) $ (CA_vb_UFD(rxn_vb_PHCA) > 0) = (CA_vb_UFD(rxn_vb_PHCA) - PH_vb_UFD(rxn_vb_PHCA))/
                                                              (CA_vb_UFD(rxn_vb_PHCA) - CA_vb_rxn_LB(rxn_vb_PHCA));
   L_mem_vb_tmp(rxn_vb_PHCA) $ (CA_vb_UFD(rxn_vb_PHCA) = 0) = 0;                                     
   R_mem_vb_tmp(rxn_vb_PHCA) = (PH_vb_UFD(rxn_vb_PHCA) - CA_vb_UFD(rxn_vb_PHCA))/
                               (CA_vb_rxn_UB(rxn_vb_PHCA)- CA_vb_UFD(rxn_vb_PHCA)); 

**** intialization  
   mem_vf_tmp(reactions) = 0;
   mem_vb_tmp(reactions) = 0;               
   mem_vf_tmp(rxn_vf_PHCA) = min(max(L_mem_vf_tmp(rxn_vf_PHCA), R_mem_vf_tmp(rxn_vf_PHCA), 0), 1);
   mem_vb_tmp(rxn_vb_PHCA) = min(max(L_mem_vb_tmp(rxn_vb_PHCA), R_mem_vb_tmp(rxn_vb_PHCA), 0), 1);

   nonzero_vf(reactions) = no;
   nonzero_vf(reactions) $ ((PH_vf_UFD(reactions) > 0 or
                             CA_vf_UFD(reactions) > 0) and rxn_vf_PHCA(reactions)) = yes;
   nonzero_vb(reactions) = no;
   nonzero_vb(reactions) $ ((PH_vb_UFD(reactions) > 0 or
                             CA_vb_UFD(reactions) > 0) and rxn_vb_PHCA(reactions)) = yes;
                           
   nonzero_v(reactions) = no;                               
   nonzero_v(reactions) =  nonzero_vf(reactions) + nonzero_vb(reactions);
   No_nonzero_vf_PHCA = card(nonzero_vf);
   No_nonzero_vb_PHCA = card(nonzero_vb);              
   No_nonzero_v_PHCA = card(nonzero_v);
   best_mem_rxn_PHCA = sum(reactions $ (nonzero_v(reactions)),             
                            max(mem_vf_tmp(reactions),mem_vb_tmp(reactions)))/No_nonzero_v_PHCA;  
*====================================================================================================================================================

*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
***** compute fuzzy similarity of Warburg and experiments for PHHT model     
   L_mem_Met_Exp(BioCompound) = 0;
   R_mem_Met_Exp(BioCompound) = 0;
   mem_Met_Exp(BioCompound) = 0;
   L_mem_Met_Exp(BioComp_ExpWarb) $ (HT_BioComp_SynRate(BioComp_ExpWarb) > 0) =
                                    (PH_BioComp_SynRate(BioComp_ExpWarb) - HT_MetFlowRate_LB(BioComp_ExpWarb))/
                                    (HT_BioComp_SynRate(BioComp_ExpWarb) - HT_MetFlowRate_LB(BioComp_ExpWarb));
   L_mem_Met_Exp(BioComp_ExpWarb) $ (HT_BioComp_SynRate(BioComp_ExpWarb) = 0) = 1;
   R_mem_Met_Exp(BioComp_ExpWarb) = (HT_MetFlowRate_UB(BioComp_ExpWarb) - PH_BioComp_SynRate(BioComp_ExpWarb))/
                                    (HT_MetFlowRate_UB(BioComp_ExpWarb) - HT_BioComp_SynRate(BioComp_ExpWarb));
   mem_Met_Exp(BioComp_ExpWarb) = max(min(L_mem_Met_Exp(BioComp_ExpWarb), R_mem_Met_Exp(BioComp_ExpWarb), 1), 0);
   best_mem_Met_Exp_PHHT = sum(BioComp_ExpWarb, mem_Met_Exp(BioComp_ExpWarb))/card(BioComp_ExpWarb);

*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
***** compute fuzzy similarity of metabolite flow rates for biocompounds of PHHT model **********************************************************************
   L_mem_Met_tmp(biocompound) = 0;
   R_mem_Met_tmp(biocompound) = 0;
   mem_Met_tmp(biocompound) = 0;             
   L_mem_Met_tmp(BioComp_PHHT) $ (HT_BioComp_SynRate(BioComp_PHHT) > 0) =
                                 (PH_BioComp_SynRate(BioComp_PHHT) - HT_MetFlowRate_LB(BioComp_PHHT))/
                                 (HT_BioComp_SynRate(BioComp_PHHT) - HT_MetFlowRate_LB(BioComp_PHHT)); 
   L_mem_Met_tmp(BioComp_PHHT) $ (HT_BioComp_SynRate(BioComp_PHHT) = 0) = 1;
   R_mem_Met_tmp(BioComp_PHHT) = (HT_MetFlowRate_UB(BioComp_PHHT) - PH_BioComp_SynRate(BioComp_PHHT))/
                                 (HT_MetFlowRate_UB(BioComp_PHHT) - HT_BioComp_SynRate(BioComp_PHHT));  
   mem_Met_tmp(BioComp_PHHT) = max(min(L_mem_Met_tmp(BioComp_PHHT), R_mem_Met_tmp(BioComp_PHHT), 1), 0);
   nonzero_Biocomp(biocompound) = no;             
   nonzero_Biocomp(biocompound) $ ((PH_BioComp_SynRate(biocompound) > 0 or
                                    HT_BioComp_SynRate(biocompound) > 0) and BioComp_PHHT(biocompound)) = yes;

   No_nonzero_Biocomp_PHHT = card(nonzero_Biocomp);                                               
   best_mem_Met_PHHT = sum(BioCompound $ (nonzero_Biocomp(biocompound)), mem_Met_tmp(BioCompound))/No_nonzero_Biocomp_PHHT;

*****************************************************************************************************************************************************
***** compute fuzzy similarity of flux and its membership grade for PHHT model **********************************************************************   
   L_mem_vf_tmp(reactions) = 0;
   R_mem_vf_tmp(reactions) = 0;
   L_mem_vb_tmp(reactions) = 0;
   R_mem_vb_tmp(reactions) = 0;
   L_mem_vf_tmp(rxn_vf_PHHT) $ (HT_vf_UFD(rxn_vf_PHHT) > 0) =
                               (PH_vf_UFD(rxn_vf_PHHT) - HT_vf_rxn_LB(rxn_vf_PHHT))/
                               (HT_vf_UFD(rxn_vf_PHHT) - HT_vf_rxn_LB(rxn_vf_PHHT));
   L_mem_vf_tmp(rxn_vf_PHHT) $ (HT_vf_UFD(rxn_vf_PHHT) = 0) = 1;
   R_mem_vf_tmp(rxn_vf_PHHT) = (HT_vf_rxn_UB(rxn_vf_PHHT) - PH_vf_UFD(rxn_vf_PHHT))/
                               (HT_vf_rxn_UB(rxn_vf_PHHT)- HT_vf_UFD(rxn_vf_PHHT));                                          
   L_mem_vb_tmp(rxn_vb_PHHT) $ (HT_vb_UFD(rxn_vb_PHHT) > 0) =
                               (PH_vb_UFD(rxn_vb_PHHT) - HT_vb_rxn_LB(rxn_vb_PHHT))/
                               (HT_vb_UFD(rxn_vb_PHHT) - HT_vb_rxn_LB(rxn_vb_PHHT));
   L_mem_vb_tmp(rxn_vb_PHHT) $ (HT_vb_UFD(rxn_vb_PHHT) = 0) = 1;
   R_mem_vb_tmp(rxn_vb_PHHT) = (HT_vb_rxn_UB(rxn_vb_PHHT) - PH_vb_UFD(rxn_vb_PHHT))/
                               (HT_vb_rxn_UB(rxn_vb_PHHT)- HT_vb_UFD(rxn_vb_PHHT));    

**** intialization
   mem_vf_tmp(reactions) = 0;
   mem_vb_tmp(reactions) = 0;             
   mem_vf_tmp(rxn_vf_PHHT) = max(min(L_mem_vf_tmp(rxn_vf_PHHT), R_mem_vf_tmp(rxn_vf_PHHT), 1), 0);
   mem_vb_tmp(rxn_vb_PHHT) = max(min(L_mem_vb_tmp(rxn_vb_PHHT), R_mem_vb_tmp(rxn_vb_PHHT), 1), 0);

   nonzero_vf(reactions) = no;
   nonzero_vf(reactions) $ ((PH_vf_UFD(reactions) > 0 or
                             HT_vf_UFD(reactions) > 0) and rxn_vf_PHHT(reactions)) = yes;
   nonzero_vb(reactions) = no;
   nonzero_vb(reactions) $ ((PH_vb_UFD(reactions) > 0 or
                             HT_vb_UFD(reactions) > 0) and rxn_vb_PHHT(reactions)) = yes;                             
   nonzero_v(reactions) = no;                               
   nonzero_v(reactions) =  nonzero_vf(reactions) + nonzero_vb(reactions);
   No_nonzero_vf_PHHT = card(nonzero_vf);
   No_nonzero_vb_PHHT = card(nonzero_vb);              
   No_nonzero_v_PHHT = card(nonzero_v);
   best_mem_rxn_PHHT = sum(reactions $ (nonzero_v(reactions)),             
                           min(mem_vf_tmp(reactions),mem_vb_tmp(reactions)))/No_nonzero_v_PHHT;           
*====================================================================================================================================================
   constraint_FBA_PH = 0;
   constraint_UFD_PH = 0;
);
*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
*----- infeasible solution for UFD problem -------------------------------------
if(UFD%No_UFD_Obj%_Problem.modelstat > 2,           
   best_FMObj_inner_TR(ObjectSet) $ (TR_UFD_ModelStat > 2) = 0;
   best_FMObj_inner_PH(ObjectSet) = 0;
   best_FMObj_outer_TR(ObjectSet) $ (TR_UFD_ModelStat > 2) = 0;
   best_FMObj_outer_PH(ObjectSet) = 0;  
   best_mem_CV_TR $ (TR_UFD_ModelStat > 2) = 0;
   best_mem_Met_Exp_PHHT = 0;
   best_mem_CV_PH = 0;
   best_mem_MD_TP = 0;
   best_mem_Met_PHHT = 0;
   best_mem_rxn_PHHT = 0;
   best_mem_Met_PHCA = 0;
   best_mem_rxn_PHCA = 0;
   best_mem_Met_TRCA $ (TR_UFD_ModelStat > 2) = 0;
   best_mem_rxn_TRCA $ (TR_UFD_ModelStat > 2) = 0;   
   best_mem_Met_TRHT $ (TR_UFD_ModelStat > 2) = 0;
   best_mem_rxn_TRHT $ (TR_UFD_ModelStat > 2) = 0;
   constraint_h(Dim_h) = 0;
   constraint_h(Dim_h) = sum(reactions, S_Matrix(Dim_h, reactions) * (vf.l(reactions) - vb.l(reactions)));
   tmp_constraint_h = sum(dyn_Fmin_Object, mem_objvalue_FBA.l(dyn_Fmin_Object) -
                         (MultiObjValue_max(dyn_Fmin_Object) - MultiObjValue_FBA.l(dyn_Fmin_Object))/
                         (MultiObjValue_max(dyn_Fmin_Object) - MultiObjValue_min(dyn_Fmin_Object))) +
                      sum(dyn_Fmax_Object, mem_objvalue_FBA.l(dyn_Fmax_Object) -
                         (MultiObjValue_FBA.l(dyn_Fmax_Object) - MultiObjValue_min(dyn_Fmax_Object))/
                         (MultiObjValue_max(dyn_Fmax_Object) - MultiObjValue_min(dyn_Fmax_Object)));                             
   constraint_g = sum(targetSet, max((target_limit_LB(targetSet) - (vf.l(targetSet) - vb.l(targetSet))), 0)) +
                  sum(targetSet, max(((vf.l(targetSet) - vb.l(targetSet)) - target_limit_UB(targetSet)), 0)) +
                  sum(dyn_ObjectSet, max((Lambda.l - mem_objvalue_FBA.l(dyn_ObjectSet)), 0));   
   constraint_UFD_PH = penalty * (sum(Dim_h, abs(constraint_h(Dim_h)) + abs(tmp_constraint_h)) + constraint_g););
*-------------------------------------------------------------------------------   
*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
*----- fitness evaluation ------------------------------------------------------
* Metabolic deviation (dissimilarity) for PH model to CA template
best_mem_MD_PHCA = ((best_mem_rxn_PHCA + best_mem_Met_PHCA)/2 + min(best_mem_rxn_PHCA, best_mem_Met_PHCA))/2;

* Metabolic deviation (similarity) for PH model to HT template
best_mem_MD_PHHT = ((best_mem_rxn_PHHT + best_mem_Met_PHHT)/2 + min(best_mem_rxn_PHHT, best_mem_Met_PHHT))/2;

* Metabolic deviation (similarity) for TR model to HT template
best_mem_MD_TRHT = ((best_mem_rxn_TRHT + best_mem_Met_TRHT)/2 + min(best_mem_rxn_TRHT, best_mem_Met_TRHT))/2;

* Metabolic deviation (dissimilarity) for TR model to CA template
best_mem_MD_TRCA = ((best_mem_rxn_TRCA + best_mem_Met_TRCA)/2 + min(best_mem_rxn_TRCA, best_mem_Met_TRCA))/2;

* Metabolic deviation of fuzzy dissimilarity and similarity for PHCA, TRCA TRHT, and PHHT
best_mem_MD_TP $ (index_sumz = 1 or index_sumz = 21 or index_sumz = 22) = ((best_mem_MD_PHCA + best_mem_MD_PHHT)/2 +
                                                                               min(best_mem_MD_PHCA, best_mem_MD_PHHT))/2;

best_mem_MD_TP $ (index_sumz = 41 or index_sumz = 42) = ((best_mem_MD_PHCA + best_mem_MD_PHHT + best_mem_MD_TRHT + best_mem_MD_TRCA)/4 +
                                                            min(best_mem_MD_PHCA, best_mem_MD_PHHT, best_mem_MD_TRHT, best_mem_MD_TRCA))/2;

* Metabolic deviation of fuzzy similarity for TRHT, and PHHT
best_mem_MD_TP $ (index_sumz = 23 or index_sumz = 24) = ((best_mem_MD_TRHT + best_mem_MD_PHHT)/2 +
                                                             min(best_mem_MD_TRHT, best_mem_MD_PHHT))/2;

*----- prioity fitness evaluation ----------------------------------------------
best_constraint = constraint_FBA_TR + constraint_UFD_TR + constraint_FBA_PH + constraint_UFD_PH;
best_fitness $ (index_sumZ = 1) = mem_PriObj_Outer_TR;
best_fitness $ (index_sumZ = 21 or index_sumZ = 23 or index_sumz = 41) = (best_mem_CV_TR +
                                                                             min(best_mem_CV_TR, best_mem_CV_PH, best_mem_MD_TP))/2;
best_fitness $ (index_sumZ = 22 or index_sumZ = 24 or index_sumz = 42) = ((best_mem_CV_TR + best_mem_CV_PH)/2 +
                                                                             min(best_mem_CV_TR, best_mem_CV_PH, best_mem_MD_TP))/2;
best_fitness = best_fitness - best_constraint;
best_fitness $ (flag_sumZ = 1) = best_fitness + best_mem_sumZ;
*-------------------------------------------------------------------------------

*----- compute MultiObjValue for all objectives of the problem --------------------------------------------------------------------------------------
dyn_reactions(reactions) = no;
dyn_reactions(reactions) = no;
dyn_Fmax_Object(ObjectSet) = no;
dyn_Fmin_Object(ObjectSet) = no;
dyn_objectSet(objectSet) = no;
dyn_reactions(reactions) $ (not reactions_NCA(reactions)) = yes;
dyn_Fmax_Object(ObjectSet) $ (FmaxObj_inner_TR(ObjectSet)) = yes;
dyn_Fmin_Object(ObjectSet) $ (FminObj_inner_TR(ObjectSet)) = yes;
dyn_objectSet(objectSet) = dyn_Fmax_Object(ObjectSet) + dyn_Fmin_Object(ObjectSet);

CA_MultiObjvalue_Optim(ObjectSet) = 0;
TR_MultiObjvalue_Optim(ObjectSet) = 0;
CA_MultiObjvalue_Optim(ObjectSet) = sum(dyn_reactions, coef_CellularObj_vf(ObjectSet, dyn_reactions) * CA_vf_UFD(dyn_reactions)) +
                                    sum(dyn_reactions, coef_CellularObj_vb(ObjectSet, dyn_reactions) * CA_vb_UFD(dyn_reactions));
TR_MultiObjvalue_Optim(ObjectSet) = sum(dyn_reactions, coef_CellularObj_vf(ObjectSet, dyn_reactions) * TR_vf_UFD(dyn_reactions)) +
                                    sum(dyn_reactions, coef_CellularObj_vb(ObjectSet, dyn_reactions) * TR_vb_UFD(dyn_reactions));

***** inner CA UFD problem ****************************************************
Mem_Obj_FBA_limit(ObjectSet) = 0;
Mem_Obj_FBA_limit(dyn_Fmax_Object) = ((CA_MultiObjvalue_Optim(dyn_Fmax_Object) - MultiObjValue_min(dyn_Fmax_Object))/
                                      (MultiObjValue_max(dyn_Fmax_Object) - MultiObjValue_min(dyn_Fmax_Object)));
                                        
Mem_Obj_FBA_limit(dyn_Fmin_Object) = ((MultiObjValue_max(dyn_Fmin_Object) - CA_MultiObjvalue_Optim(dyn_Fmin_Object))/
                                      (MultiObjValue_max(dyn_Fmin_Object) - MultiObjValue_min(dyn_Fmin_Object)));
Mem_Obj_FBA_limit(dyn_ObjectSet) = max(min( Mem_Obj_FBA_limit(dyn_ObjectSet), 1), 0);
CA_Mem_Obj_FBA_limit(dyn_ObjectSet) = Mem_Obj_FBA_limit(dyn_ObjectSet);
*******************************************************************************
                                  
dyn_reactions(reactions) = no;
dyn_reactions(reactions) = no;
dyn_Fmax_Object(ObjectSet) = no;
dyn_Fmin_Object(ObjectSet) = no;
dyn_objectSet(objectSet) = no;
dyn_reactions(reactions) $ (not reactions_NHT(reactions) and not reactions_NCA(reactions)) = yes;
dyn_reactions(reactions) $ (not reactions_NCA(reactions)) = yes;
dyn_Fmax_Object(ObjectSet) $ (FmaxObj_inner_PH(ObjectSet)) = yes;
dyn_Fmin_Object(ObjectSet) $ (FminObj_inner_PH(ObjectSet)) = yes;
dyn_objectSet(objectSet) = dyn_Fmax_Object(ObjectSet) + dyn_Fmin_Object(ObjectSet);

HT_MultiObjvalue_Optim(ObjectSet) = 0;
HT_MultiObjvalue_Optim(ObjectSet) = sum(dyn_reactions, coef_CellularObj_vf(ObjectSet, dyn_reactions) * HT_vf_UFD(dyn_reactions)) +
                                    sum(dyn_reactions, coef_CellularObj_vb(ObjectSet, dyn_reactions) * HT_vb_UFD(dyn_reactions));
                                   
***** inner HT UFD problem ****************************************************
Mem_Obj_FBA_limit(ObjectSet) = 0;
Mem_Obj_FBA_limit(dyn_Fmax_Object) = ((HT_MultiObjvalue_Optim(dyn_Fmax_Object) - MultiObjValue_min(dyn_Fmax_Object))/
                                      (MultiObjValue_max(dyn_Fmax_Object) - MultiObjValue_min(dyn_Fmax_Object)));                                       
Mem_Obj_FBA_limit(dyn_Fmin_Object) = ((MultiObjValue_max(dyn_Fmin_Object) - HT_MultiObjvalue_Optim(dyn_Fmin_Object))/
                                      (MultiObjValue_max(dyn_Fmin_Object) - MultiObjValue_min(dyn_Fmin_Object)));
Mem_Obj_FBA_limit(dyn_ObjectSet) = max(min( Mem_Obj_FBA_limit(dyn_ObjectSet), 1), 0);
HT_Mem_Obj_FBA_limit(dyn_ObjectSet) = Mem_Obj_FBA_limit(dyn_ObjectSet);   
*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

put /; put "########## Optimal solution solved by NLP solver based on the best results obtained from NHDE  ##########";
put /; put "===== Best fitness, best cell mortality, cell viability and metabolic deviation for PHCA, TRCA, PHHT and TRHT ====="; put /;
put " "; put "Cell mortality"; put "Cell viability"; put "Metabolic deviation"; put "Dissimilarity of PHCA and TRCA"; put " ";
put "Similarity of PHHT and TRHT"; put " "; put "TR_outer_obj";
for(i_loop = 1 to (card(FmaxObj_Outer_TR) + card(FminObj_Outer_TR) - 1), put " ";); put "PH_outer_obj";
for(i_loop = 1 to (card(FmaxObj_Outer_PH) + card(FminObj_Outer_PH) - 1), put " ";); put "FBA_CA_inner_obj";
for(i_loop = 1 to (card(FmaxObj_inner_TR) + card(FminObj_inner_TR) - 1), put " ";); put "FBA_HT_inner_obj"; put /;
put "best_fitness"; put "best_mem_CV_TR"; put "best_mem_CV_PH"; put "best_mem_MD_TP"; put "best_mem_MD_PHCA"; 
put "best_mem_MD_TRCA"; put "best_mem_MD_PHHT"; put "best_mem_MD_TRHT"; 
loop(objectSet $ (FmaxObj_Outer_TR(ObjectSet) or FminObj_Outer_TR(ObjectSet)), put ObjectSet.tl:0;);
loop(objectSet $ (FmaxObj_Outer_PH(ObjectSet) or FminObj_Outer_PH(ObjectSet)), put ObjectSet.tl:0;);
loop(objectSet $ (FmaxObj_inner_TR(ObjectSet) or FminObj_inner_TR(ObjectSet)), put ObjectSet.tl:0;);
loop(objectSet $ (FmaxObj_inner_PH(ObjectSet) or FminObj_inner_PH(ObjectSet)), put ObjectSet.tl:0;);
put "best_mem_Met_PHCA"; put "best_mem_rxn_PHCA"; put "best_mem_Met_TRCA"; put "best_mem_rxn_TRCA"; put "best_mem_Met_PHHT";
put "best_mem_rxn_PHHT"; put "best_mem_Met_TRHT"; put "best_mem_rxn_TRHT"; put "best_mem_Met_Exp_PHHT"; put "best_sumZ";
put "best_constraint"; put "TR_FBA_ModelStat"; put "TR_UFD_ModelStat"; put "PH_FBA_modelstat"; put "PH_UFD_modelstat"; put /;
put best_fitness:10:4; put best_mem_CV_TR:10:4; put best_mem_CV_PH:10:4; put best_mem_MD_TP:10:4; put best_mem_MD_PHCA:10:4;
put best_mem_MD_TRCA:10:4; put best_mem_MD_PHHT:10:4; put best_mem_MD_TRHT:10:4;
loop(objectSet $ (FmaxObj_Outer_TR(ObjectSet) or FminObj_Outer_TR(ObjectSet)), put best_FMObj_outer_TR(ObjectSet):10:4;);
loop(objectSet $ (FmaxObj_Outer_PH(ObjectSet) or FminObj_Outer_PH(ObjectSet)), put best_FMObj_outer_PH(ObjectSet):10:4;);
loop(objectSet $ (FmaxObj_inner_TR(ObjectSet) or FminObj_inner_TR(ObjectSet)), put best_FMObj_inner_TR(ObjectSet):10:4;);
loop(objectSet $ (FmaxObj_inner_PH(ObjectSet) or FminObj_inner_PH(ObjectSet)), put best_FMObj_inner_PH(ObjectSet):10:4;);
put best_mem_Met_PHCA:10:4; put best_mem_rxn_PHCA:10:4; put best_mem_Met_TRCA:10:4; put best_mem_rxn_TRCA:10:4;
put best_mem_Met_PHHT:10:4; put best_mem_rxn_PHHT:10:4; put best_mem_Met_TRHT:10:4; put best_mem_rxn_TRHT:10:4;
put best_mem_Met_Exp_PHHT:10:4; put (sum(Dim_BI, (bestmem_XB(Dim_BI) > 0) = 1)); put best_constraint:10:4; put TR_FBA_ModelStat;
put TR_UFD_ModelStat; put FBA_Problem.modelstat; put UFD%No_UFD_Obj%_Problem.modelstat; put /;
*****************************************************************************************************************************************************

put /;
put "No. of biocompounds for PHCA, TRCA, PHHT and TRHT"; put /;
put "No. biocompound"; put "BioComp_PHCA"; put "BioComp_TRCA"; put "BioComp_PHHT"; put "BioComp_TRHT"; 
put "No. biocompound_Warburg"; put "No. biocompound_Exp"; put "No. BioComp_ExpWarb"; put /;
put card(biocompound); put card(BioComp_PHCA);  put card(BioComp_TRCA); put card(BioComp_PHHT); put card(BioComp_TRHT);
put card(biocompound_Warburg); put card(biocompound_exp); put card(BioComp_ExpWarb); put /;

put /;
put "No. of species for PHCA, TRCA, PHHT, and TRHT"; put /;
put "No. species"; put "species_PHCA"; put "species_TRCA"; put "species_PHHT"; put "species_TRHT"; put /;
put card(species); put card(species_PHCA); put card(species_TRCA); put card(species_PHHT); put card(species_TRHT);
put /;

put /;
put "No. of Rxn_vf and Rxn_vb for PHCA, TRCA, PHHT, and TRHT"; put /;
put "rxn"; put "PHCA"; put "TRCA"; put "PHHT"; put "TRHT"; put /;
put "No. rxn_vf"; put card(rxn_vf_PHCA); put card(rxn_vf_TRCA); put card(rxn_vf_PHHT); put card(rxn_vf_TRHT); put /;
put "No. rxn_vb"; put card(rxn_vb_PHCA); put card(rxn_vb_TRCA); put card(rxn_vb_PHHT); put card(rxn_vb_TRHT); put /;

put /;
put "No. of nonzero_biocomp for PHCA, TRCA, PHHT, and TRHT"; put /;
put "No_nonzero_BioComp_PHCA"; put "No_nonzero_BioComp_TRCA"; put "No_nonzero_BioComp_PHHT"; put "No_nonzero_BioComp_TRHT"; put /;
put card(NO_nonzero_Biocomp_PHCA); put card(NO_nonzero_Biocomp_TRCA); put card(No_nonzero_Biocomp_PHHT); put card(No_nonzero_Biocomp_TRHT); put /;

put /;
put "No. of nonzero_Rxn_vf and Rxn_vb for PHCA,TRCA, PHHT, and TRHT"; put /;
put "rxn"; put "PHCA"; put "TRCA"; put "PHHT"; put "TRHT"; put /;
put "No_nonzero_vf"; put No_nonzero_vf_PHCA; put No_nonzero_vf_TRCA; put No_nonzero_vf_PHHT; put No_nonzero_vf_TRHT; put /;
put "No_nonzero_vb"; put No_nonzero_vb_PHCA; put No_nonzero_vb_TRCA; put No_nonzero_vb_PHHT; put No_nonzero_vb_TRHT; put /;
put "No_nonzero_v"; put No_nonzero_v_PHCA; put No_nonzero_v_TRCA; put No_nonzero_v_PHHT; put No_nonzero_v_TRHT; put /;
*****************************************************************************************************************************************************

put /; put "##### MultiObjValue_min, MultiObjvalue_Optim MultiObjValue_max and mem-optimal multiobjValues for CA, HT, TR and PH #####"; put /;
put "##### Fuzzy maximum objectives in the outer TR optimization problem"; put/;
put "Object"; put "MultiObjValue_min"; put "TR_MultiObjvalue_Optim"; put "MultiObjValue_max"; put "TR_mem_Obj_FBA_limit"; put /;
loop(objectSet $ (FmaxObj_Outer_TR(objectset)), put objectSet.tl:0; put put MultiObjValue_min(ObjectSet):10:4;
     put TR_MultiObjvalue_Optim(ObjectSet):10:4;put MultiObjValue_max(ObjectSet):10:4; put TR_Mem_Obj_FBA_limit(ObjectSet):10:4; put /;);

put /; put "===== Fuzzy minimum objectives in the outer TR optimization problem"; put/;
put "Object"; put "MultiObjValue_min"; put "TR_MultiObjvalue_Optim"; put "MultiObjValue_max"; put "TR_mem_Obj_FBA_limit"; put /;
loop(objectSet $ (FminObj_Outer_TR(objectset)), put objectSet.tl:0; put put MultiObjValue_min(ObjectSet):10:4;
     put TR_MultiObjvalue_Optim(ObjectSet):10:4;put MultiObjValue_max(ObjectSet):10:4; put TR_Mem_Obj_FBA_limit(ObjectSet):10:4; put /;);

put /; put "===== Priority objectives for treated CA model"; put /;
loop(objectset $ (PriObj_Outer_TR(ObjectSet)), put objectSet.tl:0;); put /;
*****************************************************************************************************************************************************

put /; put "##### Fuzzy maximum objectives in the outer PH optimization problem"; put/;
put "Object"; put "MultiObjValue_min"; put "PH_MultiObjvalue_Optim"; put "MultiObjValue_max"; put "PH_mem_Obj_FBA_limit"; put /;
loop(objectSet $ (FmaxObj_Outer_PH(objectset)), put objectSet.tl:0; put put MultiObjValue_min(ObjectSet):10:4;
     put PH_MultiObjvalue_Optim(ObjectSet):10:4;put MultiObjValue_max(ObjectSet):10:4; put PH_Mem_Obj_FBA_limit(ObjectSet):10:4; put /;);

put /; put "===== Fuzzy minimum objectives in the outer PH optimization problem"; put/;
put "Object"; put "MultiObjValue_min"; put "PH_MultiObjvalue_Optim"; put "MultiObjValue_max"; put "PH_mem_Obj_FBA_limit"; put /;
loop(objectSet $ (FminObj_Outer_PH(objectset)), put objectSet.tl:0; put put MultiObjValue_min(ObjectSet):10:4;
     put PH_MultiObjvalue_Optim(ObjectSet):10:4;put MultiObjValue_max(ObjectSet):10:4; put PH_Mem_Obj_FBA_limit(ObjectSet):10:4; put /;);

put /; put "===== Priority objectives for perturbed BL model"; put /;
loop(objectset $ (PriObj_Outer_PH(ObjectSet)), put objectSet.tl:0;); put /;
*****************************************************************************************************************************************************

put /; put "##### Fuzzy maximum objectives in the inner CA optimization problem"; put/;
put "Object"; put "MultiObjValue_min"; put "CA_MultiObjvalue_Optim"; put "MultiObjValue_max"; put "CA_mem_Obj_FBA_limit"; put /;
loop(objectSet $ (FmaxObj_inner_TR(objectset)), put objectSet.tl:0; put put MultiObjValue_min(ObjectSet):10:4;
     put CA_MultiObjvalue_Optim(ObjectSet):10:4;put MultiObjValue_max(ObjectSet):10:4; put CA_Mem_Obj_FBA_limit(ObjectSet):10:4; put /;);

put /; put "===== Fuzzy minimum objectives in the inner CA optimization problem"; put/;
put "Object"; put "MultiObjValue_min"; put "CA_MultiObjvalue_Optim"; put "MultiObjValue_max"; put "CA_mem_Obj_FBA_limit"; put /;
loop(objectSet $ (FminObj_inner_TR(objectset)), put objectSet.tl:0; put put MultiObjValue_min(ObjectSet):10:4;
     put CA_MultiObjvalue_Optim(ObjectSet):10:4;put MultiObjValue_max(ObjectSet):10:4; put CA_Mem_Obj_FBA_limit(ObjectSet):10:4; put /;);

put /; put "===== Priority objectives for the inner CA model"; put /;
loop(objectset $ (PriObj_inner_TR(ObjectSet)), put objectSet.tl:0;); put /;
*****************************************************************************************************************************************************

put /; put "##### Fuzzy maximum objectives in the inner HT optimization problem"; put/;
put "Object"; put "MultiObjValue_min"; put "HT_MultiObjvalue_Optim"; put "MultiObjValue_max"; put "HT_mem_Obj_FBA_limit"; put /;
loop(objectSet $ (FmaxObj_inner_PH(objectset)), put objectSet.tl:0; put put MultiObjValue_min(ObjectSet):10:4;
     put HT_MultiObjvalue_Optim(ObjectSet):10:4;put MultiObjValue_max(ObjectSet):10:4; put HT_Mem_Obj_FBA_limit(ObjectSet):10:4; put /;);

put "===== Fuzzy minimum objectives in the inner HT optimization problem"; put/;
put "Object"; put "MultiObjValue_min"; put "HT_MultiObjvalue_Optim"; put "MultiObjValue_max"; put "HT_mem_Obj_FBA_limit"; put /;
loop(objectSet $ (FminObj_inner_PH(objectset)), put objectSet.tl:0; put put MultiObjValue_min(ObjectSet):10:4;
     put HT_MultiObjvalue_Optim(ObjectSet):10:4;put MultiObjValue_max(ObjectSet):10:4; put HT_Mem_Obj_FBA_limit(ObjectSet):10:4; put /;);

put /; put "===== Priority objectives for the inner HT model"; put /;
loop(objectset $ (PriObj_inner_PH(ObjectSet)), put objectSet.tl:0;); put /;
*****************************************************************************************************************************************************

alias(dyn_rxn, reactions);

put /; put "===== Optimal regulated enzymes and Reg_status: up-regulation = 1, down-regulation = 2, knockout = 3"; put /;
put "Check the following regulation status if a reaction is regulated by isoenzymes, E1 and E2."; put /;
put "E1: up, E2: up/down/KO/inactive --> vf_basal + R * (vf_UB - vf_basal) <= vf <= vf_UB, vb_LB <= vb <= vb_LB + R * (vb_LB - vb_basal)"; put /;
put "E1: down, E2: inactive --> vf_LB <= vf <= vf_UB, vb_LB <= vb <= vb_UB"; put /;
put "E1: down, E2: down/KO --> vf_LB <= vf <= vf_basal + R * (vf_LB - vf_basal), vb_basal + R *(vb_UB - vb_basal)"; put /;
put "E1: KO, E2: KO --> vf = vb = 0"; put /;
put /; put "Enzyme"; put "Reg_status"; put "gene"; put /;
Regulated_rxn_v(reactions) = no;
loop(Dim_BI $ (bestmem_XB(Dim_BI) > 0), put Dim_BI.tl:0; put bestmem_XB(Dim_BI);
     loop(genes $ (enzyme_gene(Dim_BI, genes)), put genes.tl;);
     number1 = 1;
     loop(enzymes $ (identical_enz(Dim_BI, enzymes)), if(number1 = 1, put "Identical_Enz:"; number1 = 2;); put enzymes.tl;); put /;

*     Regulated_rxn_v(reactions) $ (enzyme_Reg_rxn_v(Dim_BI, reactions) and dyn_reactions(reactions)) = yes;
     Regulated_rxn_v(reactions) $ (enzyme_Reg_rxn_v(Dim_BI, reactions)) = yes;
     put "reactions"; put "TR_vf"; put "TR_vb"; put "TR_v"; put " "; put "PH_vf_UFD"; put "PH_vb_UFD"; put "PH_v_UFD"; put " ";
                      put "CA_vf_UFD"; put "CA_vb_UFD"; put "CA_v_UFD"; put " ";
                      put "vf_LB"; put "HT_vf_UFD"; put "vf_UB";
                      put "vb_LB"; put "HT_vb_UFD"; put "vb_UB"; put "v_LB"; put "HT_v_UFD"; put "v_UB"; put /;
     loop(reactions $ (Regulated_rxn_v(reactions)), put reactions.tl;
          put TR_vf_UFD(reactions):10:4; put TR_vb_UFD(reactions):10:4; put TR_v_UFD(reactions):10:4; put " ";
          put PH_vf_UFD(reactions):10:4; put PH_vb_UFD(reactions):10:4; put PH_v_UFD(reactions):10:4; put " ";
          put CA_vf_UFD(reactions):10:4; put CA_vb_UFD(reactions):10:4; put CA_v_UFD(reactions):10:4; put " ";
          put FluxBound_vf_LB(reactions):10:4; put HT_vf_UFD(reactions):10:4; put FluxBound_vf_UB(reactions):10:4;
          put FluxBound_vb_LB(reactions):10:4; put HT_vb_UFD(reactions):10:4; put FluxBound_vb_UB(reactions):10:4;
          put FluxBound_v_LB(reactions):10:4; put HT_v_UFD(reactions):10:4; put FluxBound_v_UB(reactions):10:4;
          put /;);
*          loop(dyn_reactions $ (Regulated_rxn_v(dyn_reactions) and isozyme_rxn(dyn_reactions)), put dyn_reactions.tl:0; put "isozymes:";
          loop(dyn_rxn $ (Regulated_rxn_v(dyn_rxn) and isozyme_rxn(dyn_rxn)), put dyn_rxn.tl:0; put "isozymes:";
               loop(enzymes $ (isozyme_rxn_enz(dyn_rxn, enzymes)), put enzymes.tl:0;); put /;);
          put /; Regulated_Rxn_v(reactions) = NO;);
          
***** print the feasible best solutions **************************************************************************************************************
number = card(FmaxObj_Outer_TR) + card(FminObj_Outer_TR) + card(FmaxObj_Outer_PH) + card(FminObj_Outer_PH);

put "########## Best similarity score (LFC_ExpWarb), sum(membership grade) and regulated enzymes solved by the nested HDE ###########";
put /; put "Gene-centric regulation status: (1: Up-vf, vb; 2: Down-vf, vb; 3: KO vf & vb)"; put /;
for(i_loop = 1 to 2, put " ";); put "Cell mortality"; put "Cell viability"; put "Metabolic deviation"; put "Dissimilarity of PHCA and TRCA";
put " "; put "Similarity of PHHT and TRHT"; put " "; put "TR_outer_obj";
for(i_loop = 1 to (card(FmaxObj_Outer_TR) + card(FminObj_Outer_TR) - 1), put " ";); put "PH_outer_obj";  put /;
put "iteration"; put "best_fitness"; put "best_mem_CV_TR"; put "best_mem_CV_PH"; put "best_mem_MD_TP"; put "best_mem_MD_PHCA";
put "best_mem_MD_TRCA"; put "best_mem_MD_PHHT"; put "best_mem_MD_TRHT"; 
loop(objectSet $ (FmaxObj_Outer_TR(ObjectSet) or FminObj_Outer_TR(ObjectSet)), put ObjectSet.tl:0;);
loop(objectSet $ (FmaxObj_Outer_PH(ObjectSet) or FminObj_Outer_PH(ObjectSet)), put ObjectSet.tl:0;);
put "best_mem_Met_PHCA"; put "best_mem_rxn_PHCA"; put "best_mem_Met_TRCA"; put "best_mem_rxn_TRCA"; put "best_mem_Met_PHHT";
put "best_mem_rxn_PHHT"; put "best_mem_Met_TRHT"; put "best_mem_rxn_TRHT"; 
put "best_mem_Met_Exp_PHHT"; put "best_sumZ"; put "best_constraint"; put "best_TR_Reg_factor";
put "Reg_Status"; put "Reg_Enzyme"; put "No_isozymes_CA"; put "No_isozymes_HT"; put "No_iden_Enz_CA";  put "No_iden_Enz_HT"; put "genes"; put /;
loop(itermax_DynSubset2, put itermax_DynSubset2.tl:0; put store_best_fitness(itermax_DynSubset2):10:4;    
     put store_best_mem_CV_TR(itermax_DynSubset2):10:4; put store_best_mem_CV_PH(itermax_DynSubset2):10:4;
     put store_best_mem_MD_TP(itermax_DynSubset2):10:4; put store_best_mem_MD_PHCA(itermax_DynSubset2):10:4;
     put store_best_mem_MD_TRCA(itermax_DynSubset2):10:4; put store_best_mem_MD_PHHT(itermax_DynSubset2):10:4;
     put store_best_mem_MD_TRHT(itermax_DynSubset2):10:4;     
     loop(objectSet $ (FmaxObj_Outer_TR(ObjectSet) or FminObj_Outer_TR(ObjectSet)),
          put store_best_FMObj_outer_TR(itermax_DynSubset2, objectSet):10:4;);
     loop(objectSet $ (FmaxObj_Outer_PH(ObjectSet) or FminObj_Outer_PH(ObjectSet)),
          put store_best_FMObj_outer_PH(itermax_DynSubset2, objectSet):10:4;);
     put store_best_mem_Met_PHCA(itermax_DynSubset2):10:4; put store_best_mem_rxn_PHCA(itermax_DynSubset2):10:4;
     put store_best_mem_Met_TRCA(itermax_DynSubset2):10:4; put store_best_mem_rxn_TRCA(itermax_DynSubset2):10:4;     
     put store_best_mem_Met_PHHT(itermax_DynSubset2):10:4; put store_best_mem_rxn_PHHT(itermax_DynSubset2):10:4;
     put store_best_mem_Met_TRHT(itermax_DynSubset2):10:4; put store_best_mem_rxn_TRHT(itermax_DynSubset2):10:4;
     put store_best_mem_Met_Exp_PHHT(itermax_DynSubset2):10:4; 
     put (sum(Dim_BI, (store_bestmem_XB(itermax_DynSubset2, Dim_BI) > 0) = 1)); put store_best_constraint(itermax_DynSubset2):10:4;
     put store_bestmem_XI(itermax_DynSubset2, "RSP1"):10:4;        
     number0 = 1;
     loop(Dim_BI $ (store_bestmem_XB(itermax_dynSubset2, Dim_BI) <> 0),
          if(number0 = 1, put store_bestmem_XB(itermax_dynSubset2, Dim_BI); put Dim_BI.tl:0;
             put No_isozymes_CA(Dim_BI); put No_isozymes_HT(Dim_BI); put No_iden_Enz_CA(Dim_BI);  put No_iden_Enz_HT(Dim_BI);
             loop(genes $ (enzyme_gene(Dim_BI, genes)), put genes.tl;); number0 = 2; else
             for(i_loop = 1 to (number + 21), put " ";); put store_bestmem_XB(itermax_dynSubset2, Dim_BI); put Dim_BI.tl:0;
             put No_isozymes_CA(Dim_BI); put No_isozymes_HT(Dim_BI); put No_iden_Enz_CA(Dim_BI);  put No_iden_Enz_HT(Dim_BI);
             loop(genes $ (enzyme_gene(Dim_BI, genes)), put genes.tl;);); put /;
             for(i_loop = 1 to (number + 27), put " ";);
             Regulated_rxn_v(reactions) $ (enzyme_Reg_rxn_v(Dim_BI, reactions) and dyn_reactions(reactions)) = yes;
             loop(reactions $ (Regulated_rxn_v(reactions)), put reactions.tl:0;); put /;
          Regulated_Rxn_v(reactions) = NO;);

put /;);

***** print the computational results for the user provided biocompounds ****************************************************************************
if(card(print_biocomp) > 0,
   put "########## Print the computational results for biocompounds provided by the user ##########"; put /;
   put "===== Optimal synthesis rates for PH, CA, and HT models for each biocompound provided by the user"; put /;
   loop(biocompound $ (print_biocomp(biocompound)), put "Biocomp"; 
        put "CA_BioComp_SynRate"; put "HT_BioComp_SynRate"; put "TR_BioComp_SynRate"; put "PH_BioComp_SynRate"; put /;
        put biocompound.tl:0; put CA_BioComp_SynRate(biocompound):10:4; put HT_BioComp_SynRate(biocompound):10:4;
        put TR_BioComp_SynRate(biocompound):10:4; put PH_BioComp_SynRate(biocompound):10:4;put /;
        put "Species"; put "CA_Species_SynRate"; put "HT_Species_SynRate"; put "TR_Species_SynRate"; put "PH_Species_SynRate";put /;
        loop(species $ (BioCompound_species(biocompound, species)), put species.tl:0; put CA_Species_SynRate(species):10:4;
             put HT_Species_SynRate(species):10:4; put TR_Species_SynRate(species):10:4; put PH_Species_SynRate(species):10:4; put /;);
   put /;);

*****************************************************************************************************************************************************
   Regulated_Rxn_vf(reactions) = NO;
   Regulated_Rxn_vb(reactions) = NO;
   loop(biocompound $ (print_biocomp(biocompound)),
        put "===== The computational fluxes for the reactions involved in the species of the biocompound"; put /;
        put "BioCompound"; put biocompound.tl:0; put /;
**** determine synthesis forward reactions, vf, and backward reactions, vb, to the BioCompound regulator
        loop(species $ (BioCompound_species(biocompound, species)),
             put "Species"; put species.tl:0; put /;
             Regulated_rxn_vf(reactions) $ (S_Matrix(species, reactions) > 0 and dyn_reactions(reactions)) = yes;
             Regulated_rxn_vb(reactions) $ (S_Matrix(species, reactions) < 0 and dyn_rev_rxn(reactions)) = yes;
             if(card(Regulated_rxn_vf) > 0,
                put "rxn_vf"; put "CA_vf_UFD"; put "HT_vf_UFD"; put "TR_vf_UFD"; put "PH_vf_UFD"; put " "; put "vf_LB"; put "vf_UB";
                put " "; put "index_CA_rxn_wt"; put "index_HT_rxn_wt"; put "Reg_enz"; put "Isozymes"; put /;
                loop(reactions $ (Regulated_rxn_vf(reactions)), put reactions.tl; put CA_vf_UFD(reactions):10:4; put HT_vf_UFD(reactions):10:4;
                     put TR_vf_UFD(reactions):10:4; put PH_vf_UFD(reactions):10:4; put " ";
                     put FluxBound_vf_LB(reactions):10:4; put FluxBound_vf_UB(reactions):10:4; put " ";
                     put index_CA_rxn_wt(reactions); put index_HT_rxn_wt(reactions);                     
                     if(sum(enzymes $ (isozyme_rxn_enz(reactions, enzymes)), 1) = 0, loop(enzymes $ (enzyme_Reg_rxn_v(enzymes, reactions)), put enzymes.tl:0;););
                     if(sum(enzymes $ (isozyme_rxn_enz(reactions, enzymes)), 1) > 0, loop(enzymes $ (isozyme_rxn_enz(reactions, enzymes)), put enzymes.tl:0;););
                put /;););
             put /;
             if(card(Regulated_rxn_vb) > 0,
                put "rxn_vb"; put "CA_vb_UFD"; put "HT_vb_UFD"; put "TR_vb_UFD"; put "PH_vb_UFD"; put " "; put "vb_LB"; put "vb_UB";
                put " "; put "index_CA_rxn_wt"; put "index_HT_rxn_wt"; put "Reg_enz"; put "Isozymes"; put /;
                loop(reactions $ (Regulated_rxn_vb(reactions)), put reactions.tl; put CA_vb_UFD(reactions):10:4; put HT_vb_UFD(reactions):10:4;
                     put TR_vb_UFD(reactions):10:4; put PH_vb_UFD(reactions):10:4; put " ";
                     put FluxBound_vb_LB(reactions):10:4; put FluxBound_vb_UB(reactions):10:4; put " ";
                     put index_CA_rxn_wt(reactions); put index_HT_rxn_wt(reactions);                     
                     if(sum(enzymes $ (isozyme_rxn_enz(reactions, enzymes)), 1) = 0, loop(enzymes $ (enzyme_Reg_rxn_v(enzymes, reactions)), put enzymes.tl:0;););
                     if(sum(enzymes $ (isozyme_rxn_enz(reactions, enzymes)), 1) > 0, loop(enzymes $ (isozyme_rxn_enz(reactions, enzymes)), put enzymes.tl:0;););
                put /;););
             put /; Regulated_Rxn_vf(reactions) = NO; Regulated_Rxn_vb(reactions) = NO;);
   );
);

***** print the computational results for the user provided reactions *******************************************************************************
if(card(print_rxn) > 0,
   put "######### Print the computational fluxes for the user provided reactions ##########"; put /;
   put "rnx"; put "CA_vf"; put "CA_vb"; put "HT_vf"; put "HT_vb"; put "TR_vf"; put "TR_vb"; put "PH_vf"; put "PH_vb";
              put "vf_LB"; put "vf_UB"; put "vb_LB"; put "vb_UB"; put "irrev/rev";  put "index_CA_rxn_wt"; put "index_HT_rxn_wt"; put /;
   loop(reactions $ (print_rxn(reactions)), put reactions.tl:0; put CA_vf_UFD(reactions):10:4; put CA_vb_UFD(reactions):10:4;
        put HT_vf_UFD(reactions):10:4; put HT_vb_UFD(reactions):10:4; put TR_vf_UFD(reactions):10:4; put TR_vb_UFD(reactions):10:4;
        put PH_vf_UFD(reactions):10:4; put PH_vb_UFD(reactions):10:4; put FluxBound_vf_LB(reactions):10:4; put FluxBound_vf_UB(reactions):10:4;        
        put FluxBound_vb_LB(reactions):10:4; put FluxBound_vb_UB(reactions):10:4; put index_rxn(reactions);
        put index_CA_rxn_wt(reactions); put index_HT_rxn_wt(reactions); 
   put /;);  
);
putclose result1;
*****************************************************************************************************************************************************

file result2 /%ReportData%%outputFilename2%.gms/;
put result2;
put '$onMulti'; put /;
put "Parameters"; put /;
put @3, put "Mem_Grades_%Model_Print%(GradeSEt<) 'membership grades defined in %Model_Print% model'"; put /;
put @5, "/"; put /;
put @6, put "'CV_TR'"; put best_mem_CV_TR:10:4; put ",  'MD_TP'"; put best_mem_MD_TP:10:4;
put ",  'TR_Reg_factor'"; put best_TR_Reg_factor:10:4;
put ",  'TR_FBA_ModelStat'"; put TR_FBA_ModelStat; put ","; put /;
loop(Dim_BI $ (bestMem_XB(Dim_BI) > 0), put "'"; put Dim_BI.tl:0; put "'"; put bestmem_XB(Dim_BI); put /;); 
put @5, "/;";        
putclose result2;
*****************************************************************************************************************************************************